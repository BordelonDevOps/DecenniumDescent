﻿Decennium Descent V7 — Playtest Reports Bundle
==============================================
Generated: 2026-08-05 23:25

Contents (human-readable reports + proposed patches; raw JSON under raw_results/)

PACKS
-----
01_Combat_Class_Balance / 01-combat-class-balance
  - COMPILED_REPORT.md
  - proposed_patches/

02_Expedition_Extraction / 02-expedition-extraction
  - COMPILED_REPORT.md
  - proposed_patches/

03_Haven_Economy_Social / 03-haven-economy-social
  - COMPILED_REPORT.md
  - HAVEN_FINDINGS_SUMMARY.md (if present)
  - proposed_patches/

04_Seasonal_Decennial / 04-seasonal-decennial-persistence
  - COMPILED_REPORT.md
  - SEASONAL_REPORT.md
  - proposed_patches/

Also included
-------------
- raw_results/ — per-pack results/*.json (total source ~0.7 MB)
- _meta/ — PENDING_REVIEW.md, PLAYTEST_RUN_ROOT.md (pointers)

Note: No separate playtests/runs/** mirrors existed outside pack folders;
one clear tree is used (pack COMPILED_REPORT.md + proposed_patches + raw_results).

File inventory
--------------
01_Combat_Class_Balance/01-combat-class-balance/COMPILED_REPORT.md
01_Combat_Class_Balance/01-combat-class-balance/README_FIRST.md
01_Combat_Class_Balance/01-combat-class-balance/SCENARIO_MATRIX.csv
01_Combat_Class_Balance/01-combat-class-balance/AGENT_ROSTER.md
01_Combat_Class_Balance/01-combat-class-balance/proposed_patches/PACK01_PROPOSED_PATCHES.md
raw_results/01_Combat_Class_Balance/01-combat-class-balance/ (110 files)
02_Expedition_Extraction/02-expedition-extraction/COMPILED_REPORT.md
02_Expedition_Extraction/02-expedition-extraction/README_FIRST.md
02_Expedition_Extraction/02-expedition-extraction/SCENARIO_MATRIX.csv
02_Expedition_Extraction/02-expedition-extraction/AGENT_ROSTER.md
02_Expedition_Extraction/02-expedition-extraction/proposed_patches/PROPOSED_PATCHES.md
raw_results/02_Expedition_Extraction/02-expedition-extraction/ (91 files)
03_Haven_Economy_Social/03-haven-economy-social/COMPILED_REPORT.md
03_Haven_Economy_Social/03-haven-economy-social/HAVEN_FINDINGS_SUMMARY.md
03_Haven_Economy_Social/03-haven-economy-social/EXECUTION_LOG.md
03_Haven_Economy_Social/03-haven-economy-social/README_FIRST.md
03_Haven_Economy_Social/03-haven-economy-social/SCENARIO_MATRIX.csv
03_Haven_Economy_Social/03-haven-economy-social/AGENT_ROSTER.md
03_Haven_Economy_Social/03-haven-economy-social/proposed_patches/PROPOSED_PATCHES.json
03_Haven_Economy_Social/03-haven-economy-social/proposed_patches/PROPOSED_PATCHES.md
raw_results/03_Haven_Economy_Social/03-haven-economy-social/ (120 files)
04_Seasonal_Decennial/04-seasonal-decennial-persistence/COMPILED_REPORT.md
04_Seasonal_Decennial/04-seasonal-decennial-persistence/SEASONAL_REPORT.md
04_Seasonal_Decennial/04-seasonal-decennial-persistence/README_FIRST.md
04_Seasonal_Decennial/04-seasonal-decennial-persistence/SCENARIO_MATRIX.csv
04_Seasonal_Decennial/04-seasonal-decennial-persistence/AGENT_ROSTER.md
04_Seasonal_Decennial/04-seasonal-decennial-persistence/proposed_patches/PATCH_PROPOSALS.md
raw_results/04_Seasonal_Decennial/04-seasonal-decennial-persistence/ (104 files)
_meta/PENDING_REVIEW.md
_meta/PLAYTEST_RUN_ROOT.md
