# Umbrin Shadowblade

**Family:** Umbrin
**Knowledge status:** Established Field Record
**Publication classification:** Public
**Dungeon range:** T1, Floors 1-10
**Primary source:** Treaty delegations, undercity reports, and recovered house records
**Reliability:** High
**Encounter role:** Skirmisher or social adversary

## What It Is

Umbrin Shadowblade is a infiltrator and executioner. Even when encountered alone, it is connected to a house objective, and surviving witnesses are likely to affect later negotiations.

## What Experienced Expeditions Notice

Silk laid in deliberate geometric intervals; lamps hooded from the viewer rather than the corridor; cut gemstones left where a scout must choose whether to touch them; paired footprints that abruptly become one set.

## Creature Knowledge

Use **History or Insight** unless the Director approves a more specific approach.

| Result | Information Learned |
|---|---|
| DC 11 | Creature family, usual habitat, and dominant attack type. |
| DC 15 | The first reliable counter and the sign that its strongest ability is ready. |
| DC 19 | Its defining tactical weakness, safe harvest method, and likely retreat condition. |

## Knowledge Status and Reliability

**Status:** Established Field Record  
**Primary source:** Treaty delegations, undercity reports, and recovered house records  
**Reliability:** High  
**Last confirmed:** Current Opening and prior guild registries  
**Confirmed range:** Floors 1-10  
**Rumored range:** Regional variants may extend beyond the confirmed range

## Stat Block

**Medium Humanoid, Neutral Evil**  
**Challenge** 7 (2900 XP budget) · **Dungeon Range** T1 · **Floors** 1-10
**Armor** 15 · **Hit Points** 184 · **Speed** 40 ft.

| STR | DEX | CON | INT | WIS | CHA |
|---:|---:|---:|---:|---:|---:|
| 13 (+1) | 16 (+3) | 15 (+2) | 12 (+1) | 12 (+1) | 11 (+0) |

**Resistances** poison  
**Immunities** None  
**Condition Immunities** None  
**Tactical Vulnerability** bright-light disruption (tactical)  
**Save DC** 14  

### Traits

**House-trained Darkvision.** Bright light disrupts its stealth routes, but ordinary darkness does not impair it.

### Actions

**Multiattack.** The creature makes 2 attacks using the actions below.

**Precise Cut.** *Attack:* +7 to hit, one target. *Hit:* 2d8+6 slashing damage (average 15).

**Off-hand Strike.** *Attack:* +7 to hit, one target. *Hit:* 2d8+5 piercing damage (average 14).

## How It Fights

It opens with **Precise Cut** against the target most capable of controlling its movement. It uses **Off-hand Strike** to punish anyone who tries to stabilize that target. It fights from darkness and vertical routes, spending lives only when a house objective justifies the cost.

## How to Defeat It

**Prepare Before Contact**

- Prepare resistance or mitigation for slashing, piercing damage.
- Use broad illumination and cut silk routes.

**Combat Priority**

Remove the shadowblade or arachnomancer route network, then isolate command.

**Exploit**

The defining weakness is **bright-light disruption (tactical)**. Treat this as an encounter solution rather than an automatic damage vulnerability. Successful Research, Recon, or Resource actions should make the exploit easier or safer.

**Withdraw When**

Withdraw or change the objective when the creature reaches favorable terrain or isolates a target. A failed retreat against this creature usually costs more than abandoning the immediate treasure.

## Habitat, Goals, and Lair

Umbrin sites emphasize verticality, narrow sight lines, web bridges, false balconies, and concealed side galleries. Their fighters know every line that can be crossed without entering bright light.

The Umbrin are a subterranean people whose houses treat darkness, silk, memory, and debt as instruments of government. Their patrols are not random dungeon encounters; each is an extension of a house policy, vendetta, or negotiation.

They respect accurate names, witnessed bargains, and demonstrated restraint. Threats against children, eggs, or house memory usually end negotiation immediately.

## Treasure and Harvest

**Harvest skill:** Medicine · **Harvest DC:** 12 · **Base time:** 1 hour  
**Restriction:** Routine harvesting is culturally prohibited or legally restricted; samples require consent, lawful authority, or explicit dark-path play.  

| Component | Tier | Drop / Value |
|---|---:|---|
| Giant Bone (Tier 1) | 1 | 77%, 17 gp base |
| Massive Tooth (Tier 2) | 2 | 64%, 34 gp base |
| Thick Skin (Tier 3) | 3 | 51%, 68 gp base |

Routine body harvesting is unlawful or culturally explosive. Equipment, venom, shed chitin, silk, and battlefield salvage are the safer sources of components.

## Variants and Encounter Use

Change house allegiance, objective, silk tools, and one role ability before changing hit points. An Umbrin encounter becomes memorable when the party can identify whose policy it represents.


---
*Compiled from the cited expedition records. Uncertain claims are preserved rather than silently reconciled.*
