# Decennium Descent V7.1 — AI Playtest Master Report

**Status:** Automatically compiled evidence index. Cursor agents must complete interpretation sections.

## Evidence policy

Numerical tuning requires executable or roll-by-roll evidence. Agentic findings may support rules-clarity and usability changes but do not alone prove balance.

## Pack coverage

- **01-combat-class-balance:** 0 raw JSON results; compiled report missing
- **02-expedition-extraction:** 0 raw JSON results; compiled report missing
- **03-haven-economy-social:** 0 raw JSON results; compiled report missing
- **04-seasonal-decennial-persistence:** 0 raw JSON results; compiled report missing
- **05-readability-speed-onboarding:** 0 raw JSON results; compiled report missing
- **06-dice-level-combat-validation:** 0 raw JSON results; compiled report missing
- **07-statistical-combat-calibration:** 0 raw JSON results; compiled report missing
- **08-encounter-budget-calibration:** 0 raw JSON results; compiled report missing
- **09-feat-spell-ability-interactions:** 0 raw JSON results; compiled report missing
- **10-progression-multiclass-exploit:** 0 raw JSON results; compiled report missing
- **11-expedition-attrition-monte-carlo:** 0 raw JSON results; compiled report missing
- **12-cargo-extraction-risk:** 0 raw JSON results; compiled report missing
- **13-haven-economy-stress:** 0 raw JSON results; compiled report missing
- **14-seasonal-cycle-simulation:** 0 raw JSON results; compiled report missing
- **15-boss-control-pvp:** 0 raw JSON results; compiled report missing
- **16-rules-fuzz-property-tests:** 0 raw JSON results; compiled report missing
- **17-gm-readiness-usability:** 0 raw JSON results; compiled report missing
- **18-regression-release-gate:** 0 raw JSON results; compiled report missing

## Totals

- Raw JSON result files: 3
- Rules halts: 0
- Finding records: 0

## Baseline simulations

```json
{
  "runsPerCombatFixture": 500,
  "combatRows": 72,
  "expeditionRows": 60,
  "economyRows": 5,
  "warning": "These are chassis proxies, not full class-balance evidence."
}
```

## Rules halts


## Consolidated findings


## Required human follow-up

- Confirm turn speed and cognitive load with real players.
- Confirm Director preparation burden with an experienced GM.
- Test emotional engagement, table communication, and fun.
- Treat AI-generated tactical competence as a stress condition, not a prediction of ordinary players.

## Cursor completion instructions

Replace this section with a ranked defect list, confidence level, source evidence, proposed patch scope, and exact human playtest agenda.
