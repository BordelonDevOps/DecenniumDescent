# Decennium Descent V7.2 — AI Calibration Master Report

## Evidence standard

Only raw deterministic rolls, executable simulations, frozen fixtures, and auditable agent logs support numerical changes. AI narrative estimates are hypotheses only.

## Executable result inventory

- Machine-readable files: 11
- Invalid JSON files: 0

- `results/14-one-opening-cycle/cycle_results.csv`
- `results/14-one-opening-cycle/summary.json`
- `results/11-coupled-expedition/summary.json`
- `results/11-coupled-expedition/coupled_expedition.csv`
- `results/08-objective-calibration/summary.json`
- `results/08-objective-calibration/objective_results.csv`
- `results/16-fail-closed-fuzz/summary.json`
- `results/07-budget-autotune/summary.json`
- `results/07-budget-autotune/budget_calibration.csv`
- `results/13-haven-formulas/haven_results.csv`
- `results/13-haven-formulas/summary.json`

## Agentic pack coverage

- **01-combat-class-balance:** 0 result files; compiled report missing
- **02-expedition-extraction:** 0 result files; compiled report missing
- **03-haven-economy-social:** 0 result files; compiled report missing
- **04-seasonal-decennial-persistence:** 0 result files; compiled report missing
- **05-readability-speed-onboarding:** 0 result files; compiled report missing
- **06-dice-level-combat-validation:** 0 result files; compiled report missing
- **07-statistical-combat-calibration:** 0 result files; compiled report missing
- **08-encounter-budget-calibration:** 0 result files; compiled report missing
- **09-feat-spell-ability-interactions:** 0 result files; compiled report missing
- **10-progression-multiclass-exploit:** 0 result files; compiled report missing
- **11-expedition-attrition-monte-carlo:** 0 result files; compiled report missing
- **12-cargo-extraction-risk:** 0 result files; compiled report missing
- **13-haven-economy-stress:** 0 result files; compiled report missing
- **14-seasonal-cycle-simulation:** 0 result files; compiled report missing
- **15-boss-control-pvp:** 0 result files; compiled report missing
- **16-rules-fuzz-property-tests:** 0 result files; compiled report missing
- **17-gm-readiness-usability:** 0 result files; compiled report missing
- **18-regression-release-gate:** 0 result files; compiled report missing
- **19-sensitivity-edge-cases:** 0 result files; compiled report missing
- **20-statistical-integrity-audit:** 0 result files; compiled report missing

## Required interpretation

Cursor must add: confidence intervals, training/holdout comparison, class and persona findings, confirmed rules defects, suspected balance defects, proposed patches, rejected hypotheses, and a human-GM agenda.

## Human validation boundary

AI can stress arithmetic and procedures at scale. It cannot prove table fun, social interpretation, clarity under live conversation, emotional investment, or experienced-GM preparation burden.
