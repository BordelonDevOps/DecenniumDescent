/**
 * Game functionality for Party UI
 * Handles game state and UI updates
 */

document.addEventListener('DOMContentLoaded', function() {
    // Initialize game state
    initGameState();
    
    // Set up event listeners
    setupEventListeners();
    
    // Initialize mini-map
    initMiniMap();
    
    // Initialize chat filters
    initChatFilters();
    
    // Simulate some combat log entries
    simulateCombatLog();
});

/**
 * Game state object
 */
const gameState = {
    party: [
        { name: 'Warrior', class: 'warrior', life: 80, mana: 60, melee: 90, battleTimer: 75 },
        { name: 'Cleric', class: 'cleric', life: 90, mana: 70, melee: 50, battleTimer: 60 },
        { name: 'Wizard', class: 'wizard', life: 60, mana: 90, melee: 30, battleTimer: 85 },
        { name: 'Rogue', class: 'rogue', life: 70, mana: 50, melee: 80, battleTimer: 95 },
        { name: 'Bard', class: 'bard', life: 85, mana: 75, melee: 60, battleTimer: 50 },
        { name: 'Druid', class: 'druid', life: 75, mana: 80, melee: 40, battleTimer: 30 }
    ],
    enemy: {
        name: 'Skeleton',
        life: 70,
        battleTimer: 40
    },
    activeMember: 0,
    turnOrder: ['Warrior', 'Skeleton', 'Cleric', 'Rogue', 'Wizard', 'Bard', 'Druid'],
    currentTurn: 0
};

/**
 * Initialize game state
 */
function initGameState() {
    // Update party member displays
    updatePartyDisplay();
    
    // Update enemy display
    updateEnemyDisplay();
}

/**
 * Set up event listeners
 */
function setupEventListeners() {
    // Battle menu buttons
    const battleButtons = document.querySelectorAll('.battle-btn');
    battleButtons.forEach(button => {
        button.addEventListener('click', handleBattleAction);
    });
    
    // Party member selection
    const partyMembers = document.querySelectorAll('.party-member');
    partyMembers.forEach((member, index) => {
        member.addEventListener('click', () => {
            selectPartyMember(index);
        });
    });
}

/**
 * Handle battle action button clicks
 */
function handleBattleAction(e) {
    const action = e.target.id.replace('-btn', '');
    const activeMember = gameState.party[gameState.activeMember];
    
    let logMessage = '';
    
    switch(action) {
        case 'fight':
            logMessage = `${activeMember.name} attacks ${gameState.enemy.name} for 15 damage.`;
            gameState.enemy.life = Math.max(0, gameState.enemy.life - 15);
            break;
        case 'magic':
            logMessage = `${activeMember.name} casts Fireball on ${gameState.enemy.name} for 25 damage.`;
            gameState.enemy.life = Math.max(0, gameState.enemy.life - 25);
            gameState.party[gameState.activeMember].mana -= 10;
            break;
        case 'ability':
            logMessage = `${activeMember.name} uses a special ability.`;
            gameState.party[gameState.activeMember].melee -= 20;
            break;
        case 'item':
            logMessage = `${activeMember.name} uses a Health Potion.`;
            gameState.party[gameState.activeMember].life = Math.min(100, gameState.party[gameState.activeMember].life + 20);
            break;
        case 'search':
            logMessage = `${activeMember.name} searches the area...`;
            setTimeout(() => {
                addLogEntry('Found a treasure chest!');
            }, 1000);
            break;
        case 'flee':
            logMessage = 'The party attempts to flee...';
            setTimeout(() => {
                addLogEntry('Escape successful!');
            }, 1000);
            break;
    }
    
    // Add log entry
    addLogEntry(logMessage);
    
    // Update displays
    updatePartyDisplay();
    updateEnemyDisplay();
    
    // Simulate enemy turn
    if (gameState.enemy.life > 0) {
        setTimeout(() => {
            simulateEnemyTurn();
        }, 1500);
    }
}

/**
 * Simulate enemy turn
 */
function simulateEnemyTurn() {
    // Select random party member to attack
    const targetIndex = Math.floor(Math.random() * gameState.party.length);
    const target = gameState.party[targetIndex];
    
    // Calculate damage
    const damage = Math.floor(Math.random() * 10) + 5;
    
    // Apply damage
    gameState.party[targetIndex].life = Math.max(0, target.life - damage);
    
    // Add log entry
    addLogEntry(`${gameState.enemy.name} attacks ${target.name} for ${damage} damage.`);
    
    // Update party display
    updatePartyDisplay();
}

/**
 * Select a party member
 */
function selectPartyMember(index) {
    gameState.activeMember = index;
    
    // Update visual selection
    const partyMembers = document.querySelectorAll('.party-member');
    partyMembers.forEach((member, i) => {
        if (i === index) {
            member.style.borderColor = '#ffcc00';
            member.style.boxShadow = '0 0 10px rgba(255, 204, 0, 0.5)';
        } else {
            member.style.borderColor = '#444';
            member.style.boxShadow = 'none';
        }
    });
    
    // Add log entry
    addLogEntry(`Selected ${gameState.party[index].name}.`);
}

/**
 * Update party member displays
 */
function updatePartyDisplay() {
    const partyMembers = document.querySelectorAll('.party-member');
    
    gameState.party.forEach((member, index) => {
        if (index < partyMembers.length) {
            const memberElement = partyMembers[index];
            
            // Update name
            const nameElement = memberElement.querySelector('.member-name');
            if (nameElement) nameElement.textContent = member.name;
            
            // Update bars
            const lifeFill = memberElement.querySelector('.life-bar');
            const manaFill = memberElement.querySelector('.mana-bar');
            const meleeFill = memberElement.querySelector('.melee-bar');
            const battleFill = memberElement.querySelector('.battle-timer');
            
            if (lifeFill) lifeFill.style.width = `${member.life}%`;
            if (manaFill) manaFill.style.width = `${member.mana}%`;
            if (meleeFill) meleeFill.style.width = `${member.melee}%`;
            if (battleFill) {
                battleFill.style.width = `${member.battleTimer}%`;
                if (member.battleTimer >= 100) {
                    battleFill.classList.add('ready');
                } else {
                    battleFill.classList.remove('ready');
                }
            }
        }
    });
}

/**
 * Update enemy display
 */
function updateEnemyDisplay() {
    const enemyName = document.querySelector('#enemy-area .enemy-name');
    const lifeFill = document.querySelector('#enemy-area .life-bar');
    const battleFill = document.querySelector('#enemy-area .battle-timer');
    
    if (enemyName) enemyName.textContent = gameState.enemy.name;
    if (lifeFill) lifeFill.style.width = `${gameState.enemy.life}%`;
    if (battleFill) {
        battleFill.style.width = `${gameState.enemy.battleTimer}%`;
        if (gameState.enemy.battleTimer >= 100) {
            battleFill.classList.add('ready');
        } else {
            battleFill.classList.remove('ready');
        }
    }
}

/**
 * Add entry to combat log
 */
function addLogEntry(text, type = 'system') {
    const logEntries = document.querySelector('.log-entries');
    if (!logEntries) return;
    
    const entry = document.createElement('div');
    entry.className = `log-entry ${type}`;
    entry.textContent = text;
    
    // Add to top of log
    logEntries.insertBefore(entry, logEntries.firstChild);
    
    // Limit number of entries
    if (logEntries.children.length > 50) {
        logEntries.removeChild(logEntries.lastChild);
    }
}

/**
 * Initialize chat log filters
 */
function initChatFilters() {
    const filterButtons = document.querySelectorAll('.filter-btn');
    
    filterButtons.forEach(button => {
        button.addEventListener('click', () => {
            // Update active button
            filterButtons.forEach(btn => btn.classList.remove('active'));
            button.classList.add('active');
            
            const filter = button.getAttribute('data-filter');
            filterLogEntries(filter);
        });
    });
}

/**
 * Filter log entries based on selected filter
 */
function filterLogEntries(filter) {
    const logEntries = document.querySelectorAll('.log-entry');
    
    logEntries.forEach(entry => {
        if (filter === 'all') {
            entry.style.display = 'block';
        } else {
            if (entry.classList.contains(filter)) {
                entry.style.display = 'block';
            } else {
                entry.style.display = 'none';
            }
        }
    });
}

/**
 * Initialize mini-map
 */
function initMiniMap() {
    const mapContainer = document.querySelector('.map-container');
    if (!mapContainer) return;
    
    // Create a simple grid map
    const mapSize = 10;
    const grid = document.createElement('div');
    grid.className = 'map-grid';
    grid.style.display = 'grid';
    grid.style.gridTemplateColumns = `repeat(${mapSize}, 1fr)`;
    grid.style.gridTemplateRows = `repeat(${mapSize}, 1fr)`;
    grid.style.gap = '1px';
    grid.style.height = '100%';
    
    for (let i = 0; i < mapSize * mapSize; i++) {
        const cell = document.createElement('div');
        cell.className = 'map-cell';
        cell.style.backgroundColor = '#222';
        cell.style.border = '1px solid #333';
        
        // Add some random walls
        if (Math.random() < 0.2) {
            cell.style.backgroundColor = '#444';
        }
        
        // Add player position
        if (i === 44) {
            cell.style.backgroundColor = '#ffcc00';
        }
        
        grid.appendChild(cell);
    }
    
    mapContainer.appendChild(grid);
}

/**
 * Simulate combat log entries
 */
function simulateCombatLog() {
    // Add initial entries
    addLogEntry('You enter a dark dungeon...');
    
    setTimeout(() => {
        addLogEntry('A skeleton appears!');
    }, 1000);
    
    setTimeout(() => {
        addLogEntry('Prepare for battle!');
    }, 2000);
}

/**
 * Simulate battle timer progress
 */
function simulateBattleTimers() {
    // Update party battle timers
    gameState.party.forEach((member, index) => {
        member.battleTimer += Math.random() * 5 + 5;
        if (member.battleTimer > 100) {
            member.battleTimer = 100;
        }
    });
    
    // Update enemy battle timer
    gameState.enemy.battleTimer += Math.random() * 5 + 5;
    if (gameState.enemy.battleTimer > 100) {
        gameState.enemy.battleTimer = 100;
    }
    
    // Update displays
    updatePartyDisplay();
    updateEnemyDisplay();
}

// Simulate battle timer progress every second
setInterval(simulateBattleTimers, 1000);
