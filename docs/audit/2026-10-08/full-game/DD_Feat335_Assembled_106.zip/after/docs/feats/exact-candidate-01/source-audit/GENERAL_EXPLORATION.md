# General Exploration — source reconciliation

Derived complete-text assembly 106; exact parent review and integration pending.

Original source decisions below are historical receipts. The complete current candidate procedure and linked complete case review control this derived reading.

## GE-01 — Acrobat

### Complete original object

```json
{
  "id": "acrobat",
  "name": "Acrobat",
  "description": "You become more nimble and agile.",
  "prerequisite": "Dexterity 13 or higher",
  "effect": "You gain proficiency in the Acrobatics skill. If you are already proficient, you add double your proficiency bonus to Acrobatics checks.",
  "type": "General",
  "draft": false,
  "deprecated": false,
  "needsReview": false
}
```

### Original question

```json
"Define acquisition-time versus later qualification for existing Acrobatics proficiency, doubled PB as expertise rather than another PB source, and stacking with Athletic Prodigy/Acrobatic Mastery. Preserve distinct Acrobat and Acrobatic identities until explicitly reconciled; this feat grants no movement mode or automatic success."
```

### Preserved original source direction (historical)

```json
{
  "featId": "acrobat",
  "name": "Acrobat",
  "cohort": "general_exploration",
  "questionId": "GE-01",
  "disposition": "AUTHOR_FROM_SUBMITTED_PROCEDURE_WITH_FINAL_SHARED_RULES",
  "sourcePath": "DescentReviewChanges/ReviewBible/data/director/general_exploration_feat_operating_proposal_internal.json",
  "sourceFileSha256": "e13b824f4e6b5ecb39e409d32ecc2b2bdf6aeba9cdc229d4377c50530b067149",
  "sourcePointer": "/records/0",
  "originalQuestion": "Define acquisition-time versus later qualification for existing Acrobatics proficiency, doubled PB as expertise rather than another PB source, and stacking with Athletic Prodigy/Acrobatic Mastery. Preserve distinct Acrobat and Acrobatic identities until explicitly reconciled; this feat grants no movement mode or automatic success.",
  "originalSourceObject": {
    "id": "acrobat",
    "name": "Acrobat",
    "description": "You become more nimble and agile.",
    "prerequisite": "Dexterity 13 or higher",
    "effect": "You gain proficiency in the Acrobatics skill. If you are already proficient, you add double your proficiency bonus to Acrobatics checks.",
    "type": "General",
    "draft": false,
    "deprecated": false,
    "needsReview": false
  },
  "originalSourceObjectSha256AsSubmitted": "062d436a4340c0f78f38816daa19e8acf352e4ef6b34a44207e6513945b044c3",
  "submittedProcedure": "Gain proficiency in Acrobatics if not already proficient immediately before acquiring this feat. Otherwise use twice PB for Acrobatics checks. This does not substitute Dexterity for an Athletics check, grant a climbing Speed, improve an actual jump distance or allow a reroll. Those benefits require their own actual sources.",
  "submittedNewChoices": "Apply the shared proposed acquisition snapshot independently to each listed skill; retain full source prerequisite/effect and no stacking of Expertise.",
  "submittedWorkedCases": [
    "A DEX 16, PB +2 character without Acrobatics gains a +5 normal Dexterity (Acrobatics) modifier, not +7.",
    "A DEX 16, PB +2 character already proficient in Acrobatics now uses +7. Already having another twice-PB Acrobatics source leaves +7, not +11.",
    "Owning this feat does not satisfy a prerequisite asking for the differently named Acrobatic feat unless a future explicit identity decision says so."
  ],
  "decision": "Adopt acquisition snapshot for Acrobatics; distinct from Acrobatic and Acrobatic Mastery; twice PB replaces normal PB.",
  "completeAuthoringProcedure": "Gain proficiency in Acrobatics if not already proficient immediately before acquiring this feat. Otherwise use twice PB for Acrobatics checks. This does not substitute Dexterity for an Athletics check, grant a climbing Speed, improve an actual jump distance or allow a reroll. Those benefits require their own actual sources.",
  "newRuleProvenance": "All submitted NEW/proposed completions retained by this decision and all departures below are authoring decisions of FEAT327-SOURCE-2026-10-11, not recovered source wording. The original object remains immutable.",
  "sharedContract": "FEAT_SHARED_DIRECTIONS.json: FS-01–16",
  "supplementContract": "FEAT_SUPPLEMENT_DIRECTIONS.json: explicit source path/pointer mappings",
  "workedCases": [
    "A DEX 16, PB +2 character without Acrobatics gains a +5 normal Dexterity (Acrobatics) modifier, not +7.",
    "A DEX 16, PB +2 character already proficient in Acrobatics now uses +7. Already having another twice-PB Acrobatics source leaves +7, not +11.",
    "Owning this feat does not satisfy a prerequisite asking for the differently named Acrobatic feat unless a future explicit identity decision says so."
  ],
  "payloadOperational": "full authored procedure; not a runtime adapter",
  "selectionEnabled": false,
  "exactApproved": false,
  "runtimeApproved": false
}
```

### Complete current candidate procedure

Gain proficiency in Acrobatics if not already proficient immediately before acquiring this feat. Otherwise use twice PB for Acrobatics checks. This does not substitute Dexterity for an Athletics check, grant a climbing Speed, improve an actual jump distance or allow a reroll. Those benefits require their own actual sources.

### Original-position authored review references

```json
[
  {
    "id": "GE-01-E01",
    "report": {
      "path": "docs/audit/2026-10-08/full-game/FEAT335_EXPLORATION_ORIGINAL_CASEBOOK_REVIEW_93.json",
      "bytes": 483808,
      "sha256": "ac2f12df49630b64e6cef4ca5b163c669e911338259508223a7c5eca6933a92c"
    },
    "pointer": "/originalCaseReviews/0"
  },
  {
    "id": "GE-01-E02",
    "report": {
      "path": "docs/audit/2026-10-08/full-game/FEAT335_EXPLORATION_ORIGINAL_CASEBOOK_REVIEW_93.json",
      "bytes": 483808,
      "sha256": "ac2f12df49630b64e6cef4ca5b163c669e911338259508223a7c5eca6933a92c"
    },
    "pointer": "/originalCaseReviews/1"
  },
  {
    "id": "GE-01-E03",
    "report": {
      "path": "docs/audit/2026-10-08/full-game/FEAT335_EXPLORATION_ORIGINAL_CASEBOOK_REVIEW_93.json",
      "bytes": 483808,
      "sha256": "ac2f12df49630b64e6cef4ca5b163c669e911338259508223a7c5eca6933a92c"
    },
    "pointer": "/originalCaseReviews/2"
  }
]
```

## GE-02 — Acrobatic

### Complete original object

```json
{
  "id": "acrobatic",
  "name": "Acrobatic",
  "description": "You are exceptionally agile.",
  "prerequisite": "Dexterity 13+",
  "effect": "You gain proficiency in Acrobatics and can use Dexterity instead of Strength for Athletics checks involving jumping.",
  "type": "General",
  "draft": false,
  "deprecated": false,
  "needsReview": false
}
```

### Original question

```json
"Preserve Acrobatics proficiency and DEX substitution only for Athletics checks involving jumping. Define whether Athletics proficiency/expertise still applies, actual jump distance versus check resolution, and existing Acrobatics duplicates. Do not silently copy Acrobat expertise or waive running starts, movement budgets and landing legality."
```

### Preserved original source direction (historical)

```json
{
  "featId": "acrobatic",
  "name": "Acrobatic",
  "cohort": "general_exploration",
  "questionId": "GE-02",
  "disposition": "AUTHOR_FROM_SUBMITTED_PROCEDURE_WITH_FINAL_SHARED_RULES",
  "sourcePath": "DescentReviewChanges/ReviewBible/data/director/general_exploration_feat_operating_proposal_internal.json",
  "sourceFileSha256": "e13b824f4e6b5ecb39e409d32ecc2b2bdf6aeba9cdc229d4377c50530b067149",
  "sourcePointer": "/records/1",
  "originalQuestion": "Preserve Acrobatics proficiency and DEX substitution only for Athletics checks involving jumping. Define whether Athletics proficiency/expertise still applies, actual jump distance versus check resolution, and existing Acrobatics duplicates. Do not silently copy Acrobat expertise or waive running starts, movement budgets and landing legality.",
  "originalSourceObject": {
    "id": "acrobatic",
    "name": "Acrobatic",
    "description": "You are exceptionally agile.",
    "prerequisite": "Dexterity 13+",
    "effect": "You gain proficiency in Acrobatics and can use Dexterity instead of Strength for Athletics checks involving jumping.",
    "type": "General",
    "draft": false,
    "deprecated": false,
    "needsReview": false
  },
  "originalSourceObjectSha256AsSubmitted": "6fd1303215bcd018188080b1042780f338b736fcdd5a9514fe477633711560d6",
  "submittedProcedure": "Gain Acrobatics proficiency; an existing proficiency supplies no extra grant under the proposed fixed-grant rule. On an actual Athletics check primarily resolving a jump, you may use your Dexterity modifier in place of Strength. NEW: choose the ability before rolling. It remains an Athletics check: apply actual Athletics proficiency or Expertise once, not Acrobatics proficiency merely because Dexterity is used. This substitution changes the check only. Calculate maximum jump distance, approach, movement spent, clearance and landing from the actual movement procedure and other owned features. No automatic success, standing-jump increase, climbing Speed or Acrobatic Mastery reroll is granted.",
  "submittedNewChoices": "Pre-roll ability choice and proficiency identity; fixed duplicate-grant policy. Original Dexterity substitution is retained without importing Acrobat's Expertise.",
  "submittedWorkedCases": [
    "DEX +3, STR +1, PB +2 and Athletics proficiency gives +5 on the chosen Dexterity (Athletics) jumping check. Acrobatics Expertise does not raise it to +7.",
    "A legal check using Dexterity still cannot cross a gap beyond the character's actual jump reach or place them in an occupied landing space."
  ],
  "decision": "Keep fixed Acrobatics grant and declared Dexterity substitution for Athletics jump checks only; no Expertise, extra jump distance or reroll.",
  "completeAuthoringProcedure": "Gain Acrobatics proficiency; an existing proficiency supplies no extra grant under the proposed fixed-grant rule. On an actual Athletics check primarily resolving a jump, you may use your Dexterity modifier in place of Strength. NEW: choose the ability before rolling. It remains an Athletics check: apply actual Athletics proficiency or Expertise once, not Acrobatics proficiency merely because Dexterity is used. This substitution changes the check only. Calculate maximum jump distance, approach, movement spent, clearance and landing from the actual movement procedure and other owned features. No automatic success, standing-jump increase, climbing Speed or Acrobatic Mastery reroll is granted.",
  "newRuleProvenance": "All submitted NEW/proposed completions retained by this decision and all departures below are authoring decisions of FEAT327-SOURCE-2026-10-11, not recovered source wording. The original object remains immutable.",
  "sharedContract": "FEAT_SHARED_DIRECTIONS.json: FS-01–16",
  "supplementContract": "FEAT_SUPPLEMENT_DIRECTIONS.json: explicit source path/pointer mappings",
  "workedCases": [
    "DEX +3, STR +1, PB +2 and Athletics proficiency gives +5 on the chosen Dexterity (Athletics) jumping check. Acrobatics Expertise does not raise it to +7.",
    "A legal check using Dexterity still cannot cross a gap beyond the character's actual jump reach or place them in an occupied landing space."
  ],
  "payloadOperational": "full authored procedure; not a runtime adapter",
  "selectionEnabled": false,
  "exactApproved": false,
  "runtimeApproved": false
}
```

### Complete current candidate procedure

Gain Acrobatics proficiency; an existing proficiency supplies no extra grant under the proposed fixed-grant rule. On an actual Athletics check primarily resolving a jump, you may use your Dexterity modifier in place of Strength. NEW: choose the ability before rolling. It remains an Athletics check: apply actual Athletics proficiency or Expertise once, not Acrobatics proficiency merely because Dexterity is used. This substitution changes the check only. Calculate maximum jump distance, approach, movement spent, clearance and landing from the actual movement procedure and other owned features. No automatic success, standing-jump increase, climbing Speed or Acrobatic Mastery reroll is granted.

### Original-position authored review references

```json
[
  {
    "id": "GE-02-E01",
    "report": {
      "path": "docs/audit/2026-10-08/full-game/FEAT335_EXPLORATION_ORIGINAL_CASEBOOK_REVIEW_93.json",
      "bytes": 483808,
      "sha256": "ac2f12df49630b64e6cef4ca5b163c669e911338259508223a7c5eca6933a92c"
    },
    "pointer": "/originalCaseReviews/3"
  },
  {
    "id": "GE-02-E02",
    "report": {
      "path": "docs/audit/2026-10-08/full-game/FEAT335_EXPLORATION_ORIGINAL_CASEBOOK_REVIEW_93.json",
      "bytes": 483808,
      "sha256": "ac2f12df49630b64e6cef4ca5b163c669e911338259508223a7c5eca6933a92c"
    },
    "pointer": "/originalCaseReviews/4"
  }
]
```

## GE-03 — Actor

### Complete original object

```json
{
  "id": "actor",
  "name": "Actor",
  "description": "Skilled at mimicry and dramatics.",
  "prerequisite": "Charisma 13 or higher",
  "effect": "You have advantage on Charisma (Deception) and Charisma (Performance) checks when trying to pass yourself off as a different person.",
  "type": "General",
  "draft": false,
  "deprecated": false,
  "needsReview": false
}
```

### Original question

```json
"Bound advantage to actual CHA Deception/Performance checks to pass as a different person. Define voice, disguise and observed familiarity prerequisites without granting tools, languages, borrowed memories or automatic mimicry. Resolve magical identity scrutiny and compare pending Disguise Expert/Silver Tongue without a duplicate benefit."
```

### Preserved original source direction (historical)

```json
{
  "featId": "actor",
  "name": "Actor",
  "cohort": "general_exploration",
  "questionId": "GE-03",
  "disposition": "AUTHOR_FROM_SUBMITTED_PROCEDURE_WITH_FINAL_SHARED_RULES",
  "sourcePath": "DescentReviewChanges/ReviewBible/data/director/general_exploration_feat_operating_proposal_internal.json",
  "sourceFileSha256": "e13b824f4e6b5ecb39e409d32ecc2b2bdf6aeba9cdc229d4377c50530b067149",
  "sourcePointer": "/records/2",
  "originalQuestion": "Bound advantage to actual CHA Deception/Performance checks to pass as a different person. Define voice, disguise and observed familiarity prerequisites without granting tools, languages, borrowed memories or automatic mimicry. Resolve magical identity scrutiny and compare pending Disguise Expert/Silver Tongue without a duplicate benefit.",
  "originalSourceObject": {
    "id": "actor",
    "name": "Actor",
    "description": "Skilled at mimicry and dramatics.",
    "prerequisite": "Charisma 13 or higher",
    "effect": "You have advantage on Charisma (Deception) and Charisma (Performance) checks when trying to pass yourself off as a different person.",
    "type": "General",
    "draft": false,
    "deprecated": false,
    "needsReview": false
  },
  "originalSourceObjectSha256AsSubmitted": "8cdf7499df0426dd7c9c0cafbe7d45f9845288f81a1a9a0f9b65c21ab8f7604b",
  "submittedProcedure": "Gain advantage on actual Charisma (Deception) or Charisma (Performance) checks whose declared purpose is passing yourself off as a different person. NEW: the identity can be invented or real, but the chosen presentation must be physically possible with your actual appearance, voice, clothing, languages, knowledge and any separately active disguise or magic. Familiarity with a real person's observed traits supplies evidence for imitating those traits; it does not create an automatic perfect voice copy. The Director states what scrutiny the check resolves before rolling. A forged identity does not defeat an independent magical identification effect unless that effect actually calls for the qualifying check. This feat grants no kit, prepared disguise, extra preparation time, memories or understanding of an unlearned language. Disguise Expert's separate flat bonus may coexist only under the final feat-stacking decision; advantage itself never stacks.",
  "submittedNewChoices": "Physically plausible invented/real identity and evidence scope; no automatic mimicry grant beyond the source advantage.",
  "submittedWorkedCases": [
    "An actor who speaks the requested language and has observed a guard's manner can gain advantage on the actual Deception check to pass as that guard. The feat does not reveal the guard's private password.",
    "A magical scan that directly reports the subject's actual identity without a Deception/Performance contest is not defeated by rolling with advantage on an unrelated conversation."
  ],
  "decision": "Keep Deception/Performance advantage only for plausible impersonation; no supplied voice, memories, language or magic-scan defense.",
  "completeAuthoringProcedure": "Gain advantage on actual Charisma (Deception) or Charisma (Performance) checks whose declared purpose is passing yourself off as a different person. NEW: the identity can be invented or real, but the chosen presentation must be physically possible with your actual appearance, voice, clothing, languages, knowledge and any separately active disguise or magic. Familiarity with a real person's observed traits supplies evidence for imitating those traits; it does not create an automatic perfect voice copy. The Director states what scrutiny the check resolves before rolling. A forged identity does not defeat an independent magical identification effect unless that effect actually calls for the qualifying check. This feat grants no kit, prepared disguise, extra preparation time, memories or understanding of an unlearned language. Disguise Expert's separate flat bonus may coexist only under the final feat-stacking decision; advantage itself never stacks.",
  "newRuleProvenance": "All submitted NEW/proposed completions retained by this decision and all departures below are authoring decisions of FEAT327-SOURCE-2026-10-11, not recovered source wording. The original object remains immutable.",
  "sharedContract": "FEAT_SHARED_DIRECTIONS.json: FS-01–16",
  "supplementContract": "FEAT_SUPPLEMENT_DIRECTIONS.json: explicit source path/pointer mappings",
  "workedCases": [
    "An actor who speaks the requested language and has observed a guard's manner can gain advantage on the actual Deception check to pass as that guard. The feat does not reveal the guard's private password.",
    "A magical scan that directly reports the subject's actual identity without a Deception/Performance contest is not defeated by rolling with advantage on an unrelated conversation."
  ],
  "payloadOperational": "full authored procedure; not a runtime adapter",
  "selectionEnabled": false,
  "exactApproved": false,
  "runtimeApproved": false
}
```

### Complete current candidate procedure

Gain advantage on actual Charisma (Deception) or Charisma (Performance) checks whose declared purpose is passing yourself off as a different person. NEW: the identity can be invented or real, but the chosen presentation must be physically possible with your actual appearance, voice, clothing, languages, knowledge and any separately active disguise or magic. Familiarity with a real person's observed traits supplies evidence for imitating those traits; it does not create an automatic perfect voice copy. The Director states what scrutiny the check resolves before rolling. A forged identity does not defeat an independent magical identification effect unless that effect actually calls for the qualifying check. This feat grants no kit, prepared disguise, extra preparation time, memories or understanding of an unlearned language. Disguise Expert's separate flat bonus may coexist only under the final feat-stacking decision; advantage itself never stacks.

### Original-position authored review references

```json
[
  {
    "id": "GE-03-E01",
    "report": {
      "path": "docs/audit/2026-10-08/full-game/FEAT335_EXPLORATION_ORIGINAL_CASEBOOK_REVIEW_93.json",
      "bytes": 483808,
      "sha256": "ac2f12df49630b64e6cef4ca5b163c669e911338259508223a7c5eca6933a92c"
    },
    "pointer": "/originalCaseReviews/5"
  },
  {
    "id": "GE-03-E02",
    "report": {
      "path": "docs/audit/2026-10-08/full-game/FEAT335_EXPLORATION_ORIGINAL_CASEBOOK_REVIEW_93.json",
      "bytes": 483808,
      "sha256": "ac2f12df49630b64e6cef4ca5b163c669e911338259508223a7c5eca6933a92c"
    },
    "pointer": "/originalCaseReviews/6"
  }
]
```

## GE-04 — Animal Affinity

### Complete original object

```json
{
  "id": "animalAffinity",
  "name": "Animal Affinity",
  "description": "You have a way with animals.",
  "prerequisite": "Wisdom 13 or higher",
  "effect": "You gain proficiency in Animal Handling. If already proficient, you add double your proficiency bonus.",
  "type": "General",
  "draft": false,
  "deprecated": false,
  "needsReview": false
}
```

### Original question

```json
"Define Animal Handling proficiency and existing-proficiency doubled PB, including later proficiency, noncompounding expertise and actual eligible creatures/tasks. It creates neither telepathy, automatic obedience, a companion nor a universal social check against any creature; compare Beast Whisperer separately."
```

### Preserved original source direction (historical)

```json
{
  "featId": "animalAffinity",
  "name": "Animal Affinity",
  "cohort": "general_exploration",
  "questionId": "GE-04",
  "disposition": "AUTHOR_FROM_SUBMITTED_PROCEDURE_WITH_FINAL_SHARED_RULES",
  "sourcePath": "DescentReviewChanges/ReviewBible/data/director/general_exploration_feat_operating_proposal_internal.json",
  "sourceFileSha256": "e13b824f4e6b5ecb39e409d32ecc2b2bdf6aeba9cdc229d4377c50530b067149",
  "sourcePointer": "/records/3",
  "originalQuestion": "Define Animal Handling proficiency and existing-proficiency doubled PB, including later proficiency, noncompounding expertise and actual eligible creatures/tasks. It creates neither telepathy, automatic obedience, a companion nor a universal social check against any creature; compare Beast Whisperer separately.",
  "originalSourceObject": {
    "id": "animalAffinity",
    "name": "Animal Affinity",
    "description": "You have a way with animals.",
    "prerequisite": "Wisdom 13 or higher",
    "effect": "You gain proficiency in Animal Handling. If already proficient, you add double your proficiency bonus.",
    "type": "General",
    "draft": false,
    "deprecated": false,
    "needsReview": false
  },
  "originalSourceObjectSha256AsSubmitted": "2da8f81d39d8fdb5d9dbc0439bf4ce7d120be02f07bf6d70f920c9e47e0a64d7",
  "submittedProcedure": "Gain proficiency in Animal Handling if not already proficient immediately before acquiring this feat. Otherwise use twice PB for Animal Handling checks. Apply it to an actual Animal Handling task allowed by the creature and situation. It provides no telepathy, creature language, automatic attitude change, trained mount, companion, domination or guaranteed cooperation. A different social or knowledge skill does not gain this proficiency merely because an animal is present.",
  "submittedNewChoices": "Apply the shared proposed acquisition snapshot independently to each listed skill; retain full source prerequisite/effect and no stacking of Expertise.",
  "submittedWorkedCases": [
    "A WIS 14, PB +3 character already trained in Animal Handling uses +8 on an eligible Wisdom (Animal Handling) check.",
    "An untrained holder gains normal proficiency, then later gains another Animal Handling grant from a separate source: this feat remains its original proficiency branch. The new grant follows its own rule.",
    "Even an excellent check does not create an absent beast or let an untrained mount use combat actions unavailable under its real control procedure."
  ],
  "decision": "Adopt initial Animal Handling branch and noncompounding Expertise; no training/animal/obedience production.",
  "completeAuthoringProcedure": "Gain proficiency in Animal Handling if not already proficient immediately before acquiring this feat. Otherwise use twice PB for Animal Handling checks. Apply it to an actual Animal Handling task allowed by the creature and situation. It provides no telepathy, creature language, automatic attitude change, trained mount, companion, domination or guaranteed cooperation. A different social or knowledge skill does not gain this proficiency merely because an animal is present.",
  "newRuleProvenance": "All submitted NEW/proposed completions retained by this decision and all departures below are authoring decisions of FEAT327-SOURCE-2026-10-11, not recovered source wording. The original object remains immutable.",
  "sharedContract": "FEAT_SHARED_DIRECTIONS.json: FS-01–16",
  "supplementContract": "FEAT_SUPPLEMENT_DIRECTIONS.json: explicit source path/pointer mappings",
  "workedCases": [
    "A WIS 14, PB +3 character already trained in Animal Handling uses +8 on an eligible Wisdom (Animal Handling) check.",
    "An untrained holder gains normal proficiency, then later gains another Animal Handling grant from a separate source: this feat remains its original proficiency branch. The new grant follows its own rule.",
    "Even an excellent check does not create an absent beast or let an untrained mount use combat actions unavailable under its real control procedure."
  ],
  "payloadOperational": "full authored procedure; not a runtime adapter",
  "selectionEnabled": false,
  "exactApproved": false,
  "runtimeApproved": false
}
```

### Complete current candidate procedure

Gain proficiency in Animal Handling if not already proficient immediately before acquiring this feat. Otherwise use twice PB for Animal Handling checks. Apply it to an actual Animal Handling task allowed by the creature and situation. It provides no telepathy, creature language, automatic attitude change, trained mount, companion, domination or guaranteed cooperation. A different social or knowledge skill does not gain this proficiency merely because an animal is present.

### Original-position authored review references

```json
[
  {
    "id": "GE-04-E01",
    "report": {
      "path": "docs/audit/2026-10-08/full-game/FEAT335_EXPLORATION_ORIGINAL_CASEBOOK_REVIEW_93.json",
      "bytes": 483808,
      "sha256": "ac2f12df49630b64e6cef4ca5b163c669e911338259508223a7c5eca6933a92c"
    },
    "pointer": "/originalCaseReviews/7"
  },
  {
    "id": "GE-04-E02",
    "report": {
      "path": "docs/audit/2026-10-08/full-game/FEAT335_EXPLORATION_ORIGINAL_CASEBOOK_REVIEW_93.json",
      "bytes": 483808,
      "sha256": "ac2f12df49630b64e6cef4ca5b163c669e911338259508223a7c5eca6933a92c"
    },
    "pointer": "/originalCaseReviews/8"
  },
  {
    "id": "GE-04-E03",
    "report": {
      "path": "docs/audit/2026-10-08/full-game/FEAT335_EXPLORATION_ORIGINAL_CASEBOOK_REVIEW_93.json",
      "bytes": 483808,
      "sha256": "ac2f12df49630b64e6cef4ca5b163c669e911338259508223a7c5eca6933a92c"
    },
    "pointer": "/originalCaseReviews/9"
  }
]
```

## GE-05 — Appraise

### Complete original object

```json
{
  "id": "appraise",
  "name": "Appraise",
  "description": "You can accurately determine the value of items.",
  "prerequisite": "Intelligence 13+",
  "effect": "You can determine the exact value and properties of any item with a successful Investigation check.",
  "type": "General",
  "draft": false,
  "deprecated": false,
  "needsReview": false
}
```

### Original question

```json
"Source says exact value and properties of any item on Investigation success. Complete time/action, DC, access/tools, what exact value means absent a buyer, and magical/hidden/cursed/restricted properties. Distinguish mundane appraisal from Identify and formula discovery; no automatic private-lore exposure, artifact classification or guaranteed sale."
```

### Preserved original source direction (historical)

```json
{
  "featId": "appraise",
  "name": "Appraise",
  "cohort": "general_exploration",
  "questionId": "GE-05",
  "disposition": "AUTHOR_FROM_EXACT_REPLACEMENT_WITH_FINAL_SHARED_RULES",
  "sourcePath": "DescentReviewChanges/ReviewBible/data/director/general_exploration_feat_operating_proposal_internal.json",
  "sourceFileSha256": "e13b824f4e6b5ecb39e409d32ecc2b2bdf6aeba9cdc229d4377c50530b067149",
  "sourcePointer": "/records/4",
  "originalQuestion": "Source says exact value and properties of any item on Investigation success. Complete time/action, DC, access/tools, what exact value means absent a buyer, and magical/hidden/cursed/restricted properties. Distinguish mundane appraisal from Identify and formula discovery; no automatic private-lore exposure, artifact classification or guaranteed sale.",
  "originalSourceObject": {
    "id": "appraise",
    "name": "Appraise",
    "description": "You can accurately determine the value of items.",
    "prerequisite": "Intelligence 13+",
    "effect": "You can determine the exact value and properties of any item with a successful Investigation check.",
    "type": "General",
    "draft": false,
    "deprecated": false,
    "needsReview": false
  },
  "originalSourceObjectSha256AsSubmitted": "e388a4269ef6b5cce5fc61c174287d76747a47277fea8e00fb3f1de566970a76",
  "submittedProcedure": "Spend ten active minutes closely inspecting one actual item with adequate sensory access and tools appropriate to safely examine it. NEW: make Intelligence (Investigation), DC10 for a plainly identifiable mundane object,15 for complex mundane construction,20 for an ordinary magical item, or25 for a unique unfamiliar construction; a specific item's explicit identification DC or concealment exception controls instead. Set the classification and actual information before rolling. On Success or Critical Success, learn its exact current reference value and complete discoverable operative properties, including magical properties and a curse unless that curse's specific source prevents this identification. Reference value means the recorded undamaged catalog price adjusted by the governing condition/valuation rule, or a Director-established local fair-market valuation when no catalog price exists, fixed before the roll. It is not a guaranteed purchase or sale offer. The property result states uses, limits, charges, activation and known operational risks from the actual item's complete record; it does not invent a missing profile, formula, historical truth or cosmology. A source explicitly resisting identification may withhold its protected part while other properties are identified. Safe appraisal is not activation or disarming; actual independent touch/proximity triggers remain. Failure spends time and yields no exact appraisal; another attempt needs changed evidence, access or method. This deliberately preserves a powerful item-identification benefit and requires direct comparison with Identify before adoption.",
  "submittedNewChoices": "Time, DC tiers, value definition, magic/curse scope and explicit identification exceptions. Restricting any source's 'any item' promise requires the stated joint decision.",
  "submittedWorkedCases": [
    "A known item with reference value40gp can be appraised at40gp while a real buyer offers only20gp. The feat identifies the reference value; it does not compel that buyer to pay40gp.",
    "An ordinary magical wand's complete operative profile can be learned on the proposed DC20 success. An explicitly identification-proof curse remains protected by its own source; its lore is not invented."
  ],
  "decision": "Adopt the broad source identification benefit with finite examination/known-property limits and preserve the completed thirty-minute Haven appraisal and settlement.",
  "completeAuthoringProcedure": "Spend ten active minutes closely inspecting one actual item with adequate sensory access and tools appropriate to safely examine it. NEW: make Intelligence (Investigation), DC10 for a plainly identifiable mundane object,15 for complex mundane construction,20 for an ordinary magical item, or25 for a unique unfamiliar construction; a specific item's explicit identification DC or concealment exception controls instead. Set the classification and actual information before rolling. On Success or Critical Success, learn its exact current reference value and complete discoverable operative properties, including magical properties and a curse unless that curse's specific source prevents this identification. Reference value means the recorded undamaged catalog price adjusted by the governing condition/valuation rule, or a Director-established local fair-market valuation when no catalog price exists, fixed before the roll. It is not a guaranteed purchase or sale offer. The property result states uses, limits, charges, activation and known operational risks from the actual item's complete record; it does not invent a missing profile, formula, historical truth or cosmology. A source explicitly resisting identification may withhold its protected part while other properties are identified. Safe appraisal is not activation or disarming; actual independent touch/proximity triggers remain. Failure spends time and yields no exact appraisal; another attempt needs changed evidence, access or method. This explicitly adopts the powerful source item-identification benefit. It differs from the reviewed Identify procedure; it does not amend Identify or make its protected disclosures public.\nNEW settlement binding: a Haven Appraisal remains the full thirty-minute EX58 procedure with its own governing DC, actor, evidence and one check. This ten-minute direct examination may be performed as a genuine included part of that same appraisal, not as a free second valuation, skipped twenty minutes or concurrent second job. Standalone appraisal does not itself execute title/provenance, buyer negotiation, tax, sponsor, insurance or settlement. Reference price, actual agreed gross price and net receipts remain separate; apply FS-13 and the retained greater-of assay rule.",
  "newRuleProvenance": "All submitted NEW/proposed completions retained by this decision and all departures below are authoring decisions of FEAT327-SOURCE-2026-10-11, not recovered source wording. The original object remains immutable.",
  "sharedContract": "FEAT_SHARED_DIRECTIONS.json: FS-01–16",
  "supplementContract": "FEAT_SUPPLEMENT_DIRECTIONS.json: explicit source path/pointer mappings",
  "workedCases": [
    "A known item with reference value40gp can be appraised at40gp while a real buyer offers only20gp. The feat identifies the reference value; it does not compel that buyer to pay40gp.",
    "An ordinary magical wand's complete operative profile can be learned on the proposed DC20 success. An explicitly identification-proof curse remains protected by its own source; its lore is not invented."
  ],
  "payloadOperational": "full authored procedure; not a runtime adapter",
  "selectionEnabled": false,
  "exactApproved": false,
  "runtimeApproved": false
}
```

### Complete current candidate procedure

Spend ten active minutes closely inspecting one actual item with adequate sensory access and tools appropriate to safely examine it. NEW: make Intelligence (Investigation), DC10 for a plainly identifiable mundane object,15 for complex mundane construction,20 for an ordinary magical item, or25 for a unique unfamiliar construction; a specific item's explicit identification DC or concealment exception controls instead. Set the classification and actual information before rolling. On Success or Critical Success, learn its exact current reference value and complete discoverable operative properties, including magical properties and a curse unless that curse's specific source prevents this identification. Reference value means the recorded undamaged catalog price adjusted by the governing condition/valuation rule, or a Director-established local fair-market valuation when no catalog price exists, fixed before the roll. It is not a guaranteed purchase or sale offer. The property result states uses, limits, charges, activation and known operational risks from the actual item's complete record; it does not invent a missing profile, formula, historical truth or cosmology. A source explicitly resisting identification may withhold its protected part while other properties are identified. Safe appraisal is not activation or disarming; actual independent touch/proximity triggers remain. Failure spends time and yields no exact appraisal; another attempt needs changed evidence, access or method. This explicitly adopts the powerful source item-identification benefit. It differs from the reviewed Identify procedure; it does not amend Identify or make its protected disclosures public.
NEW settlement binding: a Haven Appraisal remains the full thirty-minute EX58 procedure with its own governing DC, actor, evidence and one check. This ten-minute direct examination may be performed as a genuine included part of that same appraisal, not as a free second valuation, skipped twenty minutes or concurrent second job. Standalone appraisal does not itself execute title/provenance, buyer negotiation, tax, sponsor, insurance or settlement. Reference price, actual agreed gross price and net receipts remain separate; apply FS-13 and the retained greater-of assay rule.

### Original-position authored review references

```json
[
  {
    "id": "GE-05-E01",
    "report": {
      "path": "docs/audit/2026-10-08/full-game/FEAT335_EXPLORATION_ORIGINAL_CASEBOOK_REVIEW_93.json",
      "bytes": 483808,
      "sha256": "ac2f12df49630b64e6cef4ca5b163c669e911338259508223a7c5eca6933a92c"
    },
    "pointer": "/originalCaseReviews/10"
  },
  {
    "id": "GE-05-E02",
    "report": {
      "path": "docs/audit/2026-10-08/full-game/FEAT335_EXPLORATION_ORIGINAL_CASEBOOK_REVIEW_93.json",
      "bytes": 483808,
      "sha256": "ac2f12df49630b64e6cef4ca5b163c669e911338259508223a7c5eca6933a92c"
    },
    "pointer": "/originalCaseReviews/11"
  },
  {
    "id": "FA-14",
    "report": {
      "path": "docs/audit/2026-10-08/full-game/FEAT335_EXPLORATION_ORIGINAL_CASEBOOK_REVIEW_93.json",
      "bytes": 483808,
      "sha256": "ac2f12df49630b64e6cef4ca5b163c669e911338259508223a7c5eca6933a92c"
    },
    "pointer": "/additionalBoundaryReviews/1"
  },
  {
    "id": "FA-15",
    "report": {
      "path": "docs/audit/2026-10-08/full-game/FEAT335_EXPLORATION_ORIGINAL_CASEBOOK_REVIEW_93.json",
      "bytes": 483808,
      "sha256": "ac2f12df49630b64e6cef4ca5b163c669e911338259508223a7c5eca6933a92c"
    },
    "pointer": "/additionalBoundaryReviews/2"
  }
]
```

## GE-06 — Athletic Prodigy

### Complete original object

```json
{
  "id": "athleticProdigy",
  "name": "Athletic Prodigy",
  "description": "Your physical prowess is exceptional.",
  "prerequisite": "Strength or Dexterity 15 or higher",
  "effect": "You gain proficiency in Athletics and Acrobatics. If already proficient, you add double your proficiency bonus.",
  "type": "General",
  "draft": false,
  "deprecated": false,
  "needsReview": false
}
```

### Original question

```json
"Preserve both Athletics and Acrobatics grants under STRorDEX15. Decide existing-proficiency expertise separately for each skill, acquisition timing and later proficiency. Prevent quadruple PB with Acrobat/other expertise; this grants no extra movement mode, substituted ability or universal success."
```

### Preserved original source direction (historical)

```json
{
  "featId": "athleticProdigy",
  "name": "Athletic Prodigy",
  "cohort": "general_exploration",
  "questionId": "GE-06",
  "disposition": "AUTHOR_FROM_SUBMITTED_PROCEDURE_WITH_FINAL_SHARED_RULES",
  "sourcePath": "DescentReviewChanges/ReviewBible/data/director/general_exploration_feat_operating_proposal_internal.json",
  "sourceFileSha256": "e13b824f4e6b5ecb39e409d32ecc2b2bdf6aeba9cdc229d4377c50530b067149",
  "sourcePointer": "/records/5",
  "originalQuestion": "Preserve both Athletics and Acrobatics grants under STRorDEX15. Decide existing-proficiency expertise separately for each skill, acquisition timing and later proficiency. Prevent quadruple PB with Acrobat/other expertise; this grants no extra movement mode, substituted ability or universal success.",
  "originalSourceObject": {
    "id": "athleticProdigy",
    "name": "Athletic Prodigy",
    "description": "Your physical prowess is exceptional.",
    "prerequisite": "Strength or Dexterity 15 or higher",
    "effect": "You gain proficiency in Athletics and Acrobatics. If already proficient, you add double your proficiency bonus.",
    "type": "General",
    "draft": false,
    "deprecated": false,
    "needsReview": false
  },
  "originalSourceObjectSha256AsSubmitted": "5035953807bded8c5aae6c4f8ca33d6ba3680702fcdd7759ed68eb91e245982e",
  "submittedProcedure": "The prerequisite is Strength 15 or Dexterity 15; either permanent score suffices. Evaluate Athletics and Acrobatics separately at acquisition. Grant proficiency in each untrained skill and twice-PB Expertise in each already proficient skill. Neither skill grant changes which ability the ordinary task uses. The feat gives no Speed, movement, jumping-distance increase or automatic success. Other Expertise in one of these skills is an overlapping grant of twice PB, not another multiplier.",
  "submittedNewChoices": "Apply the shared proposed acquisition snapshot independently to each listed skill; retain full source prerequisite/effect and no stacking of Expertise.",
  "submittedWorkedCases": [
    "STR 15, DEX 12 meets the prerequisite. If Athletics is already trained but Acrobatics is not, acquire Athletics Expertise and ordinary Acrobatics proficiency.",
    "With PB +3, STR +2 and DEX +1 in that mixed case, ordinary Athletics is +8 and ordinary Acrobatics is +4. An Acrobatics roll of 12 totals 16.",
    "If both skills are already proficient, both gain twice PB independently. If both already have Expertise, neither becomes four times PB."
  ],
  "decision": "Adopt separate Athletics/Acrobatics acquisition snapshots and source STR-or-DEX prerequisite, with no multiple proficiency terms.",
  "completeAuthoringProcedure": "The prerequisite is Strength 15 or Dexterity 15; either permanent score suffices. Evaluate Athletics and Acrobatics separately at acquisition. Grant proficiency in each untrained skill and twice-PB Expertise in each already proficient skill. Neither skill grant changes which ability the ordinary task uses. The feat gives no Speed, movement, jumping-distance increase or automatic success. Other Expertise in one of these skills is an overlapping grant of twice PB, not another multiplier.",
  "newRuleProvenance": "All submitted NEW/proposed completions retained by this decision and all departures below are authoring decisions of FEAT327-SOURCE-2026-10-11, not recovered source wording. The original object remains immutable.",
  "sharedContract": "FEAT_SHARED_DIRECTIONS.json: FS-01–16",
  "supplementContract": "FEAT_SUPPLEMENT_DIRECTIONS.json: explicit source path/pointer mappings",
  "workedCases": [
    "STR 15, DEX 12 meets the prerequisite. If Athletics is already trained but Acrobatics is not, acquire Athletics Expertise and ordinary Acrobatics proficiency.",
    "With PB +3, STR +2 and DEX +1 in that mixed case, ordinary Athletics is +8 and ordinary Acrobatics is +4. An Acrobatics roll of 12 totals 16.",
    "If both skills are already proficient, both gain twice PB independently. If both already have Expertise, neither becomes four times PB."
  ],
  "payloadOperational": "full authored procedure; not a runtime adapter",
  "selectionEnabled": false,
  "exactApproved": false,
  "runtimeApproved": false
}
```

### Complete current candidate procedure

The prerequisite is Strength 15 or Dexterity 15; either permanent score suffices. Evaluate Athletics and Acrobatics separately at acquisition. Grant proficiency in each untrained skill and twice-PB Expertise in each already proficient skill. Neither skill grant changes which ability the ordinary task uses. The feat gives no Speed, movement, jumping-distance increase or automatic success. Other Expertise in one of these skills is an overlapping grant of twice PB, not another multiplier.

### Original-position authored review references

```json
[
  {
    "id": "GE-06-E01",
    "report": {
      "path": "docs/audit/2026-10-08/full-game/FEAT335_EXPLORATION_ORIGINAL_CASEBOOK_REVIEW_93.json",
      "bytes": 483808,
      "sha256": "ac2f12df49630b64e6cef4ca5b163c669e911338259508223a7c5eca6933a92c"
    },
    "pointer": "/originalCaseReviews/12"
  },
  {
    "id": "GE-06-E02",
    "report": {
      "path": "docs/audit/2026-10-08/full-game/FEAT335_EXPLORATION_ORIGINAL_CASEBOOK_REVIEW_93.json",
      "bytes": 483808,
      "sha256": "ac2f12df49630b64e6cef4ca5b163c669e911338259508223a7c5eca6933a92c"
    },
    "pointer": "/originalCaseReviews/13"
  },
  {
    "id": "GE-06-E03",
    "report": {
      "path": "docs/audit/2026-10-08/full-game/FEAT335_EXPLORATION_ORIGINAL_CASEBOOK_REVIEW_93.json",
      "bytes": 483808,
      "sha256": "ac2f12df49630b64e6cef4ca5b163c669e911338259508223a7c5eca6933a92c"
    },
    "pointer": "/originalCaseReviews/14"
  }
]
```

## GE-07 — Bruiser

### Complete original object

```json
{
  "id": "bruiser",
  "name": "Bruiser",
  "description": "You excel at intimidating and overpowering foes.",
  "prerequisite": "Strength 15+",
  "effect": "You gain proficiency in Intimidation and can use Strength instead of Charisma for Intimidation checks.",
  "type": "General",
  "draft": false,
  "deprecated": false,
  "needsReview": false
}
```

### Original question

```json
"Preserve Intimidation proficiency and optional STR instead of CHA for legitimate Intimidation checks. Define choice timing, contextual limits and proficiency-once; compare Commanding Presence wording. Successful intimidation does not automatically charm, dominate, force impossible cooperation or establish frightened without an explicit procedure."
```

### Preserved original source direction (historical)

```json
{
  "featId": "bruiser",
  "name": "Bruiser",
  "cohort": "general_exploration",
  "questionId": "GE-07",
  "disposition": "AUTHOR_FROM_SUBMITTED_PROCEDURE_WITH_FINAL_SHARED_RULES",
  "sourcePath": "DescentReviewChanges/ReviewBible/data/director/general_exploration_feat_operating_proposal_internal.json",
  "sourceFileSha256": "e13b824f4e6b5ecb39e409d32ecc2b2bdf6aeba9cdc229d4377c50530b067149",
  "sourcePointer": "/records/6",
  "originalQuestion": "Preserve Intimidation proficiency and optional STR instead of CHA for legitimate Intimidation checks. Define choice timing, contextual limits and proficiency-once; compare Commanding Presence wording. Successful intimidation does not automatically charm, dominate, force impossible cooperation or establish frightened without an explicit procedure.",
  "originalSourceObject": {
    "id": "bruiser",
    "name": "Bruiser",
    "description": "You excel at intimidating and overpowering foes.",
    "prerequisite": "Strength 15+",
    "effect": "You gain proficiency in Intimidation and can use Strength instead of Charisma for Intimidation checks.",
    "type": "General",
    "draft": false,
    "deprecated": false,
    "needsReview": false
  },
  "originalSourceObjectSha256AsSubmitted": "f8b869d9dd345664ea5f3a1b18d978097d1146fbd2ae8496951d78329787b392",
  "submittedProcedure": "Gain Intimidation proficiency. When making an actual Intimidation check, you may substitute Strength for Charisma. NEW: declare that choice before rolling and describe an actual physically intimidating presentation the target can perceive; false impossible strength or an absent threat does not become evidence from the feat. The check remains Intimidation and uses its applicable proficiency contribution once. Other legal intimidation methods may still use Charisma. This feat changes neither the ordinary social stakes nor the cost of violence, reputation, payment or consent. A successful check does not automatically impose Frightened, Charmed, obedience, a surrendered asset or a condition not included in the declared possible outcome. Commanding Presence remains a distinct source with its own reverse-substitution wording.",
  "submittedNewChoices": "Pre-roll declared method and Strength substitution; fixed duplicate-proficiency policy.",
  "submittedWorkedCases": [
    "STR +4, CHA -1 and PB +3 yields +7 for a qualifying Strength (Intimidation) check. Proficiency is not added again because an intimidating weapon is present.",
    "A guard incapable of perceiving the display receives no automatic intimidation consequence. On an actual successful exchange, resolve only the possible concession stated before the roll."
  ],
  "decision": "Keep actual physical Strength Intimidation option and fixed proficiency; possible social stakes/channel still govern.",
  "completeAuthoringProcedure": "Gain Intimidation proficiency. When making an actual Intimidation check, you may substitute Strength for Charisma. NEW: declare that choice before rolling and describe an actual physically intimidating presentation the target can perceive; false impossible strength or an absent threat does not become evidence from the feat. The check remains Intimidation and uses its applicable proficiency contribution once. Other legal intimidation methods may still use Charisma. This feat changes neither the ordinary social stakes nor the cost of violence, reputation, payment or consent. A successful check does not automatically impose Frightened, Charmed, obedience, a surrendered asset or a condition not included in the declared possible outcome. Commanding Presence remains a distinct source with its own reverse-substitution wording.",
  "newRuleProvenance": "All submitted NEW/proposed completions retained by this decision and all departures below are authoring decisions of FEAT327-SOURCE-2026-10-11, not recovered source wording. The original object remains immutable.",
  "sharedContract": "FEAT_SHARED_DIRECTIONS.json: FS-01–16",
  "supplementContract": "FEAT_SUPPLEMENT_DIRECTIONS.json: explicit source path/pointer mappings",
  "workedCases": [
    "STR +4, CHA -1 and PB +3 yields +7 for a qualifying Strength (Intimidation) check. Proficiency is not added again because an intimidating weapon is present.",
    "A guard incapable of perceiving the display receives no automatic intimidation consequence. On an actual successful exchange, resolve only the possible concession stated before the roll."
  ],
  "payloadOperational": "full authored procedure; not a runtime adapter",
  "selectionEnabled": false,
  "exactApproved": false,
  "runtimeApproved": false
}
```

### Complete current candidate procedure

Gain Intimidation proficiency. When making an actual Intimidation check, you may substitute Strength for Charisma. NEW: declare that choice before rolling and describe an actual physically intimidating presentation the target can perceive; false impossible strength or an absent threat does not become evidence from the feat. The check remains Intimidation and uses its applicable proficiency contribution once. Other legal intimidation methods may still use Charisma. This feat changes neither the ordinary social stakes nor the cost of violence, reputation, payment or consent. A successful check does not automatically impose Frightened, Charmed, obedience, a surrendered asset or a condition not included in the declared possible outcome. Commanding Presence remains a distinct source with its own reverse-substitution wording.

### Original-position authored review references

```json
[
  {
    "id": "GE-07-E01",
    "report": {
      "path": "docs/audit/2026-10-08/full-game/FEAT335_EXPLORATION_ORIGINAL_CASEBOOK_REVIEW_93.json",
      "bytes": 483808,
      "sha256": "ac2f12df49630b64e6cef4ca5b163c669e911338259508223a7c5eca6933a92c"
    },
    "pointer": "/originalCaseReviews/15"
  },
  {
    "id": "GE-07-E02",
    "report": {
      "path": "docs/audit/2026-10-08/full-game/FEAT335_EXPLORATION_ORIGINAL_CASEBOOK_REVIEW_93.json",
      "bytes": 483808,
      "sha256": "ac2f12df49630b64e6cef4ca5b163c669e911338259508223a7c5eca6933a92c"
    },
    "pointer": "/originalCaseReviews/16"
  }
]
```

## GE-08 — Cartographer

### Complete original object

```json
{
  "id": "cartographer",
  "name": "Cartographer",
  "description": "You excel at navigation and mapmaking.",
  "prerequisite": "Intelligence 13+",
  "effect": "You can create accurate maps and never get lost. You have advantage on Survival checks for navigation.",
  "type": "General",
  "draft": false,
  "deprecated": false,
  "needsReview": false
}
```

### Original question

```json
"Complete tools/materials, work time and information fidelity for accurate maps; never-get-lost must specify known routes, missing information, illusions, teleportation and changed terrain. Retain navigation Survival advantage but no omniscient map, revealed secrets or automatic access. Compare Dungeon Cartographer and actual exploration procedures."
```

### Preserved original source direction (historical)

```json
{
  "featId": "cartographer",
  "name": "Cartographer",
  "cohort": "general_exploration",
  "questionId": "GE-08",
  "disposition": "AUTHOR_FROM_SUBMITTED_PROCEDURE_WITH_FINAL_SHARED_RULES",
  "sourcePath": "DescentReviewChanges/ReviewBible/data/director/general_exploration_feat_operating_proposal_internal.json",
  "sourceFileSha256": "e13b824f4e6b5ecb39e409d32ecc2b2bdf6aeba9cdc229d4377c50530b067149",
  "sourcePointer": "/records/7",
  "originalQuestion": "Complete tools/materials, work time and information fidelity for accurate maps; never-get-lost must specify known routes, missing information, illusions, teleportation and changed terrain. Retain navigation Survival advantage but no omniscient map, revealed secrets or automatic access. Compare Dungeon Cartographer and actual exploration procedures.",
  "originalSourceObject": {
    "id": "cartographer",
    "name": "Cartographer",
    "description": "You excel at navigation and mapmaking.",
    "prerequisite": "Intelligence 13+",
    "effect": "You can create accurate maps and never get lost. You have advantage on Survival checks for navigation.",
    "type": "General",
    "draft": false,
    "deprecated": false,
    "needsReview": false
  },
  "originalSourceObjectSha256AsSubmitted": "bf7a0c0dd28ce576d8534d097308489d60fb915ab52cf1a216728ed7602af2b2",
  "submittedProcedure": "Create an accurate record of a route or place you actually observe, using real recording materials. NEW: record one minute of active map work for each distinct junction or approximately100feet of visible route, whichever requires more work; a scale overview from a clear vantage can be recorded in ten minutes. Ordinary mapping is separate work unless another feature, such as Dungeon Cartographer, permits concurrent normal-pace mapping. 'Never get lost' means you retain a reliable account of your own traversed path and current position relative to its still-valid recorded landmarks: you cannot accidentally choose a wrong already-known branch solely through a navigation failure. It does not reveal an unvisited area, locate an unknown destination, connect an unobserved teleportation gap or preserve a physically destroyed route. A changed or illusory landmark may require investigation; the feat preserves what was actually perceived rather than certifying it true. Gain advantage on actual Survival navigation checks, including where incomplete new information still makes the route uncertain. Others using your map receive its actual information, not your personal never-lost guarantee or advantage unless another feature grants it.",
  "submittedNewChoices": "Finite mapping times; explicit proposed meaning of 'never get lost'; traversed-route guarantee, changed terrain and user-specific benefit.",
  "submittedWorkedCases": [
    "On an unchanged route the holder already traversed, a failed navigation check cannot make them accidentally take the wrong recorded junction. A missing bridge still requires a real solution.",
    "After an unobserved teleportation, the old map remains accurate where its terrain survives, but the feat supplies no invented connection between departure and arrival."
  ],
  "decision": "Adopt finite map work and personal traversed-route guarantee; source absolute wording is expressly bounded, not used to invent unseen/teleported geography.",
  "completeAuthoringProcedure": "Create an accurate record of a route or place you actually observe, using real recording materials. NEW: record one minute of active map work for each distinct junction or approximately100feet of visible route, whichever requires more work; a scale overview from a clear vantage can be recorded in ten minutes. Ordinary mapping is separate work unless another feature, such as Dungeon Cartographer, permits concurrent normal-pace mapping. 'Never get lost' means you retain a reliable account of your own traversed path and current position relative to its still-valid recorded landmarks: you cannot accidentally choose a wrong already-known branch solely through a navigation failure. It does not reveal an unvisited area, locate an unknown destination, connect an unobserved teleportation gap or preserve a physically destroyed route. A changed or illusory landmark may require investigation; the feat preserves what was actually perceived rather than certifying it true. Gain advantage on actual Survival navigation checks, including where incomplete new information still makes the route uncertain. Others using your map receive its actual information, not your personal never-lost guarantee or advantage unless another feature grants it.",
  "newRuleProvenance": "All submitted NEW/proposed completions retained by this decision and all departures below are authoring decisions of FEAT327-SOURCE-2026-10-11, not recovered source wording. The original object remains immutable.",
  "sharedContract": "FEAT_SHARED_DIRECTIONS.json: FS-01–16",
  "supplementContract": "FEAT_SUPPLEMENT_DIRECTIONS.json: explicit source path/pointer mappings",
  "workedCases": [
    "On an unchanged route the holder already traversed, a failed navigation check cannot make them accidentally take the wrong recorded junction. A missing bridge still requires a real solution.",
    "After an unobserved teleportation, the old map remains accurate where its terrain survives, but the feat supplies no invented connection between departure and arrival."
  ],
  "payloadOperational": "full authored procedure; not a runtime adapter",
  "selectionEnabled": false,
  "exactApproved": false,
  "runtimeApproved": false
}
```

### Complete current candidate procedure

Create an accurate record of a route or place you actually observe, using real recording materials. NEW: record one minute of active map work for each distinct junction or approximately100feet of visible route, whichever requires more work; a scale overview from a clear vantage can be recorded in ten minutes. Ordinary mapping is separate work unless another feature, such as Dungeon Cartographer, permits concurrent normal-pace mapping. 'Never get lost' means you retain a reliable account of your own traversed path and current position relative to its still-valid recorded landmarks: you cannot accidentally choose a wrong already-known branch solely through a navigation failure. It does not reveal an unvisited area, locate an unknown destination, connect an unobserved teleportation gap or preserve a physically destroyed route. A changed or illusory landmark may require investigation; the feat preserves what was actually perceived rather than certifying it true. Gain advantage on actual Survival navigation checks, including where incomplete new information still makes the route uncertain. Others using your map receive its actual information, not your personal never-lost guarantee or advantage unless another feature grants it.

### Original-position authored review references

```json
[
  {
    "id": "GE-08-E01",
    "report": {
      "path": "docs/audit/2026-10-08/full-game/FEAT335_EXPLORATION_ORIGINAL_CASEBOOK_REVIEW_93.json",
      "bytes": 483808,
      "sha256": "ac2f12df49630b64e6cef4ca5b163c669e911338259508223a7c5eca6933a92c"
    },
    "pointer": "/originalCaseReviews/17"
  },
  {
    "id": "GE-08-E02",
    "report": {
      "path": "docs/audit/2026-10-08/full-game/FEAT335_EXPLORATION_ORIGINAL_CASEBOOK_REVIEW_93.json",
      "bytes": 483808,
      "sha256": "ac2f12df49630b64e6cef4ca5b163c669e911338259508223a7c5eca6933a92c"
    },
    "pointer": "/originalCaseReviews/18"
  }
]
```

## GE-09 — Charismatic

### Complete original object

```json
{
  "id": "charismatic",
  "name": "Charismatic",
  "description": "Your personality is magnetic.",
  "prerequisite": "Charisma 13+",
  "effect": "You gain proficiency in Persuasion and Deception. If already proficient, you add double your proficiency bonus.",
  "type": "General",
  "draft": false,
  "deprecated": false,
  "needsReview": false
}
```

### Original question

```json
"Preserve Persuasion and Deception proficiency with separately adjudicated existing-proficiency double PB. Define acquisition/later proficiency and nonstacking expertise, not automatic cooperation or lie immunity. Distinguish both skills from Intimidation, Performance and social combat effects."
```

### Preserved original source direction (historical)

```json
{
  "featId": "charismatic",
  "name": "Charismatic",
  "cohort": "general_exploration",
  "questionId": "GE-09",
  "disposition": "AUTHOR_FROM_SUBMITTED_PROCEDURE_WITH_FINAL_SHARED_RULES",
  "sourcePath": "DescentReviewChanges/ReviewBible/data/director/general_exploration_feat_operating_proposal_internal.json",
  "sourceFileSha256": "e13b824f4e6b5ecb39e409d32ecc2b2bdf6aeba9cdc229d4377c50530b067149",
  "sourcePointer": "/records/8",
  "originalQuestion": "Preserve Persuasion and Deception proficiency with separately adjudicated existing-proficiency double PB. Define acquisition/later proficiency and nonstacking expertise, not automatic cooperation or lie immunity. Distinguish both skills from Intimidation, Performance and social combat effects.",
  "originalSourceObject": {
    "id": "charismatic",
    "name": "Charismatic",
    "description": "Your personality is magnetic.",
    "prerequisite": "Charisma 13+",
    "effect": "You gain proficiency in Persuasion and Deception. If already proficient, you add double your proficiency bonus.",
    "type": "General",
    "draft": false,
    "deprecated": false,
    "needsReview": false
  },
  "originalSourceObjectSha256AsSubmitted": "a78329abb55bbef4a1278bdb2cb2a103986addf21fdcfa955cbe12d3fd97b35c",
  "submittedProcedure": "Evaluate Persuasion and Deception separately at acquisition: gain proficiency if untrained, or twice-PB Expertise if already proficient. These grants do not extend to Performance, Intimidation, Reputation or Insight. Persuasion and Deception remain distinct tasks with actual possible stakes, evidence, audience understanding and failure. The feat does not force agreement, make a lie objectively true, change standing or defeat magical truth restrictions by itself.",
  "submittedNewChoices": "Apply the shared proposed acquisition snapshot independently to each listed skill; retain full source prerequisite/effect and no stacking of Expertise.",
  "submittedWorkedCases": [
    "A CHA 16, PB +2 holder already proficient in Persuasion but not Deception has +7 Persuasion and +5 Deception after acquiring this feat.",
    "The same holder's Performance proficiency and modifier remain exactly what their other real sources provide; Charismatic grants neither.",
    "Two actual feats each granting Persuasion Expertise still yield +7 in this example, not +11; the overlapping grant history remains recorded."
  ],
  "decision": "Adopt separate Persuasion/Deception training snapshots; no extras for unrelated social skills or standing.",
  "completeAuthoringProcedure": "Evaluate Persuasion and Deception separately at acquisition: gain proficiency if untrained, or twice-PB Expertise if already proficient. These grants do not extend to Performance, Intimidation, Reputation or Insight. Persuasion and Deception remain distinct tasks with actual possible stakes, evidence, audience understanding and failure. The feat does not force agreement, make a lie objectively true, change standing or defeat magical truth restrictions by itself.",
  "newRuleProvenance": "All submitted NEW/proposed completions retained by this decision and all departures below are authoring decisions of FEAT327-SOURCE-2026-10-11, not recovered source wording. The original object remains immutable.",
  "sharedContract": "FEAT_SHARED_DIRECTIONS.json: FS-01–16",
  "supplementContract": "FEAT_SUPPLEMENT_DIRECTIONS.json: explicit source path/pointer mappings",
  "workedCases": [
    "A CHA 16, PB +2 holder already proficient in Persuasion but not Deception has +7 Persuasion and +5 Deception after acquiring this feat.",
    "The same holder's Performance proficiency and modifier remain exactly what their other real sources provide; Charismatic grants neither.",
    "Two actual feats each granting Persuasion Expertise still yield +7 in this example, not +11; the overlapping grant history remains recorded."
  ],
  "payloadOperational": "full authored procedure; not a runtime adapter",
  "selectionEnabled": false,
  "exactApproved": false,
  "runtimeApproved": false
}
```

### Complete current candidate procedure

Evaluate Persuasion and Deception separately at acquisition: gain proficiency if untrained, or twice-PB Expertise if already proficient. These grants do not extend to Performance, Intimidation, Reputation or Insight. Persuasion and Deception remain distinct tasks with actual possible stakes, evidence, audience understanding and failure. The feat does not force agreement, make a lie objectively true, change standing or defeat magical truth restrictions by itself.

### Original-position authored review references

```json
[
  {
    "id": "GE-09-E01",
    "report": {
      "path": "docs/audit/2026-10-08/full-game/FEAT335_EXPLORATION_ORIGINAL_CASEBOOK_REVIEW_93.json",
      "bytes": 483808,
      "sha256": "ac2f12df49630b64e6cef4ca5b163c669e911338259508223a7c5eca6933a92c"
    },
    "pointer": "/originalCaseReviews/19"
  },
  {
    "id": "GE-09-E02",
    "report": {
      "path": "docs/audit/2026-10-08/full-game/FEAT335_EXPLORATION_ORIGINAL_CASEBOOK_REVIEW_93.json",
      "bytes": 483808,
      "sha256": "ac2f12df49630b64e6cef4ca5b163c669e911338259508223a7c5eca6933a92c"
    },
    "pointer": "/originalCaseReviews/20"
  },
  {
    "id": "GE-09-E03",
    "report": {
      "path": "docs/audit/2026-10-08/full-game/FEAT335_EXPLORATION_ORIGINAL_CASEBOOK_REVIEW_93.json",
      "bytes": 483808,
      "sha256": "ac2f12df49630b64e6cef4ca5b163c669e911338259508223a7c5eca6933a92c"
    },
    "pointer": "/originalCaseReviews/21"
  }
]
```

## GE-10 — Climber

### Complete original object

```json
{
  "id": "climber",
  "name": "Climber",
  "description": "You are an expert at scaling walls and cliffs.",
  "prerequisite": "Strength 13 or higher",
  "effect": "You gain a climbing speed equal to your walking speed and advantage on Athletics checks made to climb.",
  "type": "General",
  "draft": false,
  "deprecated": false,
  "needsReview": false
}
```

### Original question

```json
"Define climb Speed equal to current walking Speed, conditional snapshots, zero-speed restrictions and noncompounding movement arbitration. Retain Athletics advantage when an actual climb check is required. This does not inherently permit ceilings, no-hand climbing, automatic success or disregard surfaces/equipment."
```

### Preserved original source direction (historical)

```json
{
  "featId": "climber",
  "name": "Climber",
  "cohort": "general_exploration",
  "questionId": "GE-10",
  "disposition": "AUTHOR_FROM_SUBMITTED_PROCEDURE_WITH_FINAL_SHARED_RULES",
  "sourcePath": "DescentReviewChanges/ReviewBible/data/director/general_exploration_feat_operating_proposal_internal.json",
  "sourceFileSha256": "e13b824f4e6b5ecb39e409d32ecc2b2bdf6aeba9cdc229d4377c50530b067149",
  "sourcePointer": "/records/9",
  "originalQuestion": "Define climb Speed equal to current walking Speed, conditional snapshots, zero-speed restrictions and noncompounding movement arbitration. Retain Athletics advantage when an actual climb check is required. This does not inherently permit ceilings, no-hand climbing, automatic success or disregard surfaces/equipment.",
  "originalSourceObject": {
    "id": "climber",
    "name": "Climber",
    "description": "You are an expert at scaling walls and cliffs.",
    "prerequisite": "Strength 13 or higher",
    "effect": "You gain a climbing speed equal to your walking speed and advantage on Athletics checks made to climb.",
    "type": "General",
    "draft": false,
    "deprecated": false,
    "needsReview": false
  },
  "originalSourceObjectSha256AsSubmitted": "428eda65785e8ad3892fbc458bbd24a08b39f4a36aac97b1542ff375d3c49ab6",
  "submittedProcedure": "Gain a climbing Speed equal to your current legal walking Speed and advantage on actual Athletics checks made to climb. NEW: derive the speed from the current body and applicable speed penalties, not an unmodified ancestral baseline. Follow the shared spent-movement-cost ledger when switching modes, so movement already spent is never refunded. Climbing still needs support your actual hands, limbs, equipment and surface can provide; the feat does not add adhesion, free hands or a flying mode. A check occurs only when the route calls for one, and advantage does not eliminate its real failure consequence. Grip, slippery material, load, damage, support collapse, zero Speed and falls keep their ordinary rules. A second feature granting the same climb Speed does not add another walking Speed; use the actual applicable movement profile.",
  "submittedNewChoices": "Current-speed derivation, real support and nonadditive mode grant. No silent ceiling permission or immunity to falls.",
  "submittedWorkedCases": [
    "Walking Speed20 gives climbing Speed20. With10movement-cost feet already spent, the current20-foot budget leaves10, subject to terrain costs on the climb.",
    "Athletics advantage helps a real slick-wall climb, but a ceiling with no possible grip requires another supported method; owning Climber alone does not create one."
  ],
  "decision": "Keep derived current walk-to-climb Speed and Athletics advantage with support, single inherited penalties and spent movement.",
  "completeAuthoringProcedure": "Gain a climbing Speed equal to your current legal walking Speed and advantage on actual Athletics checks made to climb. NEW: derive the speed from the current body and applicable speed penalties, not an unmodified ancestral baseline. Follow the shared spent-movement-cost ledger when switching modes, so movement already spent is never refunded. Climbing still needs support your actual hands, limbs, equipment and surface can provide; the feat does not add adhesion, free hands or a flying mode. A check occurs only when the route calls for one, and advantage does not eliminate its real failure consequence. Grip, slippery material, load, damage, support collapse, zero Speed and falls keep their ordinary rules. A second feature granting the same climb Speed does not add another walking Speed; use the actual applicable movement profile.",
  "newRuleProvenance": "All submitted NEW/proposed completions retained by this decision and all departures below are authoring decisions of FEAT327-SOURCE-2026-10-11, not recovered source wording. The original object remains immutable.",
  "sharedContract": "FEAT_SHARED_DIRECTIONS.json: FS-01–16",
  "supplementContract": "FEAT_SUPPLEMENT_DIRECTIONS.json: explicit source path/pointer mappings",
  "workedCases": [
    "Walking Speed20 gives climbing Speed20. With10movement-cost feet already spent, the current20-foot budget leaves10, subject to terrain costs on the climb.",
    "Athletics advantage helps a real slick-wall climb, but a ceiling with no possible grip requires another supported method; owning Climber alone does not create one."
  ],
  "payloadOperational": "full authored procedure; not a runtime adapter",
  "selectionEnabled": false,
  "exactApproved": false,
  "runtimeApproved": false
}
```

### Complete current candidate procedure

Gain a climbing Speed equal to your current legal walking Speed and advantage on actual Athletics checks made to climb. NEW: derive the speed from the current body and applicable speed penalties, not an unmodified ancestral baseline. Follow the shared spent-movement-cost ledger when switching modes, so movement already spent is never refunded. Climbing still needs support your actual hands, limbs, equipment and surface can provide; the feat does not add adhesion, free hands or a flying mode. A check occurs only when the route calls for one, and advantage does not eliminate its real failure consequence. Grip, slippery material, load, damage, support collapse, zero Speed and falls keep their ordinary rules. A second feature granting the same climb Speed does not add another walking Speed; use the actual applicable movement profile.

### Original-position authored review references

```json
[
  {
    "id": "GE-10-E01",
    "report": {
      "path": "docs/audit/2026-10-08/full-game/FEAT335_EXPLORATION_ORIGINAL_CASEBOOK_REVIEW_93.json",
      "bytes": 483808,
      "sha256": "ac2f12df49630b64e6cef4ca5b163c669e911338259508223a7c5eca6933a92c"
    },
    "pointer": "/originalCaseReviews/22"
  },
  {
    "id": "GE-10-E02",
    "report": {
      "path": "docs/audit/2026-10-08/full-game/FEAT335_EXPLORATION_ORIGINAL_CASEBOOK_REVIEW_93.json",
      "bytes": 483808,
      "sha256": "ac2f12df49630b64e6cef4ca5b163c669e911338259508223a7c5eca6933a92c"
    },
    "pointer": "/originalCaseReviews/23"
  }
]
```

## GE-11 — Commanding Presence

### Complete original object

```json
{
  "id": "commanding_presence",
  "name": "Commanding Presence",
  "description": "You naturally command respect.",
  "prerequisite": "Charisma 15+",
  "effect": "You can use your Charisma modifier instead of Strength for Intimidation checks, and you have advantage on Persuasion checks against creatures of lower level.",
  "type": "General",
  "draft": false,
  "deprecated": false,
  "needsReview": false
}
```

### Original question

```json
"The source permits CHA instead of STR for Intimidation, while ordinary Intimidation is CHA-based; resolve whether this clause has any added scope without replacing Bruiser backward. Define lower-level target for creatures with CR but no character level, interaction timing and actual Persuasion checks; do not equate CR to level silently."
```

### Preserved original source direction (historical)

```json
{
  "featId": "commanding_presence",
  "name": "Commanding Presence",
  "cohort": "general_exploration",
  "questionId": "GE-11",
  "disposition": "AUTHOR_FROM_SUBMITTED_PROCEDURE_WITH_FINAL_SHARED_RULES",
  "sourcePath": "DescentReviewChanges/ReviewBible/data/director/general_exploration_feat_operating_proposal_internal.json",
  "sourceFileSha256": "e13b824f4e6b5ecb39e409d32ecc2b2bdf6aeba9cdc229d4377c50530b067149",
  "sourcePointer": "/records/10",
  "originalQuestion": "The source permits CHA instead of STR for Intimidation, while ordinary Intimidation is CHA-based; resolve whether this clause has any added scope without replacing Bruiser backward. Define lower-level target for creatures with CR but no character level, interaction timing and actual Persuasion checks; do not equate CR to level silently.",
  "originalSourceObject": {
    "id": "commanding_presence",
    "name": "Commanding Presence",
    "description": "You naturally command respect.",
    "prerequisite": "Charisma 15+",
    "effect": "You can use your Charisma modifier instead of Strength for Intimidation checks, and you have advantage on Persuasion checks against creatures of lower level.",
    "type": "General",
    "draft": false,
    "deprecated": false,
    "needsReview": false
  },
  "originalSourceObjectSha256AsSubmitted": "02486173da18732dd4322f944891ccf88485cf66e7ae8777e28250449333bb97",
  "submittedProcedure": "When an actual Intimidation task would use Strength, you may use Charisma instead; choose before rolling. Ordinary Charisma (Intimidation) already uses Charisma, so this clause gives no second modifier or bonus there. It does not grant proficiency. On actual Persuasion checks directed at a creature with an explicitly recorded character level lower than your total character level, gain advantage. NEW: compare true character levels, not CR, Hit Dice, faction standing, rank or apparent seniority. A creature with only CR and no character level is not qualified through a fabricated conversion; its Director can supply an actual level only if its real profile legitimately includes one. Check eligibility at the roll, without granting the speaker metagame disclosure of the hidden value. Equal or higher level gives no advantage from this clause. All actual social possibilities, agency and costs remain.",
  "submittedNewChoices": "Charisma substitution retained as written; exact level comparison and explicit no CR conversion. This limitation needs joint source agreement.",
  "submittedWorkedCases": [
    "A level8 speaker negotiating with an actual level5 NPC can gain advantage. An NPC listed only as CR5 is not silently treated as level5.",
    "CHA +3 is used once on ordinary Intimidation. The feat does not make the total CHA +3 plus STR +2 or grant an extra +3."
  ],
  "decision": "Keep literal reverse STR-to-CHA substitution and true recorded lower character-level comparison; no CR-to-level invention.",
  "completeAuthoringProcedure": "When an actual Intimidation task would use Strength, you may use Charisma instead; choose before rolling. Ordinary Charisma (Intimidation) already uses Charisma, so this clause gives no second modifier or bonus there. It does not grant proficiency. On actual Persuasion checks directed at a creature with an explicitly recorded character level lower than your total character level, gain advantage. NEW: compare true character levels, not CR, Hit Dice, faction standing, rank or apparent seniority. A creature with only CR and no character level is not qualified through a fabricated conversion; its Director can supply an actual level only if its real profile legitimately includes one. Check eligibility at the roll, without granting the speaker metagame disclosure of the hidden value. Equal or higher level gives no advantage from this clause. All actual social possibilities, agency and costs remain.",
  "newRuleProvenance": "All submitted NEW/proposed completions retained by this decision and all departures below are authoring decisions of FEAT327-SOURCE-2026-10-11, not recovered source wording. The original object remains immutable.",
  "sharedContract": "FEAT_SHARED_DIRECTIONS.json: FS-01–16",
  "supplementContract": "FEAT_SUPPLEMENT_DIRECTIONS.json: explicit source path/pointer mappings",
  "workedCases": [
    "A level8 speaker negotiating with an actual level5 NPC can gain advantage. An NPC listed only as CR5 is not silently treated as level5.",
    "CHA +3 is used once on ordinary Intimidation. The feat does not make the total CHA +3 plus STR +2 or grant an extra +3."
  ],
  "payloadOperational": "full authored procedure; not a runtime adapter",
  "selectionEnabled": false,
  "exactApproved": false,
  "runtimeApproved": false
}
```

### Complete current candidate procedure

When an actual Intimidation task would use Strength, you may use Charisma instead; choose before rolling. Ordinary Charisma (Intimidation) already uses Charisma, so this clause gives no second modifier or bonus there. It does not grant proficiency. On actual Persuasion checks directed at a creature with an explicitly recorded character level lower than your total character level, gain advantage. NEW: compare true character levels, not CR, Hit Dice, faction standing, rank or apparent seniority. A creature with only CR and no character level is not qualified through a fabricated conversion; its Director can supply an actual level only if its real profile legitimately includes one. Check eligibility at the roll, without granting the speaker metagame disclosure of the hidden value. Equal or higher level gives no advantage from this clause. All actual social possibilities, agency and costs remain.

### Original-position authored review references

```json
[
  {
    "id": "GE-11-E01",
    "report": {
      "path": "docs/audit/2026-10-08/full-game/FEAT335_EXPLORATION_ORIGINAL_CASEBOOK_REVIEW_93.json",
      "bytes": 483808,
      "sha256": "ac2f12df49630b64e6cef4ca5b163c669e911338259508223a7c5eca6933a92c"
    },
    "pointer": "/originalCaseReviews/24"
  },
  {
    "id": "GE-11-E02",
    "report": {
      "path": "docs/audit/2026-10-08/full-game/FEAT335_EXPLORATION_ORIGINAL_CASEBOOK_REVIEW_93.json",
      "bytes": 483808,
      "sha256": "ac2f12df49630b64e6cef4ca5b163c669e911338259508223a7c5eca6933a92c"
    },
    "pointer": "/originalCaseReviews/25"
  }
]
```

## GE-12 — Courtly Manners

### Complete original object

```json
{
  "id": "courtly_manners",
  "name": "Courtly Manners",
  "description": "You are well-versed in noble etiquette.",
  "prerequisite": "Charisma 13+",
  "effect": "You have advantage on Charisma checks when interacting with nobles and can gain audience with important figures more easily.",
  "type": "General",
  "draft": false,
  "deprecated": false,
  "needsReview": false
}
```

### Original question

```json
"Define which actual CHA checks concern noble etiquette, eligible recognized social role and genuine audience-access procedure. It gives neither rank, credential nor guaranteed entry or consent. Bound the unspecified easier audience benefit using existing standing/faction access, with private identity and cosmology untouched."
```

### Preserved original source direction (historical)

```json
{
  "featId": "courtly_manners",
  "name": "Courtly Manners",
  "cohort": "general_exploration",
  "questionId": "GE-12",
  "disposition": "AUTHOR_FROM_SUBMITTED_PROCEDURE_WITH_FINAL_SHARED_RULES",
  "sourcePath": "DescentReviewChanges/ReviewBible/data/director/general_exploration_feat_operating_proposal_internal.json",
  "sourceFileSha256": "e13b824f4e6b5ecb39e409d32ecc2b2bdf6aeba9cdc229d4377c50530b067149",
  "sourcePointer": "/records/11",
  "originalQuestion": "Define which actual CHA checks concern noble etiquette, eligible recognized social role and genuine audience-access procedure. It gives neither rank, credential nor guaranteed entry or consent. Bound the unspecified easier audience benefit using existing standing/faction access, with private identity and cosmology untouched.",
  "originalSourceObject": {
    "id": "courtly_manners",
    "name": "Courtly Manners",
    "description": "You are well-versed in noble etiquette.",
    "prerequisite": "Charisma 13+",
    "effect": "You have advantage on Charisma checks when interacting with nobles and can gain audience with important figures more easily.",
    "type": "General",
    "draft": false,
    "deprecated": false,
    "needsReview": false
  },
  "originalSourceObjectSha256AsSubmitted": "5f461a58b3624d62b92cafe741013c2060eb0b2dfca804295120c358a9280ee3",
  "submittedProcedure": "Gain advantage on actual Charisma ability checks when directly interacting with someone who genuinely holds a noble social position recognized by the current community. Preserve the source's breadth: it is not restricted to etiquette checks or friendly nobles. A Charisma attack or saving throw is not an ability check. NEW audience procedure: spend fifteen active minutes preparing and submitting one credible request through an actually accessible official, host or gatekeeper. Gain advantage on a Persuasion check to arrange an audience with an important figure even when that intermediary is not noble. The audience must be possible under the figure's actual schedule, policy and willingness; announce the attainable appointment and any fee, introduction or condition before rolling. Success secures that opportunity on those terms, not immediate entry, a title, waived security or agreement to the later request. A repeated identical petition to the same gatekeeper yields no new roll without a changed circumstance. Required identity, dress and communication remain actual resources.",
  "submittedNewChoices": "Recognized noble identity; concrete audience petition time and advantage extension to the gatekeeper. Original all-Charisma-check benefit preserved.",
  "submittedWorkedCases": [
    "A noble's hostile interrogation can still qualify for the feat's advantage on an actual Charisma check made in that interaction; nobility does not guarantee a friendly response.",
    "A successful gatekeeper petition secures the announced appointment tomorrow with its stated fee. It does not place the character in a closed chamber immediately."
  ],
  "decision": "Adopt broad actual noble-interaction Charisma-check advantage and finite fifteen-minute audience-petition exception with achievable announced terms.",
  "completeAuthoringProcedure": "Gain advantage on actual Charisma ability checks when directly interacting with someone who genuinely holds a noble social position recognized by the current community. Preserve the source's breadth: it is not restricted to etiquette checks or friendly nobles. A Charisma attack or saving throw is not an ability check. NEW audience procedure: spend fifteen active minutes preparing and submitting one credible request through an actually accessible official, host or gatekeeper. Gain advantage on a Persuasion check to arrange an audience with an important figure even when that intermediary is not noble. The audience must be possible under the figure's actual schedule, policy and willingness; announce the attainable appointment and any fee, introduction or condition before rolling. Success secures that opportunity on those terms, not immediate entry, a title, waived security or agreement to the later request. A repeated identical petition to the same gatekeeper yields no new roll without a changed circumstance. Required identity, dress and communication remain actual resources.",
  "newRuleProvenance": "All submitted NEW/proposed completions retained by this decision and all departures below are authoring decisions of FEAT327-SOURCE-2026-10-11, not recovered source wording. The original object remains immutable.",
  "sharedContract": "FEAT_SHARED_DIRECTIONS.json: FS-01–16",
  "supplementContract": "FEAT_SUPPLEMENT_DIRECTIONS.json: explicit source path/pointer mappings",
  "workedCases": [
    "A noble's hostile interrogation can still qualify for the feat's advantage on an actual Charisma check made in that interaction; nobility does not guarantee a friendly response.",
    "A successful gatekeeper petition secures the announced appointment tomorrow with its stated fee. It does not place the character in a closed chamber immediately."
  ],
  "payloadOperational": "full authored procedure; not a runtime adapter",
  "selectionEnabled": false,
  "exactApproved": false,
  "runtimeApproved": false
}
```

### Complete current candidate procedure

Gain advantage on actual Charisma ability checks when directly interacting with someone who genuinely holds a noble social position recognized by the current community. Preserve the source's breadth: it is not restricted to etiquette checks or friendly nobles. A Charisma attack or saving throw is not an ability check. NEW audience procedure: spend fifteen active minutes preparing and submitting one credible request through an actually accessible official, host or gatekeeper. Gain advantage on a Persuasion check to arrange an audience with an important figure even when that intermediary is not noble. The audience must be possible under the figure's actual schedule, policy and willingness; announce the attainable appointment and any fee, introduction or condition before rolling. Success secures that opportunity on those terms, not immediate entry, a title, waived security or agreement to the later request. A repeated identical petition to the same gatekeeper yields no new roll without a changed circumstance. Required identity, dress and communication remain actual resources.

### Original-position authored review references

```json
[
  {
    "id": "GE-12-E01",
    "report": {
      "path": "docs/audit/2026-10-08/full-game/FEAT335_EXPLORATION_ORIGINAL_CASEBOOK_REVIEW_93.json",
      "bytes": 483808,
      "sha256": "ac2f12df49630b64e6cef4ca5b163c669e911338259508223a7c5eca6933a92c"
    },
    "pointer": "/originalCaseReviews/26"
  },
  {
    "id": "GE-12-E02",
    "report": {
      "path": "docs/audit/2026-10-08/full-game/FEAT335_EXPLORATION_ORIGINAL_CASEBOOK_REVIEW_93.json",
      "bytes": 483808,
      "sha256": "ac2f12df49630b64e6cef4ca5b163c669e911338259508223a7c5eca6933a92c"
    },
    "pointer": "/originalCaseReviews/27"
  }
]
```

## GE-13 — Deceiver

### Complete original object

```json
{
  "id": "deceiver",
  "name": "Deceiver",
  "description": "You are a master of deception.",
  "prerequisite": "Charisma 13+",
  "effect": "You gain proficiency in Deception and can lie convincingly even under magical compulsion.",
  "type": "General",
  "draft": false,
  "deprecated": false,
  "needsReview": false
}
```

### Original question

```json
"Preserve Deception proficiency and lying under magical compulsion. Identify exact effects that prohibit lies versus compel actions or reveal thoughts, declare any exception precisely, and retain saving throws/conditions. No automatic lie success, blanket magic immunity or retrospective erasure of witnessed facts."
```

### Preserved original source direction (historical)

```json
{
  "featId": "deceiver",
  "name": "Deceiver",
  "cohort": "general_exploration",
  "questionId": "GE-13",
  "disposition": "AUTHOR_FROM_SUBMITTED_PROCEDURE_WITH_FINAL_SHARED_RULES",
  "sourcePath": "DescentReviewChanges/ReviewBible/data/director/general_exploration_feat_operating_proposal_internal.json",
  "sourceFileSha256": "e13b824f4e6b5ecb39e409d32ecc2b2bdf6aeba9cdc229d4377c50530b067149",
  "sourcePointer": "/records/12",
  "originalQuestion": "Preserve Deception proficiency and lying under magical compulsion. Identify exact effects that prohibit lies versus compel actions or reveal thoughts, declare any exception precisely, and retain saving throws/conditions. No automatic lie success, blanket magic immunity or retrospective erasure of witnessed facts.",
  "originalSourceObject": {
    "id": "deceiver",
    "name": "Deceiver",
    "description": "You are a master of deception.",
    "prerequisite": "Charisma 13+",
    "effect": "You gain proficiency in Deception and can lie convincingly even under magical compulsion.",
    "type": "General",
    "draft": false,
    "deprecated": false,
    "needsReview": false
  },
  "originalSourceObjectSha256AsSubmitted": "c6b6387f5cde4c0566be1184dc0d3c6c1acebb389e48838ed73117bdc00289d5",
  "submittedProcedure": "Gain Deception proficiency. NEW explicit source exception: you can deliberately speak a false assertion even while a magical effect would otherwise prohibit that assertion solely because it is a lie or require that assertion to be truthful. This is a narrow exception to truth-compulsion, including the lie-prohibition part of Zone of Truth, and must be approved against those exact spell records. You still make any actual save and remain subject to the effect's other clauses. It grants no automatic convincing success: resolve a real Deception check, opposed defense or other social procedure where required. It does not falsify memories, thoughts, directly revealed facts or independently recorded events; confer no blanket immunity to charm, compelled actions or orders; and does not let you avoid an order to speak or move when that obligation is separate from truthfulness. If another effect punishes actual lies, this feat permits the lie but does not negate its punishment. The caster receives only the information their source actually grants; the feat adds neither an automatic warning nor an undetectability guarantee.",
  "submittedNewChoices": "Precise truth-compulsion exception and preservation of all independent magical effects; fixed duplicate proficiency. Consequential Zone of Truth comparison required.",
  "submittedWorkedCases": [
    "After failing a Zone of Truth save, the holder can attempt a deliberate verbal lie under this proposed exception. A suspicious listener may still defeat the Deception check.",
    "A spell that directly reveals an actual memory is not changed by the holder speaking falsely. A separate penalty triggered by telling a lie still resolves."
  ],
  "decision": "Adopt explicit truth-compulsion exception, including reviewed Zone of Truth lie restriction only; no save cancellation, automatic credibility or immunity to punishment/memory disclosure.",
  "completeAuthoringProcedure": "Gain Deception proficiency. NEW explicit source exception: you can deliberately speak a false assertion even while a magical effect would otherwise prohibit that assertion solely because it is a lie or require that assertion to be truthful. This is a narrow exception to truth-compulsion, including the lie-prohibition part of Zone of Truth, and must be approved against those exact spell records. You still make any actual save and remain subject to the effect's other clauses. It grants no automatic convincing success: resolve a real Deception check, opposed defense or other social procedure where required. It does not falsify memories, thoughts, directly revealed facts or independently recorded events; confer no blanket immunity to charm, compelled actions or orders; and does not let you avoid an order to speak or move when that obligation is separate from truthfulness. If another effect punishes actual lies, this feat permits the lie but does not negate its punishment. The caster receives only the information their source actually grants; the feat adds neither an automatic warning nor an undetectability guarantee.",
  "newRuleProvenance": "All submitted NEW/proposed completions retained by this decision and all departures below are authoring decisions of FEAT327-SOURCE-2026-10-11, not recovered source wording. The original object remains immutable.",
  "sharedContract": "FEAT_SHARED_DIRECTIONS.json: FS-01–16",
  "supplementContract": "FEAT_SUPPLEMENT_DIRECTIONS.json: explicit source path/pointer mappings",
  "workedCases": [
    "After failing a Zone of Truth save, the holder can attempt a deliberate verbal lie under this proposed exception. A suspicious listener may still defeat the Deception check.",
    "A spell that directly reveals an actual memory is not changed by the holder speaking falsely. A separate penalty triggered by telling a lie still resolves."
  ],
  "payloadOperational": "full authored procedure; not a runtime adapter",
  "selectionEnabled": false,
  "exactApproved": false,
  "runtimeApproved": false
}
```

### Complete current candidate procedure

Gain Deception proficiency. NEW explicit source exception: you can deliberately speak a false assertion even while a magical effect would otherwise prohibit that assertion solely because it is a lie or require that assertion to be truthful. This is a narrow exception to truth-compulsion, including the lie-prohibition part of Zone of Truth, and must be approved against those exact spell records. You still make any actual save and remain subject to the effect's other clauses. It grants no automatic convincing success: resolve a real Deception check, opposed defense or other social procedure where required. It does not falsify memories, thoughts, directly revealed facts or independently recorded events; confer no blanket immunity to charm, compelled actions or orders; and does not let you avoid an order to speak or move when that obligation is separate from truthfulness. If another effect punishes actual lies, this feat permits the lie but does not negate its punishment. The caster receives only the information their source actually grants; the feat adds neither an automatic warning nor an undetectability guarantee.

### Original-position authored review references

```json
[
  {
    "id": "GE-13-E01",
    "report": {
      "path": "docs/audit/2026-10-08/full-game/FEAT335_EXPLORATION_ORIGINAL_CASEBOOK_REVIEW_93.json",
      "bytes": 483808,
      "sha256": "ac2f12df49630b64e6cef4ca5b163c669e911338259508223a7c5eca6933a92c"
    },
    "pointer": "/originalCaseReviews/28"
  },
  {
    "id": "GE-13-E02",
    "report": {
      "path": "docs/audit/2026-10-08/full-game/FEAT335_EXPLORATION_ORIGINAL_CASEBOOK_REVIEW_93.json",
      "bytes": 483808,
      "sha256": "ac2f12df49630b64e6cef4ca5b163c669e911338259508223a7c5eca6933a92c"
    },
    "pointer": "/originalCaseReviews/29"
  }
]
```

## GE-14 — Diplomat

### Complete original object

```json
{
  "id": "diplomat",
  "name": "Diplomat",
  "description": "You are skilled in negotiation and persuasion.",
  "prerequisite": "Charisma 13 or higher",
  "effect": "You gain proficiency in Persuasion and Insight. If already proficient, you add double your proficiency bonus.",
  "type": "General",
  "draft": false,
  "deprecated": false,
  "needsReview": false
}
```

### Original question

```json
"Preserve Persuasion and Insight proficiency and apply any existing-proficiency double PB independently. Define timing and overlap with Charismatic/other expertise. Insight is not automatic mind reading, and Persuasion is not compelled consent; actual social procedure and possible failure remain."
```

### Preserved original source direction (historical)

```json
{
  "featId": "diplomat",
  "name": "Diplomat",
  "cohort": "general_exploration",
  "questionId": "GE-14",
  "disposition": "AUTHOR_FROM_SUBMITTED_PROCEDURE_WITH_FINAL_SHARED_RULES",
  "sourcePath": "DescentReviewChanges/ReviewBible/data/director/general_exploration_feat_operating_proposal_internal.json",
  "sourceFileSha256": "e13b824f4e6b5ecb39e409d32ecc2b2bdf6aeba9cdc229d4377c50530b067149",
  "sourcePointer": "/records/13",
  "originalQuestion": "Preserve Persuasion and Insight proficiency and apply any existing-proficiency double PB independently. Define timing and overlap with Charismatic/other expertise. Insight is not automatic mind reading, and Persuasion is not compelled consent; actual social procedure and possible failure remain.",
  "originalSourceObject": {
    "id": "diplomat",
    "name": "Diplomat",
    "description": "You are skilled in negotiation and persuasion.",
    "prerequisite": "Charisma 13 or higher",
    "effect": "You gain proficiency in Persuasion and Insight. If already proficient, you add double your proficiency bonus.",
    "type": "General",
    "draft": false,
    "deprecated": false,
    "needsReview": false
  },
  "originalSourceObjectSha256AsSubmitted": "a0fa7704eb968f61e7976497438406a22f3a6707c10ee6a134f27cff60574f61",
  "submittedProcedure": "Evaluate Persuasion and Insight separately at acquisition: gain proficiency if untrained, or twice-PB Expertise if already proficient. Use the actual ability for each task, normally Charisma for Persuasion and Wisdom for Insight. Diplomacy still requires an eligible request and a perceivable, understandable interaction. Insight can reveal only what the actual successful task supports; it is neither automatic mind reading nor a guarantee that a suspected statement is false. This feat grants no extra audience, faction rank or negotiated discount.",
  "submittedNewChoices": "Apply the shared proposed acquisition snapshot independently to each listed skill; retain full source prerequisite/effect and no stacking of Expertise.",
  "submittedWorkedCases": [
    "CHA 14, WIS 16 and PB +3 with existing Insight but no Persuasion produces +5 Persuasion and +9 Insight after acquisition.",
    "A legal choice order acquiring Charismatic first can leave Persuasion proficient before a later Diplomat acquisition, so Diplomat grants Expertise there. Record both events; this is sequential ownership, not free retroactive rewriting.",
    "An opposed Insight total of 16 against Deception 16 keeps the existing state under current Core ties; Expertise does not create an automatic win."
  ],
  "decision": "Adopt per-skill training snapshots and real order of legal acquisition; existing ties and agency unchanged.",
  "completeAuthoringProcedure": "Evaluate Persuasion and Insight separately at acquisition: gain proficiency if untrained, or twice-PB Expertise if already proficient. Use the actual ability for each task, normally Charisma for Persuasion and Wisdom for Insight. Diplomacy still requires an eligible request and a perceivable, understandable interaction. Insight can reveal only what the actual successful task supports; it is neither automatic mind reading nor a guarantee that a suspected statement is false. This feat grants no extra audience, faction rank or negotiated discount.",
  "newRuleProvenance": "All submitted NEW/proposed completions retained by this decision and all departures below are authoring decisions of FEAT327-SOURCE-2026-10-11, not recovered source wording. The original object remains immutable.",
  "sharedContract": "FEAT_SHARED_DIRECTIONS.json: FS-01–16",
  "supplementContract": "FEAT_SUPPLEMENT_DIRECTIONS.json: explicit source path/pointer mappings",
  "workedCases": [
    "CHA 14, WIS 16 and PB +3 with existing Insight but no Persuasion produces +5 Persuasion and +9 Insight after acquisition.",
    "A legal choice order acquiring Charismatic first can leave Persuasion proficient before a later Diplomat acquisition, so Diplomat grants Expertise there. Record both events; this is sequential ownership, not free retroactive rewriting.",
    "An opposed Insight total of 16 against Deception 16 keeps the existing state under current Core ties; Expertise does not create an automatic win."
  ],
  "payloadOperational": "full authored procedure; not a runtime adapter",
  "selectionEnabled": false,
  "exactApproved": false,
  "runtimeApproved": false
}
```

### Complete current candidate procedure

Evaluate Persuasion and Insight separately at acquisition: gain proficiency if untrained, or twice-PB Expertise if already proficient. Use the actual ability for each task, normally Charisma for Persuasion and Wisdom for Insight. Diplomacy still requires an eligible request and a perceivable, understandable interaction. Insight can reveal only what the actual successful task supports; it is neither automatic mind reading nor a guarantee that a suspected statement is false. This feat grants no extra audience, faction rank or negotiated discount.

### Original-position authored review references

```json
[
  {
    "id": "GE-14-E01",
    "report": {
      "path": "docs/audit/2026-10-08/full-game/FEAT335_EXPLORATION_ORIGINAL_CASEBOOK_REVIEW_93.json",
      "bytes": 483808,
      "sha256": "ac2f12df49630b64e6cef4ca5b163c669e911338259508223a7c5eca6933a92c"
    },
    "pointer": "/originalCaseReviews/30"
  },
  {
    "id": "GE-14-E02",
    "report": {
      "path": "docs/audit/2026-10-08/full-game/FEAT335_EXPLORATION_ORIGINAL_CASEBOOK_REVIEW_93.json",
      "bytes": 483808,
      "sha256": "ac2f12df49630b64e6cef4ca5b163c669e911338259508223a7c5eca6933a92c"
    },
    "pointer": "/originalCaseReviews/31"
  },
  {
    "id": "GE-14-E03",
    "report": {
      "path": "docs/audit/2026-10-08/full-game/FEAT335_EXPLORATION_ORIGINAL_CASEBOOK_REVIEW_93.json",
      "bytes": 483808,
      "sha256": "ac2f12df49630b64e6cef4ca5b163c669e911338259508223a7c5eca6933a92c"
    },
    "pointer": "/originalCaseReviews/32"
  }
]
```

## GE-15 — Dungeon Delver

### Complete original object

```json
{
  "id": "dungeonDelver",
  "name": "Dungeon Delver",
  "description": "You are experienced in underground exploration.",
  "prerequisite": "Wisdom 13 or higher",
  "effect": "You have advantage on Perception and Investigation checks to detect secret doors and traps.",
  "type": "General",
  "draft": false,
  "deprecated": false,
  "needsReview": false
}
```

### Original question

```json
"Define Perception versus Investigation for actual secret-door/trap detection, active/passive use, senses, range, time and accessible evidence. Advantage does not reveal impossible-to-detect mechanisms or grant disarming, save resistance, trap immunity or magical detection. Compare Trap Sense and Forensic Investigator."
```

### Preserved original source direction (historical)

```json
{
  "featId": "dungeonDelver",
  "name": "Dungeon Delver",
  "cohort": "general_exploration",
  "questionId": "GE-15",
  "disposition": "AUTHOR_FROM_SUBMITTED_PROCEDURE_WITH_FINAL_SHARED_RULES",
  "sourcePath": "DescentReviewChanges/ReviewBible/data/director/general_exploration_feat_operating_proposal_internal.json",
  "sourceFileSha256": "e13b824f4e6b5ecb39e409d32ecc2b2bdf6aeba9cdc229d4377c50530b067149",
  "sourcePointer": "/records/14",
  "originalQuestion": "Define Perception versus Investigation for actual secret-door/trap detection, active/passive use, senses, range, time and accessible evidence. Advantage does not reveal impossible-to-detect mechanisms or grant disarming, save resistance, trap immunity or magical detection. Compare Trap Sense and Forensic Investigator.",
  "originalSourceObject": {
    "id": "dungeonDelver",
    "name": "Dungeon Delver",
    "description": "You are experienced in underground exploration.",
    "prerequisite": "Wisdom 13 or higher",
    "effect": "You have advantage on Perception and Investigation checks to detect secret doors and traps.",
    "type": "General",
    "draft": false,
    "deprecated": false,
    "needsReview": false
  },
  "originalSourceObjectSha256AsSubmitted": "b973d1d0721e11ea25c93c4a8894a9fd245a1fb4651441de821e37a1799d460b",
  "submittedProcedure": "Gain advantage on actual Perception or Investigation checks whose purpose is detecting a secret door or a trap. Use Perception to notice accessible sensory clues and Investigation to examine and interpret the actual mechanism or evidence, as the task warrants; do not add both skill proficiencies or roll both automatically. NEW: the feat's advantage changes active rolls only. It does not add a passive+5 or create a passive Investigation procedure by itself. Actual light, senses, range, access and search time remain; a completely inaccessible or undetectable feature is not revealed by an uncalled-for roll. Success reveals the detection information defined by that task, not automatic disarming, a save bonus, damage resistance, magical identification or immunity to a trigger encountered while searching. Trap Sense and Observant are separate feats with their own actual passive grants.",
  "submittedNewChoices": "Active-roll scope and no generic passive conversion; bounded Perception/Investigation task selection.",
  "submittedWorkedCases": [
    "An actual Investigation search of a suspicious hinge gains advantage. The same check does not disarm a linked trap unless a separate procedure actually does that.",
    "A passive Perception of15 remains15 from this feat alone; there is no invented+5 for advantage. Separately owned Observant would have its own modifier."
  ],
  "decision": "Keep active Perception/Investigation detection advantage, no passive+5 or disarming permission.",
  "completeAuthoringProcedure": "Gain advantage on actual Perception or Investigation checks whose purpose is detecting a secret door or a trap. Use Perception to notice accessible sensory clues and Investigation to examine and interpret the actual mechanism or evidence, as the task warrants; do not add both skill proficiencies or roll both automatically. NEW: the feat's advantage changes active rolls only. It does not add a passive+5 or create a passive Investigation procedure by itself. Actual light, senses, range, access and search time remain; a completely inaccessible or undetectable feature is not revealed by an uncalled-for roll. Success reveals the detection information defined by that task, not automatic disarming, a save bonus, damage resistance, magical identification or immunity to a trigger encountered while searching. Trap Sense and Observant are separate feats with their own actual passive grants.",
  "newRuleProvenance": "All submitted NEW/proposed completions retained by this decision and all departures below are authoring decisions of FEAT327-SOURCE-2026-10-11, not recovered source wording. The original object remains immutable.",
  "sharedContract": "FEAT_SHARED_DIRECTIONS.json: FS-01–16",
  "supplementContract": "FEAT_SUPPLEMENT_DIRECTIONS.json: explicit source path/pointer mappings",
  "workedCases": [
    "An actual Investigation search of a suspicious hinge gains advantage. The same check does not disarm a linked trap unless a separate procedure actually does that.",
    "A passive Perception of15 remains15 from this feat alone; there is no invented+5 for advantage. Separately owned Observant would have its own modifier."
  ],
  "payloadOperational": "full authored procedure; not a runtime adapter",
  "selectionEnabled": false,
  "exactApproved": false,
  "runtimeApproved": false
}
```

### Complete current candidate procedure

Gain advantage on actual Perception or Investigation checks whose purpose is detecting a secret door or a trap. Use Perception to notice accessible sensory clues and Investigation to examine and interpret the actual mechanism or evidence, as the task warrants; do not add both skill proficiencies or roll both automatically. NEW: the feat's advantage changes active rolls only. It does not add a passive+5 or create a passive Investigation procedure by itself. Actual light, senses, range, access and search time remain; a completely inaccessible or undetectable feature is not revealed by an uncalled-for roll. Success reveals the detection information defined by that task, not automatic disarming, a save bonus, damage resistance, magical identification or immunity to a trigger encountered while searching. Trap Sense and Observant are separate feats with their own actual passive grants.

### Original-position authored review references

```json
[
  {
    "id": "GE-15-E01",
    "report": {
      "path": "docs/audit/2026-10-08/full-game/FEAT335_EXPLORATION_ORIGINAL_CASEBOOK_REVIEW_93.json",
      "bytes": 483808,
      "sha256": "ac2f12df49630b64e6cef4ca5b163c669e911338259508223a7c5eca6933a92c"
    },
    "pointer": "/originalCaseReviews/33"
  },
  {
    "id": "GE-15-E02",
    "report": {
      "path": "docs/audit/2026-10-08/full-game/FEAT335_EXPLORATION_ORIGINAL_CASEBOOK_REVIEW_93.json",
      "bytes": 483808,
      "sha256": "ac2f12df49630b64e6cef4ca5b163c669e911338259508223a7c5eca6933a92c"
    },
    "pointer": "/originalCaseReviews/34"
  }
]
```

## GE-16 — Entertainer

### Complete original object

```json
{
  "id": "entertainer",
  "name": "Entertainer",
  "description": "You can captivate audiences.",
  "prerequisite": "Charisma 13+",
  "effect": "You gain proficiency in Performance and can earn money and gather information through performances.",
  "type": "General",
  "draft": false,
  "deprecated": false,
  "needsReview": false
}
```

### Original question

```json
"Preserve Performance proficiency; complete a finite performance work/income and information-gathering procedure with time, audience, venue, lawful opportunity, costs and failure. No infinite repeated-roll cash or invented reliable rumors. Resolve competing downtime actions and the existing standing/economy rules."
```

### Preserved original source direction (historical)

```json
{
  "featId": "entertainer",
  "name": "Entertainer",
  "cohort": "general_exploration",
  "questionId": "GE-16",
  "disposition": "AUTHOR_FROM_SUBMITTED_PROCEDURE_WITH_FINAL_SHARED_RULES",
  "sourcePath": "DescentReviewChanges/ReviewBible/data/director/general_exploration_feat_operating_proposal_internal.json",
  "sourceFileSha256": "e13b824f4e6b5ecb39e409d32ecc2b2bdf6aeba9cdc229d4377c50530b067149",
  "sourcePointer": "/records/15",
  "originalQuestion": "Preserve Performance proficiency; complete a finite performance work/income and information-gathering procedure with time, audience, venue, lawful opportunity, costs and failure. No infinite repeated-roll cash or invented reliable rumors. Resolve competing downtime actions and the existing standing/economy rules.",
  "originalSourceObject": {
    "id": "entertainer",
    "name": "Entertainer",
    "description": "You can captivate audiences.",
    "prerequisite": "Charisma 13+",
    "effect": "You gain proficiency in Performance and can earn money and gather information through performances.",
    "type": "General",
    "draft": false,
    "deprecated": false,
    "needsReview": false
  },
  "originalSourceObjectSha256AsSubmitted": "9e705ee460092797575a6ca34b60e5ba49e625b1ffe3b91c90ff4d1d9932d6ad",
  "submittedProcedure": "Gain Performance proficiency. NEW finite work procedure: arrange a real two-hour performance booking with an accessible venue, an actual audience and a willing payer, using the necessary real instrument, props or voice. The default mundane fee for this proposed booking is2sp, quoted and agreed before work; an actual negotiated contract may specify another amount or a performance standard. Complete the two active hours to earn the contractual payment from that payer, minus any actual venue costs. If the contract makes pay contingent on a check, state that DC and failure payment before accepting. During one fifteen-minute audience interaction within that booking, make Charisma (Performance) DC12 to engage attendees; on success one willing attendee offers an actual relevant local event, contact or rumor from their knowledge. Label hearsay and uncertainty; no attendee with relevant information means no invented rumor. The booking can coexist with that expressly allowed conversation, not another work action or rest. Repeating for the same unchanged audience gives no new information roll; a new booking needs real demand and payment. Record spent time, patron and money so no repeated-roll income is created.",
  "submittedNewChoices": "Two-hour booking, default2sp fee, fifteen-minute integrated conversation and DC12 information opportunity; actual contract and finite audience requirements.",
  "submittedWorkedCases": [
    "One completed2sp booking with5cp venue costs nets15cp. It consumes two actual hours and the payer's actual2sp, not an unlimited roll reward.",
    "A successful performance for an audience that knows no relevant news creates no hidden fact. A later identical song to those same attendees does not reset their information."
  ],
  "decision": "Adopt NEW two-hour real booking, contractual2sp default and included fifteen-minute DC12 audience-information subtask; no invented patron, rumor or simultaneous rest.",
  "completeAuthoringProcedure": "Gain Performance proficiency. NEW finite work procedure: arrange a real two-hour performance booking with an accessible venue, an actual audience and a willing payer, using the necessary real instrument, props or voice. The default mundane fee for this proposed booking is2sp, quoted and agreed before work; an actual negotiated contract may specify another amount or a performance standard. Complete the two active hours to earn the contractual payment from that payer, minus any actual venue costs. If the contract makes pay contingent on a check, state that DC and failure payment before accepting. During one fifteen-minute audience interaction within that booking, make Charisma (Performance) DC12 to engage attendees; on success one willing attendee offers an actual relevant local event, contact or rumor from their knowledge. Label hearsay and uncertainty; no attendee with relevant information means no invented rumor. The booking can coexist with that expressly allowed conversation, not another work action or rest. Repeating for the same unchanged audience gives no new information roll; a new booking needs real demand and payment. Record spent time, patron and money so no repeated-roll income is created.",
  "newRuleProvenance": "All submitted NEW/proposed completions retained by this decision and all departures below are authoring decisions of FEAT327-SOURCE-2026-10-11, not recovered source wording. The original object remains immutable.",
  "sharedContract": "FEAT_SHARED_DIRECTIONS.json: FS-01–16",
  "supplementContract": "FEAT_SUPPLEMENT_DIRECTIONS.json: explicit source path/pointer mappings",
  "workedCases": [
    "One completed2sp booking with5cp venue costs nets15cp. It consumes two actual hours and the payer's actual2sp, not an unlimited roll reward.",
    "A successful performance for an audience that knows no relevant news creates no hidden fact. A later identical song to those same attendees does not reset their information."
  ],
  "payloadOperational": "full authored procedure; not a runtime adapter",
  "selectionEnabled": false,
  "exactApproved": false,
  "runtimeApproved": false
}
```

### Complete current candidate procedure

Gain Performance proficiency. NEW finite work procedure: arrange a real two-hour performance booking with an accessible venue, an actual audience and a willing payer, using the necessary real instrument, props or voice. The default mundane fee for this proposed booking is2sp, quoted and agreed before work; an actual negotiated contract may specify another amount or a performance standard. Complete the two active hours to earn the contractual payment from that payer, minus any actual venue costs. If the contract makes pay contingent on a check, state that DC and failure payment before accepting. During one fifteen-minute audience interaction within that booking, make Charisma (Performance) DC12 to engage attendees; on success one willing attendee offers an actual relevant local event, contact or rumor from their knowledge. Label hearsay and uncertainty; no attendee with relevant information means no invented rumor. The booking can coexist with that expressly allowed conversation, not another work action or rest. Repeating for the same unchanged audience gives no new information roll; a new booking needs real demand and payment. Record spent time, patron and money so no repeated-roll income is created.

### Original-position authored review references

```json
[
  {
    "id": "GE-16-E01",
    "report": {
      "path": "docs/audit/2026-10-08/full-game/FEAT335_EXPLORATION_ORIGINAL_CASEBOOK_REVIEW_93.json",
      "bytes": 483808,
      "sha256": "ac2f12df49630b64e6cef4ca5b163c669e911338259508223a7c5eca6933a92c"
    },
    "pointer": "/originalCaseReviews/35"
  },
  {
    "id": "GE-16-E02",
    "report": {
      "path": "docs/audit/2026-10-08/full-game/FEAT335_EXPLORATION_ORIGINAL_CASEBOOK_REVIEW_93.json",
      "bytes": 483808,
      "sha256": "ac2f12df49630b64e6cef4ca5b163c669e911338259508223a7c5eca6933a92c"
    },
    "pointer": "/originalCaseReviews/36"
  }
]
```

## GE-17 — Forager

### Complete original object

```json
{
  "id": "forager",
  "name": "Forager",
  "description": "You can find food and water in the wild.",
  "prerequisite": "Wisdom 13+",
  "effect": "You can find enough food and water for yourself and up to 6 other people each day in any terrain except deserts or arctic regions.",
  "type": "General",
  "draft": false,
  "deprecated": false,
  "needsReview": false
}
```

### Original question

```json
"Preserve self plus up to six others per day and desert/arctic exceptions. Define time, checks, actual availability, creature-size portions, edible food versus potable water, conservation/transport and group overlap. Do not conjure food in a stripped/sealed area or automatically grant abstract Supply unrelated to actual resources."
```

### Preserved original source direction (historical)

```json
{
  "featId": "forager",
  "name": "Forager",
  "cohort": "general_exploration",
  "questionId": "GE-17",
  "disposition": "AUTHOR_FROM_EXACT_REPLACEMENT_WITH_FINAL_SHARED_RULES",
  "sourcePath": "DescentReviewChanges/ReviewBible/data/director/general_exploration_feat_operating_proposal_internal.json",
  "sourceFileSha256": "e13b824f4e6b5ecb39e409d32ecc2b2bdf6aeba9cdc229d4377c50530b067149",
  "sourcePointer": "/records/16",
  "originalQuestion": "Preserve self plus up to six others per day and desert/arctic exceptions. Define time, checks, actual availability, creature-size portions, edible food versus potable water, conservation/transport and group overlap. Do not conjure food in a stripped/sealed area or automatically grant abstract Supply unrelated to actual resources.",
  "originalSourceObject": {
    "id": "forager",
    "name": "Forager",
    "description": "You can find food and water in the wild.",
    "prerequisite": "Wisdom 13+",
    "effect": "You can find enough food and water for yourself and up to 6 other people each day in any terrain except deserts or arctic regions.",
    "type": "General",
    "draft": false,
    "deprecated": false,
    "needsReview": false
  },
  "originalSourceObjectSha256AsSubmitted": "2495459a5d02759b8456bf565e2e5686923c8e9eb4b84873159117122bead761",
  "submittedProcedure": "NEW finite interpretation of the source guarantee: in an accessible non-desert, non-arctic area that actually contains enough recoverable edible food and potable water, spend one active eight-hour forage Watch to gather the normal daily food and water requirement for yourself and up to six other ordinary Small/Medium people. This feat guarantees that result from qualifying available resources without a separate yield roll; it does not guarantee access through a hazard, remove contamination or defeat a resource-specific harvesting gate. Identify a real foraging area and deplete its recorded stocks. The actual expedition procedure supplies food/water units, body-size requirements, carry weight and Supply conversion; this feat creates no extra abstract Supply. Larger or unusual consumers use their actual greater requirement from the same finite quantity, not seven unlimited creature-day portions. Record one feat forage output per holder per24 elapsed hours, shared across all locations, with the window beginning on completion; a second feat owner can work separately only against remaining real stock and their actual time. Deserts and arctic regions use ordinary foraging. A stripped, sealed or foodless place cannot satisfy the prerequisite, and no water appears because food exists. Preserve, transport and consume the actual output normally.",
  "submittedNewChoices": "Eight-hour guaranteed-yield procedure, qualified stock/access boundary, 24-hour output cadence and standard-person quantity. Literal seven-person promise preserved where its actual resources exist; other cases explicitly require conference.",
  "submittedWorkedCases": [
    "An adequately stocked temperate area can provide seven standard person-days of both food and water after the holder's real Watch. The carried water still needs sufficient containers and capacity.",
    "A previously depleted chamber cannot yield another seven person-days. Food present without a potable water source cannot silently fulfill the missing water half."
  ],
  "decision": "Keep the source guarantee only against real finite stock and author exact EX58 food/water ceilings, not abstract Supply or free transport.",
  "completeAuthoringProcedure": "NEW finite interpretation of the source guarantee: in an accessible non-desert, non-arctic area that actually contains enough recoverable edible food and potable water, spend one active eight-hour forage Watch to gather the normal daily food and water requirement for yourself and up to six other ordinary Small/Medium people. This feat guarantees that result from qualifying available resources without a separate yield roll; it does not guarantee access through a hazard, remove contamination or defeat a resource-specific harvesting gate. Identify a real foraging area and deplete its recorded stocks. The actual expedition procedure supplies food/water units, body-size requirements, carry weight and Supply conversion; this feat creates no extra abstract Supply. Larger or unusual consumers use their actual greater requirement from the same finite quantity, not seven unlimited creature-day portions. Record one feat forage output per holder per24 elapsed hours, shared across all locations, with the window beginning on completion; a second feat owner can work separately only against remaining real stock and their actual time. Deserts and arctic regions use ordinary foraging. A stripped, sealed or foodless place cannot satisfy the prerequisite, and no water appears because food exists. Preserve, transport and consume the actual output normally.\nNEW explicit quantity ceiling: the seven ordinary Small/Medium daily food-and-water portions are at most14lb edible food and56pints potable water in one completed480-active-minute Watch. Each pint of water is1lb for the existing cargo accounting. A Large consumer normally uses4lb/16pints from this same stock. These are food/water only, not seven complete Supply Units: no oil, sundries, storage or transport is awarded. If the full guarantee cannot be supported, before work declare an ordinary lawful forage attempt or a smaller supported quantity under this feat; its no-yield-roll benefit may recover only that predeclared real accessible amount. The one-completion/24-elapsed-hour and all actual acquisition/handling restrictions still apply.",
  "newRuleProvenance": "All submitted NEW/proposed completions retained by this decision and all departures below are authoring decisions of FEAT327-SOURCE-2026-10-11, not recovered source wording. The original object remains immutable.",
  "sharedContract": "FEAT_SHARED_DIRECTIONS.json: FS-01–16",
  "supplementContract": "FEAT_SUPPLEMENT_DIRECTIONS.json: explicit source path/pointer mappings",
  "workedCases": [
    "One lawful Watch recovers14lb food and56pints water for seven standard people from actual stock. Water adds56lb; the output is70lb before containers, and includes no oil or sundries.",
    "A source has only4lb food and8pints safe accessible water. A predeclared smaller feat attempt cannot recover more than those amounts; a second worker or new container cannot recreate the depleted stock."
  ],
  "payloadOperational": "full authored procedure; not a runtime adapter",
  "selectionEnabled": false,
  "exactApproved": false,
  "runtimeApproved": false
}
```

### Complete current candidate procedure

NEW finite interpretation of the source guarantee: in an accessible non-desert, non-arctic area that actually contains enough recoverable edible food and potable water, spend one active eight-hour forage Watch to gather the normal daily food and water requirement for yourself and up to six other ordinary Small/Medium people. This feat guarantees that result from qualifying available resources without a separate yield roll; it does not guarantee access through a hazard, remove contamination or defeat a resource-specific harvesting gate. Identify a real foraging area and deplete its recorded stocks. The actual expedition procedure supplies food/water units, body-size requirements, carry weight and Supply conversion; this feat creates no extra abstract Supply. Larger or unusual consumers use their actual greater requirement from the same finite quantity, not seven unlimited creature-day portions. Record one feat forage output per holder per24 elapsed hours, shared across all locations, with the window beginning on completion; a second feat owner can work separately only against remaining real stock and their actual time. Deserts and arctic regions use ordinary foraging. A stripped, sealed or foodless place cannot satisfy the prerequisite, and no water appears because food exists. Preserve, transport and consume the actual output normally.
NEW explicit quantity ceiling: the seven ordinary Small/Medium daily food-and-water portions are at most14lb edible food and56pints potable water in one completed480-active-minute Watch. Each pint of water is1lb for the existing cargo accounting. A Large consumer normally uses4lb/16pints from this same stock. These are food/water only, not seven complete Supply Units: no oil, sundries, storage or transport is awarded. If the full guarantee cannot be supported, before work declare an ordinary lawful forage attempt or a smaller supported quantity under this feat; its no-yield-roll benefit may recover only that predeclared real accessible amount. The one-completion/24-elapsed-hour and all actual acquisition/handling restrictions still apply.

### Original-position authored review references

```json
[
  {
    "id": "GE-17-E01",
    "report": {
      "path": "docs/audit/2026-10-08/full-game/FEAT335_EXPLORATION_ORIGINAL_CASEBOOK_REVIEW_93.json",
      "bytes": 483808,
      "sha256": "ac2f12df49630b64e6cef4ca5b163c669e911338259508223a7c5eca6933a92c"
    },
    "pointer": "/originalCaseReviews/37"
  },
  {
    "id": "GE-17-E02",
    "report": {
      "path": "docs/audit/2026-10-08/full-game/FEAT335_EXPLORATION_ORIGINAL_CASEBOOK_REVIEW_93.json",
      "bytes": 483808,
      "sha256": "ac2f12df49630b64e6cef4ca5b163c669e911338259508223a7c5eca6933a92c"
    },
    "pointer": "/originalCaseReviews/38"
  },
  {
    "id": "FA-03",
    "report": {
      "path": "docs/audit/2026-10-08/full-game/FEAT335_EXPLORATION_ORIGINAL_CASEBOOK_REVIEW_93.json",
      "bytes": 483808,
      "sha256": "ac2f12df49630b64e6cef4ca5b163c669e911338259508223a7c5eca6933a92c"
    },
    "pointer": "/additionalBoundaryReviews/0"
  }
]
```

## GE-18 — Gossip

### Complete original object

```json
{
  "id": "gossip",
  "name": "Gossip",
  "description": "You excel at gathering information.",
  "prerequisite": "Charisma 13+",
  "effect": "You can gather information about local events, people, and rumors twice as fast as normal.",
  "type": "General",
  "draft": false,
  "deprecated": false,
  "needsReview": false
}
```

### Original question

```json
"Define the actual baseline time for obtaining local information and how half-time rounds, including audience/contact costs and simultaneous work. Faster gathering does not change truth, completeness, secrecy, coercion or willingness. Compare rumors/research and avoid repeated unchanged-evidence rerolls."
```

### Preserved original source direction (historical)

```json
{
  "featId": "gossip",
  "name": "Gossip",
  "cohort": "general_exploration",
  "questionId": "GE-18",
  "disposition": "AUTHOR_FROM_SUBMITTED_PROCEDURE_WITH_FINAL_SHARED_RULES",
  "sourcePath": "DescentReviewChanges/ReviewBible/data/director/general_exploration_feat_operating_proposal_internal.json",
  "sourceFileSha256": "e13b824f4e6b5ecb39e409d32ecc2b2bdf6aeba9cdc229d4377c50530b067149",
  "sourcePointer": "/records/17",
  "originalQuestion": "Define the actual baseline time for obtaining local information and how half-time rounds, including audience/contact costs and simultaneous work. Faster gathering does not change truth, completeness, secrecy, coercion or willingness. Compare rumors/research and avoid repeated unchanged-evidence rerolls.",
  "originalSourceObject": {
    "id": "gossip",
    "name": "Gossip",
    "description": "You excel at gathering information.",
    "prerequisite": "Charisma 13+",
    "effect": "You can gather information about local events, people, and rumors twice as fast as normal.",
    "type": "General",
    "draft": false,
    "deprecated": false,
    "needsReview": false
  },
  "originalSourceObjectSha256AsSubmitted": "7785ba139c89da2237a0bb8fd79d15c84b59b55999b9fe8e4e718072bcdcb5fd",
  "submittedProcedure": "Identify an actual local information-gathering task, its contacts, topic, permitted method, normal active time and real costs before work. Spend half that actor's normal active time, rounded upward once to a whole minute. NEW: absent a more specific procedure, an ordinary round of local inquiries through accessible willing contacts takes two active hours, reduced here to one. The feat does not reduce an appointment's calendar wait, another person's work, mandatory travel, deciphering unknown language, a fixed magical duration or a research procedure that is not gathering local events, people or rumors. Use the ordinary information/social check and result without an extra numerical bonus. Faster acquisition does not make gossip true, complete, public or freely given. Keep actual bribes, admission, obligations and secrecy risks. No retry of unchanged evidence merely because the task was faster; record which contacts actually supplied which claims. Apply the final feat conference's time-reduction stacking rule rather than multiply overlapping discounts silently.",
  "submittedNewChoices": "Two-hour fallback task; half-time rounding and boundary between active inquiry and calendar waits; stacking still a joint choice.",
  "submittedWorkedCases": [
    "A declared90-minute local inquiry becomes45active minutes. A separately scheduled meeting tomorrow still occurs tomorrow.",
    "The holder learns a rumor more quickly, but a false rumor remains false and an unwilling contact does not become willing from the time reduction."
  ],
  "decision": "Adopt half actual inquiry work and only a two-hour fallback absent a specific current task; appointment, travel and other actors time not reduced.",
  "completeAuthoringProcedure": "Identify an actual local information-gathering task, its contacts, topic, permitted method, normal active time and real costs before work. Spend half that actor's normal active time, rounded upward once to a whole minute. NEW: absent a more specific procedure, an ordinary round of local inquiries through accessible willing contacts takes two active hours, reduced here to one. The feat does not reduce an appointment's calendar wait, another person's work, mandatory travel, deciphering unknown language, a fixed magical duration or a research procedure that is not gathering local events, people or rumors. Use the ordinary information/social check and result without an extra numerical bonus. Faster acquisition does not make gossip true, complete, public or freely given. Keep actual bribes, admission, obligations and secrecy risks. No retry of unchanged evidence merely because the task was faster; record which contacts actually supplied which claims. Apply the final feat conference's time-reduction stacking rule rather than multiply overlapping discounts silently.",
  "newRuleProvenance": "All submitted NEW/proposed completions retained by this decision and all departures below are authoring decisions of FEAT327-SOURCE-2026-10-11, not recovered source wording. The original object remains immutable.",
  "sharedContract": "FEAT_SHARED_DIRECTIONS.json: FS-01–16",
  "supplementContract": "FEAT_SUPPLEMENT_DIRECTIONS.json: explicit source path/pointer mappings",
  "workedCases": [
    "A declared90-minute local inquiry becomes45active minutes. A separately scheduled meeting tomorrow still occurs tomorrow.",
    "The holder learns a rumor more quickly, but a false rumor remains false and an unwilling contact does not become willing from the time reduction."
  ],
  "payloadOperational": "full authored procedure; not a runtime adapter",
  "selectionEnabled": false,
  "exactApproved": false,
  "runtimeApproved": false
}
```

### Complete current candidate procedure

Identify an actual local information-gathering task, its contacts, topic, permitted method, normal active time and real costs before work. Spend half that actor's normal active time, rounded upward once to a whole minute. NEW: absent a more specific procedure, an ordinary round of local inquiries through accessible willing contacts takes two active hours, reduced here to one. The feat does not reduce an appointment's calendar wait, another person's work, mandatory travel, deciphering unknown language, a fixed magical duration or a research procedure that is not gathering local events, people or rumors. Use the ordinary information/social check and result without an extra numerical bonus. Faster acquisition does not make gossip true, complete, public or freely given. Keep actual bribes, admission, obligations and secrecy risks. No retry of unchanged evidence merely because the task was faster; record which contacts actually supplied which claims. Apply the final feat conference's time-reduction stacking rule rather than multiply overlapping discounts silently.

### Original-position authored review references

```json
[
  {
    "id": "GE-18-E01",
    "report": {
      "path": "docs/audit/2026-10-08/full-game/FEAT335_EXPLORATION_ORIGINAL_CASEBOOK_REVIEW_93.json",
      "bytes": 483808,
      "sha256": "ac2f12df49630b64e6cef4ca5b163c669e911338259508223a7c5eca6933a92c"
    },
    "pointer": "/originalCaseReviews/39"
  },
  {
    "id": "GE-18-E02",
    "report": {
      "path": "docs/audit/2026-10-08/full-game/FEAT335_EXPLORATION_ORIGINAL_CASEBOOK_REVIEW_93.json",
      "bytes": 483808,
      "sha256": "ac2f12df49630b64e6cef4ca5b163c669e911338259508223a7c5eca6933a92c"
    },
    "pointer": "/originalCaseReviews/40"
  }
]
```

## GE-19 — Improved Athlete

### Complete original object

```json
{
  "id": "athlete_improved",
  "name": "Improved Athlete",
  "description": "Your athletic abilities are exceptional.",
  "prerequisite": "Athlete feat",
  "effect": "Your climbing and swimming speeds equal your walking speed, and you can long jump your full Strength score.",
  "type": "General",
  "draft": false,
  "deprecated": false,
  "needsReview": false
}
```

### Original question

```json
"Require the actual Athlete feat ID. Resolve climb/swim Speed equality to walking, stacking with Climber, and long jump equal to full STR score: running versus standing, upward/vertical limits, spent movement and actual landing/checks. Preserve Athlete base benefit without adding its modifier twice unless explicitly decided."
```

### Preserved original source direction (historical)

```json
{
  "featId": "athlete_improved",
  "name": "Improved Athlete",
  "cohort": "general_exploration",
  "questionId": "GE-19",
  "disposition": "AUTHOR_FROM_SUBMITTED_PROCEDURE_WITH_FINAL_SHARED_RULES",
  "sourcePath": "DescentReviewChanges/ReviewBible/data/director/general_exploration_feat_operating_proposal_internal.json",
  "sourceFileSha256": "e13b824f4e6b5ecb39e409d32ecc2b2bdf6aeba9cdc229d4377c50530b067149",
  "sourcePointer": "/records/18",
  "originalQuestion": "Require the actual Athlete feat ID. Resolve climb/swim Speed equality to walking, stacking with Climber, and long jump equal to full STR score: running versus standing, upward/vertical limits, spent movement and actual landing/checks. Preserve Athlete base benefit without adding its modifier twice unless explicitly decided.",
  "originalSourceObject": {
    "id": "athlete_improved",
    "name": "Improved Athlete",
    "description": "Your athletic abilities are exceptional.",
    "prerequisite": "Athlete feat",
    "effect": "Your climbing and swimming speeds equal your walking speed, and you can long jump your full Strength score.",
    "type": "General",
    "draft": false,
    "deprecated": false,
    "needsReview": false
  },
  "originalSourceObjectSha256AsSubmitted": "a2fc8eea9280ecf769359fa7168b4aeb3cea8525e51cb957ea7cac2553c48eb1",
  "submittedProcedure": "Requires the actual Athlete feat, ID athlete. Gain climbing and swimming Speeds equal to current legal walking Speed; alternate sources granting those same modes do not add together. Use actual anatomy, support, water conditions, breathing and the spent-cost ledger; neither movement mode permits an impossible surface or cancels hazards. NEW reading of the source's unrestricted long-jump clause: a standing long jump can span up to the current Strength score in feet; a running long jump uses that same base and retains Athlete's separate increase equal to the nonnegative current Strength modifier. For this proposal, a running approach means at least10feet of actual immediately preceding movement on supporting ground. Both the approach and airborne distance spend movement normally. The feat changes horizontal distance, not vertical clearance, a high jump, flight or safe landing. A legal check can still be needed for a hazardous takeoff or landing, and no success creates additional distance. These proposed standing/running distinctions and the10-foot approach need comparison with the complete movement source review before adoption.",
  "submittedNewChoices": "Standing full-Strength distance; explicit10-foot running approach; preserve Athlete's separate running modifier once with nonnegative gain; current-speed grants.",
  "submittedWorkedCases": [
    "STR16 and its+3 modifier permit a proposed16-foot standing jump or19-foot running jump. A10-foot approach plus19feet airborne spends29feet before any additional terrain costs.",
    "Walking Speed0 gives climbing and swimming Speed0. A legal destination still cannot be reached by claiming the jump as free movement."
  ],
  "decision": "Adopt NEW standing full STR jump and running STR+nonnegativeSTRmod with ten-foot approach; Athlete prerequisite and actual movement costs/landing govern.",
  "completeAuthoringProcedure": "Requires the actual Athlete feat, ID athlete. Gain climbing and swimming Speeds equal to current legal walking Speed; alternate sources granting those same modes do not add together. Use actual anatomy, support, water conditions, breathing and the spent-cost ledger; neither movement mode permits an impossible surface or cancels hazards. NEW reading of the source's unrestricted long-jump clause: a standing long jump can span up to the current Strength score in feet; a running long jump uses that same base and retains Athlete's separate increase equal to the nonnegative current Strength modifier. For this proposal, a running approach means at least10feet of actual immediately preceding movement on supporting ground. Both the approach and airborne distance spend movement normally. The feat changes horizontal distance, not vertical clearance, a high jump, flight or safe landing. A legal check can still be needed for a hazardous takeoff or landing, and no success creates additional distance. These proposed standing/running distinctions and the10-foot approach need comparison with the complete movement source review before adoption.",
  "newRuleProvenance": "All submitted NEW/proposed completions retained by this decision and all departures below are authoring decisions of FEAT327-SOURCE-2026-10-11, not recovered source wording. The original object remains immutable.",
  "sharedContract": "FEAT_SHARED_DIRECTIONS.json: FS-01–16",
  "supplementContract": "FEAT_SUPPLEMENT_DIRECTIONS.json: explicit source path/pointer mappings",
  "workedCases": [
    "STR16 and its+3 modifier permit a proposed16-foot standing jump or19-foot running jump. A10-foot approach plus19feet airborne spends29feet before any additional terrain costs.",
    "Walking Speed0 gives climbing and swimming Speed0. A legal destination still cannot be reached by claiming the jump as free movement."
  ],
  "payloadOperational": "full authored procedure; not a runtime adapter",
  "selectionEnabled": false,
  "exactApproved": false,
  "runtimeApproved": false
}
```

### Complete current candidate procedure

Requires the actual Athlete feat, ID athlete. Gain climbing and swimming Speeds equal to current legal walking Speed; alternate sources granting those same modes do not add together. Use actual anatomy, support, water conditions, breathing and the spent-cost ledger; neither movement mode permits an impossible surface or cancels hazards. NEW reading of the source's unrestricted long-jump clause: a standing long jump can span up to the current Strength score in feet; a running long jump uses that same base and retains Athlete's separate increase equal to the nonnegative current Strength modifier. For this proposal, a running approach means at least10feet of actual immediately preceding movement on supporting ground. Both the approach and airborne distance spend movement normally. The feat changes horizontal distance, not vertical clearance, a high jump, flight or safe landing. A legal check can still be needed for a hazardous takeoff or landing, and no success creates additional distance. These proposed standing/running distinctions and the10-foot approach need comparison with the complete movement source review before adoption.

### Original-position authored review references

```json
[
  {
    "id": "GE-19-E01",
    "report": {
      "path": "docs/audit/2026-10-08/full-game/FEAT335_EXPLORATION_ORIGINAL_CASEBOOK_REVIEW_93.json",
      "bytes": 483808,
      "sha256": "ac2f12df49630b64e6cef4ca5b163c669e911338259508223a7c5eca6933a92c"
    },
    "pointer": "/originalCaseReviews/41"
  },
  {
    "id": "GE-19-E02",
    "report": {
      "path": "docs/audit/2026-10-08/full-game/FEAT335_EXPLORATION_ORIGINAL_CASEBOOK_REVIEW_93.json",
      "bytes": 483808,
      "sha256": "ac2f12df49630b64e6cef4ca5b163c669e911338259508223a7c5eca6933a92c"
    },
    "pointer": "/originalCaseReviews/42"
  }
]
```

## GE-20 — Improved Climber

### Complete original object

```json
{
  "id": "climber_improved",
  "name": "Improved Climber",
  "description": "You are an exceptional climber.",
  "prerequisite": "Climber feat",
  "effect": "You can climb on ceilings and overhangs, and you don't fall when you fail a climbing check by 4 or less.",
  "type": "General",
  "draft": false,
  "deprecated": false,
  "needsReview": false
}
```

### Original question

```json
"Require the actual Climber feat. Define ceiling/overhang support, hands/equipment, movement and surfaces; does this create adhesion or require holds? A climb failure by four or less avoids falling but needs exact position, spent movement, repeat attempts and consequences. No retroactive success or rescue from already-falling unrelated events."
```

### Preserved original source direction (historical)

```json
{
  "featId": "climber_improved",
  "name": "Improved Climber",
  "cohort": "general_exploration",
  "questionId": "GE-20",
  "disposition": "AUTHOR_FROM_SUBMITTED_PROCEDURE_WITH_FINAL_SHARED_RULES",
  "sourcePath": "DescentReviewChanges/ReviewBible/data/director/general_exploration_feat_operating_proposal_internal.json",
  "sourceFileSha256": "e13b824f4e6b5ecb39e409d32ecc2b2bdf6aeba9cdc229d4377c50530b067149",
  "sourcePointer": "/records/19",
  "originalQuestion": "Require the actual Climber feat. Define ceiling/overhang support, hands/equipment, movement and surfaces; does this create adhesion or require holds? A climb failure by four or less avoids falling but needs exact position, spent movement, repeat attempts and consequences. No retroactive success or rescue from already-falling unrelated events.",
  "originalSourceObject": {
    "id": "climber_improved",
    "name": "Improved Climber",
    "description": "You are an exceptional climber.",
    "prerequisite": "Climber feat",
    "effect": "You can climb on ceilings and overhangs, and you don't fall when you fail a climbing check by 4 or less.",
    "type": "General",
    "draft": false,
    "deprecated": false,
    "needsReview": false
  },
  "originalSourceObjectSha256AsSubmitted": "37fe21dc63e29d4eeb836f10a12a23053a194363607a4e9b4c17f69bec93dd24",
  "submittedProcedure": "Requires the actual Climber feat, ID climber. NEW: ceiling and overhang climbing is possible with actual usable grips, anchors or equipment sufficient for the current body's support; the feat removes the angle-only bar but supplies no adhesion to a featureless unsupported surface. Pay the ordinary climbing movement budget and make any real required check, including Climber's advantage when applicable. If that climb check fails by a final numerical deficit of1–4, you avoid the fall caused by that failed check. Remain at the last legally supported position, spend the movement/action/time already committed, and gain no progress through the failed segment. A natural-1 degree downgrade with deficit below5 still receives this narrow fall protection. A failed result with total meeting the DC due solely to a natural downgrade also avoids that check's fall under this NEW clarification. Deficit5+ receives no protection. The feat does not stop an unrelated shove, lost anchor, collapsing support, already ongoing fall or deliberate release. A retry needs a legally available new attempt under the climb task, without refunded movement.",
  "submittedNewChoices": "Real support versus adhesion; exact failure-margin/zero-deficit handling; position and spent-cost consequence.",
  "submittedWorkedCases": [
    "DC18, total14 fails by4: remain at the last supported place without gaining the failed traverse, and keep the spent movement cost. Total13 fails by5 and may fall normally.",
    "A rope anchor breaks after a successful climb. That is a separate loss of support, so the feat's failed-check protection does not suspend the climber in air."
  ],
  "decision": "Adopt ceiling/overhang grip capability and no-fall on numerical deficit<5 only, preserving committed cost, last support and independent collapse.",
  "completeAuthoringProcedure": "Requires the actual Climber feat, ID climber. NEW: ceiling and overhang climbing is possible with actual usable grips, anchors or equipment sufficient for the current body's support; the feat removes the angle-only bar but supplies no adhesion to a featureless unsupported surface. Pay the ordinary climbing movement budget and make any real required check, including Climber's advantage when applicable. If that climb check fails by a final numerical deficit of1–4, you avoid the fall caused by that failed check. Remain at the last legally supported position, spend the movement/action/time already committed, and gain no progress through the failed segment. A natural-1 degree downgrade with deficit below5 still receives this narrow fall protection. A failed result with total meeting the DC due solely to a natural downgrade also avoids that check's fall under this NEW clarification. Deficit5+ receives no protection. The feat does not stop an unrelated shove, lost anchor, collapsing support, already ongoing fall or deliberate release. A retry needs a legally available new attempt under the climb task, without refunded movement.",
  "newRuleProvenance": "All submitted NEW/proposed completions retained by this decision and all departures below are authoring decisions of FEAT327-SOURCE-2026-10-11, not recovered source wording. The original object remains immutable.",
  "sharedContract": "FEAT_SHARED_DIRECTIONS.json: FS-01–16",
  "supplementContract": "FEAT_SUPPLEMENT_DIRECTIONS.json: explicit source path/pointer mappings",
  "workedCases": [
    "DC18, total14 fails by4: remain at the last supported place without gaining the failed traverse, and keep the spent movement cost. Total13 fails by5 and may fall normally.",
    "A rope anchor breaks after a successful climb. That is a separate loss of support, so the feat's failed-check protection does not suspend the climber in air."
  ],
  "payloadOperational": "full authored procedure; not a runtime adapter",
  "selectionEnabled": false,
  "exactApproved": false,
  "runtimeApproved": false
}
```

### Complete current candidate procedure

Requires the actual Climber feat, ID climber. NEW: ceiling and overhang climbing is possible with actual usable grips, anchors or equipment sufficient for the current body's support; the feat removes the angle-only bar but supplies no adhesion to a featureless unsupported surface. Pay the ordinary climbing movement budget and make any real required check, including Climber's advantage when applicable. If that climb check fails by a final numerical deficit of1–4, you avoid the fall caused by that failed check. Remain at the last legally supported position, spend the movement/action/time already committed, and gain no progress through the failed segment. A natural-1 degree downgrade with deficit below5 still receives this narrow fall protection. A failed result with total meeting the DC due solely to a natural downgrade also avoids that check's fall under this NEW clarification. Deficit5+ receives no protection. The feat does not stop an unrelated shove, lost anchor, collapsing support, already ongoing fall or deliberate release. A retry needs a legally available new attempt under the climb task, without refunded movement.

### Original-position authored review references

```json
[
  {
    "id": "GE-20-E01",
    "report": {
      "path": "docs/audit/2026-10-08/full-game/FEAT335_EXPLORATION_ORIGINAL_CASEBOOK_REVIEW_93.json",
      "bytes": 483808,
      "sha256": "ac2f12df49630b64e6cef4ca5b163c669e911338259508223a7c5eca6933a92c"
    },
    "pointer": "/originalCaseReviews/43"
  },
  {
    "id": "GE-20-E02",
    "report": {
      "path": "docs/audit/2026-10-08/full-game/FEAT335_EXPLORATION_ORIGINAL_CASEBOOK_REVIEW_93.json",
      "bytes": 483808,
      "sha256": "ac2f12df49630b64e6cef4ca5b163c669e911338259508223a7c5eca6933a92c"
    },
    "pointer": "/originalCaseReviews/44"
  }
]
```

## GE-21 — Keen Mind

### Complete original object

```json
{
  "id": "keen_mind",
  "name": "Keen Mind",
  "description": "You have a mind that can track time, direction, and detail.",
  "prerequisite": "Intelligence 13 or higher",
  "effect": "You always know which way is north, the number of hours left before sunrise or sunset, and can recall anything you have seen or heard within the past month.",
  "type": "General",
  "draft": false,
  "deprecated": false,
  "needsReview": false
}
```

### Original question

```json
"Define remembered observations versus previously hidden information, one-month elapsed-clock scope and precision, true north where meaningful, and sunrise/sunset information where none occurs. Preserve uncertainty rather than invent astronomy, planes or omniscience. Jewelcrafting06:00 recovery is not proof of actual sunrise; cosmology remains deferred."
```

### Preserved original source direction (historical)

```json
{
  "featId": "keen_mind",
  "name": "Keen Mind",
  "cohort": "general_exploration",
  "questionId": "GE-21",
  "disposition": "AUTHOR_FROM_SUBMITTED_PROCEDURE_WITH_FINAL_SHARED_RULES",
  "sourcePath": "DescentReviewChanges/ReviewBible/data/director/general_exploration_feat_operating_proposal_internal.json",
  "sourceFileSha256": "e13b824f4e6b5ecb39e409d32ecc2b2bdf6aeba9cdc229d4377c50530b067149",
  "sourcePointer": "/records/20",
  "originalQuestion": "Define remembered observations versus previously hidden information, one-month elapsed-clock scope and precision, true north where meaningful, and sunrise/sunset information where none occurs. Preserve uncertainty rather than invent astronomy, planes or omniscience. Jewelcrafting06:00 recovery is not proof of actual sunrise; cosmology remains deferred.",
  "originalSourceObject": {
    "id": "keen_mind",
    "name": "Keen Mind",
    "description": "You have a mind that can track time, direction, and detail.",
    "prerequisite": "Intelligence 13 or higher",
    "effect": "You always know which way is north, the number of hours left before sunrise or sunset, and can recall anything you have seen or heard within the past month.",
    "type": "General",
    "draft": false,
    "deprecated": false,
    "needsReview": false
  },
  "originalSourceObjectSha256AsSubmitted": "9def84d67bdbeee6f320c24e2ccd68795c4dc05ff8a93848757b4d3e746fb893",
  "submittedProcedure": "Always know the direction designated as true north in the current region's established physical/map frame and the remaining elapsed hours to its actual next sunrise or sunset when that event exists. This requires no artificial navigation roll, but does not reveal passages, destinations or a safe route. NEW boundary: where no such direction/event is defined by actual setting evidence, record 'not defined here' or 'no scheduled event' rather than inventing a cosmological answer; confer on any real exception later. Accurately recall anything you actually perceived by sight or hearing within the past month, including sounds or marks you did not understand, without thereby translating them or learning concealed details. NEW: for this feat's memory window only, month means30elapsed24-hour days; this does not define the world's calendar. Recollection can reproduce the perceived sequence, but limited attention, obstructed senses and a deceptive illusion limit what was perceived. Explicit memory alteration follows its own effect. Numerical dawn-like recharge receipts are not evidence of sunrise. No soul, plane, alignment or celestial explanation is authored here.",
  "submittedNewChoices": "Defined-frame/no-event boundary;30-day memory window and perception-versus-truth distinction. No new astronomical canon.",
  "submittedWorkedCases": [
    "A rune seen clearly ten days ago can be recalled in its observed form, but an unread language remains untranslated. A hidden reverse side was never seen.",
    "A place with no actual sunrise schedule receives no invented time-to-sunrise. An item that recharges at06:00 does not establish a sunrise at06:00."
  ],
  "decision": "Adopt30 elapsed days for this memory only and actual north/sun-event receipts; no astronomy, unknown perception or translation authored.",
  "completeAuthoringProcedure": "Always know the direction designated as true north in the current region's established physical/map frame and the remaining elapsed hours to its actual next sunrise or sunset when that event exists. This requires no artificial navigation roll, but does not reveal passages, destinations or a safe route. NEW boundary: where no such direction/event is defined by actual setting evidence, record 'not defined here' or 'no scheduled event' rather than inventing a cosmological answer; confer on any real exception later. Accurately recall anything you actually perceived by sight or hearing within the past month, including sounds or marks you did not understand, without thereby translating them or learning concealed details. NEW: for this feat's memory window only, month means30elapsed24-hour days; this does not define the world's calendar. Recollection can reproduce the perceived sequence, but limited attention, obstructed senses and a deceptive illusion limit what was perceived. Explicit memory alteration follows its own effect. Numerical dawn-like recharge receipts are not evidence of sunrise. No soul, plane, alignment or celestial explanation is authored here.",
  "newRuleProvenance": "All submitted NEW/proposed completions retained by this decision and all departures below are authoring decisions of FEAT327-SOURCE-2026-10-11, not recovered source wording. The original object remains immutable.",
  "sharedContract": "FEAT_SHARED_DIRECTIONS.json: FS-01–16",
  "supplementContract": "FEAT_SUPPLEMENT_DIRECTIONS.json: explicit source path/pointer mappings",
  "workedCases": [
    "A rune seen clearly ten days ago can be recalled in its observed form, but an unread language remains untranslated. A hidden reverse side was never seen.",
    "A place with no actual sunrise schedule receives no invented time-to-sunrise. An item that recharges at06:00 does not establish a sunrise at06:00."
  ],
  "payloadOperational": "full authored procedure; not a runtime adapter",
  "selectionEnabled": false,
  "exactApproved": false,
  "runtimeApproved": false
}
```

### Complete current candidate procedure

Always know the direction designated as true north in the current region's established physical/map frame and the remaining elapsed hours to its actual next sunrise or sunset when that event exists. This requires no artificial navigation roll, but does not reveal passages, destinations or a safe route. NEW boundary: where no such direction/event is defined by actual setting evidence, record 'not defined here' or 'no scheduled event' rather than inventing a cosmological answer; confer on any real exception later. Accurately recall anything you actually perceived by sight or hearing within the past month, including sounds or marks you did not understand, without thereby translating them or learning concealed details. NEW: for this feat's memory window only, month means30elapsed24-hour days; this does not define the world's calendar. Recollection can reproduce the perceived sequence, but limited attention, obstructed senses and a deceptive illusion limit what was perceived. Explicit memory alteration follows its own effect. Numerical dawn-like recharge receipts are not evidence of sunrise. No soul, plane, alignment or celestial explanation is authored here.

### Original-position authored review references

```json
[
  {
    "id": "GE-21-E01",
    "report": {
      "path": "docs/audit/2026-10-08/full-game/FEAT335_EXPLORATION_ORIGINAL_CASEBOOK_REVIEW_93.json",
      "bytes": 483808,
      "sha256": "ac2f12df49630b64e6cef4ca5b163c669e911338259508223a7c5eca6933a92c"
    },
    "pointer": "/originalCaseReviews/45"
  },
  {
    "id": "GE-21-E02",
    "report": {
      "path": "docs/audit/2026-10-08/full-game/FEAT335_EXPLORATION_ORIGINAL_CASEBOOK_REVIEW_93.json",
      "bytes": 483808,
      "sha256": "ac2f12df49630b64e6cef4ca5b163c669e911338259508223a7c5eca6933a92c"
    },
    "pointer": "/originalCaseReviews/46"
  }
]
```

## GE-22 — Leadership

### Complete original object

```json
{
  "id": "leadership",
  "name": "Leadership",
  "description": "You inspire others to follow you.",
  "prerequisite": "Charisma 15+, level 6+",
  "effect": "You can recruit followers and hirelings more easily, and they are more loyal to you.",
  "type": "General",
  "draft": false,
  "deprecated": false,
  "needsReview": false
}
```

### Original question

```json
"Complete a finite recruitment and loyalty benefit with actual willingness, pay, number/type/level of followers, time and obligations. Separate hirelings from bonded combat companions and summoned units; no free statblock, extra turn, forced loyalty or bypass of command/structural caps. Compare Natural Leader and Commanding Presence."
```

### Preserved original source direction (historical)

```json
{
  "featId": "leadership",
  "name": "Leadership",
  "cohort": "general_exploration",
  "questionId": "GE-22",
  "disposition": "AUTHOR_FROM_SUBMITTED_PROCEDURE_WITH_FINAL_SHARED_RULES",
  "sourcePath": "DescentReviewChanges/ReviewBible/data/director/general_exploration_feat_operating_proposal_internal.json",
  "sourceFileSha256": "e13b824f4e6b5ecb39e409d32ecc2b2bdf6aeba9cdc229d4377c50530b067149",
  "sourcePointer": "/records/21",
  "originalQuestion": "Complete a finite recruitment and loyalty benefit with actual willingness, pay, number/type/level of followers, time and obligations. Separate hirelings from bonded combat companions and summoned units; no free statblock, extra turn, forced loyalty or bypass of command/structural caps. Compare Natural Leader and Commanding Presence.",
  "originalSourceObject": {
    "id": "leadership",
    "name": "Leadership",
    "description": "You inspire others to follow you.",
    "prerequisite": "Charisma 15+, level 6+",
    "effect": "You can recruit followers and hirelings more easily, and they are more loyal to you.",
    "type": "General",
    "draft": false,
    "deprecated": false,
    "needsReview": false
  },
  "originalSourceObjectSha256AsSubmitted": "0368e1d780cdfc738b44a05bfd9292218364b737227923772344c774870974a1",
  "submittedProcedure": "NEW finite recruitment/loyalty procedure: during a real recruitment effort, designate up to current PB actual willing prospective followers or hirelings. Spend one active hour interviewing and briefing them, agree on their actual jobs, pay, duration, risk, equipment and departure terms, and gain+2 on any legitimate Persuasion checks to secure those agreements. An automatic willing agreement needs no roll. The feat creates no candidate, free wage, stat block, level, binding, summoned unit or extra class companion. Keep at most PB current designated contracts receiving the feat's loyalty benefit; designate at agreement or at a new hour-long briefing, never retroactively during a morale event. While the employer honors the terms and the work remains within the agreed risk, a designated follower gains+2 on an actual loyalty/morale check whose purpose is deciding whether to abandon that agreement under pressure. This is not a bonus against every fear spell or a compulsion to stay; no roll is invented where the person's real decision is certain. Broken terms, unpaid wages or an unagreed suicidal demand remove this benefit until genuinely repaired and re-briefed. Actual transport, expedition caps, combat turns and command budgets continue to govern each recruited person. Dismissal ends designation without transferring any creature's property or earned wages.",
  "submittedNewChoices": "PB designated-contract cap, one-hour briefing, +2 recruitment and scoped+2 loyalty checks; contract/agency bounds. Requires final hireling procedure.",
  "submittedWorkedCases": [
    "PB3 can designate three real hired people, each still requiring a valid contract and actual pay. The feat does not authorize a thirteenth expedition character against the owner's12-character cap.",
    "A follower ordered into danger expressly excluded from their contract does not receive a loyalty check that forces compliance. The employer must negotiate a real change or accept refusal."
  ],
  "decision": "Adopt PB contracts, one-hour briefing and scoped+2 recruitment/loyalty with actual wages, terms, risk and owner-locked12-character cap.",
  "completeAuthoringProcedure": "NEW finite recruitment/loyalty procedure: during a real recruitment effort, designate up to current PB actual willing prospective followers or hirelings. Spend one active hour interviewing and briefing them, agree on their actual jobs, pay, duration, risk, equipment and departure terms, and gain+2 on any legitimate Persuasion checks to secure those agreements. An automatic willing agreement needs no roll. The feat creates no candidate, free wage, stat block, level, binding, summoned unit or extra class companion. Keep at most PB current designated contracts receiving the feat's loyalty benefit; designate at agreement or at a new hour-long briefing, never retroactively during a morale event. While the employer honors the terms and the work remains within the agreed risk, a designated follower gains+2 on an actual loyalty/morale check whose purpose is deciding whether to abandon that agreement under pressure. This is not a bonus against every fear spell or a compulsion to stay; no roll is invented where the person's real decision is certain. Broken terms, unpaid wages or an unagreed suicidal demand remove this benefit until genuinely repaired and re-briefed. Actual transport, expedition caps, combat turns and command budgets continue to govern each recruited person. Dismissal ends designation without transferring any creature's property or earned wages.",
  "newRuleProvenance": "All submitted NEW/proposed completions retained by this decision and all departures below are authoring decisions of FEAT327-SOURCE-2026-10-11, not recovered source wording. The original object remains immutable.",
  "sharedContract": "FEAT_SHARED_DIRECTIONS.json: FS-01–16",
  "supplementContract": "FEAT_SUPPLEMENT_DIRECTIONS.json: explicit source path/pointer mappings",
  "workedCases": [
    "PB3 can designate three real hired people, each still requiring a valid contract and actual pay. The feat does not authorize a thirteenth expedition character against the owner's12-character cap.",
    "A follower ordered into danger expressly excluded from their contract does not receive a loyalty check that forces compliance. The employer must negotiate a real change or accept refusal."
  ],
  "payloadOperational": "full authored procedure; not a runtime adapter",
  "selectionEnabled": false,
  "exactApproved": false,
  "runtimeApproved": false
}
```

### Complete current candidate procedure

NEW finite recruitment/loyalty procedure: during a real recruitment effort, designate up to current PB actual willing prospective followers or hirelings. Spend one active hour interviewing and briefing them, agree on their actual jobs, pay, duration, risk, equipment and departure terms, and gain+2 on any legitimate Persuasion checks to secure those agreements. An automatic willing agreement needs no roll. The feat creates no candidate, free wage, stat block, level, binding, summoned unit or extra class companion. Keep at most PB current designated contracts receiving the feat's loyalty benefit; designate at agreement or at a new hour-long briefing, never retroactively during a morale event. While the employer honors the terms and the work remains within the agreed risk, a designated follower gains+2 on an actual loyalty/morale check whose purpose is deciding whether to abandon that agreement under pressure. This is not a bonus against every fear spell or a compulsion to stay; no roll is invented where the person's real decision is certain. Broken terms, unpaid wages or an unagreed suicidal demand remove this benefit until genuinely repaired and re-briefed. Actual transport, expedition caps, combat turns and command budgets continue to govern each recruited person. Dismissal ends designation without transferring any creature's property or earned wages.

### Original-position authored review references

```json
[
  {
    "id": "GE-22-E01",
    "report": {
      "path": "docs/audit/2026-10-08/full-game/FEAT335_EXPLORATION_ORIGINAL_CASEBOOK_REVIEW_93.json",
      "bytes": 483808,
      "sha256": "ac2f12df49630b64e6cef4ca5b163c669e911338259508223a7c5eca6933a92c"
    },
    "pointer": "/originalCaseReviews/47"
  },
  {
    "id": "GE-22-E02",
    "report": {
      "path": "docs/audit/2026-10-08/full-game/FEAT335_EXPLORATION_ORIGINAL_CASEBOOK_REVIEW_93.json",
      "bytes": 483808,
      "sha256": "ac2f12df49630b64e6cef4ca5b163c669e911338259508223a7c5eca6933a92c"
    },
    "pointer": "/originalCaseReviews/48"
  }
]
```

## GE-23 — Naturalist

### Complete original object

```json
{
  "id": "naturalist",
  "name": "Naturalist",
  "description": "You have extensive knowledge of nature.",
  "prerequisite": "Wisdom 13 or higher",
  "effect": "You gain proficiency in Nature and Survival. If already proficient, you add double your proficiency bonus.",
  "type": "General",
  "draft": false,
  "deprecated": false,
  "needsReview": false
}
```

### Original question

```json
"Preserve Nature and Survival training and existing-proficiency double PB separately. Define acquisition/later proficiency and strongest expertise handling. Distinguish knowledge, navigation, tracking and resource-finding tasks; no automatic foraging output or access to hidden ecology/cosmology."
```

### Preserved original source direction (historical)

```json
{
  "featId": "naturalist",
  "name": "Naturalist",
  "cohort": "general_exploration",
  "questionId": "GE-23",
  "disposition": "AUTHOR_FROM_SUBMITTED_PROCEDURE_WITH_FINAL_SHARED_RULES",
  "sourcePath": "DescentReviewChanges/ReviewBible/data/director/general_exploration_feat_operating_proposal_internal.json",
  "sourceFileSha256": "e13b824f4e6b5ecb39e409d32ecc2b2bdf6aeba9cdc229d4377c50530b067149",
  "sourcePointer": "/records/22",
  "originalQuestion": "Preserve Nature and Survival training and existing-proficiency double PB separately. Define acquisition/later proficiency and strongest expertise handling. Distinguish knowledge, navigation, tracking and resource-finding tasks; no automatic foraging output or access to hidden ecology/cosmology.",
  "originalSourceObject": {
    "id": "naturalist",
    "name": "Naturalist",
    "description": "You have extensive knowledge of nature.",
    "prerequisite": "Wisdom 13 or higher",
    "effect": "You gain proficiency in Nature and Survival. If already proficient, you add double your proficiency bonus.",
    "type": "General",
    "draft": false,
    "deprecated": false,
    "needsReview": false
  },
  "originalSourceObjectSha256AsSubmitted": "17a0ca350418faf9027b3df48a6c8bd93df7d194bcf4c4674ec9b47467f42f6d",
  "submittedProcedure": "Evaluate Nature and Survival separately at acquisition: gain proficiency if untrained, or twice-PB Expertise if already proficient. Nature remains the relevant knowledge skill, normally Intelligence; Survival remains the actual navigation, tracking or resource-finding skill, normally Wisdom, when the task calls for it. The feat grants no free forage yield, hidden ecological fact, ingredient identity, wilderness immunity or new resource. It does not bypass the actual Supply, source-depletion, route, watch or creature-size procedures. No creature origin or cosmology is inferred from its name.",
  "submittedNewChoices": "Apply the shared proposed acquisition snapshot independently to each listed skill; retain full source prerequisite/effect and no stacking of Expertise.",
  "submittedWorkedCases": [
    "INT 12, WIS 16, PB +2 with Nature trained and Survival untrained gives Nature +5 and Survival +5 after acquisition; equal totals arise from different ability/proficiency contributions.",
    "Two sources of Survival Expertise use one twice-PB contribution. A tool credential that also fits the task does not add a second PB.",
    "A successful knowledge check can identify a plant from available evidence. If an area is already depleted, the feat does not make another harvest exist."
  ],
  "decision": "Adopt independent Nature/Survival snapshot; actual skill abilities and finite stock remain.",
  "completeAuthoringProcedure": "Evaluate Nature and Survival separately at acquisition: gain proficiency if untrained, or twice-PB Expertise if already proficient. Nature remains the relevant knowledge skill, normally Intelligence; Survival remains the actual navigation, tracking or resource-finding skill, normally Wisdom, when the task calls for it. The feat grants no free forage yield, hidden ecological fact, ingredient identity, wilderness immunity or new resource. It does not bypass the actual Supply, source-depletion, route, watch or creature-size procedures. No creature origin or cosmology is inferred from its name.",
  "newRuleProvenance": "All submitted NEW/proposed completions retained by this decision and all departures below are authoring decisions of FEAT327-SOURCE-2026-10-11, not recovered source wording. The original object remains immutable.",
  "sharedContract": "FEAT_SHARED_DIRECTIONS.json: FS-01–16",
  "supplementContract": "FEAT_SUPPLEMENT_DIRECTIONS.json: explicit source path/pointer mappings",
  "workedCases": [
    "INT 12, WIS 16, PB +2 with Nature trained and Survival untrained gives Nature +5 and Survival +5 after acquisition; equal totals arise from different ability/proficiency contributions.",
    "Two sources of Survival Expertise use one twice-PB contribution. A tool credential that also fits the task does not add a second PB.",
    "A successful knowledge check can identify a plant from available evidence. If an area is already depleted, the feat does not make another harvest exist."
  ],
  "payloadOperational": "full authored procedure; not a runtime adapter",
  "selectionEnabled": false,
  "exactApproved": false,
  "runtimeApproved": false
}
```

### Complete current candidate procedure

Evaluate Nature and Survival separately at acquisition: gain proficiency if untrained, or twice-PB Expertise if already proficient. Nature remains the relevant knowledge skill, normally Intelligence; Survival remains the actual navigation, tracking or resource-finding skill, normally Wisdom, when the task calls for it. The feat grants no free forage yield, hidden ecological fact, ingredient identity, wilderness immunity or new resource. It does not bypass the actual Supply, source-depletion, route, watch or creature-size procedures. No creature origin or cosmology is inferred from its name.

### Original-position authored review references

```json
[
  {
    "id": "GE-23-E01",
    "report": {
      "path": "docs/audit/2026-10-08/full-game/FEAT335_EXPLORATION_ORIGINAL_CASEBOOK_REVIEW_93.json",
      "bytes": 483808,
      "sha256": "ac2f12df49630b64e6cef4ca5b163c669e911338259508223a7c5eca6933a92c"
    },
    "pointer": "/originalCaseReviews/49"
  },
  {
    "id": "GE-23-E02",
    "report": {
      "path": "docs/audit/2026-10-08/full-game/FEAT335_EXPLORATION_ORIGINAL_CASEBOOK_REVIEW_93.json",
      "bytes": 483808,
      "sha256": "ac2f12df49630b64e6cef4ca5b163c669e911338259508223a7c5eca6933a92c"
    },
    "pointer": "/originalCaseReviews/50"
  },
  {
    "id": "GE-23-E03",
    "report": {
      "path": "docs/audit/2026-10-08/full-game/FEAT335_EXPLORATION_ORIGINAL_CASEBOOK_REVIEW_93.json",
      "bytes": 483808,
      "sha256": "ac2f12df49630b64e6cef4ca5b163c669e911338259508223a7c5eca6933a92c"
    },
    "pointer": "/originalCaseReviews/51"
  }
]
```

## GE-24 — Negotiator

### Complete original object

```json
{
  "id": "negotiator",
  "name": "Negotiator",
  "description": "You excel at making deals.",
  "prerequisite": "Charisma 13+",
  "effect": "You can negotiate better prices for goods and services, and you have advantage on Persuasion checks during negotiations.",
  "type": "General",
  "draft": false,
  "deprecated": false,
  "needsReview": false
}
```

### Original question

```json
"Complete better-prices wording in actual buyer/seller procedures; distinguish negotiated quotes from guaranteed percentage multipliers or standing benefits. Preserve Persuasion advantage on genuine negotiations, limits on repeated rolls, information and willingness. No circular buy/sell profit or automatic magical-item buyer."
```

### Preserved original source direction (historical)

```json
{
  "featId": "negotiator",
  "name": "Negotiator",
  "cohort": "general_exploration",
  "questionId": "GE-24",
  "disposition": "AUTHOR_FROM_SUBMITTED_PROCEDURE_WITH_FINAL_SHARED_RULES",
  "sourcePath": "DescentReviewChanges/ReviewBible/data/director/general_exploration_feat_operating_proposal_internal.json",
  "sourceFileSha256": "e13b824f4e6b5ecb39e409d32ecc2b2bdf6aeba9cdc229d4377c50530b067149",
  "sourcePointer": "/records/23",
  "originalQuestion": "Complete better-prices wording in actual buyer/seller procedures; distinguish negotiated quotes from guaranteed percentage multipliers or standing benefits. Preserve Persuasion advantage on genuine negotiations, limits on repeated rolls, information and willingness. No circular buy/sell profit or automatic magical-item buyer.",
  "originalSourceObject": {
    "id": "negotiator",
    "name": "Negotiator",
    "description": "You excel at making deals.",
    "prerequisite": "Charisma 13+",
    "effect": "You can negotiate better prices for goods and services, and you have advantage on Persuasion checks during negotiations.",
    "type": "General",
    "draft": false,
    "deprecated": false,
    "needsReview": false
  },
  "originalSourceObjectSha256AsSubmitted": "ac1930df29ef3f89263af0bcca45b605a4792338abfd85a2b96abbb129d62e10",
  "submittedProcedure": "Gain advantage on actual Persuasion checks during negotiations for real goods or services. NEW: before the check, establish the seller/buyer's available stock, normal quote, attainable concession, payment and conditions. A successful check secures that announced better quote or term; no universal percentage discount or guaranteed buyer is created. A concession can be a lower price, improved payment schedule, delivery, included fitting or a better actual sale offer, with its exact value set before rolling. The counterpart must have authority and willingness to consider it. Failed unchanged negotiations cannot be repeated by restating the same bargain or swapping speakers without a materially changed offer or evidence. Distinct standing, sponsor and service benefits use their own actual clauses; advantage does not stack. Different purchase and resale quotes remain separate, and this feat never establishes a same-price repurchase promise or circular money source. Record the final agreement and any taxes/fees through the actual settlement procedure.",
  "submittedNewChoices": "Predeclared exact concession and finite bargain record; no invented blanket percentage. Full live market/social procedure supplies numeric quote limits.",
  "submittedWorkedCases": [
    "A merchant offers a possible reduction from50gp to45gp on success. A successful advantaged check secures45gp under the announced terms; it does not also apply another unprinted10% discount.",
    "Buying for45gp does not force any buyer to repurchase for50gp. A later actual resale uses that buyer's own stock, demand and quote."
  ],
  "decision": "Keep advantage and predeclared achievable concession without universal discount; completed EX58 quote, standing, institution and settlement records govern.",
  "completeAuthoringProcedure": "Gain advantage on actual Persuasion checks during negotiations for real goods or services. NEW: before the check, establish the seller/buyer's available stock, normal quote, attainable concession, payment and conditions. A successful check secures that announced better quote or term; no universal percentage discount or guaranteed buyer is created. A concession can be a lower price, improved payment schedule, delivery, included fitting or a better actual sale offer, with its exact value set before rolling. The counterpart must have authority and willingness to consider it. Failed unchanged negotiations cannot be repeated by restating the same bargain or swapping speakers without a materially changed offer or evidence. Distinct standing, sponsor and service benefits use their own actual clauses; advantage does not stack. Different purchase and resale quotes remain separate, and this feat never establishes a same-price repurchase promise or circular money source. Record the final agreement and any taxes/fees through the actual settlement procedure.",
  "newRuleProvenance": "All submitted NEW/proposed completions retained by this decision and all departures below are authoring decisions of FEAT327-SOURCE-2026-10-11, not recovered source wording. The original object remains immutable.",
  "sharedContract": "FEAT_SHARED_DIRECTIONS.json: FS-01–16",
  "supplementContract": "FEAT_SUPPLEMENT_DIRECTIONS.json: explicit source path/pointer mappings",
  "workedCases": [
    "A merchant offers a possible reduction from50gp to45gp on success. A successful advantaged check secures45gp under the announced terms; it does not also apply another unprinted10% discount.",
    "Buying for45gp does not force any buyer to repurchase for50gp. A later actual resale uses that buyer's own stock, demand and quote."
  ],
  "payloadOperational": "full authored procedure; not a runtime adapter",
  "selectionEnabled": false,
  "exactApproved": false,
  "runtimeApproved": false
}
```

### Complete current candidate procedure

Gain advantage on actual Persuasion checks during negotiations for real goods or services. NEW: before the check, establish the seller/buyer's available stock, normal quote, attainable concession, payment and conditions. A successful check secures that announced better quote or term; no universal percentage discount or guaranteed buyer is created. A concession can be a lower price, improved payment schedule, delivery, included fitting or a better actual sale offer, with its exact value set before rolling. The counterpart must have authority and willingness to consider it. Failed unchanged negotiations cannot be repeated by restating the same bargain or swapping speakers without a materially changed offer or evidence. Distinct standing, sponsor and service benefits use their own actual clauses; advantage does not stack. Different purchase and resale quotes remain separate, and this feat never establishes a same-price repurchase promise or circular money source. Record the final agreement and any taxes/fees through the actual settlement procedure.

### Original-position authored review references

```json
[
  {
    "id": "GE-24-E01",
    "report": {
      "path": "docs/audit/2026-10-08/full-game/FEAT335_EXPLORATION_ORIGINAL_CASEBOOK_REVIEW_93.json",
      "bytes": 483808,
      "sha256": "ac2f12df49630b64e6cef4ca5b163c669e911338259508223a7c5eca6933a92c"
    },
    "pointer": "/originalCaseReviews/52"
  },
  {
    "id": "GE-24-E02",
    "report": {
      "path": "docs/audit/2026-10-08/full-game/FEAT335_EXPLORATION_ORIGINAL_CASEBOOK_REVIEW_93.json",
      "bytes": 483808,
      "sha256": "ac2f12df49630b64e6cef4ca5b163c669e911338259508223a7c5eca6933a92c"
    },
    "pointer": "/originalCaseReviews/53"
  }
]
```

## GE-25 — Observant

### Complete original object

```json
{
  "id": "observant",
  "name": "Observant",
  "description": "Quick to notice details of your environment, you gain the following benefits:",
  "prerequisite": "None",
  "effect": "Increase Intelligence or Wisdom by 1, +5 bonus to passive Perception and passive Investigation",
  "type": "General",
  "draft": false,
  "deprecated": false,
  "needsReview": false
}
```

### Original question

```json
"Preserve +1INT orWIS and +5passive Perception AND passive Investigation. Define score cap, actual passive formulas and when Investigation can be passive under current Core procedures; no automatic active-check+5 or unlimited hidden-detail revelation. Resolve advantage/disadvantage passive adjustments and related bonuses explicitly."
```

### Preserved original source direction (historical)

```json
{
  "featId": "observant",
  "name": "Observant",
  "cohort": "general_exploration",
  "questionId": "GE-25",
  "disposition": "AUTHOR_FROM_SUBMITTED_PROCEDURE_WITH_FINAL_SHARED_RULES",
  "sourcePath": "DescentReviewChanges/ReviewBible/data/director/general_exploration_feat_operating_proposal_internal.json",
  "sourceFileSha256": "e13b824f4e6b5ecb39e409d32ecc2b2bdf6aeba9cdc229d4377c50530b067149",
  "sourcePointer": "/records/24",
  "originalQuestion": "Preserve +1INT orWIS and +5passive Perception AND passive Investigation. Define score cap, actual passive formulas and when Investigation can be passive under current Core procedures; no automatic active-check+5 or unlimited hidden-detail revelation. Resolve advantage/disadvantage passive adjustments and related bonuses explicitly.",
  "originalSourceObject": {
    "id": "observant",
    "name": "Observant",
    "description": "Quick to notice details of your environment, you gain the following benefits:",
    "prerequisite": "None",
    "effect": "Increase Intelligence or Wisdom by 1, +5 bonus to passive Perception and passive Investigation",
    "type": "General",
    "draft": false,
    "deprecated": false,
    "needsReview": false
  },
  "originalSourceObjectSha256AsSubmitted": "1c49ca9e8bbb96abf1b98785dd41f74514d3f8f09299a6f150bef9aff29138b9",
  "submittedProcedure": "At acquisition choose Intelligence or Wisdom and increase that score by1, to the ordinary maximum20 unless a separately reviewed source explicitly permits more. Gain+5 to passive Perception and passive Investigation. NEW: passive Perception is10 plus the current Wisdom (Perception) modifier including applicable proficiency once; passive Investigation is10 plus the current Intelligence (Investigation) modifier including applicable proficiency once. Apply this feat's+5 once to each. Passive Investigation may resolve a declared sustained or routine examination of actually accessible physical evidence when the governing task permits a passive result; it is not a free constant scan for every hidden detail. Specific tasks requiring an active check or paid examination remain active. No natural-die shift or automatic passive±5 for advantage/disadvantage is added. Apply actual qualifying numerical penalties or bonuses in their normal scope. This feat gives no+5 to active rolls, attack detection through impossible senses or automatic truth about an illusion. The score increase can independently alter its own relevant ability modifiers.",
  "submittedNewChoices": "Score cap and declared passive-Investigation procedure; actual formulas; no generic advantage conversion.",
  "submittedWorkedCases": [
    "WIS16 and Perception proficiency at PB+2 gives passive Perception10+3+2+5=20. An active Perception roll gets the ordinary+5 modifier, not an additional feat+5.",
    "INT15 increased to16 with Investigation proficiency at PB+3 gives passive Investigation10+3+3+5=21 when that passive task is allowed. A required lock examination still takes its stated time."
  ],
  "decision": "Adopt passive formulas and+5 only on authorized passive tasks, with actual+1 INT/WIS cap20; no invented passive advantage bonus.",
  "completeAuthoringProcedure": "At acquisition choose Intelligence or Wisdom and increase that score by1, to the ordinary maximum20 unless a separately reviewed source explicitly permits more. Gain+5 to passive Perception and passive Investigation. NEW: passive Perception is10 plus the current Wisdom (Perception) modifier including applicable proficiency once; passive Investigation is10 plus the current Intelligence (Investigation) modifier including applicable proficiency once. Apply this feat's+5 once to each. Passive Investigation may resolve a declared sustained or routine examination of actually accessible physical evidence when the governing task permits a passive result; it is not a free constant scan for every hidden detail. Specific tasks requiring an active check or paid examination remain active. No natural-die shift or automatic passive±5 for advantage/disadvantage is added. Apply actual qualifying numerical penalties or bonuses in their normal scope. This feat gives no+5 to active rolls, attack detection through impossible senses or automatic truth about an illusion. The score increase can independently alter its own relevant ability modifiers.",
  "newRuleProvenance": "All submitted NEW/proposed completions retained by this decision and all departures below are authoring decisions of FEAT327-SOURCE-2026-10-11, not recovered source wording. The original object remains immutable.",
  "sharedContract": "FEAT_SHARED_DIRECTIONS.json: FS-01–16",
  "supplementContract": "FEAT_SUPPLEMENT_DIRECTIONS.json: explicit source path/pointer mappings",
  "workedCases": [
    "WIS16 and Perception proficiency at PB+2 gives passive Perception10+3+2+5=20. An active Perception roll gets the ordinary+5 modifier, not an additional feat+5.",
    "INT15 increased to16 with Investigation proficiency at PB+3 gives passive Investigation10+3+3+5=21 when that passive task is allowed. A required lock examination still takes its stated time."
  ],
  "payloadOperational": "full authored procedure; not a runtime adapter",
  "selectionEnabled": false,
  "exactApproved": false,
  "runtimeApproved": false
}
```

### Complete current candidate procedure

At acquisition choose Intelligence or Wisdom and increase that score by1, to the ordinary maximum20 unless a separately reviewed source explicitly permits more. Gain+5 to passive Perception and passive Investigation. NEW: passive Perception is10 plus the current Wisdom (Perception) modifier including applicable proficiency once; passive Investigation is10 plus the current Intelligence (Investigation) modifier including applicable proficiency once. Apply this feat's+5 once to each. Passive Investigation may resolve a declared sustained or routine examination of actually accessible physical evidence when the governing task permits a passive result; it is not a free constant scan for every hidden detail. Specific tasks requiring an active check or paid examination remain active. No natural-die shift or automatic passive±5 for advantage/disadvantage is added. Apply actual qualifying numerical penalties or bonuses in their normal scope. This feat gives no+5 to active rolls, attack detection through impossible senses or automatic truth about an illusion. The score increase can independently alter its own relevant ability modifiers.

### Original-position authored review references

```json
[
  {
    "id": "GE-25-E01",
    "report": {
      "path": "docs/audit/2026-10-08/full-game/FEAT335_EXPLORATION_ORIGINAL_CASEBOOK_REVIEW_93.json",
      "bytes": 483808,
      "sha256": "ac2f12df49630b64e6cef4ca5b163c669e911338259508223a7c5eca6933a92c"
    },
    "pointer": "/originalCaseReviews/54"
  },
  {
    "id": "GE-25-E02",
    "report": {
      "path": "docs/audit/2026-10-08/full-game/FEAT335_EXPLORATION_ORIGINAL_CASEBOOK_REVIEW_93.json",
      "bytes": 483808,
      "sha256": "ac2f12df49630b64e6cef4ca5b163c669e911338259508223a7c5eca6933a92c"
    },
    "pointer": "/originalCaseReviews/55"
  }
]
```

## GE-26 — Pathfinder

### Complete original object

```json
{
  "id": "pathfinder",
  "name": "Pathfinder",
  "description": "You can navigate any terrain.",
  "prerequisite": "Wisdom 13+",
  "effect": "You and your party can move at normal speed while tracking, and difficult terrain doesn't slow your group's travel.",
  "type": "General",
  "draft": false,
  "deprecated": false,
  "needsReview": false
}
```

### Original question

```json
"Define one actual traveling party, tracking pace and what difficult terrain travel ignores, including mounts/vehicles, separation, route access and adverse hazards. Distinguish strategic travel time from tactical Speed/movement costs, climbing/swimming, forced march and impassable surfaces. Compare Wilderness Walker and Master Tracker."
```

### Preserved original source direction (historical)

```json
{
  "featId": "pathfinder",
  "name": "Pathfinder",
  "cohort": "general_exploration",
  "questionId": "GE-26",
  "disposition": "AUTHOR_FROM_SUBMITTED_PROCEDURE_WITH_FINAL_SHARED_RULES",
  "sourcePath": "DescentReviewChanges/ReviewBible/data/director/general_exploration_feat_operating_proposal_internal.json",
  "sourceFileSha256": "e13b824f4e6b5ecb39e409d32ecc2b2bdf6aeba9cdc229d4377c50530b067149",
  "sourcePointer": "/records/25",
  "originalQuestion": "Define one actual traveling party, tracking pace and what difficult terrain travel ignores, including mounts/vehicles, separation, route access and adverse hazards. Distinguish strategic travel time from tactical Speed/movement costs, climbing/swimming, forced march and impassable surfaces. Compare Wilderness Walker and Master Tracker.",
  "originalSourceObject": {
    "id": "pathfinder",
    "name": "Pathfinder",
    "description": "You can navigate any terrain.",
    "prerequisite": "Wisdom 13+",
    "effect": "You and your party can move at normal speed while tracking, and difficult terrain doesn't slow your group's travel.",
    "type": "General",
    "draft": false,
    "deprecated": false,
    "needsReview": false
  },
  "originalSourceObjectSha256AsSubmitted": "02c5aea4884d7d1db2f9b760e75626443d6ea2ebc7bde2516c3649177bd6a8a4",
  "submittedProcedure": "While you actively lead one physically coordinated traveling party, the party may track at its actual normal travel pace and ignore ordinary difficult terrain's reduction of strategic travel rate. NEW: party members must remain on the led route and able to follow your current directions directly or through their actual communications chain; separated scouts and a different caravan receive no remote benefit. Use the normal rate of the actual slowest participating body/vehicle, with actual capacity, access and work/rest limits. A mount or wagon can benefit only on a route it can physically traverse; the feat supplies neither a road through an impassable gap nor a swim/fly/climb mode. Severe weather, visibility, moving currents, climbing tasks, hazards, loading and other independent delays still apply. This changes the difficult-terrain travel-rate factor and tracking activity, not tactical difficult-terrain movement costs, combat Speed, forced-march rules or resource consumption. If leadership/coordination ends, subsequent travel uses ordinary rates; already elapsed time is not recalculated.",
  "submittedNewChoices": "One coordinated party, strategic-only terrain-rate scope, actual slowest traveler and vehicle legality. Full travel numbers come from the live expedition verdict.",
  "submittedWorkedCases": [
    "A coordinated party with a slower laden wagon uses that wagon's actual normal route rate while ignoring the ordinary rough-ground slowdown. The feat cannot make the wagon cross a path narrower than its body.",
    "A scout who leaves the coordinated route loses the group benefit for their separate travel. During combat, ordinary difficult-terrain costs still apply."
  ],
  "decision": "Adopt coordinated party strategic terrain/tracking exception with genuine instructions, slowest body/profile, actual route and no tactical or mount-mode creation.",
  "completeAuthoringProcedure": "While you actively lead one physically coordinated traveling party, the party may track at its actual normal travel pace and ignore ordinary difficult terrain's reduction of strategic travel rate. NEW: party members must remain on the led route and able to follow your current directions directly or through their actual communications chain; separated scouts and a different caravan receive no remote benefit. Use the normal rate of the actual slowest participating body/vehicle, with actual capacity, access and work/rest limits. A mount or wagon can benefit only on a route it can physically traverse; the feat supplies neither a road through an impassable gap nor a swim/fly/climb mode. Severe weather, visibility, moving currents, climbing tasks, hazards, loading and other independent delays still apply. This changes the difficult-terrain travel-rate factor and tracking activity, not tactical difficult-terrain movement costs, combat Speed, forced-march rules or resource consumption. If leadership/coordination ends, subsequent travel uses ordinary rates; already elapsed time is not recalculated.",
  "newRuleProvenance": "All submitted NEW/proposed completions retained by this decision and all departures below are authoring decisions of FEAT327-SOURCE-2026-10-11, not recovered source wording. The original object remains immutable.",
  "sharedContract": "FEAT_SHARED_DIRECTIONS.json: FS-01–16",
  "supplementContract": "FEAT_SUPPLEMENT_DIRECTIONS.json: explicit source path/pointer mappings",
  "workedCases": [
    "A coordinated party with a slower laden wagon uses that wagon's actual normal route rate while ignoring the ordinary rough-ground slowdown. The feat cannot make the wagon cross a path narrower than its body.",
    "A scout who leaves the coordinated route loses the group benefit for their separate travel. During combat, ordinary difficult-terrain costs still apply."
  ],
  "payloadOperational": "full authored procedure; not a runtime adapter",
  "selectionEnabled": false,
  "exactApproved": false,
  "runtimeApproved": false
}
```

### Complete current candidate procedure

While you actively lead one physically coordinated traveling party, the party may track at its actual normal travel pace and ignore ordinary difficult terrain's reduction of strategic travel rate. NEW: party members must remain on the led route and able to follow your current directions directly or through their actual communications chain; separated scouts and a different caravan receive no remote benefit. Use the normal rate of the actual slowest participating body/vehicle, with actual capacity, access and work/rest limits. A mount or wagon can benefit only on a route it can physically traverse; the feat supplies neither a road through an impassable gap nor a swim/fly/climb mode. Severe weather, visibility, moving currents, climbing tasks, hazards, loading and other independent delays still apply. This changes the difficult-terrain travel-rate factor and tracking activity, not tactical difficult-terrain movement costs, combat Speed, forced-march rules or resource consumption. If leadership/coordination ends, subsequent travel uses ordinary rates; already elapsed time is not recalculated.

### Original-position authored review references

```json
[
  {
    "id": "GE-26-E01",
    "report": {
      "path": "docs/audit/2026-10-08/full-game/FEAT335_EXPLORATION_ORIGINAL_CASEBOOK_REVIEW_93.json",
      "bytes": 483808,
      "sha256": "ac2f12df49630b64e6cef4ca5b163c669e911338259508223a7c5eca6933a92c"
    },
    "pointer": "/originalCaseReviews/56"
  },
  {
    "id": "GE-26-E02",
    "report": {
      "path": "docs/audit/2026-10-08/full-game/FEAT335_EXPLORATION_ORIGINAL_CASEBOOK_REVIEW_93.json",
      "bytes": 483808,
      "sha256": "ac2f12df49630b64e6cef4ca5b163c669e911338259508223a7c5eca6933a92c"
    },
    "pointer": "/originalCaseReviews/57"
  }
]
```

## GE-27 — Ranger Training

### Complete original object

```json
{
  "id": "ranger_training",
  "name": "Ranger Training",
  "description": "You have learned wilderness survival techniques.",
  "prerequisite": "Wisdom 13+",
  "effect": "You gain proficiency in Survival and Nature, and you can hide even when only lightly obscured by natural phenomena.",
  "type": "General",
  "draft": false,
  "deprecated": false,
  "needsReview": false
}
```

### Original question

```json
"Preserve Survival/Nature proficiency and legal Hide while only lightly obscured by natural phenomena. Define actual natural obscurity, sight lines and observed hiding limitations; no invisible state or automatic success. The feat name grants no Ranger class level, spell list, companion or expertise when already proficient."
```

### Preserved original source direction (historical)

```json
{
  "featId": "ranger_training",
  "name": "Ranger Training",
  "cohort": "general_exploration",
  "questionId": "GE-27",
  "disposition": "AUTHOR_FROM_SUBMITTED_PROCEDURE_WITH_FINAL_SHARED_RULES",
  "sourcePath": "DescentReviewChanges/ReviewBible/data/director/general_exploration_feat_operating_proposal_internal.json",
  "sourceFileSha256": "e13b824f4e6b5ecb39e409d32ecc2b2bdf6aeba9cdc229d4377c50530b067149",
  "sourcePointer": "/records/26",
  "originalQuestion": "Preserve Survival/Nature proficiency and legal Hide while only lightly obscured by natural phenomena. Define actual natural obscurity, sight lines and observed hiding limitations; no invisible state or automatic success. The feat name grants no Ranger class level, spell list, companion or expertise when already proficient.",
  "originalSourceObject": {
    "id": "ranger_training",
    "name": "Ranger Training",
    "description": "You have learned wilderness survival techniques.",
    "prerequisite": "Wisdom 13+",
    "effect": "You gain proficiency in Survival and Nature, and you can hide even when only lightly obscured by natural phenomena.",
    "type": "General",
    "draft": false,
    "deprecated": false,
    "needsReview": false
  },
  "originalSourceObjectSha256AsSubmitted": "be0a392b6ab156ee39e4eaf4cfe46c213a4610dfbad03e5a82b3c9f3a797a450",
  "submittedProcedure": "Gain proficiency in Survival and Nature. Existing proficiency gives no Expertise under the proposed fixed-grant rule. You may attempt to Hide while only lightly obscured by actual natural phenomena, such as naturally occurring foliage, rainfall, falling snow, fog or blowing dust that genuinely interferes with the observer's view. NEW: this is an express eligibility exception to the ordinary clear-sight bar only while that qualifying partial obscurity exists; it permits a real Hide attempt against each affected observer, not automatic Hidden. Use normal Stealth, observer-specific passive DC, sound, other senses and revealing-event rules. A fully clear view or an observer unaffected by that natural obscurity gains no new bar to seeing you. Ordinary darkness and magical concealment use their own source permissions; merely naming a magical effect 'natural' does not qualify it here. The feat grants no Ranger class level, spells, companion, tracking expertise or movement benefit.",
  "submittedNewChoices": "Observed natural obscurity examples; precise Hide eligibility exception; independent observer/sense rules.",
  "submittedWorkedCases": [
    "Actual rain lightly obscures a character from one observer, permitting a Hide attempt. The character still rolls Stealth and can fail to become Hidden from that observer.",
    "A creature using an unaffected sense or a clear angle does not lose the character's position solely because another observer's view is obscured."
  ],
  "decision": "Adopt source natural-light-obscurity Hide permission with observer-specific checks; fixed Nature/Survival grants no Ranger engine.",
  "completeAuthoringProcedure": "Gain proficiency in Survival and Nature. Existing proficiency gives no Expertise under the proposed fixed-grant rule. You may attempt to Hide while only lightly obscured by actual natural phenomena, such as naturally occurring foliage, rainfall, falling snow, fog or blowing dust that genuinely interferes with the observer's view. NEW: this is an express eligibility exception to the ordinary clear-sight bar only while that qualifying partial obscurity exists; it permits a real Hide attempt against each affected observer, not automatic Hidden. Use normal Stealth, observer-specific passive DC, sound, other senses and revealing-event rules. A fully clear view or an observer unaffected by that natural obscurity gains no new bar to seeing you. Ordinary darkness and magical concealment use their own source permissions; merely naming a magical effect 'natural' does not qualify it here. The feat grants no Ranger class level, spells, companion, tracking expertise or movement benefit.",
  "newRuleProvenance": "All submitted NEW/proposed completions retained by this decision and all departures below are authoring decisions of FEAT327-SOURCE-2026-10-11, not recovered source wording. The original object remains immutable.",
  "sharedContract": "FEAT_SHARED_DIRECTIONS.json: FS-01–16",
  "supplementContract": "FEAT_SUPPLEMENT_DIRECTIONS.json: explicit source path/pointer mappings",
  "workedCases": [
    "Actual rain lightly obscures a character from one observer, permitting a Hide attempt. The character still rolls Stealth and can fail to become Hidden from that observer.",
    "A creature using an unaffected sense or a clear angle does not lose the character's position solely because another observer's view is obscured."
  ],
  "payloadOperational": "full authored procedure; not a runtime adapter",
  "selectionEnabled": false,
  "exactApproved": false,
  "runtimeApproved": false
}
```

### Complete current candidate procedure

Gain proficiency in Survival and Nature. Existing proficiency gives no Expertise under the proposed fixed-grant rule. You may attempt to Hide while only lightly obscured by actual natural phenomena, such as naturally occurring foliage, rainfall, falling snow, fog or blowing dust that genuinely interferes with the observer's view. NEW: this is an express eligibility exception to the ordinary clear-sight bar only while that qualifying partial obscurity exists; it permits a real Hide attempt against each affected observer, not automatic Hidden. Use normal Stealth, observer-specific passive DC, sound, other senses and revealing-event rules. A fully clear view or an observer unaffected by that natural obscurity gains no new bar to seeing you. Ordinary darkness and magical concealment use their own source permissions; merely naming a magical effect 'natural' does not qualify it here. The feat grants no Ranger class level, spells, companion, tracking expertise or movement benefit.

### Original-position authored review references

```json
[
  {
    "id": "GE-27-E01",
    "report": {
      "path": "docs/audit/2026-10-08/full-game/FEAT335_EXPLORATION_ORIGINAL_CASEBOOK_REVIEW_93.json",
      "bytes": 483808,
      "sha256": "ac2f12df49630b64e6cef4ca5b163c669e911338259508223a7c5eca6933a92c"
    },
    "pointer": "/originalCaseReviews/58"
  },
  {
    "id": "GE-27-E02",
    "report": {
      "path": "docs/audit/2026-10-08/full-game/FEAT335_EXPLORATION_ORIGINAL_CASEBOOK_REVIEW_93.json",
      "bytes": 483808,
      "sha256": "ac2f12df49630b64e6cef4ca5b163c669e911338259508223a7c5eca6933a92c"
    },
    "pointer": "/originalCaseReviews/59"
  }
]
```

## GE-28 — Scavenger

### Complete original object

```json
{
  "id": "scavenger",
  "name": "Scavenger",
  "description": "You can find useful items in unlikely places.",
  "prerequisite": "Intelligence 13+",
  "effect": "You can find basic equipment and supplies in ruins, dungeons, and other locations where others have been.",
  "type": "General",
  "draft": false,
  "deprecated": false,
  "needsReview": false
}
```

### Original question

```json
"Complete finite time, check, location availability and legal item table/value/quantity caps for basic equipment and supplies. Establish preexisting recoverable objects, ownership, condition and repeat-search depletion. No item creation, automatic harvest ingredient identity, magic loot or direct sale-value-to-Supply conversion."
```

### Preserved original source direction (historical)

```json
{
  "featId": "scavenger",
  "name": "Scavenger",
  "cohort": "general_exploration",
  "questionId": "GE-28",
  "disposition": "AUTHOR_FROM_SUBMITTED_PROCEDURE_WITH_FINAL_SHARED_RULES",
  "sourcePath": "DescentReviewChanges/ReviewBible/data/director/general_exploration_feat_operating_proposal_internal.json",
  "sourceFileSha256": "e13b824f4e6b5ecb39e409d32ecc2b2bdf6aeba9cdc229d4377c50530b067149",
  "sourcePointer": "/records/27",
  "originalQuestion": "Complete finite time, check, location availability and legal item table/value/quantity caps for basic equipment and supplies. Establish preexisting recoverable objects, ownership, condition and repeat-search depletion. No item creation, automatic harvest ingredient identity, magic loot or direct sale-value-to-Supply conversion.",
  "originalSourceObject": {
    "id": "scavenger",
    "name": "Scavenger",
    "description": "You can find useful items in unlikely places.",
    "prerequisite": "Intelligence 13+",
    "effect": "You can find basic equipment and supplies in ruins, dungeons, and other locations where others have been.",
    "type": "General",
    "draft": false,
    "deprecated": false,
    "needsReview": false
  },
  "originalSourceObjectSha256AsSubmitted": "bd0753467bfb0936caaa7be9e5d12d9ab98eb75b590548e3dc2c56163129c79e",
  "submittedProcedure": "NEW finite search procedure: choose an accessible previously occupied site and spend thirty active minutes searching one bounded area, such as a room, wreck compartment or campsite. Before the roll the Director records the actual recoverable mundane equipment/supplies, their condition, ownership and access barriers. Make Intelligence (Investigation), DC12 for ordinary scattered remains,15 for concealed useful pieces or20 for heavily obscured remains; a specific site DC takes precedence. On success identify up to1d4 actual item lots from that finite inventory, with a combined reference value at most10gp and combined cargo at most1Load. The die cannot create missing lots: take no more than actually exist and are within those limits. The player chooses which identified lots to retrieve, paying any separate safe-access/removal time; uncollected objects remain in place. These are ordinary catalog-compatible items or usable supplies, not magic loot, a free recipe ingredient classification or converted gp-to-Supply. A larger valuable object can be noticed by the normal search result but is not granted as an extra feat output. Mark searched evidence and removed quantities; another unchanged search of the same area gives no fresh roll or generated inventory. Genuine new access, deposited material or a different bounded area can justify a new attempt.",
  "submittedNewChoices": "Thirty-minute task, DC tiers, finite1d4/10gp/1Load discovery cap and site depletion. These numerical bounds need explicit source agreement.",
  "submittedWorkedCases": [
    "The die gives4 but the site holds only two eligible real lots worth7gp and0.5Load: only those two can be recovered. No third or fourth lot appears.",
    "A found locked chest still requires opening and ownership consequences. Repeating the scavenging roll cannot turn its unknown contents into free mundane supplies."
  ],
  "decision": "Adopt thirty-minute bounded site search, specifiedDC and1d4/10gp/1Load finite discovery limits; no new matter, ownership or salvage reset.",
  "completeAuthoringProcedure": "NEW finite search procedure: choose an accessible previously occupied site and spend thirty active minutes searching one bounded area, such as a room, wreck compartment or campsite. Before the roll the Director records the actual recoverable mundane equipment/supplies, their condition, ownership and access barriers. Make Intelligence (Investigation), DC12 for ordinary scattered remains,15 for concealed useful pieces or20 for heavily obscured remains; a specific site DC takes precedence. On success identify up to1d4 actual item lots from that finite inventory, with a combined reference value at most10gp and combined cargo at most1Load. The die cannot create missing lots: take no more than actually exist and are within those limits. The player chooses which identified lots to retrieve, paying any separate safe-access/removal time; uncollected objects remain in place. These are ordinary catalog-compatible items or usable supplies, not magic loot, a free recipe ingredient classification or converted gp-to-Supply. A larger valuable object can be noticed by the normal search result but is not granted as an extra feat output. Mark searched evidence and removed quantities; another unchanged search of the same area gives no fresh roll or generated inventory. Genuine new access, deposited material or a different bounded area can justify a new attempt.",
  "newRuleProvenance": "All submitted NEW/proposed completions retained by this decision and all departures below are authoring decisions of FEAT327-SOURCE-2026-10-11, not recovered source wording. The original object remains immutable.",
  "sharedContract": "FEAT_SHARED_DIRECTIONS.json: FS-01–16",
  "supplementContract": "FEAT_SUPPLEMENT_DIRECTIONS.json: explicit source path/pointer mappings",
  "workedCases": [
    "The die gives4 but the site holds only two eligible real lots worth7gp and0.5Load: only those two can be recovered. No third or fourth lot appears.",
    "A found locked chest still requires opening and ownership consequences. Repeating the scavenging roll cannot turn its unknown contents into free mundane supplies."
  ],
  "payloadOperational": "full authored procedure; not a runtime adapter",
  "selectionEnabled": false,
  "exactApproved": false,
  "runtimeApproved": false
}
```

### Complete current candidate procedure

NEW finite search procedure: choose an accessible previously occupied site and spend thirty active minutes searching one bounded area, such as a room, wreck compartment or campsite. Before the roll the Director records the actual recoverable mundane equipment/supplies, their condition, ownership and access barriers. Make Intelligence (Investigation), DC12 for ordinary scattered remains,15 for concealed useful pieces or20 for heavily obscured remains; a specific site DC takes precedence. On success identify up to1d4 actual item lots from that finite inventory, with a combined reference value at most10gp and combined cargo at most1Load. The die cannot create missing lots: take no more than actually exist and are within those limits. The player chooses which identified lots to retrieve, paying any separate safe-access/removal time; uncollected objects remain in place. These are ordinary catalog-compatible items or usable supplies, not magic loot, a free recipe ingredient classification or converted gp-to-Supply. A larger valuable object can be noticed by the normal search result but is not granted as an extra feat output. Mark searched evidence and removed quantities; another unchanged search of the same area gives no fresh roll or generated inventory. Genuine new access, deposited material or a different bounded area can justify a new attempt.

### Original-position authored review references

```json
[
  {
    "id": "GE-28-E01",
    "report": {
      "path": "docs/audit/2026-10-08/full-game/FEAT335_EXPLORATION_ORIGINAL_CASEBOOK_REVIEW_93.json",
      "bytes": 483808,
      "sha256": "ac2f12df49630b64e6cef4ca5b163c669e911338259508223a7c5eca6933a92c"
    },
    "pointer": "/originalCaseReviews/60"
  },
  {
    "id": "GE-28-E02",
    "report": {
      "path": "docs/audit/2026-10-08/full-game/FEAT335_EXPLORATION_ORIGINAL_CASEBOOK_REVIEW_93.json",
      "bytes": 483808,
      "sha256": "ac2f12df49630b64e6cef4ca5b163c669e911338259508223a7c5eca6933a92c"
    },
    "pointer": "/originalCaseReviews/61"
  }
]
```

## GE-29 — Survivalist

### Complete original object

```json
{
  "id": "survivalist",
  "name": "Survivalist",
  "description": "You excel at surviving in harsh conditions.",
  "prerequisite": "Constitution 13+, Wisdom 13+",
  "effect": "You can survive in any environment and can help others do the same. You need only half the normal amount of food and water.",
  "type": "General",
  "draft": false,
  "deprecated": false,
  "needsReview": false
}
```

### Original question

```json
"Resolve absolute survive-any-environment wording into explicit hazards and aid limits, without implying vacuum, lava, suffocation or universal immunity absent a rule. Preserve half food/water with exact units, size, rounding, schedules and stacking with Endurance/foraging. Do not grant rest benefits or erase existing deprivation."
```

### Preserved original source direction (historical)

```json
{
  "featId": "survivalist",
  "name": "Survivalist",
  "cohort": "general_exploration",
  "questionId": "GE-29",
  "disposition": "AUTHOR_FROM_EXACT_REPLACEMENT_WITH_FINAL_SHARED_RULES",
  "sourcePath": "DescentReviewChanges/ReviewBible/data/director/general_exploration_feat_operating_proposal_internal.json",
  "sourceFileSha256": "e13b824f4e6b5ecb39e409d32ecc2b2bdf6aeba9cdc229d4377c50530b067149",
  "sourcePointer": "/records/28",
  "originalQuestion": "Resolve absolute survive-any-environment wording into explicit hazards and aid limits, without implying vacuum, lava, suffocation or universal immunity absent a rule. Preserve half food/water with exact units, size, rounding, schedules and stacking with Endurance/foraging. Do not grant rest benefits or erase existing deprivation.",
  "originalSourceObject": {
    "id": "survivalist",
    "name": "Survivalist",
    "description": "You excel at surviving in harsh conditions.",
    "prerequisite": "Constitution 13+, Wisdom 13+",
    "effect": "You can survive in any environment and can help others do the same. You need only half the normal amount of food and water.",
    "type": "General",
    "draft": false,
    "deprecated": false,
    "needsReview": false
  },
  "originalSourceObjectSha256AsSubmitted": "6ab272306cf3dda5eb77092928542ea8bf522f2382c45d97e7cfd4af1826b2bd",
  "submittedProcedure": "Consume half your actual normal food requirement and half your actual normal potable-water requirement under the governing body/environment schedule. Keep the two quantities separate and exact; purchase indivisible containers or portions as needed but retain unused contents rather than rounding each consumption upward. NEW: choose the strongest applicable fractional requirement reduction instead of multiplying overlapping reductions. This does not erase existing deprivation or replace required breathing, shelter, equipment or rest. To complete the source's broad survival/help clause, NEW proposal: you have advantage on actual Survival checks to adapt a camp, clothing, route or shelter to an ordinary nonmagical environment and on Constitution saves caused solely by ordinary heat/cold exposure. During one active hour preparing a camp or travel plan, you can designate up to PB actual companions participating in that preparation; while they follow the plan and keep its required gear, they share the heat/cold-save advantage for the next eight elapsed hours. This does not confer food/water reduction on them, make unsafe material edible, or permit survival in lava, vacuum, drowning, magical extremes or an environment with no physically possible protective method. Actual hazard frequency, severity, DC and finite protection still apply. These explicit environmental limits are proposed replacements for the source's undefined absolute phrase, not a claim that it already said them.",
  "submittedNewChoices": "Exact half quantities; strongest requirement reduction; new Survival/heat-cold advantage and PB companion preparation; explicit scope of 'any environment'.",
  "submittedWorkedCases": [
    "A body needing2food units and4water units for the period consumes1food and2water with this feat; a separate half-requirement effect does not silently make either requirement one quarter.",
    "PB3 permits three actual prepared companions to share the proposed heat/cold advantage for eight hours. They still need their normal water, and none gains the ability to breathe underwater."
  ],
  "decision": "Adopt the explicit bounded survival assistance and strongest requirement reduction, using canonical2lb/8pint standard rather than an unexplained unit example.",
  "completeAuthoringProcedure": "Consume half your actual normal food requirement and half your actual normal potable-water requirement under the governing body/environment schedule. Keep the two quantities separate and exact; purchase indivisible containers or portions as needed but retain unused contents rather than rounding each consumption upward. NEW: choose the strongest applicable fractional requirement reduction instead of multiplying overlapping reductions. This does not erase existing deprivation or replace required breathing, shelter, equipment or rest. To complete the source's broad survival/help clause, NEW proposal: you have advantage on actual Survival checks to adapt a camp, clothing, route or shelter to an ordinary nonmagical environment and on Constitution saves caused solely by ordinary heat/cold exposure. During one active hour preparing a camp or travel plan, you can designate up to PB actual companions participating in that preparation; while they follow the plan and keep its required gear, they share the heat/cold-save advantage for the next eight elapsed hours. This does not confer food/water reduction on them, make unsafe material edible, or permit survival in lava, vacuum, drowning, magical extremes or an environment with no physically possible protective method. Actual hazard frequency, severity, DC and finite protection still apply. These explicit environmental limits are proposed replacements for the source's undefined absolute phrase, not a claim that it already said them.\nThe canonical daily standard is2lb food and8pints water, so this feat requires1lb/4pints; a Large consumer requires2lb/8pints rather than its ordinary4lb/16pints. The daily assessment, Rest Debt and unsupported-day recovery rules are unchanged. Include actual requirements by participant/time; do not halve companion or mount needs merely because they travel with you.",
  "newRuleProvenance": "All submitted NEW/proposed completions retained by this decision and all departures below are authoring decisions of FEAT327-SOURCE-2026-10-11, not recovered source wording. The original object remains immutable.",
  "sharedContract": "FEAT_SHARED_DIRECTIONS.json: FS-01–16",
  "supplementContract": "FEAT_SUPPLEMENT_DIRECTIONS.json: explicit source path/pointer mappings",
  "workedCases": [
    "A standard actor meets their reduced daily requirements with1lb food and4pints water. A Large actor needs2lb/8pints. A second half-requirement effect does not reduce those to quarters.",
    "PB3 supports three genuinely prepared companions for eight hours of the stated heat/cold-save advantage; they retain their own full requirements and all actual breathing/shelter limits."
  ],
  "payloadOperational": "full authored procedure; not a runtime adapter",
  "selectionEnabled": false,
  "exactApproved": false,
  "runtimeApproved": false
}
```

### Complete current candidate procedure

Consume half your actual normal food requirement and half your actual normal potable-water requirement under the governing body/environment schedule. Keep the two quantities separate and exact; purchase indivisible containers or portions as needed but retain unused contents rather than rounding each consumption upward. NEW: choose the strongest applicable fractional requirement reduction instead of multiplying overlapping reductions. This does not erase existing deprivation or replace required breathing, shelter, equipment or rest. To complete the source's broad survival/help clause, NEW proposal: you have advantage on actual Survival checks to adapt a camp, clothing, route or shelter to an ordinary nonmagical environment and on Constitution saves caused solely by ordinary heat/cold exposure. During one active hour preparing a camp or travel plan, you can designate up to PB actual companions participating in that preparation; while they follow the plan and keep its required gear, they share the heat/cold-save advantage for the next eight elapsed hours. This does not confer food/water reduction on them, make unsafe material edible, or permit survival in lava, vacuum, drowning, magical extremes or an environment with no physically possible protective method. Actual hazard frequency, severity, DC and finite protection still apply. These explicit environmental limits are proposed replacements for the source's undefined absolute phrase, not a claim that it already said them.
The canonical daily standard is2lb food and8pints water, so this feat requires1lb/4pints; a Large consumer requires2lb/8pints rather than its ordinary4lb/16pints. The daily assessment, Rest Debt and unsupported-day recovery rules are unchanged. Include actual requirements by participant/time; do not halve companion or mount needs merely because they travel with you.

### Original-position authored review references

```json
[
  {
    "id": "GE-29-E01",
    "report": {
      "path": "docs/audit/2026-10-08/full-game/FEAT335_EXPLORATION_ORIGINAL_CASEBOOK_REVIEW_93.json",
      "bytes": 483808,
      "sha256": "ac2f12df49630b64e6cef4ca5b163c669e911338259508223a7c5eca6933a92c"
    },
    "pointer": "/originalCaseReviews/62"
  },
  {
    "id": "GE-29-E02",
    "report": {
      "path": "docs/audit/2026-10-08/full-game/FEAT335_EXPLORATION_ORIGINAL_CASEBOOK_REVIEW_93.json",
      "bytes": 483808,
      "sha256": "ac2f12df49630b64e6cef4ca5b163c669e911338259508223a7c5eca6933a92c"
    },
    "pointer": "/originalCaseReviews/63"
  }
]
```

## GE-30 — Tracker

### Complete original object

```json
{
  "id": "tracker",
  "name": "Tracker",
  "description": "You can follow tracks across any terrain.",
  "prerequisite": "Wisdom 15+",
  "effect": "You can track creatures across any surface, including water and air. You can determine the age, size, and condition of tracks.",
  "type": "General",
  "draft": false,
  "deprecated": false,
  "needsReview": false
}
```

### Original question

```json
"Complete tracking across water/air using actual evidence, senses, time, DC, range and loss/reacquisition; distinguish finding no trail from automatic supernatural detection. Define precision and limits of age/size/condition information. No teleportation pursuit, hidden identity knowledge or cosmological travel permission."
```

### Preserved original source direction (historical)

```json
{
  "featId": "tracker",
  "name": "Tracker",
  "cohort": "general_exploration",
  "questionId": "GE-30",
  "disposition": "AUTHOR_FROM_SUBMITTED_PROCEDURE_WITH_FINAL_SHARED_RULES",
  "sourcePath": "DescentReviewChanges/ReviewBible/data/director/general_exploration_feat_operating_proposal_internal.json",
  "sourceFileSha256": "e13b824f4e6b5ecb39e409d32ecc2b2bdf6aeba9cdc229d4377c50530b067149",
  "sourcePointer": "/records/29",
  "originalQuestion": "Complete tracking across water/air using actual evidence, senses, time, DC, range and loss/reacquisition; distinguish finding no trail from automatic supernatural detection. Define precision and limits of age/size/condition information. No teleportation pursuit, hidden identity knowledge or cosmological travel permission.",
  "originalSourceObject": {
    "id": "tracker",
    "name": "Tracker",
    "description": "You can follow tracks across any terrain.",
    "prerequisite": "Wisdom 15+",
    "effect": "You can track creatures across any surface, including water and air. You can determine the age, size, and condition of tracks.",
    "type": "General",
    "draft": false,
    "deprecated": false,
    "needsReview": false
  },
  "originalSourceObjectSha256AsSubmitted": "7ded6b253b3f7a7247a62e129cb22706e56461aadad3e9243674ec6bf521fd15",
  "submittedProcedure": "The source expressly allows tracking over water and air. NEW proposed completion preserves a real exceptional benefit: from an actual known starting trail or witnessed passage, you can perceive faint physical-passage impressions of that same creature's continuous route within60feet of your position for up to24elapsed hours after passage, including its waterborne or airborne segments. This is a feat-local extraordinary trail sense, not free knowledge of every nearby creature. Spend one active minute examining a segment and make Wisdom (Survival) DC15, increased by5 when the trail is more than12hours old and by5 where multiple actual trails are heavily intermingled; an exact concealing source may expressly block or modify this sensing. On success follow the actual local direction and learn the passage's approximate age, creature size and evident physical condition such as limping or bleeding. No exact current HP, identity, destination, invisible present location, future path or unobserved intent is revealed. You still need a physically possible way to traverse the route, time at your legal tracking pace and a new real examination when a junction or lost segment creates uncertainty. Teleportation supplies no traversed intervening path; track ends at departure and resumes only after separately finding the arrival trail. No new plane/soul/cosmological mechanism is inferred. Failed unchanged examination cannot be rerolled without changed access, evidence or method. This exceptional-sense choice needs explicit GPT review against mundane tracking and divination.",
  "submittedNewChoices": "Entire exceptional trail-sense procedure,60feet/24hours/one-minute/DC bounds and teleport gap. It deliberately retains water/air tracking rather than making the source clause ineffective.",
  "submittedWorkedCases": [
    "At a witnessed flight departure ten hours ago, a nearby actual airborne trail can be followed on the proposed DC15 success. The tracker still needs a real route or flight capability to follow it vertically.",
    "A sixteen-hour-old heavily intermingled trail uses proposed DC25. A teleport at its end gives no directional line to the arrival point; no intervening travel happened."
  ],
  "decision": "Adopt explicitly NEW60-foot/24-hour passage-impression sense from real known/witnessed start, with one-minute15/+5/+5 check and no teleport bridge.",
  "completeAuthoringProcedure": "The source expressly allows tracking over water and air. NEW proposed completion preserves a real exceptional benefit: from an actual known starting trail or witnessed passage, you can perceive faint physical-passage impressions of that same creature's continuous route within60feet of your position for up to24elapsed hours after passage, including its waterborne or airborne segments. This is a feat-local extraordinary trail sense, not free knowledge of every nearby creature. Spend one active minute examining a segment and make Wisdom (Survival) DC15, increased by5 when the trail is more than12hours old and by5 where multiple actual trails are heavily intermingled; an exact concealing source may expressly block or modify this sensing. On success follow the actual local direction and learn the passage's approximate age, creature size and evident physical condition such as limping or bleeding. No exact current HP, identity, destination, invisible present location, future path or unobserved intent is revealed. You still need a physically possible way to traverse the route, time at your legal tracking pace and a new real examination when a junction or lost segment creates uncertainty. Teleportation supplies no traversed intervening path; track ends at departure and resumes only after separately finding the arrival trail. No new plane/soul/cosmological mechanism is inferred. Failed unchanged examination cannot be rerolled without changed access, evidence or method. This exceptional-sense choice needs explicit GPT review against mundane tracking and divination.",
  "newRuleProvenance": "All submitted NEW/proposed completions retained by this decision and all departures below are authoring decisions of FEAT327-SOURCE-2026-10-11, not recovered source wording. The original object remains immutable.",
  "sharedContract": "FEAT_SHARED_DIRECTIONS.json: FS-01–16",
  "supplementContract": "FEAT_SUPPLEMENT_DIRECTIONS.json: explicit source path/pointer mappings",
  "workedCases": [
    "At a witnessed flight departure ten hours ago, a nearby actual airborne trail can be followed on the proposed DC15 success. The tracker still needs a real route or flight capability to follow it vertically.",
    "A sixteen-hour-old heavily intermingled trail uses proposed DC25. A teleport at its end gives no directional line to the arrival point; no intervening travel happened."
  ],
  "payloadOperational": "full authored procedure; not a runtime adapter",
  "selectionEnabled": false,
  "exactApproved": false,
  "runtimeApproved": false
}
```

### Complete current candidate procedure

The source expressly allows tracking over water and air. NEW proposed completion preserves a real exceptional benefit: from an actual known starting trail or witnessed passage, you can perceive faint physical-passage impressions of that same creature's continuous route within60feet of your position for up to24elapsed hours after passage, including its waterborne or airborne segments. This is a feat-local extraordinary trail sense, not free knowledge of every nearby creature. Spend one active minute examining a segment and make Wisdom (Survival) DC15, increased by5 when the trail is more than12hours old and by5 where multiple actual trails are heavily intermingled; an exact concealing source may expressly block or modify this sensing. On success follow the actual local direction and learn the passage's approximate age, creature size and evident physical condition such as limping or bleeding. No exact current HP, identity, destination, invisible present location, future path or unobserved intent is revealed. You still need a physically possible way to traverse the route, time at your legal tracking pace and a new real examination when a junction or lost segment creates uncertainty. Teleportation supplies no traversed intervening path; track ends at departure and resumes only after separately finding the arrival trail. No new plane/soul/cosmological mechanism is inferred. Failed unchanged examination cannot be rerolled without changed access, evidence or method. This exceptional-sense choice needs explicit GPT review against mundane tracking and divination.

### Original-position authored review references

```json
[
  {
    "id": "GE-30-E01",
    "report": {
      "path": "docs/audit/2026-10-08/full-game/FEAT335_EXPLORATION_ORIGINAL_CASEBOOK_REVIEW_93.json",
      "bytes": 483808,
      "sha256": "ac2f12df49630b64e6cef4ca5b163c669e911338259508223a7c5eca6933a92c"
    },
    "pointer": "/originalCaseReviews/64"
  },
  {
    "id": "GE-30-E02",
    "report": {
      "path": "docs/audit/2026-10-08/full-game/FEAT335_EXPLORATION_ORIGINAL_CASEBOOK_REVIEW_93.json",
      "bytes": 483808,
      "sha256": "ac2f12df49630b64e6cef4ca5b163c669e911338259508223a7c5eca6933a92c"
    },
    "pointer": "/originalCaseReviews/65"
  }
]
```

## GE-31 — Wilderness Walker

### Complete original object

```json
{
  "id": "wilderness_walker",
  "name": "Wilderness Walker",
  "description": "Survival 4+ supports the listed freedom from terrain movement penalties.",
  "prerequisite": "Survival 4+",
  "effect": "No movement penalty in terrain.",
  "type": "General",
  "legacyEffect": "No movement penalty in terrain",
  "status": "provisional-complete",
  "balanceReview": true,
  "source": "Completed from the existing feat draft corpus on 2026-08-05; playable wording supplied, final balance pass still required.",
  "draft": false,
  "deprecated": false,
  "needsReview": true
}
```

### Original question

```json
"Resolve Survival4+ prerequisite against actual proficiency-based skill identities; do not assume trade level or PB4 satisfies it. Define terrain movement penalty scope across tactical difficult terrain, strategic pace and specific hazards, plus actual walk/climb/swim modes. Preserve source broad wording until explicitly bounded."
```

### Preserved original source direction (historical)

```json
{
  "featId": "wilderness_walker",
  "name": "Wilderness Walker",
  "cohort": "general_exploration",
  "questionId": "GE-31",
  "disposition": "AUTHOR_FROM_SUBMITTED_PROCEDURE_WITH_FINAL_SHARED_RULES",
  "sourcePath": "DescentReviewChanges/ReviewBible/data/director/general_exploration_feat_operating_proposal_internal.json",
  "sourceFileSha256": "e13b824f4e6b5ecb39e409d32ecc2b2bdf6aeba9cdc229d4377c50530b067149",
  "sourcePointer": "/records/30",
  "originalQuestion": "Resolve Survival4+ prerequisite against actual proficiency-based skill identities; do not assume trade level or PB4 satisfies it. Define terrain movement penalty scope across tactical difficult terrain, strategic pace and specific hazards, plus actual walk/climb/swim modes. Preserve source broad wording until explicitly bounded.",
  "originalSourceObject": {
    "id": "wilderness_walker",
    "name": "Wilderness Walker",
    "description": "Survival 4+ supports the listed freedom from terrain movement penalties.",
    "prerequisite": "Survival 4+",
    "effect": "No movement penalty in terrain.",
    "type": "General",
    "legacyEffect": "No movement penalty in terrain",
    "status": "provisional-complete",
    "balanceReview": true,
    "source": "Completed from the existing feat draft corpus on 2026-08-05; playable wording supplied, final balance pass still required.",
    "draft": false,
    "deprecated": false,
    "needsReview": true
  },
  "originalSourceObjectSha256AsSubmitted": "59bc160d39e5091c3b47540aa0701ca6bc26af4b5776aa2854c3e8f48022765b",
  "submittedProcedure": "Use the shared Skill-feat proposal's explicit acquisition bridge for Survival4+: actual Survival proficiency and permanent ordinary skill modifier at least+4, excluding temporary/situational bonuses. NEW broad completion of 'no movement penalty in terrain': when your own body moves through an actually traversable route, ignore extra movement-cost factors and Speed reductions whose sole stated cause is the terrain itself, including ordinary difficult/severe ground and magical terrain that only imposes those movement penalties. Crawling, squeezing, load, injury, creature conditions, lack of a movement mode, occupied-space restrictions, forced movement and an actual obstruction remain separate causes and still apply. A terrain hazard's attack, save, damage, falling risk or inflicted Grappled/Restrained condition is not itself waived; if its separate condition reduces Speed, that condition remains. In strategic travel remove only your own terrain-derived rate penalty, not every party member's; the group still uses its actual slowest participant. A mount, vehicle or carried companion does not inherit your feat. Mode switching retains spent movement costs and never refunds earlier expenditure. This deliberately proposes broad terrain-cost protection, including qualifying magical terrain, and needs exact spell/hazard comparisons rather than silently narrowing the source to woodland alone.",
  "submittedNewChoices": "Numeric prerequisite bridge; explicit terrain-only cause arbitration; magical terrain included, independent costs/conditions excluded; personal strategic scope.",
  "submittedWorkedCases": [
    "Crawling and squeezing through difficult terrain normally costs4feet per foot under current Core. Removing the terrain surcharge leaves3feet per foot: base1, crawling1 and squeezing1.",
    "A magical bog that only doubles terrain movement cost can be crossed at ordinary terrain cost. If its separate failed save inflicts Restrained, the resulting Speed0 remains until that condition ends."
  ],
  "decision": "Adopt explicit personal terrain-only movement protection, including magical terrain-only costs, not resulting conditions, crawl/squeeze, burden, mount movement or unsupported modes.",
  "completeAuthoringProcedure": "Use the shared Skill-feat proposal's explicit acquisition bridge for Survival4+: actual Survival proficiency and permanent ordinary skill modifier at least+4, excluding temporary/situational bonuses. NEW broad completion of 'no movement penalty in terrain': when your own body moves through an actually traversable route, ignore extra movement-cost factors and Speed reductions whose sole stated cause is the terrain itself, including ordinary difficult/severe ground and magical terrain that only imposes those movement penalties. Crawling, squeezing, load, injury, creature conditions, lack of a movement mode, occupied-space restrictions, forced movement and an actual obstruction remain separate causes and still apply. A terrain hazard's attack, save, damage, falling risk or inflicted Grappled/Restrained condition is not itself waived; if its separate condition reduces Speed, that condition remains. In strategic travel remove only your own terrain-derived rate penalty, not every party member's; the group still uses its actual slowest participant. A mount, vehicle or carried companion does not inherit your feat. Mode switching retains spent movement costs and never refunds earlier expenditure. This deliberately proposes broad terrain-cost protection, including qualifying magical terrain, and needs exact spell/hazard comparisons rather than silently narrowing the source to woodland alone.",
  "newRuleProvenance": "All submitted NEW/proposed completions retained by this decision and all departures below are authoring decisions of FEAT327-SOURCE-2026-10-11, not recovered source wording. The original object remains immutable.",
  "sharedContract": "FEAT_SHARED_DIRECTIONS.json: FS-01–16",
  "supplementContract": "FEAT_SUPPLEMENT_DIRECTIONS.json: explicit source path/pointer mappings",
  "workedCases": [
    "Crawling and squeezing through difficult terrain normally costs4feet per foot under current Core. Removing the terrain surcharge leaves3feet per foot: base1, crawling1 and squeezing1.",
    "A magical bog that only doubles terrain movement cost can be crossed at ordinary terrain cost. If its separate failed save inflicts Restrained, the resulting Speed0 remains until that condition ends."
  ],
  "payloadOperational": "full authored procedure; not a runtime adapter",
  "selectionEnabled": false,
  "exactApproved": false,
  "runtimeApproved": false
}
```

### Complete current candidate procedure

Use the shared Skill-feat proposal's explicit acquisition bridge for Survival4+: actual Survival proficiency and permanent ordinary skill modifier at least+4, excluding temporary/situational bonuses. NEW broad completion of 'no movement penalty in terrain': when your own body moves through an actually traversable route, ignore extra movement-cost factors and Speed reductions whose sole stated cause is the terrain itself, including ordinary difficult/severe ground and magical terrain that only imposes those movement penalties. Crawling, squeezing, load, injury, creature conditions, lack of a movement mode, occupied-space restrictions, forced movement and an actual obstruction remain separate causes and still apply. A terrain hazard's attack, save, damage, falling risk or inflicted Grappled/Restrained condition is not itself waived; if its separate condition reduces Speed, that condition remains. In strategic travel remove only your own terrain-derived rate penalty, not every party member's; the group still uses its actual slowest participant. A mount, vehicle or carried companion does not inherit your feat. Mode switching retains spent movement costs and never refunds earlier expenditure. This deliberately proposes broad terrain-cost protection, including qualifying magical terrain, and needs exact spell/hazard comparisons rather than silently narrowing the source to woodland alone.

### Original-position authored review references

```json
[
  {
    "id": "GE-31-E01",
    "report": {
      "path": "docs/audit/2026-10-08/full-game/FEAT335_EXPLORATION_ORIGINAL_CASEBOOK_REVIEW_93.json",
      "bytes": 483808,
      "sha256": "ac2f12df49630b64e6cef4ca5b163c669e911338259508223a7c5eca6933a92c"
    },
    "pointer": "/originalCaseReviews/66"
  },
  {
    "id": "GE-31-E02",
    "report": {
      "path": "docs/audit/2026-10-08/full-game/FEAT335_EXPLORATION_ORIGINAL_CASEBOOK_REVIEW_93.json",
      "bytes": 483808,
      "sha256": "ac2f12df49630b64e6cef4ca5b163c669e911338259508223a7c5eca6933a92c"
    },
    "pointer": "/originalCaseReviews/67"
  }
]
```
