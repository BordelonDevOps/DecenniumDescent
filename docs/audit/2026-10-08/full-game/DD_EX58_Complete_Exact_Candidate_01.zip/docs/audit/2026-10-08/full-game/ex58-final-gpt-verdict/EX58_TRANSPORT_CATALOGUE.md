# All29 transport source rows — complete source-authoring profiles

All operational additions are NEW except explicitly retained source numbers. Original source records below remain unchanged. These are not approved exact candidate/bestiary cards.

| Source row | Category | Source price (cp) | New physical classification |
|---|---|---:|---|
| Camel | Mounts | 5000.0 | living-mount |
| Donkey or mule | Mounts | 800.0 | living-mount |
| Elephant | Mounts | 20000.0 | living-mount |
| Horse, draft | Mounts | 5000.0 | living-mount |
| Horse, riding | Mounts | 7500.0 | living-mount |
| Horse, war | Mounts | 40000.0 | living-mount |
| Mastiff | Mounts | 2500.0 | living-mount |
| Pony | Mounts | 3000.0 | living-mount |
| Warhound | Mounts | 5000.0 | living-mount |
| Barding | Tack, Harness, and Drawn Vehicles | None | fitted-armor |
| Bit and bridle | Tack, Harness, and Drawn Vehicles | 200.0 | tack-or-container |
| Carriage | Tack, Harness, and Drawn Vehicles | 10000.0 | drawn-vehicle |
| Cart | Tack, Harness, and Drawn Vehicles | 1500.0 | drawn-vehicle |
| Chariot | Tack, Harness, and Drawn Vehicles | 25000.0 | drawn-vehicle |
| Feed (per day) | Tack, Harness, and Drawn Vehicles | 5.0 | consumable-provision |
| Saddle, exotic | Tack, Harness, and Drawn Vehicles | 6000.0 | tack-or-container |
| Saddle, military | Tack, Harness, and Drawn Vehicles | 2000.0 | tack-or-container |
| Saddle, pack | Tack, Harness, and Drawn Vehicles | 500.0 | tack-or-container |
| Saddle, riding | Tack, Harness, and Drawn Vehicles | 1000.0 | tack-or-container |
| Saddlebags | Tack, Harness, and Drawn Vehicles | 400.0 | tack-or-container |
| Sled | Tack, Harness, and Drawn Vehicles | 2000.0 | drawn-vehicle |
| Stabling (per day) | Tack, Harness, and Drawn Vehicles | 50.0 | service |
| Wagon | Tack, Harness, and Drawn Vehicles | 3500.0 | drawn-vehicle |
| Galley | Waterborne Vehicles | 3000000.0 | watercraft |
| Keelboat | Waterborne Vehicles | 300000.0 | watercraft |
| Longship | Waterborne Vehicles | 1000000.0 | watercraft |
| Rowboat | Waterborne Vehicles | 5000.0 | watercraft |
| Sailing ship | Waterborne Vehicles | 1000000.0 | watercraft |
| Warship | Waterborne Vehicles | 2500000.0 | watercraft |

## mounts-vehicles-and-services.camel — Camel

**Preserved complete source record**

```json
{
  "id": "mounts-vehicles-and-services.camel",
  "name": "Camel",
  "category": "Mounts vehicles and services",
  "group": "Mounts",
  "status": "source-projection-only",
  "sourceLine": 7066,
  "sourceFields": {
    "Item": "Camel",
    "Cost": "50 gp",
    "Speed": "50 ft.",
    "Carrying Capacity": "480 lb."
  },
  "sourcePriceCp": 5000.0,
  "sourceWeightLb": null,
  "sourceWeightIncludesContents": false
}
```

**Complete operational body/service binding**

**provenance:** All size, mass, abilities, natural AC, HP/Hit Dice, senses, behavior, supply quantities, draw capability and reference level below are NEW provisional game values, not inferred anatomy/Strength or external bestiary statistics. Source purchase price, walking Speed and carry pounds alone are retained numbers.

**priceCp:** 5000

**size:** Large

**spaceFt:** 10

**baseBodyMassLb:** 900

### abilities

```json
{
  "STR": 15,
  "DEX": 10,
  "CON": 14,
  "INT": 2,
  "WIS": 11,
  "CHA": 5
}
```

**proficiencyBonus:** 2

**naturalAC:** 11

**naturalACIncludesDexterity:** true

**maximumHP:** 24

### hitDice

```json
{
  "count": 3,
  "die": 8,
  "restUse": "real remaining dice and ordinary creature rest/healing limits; fixed maximumHP is this NEW profile, not regenerated from a class table"
}
```

**saveProficiencies:** []

**skillProficiencies:** []

**saves:** ability modifier only unless an actual later source grants proficiency; current Wounds/conditions apply

**initiative:** DEX modifier plus actual lawful modifiers

**passivePerception:** 10

**senses:** ordinary sight, hearing and smell subject to actual light, line, distance/noise; no darkvision, blindsight, special detection or automatic advantage

**languages:** []

**trainedCuesAreFluency:** false

**immunities:** []

**resistances:** []

**innateSpells:** []

**classResources:** null

**walkingSpeedFt:** 50

**travelMphBeforePenalties:** 5.0

**carryPounds:** 480

**cargoLoadCapacity:** 48.0

**cargoLoadProvenance:** NEW explicit profile Load cap independent of Strength; not claimed source value

**burdenedAtLoadOrPounds:** positive supported load at least half the respective limit; one Burdened speed penalty, not two for the same state

**hardCarryAdmission:** must meet both pounds/Load and physical fit; no routine movement above either full cap

**riderSeats:** 1

**riderSizeRule:** at least one size smaller; saddle and actual body compatible; both personal gear and rider equipment count

**grossDrawLimitLb:** 800

**drawLimitProvenance:** NEW separate trained-harness capability on firm rolling surface or appropriate ice/snow runners; never a five-times Strength inference

**drawMovement:** minimum actual puller speed and vehicle cap; a gross draw above half the combined draw rating also causes the one Burdened speed penalty. Loads on a puller and towing constraints are separately checked; the same named penalty is not doubled. No slopes, broken axles or impassable terrain waived.

### attack

```json
{
  "name": "Kick",
  "activation": "Action on its own independent regular turn only; one attack",
  "attackBonus": 4,
  "reachFt": 5,
  "damageDice": "1d6",
  "damageModifier": 2,
  "damageType": "bludgeoning",
  "rider": "none",
  "critical": "Core natural20 doubles damage dice only; natural1 misses"
}
```

**otherActions:** independent actual creature may use physically compatible Core Actions; controlled ridden Action list is Dash, Disengage, Dodge only; no Multiattack or automatic opportunity attack while controlled

**deathRule:** NEW default registered Expedition mount is significant and uses ordinary Core Wounds/dying/death saves. Mark significance before an encounter; no retrospective designation to dodge death. A later actual Ranger Beast bond uses its expressly different HP-only/immediate-death lifecycle instead.

**training:** Actual ride/cargo/harness/armor training recorded separately under TR-02/07. Purchase name/price is not proof of present training, willingness or health. War-named template may be sold with documented combat habituation but gains no new controlled attack.

### dailyFeed

```json
{
  "sourceItemId": "mounts-vehicles-and-services.feed-per-day",
  "priceCp": 5,
  "feedMassLb": 12,
  "speciesCompatible": true,
  "meaning": "NEW one animal-day sold feed quantity for this template at the printed5cp daily reference. Actual species-compatible stock must be supplied; no fodder-to-meat conversion or infinite vendor stock."
}
```

**dailyWaterPints:** 32

**foodCare:** Use these NEW animal quantities instead of the human Small/Medium/Large Supply basket, with actual safe water and continued rest. Do not add human lamp oil demand to an animal. Unmet daily food/water gives at most1 ordinary expedition Strain for that day; no additional duplicate failure per missing component. No automatic desert-fasting trait.

**threatReferenceLevel:** 1

**threatReferenceProvenance:** NEW encounter-budget comparison only, not a CR, character class level, Ranger acquisition authorization or XP award

**sourceCR:** absent; retain absence, and any actual CR-gated ability needs its genuine source/profile predicate rather than treating referenceLevel as CR

**custody:** actual individual creature ID and original body history; Donkey or mule is one selected individual, not two. Purchase, hire, boarding, battle loss, rescue, bond and sale preserve that history.


## mounts-vehicles-and-services.donkey-or-mule — Donkey or mule

**Preserved complete source record**

```json
{
  "id": "mounts-vehicles-and-services.donkey-or-mule",
  "name": "Donkey or mule",
  "category": "Mounts vehicles and services",
  "group": "Mounts",
  "status": "source-projection-only",
  "sourceLine": 7067,
  "sourceFields": {
    "Item": "Donkey or mule",
    "Cost": "8 gp",
    "Speed": "40 ft.",
    "Carrying Capacity": "420 lb."
  },
  "sourcePriceCp": 800.0,
  "sourceWeightLb": null,
  "sourceWeightIncludesContents": false
}
```

**Complete operational body/service binding**

**provenance:** All size, mass, abilities, natural AC, HP/Hit Dice, senses, behavior, supply quantities, draw capability and reference level below are NEW provisional game values, not inferred anatomy/Strength or external bestiary statistics. Source purchase price, walking Speed and carry pounds alone are retained numbers.

**priceCp:** 800

**size:** Large

**spaceFt:** 10

**baseBodyMassLb:** 400

### abilities

```json
{
  "STR": 13,
  "DEX": 11,
  "CON": 13,
  "INT": 2,
  "WIS": 12,
  "CHA": 5
}
```

**proficiencyBonus:** 2

**naturalAC:** 11

**naturalACIncludesDexterity:** true

**maximumHP:** 20

### hitDice

```json
{
  "count": 3,
  "die": 8,
  "restUse": "real remaining dice and ordinary creature rest/healing limits; fixed maximumHP is this NEW profile, not regenerated from a class table"
}
```

**saveProficiencies:** []

**skillProficiencies:** []

**saves:** ability modifier only unless an actual later source grants proficiency; current Wounds/conditions apply

**initiative:** DEX modifier plus actual lawful modifiers

**passivePerception:** 11

**senses:** ordinary sight, hearing and smell subject to actual light, line, distance/noise; no darkvision, blindsight, special detection or automatic advantage

**languages:** []

**trainedCuesAreFluency:** false

**immunities:** []

**resistances:** []

**innateSpells:** []

**classResources:** null

**walkingSpeedFt:** 40

**travelMphBeforePenalties:** 4.0

**carryPounds:** 420

**cargoLoadCapacity:** 42.0

**cargoLoadProvenance:** NEW explicit profile Load cap independent of Strength; not claimed source value

**burdenedAtLoadOrPounds:** positive supported load at least half the respective limit; one Burdened speed penalty, not two for the same state

**hardCarryAdmission:** must meet both pounds/Load and physical fit; no routine movement above either full cap

**riderSeats:** 1

**riderSizeRule:** at least one size smaller; saddle and actual body compatible; both personal gear and rider equipment count

**grossDrawLimitLb:** 600

**drawLimitProvenance:** NEW separate trained-harness capability on firm rolling surface or appropriate ice/snow runners; never a five-times Strength inference

**drawMovement:** minimum actual puller speed and vehicle cap; a gross draw above half the combined draw rating also causes the one Burdened speed penalty. Loads on a puller and towing constraints are separately checked; the same named penalty is not doubled. No slopes, broken axles or impassable terrain waived.

### attack

```json
{
  "name": "Kick",
  "activation": "Action on its own independent regular turn only; one attack",
  "attackBonus": 3,
  "reachFt": 5,
  "damageDice": "1d4",
  "damageModifier": 1,
  "damageType": "bludgeoning",
  "rider": "none",
  "critical": "Core natural20 doubles damage dice only; natural1 misses"
}
```

**otherActions:** independent actual creature may use physically compatible Core Actions; controlled ridden Action list is Dash, Disengage, Dodge only; no Multiattack or automatic opportunity attack while controlled

**deathRule:** NEW default registered Expedition mount is significant and uses ordinary Core Wounds/dying/death saves. Mark significance before an encounter; no retrospective designation to dodge death. A later actual Ranger Beast bond uses its expressly different HP-only/immediate-death lifecycle instead.

**training:** Actual ride/cargo/harness/armor training recorded separately under TR-02/07. Purchase name/price is not proof of present training, willingness or health. War-named template may be sold with documented combat habituation but gains no new controlled attack.

### dailyFeed

```json
{
  "sourceItemId": "mounts-vehicles-and-services.feed-per-day",
  "priceCp": 5,
  "feedMassLb": 10,
  "speciesCompatible": true,
  "meaning": "NEW one animal-day sold feed quantity for this template at the printed5cp daily reference. Actual species-compatible stock must be supplied; no fodder-to-meat conversion or infinite vendor stock."
}
```

**dailyWaterPints:** 24

**foodCare:** Use these NEW animal quantities instead of the human Small/Medium/Large Supply basket, with actual safe water and continued rest. Do not add human lamp oil demand to an animal. Unmet daily food/water gives at most1 ordinary expedition Strain for that day; no additional duplicate failure per missing component. No automatic desert-fasting trait.

**threatReferenceLevel:** 1

**threatReferenceProvenance:** NEW encounter-budget comparison only, not a CR, character class level, Ranger acquisition authorization or XP award

**sourceCR:** absent; retain absence, and any actual CR-gated ability needs its genuine source/profile predicate rather than treating referenceLevel as CR

**custody:** actual individual creature ID and original body history; Donkey or mule is one selected individual, not two. Purchase, hire, boarding, battle loss, rescue, bond and sale preserve that history.


## mounts-vehicles-and-services.elephant — Elephant

**Preserved complete source record**

```json
{
  "id": "mounts-vehicles-and-services.elephant",
  "name": "Elephant",
  "category": "Mounts vehicles and services",
  "group": "Mounts",
  "status": "source-projection-only",
  "sourceLine": 7068,
  "sourceFields": {
    "Item": "Elephant",
    "Cost": "200 gp",
    "Speed": "40 ft.",
    "Carrying Capacity": "1,320 lb."
  },
  "sourcePriceCp": 20000.0,
  "sourceWeightLb": null,
  "sourceWeightIncludesContents": false
}
```

**Complete operational body/service binding**

**provenance:** All size, mass, abilities, natural AC, HP/Hit Dice, senses, behavior, supply quantities, draw capability and reference level below are NEW provisional game values, not inferred anatomy/Strength or external bestiary statistics. Source purchase price, walking Speed and carry pounds alone are retained numbers.

**priceCp:** 20000

**size:** Huge

**spaceFt:** 15

**baseBodyMassLb:** 5000

### abilities

```json
{
  "STR": 23,
  "DEX": 8,
  "CON": 18,
  "INT": 3,
  "WIS": 12,
  "CHA": 6
}
```

**proficiencyBonus:** 2

**naturalAC:** 13

**naturalACIncludesDexterity:** true

**maximumHP:** 80

### hitDice

```json
{
  "count": 8,
  "die": 8,
  "restUse": "real remaining dice and ordinary creature rest/healing limits; fixed maximumHP is this NEW profile, not regenerated from a class table"
}
```

**saveProficiencies:** []

**skillProficiencies:** []

**saves:** ability modifier only unless an actual later source grants proficiency; current Wounds/conditions apply

**initiative:** DEX modifier plus actual lawful modifiers

**passivePerception:** 11

**senses:** ordinary sight, hearing and smell subject to actual light, line, distance/noise; no darkvision, blindsight, special detection or automatic advantage

**languages:** []

**trainedCuesAreFluency:** false

**immunities:** []

**resistances:** []

**innateSpells:** []

**classResources:** null

**walkingSpeedFt:** 40

**travelMphBeforePenalties:** 4.0

**carryPounds:** 1320

**cargoLoadCapacity:** 132.0

**cargoLoadProvenance:** NEW explicit profile Load cap independent of Strength; not claimed source value

**burdenedAtLoadOrPounds:** positive supported load at least half the respective limit; one Burdened speed penalty, not two for the same state

**hardCarryAdmission:** must meet both pounds/Load and physical fit; no routine movement above either full cap

**riderSeats:** 1

**riderSizeRule:** at least one size smaller; saddle and actual body compatible; both personal gear and rider equipment count

**grossDrawLimitLb:** 4000

**drawLimitProvenance:** NEW separate trained-harness capability on firm rolling surface or appropriate ice/snow runners; never a five-times Strength inference

**drawMovement:** minimum actual puller speed and vehicle cap; a gross draw above half the combined draw rating also causes the one Burdened speed penalty. Loads on a puller and towing constraints are separately checked; the same named penalty is not doubled. No slopes, broken axles or impassable terrain waived.

### attack

```json
{
  "name": "Tusk",
  "activation": "Action on its own independent regular turn only; one attack",
  "attackBonus": 8,
  "reachFt": 10,
  "damageDice": "2d8",
  "damageModifier": 6,
  "damageType": "piercing",
  "rider": "none",
  "critical": "Core natural20 doubles damage dice only; natural1 misses"
}
```

**otherActions:** independent actual creature may use physically compatible Core Actions; controlled ridden Action list is Dash, Disengage, Dodge only; no Multiattack or automatic opportunity attack while controlled

**deathRule:** NEW default registered Expedition mount is significant and uses ordinary Core Wounds/dying/death saves. Mark significance before an encounter; no retrospective designation to dodge death. A later actual Ranger Beast bond uses its expressly different HP-only/immediate-death lifecycle instead.

**training:** Actual ride/cargo/harness/armor training recorded separately under TR-02/07. Purchase name/price is not proof of present training, willingness or health. War-named template may be sold with documented combat habituation but gains no new controlled attack.

### dailyFeed

```json
{
  "sourceItemId": "mounts-vehicles-and-services.feed-per-day",
  "priceCp": 5,
  "feedMassLb": 60,
  "speciesCompatible": true,
  "meaning": "NEW one animal-day sold feed quantity for this template at the printed5cp daily reference. Actual species-compatible stock must be supplied; no fodder-to-meat conversion or infinite vendor stock."
}
```

**dailyWaterPints:** 128

**foodCare:** Use these NEW animal quantities instead of the human Small/Medium/Large Supply basket, with actual safe water and continued rest. Do not add human lamp oil demand to an animal. Unmet daily food/water gives at most1 ordinary expedition Strain for that day; no additional duplicate failure per missing component. No automatic desert-fasting trait.

**threatReferenceLevel:** 4

**threatReferenceProvenance:** NEW encounter-budget comparison only, not a CR, character class level, Ranger acquisition authorization or XP award

**sourceCR:** absent; retain absence, and any actual CR-gated ability needs its genuine source/profile predicate rather than treating referenceLevel as CR

**custody:** actual individual creature ID and original body history; Donkey or mule is one selected individual, not two. Purchase, hire, boarding, battle loss, rescue, bond and sale preserve that history.


## mounts-vehicles-and-services.horse-draft — Horse, draft

**Preserved complete source record**

```json
{
  "id": "mounts-vehicles-and-services.horse-draft",
  "name": "Horse, draft",
  "category": "Mounts vehicles and services",
  "group": "Mounts",
  "status": "source-projection-only",
  "sourceLine": 7069,
  "sourceFields": {
    "Item": "Horse, draft",
    "Cost": "50 gp",
    "Speed": "40 ft.",
    "Carrying Capacity": "540 lb."
  },
  "sourcePriceCp": 5000.0,
  "sourceWeightLb": null,
  "sourceWeightIncludesContents": false
}
```

**Complete operational body/service binding**

**provenance:** All size, mass, abilities, natural AC, HP/Hit Dice, senses, behavior, supply quantities, draw capability and reference level below are NEW provisional game values, not inferred anatomy/Strength or external bestiary statistics. Source purchase price, walking Speed and carry pounds alone are retained numbers.

**priceCp:** 5000

**size:** Large

**spaceFt:** 10

**baseBodyMassLb:** 1200

### abilities

```json
{
  "STR": 17,
  "DEX": 10,
  "CON": 15,
  "INT": 2,
  "WIS": 11,
  "CHA": 5
}
```

**proficiencyBonus:** 2

**naturalAC:** 11

**naturalACIncludesDexterity:** true

**maximumHP:** 32

### hitDice

```json
{
  "count": 4,
  "die": 8,
  "restUse": "real remaining dice and ordinary creature rest/healing limits; fixed maximumHP is this NEW profile, not regenerated from a class table"
}
```

**saveProficiencies:** []

**skillProficiencies:** []

**saves:** ability modifier only unless an actual later source grants proficiency; current Wounds/conditions apply

**initiative:** DEX modifier plus actual lawful modifiers

**passivePerception:** 10

**senses:** ordinary sight, hearing and smell subject to actual light, line, distance/noise; no darkvision, blindsight, special detection or automatic advantage

**languages:** []

**trainedCuesAreFluency:** false

**immunities:** []

**resistances:** []

**innateSpells:** []

**classResources:** null

**walkingSpeedFt:** 40

**travelMphBeforePenalties:** 4.0

**carryPounds:** 540

**cargoLoadCapacity:** 54.0

**cargoLoadProvenance:** NEW explicit profile Load cap independent of Strength; not claimed source value

**burdenedAtLoadOrPounds:** positive supported load at least half the respective limit; one Burdened speed penalty, not two for the same state

**hardCarryAdmission:** must meet both pounds/Load and physical fit; no routine movement above either full cap

**riderSeats:** 1

**riderSizeRule:** at least one size smaller; saddle and actual body compatible; both personal gear and rider equipment count

**grossDrawLimitLb:** 1200

**drawLimitProvenance:** NEW separate trained-harness capability on firm rolling surface or appropriate ice/snow runners; never a five-times Strength inference

**drawMovement:** minimum actual puller speed and vehicle cap; a gross draw above half the combined draw rating also causes the one Burdened speed penalty. Loads on a puller and towing constraints are separately checked; the same named penalty is not doubled. No slopes, broken axles or impassable terrain waived.

### attack

```json
{
  "name": "Kick",
  "activation": "Action on its own independent regular turn only; one attack",
  "attackBonus": 5,
  "reachFt": 5,
  "damageDice": "1d6",
  "damageModifier": 3,
  "damageType": "bludgeoning",
  "rider": "none",
  "critical": "Core natural20 doubles damage dice only; natural1 misses"
}
```

**otherActions:** independent actual creature may use physically compatible Core Actions; controlled ridden Action list is Dash, Disengage, Dodge only; no Multiattack or automatic opportunity attack while controlled

**deathRule:** NEW default registered Expedition mount is significant and uses ordinary Core Wounds/dying/death saves. Mark significance before an encounter; no retrospective designation to dodge death. A later actual Ranger Beast bond uses its expressly different HP-only/immediate-death lifecycle instead.

**training:** Actual ride/cargo/harness/armor training recorded separately under TR-02/07. Purchase name/price is not proof of present training, willingness or health. War-named template may be sold with documented combat habituation but gains no new controlled attack.

### dailyFeed

```json
{
  "sourceItemId": "mounts-vehicles-and-services.feed-per-day",
  "priceCp": 5,
  "feedMassLb": 16,
  "speciesCompatible": true,
  "meaning": "NEW one animal-day sold feed quantity for this template at the printed5cp daily reference. Actual species-compatible stock must be supplied; no fodder-to-meat conversion or infinite vendor stock."
}
```

**dailyWaterPints:** 40

**foodCare:** Use these NEW animal quantities instead of the human Small/Medium/Large Supply basket, with actual safe water and continued rest. Do not add human lamp oil demand to an animal. Unmet daily food/water gives at most1 ordinary expedition Strain for that day; no additional duplicate failure per missing component. No automatic desert-fasting trait.

**threatReferenceLevel:** 2

**threatReferenceProvenance:** NEW encounter-budget comparison only, not a CR, character class level, Ranger acquisition authorization or XP award

**sourceCR:** absent; retain absence, and any actual CR-gated ability needs its genuine source/profile predicate rather than treating referenceLevel as CR

**custody:** actual individual creature ID and original body history; Donkey or mule is one selected individual, not two. Purchase, hire, boarding, battle loss, rescue, bond and sale preserve that history.


## mounts-vehicles-and-services.horse-riding — Horse, riding

**Preserved complete source record**

```json
{
  "id": "mounts-vehicles-and-services.horse-riding",
  "name": "Horse, riding",
  "category": "Mounts vehicles and services",
  "group": "Mounts",
  "status": "source-projection-only",
  "sourceLine": 7070,
  "sourceFields": {
    "Item": "Horse, riding",
    "Cost": "75 gp",
    "Speed": "60 ft.",
    "Carrying Capacity": "480 lb."
  },
  "sourcePriceCp": 7500.0,
  "sourceWeightLb": null,
  "sourceWeightIncludesContents": false
}
```

**Complete operational body/service binding**

**provenance:** All size, mass, abilities, natural AC, HP/Hit Dice, senses, behavior, supply quantities, draw capability and reference level below are NEW provisional game values, not inferred anatomy/Strength or external bestiary statistics. Source purchase price, walking Speed and carry pounds alone are retained numbers.

**priceCp:** 7500

**size:** Large

**spaceFt:** 10

**baseBodyMassLb:** 1000

### abilities

```json
{
  "STR": 14,
  "DEX": 13,
  "CON": 13,
  "INT": 2,
  "WIS": 12,
  "CHA": 6
}
```

**proficiencyBonus:** 2

**naturalAC:** 12

**naturalACIncludesDexterity:** true

**maximumHP:** 24

### hitDice

```json
{
  "count": 3,
  "die": 8,
  "restUse": "real remaining dice and ordinary creature rest/healing limits; fixed maximumHP is this NEW profile, not regenerated from a class table"
}
```

**saveProficiencies:** []

**skillProficiencies:** []

**saves:** ability modifier only unless an actual later source grants proficiency; current Wounds/conditions apply

**initiative:** DEX modifier plus actual lawful modifiers

**passivePerception:** 11

**senses:** ordinary sight, hearing and smell subject to actual light, line, distance/noise; no darkvision, blindsight, special detection or automatic advantage

**languages:** []

**trainedCuesAreFluency:** false

**immunities:** []

**resistances:** []

**innateSpells:** []

**classResources:** null

**walkingSpeedFt:** 60

**travelMphBeforePenalties:** 6.0

**carryPounds:** 480

**cargoLoadCapacity:** 48.0

**cargoLoadProvenance:** NEW explicit profile Load cap independent of Strength; not claimed source value

**burdenedAtLoadOrPounds:** positive supported load at least half the respective limit; one Burdened speed penalty, not two for the same state

**hardCarryAdmission:** must meet both pounds/Load and physical fit; no routine movement above either full cap

**riderSeats:** 1

**riderSizeRule:** at least one size smaller; saddle and actual body compatible; both personal gear and rider equipment count

**grossDrawLimitLb:** 800

**drawLimitProvenance:** NEW separate trained-harness capability on firm rolling surface or appropriate ice/snow runners; never a five-times Strength inference

**drawMovement:** minimum actual puller speed and vehicle cap; a gross draw above half the combined draw rating also causes the one Burdened speed penalty. Loads on a puller and towing constraints are separately checked; the same named penalty is not doubled. No slopes, broken axles or impassable terrain waived.

### attack

```json
{
  "name": "Kick",
  "activation": "Action on its own independent regular turn only; one attack",
  "attackBonus": 4,
  "reachFt": 5,
  "damageDice": "1d6",
  "damageModifier": 2,
  "damageType": "bludgeoning",
  "rider": "none",
  "critical": "Core natural20 doubles damage dice only; natural1 misses"
}
```

**otherActions:** independent actual creature may use physically compatible Core Actions; controlled ridden Action list is Dash, Disengage, Dodge only; no Multiattack or automatic opportunity attack while controlled

**deathRule:** NEW default registered Expedition mount is significant and uses ordinary Core Wounds/dying/death saves. Mark significance before an encounter; no retrospective designation to dodge death. A later actual Ranger Beast bond uses its expressly different HP-only/immediate-death lifecycle instead.

**training:** Actual ride/cargo/harness/armor training recorded separately under TR-02/07. Purchase name/price is not proof of present training, willingness or health. War-named template may be sold with documented combat habituation but gains no new controlled attack.

### dailyFeed

```json
{
  "sourceItemId": "mounts-vehicles-and-services.feed-per-day",
  "priceCp": 5,
  "feedMassLb": 12,
  "speciesCompatible": true,
  "meaning": "NEW one animal-day sold feed quantity for this template at the printed5cp daily reference. Actual species-compatible stock must be supplied; no fodder-to-meat conversion or infinite vendor stock."
}
```

**dailyWaterPints:** 32

**foodCare:** Use these NEW animal quantities instead of the human Small/Medium/Large Supply basket, with actual safe water and continued rest. Do not add human lamp oil demand to an animal. Unmet daily food/water gives at most1 ordinary expedition Strain for that day; no additional duplicate failure per missing component. No automatic desert-fasting trait.

**threatReferenceLevel:** 1

**threatReferenceProvenance:** NEW encounter-budget comparison only, not a CR, character class level, Ranger acquisition authorization or XP award

**sourceCR:** absent; retain absence, and any actual CR-gated ability needs its genuine source/profile predicate rather than treating referenceLevel as CR

**custody:** actual individual creature ID and original body history; Donkey or mule is one selected individual, not two. Purchase, hire, boarding, battle loss, rescue, bond and sale preserve that history.


## mounts-vehicles-and-services.horse-war — Horse, war

**Preserved complete source record**

```json
{
  "id": "mounts-vehicles-and-services.horse-war",
  "name": "Horse, war",
  "category": "Mounts vehicles and services",
  "group": "Mounts",
  "status": "source-projection-only",
  "sourceLine": 7071,
  "sourceFields": {
    "Item": "Horse, war",
    "Cost": "400 gp",
    "Speed": "60 ft.",
    "Carrying Capacity": "540 lb."
  },
  "sourcePriceCp": 40000.0,
  "sourceWeightLb": null,
  "sourceWeightIncludesContents": false
}
```

**Complete operational body/service binding**

**provenance:** All size, mass, abilities, natural AC, HP/Hit Dice, senses, behavior, supply quantities, draw capability and reference level below are NEW provisional game values, not inferred anatomy/Strength or external bestiary statistics. Source purchase price, walking Speed and carry pounds alone are retained numbers.

**priceCp:** 40000

**size:** Large

**spaceFt:** 10

**baseBodyMassLb:** 1100

### abilities

```json
{
  "STR": 18,
  "DEX": 12,
  "CON": 16,
  "INT": 2,
  "WIS": 12,
  "CHA": 7
}
```

**proficiencyBonus:** 2

**naturalAC:** 13

**naturalACIncludesDexterity:** true

**maximumHP:** 40

### hitDice

```json
{
  "count": 5,
  "die": 8,
  "restUse": "real remaining dice and ordinary creature rest/healing limits; fixed maximumHP is this NEW profile, not regenerated from a class table"
}
```

**saveProficiencies:** []

**skillProficiencies:** []

**saves:** ability modifier only unless an actual later source grants proficiency; current Wounds/conditions apply

**initiative:** DEX modifier plus actual lawful modifiers

**passivePerception:** 11

**senses:** ordinary sight, hearing and smell subject to actual light, line, distance/noise; no darkvision, blindsight, special detection or automatic advantage

**languages:** []

**trainedCuesAreFluency:** false

**immunities:** []

**resistances:** []

**innateSpells:** []

**classResources:** null

**walkingSpeedFt:** 60

**travelMphBeforePenalties:** 6.0

**carryPounds:** 540

**cargoLoadCapacity:** 54.0

**cargoLoadProvenance:** NEW explicit profile Load cap independent of Strength; not claimed source value

**burdenedAtLoadOrPounds:** positive supported load at least half the respective limit; one Burdened speed penalty, not two for the same state

**hardCarryAdmission:** must meet both pounds/Load and physical fit; no routine movement above either full cap

**riderSeats:** 1

**riderSizeRule:** at least one size smaller; saddle and actual body compatible; both personal gear and rider equipment count

**grossDrawLimitLb:** 1200

**drawLimitProvenance:** NEW separate trained-harness capability on firm rolling surface or appropriate ice/snow runners; never a five-times Strength inference

**drawMovement:** minimum actual puller speed and vehicle cap; a gross draw above half the combined draw rating also causes the one Burdened speed penalty. Loads on a puller and towing constraints are separately checked; the same named penalty is not doubled. No slopes, broken axles or impassable terrain waived.

### attack

```json
{
  "name": "Kick",
  "activation": "Action on its own independent regular turn only; one attack",
  "attackBonus": 6,
  "reachFt": 5,
  "damageDice": "1d8",
  "damageModifier": 4,
  "damageType": "bludgeoning",
  "rider": "none",
  "critical": "Core natural20 doubles damage dice only; natural1 misses"
}
```

**otherActions:** independent actual creature may use physically compatible Core Actions; controlled ridden Action list is Dash, Disengage, Dodge only; no Multiattack or automatic opportunity attack while controlled

**deathRule:** NEW default registered Expedition mount is significant and uses ordinary Core Wounds/dying/death saves. Mark significance before an encounter; no retrospective designation to dodge death. A later actual Ranger Beast bond uses its expressly different HP-only/immediate-death lifecycle instead.

**training:** Actual ride/cargo/harness/armor training recorded separately under TR-02/07. Purchase name/price is not proof of present training, willingness or health. War-named template may be sold with documented combat habituation but gains no new controlled attack.

### dailyFeed

```json
{
  "sourceItemId": "mounts-vehicles-and-services.feed-per-day",
  "priceCp": 5,
  "feedMassLb": 16,
  "speciesCompatible": true,
  "meaning": "NEW one animal-day sold feed quantity for this template at the printed5cp daily reference. Actual species-compatible stock must be supplied; no fodder-to-meat conversion or infinite vendor stock."
}
```

**dailyWaterPints:** 40

**foodCare:** Use these NEW animal quantities instead of the human Small/Medium/Large Supply basket, with actual safe water and continued rest. Do not add human lamp oil demand to an animal. Unmet daily food/water gives at most1 ordinary expedition Strain for that day; no additional duplicate failure per missing component. No automatic desert-fasting trait.

**threatReferenceLevel:** 2

**threatReferenceProvenance:** NEW encounter-budget comparison only, not a CR, character class level, Ranger acquisition authorization or XP award

**sourceCR:** absent; retain absence, and any actual CR-gated ability needs its genuine source/profile predicate rather than treating referenceLevel as CR

**custody:** actual individual creature ID and original body history; Donkey or mule is one selected individual, not two. Purchase, hire, boarding, battle loss, rescue, bond and sale preserve that history.


## mounts-vehicles-and-services.mastiff — Mastiff

**Preserved complete source record**

```json
{
  "id": "mounts-vehicles-and-services.mastiff",
  "name": "Mastiff",
  "category": "Mounts vehicles and services",
  "group": "Mounts",
  "status": "source-projection-only",
  "sourceLine": 7072,
  "sourceFields": {
    "Item": "Mastiff",
    "Cost": "25 gp",
    "Speed": "40 ft.",
    "Carrying Capacity": "195 lb."
  },
  "sourcePriceCp": 2500.0,
  "sourceWeightLb": null,
  "sourceWeightIncludesContents": false
}
```

**Complete operational body/service binding**

**provenance:** All size, mass, abilities, natural AC, HP/Hit Dice, senses, behavior, supply quantities, draw capability and reference level below are NEW provisional game values, not inferred anatomy/Strength or external bestiary statistics. Source purchase price, walking Speed and carry pounds alone are retained numbers.

**priceCp:** 2500

**size:** Medium

**spaceFt:** 5

**baseBodyMassLb:** 90

### abilities

```json
{
  "STR": 11,
  "DEX": 13,
  "CON": 12,
  "INT": 3,
  "WIS": 13,
  "CHA": 7
}
```

**proficiencyBonus:** 2

**naturalAC:** 12

**naturalACIncludesDexterity:** true

**maximumHP:** 12

### hitDice

```json
{
  "count": 2,
  "die": 8,
  "restUse": "real remaining dice and ordinary creature rest/healing limits; fixed maximumHP is this NEW profile, not regenerated from a class table"
}
```

**saveProficiencies:** []

**skillProficiencies:** []

**saves:** ability modifier only unless an actual later source grants proficiency; current Wounds/conditions apply

**initiative:** DEX modifier plus actual lawful modifiers

**passivePerception:** 11

**senses:** ordinary sight, hearing and smell subject to actual light, line, distance/noise; no darkvision, blindsight, special detection or automatic advantage

**languages:** []

**trainedCuesAreFluency:** false

**immunities:** []

**resistances:** []

**innateSpells:** []

**classResources:** null

**walkingSpeedFt:** 40

**travelMphBeforePenalties:** 4.0

**carryPounds:** 195

**cargoLoadCapacity:** 19.5

**cargoLoadProvenance:** NEW explicit profile Load cap independent of Strength; not claimed source value

**burdenedAtLoadOrPounds:** positive supported load at least half the respective limit; one Burdened speed penalty, not two for the same state

**hardCarryAdmission:** must meet both pounds/Load and physical fit; no routine movement above either full cap

**riderSeats:** 1

**riderSizeRule:** at least one size smaller; saddle and actual body compatible; both personal gear and rider equipment count

**grossDrawLimitLb:** 180

**drawLimitProvenance:** NEW separate trained-harness capability on firm rolling surface or appropriate ice/snow runners; never a five-times Strength inference

**drawMovement:** minimum actual puller speed and vehicle cap; a gross draw above half the combined draw rating also causes the one Burdened speed penalty. Loads on a puller and towing constraints are separately checked; the same named penalty is not doubled. No slopes, broken axles or impassable terrain waived.

### attack

```json
{
  "name": "Bite",
  "activation": "Action on its own independent regular turn only; one attack",
  "attackBonus": 2,
  "reachFt": 5,
  "damageDice": "1d4",
  "damageModifier": 0,
  "damageType": "piercing",
  "rider": "none",
  "critical": "Core natural20 doubles damage dice only; natural1 misses"
}
```

**otherActions:** independent actual creature may use physically compatible Core Actions; controlled ridden Action list is Dash, Disengage, Dodge only; no Multiattack or automatic opportunity attack while controlled

**deathRule:** NEW default registered Expedition mount is significant and uses ordinary Core Wounds/dying/death saves. Mark significance before an encounter; no retrospective designation to dodge death. A later actual Ranger Beast bond uses its expressly different HP-only/immediate-death lifecycle instead.

**training:** Actual ride/cargo/harness/armor training recorded separately under TR-02/07. Purchase name/price is not proof of present training, willingness or health. War-named template may be sold with documented combat habituation but gains no new controlled attack.

### dailyFeed

```json
{
  "sourceItemId": "mounts-vehicles-and-services.feed-per-day",
  "priceCp": 5,
  "feedMassLb": 2,
  "speciesCompatible": true,
  "meaning": "NEW one animal-day sold feed quantity for this template at the printed5cp daily reference. Actual species-compatible stock must be supplied; no fodder-to-meat conversion or infinite vendor stock."
}
```

**dailyWaterPints:** 8

**foodCare:** Use these NEW animal quantities instead of the human Small/Medium/Large Supply basket, with actual safe water and continued rest. Do not add human lamp oil demand to an animal. Unmet daily food/water gives at most1 ordinary expedition Strain for that day; no additional duplicate failure per missing component. No automatic desert-fasting trait.

**threatReferenceLevel:** 1

**threatReferenceProvenance:** NEW encounter-budget comparison only, not a CR, character class level, Ranger acquisition authorization or XP award

**sourceCR:** absent; retain absence, and any actual CR-gated ability needs its genuine source/profile predicate rather than treating referenceLevel as CR

**custody:** actual individual creature ID and original body history; Donkey or mule is one selected individual, not two. Purchase, hire, boarding, battle loss, rescue, bond and sale preserve that history.


## mounts-vehicles-and-services.pony — Pony

**Preserved complete source record**

```json
{
  "id": "mounts-vehicles-and-services.pony",
  "name": "Pony",
  "category": "Mounts vehicles and services",
  "group": "Mounts",
  "status": "source-projection-only",
  "sourceLine": 7073,
  "sourceFields": {
    "Item": "Pony",
    "Cost": "30 gp",
    "Speed": "40 ft.",
    "Carrying Capacity": "225 lb."
  },
  "sourcePriceCp": 3000.0,
  "sourceWeightLb": null,
  "sourceWeightIncludesContents": false
}
```

**Complete operational body/service binding**

**provenance:** All size, mass, abilities, natural AC, HP/Hit Dice, senses, behavior, supply quantities, draw capability and reference level below are NEW provisional game values, not inferred anatomy/Strength or external bestiary statistics. Source purchase price, walking Speed and carry pounds alone are retained numbers.

**priceCp:** 3000

**size:** Medium

**spaceFt:** 5

**baseBodyMassLb:** 400

### abilities

```json
{
  "STR": 12,
  "DEX": 12,
  "CON": 12,
  "INT": 2,
  "WIS": 11,
  "CHA": 6
}
```

**proficiencyBonus:** 2

**naturalAC:** 11

**naturalACIncludesDexterity:** true

**maximumHP:** 16

### hitDice

```json
{
  "count": 2,
  "die": 8,
  "restUse": "real remaining dice and ordinary creature rest/healing limits; fixed maximumHP is this NEW profile, not regenerated from a class table"
}
```

**saveProficiencies:** []

**skillProficiencies:** []

**saves:** ability modifier only unless an actual later source grants proficiency; current Wounds/conditions apply

**initiative:** DEX modifier plus actual lawful modifiers

**passivePerception:** 10

**senses:** ordinary sight, hearing and smell subject to actual light, line, distance/noise; no darkvision, blindsight, special detection or automatic advantage

**languages:** []

**trainedCuesAreFluency:** false

**immunities:** []

**resistances:** []

**innateSpells:** []

**classResources:** null

**walkingSpeedFt:** 40

**travelMphBeforePenalties:** 4.0

**carryPounds:** 225

**cargoLoadCapacity:** 22.5

**cargoLoadProvenance:** NEW explicit profile Load cap independent of Strength; not claimed source value

**burdenedAtLoadOrPounds:** positive supported load at least half the respective limit; one Burdened speed penalty, not two for the same state

**hardCarryAdmission:** must meet both pounds/Load and physical fit; no routine movement above either full cap

**riderSeats:** 1

**riderSizeRule:** at least one size smaller; saddle and actual body compatible; both personal gear and rider equipment count

**grossDrawLimitLb:** 500

**drawLimitProvenance:** NEW separate trained-harness capability on firm rolling surface or appropriate ice/snow runners; never a five-times Strength inference

**drawMovement:** minimum actual puller speed and vehicle cap; a gross draw above half the combined draw rating also causes the one Burdened speed penalty. Loads on a puller and towing constraints are separately checked; the same named penalty is not doubled. No slopes, broken axles or impassable terrain waived.

### attack

```json
{
  "name": "Kick",
  "activation": "Action on its own independent regular turn only; one attack",
  "attackBonus": 3,
  "reachFt": 5,
  "damageDice": "1d4",
  "damageModifier": 1,
  "damageType": "bludgeoning",
  "rider": "none",
  "critical": "Core natural20 doubles damage dice only; natural1 misses"
}
```

**otherActions:** independent actual creature may use physically compatible Core Actions; controlled ridden Action list is Dash, Disengage, Dodge only; no Multiattack or automatic opportunity attack while controlled

**deathRule:** NEW default registered Expedition mount is significant and uses ordinary Core Wounds/dying/death saves. Mark significance before an encounter; no retrospective designation to dodge death. A later actual Ranger Beast bond uses its expressly different HP-only/immediate-death lifecycle instead.

**training:** Actual ride/cargo/harness/armor training recorded separately under TR-02/07. Purchase name/price is not proof of present training, willingness or health. War-named template may be sold with documented combat habituation but gains no new controlled attack.

### dailyFeed

```json
{
  "sourceItemId": "mounts-vehicles-and-services.feed-per-day",
  "priceCp": 5,
  "feedMassLb": 8,
  "speciesCompatible": true,
  "meaning": "NEW one animal-day sold feed quantity for this template at the printed5cp daily reference. Actual species-compatible stock must be supplied; no fodder-to-meat conversion or infinite vendor stock."
}
```

**dailyWaterPints:** 16

**foodCare:** Use these NEW animal quantities instead of the human Small/Medium/Large Supply basket, with actual safe water and continued rest. Do not add human lamp oil demand to an animal. Unmet daily food/water gives at most1 ordinary expedition Strain for that day; no additional duplicate failure per missing component. No automatic desert-fasting trait.

**threatReferenceLevel:** 1

**threatReferenceProvenance:** NEW encounter-budget comparison only, not a CR, character class level, Ranger acquisition authorization or XP award

**sourceCR:** absent; retain absence, and any actual CR-gated ability needs its genuine source/profile predicate rather than treating referenceLevel as CR

**custody:** actual individual creature ID and original body history; Donkey or mule is one selected individual, not two. Purchase, hire, boarding, battle loss, rescue, bond and sale preserve that history.


## mounts-vehicles-and-services.warhound — Warhound

**Preserved complete source record**

```json
{
  "id": "mounts-vehicles-and-services.warhound",
  "name": "Warhound",
  "category": "Mounts vehicles and services",
  "group": "Mounts",
  "status": "source-projection-only",
  "sourceLine": 7074,
  "sourceFields": {
    "Item": "Warhound",
    "Cost": "50 gp",
    "Speed": "50 ft.",
    "Carrying Capacity": "250 lb."
  },
  "sourcePriceCp": 5000.0,
  "sourceWeightLb": null,
  "sourceWeightIncludesContents": false
}
```

**Complete operational body/service binding**

**provenance:** All size, mass, abilities, natural AC, HP/Hit Dice, senses, behavior, supply quantities, draw capability and reference level below are NEW provisional game values, not inferred anatomy/Strength or external bestiary statistics. Source purchase price, walking Speed and carry pounds alone are retained numbers.

**priceCp:** 5000

**size:** Medium

**spaceFt:** 5

**baseBodyMassLb:** 140

### abilities

```json
{
  "STR": 15,
  "DEX": 14,
  "CON": 14,
  "INT": 3,
  "WIS": 13,
  "CHA": 7
}
```

**proficiencyBonus:** 2

**naturalAC:** 13

**naturalACIncludesDexterity:** true

**maximumHP:** 24

### hitDice

```json
{
  "count": 3,
  "die": 8,
  "restUse": "real remaining dice and ordinary creature rest/healing limits; fixed maximumHP is this NEW profile, not regenerated from a class table"
}
```

**saveProficiencies:** []

**skillProficiencies:** []

**saves:** ability modifier only unless an actual later source grants proficiency; current Wounds/conditions apply

**initiative:** DEX modifier plus actual lawful modifiers

**passivePerception:** 11

**senses:** ordinary sight, hearing and smell subject to actual light, line, distance/noise; no darkvision, blindsight, special detection or automatic advantage

**languages:** []

**trainedCuesAreFluency:** false

**immunities:** []

**resistances:** []

**innateSpells:** []

**classResources:** null

**walkingSpeedFt:** 50

**travelMphBeforePenalties:** 5.0

**carryPounds:** 250

**cargoLoadCapacity:** 25.0

**cargoLoadProvenance:** NEW explicit profile Load cap independent of Strength; not claimed source value

**burdenedAtLoadOrPounds:** positive supported load at least half the respective limit; one Burdened speed penalty, not two for the same state

**hardCarryAdmission:** must meet both pounds/Load and physical fit; no routine movement above either full cap

**riderSeats:** 1

**riderSizeRule:** at least one size smaller; saddle and actual body compatible; both personal gear and rider equipment count

**grossDrawLimitLb:** 250

**drawLimitProvenance:** NEW separate trained-harness capability on firm rolling surface or appropriate ice/snow runners; never a five-times Strength inference

**drawMovement:** minimum actual puller speed and vehicle cap; a gross draw above half the combined draw rating also causes the one Burdened speed penalty. Loads on a puller and towing constraints are separately checked; the same named penalty is not doubled. No slopes, broken axles or impassable terrain waived.

### attack

```json
{
  "name": "Bite",
  "activation": "Action on its own independent regular turn only; one attack",
  "attackBonus": 4,
  "reachFt": 5,
  "damageDice": "1d6",
  "damageModifier": 2,
  "damageType": "piercing",
  "rider": "none",
  "critical": "Core natural20 doubles damage dice only; natural1 misses"
}
```

**otherActions:** independent actual creature may use physically compatible Core Actions; controlled ridden Action list is Dash, Disengage, Dodge only; no Multiattack or automatic opportunity attack while controlled

**deathRule:** NEW default registered Expedition mount is significant and uses ordinary Core Wounds/dying/death saves. Mark significance before an encounter; no retrospective designation to dodge death. A later actual Ranger Beast bond uses its expressly different HP-only/immediate-death lifecycle instead.

**training:** Actual ride/cargo/harness/armor training recorded separately under TR-02/07. Purchase name/price is not proof of present training, willingness or health. War-named template may be sold with documented combat habituation but gains no new controlled attack.

### dailyFeed

```json
{
  "sourceItemId": "mounts-vehicles-and-services.feed-per-day",
  "priceCp": 5,
  "feedMassLb": 3,
  "speciesCompatible": true,
  "meaning": "NEW one animal-day sold feed quantity for this template at the printed5cp daily reference. Actual species-compatible stock must be supplied; no fodder-to-meat conversion or infinite vendor stock."
}
```

**dailyWaterPints:** 12

**foodCare:** Use these NEW animal quantities instead of the human Small/Medium/Large Supply basket, with actual safe water and continued rest. Do not add human lamp oil demand to an animal. Unmet daily food/water gives at most1 ordinary expedition Strain for that day; no additional duplicate failure per missing component. No automatic desert-fasting trait.

**threatReferenceLevel:** 2

**threatReferenceProvenance:** NEW encounter-budget comparison only, not a CR, character class level, Ranger acquisition authorization or XP award

**sourceCR:** absent; retain absence, and any actual CR-gated ability needs its genuine source/profile predicate rather than treating referenceLevel as CR

**custody:** actual individual creature ID and original body history; Donkey or mule is one selected individual, not two. Purchase, hire, boarding, battle loss, rescue, bond and sale preserve that history.


## mounts-vehicles-and-services.barding — Barding

**Preserved complete source record**

```json
{
  "id": "mounts-vehicles-and-services.barding",
  "name": "Barding",
  "category": "Mounts vehicles and services",
  "group": "Tack, Harness, and Drawn Vehicles",
  "status": "source-projection-only",
  "sourceLine": 7076,
  "sourceFields": {
    "Item": "Barding",
    "Cost": "×4",
    "Speed": ",",
    "Carrying Capacity": ","
  },
  "sourcePriceCp": null,
  "sourceWeightLb": null,
  "sourceWeightIncludesContents": false
}
```

**Complete operational body/service binding**

**provenance:** Printed cost multiplier×4 retained; all body sizing/weight rules below explicitly NEW beside null sourceWeight. Bind one actual reviewed ordinary armor model, not an undefined armor bonus.

**priceRule:** 4× the selected Standard ordinary armor baseline price; this exact barding rule replaces, not multiplies again by, the general Large price multiplier. A genuine separately sourced grade/fit contract must identify its own rule, never be inferred.

**massRule:** NEW actual selected baseline armor mass×2 Medium,×4 Large,×8 Huge. Smaller sizes need their own actual fitted model, not a placeholder. The source weight remains null.

**maximumHPRule:** reviewed base armorHP×1 Medium,×2 Large,×4 Huge (Huge NEW); actual existing workmanship/grade rules apply once

**armorRule:** actual selected armor AC formula, Dex cap, STR requirement, Stealth penalty and other printed properties; choose among eligible AC formulas under equipment rules, never add its AC to naturalAC

**wearerTraining:** TR-07 animal armor-category habituation grants only ordinary fitted wearing competence for that category; not a humanoid/class proficiency or new armor source

**equipping:** actual armor don/doff time from that reviewed model, with one capable helper occupied; no instant barding or resized armor on transformation

**capacity:** actual mass counts on mount; no cargo space or extra carry rating

**repair:** actual sized barding-body value and generic armor rule; not the whole animal price/HP

**primaryConstituents:** actual armor main body and creation history, not an invented virtual rating


## mounts-vehicles-and-services.bit-and-bridle — Bit and bridle

**Preserved complete source record**

```json
{
  "id": "mounts-vehicles-and-services.bit-and-bridle",
  "name": "Bit and bridle",
  "category": "Mounts vehicles and services",
  "group": "Tack, Harness, and Drawn Vehicles",
  "status": "source-projection-only",
  "sourceLine": 7077,
  "sourceFields": {
    "Item": "Bit and bridle",
    "Cost": "2 gp",
    "Speed": ",",
    "Carrying Capacity": ","
  },
  "sourcePriceCp": 200.0,
  "sourceWeightLb": null,
  "sourceWeightIncludesContents": false
}
```

**Complete operational body/service binding**

**provenance:** Price retained; mass, geometry,HP and ordinary functional details NEW. No source comma/null rewritten.

**priceCp:** 200

**emptyMassLb:** 2

**maximumHP:** 5

**structuralAC:** 15

### packedEnvelopeInches

```json
[
  12,
  8,
  4
]
```

**ordinaryUse:** Fitted head-control tack and reins; actual trained willing animal, no compulsion, damage or universal compatibility. Nonoral fitted head control may implement the same ordinary function for a compatible animal; name never authorizes harmful forced control.

**fittingOrAttachmentMinutes:** 2

**requiredWorkers:** 1

**hands:** 2

**access:** ordinary item interaction/Action for actual access after fitting; no remote contents

**primaryConstituents:** original seat/load frame or principal bag/head harness body as applicable; compatible straps, grips and closures replaceable

**repair:** ordinary trained appropriate leatherworker/carpenter repair; real materials25%body,DC10,max(1h,maxHP/10); source-specific service alternative remains separate


## mounts-vehicles-and-services.carriage — Carriage

**Preserved complete source record**

```json
{
  "id": "mounts-vehicles-and-services.carriage",
  "name": "Carriage",
  "category": "Mounts vehicles and services",
  "group": "Tack, Harness, and Drawn Vehicles",
  "status": "source-projection-only",
  "sourceLine": 7078,
  "sourceFields": {
    "Item": "Carriage",
    "Cost": "100 gp",
    "Speed": ",",
    "Carrying Capacity": ","
  },
  "sourcePriceCp": 10000.0,
  "sourceWeightLb": null,
  "sourceWeightIncludesContents": false
}
```

**Complete operational body/service binding**

**provenance:** Price retained; Cart maximumHP30 binds the reviewed ordinary cart body. Every other listed body quantity/geometry/handling number is NEW. No passengers, animals, harnesses, operators or contents are included in price.

**priceCp:** 10000

**emptyMassLb:** 600

### outerFeet

```json
[
  12,
  6,
  7
]
```

### usableBedFeet

```json
[
  8,
  4,
  5
]
```

**bodyMaterial:** wood with ordinary metal fittings

**structuralAC:** 15

**maximumHP:** 50

**payloadPounds:** 1000

**payloadLoads:** 100

**cargoSublimitPounds:** 200

**cargoSublimitLoads:** 20

**maximumSeatedOccupantsIncludingDriver:** 5

**requiredDrivers:** 1

**minimumFittedPullers:** 2

**tacticalSpeedCapFt:** 50

**speedRule:** minimum current fitted puller Speed and cap. Each actual puller draw rating, combined gross vehicle+payload draw limit, route fit, stability and terrain must pass. One named Burdened penalty applies when either carried or gross-draw threshold qualifies; no duplicate penalty for the same mount.

**terrain:** firm wheel-supporting route; no ordinary climbing, stairs, ladders, swimming or unsupported gaps

**operatingFootprint:** vehicle envelope plus actual puller footprint and at least5ft forward harness gap; route must contain all real widths/heights/turning space

**turning:** one90-degree turn needs traveled distance at least the vehicle length and a clear swept envelope; sharper/blocked maneuver needs an actual separate route/work plan, not an automatic check

**controls:** driver uses one Action per regular turn in tactical operation to guide/brake using the actual reins/lever and one hand; NEW manual brakes are included. Pullers expend actual movement in the linked drive event. Driver cannot claim a separate mounted turn for a pulling animal or duplicate movement by changing drivers. Outside initiative driving is continuous actual work, not rest.

**movementEvent:** one linked vehicle/puller movement event per numbered round; resolve after required current driver Action and puller movement budgets are available. No future crew Action is presumed. All contributing budgets spent once. No vehicle Dash/Disengage/Reaction/attack; actual pullers have only their legal creature Actions.

**setupMinutes:** 5

**setupActors:** 1

**loadingRule:** TR-12, real necessary handling; setup harness is additional, no free load/receivers

**brake:** actual controlled stop at end of paid move; uncrewed/unhitched vehicle at rest stays at rest unless terrain/force actually moves it; no generic magical parking

**primaryConstituents:** original main frame, principal axle/runner set and bed structure; subordinate wheels, pins, harness fittings or brake pads can be replaced by actual compatible stock

**zeroHP:** Broken, stops useful self/drawn transport; retains wreck, mass, passengers and custody. No automatic occupant damage from mere HP0. Real collision/fall/dislodgement is a separately declared event. Reaching0 does not erase salvage or restore original frame.

**repair:** TR-14 ordinary structural repair with source-specific cost/time and original main body; not creature healing. No equipment Integrity track in parallel.


## mounts-vehicles-and-services.cart — Cart

**Preserved complete source record**

```json
{
  "id": "mounts-vehicles-and-services.cart",
  "name": "Cart",
  "category": "Mounts vehicles and services",
  "group": "Tack, Harness, and Drawn Vehicles",
  "status": "source-projection-only",
  "sourceLine": 7079,
  "sourceFields": {
    "Item": "Cart",
    "Cost": "15 gp",
    "Speed": ",",
    "Carrying Capacity": ","
  },
  "sourcePriceCp": 1500.0,
  "sourceWeightLb": null,
  "sourceWeightIncludesContents": false
}
```

**Complete operational body/service binding**

**provenance:** Price retained; Cart maximumHP30 binds the reviewed ordinary cart body. Every other listed body quantity/geometry/handling number is NEW. No passengers, animals, harnesses, operators or contents are included in price.

**priceCp:** 1500

**emptyMassLb:** 200

### outerFeet

```json
[
  8,
  5,
  4
]
```

### usableBedFeet

```json
[
  6,
  4,
  3
]
```

**bodyMaterial:** wood with ordinary metal fittings

**structuralAC:** 15

**maximumHP:** 30

**payloadPounds:** 300

**payloadLoads:** 30

**cargoSublimitPounds:** 300

**cargoSublimitLoads:** 30

**maximumSeatedOccupantsIncludingDriver:** 1

**requiredDrivers:** 1

**minimumFittedPullers:** 1

**tacticalSpeedCapFt:** 40

**speedRule:** minimum current fitted puller Speed and cap. Each actual puller draw rating, combined gross vehicle+payload draw limit, route fit, stability and terrain must pass. One named Burdened penalty applies when either carried or gross-draw threshold qualifies; no duplicate penalty for the same mount.

**terrain:** firm wheel-supporting route; no ordinary climbing, stairs, ladders, swimming or unsupported gaps

**operatingFootprint:** vehicle envelope plus actual puller footprint and at least5ft forward harness gap; route must contain all real widths/heights/turning space

**turning:** one90-degree turn needs traveled distance at least the vehicle length and a clear swept envelope; sharper/blocked maneuver needs an actual separate route/work plan, not an automatic check

**controls:** driver uses one Action per regular turn in tactical operation to guide/brake using the actual reins/lever and one hand; NEW manual brakes are included. Pullers expend actual movement in the linked drive event. Driver cannot claim a separate mounted turn for a pulling animal or duplicate movement by changing drivers. Outside initiative driving is continuous actual work, not rest.

**movementEvent:** one linked vehicle/puller movement event per numbered round; resolve after required current driver Action and puller movement budgets are available. No future crew Action is presumed. All contributing budgets spent once. No vehicle Dash/Disengage/Reaction/attack; actual pullers have only their legal creature Actions.

**setupMinutes:** 5

**setupActors:** 1

**loadingRule:** TR-12, real necessary handling; setup harness is additional, no free load/receivers

**brake:** actual controlled stop at end of paid move; uncrewed/unhitched vehicle at rest stays at rest unless terrain/force actually moves it; no generic magical parking

**primaryConstituents:** original main frame, principal axle/runner set and bed structure; subordinate wheels, pins, harness fittings or brake pads can be replaced by actual compatible stock

**zeroHP:** Broken, stops useful self/drawn transport; retains wreck, mass, passengers and custody. No automatic occupant damage from mere HP0. Real collision/fall/dislodgement is a separately declared event. Reaching0 does not erase salvage or restore original frame.

**repair:** TR-14 ordinary structural repair with source-specific cost/time and original main body; not creature healing. No equipment Integrity track in parallel.


## mounts-vehicles-and-services.chariot — Chariot

**Preserved complete source record**

```json
{
  "id": "mounts-vehicles-and-services.chariot",
  "name": "Chariot",
  "category": "Mounts vehicles and services",
  "group": "Tack, Harness, and Drawn Vehicles",
  "status": "source-projection-only",
  "sourceLine": 7080,
  "sourceFields": {
    "Item": "Chariot",
    "Cost": "250 gp",
    "Speed": ",",
    "Carrying Capacity": ","
  },
  "sourcePriceCp": 25000.0,
  "sourceWeightLb": null,
  "sourceWeightIncludesContents": false
}
```

**Complete operational body/service binding**

**provenance:** Price retained; Cart maximumHP30 binds the reviewed ordinary cart body. Every other listed body quantity/geometry/handling number is NEW. No passengers, animals, harnesses, operators or contents are included in price.

**priceCp:** 25000

**emptyMassLb:** 180

### outerFeet

```json
[
  7,
  5,
  5
]
```

### usableBedFeet

```json
[
  5,
  4,
  3
]
```

**bodyMaterial:** wood with ordinary metal fittings

**structuralAC:** 15

**maximumHP:** 30

**payloadPounds:** 500

**payloadLoads:** 50

**cargoSublimitPounds:** 100

**cargoSublimitLoads:** 10

**maximumSeatedOccupantsIncludingDriver:** 2

**requiredDrivers:** 1

**minimumFittedPullers:** 2

**tacticalSpeedCapFt:** 60

**speedRule:** minimum current fitted puller Speed and cap. Each actual puller draw rating, combined gross vehicle+payload draw limit, route fit, stability and terrain must pass. One named Burdened penalty applies when either carried or gross-draw threshold qualifies; no duplicate penalty for the same mount.

**terrain:** firm wheel-supporting route; no ordinary climbing, stairs, ladders, swimming or unsupported gaps

**operatingFootprint:** vehicle envelope plus actual puller footprint and at least5ft forward harness gap; route must contain all real widths/heights/turning space

**turning:** one90-degree turn needs traveled distance at least the vehicle length and a clear swept envelope; sharper/blocked maneuver needs an actual separate route/work plan, not an automatic check

**controls:** driver uses one Action per regular turn in tactical operation to guide/brake using the actual reins/lever and one hand; NEW manual brakes are included. Pullers expend actual movement in the linked drive event. Driver cannot claim a separate mounted turn for a pulling animal or duplicate movement by changing drivers. Outside initiative driving is continuous actual work, not rest.

**movementEvent:** one linked vehicle/puller movement event per numbered round; resolve after required current driver Action and puller movement budgets are available. No future crew Action is presumed. All contributing budgets spent once. No vehicle Dash/Disengage/Reaction/attack; actual pullers have only their legal creature Actions.

**setupMinutes:** 5

**setupActors:** 1

**loadingRule:** TR-12, real necessary handling; setup harness is additional, no free load/receivers

**brake:** actual controlled stop at end of paid move; uncrewed/unhitched vehicle at rest stays at rest unless terrain/force actually moves it; no generic magical parking

**primaryConstituents:** original main frame, principal axle/runner set and bed structure; subordinate wheels, pins, harness fittings or brake pads can be replaced by actual compatible stock

**zeroHP:** Broken, stops useful self/drawn transport; retains wreck, mass, passengers and custody. No automatic occupant damage from mere HP0. Real collision/fall/dislodgement is a separately declared event. Reaching0 does not erase salvage or restore original frame.

**repair:** TR-14 ordinary structural repair with source-specific cost/time and original main body; not creature healing. No equipment Integrity track in parallel.


## mounts-vehicles-and-services.feed-per-day — Feed (per day)

**Preserved complete source record**

```json
{
  "id": "mounts-vehicles-and-services.feed-per-day",
  "name": "Feed (per day)",
  "category": "Mounts vehicles and services",
  "group": "Tack, Harness, and Drawn Vehicles",
  "status": "source-projection-only",
  "sourceLine": 7081,
  "sourceFields": {
    "Item": "Feed (per day)",
    "Cost": "5 cp",
    "Speed": ",",
    "Carrying Capacity": ","
  },
  "sourcePriceCp": 5.0,
  "sourceWeightLb": null,
  "sourceWeightIncludesContents": false
}
```

**Complete operational body/service binding**

**provenance:** 5cp per day retained; exact supported quantities/species chosen NEW in each mount profile. Source numeric weight remains null because this is a recipient-qualified provision rather than one universal weighed object.

**priceCp:** 5

**recipientLimit:** one actual named mount for one24-hour nutrition interval

**quantity:** actual species-compatible dry ration mass in that mount profile; receipt must name it

**waterIncluded:** false

**storage:** actual compatible sack/container; no free container. Default dry unspoiled sealed course uses FL-05 dry-ration30-day newly authored interval unless actual source/condition specifies another; real wet/spoiled feed does not qualify.

**consumption:** actual24-hour recipient interval, no double human Supply charge; partial feed remains physical measured mass but does not complete the interval until requirement met

**restEffect:** nutrition prerequisite only, not healing/Strain removal/extra Long Rest


## mounts-vehicles-and-services.saddle-exotic — Saddle, exotic

**Preserved complete source record**

```json
{
  "id": "mounts-vehicles-and-services.saddle-exotic",
  "name": "Saddle, exotic",
  "category": "Mounts vehicles and services",
  "group": "Tack, Harness, and Drawn Vehicles",
  "status": "source-projection-only",
  "sourceLine": 7082,
  "sourceFields": {
    "Item": "Saddle, exotic",
    "Cost": "60 gp",
    "Speed": ",",
    "Carrying Capacity": ","
  },
  "sourcePriceCp": 6000.0,
  "sourceWeightLb": null,
  "sourceWeightIncludesContents": false
}
```

**Complete operational body/service binding**

**provenance:** Price retained; mass, geometry,HP and ordinary functional details NEW. No source comma/null rewritten.

**priceCp:** 6000

**emptyMassLb:** 36

**maximumHP:** 5

**structuralAC:** 15

### packedEnvelopeInches

```json
[
  36,
  24,
  12
]
```

**ordinaryUse:** One fitted seat/restraint arrangement for a particular nonstandard mount body, including this Elephant when actually fitted; not wings, multiple seats, armor or class binding.

**fittingOrAttachmentMinutes:** 5

**requiredWorkers:** 1

**hands:** 2

**access:** ordinary item interaction/Action for actual access after fitting; no remote contents

**primaryConstituents:** original seat/load frame or principal bag/head harness body as applicable; compatible straps, grips and closures replaceable

**repair:** ordinary trained appropriate leatherworker/carpenter repair; real materials25%body,DC10,max(1h,maxHP/10); source-specific service alternative remains separate


## mounts-vehicles-and-services.saddle-military — Saddle, military

**Preserved complete source record**

```json
{
  "id": "mounts-vehicles-and-services.saddle-military",
  "name": "Saddle, military",
  "category": "Mounts vehicles and services",
  "group": "Tack, Harness, and Drawn Vehicles",
  "status": "source-projection-only",
  "sourceLine": 7083,
  "sourceFields": {
    "Item": "Saddle, military",
    "Cost": "20 gp",
    "Speed": ",",
    "Carrying Capacity": ","
  },
  "sourcePriceCp": 2000.0,
  "sourceWeightLb": null,
  "sourceWeightIncludesContents": false
}
```

**Complete operational body/service binding**

**provenance:** Price retained; mass, geometry,HP and ordinary functional details NEW. No source comma/null rewritten.

**priceCp:** 2000

**emptyMassLb:** 24

**maximumHP:** 5

**structuralAC:** 15

### packedEnvelopeInches

```json
[
  24,
  20,
  10
]
```

**ordinaryUse:** One fitted reinforced rider seat with handholds; no automatic advantage, prevention of falling or mounted combat feat.

**fittingOrAttachmentMinutes:** 5

**requiredWorkers:** 1

**hands:** 2

**access:** ordinary item interaction/Action for actual access after fitting; no remote contents

**primaryConstituents:** original seat/load frame or principal bag/head harness body as applicable; compatible straps, grips and closures replaceable

**repair:** ordinary trained appropriate leatherworker/carpenter repair; real materials25%body,DC10,max(1h,maxHP/10); source-specific service alternative remains separate


## mounts-vehicles-and-services.saddle-pack — Saddle, pack

**Preserved complete source record**

```json
{
  "id": "mounts-vehicles-and-services.saddle-pack",
  "name": "Saddle, pack",
  "category": "Mounts vehicles and services",
  "group": "Tack, Harness, and Drawn Vehicles",
  "status": "source-projection-only",
  "sourceLine": 7084,
  "sourceFields": {
    "Item": "Saddle, pack",
    "Cost": "5 gp",
    "Speed": ",",
    "Carrying Capacity": ","
  },
  "sourcePriceCp": 500.0,
  "sourceWeightLb": null,
  "sourceWeightIncludesContents": false
}
```

**Complete operational body/service binding**

**provenance:** Price retained; mass, geometry,HP and ordinary functional details NEW. No source comma/null rewritten.

**priceCp:** 500

**emptyMassLb:** 15

**maximumHP:** 5

**structuralAC:** 15

### packedEnvelopeInches

```json
[
  24,
  20,
  10
]
```

**ordinaryUse:** Compatible load frame and tie points; no rider seat or free cargo container. Actual balanced load is still subject to animal limits.

**fittingOrAttachmentMinutes:** 5

**requiredWorkers:** 1

**hands:** 2

**access:** ordinary item interaction/Action for actual access after fitting; no remote contents

**primaryConstituents:** original seat/load frame or principal bag/head harness body as applicable; compatible straps, grips and closures replaceable

**repair:** ordinary trained appropriate leatherworker/carpenter repair; real materials25%body,DC10,max(1h,maxHP/10); source-specific service alternative remains separate


## mounts-vehicles-and-services.saddle-riding — Saddle, riding

**Preserved complete source record**

```json
{
  "id": "mounts-vehicles-and-services.saddle-riding",
  "name": "Saddle, riding",
  "category": "Mounts vehicles and services",
  "group": "Tack, Harness, and Drawn Vehicles",
  "status": "source-projection-only",
  "sourceLine": 7085,
  "sourceFields": {
    "Item": "Saddle, riding",
    "Cost": "10 gp",
    "Speed": ",",
    "Carrying Capacity": ","
  },
  "sourcePriceCp": 1000.0,
  "sourceWeightLb": null,
  "sourceWeightIncludesContents": false
}
```

**Complete operational body/service binding**

**provenance:** Price retained; mass, geometry,HP and ordinary functional details NEW. No source comma/null rewritten.

**priceCp:** 1000

**emptyMassLb:** 18

**maximumHP:** 5

**structuralAC:** 15

### packedEnvelopeInches

```json
[
  24,
  20,
  10
]
```

**ordinaryUse:** One fitted ordinary rider seat; no control without actual training/channel and no automatic save modifier.

**fittingOrAttachmentMinutes:** 5

**requiredWorkers:** 1

**hands:** 2

**access:** ordinary item interaction/Action for actual access after fitting; no remote contents

**primaryConstituents:** original seat/load frame or principal bag/head harness body as applicable; compatible straps, grips and closures replaceable

**repair:** ordinary trained appropriate leatherworker/carpenter repair; real materials25%body,DC10,max(1h,maxHP/10); source-specific service alternative remains separate


## mounts-vehicles-and-services.saddlebags — Saddlebags

**Preserved complete source record**

```json
{
  "id": "mounts-vehicles-and-services.saddlebags",
  "name": "Saddlebags",
  "category": "Mounts vehicles and services",
  "group": "Tack, Harness, and Drawn Vehicles",
  "status": "source-projection-only",
  "sourceLine": 7086,
  "sourceFields": {
    "Item": "Saddlebags",
    "Cost": "4 gp",
    "Speed": ",",
    "Carrying Capacity": ","
  },
  "sourcePriceCp": 400.0,
  "sourceWeightLb": null,
  "sourceWeightIncludesContents": false
}
```

**Complete operational body/service binding**

**provenance:** Price retained; mass, geometry,HP and ordinary functional details NEW. No source comma/null rewritten.

**priceCp:** 400

**emptyMassLb:** 4

**maximumHP:** 5

**structuralAC:** 15

### packedEnvelopeInches

```json
[
  16,
  12,
  12
]
```

**ordinaryUse:** Two fitted cells, each0.5ft³ and20lb maximum, together1ft³/40lb; actual shape and balance apply. Neither stasis nor hazardous containment. Contents add to animal payload and total mass.

**fittingOrAttachmentMinutes:** 1

**requiredWorkers:** 1

**hands:** 2

**access:** ordinary item interaction/Action for actual access after fitting; no remote contents

**primaryConstituents:** original seat/load frame or principal bag/head harness body as applicable; compatible straps, grips and closures replaceable

**repair:** ordinary trained appropriate leatherworker/carpenter repair; real materials25%body,DC10,max(1h,maxHP/10); source-specific service alternative remains separate


## mounts-vehicles-and-services.sled — Sled

**Preserved complete source record**

```json
{
  "id": "mounts-vehicles-and-services.sled",
  "name": "Sled",
  "category": "Mounts vehicles and services",
  "group": "Tack, Harness, and Drawn Vehicles",
  "status": "source-projection-only",
  "sourceLine": 7087,
  "sourceFields": {
    "Item": "Sled",
    "Cost": "20 gp",
    "Speed": ",",
    "Carrying Capacity": ","
  },
  "sourcePriceCp": 2000.0,
  "sourceWeightLb": null,
  "sourceWeightIncludesContents": false
}
```

**Complete operational body/service binding**

**provenance:** Price retained; Cart maximumHP30 binds the reviewed ordinary cart body. Every other listed body quantity/geometry/handling number is NEW. No passengers, animals, harnesses, operators or contents are included in price.

**priceCp:** 2000

**emptyMassLb:** 80

### outerFeet

```json
[
  8,
  4,
  2
]
```

### usableBedFeet

```json
[
  6,
  3,
  1.5
]
```

**bodyMaterial:** wood with ordinary metal fittings

**structuralAC:** 15

**maximumHP:** 30

**payloadPounds:** 400

**payloadLoads:** 40

**cargoSublimitPounds:** 300

**cargoSublimitLoads:** 30

**maximumSeatedOccupantsIncludingDriver:** 2

**requiredDrivers:** 1

**minimumFittedPullers:** 1

**tacticalSpeedCapFt:** 40

**speedRule:** minimum current fitted puller Speed and cap. Each actual puller draw rating, combined gross vehicle+payload draw limit, route fit, stability and terrain must pass. One named Burdened penalty applies when either carried or gross-draw threshold qualifies; no duplicate penalty for the same mount.

**terrain:** snow/ice or actual compatible runner surface only; not a wheeled road vehicle

**operatingFootprint:** vehicle envelope plus actual puller footprint and at least5ft forward harness gap; route must contain all real widths/heights/turning space

**turning:** one90-degree turn needs traveled distance at least the vehicle length and a clear swept envelope; sharper/blocked maneuver needs an actual separate route/work plan, not an automatic check

**controls:** driver uses one Action per regular turn in tactical operation to guide/brake using the actual reins/lever and one hand; NEW manual brakes are included. Pullers expend actual movement in the linked drive event. Driver cannot claim a separate mounted turn for a pulling animal or duplicate movement by changing drivers. Outside initiative driving is continuous actual work, not rest.

**movementEvent:** one linked vehicle/puller movement event per numbered round; resolve after required current driver Action and puller movement budgets are available. No future crew Action is presumed. All contributing budgets spent once. No vehicle Dash/Disengage/Reaction/attack; actual pullers have only their legal creature Actions.

**setupMinutes:** 5

**setupActors:** 1

**loadingRule:** TR-12, real necessary handling; setup harness is additional, no free load/receivers

**brake:** actual controlled stop at end of paid move; uncrewed/unhitched vehicle at rest stays at rest unless terrain/force actually moves it; no generic magical parking

**primaryConstituents:** original main frame, principal axle/runner set and bed structure; subordinate wheels, pins, harness fittings or brake pads can be replaced by actual compatible stock

**zeroHP:** Broken, stops useful self/drawn transport; retains wreck, mass, passengers and custody. No automatic occupant damage from mere HP0. Real collision/fall/dislodgement is a separately declared event. Reaching0 does not erase salvage or restore original frame.

**repair:** TR-14 ordinary structural repair with source-specific cost/time and original main body; not creature healing. No equipment Integrity track in parallel.


## mounts-vehicles-and-services.stabling-per-day — Stabling (per day)

**Preserved complete source record**

```json
{
  "id": "mounts-vehicles-and-services.stabling-per-day",
  "name": "Stabling (per day)",
  "category": "Mounts vehicles and services",
  "group": "Tack, Harness, and Drawn Vehicles",
  "status": "source-projection-only",
  "sourceLine": 7088,
  "sourceFields": {
    "Item": "Stabling (per day)",
    "Cost": "5 sp",
    "Speed": ",",
    "Carrying Capacity": ","
  },
  "sourcePriceCp": 50.0,
  "sourceWeightLb": null,
  "sourceWeightIncludesContents": false
}
```

**Complete operational body/service binding**

**provenance:** 50cp/day retained; service content/timing NEW, not an object with artificial weight/HP.

**priceCp:** 50

**durationSeconds:** 86400

**recipientLimit:** one actual mount in a genuinely fitting secure stall/pen

**service:** ordinary shelter, cleaning, ordinary supervision and access for a qualified caretaker; actual available stall capacity and care are prerequisites. Feed and water are separately allocated/charged unless the offered agreement explicitly includes them.

**capacity:** must fit the actual mount space/height and safe access; a5ft dog stall cannot admit an Elephant by price

**rest:** actual safe suitable rest may qualify; stabling payment alone does not restore HP/Hit Dice/food, clear Wounds or break a bond

**custody:** owner, provider, location, period and real handover; liability/escape/theft actual contract and events. No ownership transfer.


## mounts-vehicles-and-services.wagon — Wagon

**Preserved complete source record**

```json
{
  "id": "mounts-vehicles-and-services.wagon",
  "name": "Wagon",
  "category": "Mounts vehicles and services",
  "group": "Tack, Harness, and Drawn Vehicles",
  "status": "source-projection-only",
  "sourceLine": 7089,
  "sourceFields": {
    "Item": "Wagon",
    "Cost": "35 gp",
    "Speed": ",",
    "Carrying Capacity": ","
  },
  "sourcePriceCp": 3500.0,
  "sourceWeightLb": null,
  "sourceWeightIncludesContents": false
}
```

**Complete operational body/service binding**

**provenance:** Price retained; Cart maximumHP30 binds the reviewed ordinary cart body. Every other listed body quantity/geometry/handling number is NEW. No passengers, animals, harnesses, operators or contents are included in price.

**priceCp:** 3500

**emptyMassLb:** 300

### outerFeet

```json
[
  12,
  6,
  6
]
```

### usableBedFeet

```json
[
  8,
  4,
  4
]
```

**bodyMaterial:** wood with ordinary metal fittings

**structuralAC:** 15

**maximumHP:** 40

**payloadPounds:** 800

**payloadLoads:** 80

**cargoSublimitPounds:** 800

**cargoSublimitLoads:** 80

**maximumSeatedOccupantsIncludingDriver:** 2

**requiredDrivers:** 1

**minimumFittedPullers:** 2

**tacticalSpeedCapFt:** 40

**speedRule:** minimum current fitted puller Speed and cap. Each actual puller draw rating, combined gross vehicle+payload draw limit, route fit, stability and terrain must pass. One named Burdened penalty applies when either carried or gross-draw threshold qualifies; no duplicate penalty for the same mount.

**terrain:** firm wheel-supporting route; no ordinary climbing, stairs, ladders, swimming or unsupported gaps

**operatingFootprint:** vehicle envelope plus actual puller footprint and at least5ft forward harness gap; route must contain all real widths/heights/turning space

**turning:** one90-degree turn needs traveled distance at least the vehicle length and a clear swept envelope; sharper/blocked maneuver needs an actual separate route/work plan, not an automatic check

**controls:** driver uses one Action per regular turn in tactical operation to guide/brake using the actual reins/lever and one hand; NEW manual brakes are included. Pullers expend actual movement in the linked drive event. Driver cannot claim a separate mounted turn for a pulling animal or duplicate movement by changing drivers. Outside initiative driving is continuous actual work, not rest.

**movementEvent:** one linked vehicle/puller movement event per numbered round; resolve after required current driver Action and puller movement budgets are available. No future crew Action is presumed. All contributing budgets spent once. No vehicle Dash/Disengage/Reaction/attack; actual pullers have only their legal creature Actions.

**setupMinutes:** 5

**setupActors:** 1

**loadingRule:** TR-12, real necessary handling; setup harness is additional, no free load/receivers

**brake:** actual controlled stop at end of paid move; uncrewed/unhitched vehicle at rest stays at rest unless terrain/force actually moves it; no generic magical parking

**primaryConstituents:** original main frame, principal axle/runner set and bed structure; subordinate wheels, pins, harness fittings or brake pads can be replaced by actual compatible stock

**zeroHP:** Broken, stops useful self/drawn transport; retains wreck, mass, passengers and custody. No automatic occupant damage from mere HP0. Real collision/fall/dislodgement is a separately declared event. Reaching0 does not erase salvage or restore original frame.

**repair:** TR-14 ordinary structural repair with source-specific cost/time and original main body; not creature healing. No equipment Integrity track in parallel.


## mounts-vehicles-and-services.galley — Galley

**Preserved complete source record**

```json
{
  "id": "mounts-vehicles-and-services.galley",
  "name": "Galley",
  "category": "Mounts vehicles and services",
  "group": "Waterborne Vehicles",
  "status": "source-projection-only",
  "sourceLine": 7091,
  "sourceFields": {
    "Item": "Galley",
    "Cost": "30,000 gp",
    "Speed": ",",
    "Carrying Capacity": ","
  },
  "sourcePriceCp": 3000000.0,
  "sourceWeightLb": null,
  "sourceWeightIncludesContents": false
}
```

**Complete operational body/service binding**

**provenance:** Price retained; EVERY mass,HP,geometry,draft,crew,seat,cargo,propulsion and Speed number is explicitly NEW provisional game-profile authorship. No outside vessel stat block, inherent weapons, crew or cargo imported.

**priceCp:** 3000000

**emptyMassLb:** 60000

**structuralAC:** 15

**maximumHP:** 300

### outerFeetIncludingStandingRig

```json
[
  100,
  20,
  40
]
```

**draftFeetAtPermittedPayload:** 4

**minimumWaterDepthFeet:** 4.5

### usableHoldFeet

```json
[
  70,
  14,
  4
]
```

**totalPayloadPounds:** 35000

**totalPayloadLoads:** 3500.0

**cargoSublimitPounds:** 20000

**cargoSublimitLoads:** 2000.0

**maximumOccupantsIncludingCrew:** 100

### requiredActiveCrewByModeIncludingHelm

```json
{
  "oar": 41,
  "sail": 8
}
```

### tacticalSpeedFtByMode

```json
{
  "oar": 30,
  "sail": 40
}
```

### travelMphByMode

```json
{
  "oar": 3.0,
  "sail": 4.0
}
```

**inventoryIncluded:** actual hull, principal mast/sail/rigging where sail mode exists, oars/rowlocks for stated oar mode, ordinary rudder/tiller and mooring lines. No crew, food/water, personal gear, cargo, weapons, lifeboat, magic or elemental power.

**crewGate:** one designated trained Vehicles(Water) helmsman for hazardous navigation; actual capable crew meet each mode minimum and work continuously. Calm ordinary paddling/rowing may be physically attempted untrained without automatic penalty; uncertainty uses TR-09 actual check. Source-specific proficiency gates override.

**movementEvent:** one vessel drive event per numbered round after a current helm Action and all required actual crew contributions for that mode are available. One person may satisfy rowboat helm+oar in one combined Action, otherwise each required crew member is distinct. Resolve after the last necessary contributing turn/Action, rechecking current feasibility. Contributions cannot also make attacks/Help/guard/beneficial rest. Extra Actions/extra turns or a new helm do not make a second event. No native vessel turn,Reaction,Dash,Disengage or attack.

**travel:** actual continuous staffed labor on FL-03 clock; speed is one active hour basis, not miles per second. Crew shifts need real people, food and rest. Passengers can perform compatible limited activity only if real movement/environment permits; no automatic rest or full workshop.

**currentWind:** actual route must supply water-current vector and sail feasibility. No stated current defaults to0 in the synthetic model only, not proof of calm seas. Sail calm or directly unsupported wind course gives0 self-propulsion; oars can still work if supplied. Ordinary usable wind gives stated sail speed; declared adverse-but-usable conditions halve it. Stronger weather needs actual hazard stakes, not an automatic new storm. Tactical actual current displacement is separate from own propulsion; countercurrent subtracts along route, minimum0 ground progress, with actual drift retained.

**turning:** clear swept envelope required; a90-degree heading change requires at least one hull-length traveled and sufficient water/clearance, or an actual stationary line/anchor maneuver taking10 active minutes with working crew. No instant spin through walls.

**dockingMinutes:** 5

**docking:** actual slow approach, available berth/bank, water depth, lines and capable receiver/crew. Uncontested calm docking needs no roll; hazardous approach uses declared Vehicles(Water) DC and failure under TR-09. Load/unload is extra real handling. Mast lowering is not free; separate actually feasible20-minute crew operation, mast/clearance accounted during it.

**primaryConstituents:** original principal keel/hull frame and steering body; original primary mast/rig where needed to restore that same sail assembly. Compatible planking, cloth sails, ropes, oars and subordinate fittings may be replaced with actual stock, not invented from a cost quotation.

**zeroHP:** Broken and propulsion disabled. If afloat and no specific different destruction source governs, NEW begins one10-minute flooding/evacuation deadline; at it the wreck becomes submerged/stranded according to actual depth/bank/support, not deleted. Occupants receive actual fall/swim/drowning/escape procedures, not automatic death or shared hull damage. Repairing, touching or renaming the hull cannot reset that event.

**emergencyShoring:** NEW once per actual hull-breaking damage episode: two capable workers, at least one trained Carpenter tools or Vehicles(Water), real compatible patch/bracing material priced at1%undamaged body reference (minimum1gp),five uninterrupted active minutes before the flooding deadline; DC15 appropriate tool task,Core collapsed binary. Success keeps that same disabled hull afloat for60 minutes from completion, withoutHP,propulsion or a new seaworthy status; failure spends work/materials and does not alter deadline. It cannot be repeated on that same rupture to bank time. Grounding/towing to genuine support may permit later full repair.

**repair:** TR-14 actual structural repair, full required original body, trained suitable toolkit, dry/supportable worksite; generic25%body material reference/DC10/max(1h,maxHP/10h) unless a specific actual repair authority differs. Core complete service quote10%/15% is an alternative, not another material charge. No repair while the purported workpiece is irretrievably absent.


## mounts-vehicles-and-services.keelboat — Keelboat

**Preserved complete source record**

```json
{
  "id": "mounts-vehicles-and-services.keelboat",
  "name": "Keelboat",
  "category": "Mounts vehicles and services",
  "group": "Waterborne Vehicles",
  "status": "source-projection-only",
  "sourceLine": 7092,
  "sourceFields": {
    "Item": "Keelboat",
    "Cost": "3,000 gp",
    "Speed": ",",
    "Carrying Capacity": ","
  },
  "sourcePriceCp": 300000.0,
  "sourceWeightLb": null,
  "sourceWeightIncludesContents": false
}
```

**Complete operational body/service binding**

**provenance:** Price retained; EVERY mass,HP,geometry,draft,crew,seat,cargo,propulsion and Speed number is explicitly NEW provisional game-profile authorship. No outside vessel stat block, inherent weapons, crew or cargo imported.

**priceCp:** 300000

**emptyMassLb:** 4000

**structuralAC:** 15

**maximumHP:** 90

### outerFeetIncludingStandingRig

```json
[
  30,
  10,
  15
]
```

**draftFeetAtPermittedPayload:** 2

**minimumWaterDepthFeet:** 2.5

### usableHoldFeet

```json
[
  20,
  6,
  3
]
```

**totalPayloadPounds:** 4000

**totalPayloadLoads:** 400.0

**cargoSublimitPounds:** 2000

**cargoSublimitLoads:** 200.0

**maximumOccupantsIncludingCrew:** 10

### requiredActiveCrewByModeIncludingHelm

```json
{
  "oar": 3,
  "sail": 3
}
```

### tacticalSpeedFtByMode

```json
{
  "oar": 20,
  "sail": 30
}
```

### travelMphByMode

```json
{
  "oar": 2.0,
  "sail": 3.0
}
```

**inventoryIncluded:** actual hull, principal mast/sail/rigging where sail mode exists, oars/rowlocks for stated oar mode, ordinary rudder/tiller and mooring lines. No crew, food/water, personal gear, cargo, weapons, lifeboat, magic or elemental power.

**crewGate:** one designated trained Vehicles(Water) helmsman for hazardous navigation; actual capable crew meet each mode minimum and work continuously. Calm ordinary paddling/rowing may be physically attempted untrained without automatic penalty; uncertainty uses TR-09 actual check. Source-specific proficiency gates override.

**movementEvent:** one vessel drive event per numbered round after a current helm Action and all required actual crew contributions for that mode are available. One person may satisfy rowboat helm+oar in one combined Action, otherwise each required crew member is distinct. Resolve after the last necessary contributing turn/Action, rechecking current feasibility. Contributions cannot also make attacks/Help/guard/beneficial rest. Extra Actions/extra turns or a new helm do not make a second event. No native vessel turn,Reaction,Dash,Disengage or attack.

**travel:** actual continuous staffed labor on FL-03 clock; speed is one active hour basis, not miles per second. Crew shifts need real people, food and rest. Passengers can perform compatible limited activity only if real movement/environment permits; no automatic rest or full workshop.

**currentWind:** actual route must supply water-current vector and sail feasibility. No stated current defaults to0 in the synthetic model only, not proof of calm seas. Sail calm or directly unsupported wind course gives0 self-propulsion; oars can still work if supplied. Ordinary usable wind gives stated sail speed; declared adverse-but-usable conditions halve it. Stronger weather needs actual hazard stakes, not an automatic new storm. Tactical actual current displacement is separate from own propulsion; countercurrent subtracts along route, minimum0 ground progress, with actual drift retained.

**turning:** clear swept envelope required; a90-degree heading change requires at least one hull-length traveled and sufficient water/clearance, or an actual stationary line/anchor maneuver taking10 active minutes with working crew. No instant spin through walls.

**dockingMinutes:** 5

**docking:** actual slow approach, available berth/bank, water depth, lines and capable receiver/crew. Uncontested calm docking needs no roll; hazardous approach uses declared Vehicles(Water) DC and failure under TR-09. Load/unload is extra real handling. Mast lowering is not free; separate actually feasible20-minute crew operation, mast/clearance accounted during it.

**primaryConstituents:** original principal keel/hull frame and steering body; original primary mast/rig where needed to restore that same sail assembly. Compatible planking, cloth sails, ropes, oars and subordinate fittings may be replaced with actual stock, not invented from a cost quotation.

**zeroHP:** Broken and propulsion disabled. If afloat and no specific different destruction source governs, NEW begins one10-minute flooding/evacuation deadline; at it the wreck becomes submerged/stranded according to actual depth/bank/support, not deleted. Occupants receive actual fall/swim/drowning/escape procedures, not automatic death or shared hull damage. Repairing, touching or renaming the hull cannot reset that event.

**emergencyShoring:** NEW once per actual hull-breaking damage episode: two capable workers, at least one trained Carpenter tools or Vehicles(Water), real compatible patch/bracing material priced at1%undamaged body reference (minimum1gp),five uninterrupted active minutes before the flooding deadline; DC15 appropriate tool task,Core collapsed binary. Success keeps that same disabled hull afloat for60 minutes from completion, withoutHP,propulsion or a new seaworthy status; failure spends work/materials and does not alter deadline. It cannot be repeated on that same rupture to bank time. Grounding/towing to genuine support may permit later full repair.

**repair:** TR-14 actual structural repair, full required original body, trained suitable toolkit, dry/supportable worksite; generic25%body material reference/DC10/max(1h,maxHP/10h) unless a specific actual repair authority differs. Core complete service quote10%/15% is an alternative, not another material charge. No repair while the purported workpiece is irretrievably absent.


## mounts-vehicles-and-services.longship — Longship

**Preserved complete source record**

```json
{
  "id": "mounts-vehicles-and-services.longship",
  "name": "Longship",
  "category": "Mounts vehicles and services",
  "group": "Waterborne Vehicles",
  "status": "source-projection-only",
  "sourceLine": 7093,
  "sourceFields": {
    "Item": "Longship",
    "Cost": "10,000 gp",
    "Speed": ",",
    "Carrying Capacity": ","
  },
  "sourcePriceCp": 1000000.0,
  "sourceWeightLb": null,
  "sourceWeightIncludesContents": false
}
```

**Complete operational body/service binding**

**provenance:** Price retained; EVERY mass,HP,geometry,draft,crew,seat,cargo,propulsion and Speed number is explicitly NEW provisional game-profile authorship. No outside vessel stat block, inherent weapons, crew or cargo imported.

**priceCp:** 1000000

**emptyMassLb:** 12000

**structuralAC:** 15

**maximumHP:** 180

### outerFeetIncludingStandingRig

```json
[
  60,
  12,
  28
]
```

**draftFeetAtPermittedPayload:** 3

**minimumWaterDepthFeet:** 3.5

### usableHoldFeet

```json
[
  40,
  8,
  3
]
```

**totalPayloadPounds:** 14000

**totalPayloadLoads:** 1400.0

**cargoSublimitPounds:** 8000

**cargoSublimitLoads:** 800.0

**maximumOccupantsIncludingCrew:** 50

### requiredActiveCrewByModeIncludingHelm

```json
{
  "oar": 11,
  "sail": 4
}
```

### tacticalSpeedFtByMode

```json
{
  "oar": 30,
  "sail": 40
}
```

### travelMphByMode

```json
{
  "oar": 3.0,
  "sail": 4.0
}
```

**inventoryIncluded:** actual hull, principal mast/sail/rigging where sail mode exists, oars/rowlocks for stated oar mode, ordinary rudder/tiller and mooring lines. No crew, food/water, personal gear, cargo, weapons, lifeboat, magic or elemental power.

**crewGate:** one designated trained Vehicles(Water) helmsman for hazardous navigation; actual capable crew meet each mode minimum and work continuously. Calm ordinary paddling/rowing may be physically attempted untrained without automatic penalty; uncertainty uses TR-09 actual check. Source-specific proficiency gates override.

**movementEvent:** one vessel drive event per numbered round after a current helm Action and all required actual crew contributions for that mode are available. One person may satisfy rowboat helm+oar in one combined Action, otherwise each required crew member is distinct. Resolve after the last necessary contributing turn/Action, rechecking current feasibility. Contributions cannot also make attacks/Help/guard/beneficial rest. Extra Actions/extra turns or a new helm do not make a second event. No native vessel turn,Reaction,Dash,Disengage or attack.

**travel:** actual continuous staffed labor on FL-03 clock; speed is one active hour basis, not miles per second. Crew shifts need real people, food and rest. Passengers can perform compatible limited activity only if real movement/environment permits; no automatic rest or full workshop.

**currentWind:** actual route must supply water-current vector and sail feasibility. No stated current defaults to0 in the synthetic model only, not proof of calm seas. Sail calm or directly unsupported wind course gives0 self-propulsion; oars can still work if supplied. Ordinary usable wind gives stated sail speed; declared adverse-but-usable conditions halve it. Stronger weather needs actual hazard stakes, not an automatic new storm. Tactical actual current displacement is separate from own propulsion; countercurrent subtracts along route, minimum0 ground progress, with actual drift retained.

**turning:** clear swept envelope required; a90-degree heading change requires at least one hull-length traveled and sufficient water/clearance, or an actual stationary line/anchor maneuver taking10 active minutes with working crew. No instant spin through walls.

**dockingMinutes:** 5

**docking:** actual slow approach, available berth/bank, water depth, lines and capable receiver/crew. Uncontested calm docking needs no roll; hazardous approach uses declared Vehicles(Water) DC and failure under TR-09. Load/unload is extra real handling. Mast lowering is not free; separate actually feasible20-minute crew operation, mast/clearance accounted during it.

**primaryConstituents:** original principal keel/hull frame and steering body; original primary mast/rig where needed to restore that same sail assembly. Compatible planking, cloth sails, ropes, oars and subordinate fittings may be replaced with actual stock, not invented from a cost quotation.

**zeroHP:** Broken and propulsion disabled. If afloat and no specific different destruction source governs, NEW begins one10-minute flooding/evacuation deadline; at it the wreck becomes submerged/stranded according to actual depth/bank/support, not deleted. Occupants receive actual fall/swim/drowning/escape procedures, not automatic death or shared hull damage. Repairing, touching or renaming the hull cannot reset that event.

**emergencyShoring:** NEW once per actual hull-breaking damage episode: two capable workers, at least one trained Carpenter tools or Vehicles(Water), real compatible patch/bracing material priced at1%undamaged body reference (minimum1gp),five uninterrupted active minutes before the flooding deadline; DC15 appropriate tool task,Core collapsed binary. Success keeps that same disabled hull afloat for60 minutes from completion, withoutHP,propulsion or a new seaworthy status; failure spends work/materials and does not alter deadline. It cannot be repeated on that same rupture to bank time. Grounding/towing to genuine support may permit later full repair.

**repair:** TR-14 actual structural repair, full required original body, trained suitable toolkit, dry/supportable worksite; generic25%body material reference/DC10/max(1h,maxHP/10h) unless a specific actual repair authority differs. Core complete service quote10%/15% is an alternative, not another material charge. No repair while the purported workpiece is irretrievably absent.


## mounts-vehicles-and-services.rowboat — Rowboat

**Preserved complete source record**

```json
{
  "id": "mounts-vehicles-and-services.rowboat",
  "name": "Rowboat",
  "category": "Mounts vehicles and services",
  "group": "Waterborne Vehicles",
  "status": "source-projection-only",
  "sourceLine": 7094,
  "sourceFields": {
    "Item": "Rowboat",
    "Cost": "50 gp",
    "Speed": ",",
    "Carrying Capacity": ","
  },
  "sourcePriceCp": 5000.0,
  "sourceWeightLb": null,
  "sourceWeightIncludesContents": false
}
```

**Complete operational body/service binding**

**provenance:** Price retained; EVERY mass,HP,geometry,draft,crew,seat,cargo,propulsion and Speed number is explicitly NEW provisional game-profile authorship. No outside vessel stat block, inherent weapons, crew or cargo imported.

**priceCp:** 5000

**emptyMassLb:** 120

**structuralAC:** 15

**maximumHP:** 30

### outerFeetIncludingStandingRig

```json
[
  12,
  5,
  2
]
```

**draftFeetAtPermittedPayload:** 0.5

**minimumWaterDepthFeet:** 1.0

### usableHoldFeet

```json
[
  8,
  3,
  1
]
```

**totalPayloadPounds:** 600

**totalPayloadLoads:** 60.0

**cargoSublimitPounds:** 400

**cargoSublimitLoads:** 40.0

**maximumOccupantsIncludingCrew:** 4

### requiredActiveCrewByModeIncludingHelm

```json
{
  "oar": 1
}
```

### tacticalSpeedFtByMode

```json
{
  "oar": 20
}
```

### travelMphByMode

```json
{
  "oar": 2.0
}
```

**inventoryIncluded:** actual hull, principal mast/sail/rigging where sail mode exists, oars/rowlocks for stated oar mode, ordinary rudder/tiller and mooring lines. No crew, food/water, personal gear, cargo, weapons, lifeboat, magic or elemental power.

**crewGate:** one designated trained Vehicles(Water) helmsman for hazardous navigation; actual capable crew meet each mode minimum and work continuously. Calm ordinary paddling/rowing may be physically attempted untrained without automatic penalty; uncertainty uses TR-09 actual check. Source-specific proficiency gates override.

**movementEvent:** one vessel drive event per numbered round after a current helm Action and all required actual crew contributions for that mode are available. One person may satisfy rowboat helm+oar in one combined Action, otherwise each required crew member is distinct. Resolve after the last necessary contributing turn/Action, rechecking current feasibility. Contributions cannot also make attacks/Help/guard/beneficial rest. Extra Actions/extra turns or a new helm do not make a second event. No native vessel turn,Reaction,Dash,Disengage or attack.

**travel:** actual continuous staffed labor on FL-03 clock; speed is one active hour basis, not miles per second. Crew shifts need real people, food and rest. Passengers can perform compatible limited activity only if real movement/environment permits; no automatic rest or full workshop.

**currentWind:** actual route must supply water-current vector and sail feasibility. No stated current defaults to0 in the synthetic model only, not proof of calm seas. Sail calm or directly unsupported wind course gives0 self-propulsion; oars can still work if supplied. Ordinary usable wind gives stated sail speed; declared adverse-but-usable conditions halve it. Stronger weather needs actual hazard stakes, not an automatic new storm. Tactical actual current displacement is separate from own propulsion; countercurrent subtracts along route, minimum0 ground progress, with actual drift retained.

**turning:** clear swept envelope required; a90-degree heading change requires at least one hull-length traveled and sufficient water/clearance, or an actual stationary line/anchor maneuver taking10 active minutes with working crew. No instant spin through walls.

**dockingMinutes:** 1

**docking:** actual slow approach, available berth/bank, water depth, lines and capable receiver/crew. Uncontested calm docking needs no roll; hazardous approach uses declared Vehicles(Water) DC and failure under TR-09. Load/unload is extra real handling. Mast lowering is not free; separate actually feasible20-minute crew operation, mast/clearance accounted during it.

**primaryConstituents:** original principal keel/hull frame and steering body; original primary mast/rig where needed to restore that same sail assembly. Compatible planking, cloth sails, ropes, oars and subordinate fittings may be replaced with actual stock, not invented from a cost quotation.

**zeroHP:** Broken and propulsion disabled. If afloat and no specific different destruction source governs, NEW begins one10-minute flooding/evacuation deadline; at it the wreck becomes submerged/stranded according to actual depth/bank/support, not deleted. Occupants receive actual fall/swim/drowning/escape procedures, not automatic death or shared hull damage. Repairing, touching or renaming the hull cannot reset that event.

**emergencyShoring:** NEW once per actual hull-breaking damage episode: two capable workers, at least one trained Carpenter tools or Vehicles(Water), real compatible patch/bracing material priced at1%undamaged body reference (minimum1gp),five uninterrupted active minutes before the flooding deadline; DC15 appropriate tool task,Core collapsed binary. Success keeps that same disabled hull afloat for60 minutes from completion, withoutHP,propulsion or a new seaworthy status; failure spends work/materials and does not alter deadline. It cannot be repeated on that same rupture to bank time. Grounding/towing to genuine support may permit later full repair.

**repair:** TR-14 actual structural repair, full required original body, trained suitable toolkit, dry/supportable worksite; generic25%body material reference/DC10/max(1h,maxHP/10h) unless a specific actual repair authority differs. Core complete service quote10%/15% is an alternative, not another material charge. No repair while the purported workpiece is irretrievably absent.


## mounts-vehicles-and-services.sailing-ship — Sailing ship

**Preserved complete source record**

```json
{
  "id": "mounts-vehicles-and-services.sailing-ship",
  "name": "Sailing ship",
  "category": "Mounts vehicles and services",
  "group": "Waterborne Vehicles",
  "status": "source-projection-only",
  "sourceLine": 7095,
  "sourceFields": {
    "Item": "Sailing ship",
    "Cost": "10,000 gp",
    "Speed": ",",
    "Carrying Capacity": ","
  },
  "sourcePriceCp": 1000000.0,
  "sourceWeightLb": null,
  "sourceWeightIncludesContents": false
}
```

**Complete operational body/service binding**

**provenance:** Price retained; EVERY mass,HP,geometry,draft,crew,seat,cargo,propulsion and Speed number is explicitly NEW provisional game-profile authorship. No outside vessel stat block, inherent weapons, crew or cargo imported.

**priceCp:** 1000000

**emptyMassLb:** 40000

**structuralAC:** 15

**maximumHP:** 240

### outerFeetIncludingStandingRig

```json
[
  80,
  22,
  60
]
```

**draftFeetAtPermittedPayload:** 5

**minimumWaterDepthFeet:** 5.5

### usableHoldFeet

```json
[
  50,
  14,
  8
]
```

**totalPayloadPounds:** 30000

**totalPayloadLoads:** 3000.0

**cargoSublimitPounds:** 24000

**cargoSublimitLoads:** 2400.0

**maximumOccupantsIncludingCrew:** 30

### requiredActiveCrewByModeIncludingHelm

```json
{
  "sail": 8
}
```

### tacticalSpeedFtByMode

```json
{
  "sail": 40
}
```

### travelMphByMode

```json
{
  "sail": 4.0
}
```

**inventoryIncluded:** actual hull, principal mast/sail/rigging where sail mode exists, oars/rowlocks for stated oar mode, ordinary rudder/tiller and mooring lines. No crew, food/water, personal gear, cargo, weapons, lifeboat, magic or elemental power.

**crewGate:** one designated trained Vehicles(Water) helmsman for hazardous navigation; actual capable crew meet each mode minimum and work continuously. Calm ordinary paddling/rowing may be physically attempted untrained without automatic penalty; uncertainty uses TR-09 actual check. Source-specific proficiency gates override.

**movementEvent:** one vessel drive event per numbered round after a current helm Action and all required actual crew contributions for that mode are available. One person may satisfy rowboat helm+oar in one combined Action, otherwise each required crew member is distinct. Resolve after the last necessary contributing turn/Action, rechecking current feasibility. Contributions cannot also make attacks/Help/guard/beneficial rest. Extra Actions/extra turns or a new helm do not make a second event. No native vessel turn,Reaction,Dash,Disengage or attack.

**travel:** actual continuous staffed labor on FL-03 clock; speed is one active hour basis, not miles per second. Crew shifts need real people, food and rest. Passengers can perform compatible limited activity only if real movement/environment permits; no automatic rest or full workshop.

**currentWind:** actual route must supply water-current vector and sail feasibility. No stated current defaults to0 in the synthetic model only, not proof of calm seas. Sail calm or directly unsupported wind course gives0 self-propulsion; oars can still work if supplied. Ordinary usable wind gives stated sail speed; declared adverse-but-usable conditions halve it. Stronger weather needs actual hazard stakes, not an automatic new storm. Tactical actual current displacement is separate from own propulsion; countercurrent subtracts along route, minimum0 ground progress, with actual drift retained.

**turning:** clear swept envelope required; a90-degree heading change requires at least one hull-length traveled and sufficient water/clearance, or an actual stationary line/anchor maneuver taking10 active minutes with working crew. No instant spin through walls.

**dockingMinutes:** 5

**docking:** actual slow approach, available berth/bank, water depth, lines and capable receiver/crew. Uncontested calm docking needs no roll; hazardous approach uses declared Vehicles(Water) DC and failure under TR-09. Load/unload is extra real handling. Mast lowering is not free; separate actually feasible20-minute crew operation, mast/clearance accounted during it.

**primaryConstituents:** original principal keel/hull frame and steering body; original primary mast/rig where needed to restore that same sail assembly. Compatible planking, cloth sails, ropes, oars and subordinate fittings may be replaced with actual stock, not invented from a cost quotation.

**zeroHP:** Broken and propulsion disabled. If afloat and no specific different destruction source governs, NEW begins one10-minute flooding/evacuation deadline; at it the wreck becomes submerged/stranded according to actual depth/bank/support, not deleted. Occupants receive actual fall/swim/drowning/escape procedures, not automatic death or shared hull damage. Repairing, touching or renaming the hull cannot reset that event.

**emergencyShoring:** NEW once per actual hull-breaking damage episode: two capable workers, at least one trained Carpenter tools or Vehicles(Water), real compatible patch/bracing material priced at1%undamaged body reference (minimum1gp),five uninterrupted active minutes before the flooding deadline; DC15 appropriate tool task,Core collapsed binary. Success keeps that same disabled hull afloat for60 minutes from completion, withoutHP,propulsion or a new seaworthy status; failure spends work/materials and does not alter deadline. It cannot be repeated on that same rupture to bank time. Grounding/towing to genuine support may permit later full repair.

**repair:** TR-14 actual structural repair, full required original body, trained suitable toolkit, dry/supportable worksite; generic25%body material reference/DC10/max(1h,maxHP/10h) unless a specific actual repair authority differs. Core complete service quote10%/15% is an alternative, not another material charge. No repair while the purported workpiece is irretrievably absent.


## mounts-vehicles-and-services.warship — Warship

**Preserved complete source record**

```json
{
  "id": "mounts-vehicles-and-services.warship",
  "name": "Warship",
  "category": "Mounts vehicles and services",
  "group": "Waterborne Vehicles",
  "status": "source-projection-only",
  "sourceLine": 7096,
  "sourceFields": {
    "Item": "Warship",
    "Cost": "25,000 gp",
    "Speed": ",",
    "Carrying Capacity": ","
  },
  "sourcePriceCp": 2500000.0,
  "sourceWeightLb": null,
  "sourceWeightIncludesContents": false
}
```

**Complete operational body/service binding**

**provenance:** Price retained; EVERY mass,HP,geometry,draft,crew,seat,cargo,propulsion and Speed number is explicitly NEW provisional game-profile authorship. No outside vessel stat block, inherent weapons, crew or cargo imported.

**priceCp:** 2500000

**emptyMassLb:** 70000

**structuralAC:** 15

**maximumHP:** 300

### outerFeetIncludingStandingRig

```json
[
  90,
  24,
  60
]
```

**draftFeetAtPermittedPayload:** 5

**minimumWaterDepthFeet:** 5.5

### usableHoldFeet

```json
[
  50,
  16,
  8
]
```

**totalPayloadPounds:** 40000

**totalPayloadLoads:** 4000.0

**cargoSublimitPounds:** 20000

**cargoSublimitLoads:** 2000.0

**maximumOccupantsIncludingCrew:** 80

### requiredActiveCrewByModeIncludingHelm

```json
{
  "oar": 21,
  "sail": 10
}
```

### tacticalSpeedFtByMode

```json
{
  "oar": 30,
  "sail": 40
}
```

### travelMphByMode

```json
{
  "oar": 3.0,
  "sail": 4.0
}
```

**inventoryIncluded:** actual hull, principal mast/sail/rigging where sail mode exists, oars/rowlocks for stated oar mode, ordinary rudder/tiller and mooring lines. No crew, food/water, personal gear, cargo, weapons, lifeboat, magic or elemental power.

**crewGate:** one designated trained Vehicles(Water) helmsman for hazardous navigation; actual capable crew meet each mode minimum and work continuously. Calm ordinary paddling/rowing may be physically attempted untrained without automatic penalty; uncertainty uses TR-09 actual check. Source-specific proficiency gates override.

**movementEvent:** one vessel drive event per numbered round after a current helm Action and all required actual crew contributions for that mode are available. One person may satisfy rowboat helm+oar in one combined Action, otherwise each required crew member is distinct. Resolve after the last necessary contributing turn/Action, rechecking current feasibility. Contributions cannot also make attacks/Help/guard/beneficial rest. Extra Actions/extra turns or a new helm do not make a second event. No native vessel turn,Reaction,Dash,Disengage or attack.

**travel:** actual continuous staffed labor on FL-03 clock; speed is one active hour basis, not miles per second. Crew shifts need real people, food and rest. Passengers can perform compatible limited activity only if real movement/environment permits; no automatic rest or full workshop.

**currentWind:** actual route must supply water-current vector and sail feasibility. No stated current defaults to0 in the synthetic model only, not proof of calm seas. Sail calm or directly unsupported wind course gives0 self-propulsion; oars can still work if supplied. Ordinary usable wind gives stated sail speed; declared adverse-but-usable conditions halve it. Stronger weather needs actual hazard stakes, not an automatic new storm. Tactical actual current displacement is separate from own propulsion; countercurrent subtracts along route, minimum0 ground progress, with actual drift retained.

**turning:** clear swept envelope required; a90-degree heading change requires at least one hull-length traveled and sufficient water/clearance, or an actual stationary line/anchor maneuver taking10 active minutes with working crew. No instant spin through walls.

**dockingMinutes:** 5

**docking:** actual slow approach, available berth/bank, water depth, lines and capable receiver/crew. Uncontested calm docking needs no roll; hazardous approach uses declared Vehicles(Water) DC and failure under TR-09. Load/unload is extra real handling. Mast lowering is not free; separate actually feasible20-minute crew operation, mast/clearance accounted during it.

**primaryConstituents:** original principal keel/hull frame and steering body; original primary mast/rig where needed to restore that same sail assembly. Compatible planking, cloth sails, ropes, oars and subordinate fittings may be replaced with actual stock, not invented from a cost quotation.

**zeroHP:** Broken and propulsion disabled. If afloat and no specific different destruction source governs, NEW begins one10-minute flooding/evacuation deadline; at it the wreck becomes submerged/stranded according to actual depth/bank/support, not deleted. Occupants receive actual fall/swim/drowning/escape procedures, not automatic death or shared hull damage. Repairing, touching or renaming the hull cannot reset that event.

**emergencyShoring:** NEW once per actual hull-breaking damage episode: two capable workers, at least one trained Carpenter tools or Vehicles(Water), real compatible patch/bracing material priced at1%undamaged body reference (minimum1gp),five uninterrupted active minutes before the flooding deadline; DC15 appropriate tool task,Core collapsed binary. Success keeps that same disabled hull afloat for60 minutes from completion, withoutHP,propulsion or a new seaworthy status; failure spends work/materials and does not alter deadline. It cannot be repeated on that same rupture to bank time. Grounding/towing to genuine support may permit later full repair.

**repair:** TR-14 actual structural repair, full required original body, trained suitable toolkit, dry/supportable worksite; generic25%body material reference/DC10/max(1h,maxHP/10h) unless a specific actual repair authority differs. Core complete service quote10%/15% is an alternative, not another material charge. No repair while the purported workpiece is irretrievably absent.


## Distinct Core and NEW auxiliaries

These four records are not extra copies of the29 Player rows.

### NEW.transport.draw-harness

```json
{
  "id": "NEW.transport.draw-harness",
  "status": "NEW auxiliary, not a30th Player source row",
  "priceGp": 5,
  "emptyMassLb": 8,
  "fits": "one Medium/Large anatomically compatible trained puller",
  "hugeVariant": {
    "priceGp": 20,
    "emptyMassLb": 32
  },
  "HP": 5,
  "AC": 15,
  "setupMinutes": 5,
  "function": "actual traces/collar/attachment only; no draw multiplier, animal or capacity. Required separately per puller unless genuine agreed complete vehicle purchase includes actual stock."
}
```

### NEW.transport.stretcher

```json
{
  "id": "NEW.transport.stretcher",
  "status": "NEW auxiliary, not a Player source row",
  "priceGp": 5,
  "emptyMassLb": 10,
  "outerFeet": [
    7,
    2.5,
    0.5
  ],
  "payloadPounds": 300,
  "payloadCasualtyLoads": 6,
  "HP": 5,
  "AC": 15,
  "carriers": 2,
  "handsPerCarrier": 2,
  "assemblyMinutes": 1,
  "function": "one actually fitting Small/Medium casualty; actual two-carrier shares assigned before lift; body plus gear and stretcher mass checked. Does not reduce casualtyLoad or preserve life by itself."
}
```

### core.transport.dungeon-sled

```json
{
  "id": "core.transport.dungeon-sled",
  "status": "retained distinct Core item plus NEW complete body",
  "priceGp": 25,
  "sourceNormalCargoLoads": 12,
  "sourceMaximumCargoLoads": 20,
  "sourceOperators": 2,
  "NEWemptyMassLb": 60,
  "NEWouterFeet": [
    6,
    3,
    2
  ],
  "NEWbedFeet": [
    5,
    2.5,
    1.5
  ],
  "NEWnormalPayloadLb": 120,
  "NEWmaximumPayloadLb": 200,
  "NEWHP": 30,
  "NEWAC": 15,
  "NEWspeed": "two active manual operators using actual compatible drag/carry shares and route; normal convoy pace at<=12Loads/120lb if feasible, excess through20Loads/200lb emergency dragSpeed5. Real payload, frame and gear pounds checked against both workers; no driver seat or animal included.",
  "NEWterrain": "clear passable floor/runner path with no stairs/ladders or gap bypass",
  "repair": "TR-14 ordinary, actual original primary runner/frame"
}
```

### core.transport.hauler

```json
{
  "id": "core.transport.hauler",
  "status": "retained Core quote/capacity plus NEW separate magical transport-machine body, not a Player30th row or AEX/class device",
  "source": {
    "priceGp": 500,
    "normalLoads": 20,
    "emergencyLoads": 30,
    "fuel": "required, source quantity absent",
    "availability": "Tier IV+"
  },
  "NEW": {
    "emptyMassLb": 120,
    "outerFeet": [
      5,
      3,
      4
    ],
    "bedFeet": [
      4,
      2,
      2
    ],
    "structuralAC": 19,
    "maximumHP": 60,
    "normalPayloadLb": 200,
    "maximumPayloadLb": 300,
    "normalSpeedFt": 30,
    "emergencySpeedFt": 5,
    "operatorCount": 1,
    "operatorDistanceFt": 5,
    "hands": 2,
    "actionsPerDrive": 1,
    "driveEventsPerNumberedRound": 1,
    "fuelPintsPer8MovingHours": 1,
    "reservoirPints": 1,
    "refillMinutes": 1,
    "serviceAfterMovingHours": 40,
    "serviceActiveHours": 1,
    "servicePackGp": 1,
    "servicePackMassLb": 0.5,
    "functionalRepair": {
      "DC": 10,
      "hours": 6,
      "materialReferenceGp": 125
    },
    "BrokenReconstruction": {
      "DC": 15,
      "hours": 8,
      "materialReferenceGp": 125,
      "primary": "original frame,drive unit,controller"
    }
  },
  "fullOperatingDirection": "TR-11 and TR-14; no attack,creature turn,RP,recharge,class command,autonomy or magical salvage authority"
}
```

