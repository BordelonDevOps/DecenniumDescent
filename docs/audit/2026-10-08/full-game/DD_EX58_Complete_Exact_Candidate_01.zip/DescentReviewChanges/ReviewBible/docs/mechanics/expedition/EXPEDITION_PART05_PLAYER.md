# Player expedition procedures — mounts, transport and rescue

Working chapter module 5, authored from the agreed transport decisions and complete profile catalogue. Reputation and integrated records remain to assemble before exact candidate review.

Use with the [complete transport catalogue](TRANSPORT_CATALOGUE_CANDIDATE.md), [body and equipment rules](../BODY_EQUIPMENT_PLAYTEST.md), [Core resolution](../CORE_RESOLUTION_PLAYTEST.md), [routes and extraction](EXPEDITION_PART02_PLAYER.md), and [Haven services](EXPEDITION_PART03_PLAYER.md).

## Choose an actual mount

Use the complete [transport catalogue](TRANSPORT_CATALOGUE_CANDIDATE.md) for Camel, Donkey or mule, Elephant, Draft horse, Riding horse, War horse, Mastiff, Pony and Warhound. Each is a separate profile. “Donkey or mule” means one chosen individual.

The printed price, walking Speed and carrying pounds are retained. The additional body size, mass, abilities, defenses, HP, Hit Dice, attack, training, nutrition, draw rating and Load cap are explicit new provisional game values. A carrying rating does not determine Strength or make a template a record of the particular animal being sold.

Use the profile's natural AC, which already includes its Dexterity, and its fixed maximum HP. Record the individual's current HP, remaining Hit Dice, Wounds, conditions, injuries and training. Saves use its ability modifier without an added save proficiency unless an actual source grants it. Ordinary senses do not grant darkvision or automatic detection. These profiles supply no class levels, RP, spellcasting, special immunity or class features.

An independent animal's listed attack costs its Action and makes one attack using that profile's bonus, reach and damage. Core attack criticals apply. It has no automatic charge damage, knockdown or Multiattack, and the rider receives no extra attack. A controlled ridden mount instead uses the restricted Action choices below.

Large mounts occupy a 10-foot square, Medium mounts a 5-foot square, and the new Huge Elephant a 15-foot square. A saddle admits one physically compatible rider at least one size smaller. A Medium character cannot ride a Medium Pony merely because their weight is low. Count the rider, all equipment, tack, containers and contents against both the mount's pounds and Load limits. Its separate harness draw rating is not extra back capacity.

A positive carried burden at or above half either profile limit applies the one Burdened penalty: Speed −10 feet and disadvantage to climbing, swimming or moving silently. Do not apply it twice because both measures qualify. Routine carriage must fit both full limits and the actual body/seat geometry.

A registered ordinary expedition mount is, by this new default, a significant creature using Core Wounds, dying and death saves. Establish that status before the encounter. An actual Ranger Beast bond instead follows its own HP-only, immediate-death lifecycle. No repair, stable fee, new template or replacement purchase revives a dead individual.

## Control and training

A physically compatible, trained and willing mount can be controlled. An intelligent or untrained independent mount keeps its own agency. Ownership, restraint and payment do not establish willingness or training.

A conscious, nonincapacitated seated rider can direct intended movement and choose the controlled mount's one allowed Action: **Dash, Disengage or Dodge**. Use an actual trained audible or tactile channel. An audible cue shares the language rules' speech allowance. Reins require an available hand; a trained seat/leg cue works only if that individual knows it and the current seat permits it. Ordinary riding direction adds no separate Bonus Action. It does not issue a class companion command, authorize an attack or transfer rider bonuses to the animal.

A controlled mount with its own regular turn counts toward the controller's existing limit of two commanded independent-turn combat-capable subordinates. The controller's own character is separate. A source-bound companion with only an attached phase retains its own command and offensive budgets; calling it a mount does not give it a full turn. Additional pack animals can be led outside combat through real handling, but do not give a third controlled combat turn. There is no automatic animal swarm.

An independent NPC acting as a party character counts toward the twelve-character roster. A merely ridden animal does not occupy a member seat, although its actions, cargo, provisions and history still matter. Independent animals are directed by their real agency, not treated as free player attack orders.

Recheck control when the mount acts. If the rider is no longer seated or able to cue it, the channel fails, or the mount is unable or unwilling, an unexecuted riding cue cannot compel it. If able, it defensively Dodges and stays still or moves only to an immediately safer available space, chosen through its actual agency. Its existing turn and spent budgets do not reset. An executed cue is not undone. A legitimate trained noncombat lead/follow cue can continue only while its actual conditions and handler remain available.

**New ordinary training course.** A genuinely tame, willing animal can learn one named riding or harness function through 40 active hours, at most four credited training hours per animal per day. The instructor needs Animal Handling proficiency, a suitable safe space, fitting tack and a usable conditioning method. Credit complete 15-minute phases. An interruption loses unfinished prospective phase credit; actual time, feed and fees remain spent. The full-course tuition reference is 5 gp, unless an actual voluntary or paid agreement differs.

Completion requires the real course and demonstrated safe routine behavior. It grants only the practiced function, without an obedience spell, rider proficiency or Ranger bond. A documented already-trained animal needs no repeat course. Wildness or unwillingness cannot be cured by depositing hours. A war-named purchase includes combat habituation only if its actual contract and behavior establish it. Feed, water, tack and stabling are separate unless genuinely included.

## One complete mount turn

At initiative registration, a controlled mount shares its rider's initiative value and takes one complete regular turn immediately **after** the rider's complete regular turn. Their movement and Actions do not interleave. You cannot move the mount twenty feet, insert a free rider attack segment, then finish the mount's movement.

You may Ready a permitted Action through the normal procedure, paying your Action and later Reaction, with its actual trigger, components and duration. This creates no free attack. An independent mount keeps its own initiative and choices.

The mount has its own regular-start/end markers, movement, normal Action and applicable Reaction budget. Its controlled Actions remain Dash, Disengage and Dodge. Control grants no offensive Reaction or opportunity attack; a specific defensive Reaction works only if actually available. It makes its own death saves when its lifecycle requires them. A rider's extra turn does not create another mount turn, start, recharge or condition tick.

Each physical actor receives at most one scheduled regular turn per numbered round. Mounting, dismounting or changing controllers retains its spent budgets and original allocated slot for that round. A new valid controlled relation takes its new rider-linked position beginning next round. This round, use the existing unspent slot if any; never replay a taken one.

A mount entering mid-round uses a legal not-yet-passed insertion under the combat-entry rules, or starts next round. It does not replay the new rider's earlier slot. Changing to independent behavior also grants no second turn. Separate rider and mount effects still expire at their own stated markers even when initiative values match.

## Mounting, dismounting and losing the seat

An ordinary mount or voluntary dismount costs half your current walking Speed, rounded down in feet, from your remaining regular movement. A positive Speed whose half is below one instead costs one foot. Speed 0 does not permit it. You may perform at most one mount **or** dismount operation per regular turn; an extra turn supplies no additional operation through this rule. The cost is movement, not a Bonus Action or free object interaction.

Start within five feet of the accessible seat at a reachable height, with a stable approach, one usable supporting hand and a physically fitting destination. A high Elephant saddle needs actual steps, help or a legal route to reach it; an exotic saddle does not lift you. If Prone, first stand using the real cost or use another valid assisted procedure. Mounting does not remove Prone.

To dismount, choose a visible, free adjacent space within five feet of the relevant body boundary at a reachable level. A wall, another creature, an inadequate gap or an unpaid fall is not a legal destination. Insufficient remaining movement or an inaccessible seat prevents the ordinary operation. A specific acquired feature overrides only its actual clause. The animal's remaining movement and Actions stay unchanged.

When one resolved source event moves a seated rider's mount against its will **or** knocks it Prone, the rider makes one DC 10 Dexterity saving throw. If that same event does both, make one save. Distinct events can each trigger a save. This is a binary Core save with no generic natural 1/20 degree shifts.

On failure, leave the seat and land Prone in the first legal adjacent space from your recorded dismount preference, or the Director's neutral accessible ordering. Resolve actual height and falling under the falling rules; unseating adds no fixed damage by itself. On success, retain the seat only if support remains physically possible.

A Prone mount does not automatically make its successful rider Prone, but its awkward body and blocked movement still matter. A rider independently made Prone gains that condition without another seat save. Voluntary ordinary travel alone causes no save. If an exact effect ejects you regardless of a save, use that effect and the actual landing. Impossible support or landing resolves through the real fall/entrapment situation, never placement inside a wall.

## Position, areas and opportunity attacks

Record the rider's actual saddle point or fitting five-foot subspace on the mount before movement. Attacks, reach, line of effect and area exposure use that position, not every edge of an Elephant's footprint. Moving to another accessible seat position takes your own real movement, path and support.

Rider and mount remain two creatures with separate AC, HP, conditions and resources. An area can affect both if it actually includes each; resolve separate saves and damage histories. Riding grants no automatic cover, shared HP or immunity. Actual barriers and body geometry can supply cover under the normal rules.

When the mount's own voluntary movement provokes a legal opportunity attack, the reactor may choose the mount **or** rider. The chosen target must actually be visible and within legal reach/line at the departure edge. Spend one available Reaction for one permitted ordinary attack before completing that departure step. One provoking move is not an attack on each creature, and a distant rider's seat does not become reachable merely because the mount is adjacent.

The mount's Disengage prevents the opportunity provoked by its movement, including this rider-or-mount choice. The rider's own Disengage protects the rider's own voluntary movement; it does not give the mount Disengage. Your own movement around the seat or while dismounting uses your own opportunity-attack rules.

Forced displacement or teleportation does not provoke a generic movement opportunity attack, although an actual seat-save trigger or other specific effect may apply. An attack against the mount does not automatically damage or unseat its rider; its actual consequence must trigger that result.

Vehicle carriage does not use this living-mount exception. Passive displacement of vehicle occupants gives no generic opportunity attack without a specific source. Moving pullers can provoke for themselves, without granting an attack through a wall against a distant passenger.

## Movement belongs to the actor who performs it

Riding changes your position, but it does not automatically spend your movement, perform your leap, count as your flight or charge, deal your weapon damage or activate a class feature. Track who moves under their own power, who is carried, the path, forced or teleport displacement, the budget spent, and whose turn it is. A rule asking whether someone is within a distance still uses actual positions.

Cavalry and Mounted Combatant remain separate pending feats. Ordinary riding grants neither their attack advantages nor Cavalry's +10 mount Speed. Their different prerequisites and attack scopes are not merged or assumed to stack.

Dragoon Momentum keeps its actual engine: genuine self-powered movement of at least 15 feet toward a tactical destination on the Dragoon's regular turn supplies its one movement gain; a qualifying personal weapon-damage event supplies the other default gain. All gains and refunds remain capped at two per round. Being carried, forced movement, teleportation, movement in place, allies, summons or another actor's hit does not qualify. A mount's leap is not the Dragoon's paid leap technique.

**New narrow transport interpretation:** the Dragoon's separate requirement to move at least twenty feet on its turn before a Weave cast counts actual voluntary self-propelled path, including a legitimately paid source leap. It excludes carriage, forced movement and teleportation. Keep the actual before-cast window and the Dissonance reduction of one, minimum zero. It grants no RP discount or additional Momentum.

Other class, oath, ancestry, spell and companion movement rules retain their exact acquired effects. This interpretation does not rewrite every distance condition or prohibit an actual feature expressly benefiting passive carriage.

## Tack, food, water and boarding

Use the catalogue's actual tack profiles and fitting times. These new empty masses are separate from the old blank source weights:

| Tack | Empty mass |
|---|---:|
| Bit and bridle | 2 lb |
| Exotic saddle | 36 lb |
| Military saddle | 24 lb |
| Pack saddle | 15 lb |
| Riding saddle | 18 lb |
| Saddlebags | 4 lb |

These ordinary tack bodies have AC 15 and 5 HP. Saddlebags contain two actual cells of 20 lb and 0.5 cubic feet each, for 40 lb and one cubic foot total. Fit, balance, closure and shape still matter; they add no carrying capacity to the animal. A pack saddle is a load frame, not a rider seat. Military or exotic names grant no feat, seat-save advantage or fall immunity.

Fit equipment to the named animal's current anatomy. A new draw harness costs 5 gp and weighs 8 lb per compatible Medium/Large puller; the Huge version is 20 gp and 32 lb. Each has AC 15, 5 HP and five-minute setup. A bridle is not a complete draw harness. An actual purchase already including the fitting harness need not buy it again.

**Barding.** Choose an actual reviewed ordinary armor model. Its price is four times that baseline, replacing rather than compounding the general Large price multiplier. New mass multipliers are ×2 Medium, ×4 Large and ×8 Huge; armor HP multipliers are ×1, ×2 and ×4 respectively. Use that armor's real AC formula, Dexterity cap, Strength requirement and Stealth penalty. Choose between eligible armor and natural-AC formulas; do not add them together. Different grades or magic require their own real records.

New armor habituation takes eight active hours for one named armor category, at most four credited animal-training hours/day, in completed fifteen-minute phases. It requires a tame, willing, trained mount, fitting armor, a competent Animal Handling instructor and actual suitable work. Ordinary full-course tuition reference is 1 gp or the agreed rate. It grants only safe ordinary wearing competence, not rider proficiency or immunity to armor restrictions. Previously documented training needs no repeat course. Donning/doffing takes the actual armor time and a capable helper; changing form does not resize armor.

**Provisions.** The printed 5 cp daily feed reference buys one actual species-compatible animal-day quantity from the catalogue: Camel 12 lb, Donkey/mule 10, Elephant 60, Draft horse 16, Riding horse 12, War horse 16, Mastiff 2, Pony 8, Warhound 3. This is an explicit provisional price/quantity choice. Actual compatible stock is required. Water is separate: respectively 32, 24, 128, 40, 32, 40, 8, 16 and 12 pints/day, with real containers and weight. These replace the human Supply basket for those animals; add no human oil ration or free desert-fasting trait. Unmet daily food/water causes at most one ordinary expedition Strain for that day, not a duplicate for each missing component.

**Stabling.** Five sp/day buys one actual fitting safe stall or pen for 24 hours, ordinary supervision/cleaning and ten active caretaker minutes per animal-day. Food and water are separate unless the real quote includes their quantities. A small stall cannot accommodate an Elephant because the posted price was paid. Real suitable rest can qualify normally; payment does not heal, cure, refill Hit Dice or grant a second Long Rest. Emergencies and treatment require their actual additional work.

## Drawn vehicles and the two sleds

The catalogue supplies five distinct new frames: Carriage 100 gp, Cart 15 gp, Chariot 250 gp, Player Sled 20 gp and Wagon 35 gp. The Cart retains its reviewed 30 structural HP. The other body quantities, geometry and handling values are explicitly new. Purchase does not automatically include animals, harnesses, drivers or contents.

The Core Dungeon sled is a separate 25 gp, two-operator item. Its new frame weighs 60 lb and has 30 HP/AC 15, a 6×3×2-foot outer envelope and 5×2.5×1.5-foot bed. Normal payload is 12 Load/120 lb; emergency maximum is 20 Load/200 lb at drag Speed 5 if the real two workers and route can support it. It does not replace the Player snow/ice sled or inherit that sled's animal-drawn profile.

For every frame, check empty mass, full payload pounds and Load, cargo sublimit, seats, draw-team requirement and actual passage geometry. A passenger uses a real seat and counts body, gear and passenger Load. Luggage capacity is part of total payload, not extra. Cart's normal payload limit is 30 Load, Wagon's 80; their empty frame masses are additional support/draw burden.

Only compatible, trained, simultaneously working pullers with fitting harness can combine their explicit gross draw ratings. Gross draw means vehicle plus payload, occupants and attachments. The pullers' own body masses are not part of draw weight, but every animal still counts against a bridge or floor's support. Each puller's own carried burden is checked separately. Above half the combined gross draw rating causes one Burdened speed penalty; above the full rating prohibits routine draw. A check does not waive stairs, gaps, blocked widths, incompatible slopes or terrain.

**New tactical driving procedure.** The actual driver spends an Action through a usable control channel, with reins/controls and one available hand. Required pullers reserve sufficient real movement from their legal turns in the same round. Resolve one coherent vehicle/puller movement after the last required contribution is available, rechecking bodies, load, harness and path. Earlier reserved movement cannot also be spent elsewhere. Consume each contribution once. Motion is limited by the slowest current puller budget/Speed and the vehicle cap.

No future Action is presumed. A later incapacity or broken harness can prevent motion while already spent Actions remain spent. Extra Actions, another driver or another puller do not create a second drive event in that numbered round. The frame has no native Dash, Disengage, Reaction, weapon or attack. Pullers retain only their own actual creature actions and command limits.

Outside initiative, the driver and pullers work for actual travel time. Harnessing takes five active minutes per vehicle with actual workers; loading is separate. Independent workers can fit separate harnesses concurrently where feasible. A moving ninety-degree turn requires clear swept space and at least one vehicle-length of forward travel. Brakes allow an ordinary controlled stop; steep slopes or failed brakes need their actual hazard resolution.

A routine clear feasible road needs no check. For an uncertain driving hazard use DEX with Vehicles (Land), or WIS (Animal Handling) for an animal-response problem, one proficiency once. Use the hazard's DC, or the new references 10 ordinary, 13 hard, 16 severe. Declare consequences first. Success avoids the stated obstacle; a critical adds only declared feasible positioning. Failure stops safely if possible; otherwise an actual bounded low-speed collision deals 1d6 bludgeoning to the frame, or 2d6 on Critical Failure. These fallback packets do not replace specific high-speed, falling or passenger-injury rules.

## Watercraft need working crews

The catalogue supplies six complete provisional watercraft: Galley 30,000 gp, Keelboat 3,000 gp, Longship 10,000 gp, Rowboat 50 gp, Sailing ship 10,000 gp and Warship 25,000 gp. Their new bodies specify mass, AC 15, structural HP, hull/mast envelope, draft, hold shape, payload, occupants, crew, Speed and repair. A name or price includes no crew, weapons, cargo, berth, lifeboat or feasible route.

| Vessel | Active oar crew, including helm | Active sail crew, including helm |
|---|---:|---:|
| Galley | 41 | 8 |
| Keelboat | 3 | 3 |
| Longship | 11 | 4 |
| Rowboat | 1 | No sail mode |
| Sailing ship | No oar mode | 8 |
| Warship | 21 | 10 |

These are simultaneous real workers in their actual positions. Only the Rowboat combines helm and oar in one person's Action. A person's Action cannot fill two other crew jobs. Replacement crew take over prospectively; they do not supply a missed past stroke. Actual training, appendages and tools still matter. Calm ordinary rowing can be physically attempted untrained without an automatic penalty; a hazardous helm needs the specified trained operator and actual procedure.

Large public-service crews may exist outside the twelve-character party, but remain separately paid, supplied, rested staff. They are not free party helpers or recruited combat allies. Owning a ship with too few personnel does not operate it.

**Tactical movement.** One vessel drive event per numbered round resolves only after the current helm Action and every required propulsion/rigging Action for the selected mode are available. Recheck feasibility after the last contribution. Actions already spent remain spent if a later blocker prevents the event. Extra Actions, turns or helm changes do not grant a second drive. Working crew cannot also use those Actions to attack, Help, guard, command a different device or claim rest. The hull has no creature turn, save, Reaction, Dash, Disengage or creature-condition clock.

**Travel.** Use the catalogue's mph per active staffed travel hour. A stated sail mode needs usable wind and course: no usable wind means zero sail self-propulsion. Adverse but usable wind halves the sail rate unless a specific weather rule says otherwise. Oars need their full crew. Record current as an actual separate vector. A countercurrent can reduce along-route progress to zero while drift still changes position. Missing weather/current information is unknown; only a stated synthetic example may assume calm/current zero. An uncrewed ship can drift under real forces without receiving a free commanded move.

Check total payload and cargo sublimit separately, including all people, their gear, ballast and containers once. Occupant limits still apply to magically light passengers. Require draft plus half a foot of water clearance at allowed payload, the full hull/mast passage and clear swept turn space.

Docking takes one minute for a Rowboat, five minutes for the others, with actual bank/berth, lines, water and workers. Loading is additional. A ninety-degree moving turn requires one hull-length of forward travel and clear sweep; a feasible stationary line/anchor maneuver takes ten crew minutes. Lowering an actually lowerable mast takes twenty active crew minutes and retains the real lowered mast aboard with its clearance.

Hazardous charting uses INT and hazardous helm work DEX with Vehicles (Water), one proficiency once. Use the actual source DC or 10 ordinary/13 hard/16 severe. Routine feasible calm work needs no roll. Declare drift, grounding and obstruction stakes first. Failed bounded low-speed contact stops/grounds where possible, otherwise deals 1d6 hull bludgeoning; Critical Failure deals 2d6 or the declared actual severe hazard, not both by default. Creature harm, drowning, falling and exposure use their own rules. Hull HP 0 follows the finite flooding/rescue procedure below.

## Porters, bearers and hired pack animals

| Service | Contracted customer cargo | Base daily price |
|---|---:|---:|
| Porter | 2 Load | 2 sp, plus agreed danger pay |
| Skilled bearer | 3 Load | 1 gp |
| Pack-animal hire | 6 Load | 5 sp, plus feed |

These are customer allowances, not a biological capacity increase. Name the actual worker or animal and check their own gear plus the promised cargo against their real pounds, Load, shape, fatigue and terrain limits. A stronger porter does not automatically owe more work; extra carriage needs a feasible amended agreement.

Core's porter safe 2/maximum 4 and pack-animal safe 6/maximum 10 Load describe emergency offer limits. Extra loads require an expressly accepted feasible operation, with actual burden/drag penalties and risk. They never override the individual's body limits or grant free overflow.

A bought Camel, mule or other mount keeps its own complete profile. A hired six-Load service must provide one identified suitable trained animal; it is not an interchangeable invisible body. Record the operator separately. Hire does not include a human handler, saddle, water, feed or stabling unless the real agreement includes them. Do not charge both purchase and hire for the same delivered ownership interest. Late-return or loss liability must be agreed, not invented from the market price.

A service day is 24 elapsed hours of custody with at most two eight-hour assigned work Watches and actual Rest. Charge a started day once under the agreement; loading again or crossing a Haven gate does not restart the bill. The named service rate takes precedence over generic wages. Accepted dangerous duty defaults to twice that rate once, unless a different prospective agreement applies. Work already performed earns its agreed wage even when a task fails; refunds and liability follow the actual contract.

People hired into ordinary expedition jobs count toward the twelve-member roster. A public carrier's external crew stays on its service roster and supplies no free party jobs. Record consent, duties, knowledge, communication, pay, supplies, HP, Strain, rest, custody and departure. A wounded, exhausted or absent provider requires a real replacement and transfer; treating someone as cargo does not compel obedience.

## The bound hauler and specialist services

**Core transport hauler.** The retained reference is 500 gp plus fuel, with actual Tier-IV-or-higher availability, 20 normal Load and 30 emergency maximum. The new complete profile is a separate transport-only magical nonartifact machine. It is not a creature, summoned body, class companion, AEX automaton, recipe 507/670 or PC. It has no CR, mind, creature turn, attack, spell, RP, corpse/drop or class-command entitlement.

Its empty 120 lb wheeled frame measures 5×3×4 feet with a 4×2×2-foot clear bed, AC 19 and 60 maximum structural HP. Normal payload is 200 lb/20 Load at Speed 30 feet/3 mph. Over either normal rating, emergency carriage is limited to 300 lb/30 Load at Speed 5 feet/0.5 mph. Shape, full supported gross weight and a clear firm route remain necessary; never exceed either emergency maximum.

One real adjacent operator within five feet, with access to the controls and both manipulating hands, spends an Action for one drive event per numbered round, moving at most its current Speed over a feasible path. It cannot Dash, climb, fly, use stairs, act remotely or run an autonomous program. Another Action cannot buy another drive. Outside initiative the operator works continuously. Being aboard does not help if the controls are out of reach. This local mechanism is distinct from TI04's binding, channel and shared offensive-device budgets.

**Fuel.** One actual compatible lamp-oil pint, reference 10 cp/1 lb, powers eight accumulated active propulsion hours. The reservoir holds one pint. Consume exact proportional fuel as it actually operates; pauses consume no propulsion fuel, while leaks/losses persist. Refilling a stationary machine takes one active minute, two hands and available oil. Purchase creates no free oil or flask. Oil already spent for propulsion cannot also light a lamp or remain unspent Supply. This power grants no transferable energy, RP, distillate or spellcasting.

**Service.** At each forty accumulated moving hours, service is due before further propulsion. On the stationary serviceable mechanism, a qualified Vehicles (Land) or appropriate Tinker's-tools practitioner spends one active hour, suitable tools and one actual 1 gp/0.5 lb grease/fastener pack. Routine completed service needs no check. It clears only the due-service counter, restoring no HP, fuel or lost part. An interrupted service retains completed work but provides no completion until finished; it is not rest. A differently named AEX pack is not interchangeable without real compatible quantities.

**Restoration.** This hauler's explicit new magical repair bridge uses actual compatible materials at a 125 gp reference and qualified Vehicles (Land)/Tinker's tools. Positive-HP functional repair takes six active hours at DC 10. HP-0 reconstruction takes eight active hours at DC 15 and requires the original primary frame, drive unit and controller. Use Core task degree shifts, collapsing to success/failure without extra critical effects. Success restores this body's maximum HP/function only. Failure spends work and materials. Subordinate wheels, straps and fasteners can be replaced with real stock; missing primary assemblies or terminal dismantling cannot be recreated by payment. Fuel, service history, ownership and closed claims do not reset.

**Gate caravan.** The retained 100+ Load/10%-of-cargo-value reference is a real large service. Its quote must state a finite offered capacity of at least 100 Load, pounds and geometry, occupants, actual journey/route, staff, containers, custody, appraisal base, danger and schedule. Paying the fee does not cross a restricted Gate or move cargo. Staff do not become free expedition combat support.

**Teleport extraction.** The reference is Tier×100 gp for each accepted Extraction Load. The new default rounds the accepted positive total upward to a whole Load once per commissioned bill, unless an actual finite source contract states another rule. Execution still needs a currently operative acquired effect with its full endpoints, range, person/object/mass/volume limits, consent, access, costs and containment. A price table supplies no spell or destination permission. Without that particular procedure/endpoint, that service is unavailable; ordinary transport remains usable.

## People, stretchers and cargo transfers

A passenger remains an actor. Check the actual seat/occupant geometry, total effective pounds and separate passenger/casualty Load:

| Body size | Passenger/casualty Load |
|---|---:|
| Tiny | 1.5 |
| Small | 3 |
| Medium | 6 |
| Large | 12 |
| Huge | 24, a new completion for these profiles |

Voluntary seated passengers use these burden units without losing their agency or ability to act/exit. A walking crew member does not count as a passenger on someone else. An animal aboard a ship contributes its full body mass and carried cargo once, as well as its passenger Load; a 5,000 lb Elephant is not weightless because it has 24 Load.

An external carrier counts effective body weight and all associated equipment, including melded equipment, once. Petrified multiplies base-body pounds by ten once, without multiplying gear or casualty Load. Personal transformed inventory uses its own different meld rules. One bag cannot be both omitted and treated as a separate extra copy. Count actual blankets, harnesses, frames and containing vehicles. Preserve a source's explicitly approximate ten-pounds-per-Load fallback as an estimate, never relabel it as measured weight or discard known pounds.

**New ordinary stretcher.** The 5 gp, 10 lb frame measures 7×2.5×0.5 feet, with AC 15/5 HP. It supports one fitting Small/Medium patient, with a 300 lb payload limit including their gear and a six-casualty-Load body limit. The frame's own mass is additional carrier burden. Two carriers each need both hands. Assign actual shares before lifting, normally half the combined stretcher, patient and gear to each; each carrier's own gear plus share must fit both limits and their actual supporting position. Shares total exactly the one burden, including equipment Load separately from casualty Load. Coordinated Speed is the slowest eligible carrier after burden, terrain and Strain; one carrier's Dash does not pay the other's movement. A bigger casualty needs a fitting platform/team or exact effect.

**Calm transfers.** One active minute handles one actual discrete fitting bundle of up to 50 lb. An indivisible heavier object needs enough carriers/hoist/support and a declared positive duration for its real feasible lift; it is not divided into fictional fifty-pound slices. A supported person or ordinary mount transfer takes two active minutes, plus real ramp/securement work. Assembling the stretcher takes one minute. Harnessing and seat fitting have their own additional time. Independent workers can handle disjoint loads concurrently; incompatible pulls on one load do not.

Existing shorter access/retrieval procedures remain where genuinely applicable. In initiative, each actual attach, lift or transfer step uses Secure Cargo or another appropriate Action, with the necessary bodies, hands, access and checks. A two-minute calm transfer is not a promise to finish any battlefield lift with one Action.

Safe cooperative transfer can need no roll. A ledge, enemy interference, resistance or inadequate control uses its actual check, contest or attack with declared consequences. Loading does not grant permission for restraint, surgery or a willing-target spell. Unconsciousness, Prone, dying, Wounds and death/stabilization clocks continue during carriage. A belt applies only its real restraint effect, not universal fall protection. Record the actual sender, receiver, location and body/item identities; custody changes do not renew material age or harvest claims.

## One route rate, with real transfers

Route quality, mapping knowledge and Risk are separate. A well-mapped collapsed bridge remains physically collapsed.

| Physical route quality | Travel-time multiplier |
|---|---:|
| Secured | 0.75 |
| Known | 1 |
| Contested | 1.25 |
| Collapsed | 1.50 |

For the ordinary route-work tranche, use:

`480 active minutes × physical quality × (3 ÷ limiting convoy mph)`

An explicit route mode/duration can replace that reference only through its actual rule. The forced Unknown march's nominal 480-minute attempt uses this same normalization, not an additional eight hours or an unadjusted fast pace. Do not award both a route-progress result and a second distance from those same hours.

For these creatures, ordinary travel mph is current otherwise-legal walking Speed divided by ten, after applicable burden, injury and environmental modifiers. Apply the reviewed Strain-5 half-travel penalty once. Watercraft use the actual available propulsion/current ground rate. The convoy is limited by its slowest necessary moving member, puller or carrier. A passenger contributes the carrier's movement, not their own Speed.

An essential stopped, overloaded or unavailable carrier stops convoy progress until a real transfer, repair or route change. Leaving it behind is an actual split or abandonment. A Speed change affects only the remaining route work; preserve completed distance/fractional progress.

The source Secured −1 and Contested +1 threat modifiers adjust effective Pressure for the **single ordinary travel complication check**, clamped 0–6. They do not change stored Pressure or cause another roll. Collapsed adds the actual physical obstacle's +3 difficulty where that obstacle exists. The extraction checkpoint's specific secured −2/pursuit/exposure formula remains separate; do not add a second route modifier for the same secured condition.

Core's Known one-Load, Contested 10% and Collapsed 20%-or-reroute losses are possible predeclared stakes, not automatic additional penalties on a complication or failed extraction check. Choose the consequence model beforehand. A declared percentage uses the current at-risk manifest and actual eligible lots/portions in a predeclared priority, with permitted unit rounding. Never delete part of a person or indivisible object to satisfy the fraction. Unachievable remainder is not banked. Secured's “none” removes that routine table-loss rider, not actual separate danger.

Changing mount, cart or ship takes a real transfer interval with receivers, crew and route ready. Retain Extraction Class, title, custody, material age, identity and closed claims. A transport-mode rename does not cross a checkpoint again. A genuinely new border, exit or handover can be its own declared finite checkpoint.

## Recover living creatures; repair actual structures

Living mounts use creature healing, HP, Hit Dice, Wounds, injuries, conditions, rest eligibility, nutrition and their actual lifecycle. Healing can end dying only as its procedure permits. Repair work, a quarter-price bill, insurance, stabling or buying another animal does not revive the dead individual. The ordinary significant-mount default remains distinct from a Ranger Beast's HP-only exception and finite creations. Actual remains use existing once-only harvest rules, not a resource yield invented from price or carrying capacity.

Objects use structural HP and their real material/object defenses. They receive no creature Wounds, death saves or parallel duplicate Integrity penalties.

For a positive-HP or genuinely reparable mundane HP-0 main body, trained appropriate-tool self-repair uses actual compatible materials at 25% of the applicable undamaged mundane body reference, DC 10, and active work of `max(1 hour, recorded maximum HP ÷ 10 hours)`. Apply Core task shifts with the upper two degrees as success and lower two as failure, without extra critical benefits. A 300-HP hull therefore takes thirty active hours, not one Watch or thirty independent restorations.

The worker needs the actually appropriate carpenter, smith or vehicle tools and a workable supported/dry site. A complete qualified service quote at the source's 10%/15% price is alternative pricing, not another 25% material charge. Recipe-magical equipment keeps its own reviewed procedure; the Core hauler uses its specific new repair bridge above.

Success restores the same body's HP to its existing permitted maximum/function. It does not recreate missing primary structure, restore cargo, fuel, charges, service credit, magical imprint, flaws or closed claims unless an actual rule expressly does so. Compatible subordinate parts use actual stock once; the profile's required original primary members must survive. Failure spends actual materials and work. Another permitted attempt requires new inputs, not a free reroll. Terminal dismantling is not merely HP 0. Custody, material age and source clocks continue during repair and storage.

Drawn frames and the hauler at HP 0 are disabled and strand their real load. Unload, transfer, support or tow only through a feasible method. Occupants are not automatically damaged solely because structural HP reaches zero.

**New afloat-hull emergency.** Without a specific different destruction source, a watercraft reaching HP 0 becomes disabled and starts one ten-minute flooding/evacuation deadline. At that deadline its wreck becomes submerged or stranded according to the real depth and support. It is not deleted, and occupants use actual escape, falling, swimming and drowning rules.

Once per actual hull-breaking episode, two capable workers, at least one trained with carpenter's tools or Vehicles (Water), can spend five uninterrupted active minutes and real compatible patch/bracing supplies at 1% of the undamaged body reference, minimum 1 gp. The work must finish before the flooding deadline. Make the appropriate DC 15 tool task using Core shifts collapsed to success/failure. Success holds that same disabled hull afloat for sixty minutes from completion, without restoring HP or propulsion. Failure spends work/materials and leaves the original deadline. Repeating the label cannot reset the same rupture or bank more time.

Real grounding, docking, towing or a hoist can support the still-present wreck for full repair. Rescue uses actual people, tools, locations, mass, Actions and time. It creates no lifeboat, fresh crew, stretcher, survivor or recovered property. Apply ordinary cargo rescue where appropriate and encounter procedures under actual threat. Insurance pays only an eligible recorded loss; it does not automatically repurchase inaccessible unique bodies.
