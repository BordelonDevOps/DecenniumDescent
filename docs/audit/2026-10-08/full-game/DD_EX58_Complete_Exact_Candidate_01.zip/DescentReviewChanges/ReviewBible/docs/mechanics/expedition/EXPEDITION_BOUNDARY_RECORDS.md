# Expedition boundary records

Full concrete fixture records for EX-W01–28. The accompanying public walkthrough explains each result. Original source versions and full selected recipe, spell, class and transport dependencies are preserved in the internal JSON. These are authored expectations with finite reference calculations; they do not certify a runtime or human balance.

## EX-W01 — Interrupted crafting and a travelling team

The disturbance erases 3 hours 45 minutes of the unfinished phase, while the first 15 minutes survive. The legal completion is 11:45:18, not the first Watch boundary. The guard and travelling team supply no remote crafting help. The result uses the actual manufacturing bands.

```json
{
  "id": "EX-W01",
  "schemaVersion": "EX58-boundary-record-v1",
  "status": "authored synthetic expectation; exact review pending",
  "audience": "public synthetic example",
  "title": "Interrupted crafting and a travelling team",
  "questionIds": [
    "FL-01",
    "FL-02",
    "FL-03",
    "FL-24"
  ],
  "contractIds": [
    "EC-01",
    "EC-02",
    "EC-03",
    "EC-14"
  ],
  "sourceBinding": {
    "path": "docs/audit/2026-10-08/full-game/ex58-final-gpt-verdict/EX58_WORKED_SEQUENCES.json",
    "bytes": 73808,
    "sha256": "f668c9aff1c836f61e5766db3eed49d62ba2f1a6d638959157e5551223aa2c80",
    "pointer": "/additionalBoundaries/0"
  },
  "actualSyntheticPremises": "Eight members share one clock. A has the real recipe, materials, permitted station and own tools; B guards. The other six are actually elsewhere.",
  "records": {
    "roster": [
      "A",
      "B",
      "C",
      "D",
      "E",
      "F",
      "G",
      "H"
    ],
    "campWorkers": [
      "A",
      "B"
    ],
    "travellingCharacters": [
      "C",
      "D",
      "E",
      "F",
      "G",
      "H"
    ],
    "workerA": {
      "EnchantingLevel": 4,
      "INTModifier": 3,
      "toolPB": 2,
      "ForgeDwarf": false,
      "assistants": []
    },
    "workOrder": {
      "id": "W01-order",
      "recipeId": "recipe-122",
      "station": "actual permitted fixed Resonance Circle at Fortified site",
      "tools": [
        "Enchanter's tools",
        "Focusing lens",
        "Inscription stylus"
      ],
      "formulaAccess": "owned authentic established formula; no acquisition inferred from item name",
      "bodyReserve": [
        {
          "id": "W01-chain-shirt",
          "model": "EN-armor",
          "size": "Medium",
          "grade": "Standard",
          "HP": 15,
          "maxHP": 15,
          "massLb": 20,
          "everMagicallyAltered": false,
          "complete": true
        }
      ],
      "componentLots": [
        {
          "id": "W01-matrix",
          "name": "Stabilizing matrix",
          "quantity": 3
        },
        {
          "id": "W01-crystal",
          "name": "Luminous Crystal",
          "quantity": 4
        },
        {
          "id": "W01-goo",
          "name": "caustic goo",
          "quantity": 1
        }
      ],
      "materialHistory": "Finite qualifying original inputs reserved once. Completed incorporated first-phase inputs stabilize; remaining real stock stays in its adequate declared containment. No new ingredients arise from interruption."
    },
    "intervals": [
      {
        "startSeconds": 0,
        "endSeconds": 900,
        "actors": [
          "A"
        ],
        "activity": "complete stable first phase",
        "activeSeconds": 900,
        "clock": "case-local canonical clock, seconds; half-open"
      },
      {
        "startSeconds": 900,
        "endSeconds": 14400,
        "actors": [
          "A"
        ],
        "activity": "unfinished second phase",
        "activeSeconds": 13500,
        "clock": "case-local canonical clock, seconds; half-open"
      },
      {
        "startSeconds": 14400,
        "endSeconds": 14418,
        "actors": [
          "A",
          "B"
        ],
        "activity": "actual three-round disturbance",
        "activeSeconds": 18,
        "clock": "case-local canonical clock, seconds; half-open"
      },
      {
        "startSeconds": 14418,
        "endSeconds": 42318,
        "actors": [
          "A"
        ],
        "activity": "repeat the interrupted 465-minute second phase",
        "activeSeconds": 27900,
        "clock": "case-local canonical clock, seconds; half-open"
      },
      {
        "startSeconds": 0,
        "endSeconds": 28800,
        "actors": [
          "B"
        ],
        "activity": "guard except actual disturbance; no craft credit",
        "activeSeconds": 28800,
        "clock": "case-local canonical clock, seconds; half-open"
      },
      {
        "startSeconds": 0,
        "endSeconds": 28800,
        "actors": [
          "C",
          "D",
          "E",
          "F",
          "G",
          "H"
        ],
        "activity": "actual separate travel",
        "activeSeconds": 28800,
        "clock": "case-local canonical clock, seconds; half-open"
      }
    ],
    "phaseLedger": {
      "firstPhaseRetainedSeconds": 900,
      "unfinishedPhaseLostSeconds": 13500,
      "secondPhaseRequiredSeconds": 27900,
      "progressAtFirstWatchEndSeconds": 15282,
      "completionSeconds": 42318,
      "totalActualCraftSeconds": 42300
    },
    "completionRoll": {
      "natural": 10,
      "INT": 3,
      "PB": 2,
      "DC": 12,
      "total": 15,
      "margin": 3,
      "native": "six manufacturing bands, no Core natural shifts",
      "outcome": "Standard",
      "outputCount": 1
    },
    "resultBody": {
      "sameIdentity": "W01-chain-shirt",
      "activeBeforeCompletion": false,
      "newBodiesCreated": 0,
      "initialChargesAtActualCompletion": 1,
      "enhancement": 1,
      "damageType": "acid",
      "quality": "Standard"
    },
    "communication": {
      "reportAt28800ReceivedInCamp": false,
      "methodNotProvided": "no telepathic or notebook communication assumed"
    }
  },
  "expectedOutcomes": {
    "completeAt8h": false,
    "completedFirstPhaseSurvives": true,
    "finishesAtSeconds": 42318,
    "offscreenCombatantsAdded": 0
  },
  "readerExplanation": "The disturbance erases 3 hours 45 minutes of the unfinished phase, while the first 15 minutes survive. The legal completion is 11:45:18, not the first Watch boundary. The guard and travelling team supply no remote crafting help. The result uses the actual manufacturing bands.",
  "evidenceClass": "authored expectation; named source and arithmetic checks separately executed",
  "worldAuthentication": "All named people, sites and permissions are synthetic premises, not new canonical facts."
}
```

## EX-W02 — Rest debt without another refill

Eight real safe hours clear the debt. Only 12 hours have elapsed since the prior beneficial completion, so HP and RP do not refill. Re-reading the same unpaid deadline adds no further Strain.

```json
{
  "id": "EX-W02",
  "schemaVersion": "EX58-boundary-record-v1",
  "status": "authored synthetic expectation; exact review pending",
  "audience": "public synthetic example",
  "title": "Rest debt without another refill",
  "questionIds": [
    "FL-03",
    "FL-04"
  ],
  "contractIds": [
    "EC-02",
    "EC-03"
  ],
  "sourceBinding": {
    "path": "docs/audit/2026-10-08/full-game/ex58-final-gpt-verdict/EX58_WORKED_SEQUENCES.json",
    "bytes": 73808,
    "sha256": "f668c9aff1c836f61e5766db3eed49d62ba2f1a6d638959157e5551223aa2c80",
    "pointer": "/additionalBoundaries/1"
  },
  "actualSyntheticPremises": "A prospective Rest slot is 16–24h. Actual safe support is available. A prior beneficial Rest completed at hour 20; the owed scheduled slot was nonetheless missed.",
  "records": {
    "actor": "Iria",
    "openingState": {
      "HP": 8,
      "maxHP": 20,
      "RP": 2,
      "lastBeneficialEnd": 72000
    },
    "scheduledSlot": {
      "startSeconds": 57600,
      "endSeconds": 86400,
      "actors": [
        "Iria"
      ],
      "activity": "scheduled but unfulfilled slot",
      "activeSeconds": 28800,
      "clock": "case-local canonical clock, seconds; half-open"
    },
    "debt": {
      "id": "W02-debt",
      "openedAt": 86400,
      "deadline": 144000,
      "assessedDeadlineIds": []
    },
    "paidBranch": {
      "actualRest": {
        "startSeconds": 86400,
        "endSeconds": 115200,
        "actors": [
          "Iria"
        ],
        "activity": "safe supported rest",
        "activeSeconds": 28800,
        "clock": "case-local canonical clock, seconds; half-open"
      },
      "debtAfter": false,
      "HPAfter": 8,
      "RPAfter": 2,
      "lastBeneficialEndAfter": 72000
    },
    "unpaidBranch": {
      "visits": [
        144000,
        144001,
        172799
      ],
      "strainEvents": [
        {
          "id": "W02-deadline",
          "time": 144000,
          "delta": 1
        }
      ],
      "debtAfter": true,
      "newMissedScheduledSlotAt172800": "outside this branch; would be a separate event"
    }
  },
  "expectedOutcomes": {
    "debtClearsAtHour": 32,
    "benefitIntervalHours": 12,
    "secondRefill": false,
    "deadlineAssessmentsBeforeNewCause": 1
  },
  "readerExplanation": "Eight real safe hours clear the debt. Only 12 hours have elapsed since the prior beneficial completion, so HP and RP do not refill. Re-reading the same unpaid deadline adds no further Strain.",
  "evidenceClass": "authored expectation; named source and arithmetic checks separately executed",
  "worldAuthentication": "All named people, sites and permissions are synthetic premises, not new canonical facts."
}
```

## EX-W03 — Provision quantities, daylight and different recipients

A basket costs 63 cp; two new skins make 103 cp and 13.25 lb. Feeding both named recipients takes three real baskets. In the separate shortage branch, Bor’s missing food and water cause one daily Strain total. Unneeded daylight oil survives.

```json
{
  "id": "EX-W03",
  "schemaVersion": "EX58-boundary-record-v1",
  "status": "authored synthetic expectation; exact review pending",
  "audience": "public synthetic example",
  "title": "Provision quantities, daylight and different recipients",
  "questionIds": [
    "FL-04",
    "FL-05",
    "TR-07"
  ],
  "contractIds": [
    "EC-03",
    "EC-08",
    "EC-10"
  ],
  "sourceBinding": {
    "path": "docs/audit/2026-10-08/full-game/ex58-final-gpt-verdict/EX58_WORKED_SEQUENCES.json",
    "bytes": 73808,
    "sha256": "f668c9aff1c836f61e5766db3eed49d62ba2f1a6d638959157e5551223aa2c80",
    "pointer": "/additionalBoundaries/2"
  },
  "actualSyntheticPremises": "Mira is Medium and Bor is Large. A real low-tier seller has three baskets. Four clean skins are already owned and two new skins are bought. Bright daylight and safe shelter require no flame.",
  "records": {
    "invoice": {
      "foodCp": 150,
      "waterCp": 3,
      "oilCp": 30,
      "sundriesCp": 6,
      "newSkinsCp": 40,
      "totalCp": 229
    },
    "singleBasket": {
      "costCp": 63,
      "massLb": {
        "numerator": 45,
        "denominator": 4
      },
      "newSkins": 2,
      "withNewSkinsCostCp": 103,
      "withSkinMassLb": {
        "numerator": 53,
        "denominator": 4
      }
    },
    "lots": {
      "foodLb": 6,
      "waterPints": 24,
      "oilPints": 3,
      "oilFlaskInclusiveLb": 3,
      "sundriesLb": {
        "numerator": 3,
        "denominator": 4
      },
      "skinTareLb": 6
    },
    "allocation": [
      {
        "id": "Mira-day",
        "foodLb": 2,
        "waterPints": 8
      },
      {
        "id": "Bor-day",
        "foodLb": 4,
        "waterPints": 16
      }
    ],
    "dayEnd": {
      "MiraStrainAdded": 0,
      "BorStrainAdded": 0,
      "oilPintsStillOwned": 3,
      "noAutomaticSundryDestruction": true
    },
    "independentShortageBranch": {
      "openingOnlyOneBasket": true,
      "MiraReceivesFoodLb": 2,
      "MiraReceivesWaterPints": 8,
      "BorFoodLb": 0,
      "BorWaterPints": 0,
      "BorStrainAdded": 1
    },
    "separateMuleFeedOffer": {
      "profileId": "mounts-vehicles-and-services.donkey-or-mule",
      "feedPriceCp": 5,
      "feedMassLb": 10,
      "waterIncluded": false,
      "humanNutritionCredit": 0
    }
  },
  "expectedOutcomes": {
    "ordinaryBasketCp": 63,
    "firstPortableBasketCp": 103,
    "LargeDailyFoodLb": 4,
    "LargeDailyWaterPints": 16
  },
  "readerExplanation": "A basket costs 63 cp; two new skins make 103 cp and 13.25 lb. Feeding both named recipients takes three real baskets. In the separate shortage branch, Bor’s missing food and water cause one daily Strain total. Unneeded daylight oil survives.",
  "evidenceClass": "authored expectation; named source and arithmetic checks separately executed",
  "worldAuthentication": "All named people, sites and permissions are synthetic premises, not new canonical facts."
}
```

## EX-W04 — One finite forage site

The critical result permits at most the original five nutrition units. Ten pounds of food and 40 pints of water move to real receivers; nothing creates oil or a second site allocation.

```json
{
  "id": "EX-W04",
  "schemaVersion": "EX58-boundary-record-v1",
  "status": "authored synthetic expectation; exact review pending",
  "audience": "public synthetic example",
  "title": "One finite forage site",
  "questionIds": [
    "FL-04",
    "FL-05",
    "FL-06"
  ],
  "contractIds": [
    "EC-03",
    "EC-04"
  ],
  "sourceBinding": {
    "path": "docs/audit/2026-10-08/full-game/ex58-final-gpt-verdict/EX58_WORKED_SEQUENCES.json",
    "bytes": 73808,
    "sha256": "f668c9aff1c836f61e5766db3eed49d62ba2f1a6d638959157e5551223aa2c80",
    "pointer": "/additionalBoundaries/3"
  },
  "actualSyntheticPremises": "A measured food-and-water site has three baseline nutrition units and a disjoint two-unit reserve. It has no oil or sundries. Eda and Fen have actual gathering tools and ten fitting clean four-pint skins.",
  "records": {
    "site": {
      "id": "W04-site",
      "baseline": {
        "foodLb": 6,
        "waterPints": 24
      },
      "reserve": {
        "foodLb": 4,
        "waterPints": 16
      },
      "Sustenance": 3,
      "generationEvents": []
    },
    "work": {
      "startSeconds": 0,
      "endSeconds": 28800,
      "actors": [
        "Eda",
        "Fen"
      ],
      "activity": "actual forage, separate workers and tools",
      "activeSeconds": 28800,
      "clock": "case-local canonical clock, seconds; half-open"
    },
    "check": {
      "actor": "Eda",
      "nativeRoute": "Core fixed-DC task",
      "natural": 17,
      "modifier": 6,
      "DC": 13,
      "total": 23,
      "result": "Critical Success",
      "modifierSources": {
        "WISAndOnePB": 5,
        "oneTrainedHelper": 1
      }
    },
    "receivers": {
      "skins": 10,
      "capacityPintsEach": 4,
      "foodSacksCapacityLb": 10,
      "finalTotalMassWithSkinTaresLb": 60
    },
    "transfer": {
      "id": "W04-harvest",
      "foodLb": 10,
      "waterPints": 40,
      "completeProcurementBaskets": 0
    },
    "after": {
      "siteFoodLb": 0,
      "siteWaterPints": 0,
      "oilPints": 0,
      "sundryLb": 0
    },
    "parallelAttempt": {
      "party": "second team",
      "sameParentSite": "W04-site",
      "requestedUnits": 3,
      "receivedUnits": 0
    },
    "nextWatch": {
      "siteIdChanged": "W04-site-alias",
      "underlyingOrigin": "W04-site",
      "newStock": 0
    }
  },
  "expectedOutcomes": {
    "maximumNutritionEquivalents": 5,
    "secondSiteReward": 0,
    "newRecipesOrFishingClaims": 0
  },
  "readerExplanation": "The critical result permits at most the original five nutrition units. Ten pounds of food and 40 pints of water move to real receivers; nothing creates oil or a second site allocation.",
  "evidenceClass": "authored expectation; named source and arithmetic checks separately executed",
  "worldAuthentication": "All named people, sites and permissions are synthetic premises, not new canonical facts."
}
```

## EX-W05 — Camp marks, installed stock and replacement storage

Eight ordinary successful tasks supply eight marks over four days of two work Watches. The 870 lb of installed stock costs 187 gp. Forward storage replaces earlier limits; it does not sum them, mend a damaged rack or teleport a promised delivery.

```json
{
  "id": "EX-W05",
  "schemaVersion": "EX58-boundary-record-v1",
  "status": "authored synthetic expectation; exact review pending",
  "audience": "public synthetic example",
  "title": "Camp marks, installed stock and replacement storage",
  "questionIds": [
    "FL-07",
    "FL-18"
  ],
  "contractIds": [
    "EC-02",
    "EC-03",
    "EC-04",
    "EC-08"
  ],
  "sourceBinding": {
    "path": "docs/audit/2026-10-08/full-game/ex58-final-gpt-verdict/EX58_WORKED_SEQUENCES.json",
    "bytes": 73808,
    "sha256": "f668c9aff1c836f61e5766db3eed49d62ba2f1a6d638959157e5551223aa2c80",
    "pointer": "/additionalBoundaries/4"
  },
  "actualSyntheticPremises": "The Builder has an authorized stable 20×20-foot site, actual shelters, tools, a Research-qualified method and mundane stock. Safe off-duty beds are separately available; construction does not prove them.",
  "records": {
    "work": [
      {
        "startSeconds": 0,
        "endSeconds": 28800,
        "actors": [
          "Builder"
        ],
        "activity": "Support",
        "activeSeconds": 28800,
        "clock": "case-local canonical clock, seconds; half-open",
        "mark": 1,
        "roll": {
          "actor": "Builder",
          "nativeRoute": "Core fixed-DC task",
          "natural": 9,
          "modifier": 3,
          "DC": 12,
          "total": 12,
          "result": "Success"
        }
      },
      {
        "startSeconds": 28800,
        "endSeconds": 57600,
        "actors": [
          "Builder"
        ],
        "activity": "Support",
        "activeSeconds": 28800,
        "clock": "case-local canonical clock, seconds; half-open",
        "mark": 2,
        "roll": {
          "actor": "Builder",
          "nativeRoute": "Core fixed-DC task",
          "natural": 9,
          "modifier": 3,
          "DC": 12,
          "total": 12,
          "result": "Success"
        }
      },
      {
        "startSeconds": 86400,
        "endSeconds": 115200,
        "actors": [
          "Builder"
        ],
        "activity": "Support",
        "activeSeconds": 28800,
        "clock": "case-local canonical clock, seconds; half-open",
        "mark": 3,
        "roll": {
          "actor": "Builder",
          "nativeRoute": "Core fixed-DC task",
          "natural": 9,
          "modifier": 3,
          "DC": 12,
          "total": 12,
          "result": "Success"
        }
      },
      {
        "startSeconds": 115200,
        "endSeconds": 144000,
        "actors": [
          "Builder"
        ],
        "activity": "Research",
        "activeSeconds": 28800,
        "clock": "case-local canonical clock, seconds; half-open",
        "mark": 4,
        "roll": {
          "actor": "Builder",
          "nativeRoute": "Core fixed-DC task",
          "natural": 9,
          "modifier": 3,
          "DC": 12,
          "total": 12,
          "result": "Success"
        }
      },
      {
        "startSeconds": 172800,
        "endSeconds": 201600,
        "actors": [
          "Builder"
        ],
        "activity": "Research",
        "activeSeconds": 28800,
        "clock": "case-local canonical clock, seconds; half-open",
        "mark": 5,
        "roll": {
          "actor": "Builder",
          "nativeRoute": "Core fixed-DC task",
          "natural": 9,
          "modifier": 3,
          "DC": 12,
          "total": 12,
          "result": "Success"
        }
      },
      {
        "startSeconds": 201600,
        "endSeconds": 230400,
        "actors": [
          "Builder"
        ],
        "activity": "Support",
        "activeSeconds": 28800,
        "clock": "case-local canonical clock, seconds; half-open",
        "mark": 6,
        "roll": {
          "actor": "Builder",
          "nativeRoute": "Core fixed-DC task",
          "natural": 9,
          "modifier": 3,
          "DC": 12,
          "total": 12,
          "result": "Success"
        }
      },
      {
        "startSeconds": 259200,
        "endSeconds": 288000,
        "actors": [
          "Builder"
        ],
        "activity": "Support",
        "activeSeconds": 28800,
        "clock": "case-local canonical clock, seconds; half-open",
        "mark": 7,
        "roll": {
          "actor": "Builder",
          "nativeRoute": "Core fixed-DC task",
          "natural": 9,
          "modifier": 3,
          "DC": 12,
          "total": 12,
          "result": "Success"
        }
      },
      {
        "startSeconds": 288000,
        "endSeconds": 316800,
        "actors": [
          "Builder"
        ],
        "activity": "Support",
        "activeSeconds": 28800,
        "clock": "case-local canonical clock, seconds; half-open",
        "mark": 8,
        "roll": {
          "actor": "Builder",
          "nativeRoute": "Core fixed-DC task",
          "natural": 9,
          "modifier": 3,
          "DC": 12,
          "total": 12,
          "result": "Success"
        }
      }
    ],
    "stock": [
      {
        "id": "temporary-pack",
        "lb": 20,
        "cp": 200
      },
      {
        "id": "fortified-stock",
        "lb": 300,
        "cp": 6000
      },
      {
        "id": "research-desk",
        "lb": 50,
        "cp": 2500
      },
      {
        "id": "forward-depot",
        "lb": 500,
        "cp": 10000
      }
    ],
    "upgrades": [
      {
        "totalMarks": 1,
        "Support": 1,
        "Research": 0,
        "storageLoad": 20,
        "pounds": 200,
        "ft3": 20
      },
      {
        "totalMarks": 3,
        "Support": 3,
        "Research": 0,
        "storageLoad": 60,
        "pounds": 600,
        "ft3": 60
      },
      {
        "totalMarks": 5,
        "Support": 3,
        "Research": 2,
        "storageLoad": 60,
        "pounds": 600,
        "ft3": 60
      },
      {
        "totalMarks": 8,
        "Support": 6,
        "Research": 2,
        "storageLoad": 150,
        "pounds": 1500,
        "ft3": 150
      }
    ],
    "ForwardPermission": {
      "id": "local-depot-permit",
      "authority": "actual local landholder in this synthetic case",
      "acceptedBeforeFinalUpgrade": true
    },
    "supplyLine": {
      "id": "line-1",
      "provider": "Nell and Oren",
      "carrier": "one actual compatible owned wagon with two real trained pullers",
      "offeredLoad": 20,
      "currentShipmentLoad": 10,
      "routeSeconds": 28800,
      "quoteCp": 1000,
      "feePaidCp": 1000,
      "nextDepartureSeconds": 345600,
      "nextArrivalSeconds": 374400,
      "suppliesAppearBeforeActualArrival": false
    },
    "warningCheck": {
      "time": 345600,
      "perimeterIntact": true,
      "guard": "real assigned Fen",
      "approachThroughWatchedPerimeter": true,
      "surpriseAutomaticallyRemovedEverywhere": false
    },
    "separateDamage": {
      "fixture": "rack",
      "structuralHPBefore": 3,
      "structuralMaxHP": 5,
      "HPAfterTierUpgrade": 3
    }
  },
  "expectedOutcomes": {
    "marks": 8,
    "installedMassLb": 870,
    "stockPriceGp": 187,
    "finalStorageLoad": 150,
    "completionSeconds": 316800
  },
  "readerExplanation": "Eight ordinary successful tasks supply eight marks over four days of two work Watches. The 870 lb of installed stock costs 187 gp. Forward storage replaces earlier limits; it does not sum them, mend a damaged rack or teleport a promised delivery.",
  "evidenceClass": "authored expectation; named source and arithmetic checks separately executed",
  "worldAuthentication": "All named people, sites and permissions are synthetic premises, not new canonical facts."
}
```

## EX-W06 — Pressure equality, natural results and unchanged exposure

An untouched 3 at Pressure 3 is Standard. A lawfully modified 4→3, or a lawfully rerolled final 3, is Minor. A natural 1 raised above Pressure does not trigger. No modifier, reroll or enemy is granted by this classifier example.

```json
{
  "id": "EX-W06",
  "schemaVersion": "EX58-boundary-record-v1",
  "status": "authored synthetic expectation; exact review pending",
  "audience": "public synthetic example",
  "title": "Pressure equality, natural results and unchanged exposure",
  "questionIds": [
    "FL-08",
    "FL-09"
  ],
  "contractIds": [
    "EC-06",
    "EC-15"
  ],
  "sourceBinding": {
    "path": "docs/audit/2026-10-08/full-game/ex58-final-gpt-verdict/EX58_WORKED_SEQUENCES.json",
    "bytes": 73808,
    "sha256": "f668c9aff1c836f61e5766db3eed49d62ba2f1a6d638959157e5551223aa2c80",
    "pointer": "/additionalBoundaries/5"
  },
  "actualSyntheticPremises": "A Risk-1 cohort already has Pressure 3, including one previously counted Attention reveal. Modifier and reroll classifier probes explicitly assume a lawful supplied effect; they grant no character that effect.",
  "records": {
    "cohort": "W06-cohort",
    "reveal": {
      "id": "lot-A-revealed",
      "alreadyApplied": true,
      "replayedAtNextWatch": true,
      "newDelta": 0
    },
    "rollRecords": [
      {
        "id": "plain",
        "Pressure": 3,
        "natural": 3,
        "modifier": 0,
        "rerolled": false,
        "expected": "Standard"
      },
      {
        "id": "legal-minus-one",
        "Pressure": 3,
        "natural": 4,
        "modifier": -1,
        "rerolled": false,
        "expected": "Minor"
      },
      {
        "id": "natural-one",
        "Pressure": 3,
        "natural": 1,
        "modifier": 0,
        "rerolled": false,
        "expected": "Severe"
      },
      {
        "id": "raised-above",
        "Pressure": 3,
        "natural": 1,
        "modifier": 3,
        "rerolled": false,
        "expected": "none"
      },
      {
        "id": "zero",
        "Pressure": 0,
        "natural": null,
        "modifier": 0,
        "rerolled": false,
        "expected": "none"
      },
      {
        "id": "six",
        "Pressure": 6,
        "natural": null,
        "modifier": 0,
        "rerolled": false,
        "expected": "Severe"
      },
      {
        "id": "legal-reroll-equality",
        "Pressure": 3,
        "natural": 3,
        "priorNatural": 5,
        "modifier": 0,
        "rerolled": true,
        "expected": "Minor"
      },
      {
        "id": "unclamped-low",
        "Pressure": 3,
        "natural": 2,
        "modifier": -4,
        "rerolled": false,
        "expected": "Standard"
      }
    ],
    "modifierAdmission": {
      "noActualPermissionBranch": "Reject the requested modifier/reroll and use the unmodified natural result",
      "conditionalClassifierProbes": "These synthetic input probes are not claims that a listed class feature modifies complication d6s."
    },
    "stakes": {
      "Minor": "15-minute authorized inspection at the real checkpoint",
      "Standard": "60-minute actual obstruction",
      "Severe": "predeclared genuinely closed route requiring an actual response"
    },
    "rootIds": [
      "one-reveal",
      "one-due-complication"
    ],
    "recursivePressureSixRolls": 0
  },
  "expectedOutcomes": {
    "triggerBeforeNaturalOneRule": true,
    "modifiedDieClamped": false,
    "duplicateRevealIncrease": 0
  },
  "readerExplanation": "An untouched 3 at Pressure 3 is Standard. A lawfully modified 4→3, or a lawfully rerolled final 3, is Minor. A natural 1 raised above Pressure does not trigger. No modifier, reroll or enemy is granted by this classifier example.",
  "evidenceClass": "authored expectation; named source and arithmetic checks separately executed",
  "worldAuthentication": "All named people, sites and permissions are synthetic premises, not new canonical facts."
}
```

## EX-W07 — Finite extraction checkpoints and a Severe root

The midpoint and exit each resolve once. The bridge root can request one secondary test. Its further Severe result still has a real finite consequence, but does not recurse into a third test. The exit waits for actual onward travel.

```json
{
  "id": "EX-W07",
  "schemaVersion": "EX58-boundary-record-v1",
  "status": "authored synthetic expectation; exact review pending",
  "audience": "public synthetic example",
  "title": "Finite extraction checkpoints and a Severe root",
  "questionIds": [
    "FL-09",
    "FL-12",
    "FL-13"
  ],
  "contractIds": [
    "EC-02",
    "EC-05",
    "EC-06"
  ],
  "sourceBinding": {
    "path": "docs/audit/2026-10-08/full-game/ex58-final-gpt-verdict/EX58_WORKED_SEQUENCES.json",
    "bytes": 73808,
    "sha256": "f668c9aff1c836f61e5766db3eed49d62ba2f1a6d638959157e5551223aa2c80",
    "pointer": "/additionalBoundaries/6"
  },
  "actualSyntheticPremises": "The actual Mapped route has Length 6 and physical positions 3 and 6. A genuine loose-bridge incident endangers one 20-lb crate at the midpoint; ropes, workers and reachable receiving ground exist.",
  "records": {
    "route": {
      "id": "W07-route",
      "length": 6,
      "Mapping": "Mapped",
      "routineCheckpointPositions": [
        3,
        6
      ]
    },
    "queueEvents": [
      {
        "id": "midpoint-routine",
        "position": 3,
        "interval": {
          "startSeconds": 43200,
          "endSeconds": 43260,
          "actors": [
            "Lead"
          ],
          "activity": "verification",
          "activeSeconds": 60,
          "clock": "case-local canonical clock, seconds; half-open"
        },
        "roll": {
          "actor": "Lead",
          "nativeRoute": "Core fixed-DC task",
          "natural": 1,
          "modifier": 5,
          "DC": 17,
          "total": 6,
          "result": "Critical Failure"
        },
        "root": "bridge-incident"
      },
      {
        "id": "real-cargo-response",
        "position": 3,
        "interval": {
          "startSeconds": 43260,
          "endSeconds": 46860,
          "actors": [
            "Lead",
            "Helper"
          ],
          "activity": "recover the reachable crate using existing rigging",
          "activeSeconds": 3600,
          "clock": "case-local canonical clock, seconds; half-open"
        },
        "roll": {
          "actor": "Lead",
          "nativeRoute": "Core fixed-DC task",
          "natural": 12,
          "modifier": 5,
          "DC": 17,
          "total": 17,
          "result": "Success"
        },
        "crateRecovered": true
      },
      {
        "id": "midpoint-secondary",
        "position": 3,
        "interval": {
          "startSeconds": 46860,
          "endSeconds": 46920,
          "actors": [
            "Lead"
          ],
          "activity": "one post-Severe verification",
          "activeSeconds": 60,
          "clock": "case-local canonical clock, seconds; half-open"
        },
        "roll": {
          "actor": "Lead",
          "nativeRoute": "Core fixed-DC task",
          "natural": 1,
          "modifier": 5,
          "DC": 17,
          "total": 6,
          "result": "Critical Failure"
        },
        "root": "bridge-incident",
        "secondaryNumber": 1
      },
      {
        "id": "secondary-consequence",
        "position": 3,
        "interval": {
          "startSeconds": 46920,
          "endSeconds": 46980,
          "actors": [
            "Lead",
            "Helper"
          ],
          "activity": "withdraw crate from a failed original strap onto secure ground",
          "activeSeconds": 60,
          "clock": "case-local canonical clock, seconds; half-open"
        },
        "lostStock": [
          "one actual failed strap"
        ],
        "newExtractionTestRequested": false
      },
      {
        "id": "actual-onward-traverse",
        "positionFrom": 3,
        "positionTo": 6,
        "interval": {
          "startSeconds": 46980,
          "endSeconds": 90180,
          "actors": [
            "whole cohort"
          ],
          "activity": "12 actual moving hours, no free positional advance",
          "activeSeconds": 43200,
          "clock": "case-local canonical clock, seconds; half-open"
        }
      },
      {
        "id": "exit-routine",
        "position": 6,
        "interval": {
          "startSeconds": 90180,
          "endSeconds": 90240,
          "actors": [
            "Lead"
          ],
          "activity": "exit verification",
          "activeSeconds": 60,
          "clock": "case-local canonical clock, seconds; half-open"
        },
        "roll": {
          "actor": "Lead",
          "nativeRoute": "Core fixed-DC task",
          "natural": 12,
          "modifier": 5,
          "DC": 17,
          "total": 17,
          "result": "Success"
        }
      }
    ],
    "replayRequest": {
      "id": "midpoint-routine",
      "result": "already processed; no second roll"
    },
    "bonusProgressAdmission": {
      "fromPosition": 5,
      "claimedToPosition": 6,
      "actualReachabilityRequired": true,
      "absentTraverseResult": "reject teleport-like award; no queued exit yet"
    },
    "laterWatchHazards": "Separate actual due Watch events retain their own roots; none is generated merely by iterating this queue."
  },
  "expectedOutcomes": {
    "routineTests": 2,
    "secondaryTestsForBridgeRoot": 1,
    "tertiaryTests": 0,
    "crateStillSameObject": true
  },
  "readerExplanation": "The midpoint and exit each resolve once. The bridge root can request one secondary test. Its further Severe result still has a real finite consequence, but does not recurse into a third test. The exit waits for actual onward travel.",
  "evidenceClass": "authored expectation; named source and arithmetic checks separately executed",
  "worldAuthentication": "All named people, sites and permissions are synthetic premises, not new canonical facts."
}
```

## EX-W08 — A route’s time multiplier is applied once

The same traverse costs ten moving hours and eleven elapsed hours with its one-hour obstruction. Mapped Progress is its outcome, not another journey. The lawful half-pace branch takes twenty moving hours, with rest and daily needs continuing.

```json
{
  "id": "EX-W08",
  "schemaVersion": "EX58-boundary-record-v1",
  "status": "authored synthetic expectation; exact review pending",
  "audience": "public synthetic example",
  "title": "A route’s time multiplier is applied once",
  "questionIds": [
    "FL-10",
    "FL-11",
    "TR-13"
  ],
  "contractIds": [
    "EC-02",
    "EC-05"
  ],
  "sourceBinding": {
    "path": "docs/audit/2026-10-08/full-game/ex58-final-gpt-verdict/EX58_WORKED_SEQUENCES.json",
    "bytes": 73808,
    "sha256": "f668c9aff1c836f61e5766db3eed49d62ba2f1a6d638959157e5551223aa2c80",
    "pointer": "/additionalBoundaries/7"
  },
  "actualSyntheticPremises": "A feasible Mapped route is physically Contested. The ordinary convoy moves at 3 mph. A separate branch has a genuinely permitted essential traveller whose Strain-5 exception reduces lawful pace to 1.5 mph; that traveller does not lead the active check.",
  "records": {
    "nominalMinutes": 480,
    "qualityFactor": {
      "numerator": 5,
      "denominator": 4
    },
    "normalPaceMph": 3,
    "normalIntervals": [
      {
        "startSeconds": 0,
        "endSeconds": 18000,
        "actors": [
          "convoy"
        ],
        "activity": "moving",
        "activeSeconds": 18000,
        "clock": "case-local canonical clock, seconds; half-open"
      },
      {
        "startSeconds": 18000,
        "endSeconds": 21600,
        "actors": [
          "convoy"
        ],
        "activity": "actual obstruction",
        "activeSeconds": 3600,
        "clock": "case-local canonical clock, seconds; half-open"
      },
      {
        "startSeconds": 21600,
        "endSeconds": 39600,
        "actors": [
          "convoy"
        ],
        "activity": "moving",
        "activeSeconds": 18000,
        "clock": "case-local canonical clock, seconds; half-open"
      }
    ],
    "normalMovingMinutes": 600,
    "normalElapsedMinutes": 660,
    "baseProgress": 2,
    "extraMileageReward": 0,
    "strainBranch": {
      "paceMph": {
        "numerator": 3,
        "denominator": 2
      },
      "movingMinutes": 1200,
      "lead": "separate capable Routekeeper",
      "affectedActorLeads": false
    },
    "forcedMarchBranch": {
      "sameRouteTimeNormalization": true,
      "extraOrdinaryTravelReward": 0,
      "separateSevereCheckAndSupportRequired": true
    }
  },
  "expectedOutcomes": {
    "normalMovingMinutes": 600,
    "normalWithPauseMinutes": 660,
    "strainMovingMinutes": 1200
  },
  "readerExplanation": "The same traverse costs ten moving hours and eleven elapsed hours with its one-hour obstruction. Mapped Progress is its outcome, not another journey. The lawful half-pace branch takes twenty moving hours, with rest and daily needs continuing.",
  "evidenceClass": "authored expectation; named source and arithmetic checks separately executed",
  "worldAuthentication": "All named people, sites and permissions are synthetic premises, not new canonical facts."
}
```

## EX-W09 — Forced-march stock and extraction high-water marks

Five extra units are required before commitment. Success pays support once. Failure returns only actual surviving stock, while used food, water and fuel stay used. Raising Class 2 to Class 6 adds only two more surcharge points; dropping and reclaiming that cargo does not refresh the charge.

```json
{
  "id": "EX-W09",
  "schemaVersion": "EX58-boundary-record-v1",
  "status": "authored synthetic expectation; exact review pending",
  "audience": "public synthetic example",
  "title": "Forced-march stock and extraction high-water marks",
  "questionIds": [
    "FL-11",
    "FL-12"
  ],
  "contractIds": [
    "EC-03",
    "EC-05",
    "EC-06"
  ],
  "sourceBinding": {
    "path": "docs/audit/2026-10-08/full-game/ex58-final-gpt-verdict/EX58_WORKED_SEQUENCES.json",
    "bytes": 73808,
    "sha256": "f668c9aff1c836f61e5766db3eed49d62ba2f1a6d638959157e5551223aa2c80",
    "pointer": "/additionalBoundaries/8"
  },
  "actualSyntheticPremises": "Three Medium characters and one Large character attempt a feasible Unknown route with actual extra stock, carriers and lamps. Alternatives fork from the same opening manifest.",
  "records": {
    "actors": [
      {
        "id": "A",
        "size": "Medium"
      },
      {
        "id": "B",
        "size": "Medium"
      },
      {
        "id": "C",
        "size": "Medium"
      },
      {
        "id": "D",
        "size": "Large"
      }
    ],
    "reservedAdditionalLots": {
      "basketUnits": 5,
      "foodLb": 10,
      "waterPints": 40,
      "oilPints": 5,
      "fullFlaskBodiesLb": {
        "numerator": 5,
        "denominator": 4
      },
      "sundriesLb": {
        "numerator": 5,
        "denominator": 4
      },
      "waterContainers": 10
    },
    "success": {
      "work": [
        {
          "startSeconds": 0,
          "endSeconds": 21600,
          "actors": [
            "A",
            "B",
            "C",
            "D"
          ],
          "activity": "feasible forced march",
          "activeSeconds": 21600,
          "clock": "case-local canonical clock, seconds; half-open"
        },
        {
          "startSeconds": 21660,
          "endSeconds": 28860,
          "actors": [
            "A",
            "B",
            "C",
            "D"
          ],
          "activity": "remaining forced march",
          "activeSeconds": 7200,
          "clock": "case-local canonical clock, seconds; half-open"
        }
      ],
      "roll": {
        "actor": "A",
        "nativeRoute": "Core fixed-DC task",
        "natural": 14,
        "modifier": 5,
        "DC": 19,
        "total": 19,
        "result": "Success"
      },
      "Progress": 1,
      "PressureDelta": 2,
      "supportChargedOnce": 5,
      "physicalSpend": "Same reserved origins support this operation; actual consumption events are retained, no second abstract Supply asset. Carried light consists of three eight-hour lamp burns and one six-hour burn, totaling the five pints.",
      "lamps": {
        "A_B_C": {
          "firstBurn": [
            0,
            21600
          ],
          "refill": [
            21600,
            21660
          ],
          "secondBurn": [
            21660,
            28860
          ]
        },
        "D": {
          "backupBurn": [
            60,
            21660
          ]
        },
        "refillWorkers": [
          "A",
          "B",
          "C"
        ],
        "fifthPintSplitBetweenABC": {
          "numerator": 1,
          "denominator": 3
        },
        "DProvidesLightDuringRefill": true,
        "pauseSeconds": 60,
        "activeTravelSeconds": 28800,
        "elapsedSeconds": 28860
      },
      "foodWaterAndSundries": "10 lb food, 40 pints water and 1.25 lb sundries are allocated to the named three Medium and one Large recipients and actually used for this successful support operation; the same nutrition counts once."
    },
    "failureAlternative": {
      "roll": {
        "actor": "A",
        "nativeRoute": "Core fixed-DC task",
        "natural": 10,
        "modifier": 5,
        "DC": 19,
        "total": 15,
        "result": "Failure"
      },
      "Progress": 0,
      "complication": "Standard, one declared obstruction",
      "alreadyConsumed": {
        "foodLb": 2,
        "waterPints": 8,
        "oilPints": 5,
        "sundriesLb": {
          "numerator": 1,
          "denominator": 4
        }
      },
      "actuallyReturnedUnspent": {
        "foodLb": 8,
        "waterPints": 32,
        "oilPints": 0,
        "sundriesLb": 1
      },
      "nutritionCreditRecipients": "the named recipients of the consumed amounts, once; unspent stock does not credit needs"
    },
    "highwaterEvents": [
      {
        "id": "start-class2",
        "highestClass": 2,
        "surcharge": 1,
        "newDelta": 1
      },
      {
        "id": "acquire-class6",
        "highestClass": 6,
        "surcharge": 3,
        "newDelta": 2,
        "dedicatedHandling": "actual sealed cradle, rated carrier, consent/authority and prechecked route; no generic carrying exception"
      },
      {
        "id": "drop-class6",
        "highestClass": 2,
        "surchargeHighwater": 3,
        "refund": 0
      },
      {
        "id": "same-class6-return",
        "highestClass": 6,
        "surchargeHighwater": 3,
        "newDelta": 0
      }
    ]
  },
  "expectedOutcomes": {
    "extraUnits": 5,
    "successProgress": 1,
    "successPressure": 2,
    "class2To6AddedPressure": 2,
    "dropRefund": 0
  },
  "readerExplanation": "Five extra units are required before commitment. Success pays support once. Failure returns only actual surviving stock, while used food, water and fuel stay used. Raising Class 2 to Class 6 adds only two more surcharge points; dropping and reclaiming that cargo does not refresh the charge.",
  "evidenceClass": "authored expectation; named source and arithmetic checks separately executed",
  "worldAuthentication": "All named people, sites and permissions are synthetic premises, not new canonical facts."
}
```

## EX-W10 — Extraction modifiers and a real choice after failure

The handling subtotal caps at +7 before pursuit and Secured adjustments, producing DC 20. A failed test offers one declared branch. The eight-hour delay is real time; its Standard complication is a separate actual consequence whose time cannot be erased. A cargo-risk branch allows a real hour of recovery.

```json
{
  "id": "EX-W10",
  "schemaVersion": "EX58-boundary-record-v1",
  "status": "authored synthetic expectation; exact review pending",
  "audience": "public synthetic example",
  "title": "Extraction modifiers and a real choice after failure",
  "questionIds": [
    "FL-13",
    "FL-14"
  ],
  "contractIds": [
    "EC-02",
    "EC-06",
    "EC-09"
  ],
  "sourceBinding": {
    "path": "docs/audit/2026-10-08/full-game/ex58-final-gpt-verdict/EX58_WORKED_SEQUENCES.json",
    "bytes": 73808,
    "sha256": "f668c9aff1c836f61e5766db3eed49d62ba2f1a6d638959157e5551223aa2c80",
    "pointer": "/additionalBoundaries/9"
  },
  "actualSyntheticPremises": "A Tier-II lead sees the actual Class-4 cargo, one exposed Attention lot, four unsecured dangerous lots, a Burdened convoy, actual pursuit and a genuinely Secured route. Each tag names a real handling problem.",
  "records": {
    "modifierRecord": {
      "baseTierDC": 13,
      "highestClass": 4,
      "exposedAttentionLots": 1,
      "AttentionTagMentions": 2,
      "AttentionModifier": 1,
      "Burden": 1,
      "unsecuredDangerousLotIds": [
        "a",
        "b",
        "c",
        "d"
      ],
      "hazardCap": 3,
      "rawCappedPart": 9,
      "cappedPart": 7,
      "pursuit": 2,
      "Secured": -2,
      "finalDC": 20
    },
    "test": {
      "interval": {
        "startSeconds": 0,
        "endSeconds": 60,
        "actors": [
          "Lead"
        ],
        "activity": "actual checkpoint inspection",
        "activeSeconds": 60,
        "clock": "case-local canonical clock, seconds; half-open"
      },
      "actor": "Lead",
      "nativeRoute": "Core fixed-DC task",
      "natural": 10,
      "modifier": 5,
      "DC": 20,
      "total": 15,
      "result": "Failure"
    },
    "delayBranch": {
      "interval": {
        "startSeconds": 60,
        "endSeconds": 28860,
        "actors": [
          "Lead",
          "Guard"
        ],
        "activity": "handle actual gate obstruction and guard stalled convoy",
        "activeSeconds": 28800,
        "clock": "case-local canonical clock, seconds; half-open"
      },
      "Progress": 0,
      "StandardComplication": "actual separate predeclared 60-minute inspection begins at28860; cannot be hidden inside an incompatible worker interval",
      "inspection": {
        "startSeconds": 28860,
        "endSeconds": 32460,
        "actors": [
          "Lead"
        ],
        "activity": "additional actual Standard complication",
        "activeSeconds": 3600,
        "clock": "case-local canonical clock, seconds; half-open"
      },
      "otherPeopleRest": "only a separately supplied genuine safe location and uninterrupted assignment can qualify"
    },
    "riskBranch": {
      "lot": "lowest-priority reachable 20-lb crate",
      "priority": 1,
      "titleUnchanged": true,
      "response": {
        "startSeconds": 60,
        "endSeconds": 3660,
        "actors": [
          "Lead",
          "Helper"
        ],
        "activity": "real recovery with rope, anchor and receiving ground",
        "activeSeconds": 3600,
        "clock": "case-local canonical clock, seconds; half-open"
      },
      "recoveryDC": 17,
      "roll": {
        "actor": "Lead",
        "nativeRoute": "Core fixed-DC task",
        "natural": 12,
        "modifier": 5,
        "DC": 17,
        "total": 17,
        "result": "Success"
      },
      "outcome": "same crate secured; no new value, HP or Progress"
    },
    "branchChoice": "Select one; never impose both delay and risk automatically."
  },
  "expectedOutcomes": {
    "finalDC": 20,
    "delaySeconds": 28800,
    "responseSeconds": 3600,
    "automaticCargoDestruction": false
  },
  "readerExplanation": "The handling subtotal caps at +7 before pursuit and Secured adjustments, producing DC 20. A failed test offers one declared branch. The eight-hour delay is real time; its Standard complication is a separate actual consequence whose time cannot be erased. A cargo-risk branch allows a real hour of recovery.",
  "evidenceClass": "authored expectation; named source and arithmetic checks separately executed",
  "worldAuthentication": "All named people, sites and permissions are synthetic premises, not new canonical facts."
}
```

## EX-W11 — Actual encounter contributors and retreat comparison

The actual commanded offensive phase contributes one half, for N_eff 4.5 and a provisional budget of 99. Its spent command remains spent during retreat. Escape 3 wins only while Pursuit is below 3; simultaneous 3/3 fails.

```json
{
  "id": "EX-W11",
  "schemaVersion": "EX58-boundary-record-v1",
  "status": "authored synthetic expectation; exact review pending",
  "audience": "public synthetic example",
  "title": "Actual encounter contributors and retreat comparison",
  "questionIds": [
    "FL-15",
    "FL-16"
  ],
  "contractIds": [
    "EC-01",
    "EC-07",
    "EC-08"
  ],
  "sourceBinding": {
    "path": "docs/audit/2026-10-08/full-game/ex58-final-gpt-verdict/EX58_WORKED_SEQUENCES.json",
    "bytes": 73808,
    "sha256": "f668c9aff1c836f61e5766db3eed49d62ba2f1a6d638959157e5551223aa2c80",
    "pointer": "/additionalBoundaries/10"
  },
  "actualSyntheticPremises": "Four level-3 characters are present, including a Tinker with its actual class Anacite Drone. The fixture uses the unchanged provisional class engine, without promoting a card or treating an absent roster member as present.",
  "records": {
    "characters": [
      {
        "id": "Tinker",
        "level": 3,
        "INTModifier": 3,
        "PB": 2
      },
      {
        "id": "A",
        "level": 3
      },
      {
        "id": "B",
        "level": 3
      },
      {
        "id": "C",
        "level": 3
      }
    ],
    "drone": {
      "id": "W11-Anacite",
      "source": "tinker engine automatic level1 body",
      "currentHP": 11,
      "maximumHP": 11,
      "AC": 16,
      "flightFt": 30,
      "attackBonus": 5,
      "command": {
        "controller": "Tinker",
        "BonusActionSpent": true,
        "RPSpent": 0,
        "wholeAttachedPhaseAfterControllerTurn": true
      },
      "bolt": {
        "rangeFt": 60,
        "targetDistanceFt": 30,
        "lineOfEffect": true,
        "natural": 10,
        "total": 15,
        "targetAC": 13,
        "damageD6": 3,
        "damageType": "piercing",
        "shockD4": 2,
        "extraCondition": false
      },
      "damagingActionsInSharedBudget": 1
    },
    "calibration": {
      "N_eff": {
        "numerator": 9,
        "denominator": 2
      },
      "multiplier": {
        "numerator": 11,
        "denominator": 10
      },
      "standardBaseBudget": 90,
      "standardBudget": 99,
      "passiveCargoOrMountWeight": 0,
      "measuredBalance": false
    },
    "retreat": {
      "existingSpentBonusActionRetained": true,
      "actualLead": "A",
      "DC": 16,
      "rounds": [
        {
          "lead": {
            "actor": "A",
            "nativeRoute": "Core fixed-DC task",
            "natural": 11,
            "modifier": 5,
            "DC": 16,
            "total": 16,
            "result": "Success"
          },
          "Escape": 1,
          "Pursuit": 0,
          "oneThreat": "actual attack misses"
        },
        {
          "lead": {
            "actor": "A",
            "nativeRoute": "Core fixed-DC task",
            "natural": 20,
            "modifier": 5,
            "DC": 16,
            "total": 25,
            "result": "Critical Success"
          },
          "EscapeAdded": 2,
          "PursuitAdded": 0,
          "oneThreat": "actual attack misses"
        }
      ],
      "successState": {
        "Escape": 3,
        "Pursuit": 0
      },
      "independentSimultaneousBranch": {
        "Escape": 3,
        "Pursuit": 3,
        "outcome": "failure; actual next hostile advantage, not automatic death"
      }
    },
    "bossTenacity": {
      "grantedByBudget": false,
      "actualSourceRequired": true
    }
  },
  "expectedOutcomes": {
    "N_eff": {
      "numerator": 9,
      "denominator": 2
    },
    "standardBudget": 99,
    "3Versus3Retreat": "failure"
  },
  "readerExplanation": "The actual commanded offensive phase contributes one half, for N_eff 4.5 and a provisional budget of 99. Its spent command remains spent during retreat. Escape 3 wins only while Pursuit is below 3; simultaneous 3/3 fails.",
  "evidenceClass": "authored expectation; named source and arithmetic checks separately executed",
  "worldAuthentication": "All named people, sites and permissions are synthetic premises, not new canonical facts."
}
```

## EX-W12 — Whole mounted turns and prospective transfer

The rider pays 15 feet to mount, completes the whole turn and can prepare a real Ready/Reaction attack. The horse then acts once. A controller change affects a future slot, not another current-round move. A single opportunity attack chooses one legal target.

```json
{
  "id": "EX-W12",
  "schemaVersion": "EX58-boundary-record-v1",
  "status": "authored synthetic expectation; exact review pending",
  "audience": "public synthetic example",
  "title": "Whole mounted turns and prospective transfer",
  "questionIds": [
    "TR-01",
    "TR-02",
    "TR-03",
    "TR-04",
    "TR-05"
  ],
  "contractIds": [
    "EC-02",
    "EC-07",
    "EC-08"
  ],
  "sourceBinding": {
    "path": "docs/audit/2026-10-08/full-game/ex58-final-gpt-verdict/EX58_WORKED_SEQUENCES.json",
    "bytes": 73808,
    "sha256": "f668c9aff1c836f61e5766db3eed49d62ba2f1a6d638959157e5551223aa2c80",
    "pointer": "/additionalBoundaries/11"
  },
  "actualSyntheticPremises": "A willing trained Riding horse has a real riding saddle and a legal Medium rider: 150-lb body, 20-lb gear, 18-lb saddle and 2-lb reins. Their route, seat and control channel are physically usable.",
  "records": {
    "horseProfileId": "mounts-vehicles-and-services.horse-riding",
    "payload": {
      "bodyLb": 150,
      "gearLb": 20,
      "saddleLb": 18,
      "reinsLb": 2,
      "totalLb": 190,
      "Load": 10
    },
    "round1": {
      "riderInitiative": 18,
      "walkingSpeedFt": 30,
      "mountCostFt": 15,
      "movementRemainingFt": 15,
      "riderWholeTurn": {
        "Action": "Ready one legal spear attack after the horse reaches a target; this is not an immediate extra attack",
        "BonusAction": "unused",
        "Reaction": "reserved"
      },
      "horseWholeTurn": {
        "slot": "immediately after entire rider turn",
        "SpeedFt": 60,
        "moveFt": 40,
        "Action": "Dodge",
        "attackActions": 0
      },
      "trigger": {
        "targetActuallyInSpearReach": true,
        "riderReactionSpent": true,
        "ReadiedAttackCount": 1
      }
    },
    "independentTransferBranch": {
      "horseTurnAlreadySpent": true,
      "newController": "Mira",
      "newControllerActionCreatesTurn": false,
      "currentRoundHorseTurns": 1,
      "nextRoundSlot": "after Mira’s entire regular turn"
    },
    "opportunityBranch": {
      "oneEnemyReaction": true,
      "mountAndRiderBothActuallyInReach": true,
      "chooseTargets": 1,
      "bothAttackedBySameReaction": false,
      "horseDisengageProtectsItsActualMove": true
    },
    "pendingFeats": [
      "Cavalry",
      "Mounted Combatant"
    ],
    "CavalrySpeedAdded": 0
  },
  "expectedOutcomes": {
    "mountCostFt": 15,
    "horseTurnsPerRound": 1,
    "freeInterleavedRiderAttacks": 0
  },
  "readerExplanation": "The rider pays 15 feet to mount, completes the whole turn and can prepare a real Ready/Reaction attack. The horse then acts once. A controller change affects a future slot, not another current-round move. A single opportunity attack chooses one legal target.",
  "evidenceClass": "authored expectation; named source and arithmetic checks separately executed",
  "worldAuthentication": "All named people, sites and permissions are synthetic premises, not new canonical facts."
}
```

## EX-W13 — Carried movement is not Dragoon self-motion

The horse’s 20 feet change position only. Later, real Swiftness leaves exactly 20 feet after the Dragoon pays a 20-foot dismount cost. Walking those 20 feet meets the Momentum threshold and the new narrow Dissonance bridge before a legal Featherstep Action. Its normal 2 RP is still paid.

```json
{
  "id": "EX-W13",
  "schemaVersion": "EX58-boundary-record-v1",
  "status": "authored synthetic expectation; exact review pending",
  "audience": "public synthetic example",
  "title": "Carried movement is not Dragoon self-motion",
  "questionIds": [
    "TR-03",
    "TR-04",
    "TR-05",
    "TR-06"
  ],
  "contractIds": [
    "EC-02",
    "EC-07",
    "EC-08",
    "EC-14"
  ],
  "sourceBinding": {
    "path": "docs/audit/2026-10-08/full-game/ex58-final-gpt-verdict/EX58_WORKED_SEQUENCES.json",
    "bytes": 73808,
    "sha256": "f668c9aff1c836f61e5766db3eed49d62ba2f1a6d638959157e5551223aa2c80",
    "pointer": "/additionalBoundaries/12"
  },
  "actualSyntheticPremises": "A level-8 Dragoon has genuinely acquired Featherstep. A level-3 Mage ally already cast and maintains actual Swiftness, legally raising the Dragoon’s walking Speed from 30 to 40 for its minute. No pending feat is used.",
  "records": {
    "ongoingEffect": {
      "spellId": "swiftness",
      "sourceCardIndex": 71,
      "caster": "Mage ally",
      "classLevel": 3,
      "castAtSeconds": 0,
      "expiresAtSeconds": 60,
      "ActionSpent": true,
      "RPBefore": 10,
      "RPAfter": 7,
      "DissonanceBefore": 0,
      "DissonanceAfter": 1,
      "components": "actual voice, manipulating hand and held legal focus",
      "willingTarget": "Dragoon",
      "initialDistanceFt": 10,
      "concentrationHeld": true
    },
    "carriedEvent": {
      "atSeconds": 6,
      "carrier": "horse",
      "distanceFt": 20,
      "selfPoweredFt": 0,
      "MomentumAdded": 0,
      "DissonanceDiscount": 0
    },
    "seatEventAlternative": {
      "id": "one-forced-prone-root",
      "labels": [
        "forced displacement",
        "mount Prone"
      ],
      "DEXSave": {
        "actor": "Dragoon",
        "nativeRoute": "binary save",
        "natural": 8,
        "modifier": 2,
        "DC": 10,
        "total": 10,
        "result": "success"
      },
      "checks": 1,
      "actualSupportAfterSuccess": "real fitting saddle and ground; success does not hold rider in empty air"
    },
    "ownTurn": {
      "atSeconds": 12,
      "walkingSpeedFt": 40,
      "dismountCostFt": 20,
      "actualSelfPoweredPathFt": 20,
      "remainingMovementFt": 0,
      "MomentumBefore": 0,
      "MomentumFromMovement": 1,
      "MomentumAfter": 1,
      "weaponHit": false,
      "Action": "Featherstep on willing self",
      "spellRank": 1,
      "classLevel": 8,
      "requiredMinimumClassLevel": 3,
      "STRModifier": 4,
      "PB": 3,
      "DissonanceLimit": 9,
      "RPBefore": 10,
      "RPPrice": 2,
      "RPAfter": 8,
      "previousSpellName": "a different identity; Refrain0",
      "DissonanceBefore": 2,
      "baseGain": 1,
      "movementReduction": 1,
      "finalGain": 0,
      "DissonanceAfter": 2,
      "components": "usable voice, legal held focus, free manipulating hand after dismount; no weapon attack also claimed",
      "newConcentration": "Dragoon holds Featherstep; ally independently retains Swiftness",
      "targetMassWithGearLb": 170,
      "actualEffect": "only the full Featherstep card; no empty-gap flight or added Speed"
    },
    "teleportComparison": {
      "actualPositionChangedFt": 20,
      "selfPoweredPathFt": 0,
      "MomentumFromDistance": 0,
      "newMovementDiscount": 0
    }
  },
  "expectedOutcomes": {
    "carried20Momentum": 0,
    "carried20Discount": 0,
    "own20Momentum": 1,
    "own20DissonanceReduction": 1,
    "RPDiscount": 0
  },
  "readerExplanation": "The horse’s 20 feet change position only. Later, real Swiftness leaves exactly 20 feet after the Dragoon pays a 20-foot dismount cost. Walking those 20 feet meets the Momentum threshold and the new narrow Dissonance bridge before a legal Featherstep Action. Its normal 2 RP is still paid.",
  "evidenceClass": "authored expectation; named source and arithmetic checks separately executed",
  "worldAuthentication": "All named people, sites and permissions are synthetic premises, not new canonical facts."
}
```

## EX-W14 — Separate draw, back-load and vehicle limits

The 500-lb drawn load fits the actual 1,200-lb draw rating, independently of the horse’s back capacity. Barding costs four times the real armor price once. The two sleds remain distinct records with different operators and capacities.

```json
{
  "id": "EX-W14",
  "schemaVersion": "EX58-boundary-record-v1",
  "status": "authored synthetic expectation; exact review pending",
  "audience": "public synthetic example",
  "title": "Separate draw, back-load and vehicle limits",
  "questionIds": [
    "TR-07",
    "TR-08",
    "TR-12"
  ],
  "contractIds": [
    "EC-03",
    "EC-08",
    "EC-10"
  ],
  "sourceBinding": {
    "path": "docs/audit/2026-10-08/full-game/ex58-final-gpt-verdict/EX58_WORKED_SEQUENCES.json",
    "bytes": 73808,
    "sha256": "f668c9aff1c836f61e5766db3eed49d62ba2f1a6d638959157e5551223aa2c80",
    "pointer": "/additionalBoundaries/13"
  },
  "actualSyntheticPremises": "A trained Draft horse, actual compatible harness, walking driver and complete Cart are on a firm fitting road. A separate real Medium chain-shirt armor body is used for a barding quote.",
  "records": {
    "horseProfileId": "mounts-vehicles-and-services.horse-draft",
    "cartProfileId": "mounts-vehicles-and-services.cart",
    "admission": {
      "cartEmptyLb": 200,
      "cargoLb": 300,
      "cargoLoad": 30,
      "cartPayloadCapLb": 300,
      "grossDrawLb": 500,
      "horseDrawCapLb": 1200,
      "horseBackCarryCapLb": 540,
      "harnessOnHorseLb": 8,
      "backCargoLb": 0,
      "drawBurdened": false
    },
    "bardingQuote": {
      "armorSource": "EN-armor ordinary Standard Medium chain shirt actual default",
      "baseGp": 50,
      "baseMassLb": 20,
      "bardingPriceFactor": 4,
      "LargeMassFactor": 4,
      "priceGp": 200,
      "massLb": 80,
      "secondLargePriceFactorApplied": false,
      "actualFittingTrainingBeforeUseRequired": true
    },
    "sleds": [
      {
        "id": "Core Dungeon sled",
        "priceGp": 25,
        "normalLoad": 12,
        "emergencyLoad": 20,
        "twoActualOperators": true
      },
      {
        "id": "Player Sled",
        "priceGp": 20,
        "ordinaryPayloadLb": 400,
        "ordinaryPayloadLoad": 40,
        "requiredPullerAndDriver": true
      }
    ],
    "unfundedMissingPurchaseItems": [
      "horse",
      "harness",
      "driver"
    ],
    "Cart15GpAutomaticallyIncludesThem": false
  },
  "expectedOutcomes": {
    "grossDrawLb": 500,
    "drawLimitLb": 1200,
    "backCarryLimitLb": 540,
    "LargeBardingPriceGp": 200,
    "LargeBardingMassLb": 80
  },
  "readerExplanation": "The 500-lb drawn load fits the actual 1,200-lb draw rating, independently of the horse’s back capacity. Barding costs four times the real armor price once. The two sleds remain distinct records with different operators and capacities.",
  "evidenceClass": "authored expectation; named source and arithmetic checks separately executed",
  "worldAuthentication": "All named people, sites and permissions are synthetic premises, not new canonical facts."
}
```

## EX-W15 — A rowboat carries its people too

The occupants and their gear bring the payload to 540 lb even though the cargo crate weighs only 30 lb. Another 100-lb crate is prohibited. One operator Action produces one 20-foot drive event, not another boat turn.

```json
{
  "id": "EX-W15",
  "schemaVersion": "EX58-boundary-record-v1",
  "status": "authored synthetic expectation; exact review pending",
  "audience": "public synthetic example",
  "title": "A rowboat carries its people too",
  "questionIds": [
    "TR-09",
    "TR-10"
  ],
  "contractIds": [
    "EC-02",
    "EC-03",
    "EC-08"
  ],
  "sourceBinding": {
    "path": "docs/audit/2026-10-08/full-game/ex58-final-gpt-verdict/EX58_WORKED_SEQUENCES.json",
    "bytes": 73808,
    "sha256": "f668c9aff1c836f61e5766db3eed49d62ba2f1a6d638959157e5551223aa2c80",
    "pointer": "/additionalBoundaries/14"
  },
  "actualSyntheticPremises": "A real Rowboat, qualified operator, three actual occupants and fitting cargo wait at an accessible dock. Water is one foot deep with zero current and adequate clearance.",
  "records": {
    "profileId": "mounts-vehicles-and-services.rowboat",
    "manifest": [
      {
        "id": "rower",
        "bodyLb": 150,
        "gearLb": 20,
        "bodyLoad": 6,
        "gearLoad": 2
      },
      {
        "id": "passengerA",
        "bodyLb": 150,
        "gearLb": 20,
        "bodyLoad": 6,
        "gearLoad": 2
      },
      {
        "id": "passengerB",
        "bodyLb": 150,
        "gearLb": 20,
        "bodyLoad": 6,
        "gearLoad": 2
      },
      {
        "id": "crate",
        "massLb": 30,
        "Load": 3
      }
    ],
    "totals": {
      "payloadLb": 540,
      "payloadLoad": 27,
      "emptyHullLb": 120,
      "supportedGrossLb": 660,
      "occupants": 3,
      "occupantCap": 4,
      "cargoOnlyLb": 30,
      "cargoSublimitLb": 400
    },
    "drive": {
      "round": 1,
      "operator": "rower",
      "Action": "combined helm/oars",
      "hands": 2,
      "moveFt": 20,
      "secondActionAdditionalMoveFt": 0,
      "nativeBoatTurn": false
    },
    "overloadRequest": {
      "extraCrateLb": 100,
      "newPayloadLb": 640,
      "admitted": false,
      "neededAction": "real redistribution before departure"
    },
    "dock": {
      "startSeconds": 0,
      "endSeconds": 60,
      "actors": [
        "rower"
      ],
      "activity": "actual docking with line and fitting bank; loading is separate",
      "activeSeconds": 60,
      "clock": "case-local canonical clock, seconds; half-open"
    }
  },
  "expectedOutcomes": {
    "ordinaryPayloadLb": 540,
    "withExtraCrateLb": 640,
    "hardPayloadCapLb": 600,
    "requiredDepthFt": 1
  },
  "readerExplanation": "The occupants and their gear bring the payload to 540 lb even though the cargo crate weighs only 30 lb. Another 100-lb crate is prohibited. One operator Action produces one 20-foot drive event, not another boat turn.",
  "evidenceClass": "authored expectation; named source and arithmetic checks separately executed",
  "worldAuthentication": "All named people, sites and permissions are synthetic premises, not new canonical facts."
}
```

## EX-W16 — Shoring a sinking hull does not repair it

Successful shoring at minute 8 keeps the disabled hull afloat until minute 68. A real recovery reaches the cradle before then. Ordinary repair needs 750 gp of materials and nine active hours. A genuine complete 300-gp service offer is an alternative contract, not another fee added on top.

```json
{
  "id": "EX-W16",
  "schemaVersion": "EX58-boundary-record-v1",
  "status": "authored synthetic expectation; exact review pending",
  "audience": "public synthetic example",
  "title": "Shoring a sinking hull does not repair it",
  "questionIds": [
    "TR-09",
    "TR-14",
    "FL-18"
  ],
  "contractIds": [
    "EC-02",
    "EC-03",
    "EC-08",
    "EC-10"
  ],
  "sourceBinding": {
    "path": "docs/audit/2026-10-08/full-game/ex58-final-gpt-verdict/EX58_WORKED_SEQUENCES.json",
    "bytes": 73808,
    "sha256": "f668c9aff1c836f61e5766db3eed49d62ba2f1a6d638959157e5551223aa2c80",
    "pointer": "/additionalBoundaries/15"
  },
  "actualSyntheticPremises": "A real Keelboat has 0/90 HP at rupture time 0. Its required original hull members survive. Qualified workers Jo and Kai, actual patch stock and a feasible route to a dry cradle exist.",
  "records": {
    "profileId": "mounts-vehicles-and-services.keelboat",
    "initialFloodDeadlineSeconds": 600,
    "shore": {
      "id": "W16-shore",
      "interval": {
        "startSeconds": 180,
        "endSeconds": 480,
        "actors": [
          "Jo",
          "Kai"
        ],
        "activity": "uninterrupted structural shoring",
        "activeSeconds": 300,
        "clock": "case-local canonical clock, seconds; half-open"
      },
      "patchCostGp": 30,
      "stock": "one finite compatible 30-gp patch bill committed once",
      "roll": {
        "actor": "Jo",
        "nativeRoute": "Core fixed-DC task",
        "natural": 11,
        "modifier": 4,
        "DC": 15,
        "total": 15,
        "result": "Success"
      },
      "newDeadlineSeconds": 4080,
      "HPAfter": 0,
      "propulsionRestored": false,
      "sameRuptureSecondShoreAllowed": false
    },
    "towToCradle": {
      "interval": {
        "startSeconds": 480,
        "endSeconds": 3600,
        "actors": [
          "real tug crew"
        ],
        "activity": "actual supported recovery before the deadline",
        "activeSeconds": 3120,
        "clock": "case-local canonical clock, seconds; half-open"
      },
      "newHullCreated": false
    },
    "repairBranch": {
      "materialsGp": 750,
      "qualifiedWorker": "Jo",
      "interval": {
        "startSeconds": 86400,
        "endSeconds": 118800,
        "actors": [
          "Jo"
        ],
        "activity": "nine actual hours at a real supported dry site",
        "activeSeconds": 32400,
        "clock": "case-local canonical clock, seconds; half-open"
      },
      "tools": "compatible carpenter/shipwright tools",
      "roll": {
        "actor": "Jo",
        "nativeRoute": "Core fixed-DC task",
        "natural": 8,
        "modifier": 4,
        "DC": 10,
        "total": 12,
        "result": "Success"
      },
      "HPAfter": 90,
      "reopensOldSalvageClaim": false
    },
    "alternativeServiceBranch": {
      "actualProvider": "Dry-yard crew",
      "completeQuotedServiceGp": 300,
      "materialsIncluded": true,
      "alsoCharge750Gp": false,
      "realLaborStillRequired": true
    },
    "missingPrimaryBranch": {
      "originalHullIrretrievable": true,
      "moneyCreatesReplacementOriginal": false
    }
  },
  "expectedOutcomes": {
    "shoreCostGp": 30,
    "shoreEndsMinute": 8,
    "afloatUntilMinute": 68,
    "repairMaterialsGp": 750,
    "repairHours": 9,
    "alternativeServiceGp": 300
  },
  "readerExplanation": "Successful shoring at minute 8 keeps the disabled hull afloat until minute 68. A real recovery reaches the cradle before then. Ordinary repair needs 750 gp of materials and nine active hours. A genuine complete 300-gp service offer is an alternative contract, not another fee added on top.",
  "evidenceClass": "authored expectation; named source and arithmetic checks separately executed",
  "worldAuthentication": "All named people, sites and permissions are synthetic premises, not new canonical facts."
}
```

## EX-W17 — Paid transport services have real limits

A porter’s physical strength does not enlarge the purchased allowance. Forty actual hauler hours consume five pints, and servicing changes only the service counter. The 1,300-gp teleport quote cannot dispatch anything without the real effect and endpoint.

```json
{
  "id": "EX-W17",
  "schemaVersion": "EX58-boundary-record-v1",
  "status": "authored synthetic expectation; exact review pending",
  "audience": "public synthetic example",
  "title": "Paid transport services have real limits",
  "questionIds": [
    "TR-10",
    "TR-11",
    "TR-12"
  ],
  "contractIds": [
    "EC-02",
    "EC-03",
    "EC-08",
    "EC-10"
  ],
  "sourceBinding": {
    "path": "docs/audit/2026-10-08/full-game/ex58-final-gpt-verdict/EX58_WORKED_SEQUENCES.json",
    "bytes": 73808,
    "sha256": "f668c9aff1c836f61e5766db3eed49d62ba2f1a6d638959157e5551223aa2c80",
    "pointer": "/additionalBoundaries/16"
  },
  "actualSyntheticPremises": "Porter Fen has STR14, a two-Load customer contract and actual 24-lb personal gear. A distinct owned Core hauler has an adjacent qualified operator, real fuel, a service pack and firm route.",
  "records": {
    "porter": {
      "id": "Fen",
      "contractAllowanceLoad": 2,
      "proposedCustomerLoad": 3,
      "physicallyPossible": true,
      "contractAdmission": false,
      "alternative": "actual agreed amended contract or redistribute; no assumed free emergency allowance"
    },
    "hauler": {
      "identity": "Core transport-only hauler",
      "purchaseGp": 500,
      "normalLoad": 20,
      "emergencyLoad": 30,
      "actualCargoLb": 100,
      "actualCargoLoad": 10,
      "operator": "Mira",
      "continuousAdjacentWork": true,
      "hands": 2,
      "movingIntervals": [
        {
          "startSeconds": 0,
          "endSeconds": 28800,
          "actors": [
            "Mira"
          ],
          "activity": "one actual daily moving Watch",
          "activeSeconds": 28800,
          "clock": "case-local canonical clock, seconds; half-open"
        },
        {
          "startSeconds": 86400,
          "endSeconds": 115200,
          "actors": [
            "Mira"
          ],
          "activity": "one actual daily moving Watch",
          "activeSeconds": 28800,
          "clock": "case-local canonical clock, seconds; half-open"
        },
        {
          "startSeconds": 172800,
          "endSeconds": 201600,
          "actors": [
            "Mira"
          ],
          "activity": "one actual daily moving Watch",
          "activeSeconds": 28800,
          "clock": "case-local canonical clock, seconds; half-open"
        },
        {
          "startSeconds": 259200,
          "endSeconds": 288000,
          "actors": [
            "Mira"
          ],
          "activity": "one actual daily moving Watch",
          "activeSeconds": 28800,
          "clock": "case-local canonical clock, seconds; half-open"
        },
        {
          "startSeconds": 345600,
          "endSeconds": 374400,
          "actors": [
            "Mira"
          ],
          "activity": "one actual daily moving Watch",
          "activeSeconds": 28800,
          "clock": "case-local canonical clock, seconds; half-open"
        }
      ],
      "fuel": {
        "originalPints": 5,
        "costCp": 50,
        "fluidMassLb": {
          "numerator": 15,
          "denominator": 4
        },
        "flaskTareLb": {
          "numerator": 5,
          "denominator": 4
        },
        "movingHoursPaid": 40,
        "fuelRemainingPints": 0
      },
      "service": {
        "interval": {
          "startSeconds": 374400,
          "endSeconds": 378000,
          "actors": [
            "Mira"
          ],
          "activity": "actual service with Tinker tools",
          "activeSeconds": 3600,
          "clock": "case-local canonical clock, seconds; half-open"
        },
        "priceCp": 100,
        "packLb": {
          "numerator": 1,
          "denominator": 2
        },
        "serviceCounterBeforeHours": 40,
        "serviceCounterAfterHours": 0,
        "HPBefore": 45,
        "HPAfter": 45,
        "fuelAfterPints": 0
      }
    },
    "teleportOffer": {
      "Tier": 1,
      "acceptedBillLoad": {
        "numerator": 1201,
        "denominator": 100
      },
      "roundedBillLoad": 13,
      "priceGp": 1300,
      "status": "quoted, unpaid",
      "actualOperativeEffect": {
        "presence": "absent"
      },
      "actualDestinationPermission": {
        "presence": "absent"
      },
      "dispatched": false
    }
  },
  "expectedOutcomes": {
    "fuelCpPer8MovingHours": 10,
    "serviceHours": 1,
    "teleportBillLoad": 13,
    "teleportQuoteGp": 1300,
    "priceIsPermission": false
  },
  "readerExplanation": "A porter’s physical strength does not enlarge the purchased allowance. Forty actual hauler hours consume five pints, and servicing changes only the service counter. The 1,300-gp teleport quote cannot dispatch anything without the real effect and endpoint.",
  "evidenceClass": "authored expectation; named source and arithmetic checks separately executed",
  "worldAuthentication": "All named people, sites and permissions are synthetic premises, not new canonical facts."
}
```

## EX-W18 — Casualty pounds and Load are simultaneous constraints

Each carrier supports 90 lb and 4.5 Load with both hands. The coordinated movement is limited by the slower carrier. Petrification multiplies only the body’s pounds; a 1,520-lb payload does not fit this stretcher even though the casualty Load remains six.

```json
{
  "id": "EX-W18",
  "schemaVersion": "EX58-boundary-record-v1",
  "status": "authored synthetic expectation; exact review pending",
  "audience": "public synthetic example",
  "title": "Casualty pounds and Load are simultaneous constraints",
  "questionIds": [
    "TR-12",
    "FL-17",
    "FL-18"
  ],
  "contractIds": [
    "EC-03",
    "EC-08"
  ],
  "sourceBinding": {
    "path": "docs/audit/2026-10-08/full-game/ex58-final-gpt-verdict/EX58_WORKED_SEQUENCES.json",
    "bytes": 73808,
    "sha256": "f668c9aff1c836f61e5766db3eed49d62ba2f1a6d638959157e5551223aa2c80",
    "pointer": "/additionalBoundaries/17"
  },
  "actualSyntheticPremises": "A stable living Medium casualty has a 150-lb body, 20-lb gear and unchanged injury history. Two consenting able carriers, each with STR20, 200-lb/20-Load capacity and no other carried gear, have a real fitting stretcher.",
  "records": {
    "casualty": {
      "id": "patient",
      "bodyLb": 150,
      "gearLb": 20,
      "bodyLoad": 6,
      "gearLoad": 2,
      "HP": 1,
      "stable": true,
      "dyingSaveClockActive": false,
      "injuriesUnchanged": true
    },
    "stretcher": {
      "id": "stretcher-1",
      "emptyLb": 10,
      "Load": 1,
      "patientPayloadLimitLb": 300,
      "bodyLoadLimit": 6,
      "geometryFt": [
        7,
        {
          "numerator": 5,
          "denominator": 2
        },
        {
          "numerator": 1,
          "denominator": 2
        }
      ]
    },
    "carriers": [
      {
        "id": "A",
        "assignedLb": 90,
        "assignedLoad": {
          "numerator": 9,
          "denominator": 2
        },
        "capacityLb": 200,
        "capacityLoad": 20,
        "hands": 2,
        "SpeedFt": 30
      },
      {
        "id": "B",
        "assignedLb": 90,
        "assignedLoad": {
          "numerator": 9,
          "denominator": 2
        },
        "capacityLb": 200,
        "capacityLoad": 20,
        "hands": 2,
        "SpeedFt": 25
      }
    ],
    "movement": {
      "coordinatedSpeedFt": 25,
      "oneCarrierDashPaysOther": false
    },
    "petrifiedAlternative": {
      "bodyLb": 1500,
      "gearLb": 20,
      "stretcherPayloadLb": 1520,
      "admitted": false,
      "bodyLoadStill": 6
    },
    "history": {
      "ownershipTransferResetsHarvest": false,
      "healingCreatesFreshSalvage": false
    }
  },
  "expectedOutcomes": {
    "totalPhysicalLb": 180,
    "eachLb": 90,
    "totalLoad": 9,
    "eachLoad": {
      "numerator": 9,
      "denominator": 2
    },
    "petrifiedBodyLb": 1500
  },
  "readerExplanation": "Each carrier supports 90 lb and 4.5 Load with both hands. The coordinated movement is limited by the slower carrier. Petrification multiplies only the body’s pounds; a 1,520-lb payload does not fit this stretcher even though the casualty Load remains six.",
  "evidenceClass": "authored expectation; named source and arithmetic checks separately executed",
  "worldAuthentication": "All named people, sites and permissions are synthetic premises, not new canonical facts."
}
```

## EX-W19 — Preserve old Integrity and credible current HP

The explicitly interpreted old cart becomes 20/30 HP. The other stays at its credible 5/30; historical Integrity cannot heal it. A real three-hour repair uses 3.75 gp of materials. Terminal dismantling is a different state and does not reopen an old claim.

```json
{
  "id": "EX-W19",
  "schemaVersion": "EX58-boundary-record-v1",
  "status": "authored synthetic expectation; exact review pending",
  "audience": "public synthetic example",
  "title": "Preserve old Integrity and credible current HP",
  "questionIds": [
    "FL-18",
    "TR-14"
  ],
  "contractIds": [
    "EC-08",
    "EC-12"
  ],
  "sourceBinding": {
    "path": "docs/audit/2026-10-08/full-game/ex58-final-gpt-verdict/EX58_WORKED_SEQUENCES.json",
    "bytes": 73808,
    "sha256": "f668c9aff1c836f61e5766db3eed49d62ba2f1a6d638959157e5551223aa2c80",
    "pointer": "/additionalBoundaries/18"
  },
  "actualSyntheticPremises": "Two original carts have the same historical Integrity value. Only cart B also has reliable current HP. This is an explicit synthetic interpretation, not a real-save migration.",
  "records": {
    "raw": {
      "base64": "eyJjYXJ0QSI6eyJpbnRlZ3JpdHkiOjJ9LCJjYXJ0QiI6eyJocCI6NSwibWF4SHAiOjMwLCJpbnRlZ3JpdHkiOjJ9fQ==",
      "sha256": "d4ae23867273af773fed2932ed6a774c7745cc125bb12e090c021c1b506777cf",
      "producer": "declared legacy fixture"
    },
    "cartA": {
      "maxHP": 30,
      "credibleCurrentHPPresence": "absent",
      "legacyIntegrity": 2,
      "chosenInterpretation": "floor(H × I / 3) once",
      "derivedHP": 20
    },
    "cartB": {
      "maxHP": 30,
      "credibleCurrentHP": 5,
      "legacyIntegrity": 2,
      "derivedHP": 5
    },
    "repair": {
      "actor": "actual trained carpenter",
      "materialsCp": 375,
      "interval": {
        "startSeconds": 0,
        "endSeconds": 10800,
        "actors": [
          "carpenter"
        ],
        "activity": "actual Cart repair using surviving primaries and tools",
        "activeSeconds": 10800,
        "clock": "case-local canonical clock, seconds; half-open"
      },
      "roll": {
        "actor": "carpenter",
        "nativeRoute": "Core fixed-DC task",
        "natural": 8,
        "modifier": 3,
        "DC": 10,
        "total": 11,
        "result": "Success"
      },
      "resultHP": 30,
      "newCharges": 0,
      "creationXP": 0
    },
    "terminalCartC": {
      "alreadyDismantled": true,
      "oldResidueClaim": "closed",
      "ordinaryRepairAdmission": false
    }
  },
  "expectedOutcomes": {
    "A_HP": 20,
    "B_HP": 5,
    "repairGp": {
      "numerator": 15,
      "denominator": 4
    },
    "repairHours": 3,
    "realSavesChanged": 0
  },
  "readerExplanation": "The explicitly interpreted old cart becomes 20/30 HP. The other stays at its credible 5/30; historical Integrity cannot heal it. A real three-hour repair uses 3.75 gp of materials. Terminal dismantling is a different state and does not reopen an old claim.",
  "evidenceClass": "authored expectation; named source and arithmetic checks separately executed",
  "worldAuthentication": "All named people, sites and permissions are synthetic premises, not new canonical facts."
}
```

## EX-W20 — One final copper rounding in the chosen valuation domain

The sale yields 2 cp and the purchase costs 3 cp, each rounded once. The real recipe reference uses its original batch and quantity plus the actual body. A negative artifact estimate is not a forced transaction or debt.

```json
{
  "id": "EX-W20",
  "schemaVersion": "EX58-boundary-record-v1",
  "status": "authored synthetic expectation; exact review pending",
  "audience": "public synthetic example",
  "title": "One final copper rounding in the chosen valuation domain",
  "questionIds": [
    "FL-19",
    "FL-20",
    "FL-21"
  ],
  "contractIds": [
    "EC-09",
    "EC-10"
  ],
  "sourceBinding": {
    "path": "docs/audit/2026-10-08/full-game/ex58-final-gpt-verdict/EX58_WORKED_SEQUENCES.json",
    "bytes": 73808,
    "sha256": "f668c9aff1c836f61e5766db3eed49d62ba2f1a6d638959157e5551223aa2c80",
    "pointer": "/additionalBoundaries/19"
  },
  "actualSyntheticPremises": "A finite buyer accepts one homogeneous ordinary sale at 7/3 cp. A separate actual purchase has the same exact quote. Both parties have authority and enough currency; each quote expires at hour 1.",
  "records": {
    "sale": {
      "id": "W20-sale",
      "quantity": 1,
      "domain": "ordinary finite quote",
      "exactCp": {
        "numerator": 7,
        "denominator": 3
      },
      "settledCp": 2,
      "timeSeconds": 600,
      "status": "paid"
    },
    "purchase": {
      "id": "W20-buy",
      "quantity": 1,
      "domain": "ordinary finite quote",
      "exactCp": {
        "numerator": 7,
        "denominator": 3
      },
      "settledCp": 3,
      "timeSeconds": 900,
      "status": "paid"
    },
    "recipeReference": {
      "recipeId": "recipe-122",
      "originalBatchGp": 102,
      "originalQ": 1,
      "actualBodyGp": 50,
      "finishedReferenceGp": 152,
      "MasterworkOutcomeAddsArtifactFactor": false
    },
    "artifactEstimate": {
      "knownGrossGp": 15,
      "realEstimatedCostsGp": 20,
      "netEstimateGp": -5,
      "transactionAccepted": false,
      "automaticDebtGp": 0
    },
    "missingArtifactInputs": {
      "BaseFunctionValue": {
        "presence": "absent"
      },
      "GateTierMultiplier": {
        "presence": "absent"
      },
      "universalDefaultInvented": false
    }
  },
  "expectedOutcomes": {
    "saleCp": 2,
    "purchaseCp": 3,
    "negativeEstimateGp": -5,
    "automaticDebtGp": 0
  },
  "readerExplanation": "The sale yields 2 cp and the purchase costs 3 cp, each rounded once. The real recipe reference uses its original batch and quantity plus the actual body. A negative artifact estimate is not a forced transaction or debt.",
  "evidenceClass": "authored expectation; named source and arithmetic checks separately executed",
  "worldAuthentication": "All named people, sites and permissions are synthetic premises, not new canonical facts."
}
```

## EX-W21 — Net share, prior payments and the next reserve

The sponsor receives 20% of 112 gp, or 22.40 gp. Net proceeds are 89.60 gp; after 20.20 gp of unique other costs, true profit is 69.40 gp. The agreed reserve leaves 49.40 gp to divide. The paid inspection is not paid again.

```json
{
  "id": "EX-W21",
  "schemaVersion": "EX58-boundary-record-v1",
  "status": "authored synthetic expectation; exact review pending",
  "audience": "public synthetic example",
  "title": "Net share, prior payments and the next reserve",
  "questionIds": [
    "FL-21",
    "FL-22"
  ],
  "contractIds": [
    "EC-09",
    "EC-10"
  ],
  "sourceBinding": {
    "path": "docs/audit/2026-10-08/full-game/ex58-final-gpt-verdict/EX58_WORKED_SEQUENCES.json",
    "bytes": 73808,
    "sha256": "f668c9aff1c836f61e5766db3eed49d62ba2f1a6d638959157e5551223aa2c80",
    "pointer": "/additionalBoundaries/20"
  },
  "actualSyntheticPremises": "The actual integrated expedition sold its licensed crate for 120 gp under one 5% levy and a signed 20% net-share contract. Its 2-gp mandatory inspection was already paid.",
  "records": {
    "sourceFlowId": "EX-FLOW-01-CANDIDATE",
    "transactions": [
      {
        "transactionId": "buy-human-0",
        "time": {
          "epochId": "EX-FLOW-SYNTHETIC-EPOCH",
          "elapsedSeconds": 52400,
          "departurePreparationOffsetSeconds": -34000
        },
        "relativeTime": -34000,
        "payer": "Expedition cash",
        "payee": "Provisioner",
        "exactCp": {
          "numerator": 504,
          "denominator": 1
        },
        "settledCp": 504,
        "rounding": "purchase/fee ceil once",
        "status": "paid",
        "kind": "operating cost",
        "episode": "first"
      },
      {
        "transactionId": "buy-animal-0",
        "time": {
          "epochId": "EX-FLOW-SYNTHETIC-EPOCH",
          "elapsedSeconds": 52500,
          "departurePreparationOffsetSeconds": -33900
        },
        "relativeTime": -33900,
        "payer": "Expedition cash",
        "payee": "Provisioner",
        "exactCp": {
          "numerator": 16,
          "denominator": 1
        },
        "settledCp": 16,
        "rounding": "purchase/fee ceil once",
        "status": "paid",
        "kind": "operating cost",
        "episode": "first"
      },
      {
        "transactionId": "premium-0",
        "time": {
          "epochId": "EX-FLOW-SYNTHETIC-EPOCH",
          "elapsedSeconds": 53400,
          "departurePreparationOffsetSeconds": -33000
        },
        "relativeTime": -33000,
        "payer": "Expedition cash",
        "payee": "Underwriter",
        "exactCp": {
          "numerator": 600,
          "denominator": 1
        },
        "settledCp": 600,
        "rounding": "purchase/fee ceil once",
        "status": "paid",
        "kind": "operating cost",
        "episode": "first"
      },
      {
        "transactionId": "room-fee",
        "time": {
          "epochId": "EX-FLOW-SYNTHETIC-EPOCH",
          "elapsedSeconds": 148992,
          "departurePreparationOffsetSeconds": 62592
        },
        "relativeTime": 62592,
        "payer": "Expedition cash",
        "payee": "Sera",
        "exactCp": {
          "numerator": 800,
          "denominator": 1
        },
        "settledCp": 800,
        "rounding": "purchase/fee ceil once",
        "status": "paid",
        "kind": "operating cost",
        "episode": "first"
      },
      {
        "transactionId": "stable-fee",
        "time": {
          "epochId": "EX-FLOW-SYNTHETIC-EPOCH",
          "elapsedSeconds": 148992,
          "departurePreparationOffsetSeconds": 62592
        },
        "relativeTime": 62592,
        "payer": "Expedition cash",
        "payee": "Toma",
        "exactCp": {
          "numerator": 100,
          "denominator": 1
        },
        "settledCp": 100,
        "rounding": "purchase/fee ceil once",
        "status": "paid",
        "kind": "operating cost",
        "episode": "first"
      },
      {
        "transactionId": "mandatory-inspection",
        "time": {
          "epochId": "EX-FLOW-SYNTHETIC-EPOCH",
          "elapsedSeconds": 150192,
          "departurePreparationOffsetSeconds": 63792
        },
        "relativeTime": 63792,
        "payer": "Expedition cash",
        "payee": "Haven inspector",
        "exactCp": {
          "numerator": 200,
          "denominator": 1
        },
        "settledCp": 200,
        "rounding": "purchase/fee ceil once",
        "status": "paid",
        "kind": "mandatory",
        "episode": "first"
      },
      {
        "transactionId": "sale-crate",
        "time": {
          "epochId": "EX-FLOW-SYNTHETIC-EPOCH",
          "elapsedSeconds": 155592,
          "departurePreparationOffsetSeconds": 69192
        },
        "relativeTime": 69192,
        "payer": "Pera",
        "payee": "Expedition cash",
        "exactCp": {
          "numerator": 12000,
          "denominator": 1
        },
        "settledCp": 12000,
        "rounding": "sale floor once",
        "status": "paid",
        "kind": "sale",
        "episode": "first"
      },
      {
        "transactionId": "levy",
        "time": {
          "epochId": "EX-FLOW-SYNTHETIC-EPOCH",
          "elapsedSeconds": 157392,
          "departurePreparationOffsetSeconds": 70992
        },
        "relativeTime": 70992,
        "payer": "Expedition cash",
        "payee": "Haven treasury",
        "exactCp": {
          "numerator": 600,
          "denominator": 1
        },
        "settledCp": 600,
        "rounding": "purchase/fee ceil once",
        "status": "paid",
        "kind": "tax",
        "episode": "first"
      },
      {
        "transactionId": "guild-share",
        "time": {
          "epochId": "EX-FLOW-SYNTHETIC-EPOCH",
          "elapsedSeconds": 157392,
          "departurePreparationOffsetSeconds": 70992
        },
        "relativeTime": 70992,
        "payer": "Expedition cash",
        "payee": "Local guild",
        "exactCp": {
          "numerator": 2240,
          "denominator": 1
        },
        "settledCp": 2240,
        "rounding": "purchase/fee ceil once",
        "status": "paid",
        "kind": "sponsor",
        "episode": "first"
      },
      {
        "transactionId": "distribution-Arin",
        "time": {
          "epochId": "EX-FLOW-SYNTHETIC-EPOCH",
          "elapsedSeconds": 226800,
          "departurePreparationOffsetSeconds": 140400
        },
        "relativeTime": 140400,
        "payer": "Expedition cash",
        "payee": "Arin",
        "exactCp": {
          "numerator": 1235,
          "denominator": 1
        },
        "settledCp": 1235,
        "rounding": "purchase/fee ceil once",
        "status": "paid",
        "kind": "profit distribution",
        "episode": "first"
      },
      {
        "transactionId": "distribution-Bea",
        "time": {
          "epochId": "EX-FLOW-SYNTHETIC-EPOCH",
          "elapsedSeconds": 226800,
          "departurePreparationOffsetSeconds": 140400
        },
        "relativeTime": 140400,
        "payer": "Expedition cash",
        "payee": "Bea",
        "exactCp": {
          "numerator": 1235,
          "denominator": 1
        },
        "settledCp": 1235,
        "rounding": "purchase/fee ceil once",
        "status": "paid",
        "kind": "profit distribution",
        "episode": "first"
      },
      {
        "transactionId": "distribution-Cora",
        "time": {
          "epochId": "EX-FLOW-SYNTHETIC-EPOCH",
          "elapsedSeconds": 226800,
          "departurePreparationOffsetSeconds": 140400
        },
        "relativeTime": 140400,
        "payer": "Expedition cash",
        "payee": "Cora",
        "exactCp": {
          "numerator": 1235,
          "denominator": 1
        },
        "settledCp": 1235,
        "rounding": "purchase/fee ceil once",
        "status": "paid",
        "kind": "profit distribution",
        "episode": "first"
      },
      {
        "transactionId": "distribution-Dane",
        "time": {
          "epochId": "EX-FLOW-SYNTHETIC-EPOCH",
          "elapsedSeconds": 226800,
          "departurePreparationOffsetSeconds": 140400
        },
        "relativeTime": 140400,
        "payer": "Expedition cash",
        "payee": "Dane",
        "exactCp": {
          "numerator": 1235,
          "denominator": 1
        },
        "settledCp": 1235,
        "rounding": "purchase/fee ceil once",
        "status": "paid",
        "kind": "profit distribution",
        "episode": "first"
      },
      {
        "transactionId": "next-stock",
        "time": {
          "epochId": "EX-FLOW-SYNTHETIC-EPOCH",
          "elapsedSeconds": 228600,
          "departurePreparationOffsetSeconds": 142200
        },
        "relativeTime": 142200,
        "payer": "Expedition cash",
        "payee": "Provisioner",
        "exactCp": {
          "numerator": 520,
          "denominator": 1
        },
        "settledCp": 520,
        "rounding": "purchase/fee ceil once",
        "status": "paid",
        "kind": "next inventory purchase",
        "episode": "next"
      }
    ],
    "settlement": {
      "grossCp": 12000,
      "taxCp": 600,
      "mandatoryCp": 200,
      "sponsorBaseCp": 11200,
      "sponsorCp": 2240,
      "netCp": 8960,
      "uniqueOtherOperatingCostsCp": 2020,
      "trueProfitCp": 6940,
      "nextReserveCp": 2000,
      "distributionCp": 4940,
      "eachCharacterCp": 1235,
      "cashBeforeDistributionCp": 9940,
      "cashAfterDistributionCp": 5000,
      "nextProcurementCp": 520,
      "finalCashCp": 4480,
      "capitalStillCashCp": 3000,
      "unspentEarmarkCp": 1480,
      "nextInventoryPaidCostCp": 520,
      "unpaidLiabilitiesCp": 0
    },
    "priorMandatoryReceipt": "mandatory-inspection",
    "newMandatoryPaymentRequested": false,
    "alternativeGrossShareContract": {
      "selected": false,
      "automaticallyStacked": false
    },
    "levy": {
      "selectedHighestRate": {
        "numerator": 1,
        "denominator": 20
      },
      "additionalLower3PercentCharged": false
    },
    "paidVersusOwed": {
      "allListedCostsPaid": true,
      "newUnfundedLiabilityCreated": false
    }
  },
  "expectedOutcomes": {
    "grossCp": 12000,
    "taxCp": 600,
    "mandatoryCp": 200,
    "sponsorBaseCp": 11200,
    "sponsorCp": 2240,
    "netCp": 8960,
    "otherCostsCp": 2020,
    "trueProfitCp": 6940,
    "reserveCp": 2000,
    "distributionCp": 4940
  },
  "readerExplanation": "The sponsor receives 20% of 112 gp, or 22.40 gp. Net proceeds are 89.60 gp; after 20.20 gp of unique other costs, true profit is 69.40 gp. The agreed reserve leaves 49.40 gp to divide. The paid inspection is not paid again.",
  "evidenceClass": "authored expectation; named source and arithmetic checks separately executed",
  "worldAuthentication": "All named people, sites and permissions are synthetic premises, not new canonical facts."
}
```

## EX-W22 — Cumulative insurance claims

The first 40-gp loss earns 16 gp after the one deductible. When total loss reaches 100 gp, total entitlement is 70 gp, so only another 54 gp is due. A repeated notice pays nothing.

```json
{
  "id": "EX-W22",
  "schemaVersion": "EX58-boundary-record-v1",
  "status": "authored synthetic expectation; exact review pending",
  "audience": "public synthetic example",
  "title": "Cumulative insurance claims",
  "questionIds": [
    "FL-22"
  ],
  "contractIds": [
    "EC-09",
    "EC-10"
  ],
  "sourceBinding": {
    "path": "docs/audit/2026-10-08/full-game/ex58-final-gpt-verdict/EX58_WORKED_SEQUENCES.json",
    "bytes": 73808,
    "sha256": "f668c9aff1c836f61e5766db3eed49d62ba2f1a6d638959157e5551223aa2c80",
    "pointer": "/additionalBoundaries/21"
  },
  "actualSyntheticPremises": "A documented ordinary cargo policy insures 100 gp. Its 5-gp ordinary-cargo premium is paid before loss; documented provenance independently selects the 90% payout rate. There is one 20-gp episode deductible.",
  "records": {
    "policy": {
      "id": "W22-policy",
      "insuredCp": 10000,
      "premiumCp": 500,
      "premiumPaidAtSeconds": 0,
      "firstLossAtSeconds": 3600,
      "provenanceRate": {
        "numerator": 9,
        "denominator": 10
      },
      "deductibleCp": 2000
    },
    "claims": [
      {
        "id": "loss-A",
        "lossAtSeconds": 3600,
        "actualLossCp": 4000,
        "cumulativeLossCp": 4000,
        "authenticatedNoticeSeconds": 7200,
        "exam": {
          "startSeconds": 7200,
          "endSeconds": 14400,
          "actors": [
            "adjuster"
          ],
          "activity": "actual qualified examination of records and remaining cargo",
          "activeSeconds": 7200,
          "clock": "case-local canonical clock, seconds; half-open"
        },
        "entitlementCp": 1600,
        "previousPaidCp": 0,
        "newPayoutCp": 1600
      },
      {
        "id": "loss-B",
        "lossAtSeconds": 18000,
        "actualLossCp": 6000,
        "cumulativeLossCp": 10000,
        "authenticatedNoticeSeconds": 21600,
        "exam": {
          "startSeconds": 21600,
          "endSeconds": 28800,
          "actors": [
            "adjuster"
          ],
          "activity": "actual qualified second examination",
          "activeSeconds": 7200,
          "clock": "case-local canonical clock, seconds; half-open"
        },
        "entitlementCp": 7000,
        "previousPaidCp": 1600,
        "newPayoutCp": 5400
      },
      {
        "id": "loss-A-replayed-notice",
        "sameCause": "loss-A",
        "newLossCp": 0,
        "newPayoutCp": 0
      }
    ],
    "recoveries": {
      "actualRecoveredPropertyCp": 0,
      "futureRecoveryMustUseActualSubrogationTerms": true
    },
    "notCoveredByPrice": [
      "unproved loss",
      "later retroactive insurance",
      "revival",
      "new material"
    ]
  },
  "expectedOutcomes": {
    "firstPayoutCp": 1600,
    "totalEntitlementCp": 7000,
    "additionalCp": 5400,
    "replayCp": 0
  },
  "readerExplanation": "The first 40-gp loss earns 16 gp after the one deductible. When total loss reaches 100 gp, total entitlement is 70 gp, so only another 54 gp is due. A repeated notice pays nothing.",
  "evidenceClass": "authored expectation; named source and arithmetic checks separately executed",
  "worldAuthentication": "All named people, sites and permissions are synthetic premises, not new canonical facts."
}
```

## EX-W23 — Correct an initial background contribution without deleting history

Replace only the proven bad initialization, then replay the genuine earned event: −1 + 1 = 0. Preserve original bytes, duplicate occurrences and all unknown, null, zero, boolean and string values. Without that history, the current value is not silently replaced.

```json
{
  "id": "EX-W23",
  "schemaVersion": "EX58-boundary-record-v1",
  "status": "authored synthetic expectation; exact review pending",
  "audience": "public synthetic example",
  "title": "Correct an initial background contribution without deleting history",
  "questionIds": [
    "FL-23",
    "RP-A01",
    "RP-A02",
    "RP-A03",
    "RP-A04",
    "RP-A05",
    "RP-A06"
  ],
  "contractIds": [
    "EC-12",
    "EC-15"
  ],
  "sourceBinding": {
    "path": "docs/audit/2026-10-08/full-game/ex58-final-gpt-verdict/EX58_WORKED_SEQUENCES.json",
    "bytes": 73808,
    "sha256": "f668c9aff1c836f61e5766db3eed49d62ba2f1a6d638959157e5551223aa2c80",
    "pointer": "/additionalBoundaries/22"
  },
  "actualSyntheticPremises": "The original producer and erroneous Cult Escapee initialization event are evidenced. The receiving religious authority genuinely suspected the escaped cult. One later earned +1 event has its own real cause.",
  "records": {
    "rawSource": {
      "base64": "eyJyZWxpZ2lvdXMtb3JkZXJzIjoyLCJ1bmtub3duLWxvY2FsIjo1LCJleHBsaWNpdC1udWxsIjpudWxsLCJ6ZXJvIjowLCJmYWxzZSI6ZmFsc2UsIm51bWVyaWMtc3RyaW5nIjoiMSIsImR1cGxpY2F0ZSI6MSwiZHVwbGljYXRlIjoyfQ==",
      "sha256": "d2418ff01bc340f7826fdbe7790e425c63f32ac9af13c3b9ab69ab7c2bad8c50",
      "orderedMembers": [
        [
          "religious-orders",
          2
        ],
        [
          "unknown-local",
          5
        ],
        [
          "explicit-null",
          null
        ],
        [
          "zero",
          0
        ],
        [
          "false",
          false
        ],
        [
          "numeric-string",
          "1"
        ],
        [
          "duplicate",
          1
        ],
        [
          "duplicate",
          2
        ]
      ],
      "duplicateKeysRemainAmbiguous": true,
      "realSave": false
    },
    "binding": {
      "subject": "Cult Escapee A",
      "institution": "actual local suspecting authority",
      "sourceCategory": "religious-orders",
      "policy": "standing-v1"
    },
    "initialContribution": {
      "id": "bg-init-1",
      "originalErroneousValue": 1,
      "originalSourceRetained": true,
      "replacementValue": -1,
      "why": "full qualitative Disliked clause"
    },
    "earnedEvents": [
      {
        "id": "earned-1",
        "cause": "witnessed actual helpful deed",
        "delta": 1
      }
    ],
    "derived": {
      "oldCurrent": 2,
      "correctedInitial": -1,
      "replayedEarned": 1,
      "correctedCurrent": 0,
      "band": "Neutral"
    },
    "unknownFields": {
      "unknown-local": {
        "raw": 5,
        "interpretation": "unresolved"
      },
      "explicit-null": {
        "presence": "null"
      },
      "zero": {
        "presence": "value",
        "raw": 0
      },
      "false": {
        "presence": "value",
        "rawType": "boolean",
        "raw": false
      },
      "numeric-string": {
        "presence": "value",
        "rawType": "string",
        "raw": "1"
      }
    },
    "missingHistoryBranch": {
      "reportedCurrent": 2,
      "actualInitializationUnavailable": true,
      "replaceWithMinus1": false,
      "status": "unresolved; preserve source"
    }
  },
  "expectedOutcomes": {
    "correctedInitialization": -1,
    "earnedDelta": 1,
    "correctedCurrent": 0,
    "unknownSourceKeysDeleted": 0
  },
  "readerExplanation": "Replace only the proven bad initialization, then replay the genuine earned event: −1 + 1 = 0. Preserve original bytes, duplicate occurrences and all unknown, null, zero, boolean and string values. Without that history, the current value is not silently replaced.",
  "evidenceClass": "authored expectation; named source and arithmetic checks separately executed",
  "worldAuthentication": "All named people, sites and permissions are synthetic premises, not new canonical facts."
}
```

## EX-W24 — Recompute a scene from its opening standing

The first event hits the range cap at +3. After both events, the signed scene sum is zero, so recomputing from the original +2 returns +2. Subtracting from the already clamped intermediate value would be wrong.

```json
{
  "id": "EX-W24",
  "schemaVersion": "EX58-boundary-record-v1",
  "status": "authored synthetic expectation; exact review pending",
  "audience": "public synthetic example",
  "title": "Recompute a scene from its opening standing",
  "questionIds": [
    "FL-23",
    "RP-A01",
    "RP-A04",
    "RP-A06",
    "SO-10"
  ],
  "contractIds": [
    "EC-11",
    "EC-12"
  ],
  "sourceBinding": {
    "path": "docs/audit/2026-10-08/full-game/ex58-final-gpt-verdict/EX58_WORKED_SEQUENCES.json",
    "bytes": 73808,
    "sha256": "f668c9aff1c836f61e5766db3eed49d62ba2f1a6d638959157e5551223aa2c80",
    "pointer": "/additionalBoundaries/23"
  },
  "actualSyntheticPremises": "A known standing-v1 relationship opens at +2. Two distinct real events in the same institutional scene propose +2 and −2; both are known to the institution.",
  "records": {
    "sceneId": "W24-scene",
    "openingVersion": 10,
    "openingScore": 2,
    "events": [
      {
        "id": "major-help",
        "cause": "delivered promised aid",
        "proposed": 2,
        "signedSum": 2,
        "cappedSceneDelta": 2,
        "current": 3,
        "rangeOverflow": 1
      },
      {
        "id": "major-harm",
        "cause": "separate witnessed broken agreement",
        "proposed": -2,
        "signedSum": 0,
        "cappedSceneDelta": 0,
        "current": 2,
        "rangeOverflow": 0
      }
    ],
    "duplicate": {
      "id": "major-help",
      "additionalDelta": 0
    },
    "display": {
      "validPlus3Label": "Honored",
      "roundTripToPlus2": false,
      "oldQualitativeHonoredWithoutHistory": "qualitative label only; numeric 2 or3 unresolved"
    },
    "incorrectSequentialCalculation": {
      "fromClamped3Minus2": 1,
      "accepted": false
    }
  },
  "expectedOutcomes": {
    "afterFirst": 3,
    "afterBoth": 2,
    "incorrectSequentialResult": 1,
    "overflowBanked": false
  },
  "readerExplanation": "The first event hits the range cap at +3. After both events, the signed scene sum is zero, so recomputing from the original +2 returns +2. Subtracting from the already clamped intermediate value would be wrong.",
  "evidenceClass": "authored expectation; named source and arithmetic checks separately executed",
  "worldAuthentication": "All named people, sites and permissions are synthetic premises, not new canonical facts."
}
```

## EX-W25 — Honor the stated social DC and a separate costly offer

Meeting DC 12 grants the stated terms. Missing it by one remains Failure even if the player separately accepts the predeclared paid escort offer. Useful full-interval Help gives one advantage, and a new speaker alone does not reset the scene.

```json
{
  "id": "EX-W25",
  "schemaVersion": "EX58-boundary-record-v1",
  "status": "authored synthetic expectation; exact review pending",
  "audience": "public synthetic example",
  "title": "Honor the stated social DC and a separate costly offer",
  "questionIds": [
    "SO-01",
    "SO-02",
    "SO-03",
    "SO-06",
    "SO-07",
    "SO-09"
  ],
  "contractIds": [
    "EC-02",
    "EC-10",
    "EC-11"
  ],
  "sourceBinding": {
    "path": "docs/audit/2026-10-08/full-game/ex58-final-gpt-verdict/EX58_WORKED_SEQUENCES.json",
    "bytes": 73808,
    "sha256": "f668c9aff1c836f61e5766db3eed49d62ba2f1a6d638959157e5551223aa2c80",
    "pointer": "/additionalBoundaries/24"
  },
  "actualSyntheticPremises": "Warden Ione can authorize one supervised visit. She understands Common. The declared negotiation lasts ten minutes, DC 12, with success granting that visit and failure optionally offering it for a real 5-gp escort fee.",
  "records": {
    "frame": {
      "Want": "one supervised visit",
      "Leverage": "actual appointment letter",
      "Limit": "warden cannot transfer ownership or waive another authority",
      "ClockSeconds": 600,
      "Witness": "desk clerk"
    },
    "successBranch": {
      "interval": {
        "startSeconds": 0,
        "endSeconds": 600,
        "actors": [
          "A",
          "Ione"
        ],
        "activity": "actual negotiation",
        "activeSeconds": 600,
        "clock": "case-local canonical clock, seconds; half-open"
      },
      "roll": {
        "actor": "A",
        "nativeRoute": "Core fixed-DC task",
        "natural": 8,
        "modifier": 4,
        "DC": 12,
        "total": 12,
        "result": "Success"
      },
      "visitGranted": true,
      "newFee": 0
    },
    "failureBranch": {
      "interval": {
        "startSeconds": 0,
        "endSeconds": 600,
        "actors": [
          "A",
          "Ione"
        ],
        "activity": "alternative same opening negotiation",
        "activeSeconds": 600,
        "clock": "case-local canonical clock, seconds; half-open"
      },
      "roll": {
        "actor": "A",
        "nativeRoute": "Core fixed-DC task",
        "natural": 7,
        "modifier": 4,
        "DC": 12,
        "total": 11,
        "result": "Failure"
      },
      "outcomeStill": "Failure",
      "optionalOffer": {
        "id": "escort-offer",
        "amountCp": 500,
        "payerCashCp": 700,
        "expiresAtSeconds": 1200,
        "actualEscort": "Fen"
      },
      "acceptanceAlternative": {
        "playerChooses": true,
        "paymentCp": 500,
        "cashAfterCp": 200,
        "supervisedVisitGranted": true
      },
      "declineAlternative": {
        "paymentCp": 0,
        "cashAfterCp": 700,
        "visitGranted": false
      }
    },
    "helpAlternative": {
      "helper": "Mira",
      "work": {
        "startSeconds": 0,
        "endSeconds": 600,
        "actors": [
          "Mira"
        ],
        "activity": "present useful appointment evidence throughout approach",
        "activeSeconds": 600,
        "clock": "case-local canonical clock, seconds; half-open"
      },
      "advantageDice": [
        3,
        8
      ],
      "selectedNatural": 8,
      "modifierStill": 4,
      "stackedHelperPB": 0
    },
    "retry": {
      "rotatedSpeakerSameFacts": "no roll",
      "newAuthenticatedLetterAt1800": "new feasible ten-minute approach, separately recorded"
    }
  },
  "expectedOutcomes": {
    "successTotal": 12,
    "failureTotal": 11,
    "DC": 12,
    "optionalCostCp": 500,
    "ordinaryDurationSeconds": 600
  },
  "readerExplanation": "Meeting DC 12 grants the stated terms. Missing it by one remains Failure even if the player separately accepts the predeclared paid escort offer. Useful full-interval Help gives one advantage, and a new speaker alone does not reset the scene.",
  "evidenceClass": "authored expectation; named source and arithmetic checks separately executed",
  "worldAuthentication": "All named people, sites and permissions are synthetic premises, not new canonical facts."
}
```

## EX-W26 — Standing, conditions and actual institutional knowledge

Honored standing can affect an actual offered term without becoming +2 on the die. Charmed supplies only its real condition predicates and does not confer the clerk’s missing authority. Private acts need a genuine information path before an institution can react.

```json
{
  "id": "EX-W26",
  "schemaVersion": "EX58-boundary-record-v1",
  "status": "authored synthetic expectation; exact review pending",
  "audience": "public synthetic example",
  "title": "Standing, conditions and actual institutional knowledge",
  "questionIds": [
    "SO-04",
    "SO-05",
    "SO-08",
    "SO-10"
  ],
  "contractIds": [
    "EC-11",
    "EC-12",
    "EC-13"
  ],
  "sourceBinding": {
    "path": "docs/audit/2026-10-08/full-game/ex58-final-gpt-verdict/EX58_WORKED_SEQUENCES.json",
    "bytes": 73808,
    "sha256": "f668c9aff1c836f61e5766db3eed49d62ba2f1a6d638959157e5551223aa2c80",
    "pointer": "/additionalBoundaries/25"
  },
  "actualSyntheticPremises": "A character has standing +2 with one real local institution. Separate branches supply an already lawfully applied Charmed or Frightened condition with actual source and deadline; the example does not cast a missing spell.",
  "records": {
    "standing": {
      "institution": "local desk",
      "score": 2,
      "band": "Honored",
      "automaticD20Bonus": 0,
      "actualOfferedAccess": "predeclared appointment priority"
    },
    "charmedBranch": {
      "target": "clerk",
      "charmer": "A",
      "originalConditionEvent": "existing-lawful-condition-1",
      "endsAtSeconds": 600,
      "legalRequest": "one of two actual available appointment slots the clerk can assign",
      "requestInterval": {
        "startSeconds": 0,
        "endSeconds": 60,
        "actors": [
          "A",
          "clerk"
        ],
        "activity": "one actual minute of request and response",
        "activeSeconds": 60,
        "clock": "case-local canonical clock, seconds; half-open"
      },
      "declaredDC": 13,
      "actualSocialPredicateApplies": true,
      "advantageDice": [
        5,
        14
      ],
      "otherModifier": 3,
      "selectedTotal": 17,
      "harmAgainstCharmerAllowed": false,
      "obedienceGranted": false,
      "separateImpossibleRequest": {
        "request": "transfer third-party title",
        "resolution": "impossible now",
        "rollMade": false
      }
    },
    "frightenedBranch": {
      "source": "visible actual threat",
      "conditionEndsAtSeconds": 60,
      "attackAndCheckDisadvantageWhileVisible": true,
      "voluntaryApproachAllowed": false,
      "hidingSourceRemovesOnlyVisibilityDependentPenalty": true,
      "intimidationRollCreatesCondition": false
    },
    "alignment": {
      "rawDescriptorRetained": "unknown interpretation",
      "automaticModifier": 0,
      "deepInterpretationMade": false
    },
    "knowledge": [
      {
        "id": "private-help",
        "knownBy": [
          "recipient"
        ],
        "institutionReceipt": false,
        "globalStandingChanges": 0
      },
      {
        "id": "later-genuine-report",
        "recipient": "local desk",
        "receivedAtSeconds": 7200,
        "actualAttribution": true,
        "onlyRelevantInstitutionMayRespond": true
      }
    ]
  },
  "expectedOutcomes": {
    "standingIsD20Bonus": false,
    "CharmedIsObedience": false,
    "secretActUpdates44Factions": false
  },
  "readerExplanation": "Honored standing can affect an actual offered term without becoming +2 on the die. Charmed supplies only its real condition predicates and does not confer the clerk’s missing authority. Private acts need a genuine information path before an institution can react.",
  "evidenceClass": "authored expectation; named source and arithmetic checks separately executed",
  "worldAuthentication": "All named people, sites and permissions are synthetic premises, not new canonical facts."
}
```

## EX-W27 — Faction checkpoints report work rather than create it

The first return reports an unfinished interview. A later messenger brings its real result. At hour 24, the coincident return and daily checkpoint coalesce; neither supplies more labor. A full Depth clock cannot cross an actual blocked route.

```json
{
  "id": "EX-W27",
  "schemaVersion": "EX58-boundary-record-v1",
  "status": "authored synthetic expectation; exact review pending",
  "audience": "public synthetic example",
  "title": "Faction checkpoints report work rather than create it",
  "questionIds": [
    "SO-11",
    "SO-12",
    "RP-A05"
  ],
  "contractIds": [
    "EC-02",
    "EC-12",
    "EC-13"
  ],
  "sourceBinding": {
    "path": "docs/audit/2026-10-08/full-game/ex58-final-gpt-verdict/EX58_WORKED_SEQUENCES.json",
    "bytes": 73808,
    "sha256": "f668c9aff1c836f61e5766db3eed49d62ba2f1a6d638959157e5551223aa2c80",
    "pointer": "/additionalBoundaries/26"
  },
  "actualSyntheticPremises": "A real two-hour interview runs from hour 10 to 12. The expedition actually returns at 11, recrosses the same threshold at 11:05, and makes another genuine return exactly at the canonical hour-24 checkpoint.",
  "records": {
    "watchedInstitutions": [
      "local guild",
      "local court",
      "local archive"
    ],
    "interview": {
      "id": "interview-1",
      "interval": {
        "startSeconds": 36000,
        "endSeconds": 43200,
        "actors": [
          "interviewer",
          "witness"
        ],
        "activity": "actual predeclared hearing",
        "activeSeconds": 7200,
        "clock": "case-local canonical clock, seconds; half-open"
      },
      "sourceDurationSeconds": 7200,
      "tools": "actual transcript, language access and recording implements"
    },
    "checkpoints": [
      {
        "id": "return-11",
        "timeSeconds": 39600,
        "actionId": "interview-1",
        "progressSeconds": 3600,
        "complete": false
      },
      {
        "id": "threshold-recross",
        "timeSeconds": 39900,
        "sameReturnEpisode": true,
        "newActionGranted": false
      },
      {
        "id": "day24-return",
        "timeSeconds": 86400,
        "reasons": [
          "canonical day",
          "genuine second return"
        ],
        "processedCount": 1,
        "freeWorkSeconds": 0
      }
    ],
    "receipt": {
      "id": "witness-receipt",
      "cause": "interview-1",
      "actualMessenger": "Fen",
      "interval": {
        "startSeconds": 43200,
        "endSeconds": 46800,
        "actors": [
          "Fen"
        ],
        "activity": "carry original transcript",
        "activeSeconds": 3600,
        "clock": "case-local canonical clock, seconds; half-open"
      },
      "receivedAtSeconds": 46800
    },
    "claimClock": {
      "length": 4,
      "opening": 2,
      "event": "witness-receipt",
      "delta": 1,
      "ending": 3,
      "duplicateNotices": 5,
      "duplicateDelta": 0
    },
    "depthClock": {
      "length": 6,
      "current": 6,
      "actualRouteBeyond": "blocked by uncleared physical collapse",
      "status": "threshold reached, consequence blocked",
      "teleportRaidGranted": false
    },
    "publicRivalFrame": {
      "publicIdentity": "synthetic rival expedition",
      "privateFieldsPublished": false
    }
  },
  "expectedOutcomes": {
    "watchedMaximum": 3,
    "claimAfterWitness": 3,
    "claimAfterDuplicates": 3,
    "coincidentCheckpointCount": 1
  },
  "readerExplanation": "The first return reports an unfinished interview. A later messenger brings its real result. At hour 24, the coincident return and daily checkpoint coalesce; neither supplies more labor. A full Depth clock cannot cross an actual blocked route.",
  "evidenceClass": "authored expectation; named source and arithmetic checks separately executed",
  "worldAuthentication": "All named people, sites and permissions are synthetic premises, not new canonical facts."
}
```

## EX-W28 — Instruction, bounded Insight, assay and advancement

Eight instruction hours are progress, not a completed 80-hour course. The actual reference grants one Insight from fresh evidence; spending three and eight further hours interprets only the supported passage. A 200-gp batch owes one 2-gp assay fee. The XP branch uses the frozen gap: 25% gives 300 XP; the separate capped scene gives 720.

```json
{
  "id": "EX-W28",
  "schemaVersion": "EX58-boundary-record-v1",
  "status": "authored synthetic expectation; exact review pending",
  "audience": "public synthetic example",
  "title": "Instruction, bounded Insight, assay and advancement",
  "questionIds": [
    "FL-24",
    "FL-25",
    "FL-26"
  ],
  "contractIds": [
    "EC-02",
    "EC-10",
    "EC-14"
  ],
  "sourceBinding": {
    "path": "docs/audit/2026-10-08/full-game/ex58-final-gpt-verdict/EX58_WORKED_SEQUENCES.json",
    "bytes": 73808,
    "sha256": "f668c9aff1c836f61e5766db3eed49d62ba2f1a6d638959157e5551223aa2c80",
    "pointer": "/additionalBoundaries/27"
  },
  "actualSyntheticPremises": "Named qualified providers, readable source material, real tools and purchased supplies exist. The selected campaign reward mode is fixed before the scene. None of these procedures promotes pending class, spell or feat choices.",
  "records": {
    "toolCourse": {
      "id": "course-1",
      "teacher": "Mira",
      "learner": "A",
      "totalHours": 80,
      "totalCostCp": 1000,
      "depositPaidCp": 1000,
      "completedWork": {
        "startSeconds": 0,
        "endSeconds": 28800,
        "actors": [
          "Mira",
          "A"
        ],
        "activity": "eight active hours of actual instruction",
        "activeSeconds": 28800,
        "clock": "case-local canonical clock, seconds; half-open"
      },
      "hoursRemaining": 72,
      "proficiencyGranted": false,
      "adventuringXP": 0
    },
    "otherProjects": [
      {
        "id": "language-course",
        "requiredHours": 320,
        "completedHours": 8,
        "fluencyGranted": false
      },
      {
        "id": "long-recipe",
        "requiredHours": 960,
        "completedHours": 8,
        "recipeCompleted": false
      }
    ],
    "SC08": {
      "itemRecipeId": "recipe-500",
      "actualItem": "owned intact reference-1",
      "sourceLanguagesValue": 1,
      "evidenceId": "parallel-passage-1",
      "understoodBridgeLanguage": "Common",
      "targetLanguage": "case-specific unknown written tongue",
      "bookAccess": "open supported real book, within5ft and readable; actual hands/access maintained",
      "priorUnspentInsight": 2,
      "earning": {
        "startSeconds": 86400,
        "endSeconds": 90000,
        "actors": [
          "A"
        ],
        "activity": "authentic useful parallel text study",
        "activeSeconds": 3600,
        "clock": "case-local canonical clock, seconds; half-open"
      },
      "earnedInsight": 1,
      "afterEarning": 3,
      "sameEvidenceCopyReward": 0,
      "passageStudy": {
        "startSeconds": 90000,
        "endSeconds": 118800,
        "actors": [
          "A"
        ],
        "activity": "spend3 Insight plus8 active hours on one preregistered supported250-word passage",
        "activeSeconds": 28800,
        "clock": "case-local canonical clock, seconds; half-open"
      },
      "afterSpending": 0,
      "otherResearchOrTrainingCreditForSameHours": 0,
      "fluencyGranted": false
    },
    "coinAssay": {
      "actualProvider": "licensed examiner",
      "actualBatchFaceGp": 200,
      "method": "known single ordinary source assay",
      "methodDC": 13,
      "work": {
        "startSeconds": 0,
        "endSeconds": 1800,
        "actors": [
          "examiner"
        ],
        "activity": "one actual100-coin/10-lb-compatible batch inspection",
        "activeSeconds": 1800,
        "clock": "case-local canonical clock, seconds; half-open"
      },
      "roll": {
        "actor": "examiner",
        "nativeRoute": "Core fixed-DC task",
        "natural": 10,
        "modifier": 3,
        "DC": 13,
        "total": 13,
        "result": "Success"
      },
      "feeGp": 2,
      "minimumGp": 1,
      "genericSecondRoll": false,
      "suspicionIsProofOfCrime": false,
      "counterfeitFineAssessed": false
    },
    "XPBranch": {
      "mode": "XP",
      "sceneId": "scene-28",
      "openingNextLevelGap": 1200,
      "predeclaredEvents": [
        {
          "id": "hard-objective",
          "percent": 15
        },
        {
          "id": "profitable-extraction",
          "percent": 10
        }
      ],
      "awardXP": 300,
      "duplicateReceiptAwardXP": 0,
      "sameSceneFrozenGap": true
    },
    "independentCapBranch": {
      "openingGap": 1200,
      "predeclaredPercentSum": 75,
      "cappedPercent": 60,
      "roundedAwardXP": 720
    },
    "milestoneAlternative": {
      "sameSceneAlsoAwardsXP": false
    },
    "onLevelGain": {
      "HPRefill": 0,
      "RPRefill": 0,
      "pendingOptionsPromoted": 0
    }
  },
  "expectedOutcomes": {
    "toolCourseProgressHours": 8,
    "toolCourseHours": 80,
    "languageHours": 320,
    "recipeHours": 960,
    "awardXP": 300,
    "sceneCapXP": 720
  },
  "readerExplanation": "Eight instruction hours are progress, not a completed 80-hour course. The actual reference grants one Insight from fresh evidence; spending three and eight further hours interprets only the supported passage. A 200-gp batch owes one 2-gp assay fee. The XP branch uses the frozen gap: 25% gives 300 XP; the separate capped scene gives 720.",
  "evidenceClass": "authored expectation; named source and arithmetic checks separately executed",
  "worldAuthentication": "All named people, sites and permissions are synthetic premises, not new canonical facts."
}
```

