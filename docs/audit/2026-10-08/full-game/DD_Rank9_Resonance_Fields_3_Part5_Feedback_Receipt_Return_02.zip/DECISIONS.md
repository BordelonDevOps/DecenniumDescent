# Twenty-four complete question dispositions

## RF9-01

Original question (complete):

```json
{
  "id": "RF9-01",
  "spellIds": [
    "arc-furnace",
    "resonance-singularity",
    "resonance-nexus-supreme"
  ],
  "exactSourceOrConflict": "All three Core entries say Instantaneous while the native text creates a zone, point or field with continuing utility.",
  "options": [
    "Select and justify finite spell-local duration/concentration for each continuing effect, retaining Instantaneous as source conflict.",
    "Provide a genuinely useful instantaneous operation only where the complete source effect can be fulfilled; do not silently discard continuing field utility."
  ],
  "recommendationAndConsequences": "Choose explicitly for each identity. Reuse accepted elapsed/regular-marker conventions by exact scope; new duration/concentration numbers are NEW scoped authorship, not recovered source or mandatory tabletop simplification.",
  "decisionSelected": false
}
```

Select60elapsed seconds of concentration for EACH field, measured from successful establishment. Preserve Instantaneous as the original conflicting metadata; it is not retrospectively edited.

**Reasoning/tradeoff:** Continuing utility needs a real interval. A shared finite lifetime gives a useful rank9 tactical window while retaining concentration counterplay. Neither60nor concentration is printed; both are NEW. No universal duration is imposed on other spells.

## RF9-02

Original question (complete):

```json
{
  "id": "RF9-02",
  "spellIds": [
    "arc-furnace",
    "resonance-singularity",
    "resonance-nexus-supreme"
  ],
  "exactSourceOrConflict": "Core provides Action,120 feet,V/S/F and26 baseRP but no zone radius, shape, point influence volume or mobile-anchor permission.",
  "options": [
    "Specify finite geometry, legal placement, clipping and fixed/moving behavior separately for each identity.",
    "Adopt a particular existing geometry contract by explicit scoped reference and justify any changed dimensions."
  ],
  "recommendationAndConsequences": "Keep the printed120-foot placement range. Resolve occupied-body versus origin/payload eligibility at the actual relevant checkpoint, actual elevation/line of effect, tangency, barriers and unsupported space. A point does not imply infinite global reach, and no radius may be passed off as printed.",
  "decisionSelected": false
}
```

Furnace/Supreme radius30 spheres; Singularity radius10 around its point; all fixed,120ft placement, actual perceived same-plane center/line, clipped radial line of effect and body-interior intersection. A nonphysical field can share occupied creature space or its creator casting origin; walls/closed opaque interiors remain blockers.

**Reasoning/tradeoff:** The smaller absorbing volume makes an indiscriminate denial point positionable without turning its point into global magic extinction. Body tangency alone does not earn a discount; point-anchor equality is explicit. No grid/cadence/traversal standard is globally changed.

## RF9-03

Original question (complete):

```json
{
  "id": "RF9-03",
  "spellIds": [
    "arc-furnace",
    "resonance-singularity",
    "resonance-nexus-supreme"
  ],
  "exactSourceOrConflict": "Field creation and ending interact with actual cast commitment, concentration transitions, payment, interruption, suppression and replacement.",
  "options": [
    "One application identity with explicit creation/activation/end states and original deadline.",
    "A separately justified staged construction, retaining full costs and state transitions."
  ],
  "recommendationAndConsequences": "Use settled casting and concentration contracts. Define successful placement versus countered/failed creation, later expiry/removal, old cleanup versus replacement, relocation/planar absence, and save restoration. Do not return spent costs or reset deadline/history on re-entry.",
  "decisionSelected": false
}
```

One source instance, prospective concentration at commitment, actual manifestation and original60-second clock at establishment. Final price is preflighted against the genuinely post-concentration-transition state; illegal/unaffordable attempts do not partially end old concentration or pay. Committed counters/failures retain expenditures and the actual prior ending.

**Reasoning/tradeoff:** Separate simulation preflight from irreversible commitment. Own previous Nexus cannot finance its replacement after ending; an independently owned active one can. No automatic Tether or extra concentration is given.

## RF9-04

Original question (complete):

```json
{
  "id": "RF9-04",
  "spellIds": [
    "arc-furnace",
    "resonance-singularity",
    "resonance-nexus-supreme"
  ],
  "exactSourceOrConflict": "Greater Dispel, Lesser Antimagic, Null damage provenance and specific source immunities are already reviewed; these new fields have no automatic blanket override.",
  "options": [
    "Provide spell-local interfaces that preserve exact accepted source predicates and suppression clocks.",
    "Declare a narrow new exception only if necessary to preserve the printed spell and disclose affected interfaces."
  ],
  "recommendationAndConsequences": "Distinguish absorption, countering, dispelling and suppression. Supply genuine removal/suppression cases and Null branches only when the actual provenance qualifies. Do not let the word all override relic/cosmology decisions or automatically erase every magical creature/item.",
  "decisionSelected": false
}
```

Ordinary counter windows precede formation. Actual Lesser Antimagic suppresses its local scope before absorption. Source-qualified Greater Dispel uses original rank9 and DC28, including all genuinely captured applications. A legal termination operation targeting Singularity ignores only that target point’s own absorption. Damage Null flags stay dealer-owned; absorption itself has no damage root.

**Reasoning/tradeoff:** The termination exception is NEW and necessary to prevent an automatically undispellable point. It does not bypass another actual suppressor/point or turn dispelling into Counterspell/refund. Explicit relic/source immunity and completed mundane matter remain.

## AF9-05

Original question (complete):

```json
{
  "id": "AF9-05",
  "spellIds": [
    "arc-furnace"
  ],
  "exactSourceOrConflict": "Arc Furnace says allies' spell damage +50% in zone; it does not specify which actor, target, origin or damage location must be in that zone.",
  "options": [
    "Qualify the allied originating caster at a stated checkpoint and preserve qualifying downstream damage provenance.",
    "Qualify damage recipients/locations within the field, with a stated allied-source predicate.",
    "Select another exact source-faithful location predicate with complete examples."
  ],
  "recommendationAndConsequences": "Select one meaningful interpretation explicitly. Resolve caster inclusion, actual ally relation changes, hostile copies/charm, remote familiar/Echo origins and allies outside attacking in. Never silently change allies to everyone or in-zone to unlimited assistance.",
  "decisionSelected": false
}
```

At each genuine spell damage event, require the ORIGINAL damage caster’s actual body inside operative Furnace and actual ally relation to that Furnace creator. Self qualifies as ally; a hostile observer does not. Recipient can be outside and must remain in the spell’s native geometry.

**Reasoning/tradeoff:** This is caster-support geometry rather than a trap damaging all targets inside. Allegiance is an actual relationship, not a generic consequence of Charmed or a hidden client label. A remote familiar origin does not relocate the caster.

## AF9-06

Original question (complete):

```json
{
  "id": "AF9-06",
  "spellIds": [
    "arc-furnace"
  ],
  "exactSourceOrConflict": "The native numerical benefit is +50% spell damage. Core rounds fractions down unless expressly overridden; existing damage stages include saves, typed defenses, reductions, sharing and tempHP.",
  "options": [
    "Apply one explicit1.5 multiplier at a named existing damage stage with defined typed-packet allocation and rounding.",
    "Apply a separately authored equivalent +floor(base/2) addition, showing equivalence and any mixed-type difference."
  ],
  "recommendationAndConsequences": "Preserve the real50% benefit, not a small flat substitute. Decide eligible base (dice/flats/riders), critical dice before or after the stage as governed, save-halving order, odd values, mixed types, immunity/resistance/vulnerability, fixed damage and zero packets. Do not infer a second damage event or Wound check from amplification.",
  "decisionSelected": false
}
```

Apply actual3/2, not a flat replacement. Native dice/flats and actual eligible critical dice precede the new stage; combine permitted field rational factors and floor once on the typed total, then deterministic proportional remainder allocation. Source-native save halving and real defenses follow.

**Reasoning/tradeoff:** Odd and mixed outputs preserve the whole50% benefit without changing types. Late-stage source-specific riders retain their native position. No additional hit, Wound test or damage-funded recovery is invented.

## AF9-07

Original question (complete):

```json
{
  "id": "AF9-07",
  "spellIds": [
    "arc-furnace"
  ],
  "exactSourceOrConflict": "Separate hits, ongoing pulses, damage roots, redirected/shared children, reflection and already-created results retain their own source identities.",
  "options": [
    "Qualify each genuine event once at the chosen checkpoint, preserving root/child provenance and no amplification replay.",
    "Snapshot the eligible source application at creation and state exactly which later events inherit it."
  ],
  "recommendationAndConsequences": "Cover multi-hit, multi-target, damage over time, one root shared to another recipient, nonspell summoned weapon attacks, class-tagged spells, environmental consequences and ongoing magic created before the field. A transmitted child must not repeatedly acquire the same multiplier merely by crossing field boundaries.",
  "decisionSelected": false
}
```

Each genuine hit/later source pulse has its own field query and exact source root/Null timing. Existing magic can benefit later; pure transferred/reflected already-scaled descendants do not loop through the multiplier. Class-tagged spells qualify; independent summoned creature attacks, physical fire and nonspell techniques do not become spells.

**Reasoning/tradeoff:** The Cloud branch explicitly predates Furnace and has fresh source-owned pulses. Passing through more fields or changing recipients cannot mint a second amplification or conversion entitlement.

## AF9-08

Original question (complete):

```json
{
  "id": "AF9-08",
  "spellIds": [
    "arc-furnace"
  ],
  "exactSourceOrConflict": "Mage Nuke Chain and other actual class features amplify specific spell damage; Supreme Nexus enhancement is not selected yet.",
  "options": [
    "Specify additive/multiplicative composition and rounding with actual acquired class and spell modifiers.",
    "Introduce a named nonstacking family or cap only with explicit NEW justification and preserved useful50% benefit."
  ],
  "recommendationAndConsequences": "Use real class records and gates; a level17 Mage does not gain every Hero selection. Distinguish Mage Elemental Absorption from Wizard Spell Absorption and ordinary Absorb Elements. Test a legal class chain and an ineligible superficially similar source. Do not impose a global cap to make one example easy.",
  "decisionSelected": false
}
```

Actual class stages and acquired optional payments remain; compose Furnace3/2 and Supreme5/4 multiplicatively once. Same-name duplicate Furnace does not add another3/2. Mage chain completion still counts three resolved different eligible names, vents2, and requires a separate actual Bonus Action2RP finisher.

**Reasoning/tradeoff:** No arbitrary global cap replaces50%. The worked Cold chain retains real Spell Efficiency, mixed lightning resistance, Focus slow and finisher recharge. Nonspell Primal Channeling remains exactly2RP recovery, not amplified spell damage.

## AF9-09

Original question (complete):

```json
{
  "id": "AF9-09",
  "spellIds": [
    "arc-furnace"
  ],
  "exactSourceOrConflict": "A readied spell is paid at preparation but resolves later; existing copy/Ready decisions are scoped and do not decide a new amplification snapshot.",
  "options": [
    "Determine amplification at actual damage/effect resolution under the selected field predicate.",
    "Explicitly bind amplification at cast commitment and preserve that snapshot through legal release."
  ],
  "recommendationAndConsequences": "Choose the narrow checkpoint consistent with AF9-05/07. Show preparing in/releasing out and the converse, field ending after cost commitment, a real Reaction interrupt, and copied payload ownership. No second payment, casting-history update or free Action follows from release.",
  "decisionSelected": false
}
```

Choose actual damage resolution for amplification; ordinary Ready pricing/history stays at paid preparation. Preparing inside and releasing outside loses Furnace; converse gains it without a second price. Existing capture/hold deadlines and real Reaction/trigger/targets remain.

**Reasoning/tradeoff:** The two full Ready branches expose this tradeoff. Supplied current preparation-only copied-feat accounting remains confined to its actual seven profiles; it neither admits a rank9 copy nor changes this ordinary spell’s cap.

## AF9-10

Original question (complete):

```json
{
  "id": "AF9-10",
  "spellIds": [
    "arc-furnace"
  ],
  "exactSourceOrConflict": "The spell name is Furnace but its entire native function is allied spell-damage amplification.",
  "options": [
    "Keep a nonphysical damage-support field with no unstated crafting/heat/resource product.",
    "Add any independently desired physical heat/crafting function only as a separate owner-visible proposal outside this source conference."
  ],
  "recommendationAndConsequences": "Retain actual useful combat amplification and disclose player-facing cues. Do not import Eternal Forge, repair, smelting, item creation, harvestable fuel or extra fire damage from the name.",
  "decisionSelected": false
}
```

Only a visible nonphysical support pattern. No heat, smelting, material, forge station, crafting acceleration, repair, fuel or extra fire packet is added.

**Reasoning/tradeoff:** Resonance Forge remains a separate actually paid/reviewed object and manufacturing contract. A name is not a new capability.

## RS9-11

Original question (complete):

```json
{
  "id": "RS9-11",
  "spellIds": [
    "resonance-singularity"
  ],
  "exactSourceOrConflict": "Singularity explicitly absorbs ALL MAGIC and converts it to Resonance; native text is broader than hostile incoming damaging spells.",
  "options": [
    "Publish a complete operational category map covering ordinary spells, class spells, magical features, item effects, ongoing/permanent magic, summons and source protections.",
    "Choose a narrower domain only as an explicit source conflict with concrete reasons and positive coverage beyond damage."
  ],
  "recommendationAndConsequences": "Treat all magic as a consequential scope decision, never silently as one damage type or one hostile attack. Distinguish effect instance from item body/charge, creature existence, learned knowledge, faith and cosmology. No new cosmic truth or permanent soul destruction may be inferred.",
  "decisionSelected": false
}
```

Use the full category map: ordinary/class spells, nonspell magical outputs, item activations/enchantments, ongoing creature buffs/fields, real removable magical bodies, continuous properties and all ranks. Preserve actual source protection, item/engine identity and completed ordinary matter.

**Reasoning/tradeoff:** This is materially broader than Spell Absorption or Absorb Elements: friendly detection, Ward expressions and field generators can be consumed. Learned class entitlement, souls, mundane anatomy and uncast stored knowledge are not destructible magical output instances.

## RS9-12

Original question (complete):

```json
{
  "id": "RS9-12",
  "spellIds": [
    "resonance-singularity"
  ],
  "exactSourceOrConflict": "The source supplies a point and absorption but does not identify interception stage or whether one intercepted part cancels an entire remote cast.",
  "options": [
    "Consume the locally admitted effect instance or component at an explicit stage.",
    "End a whole source application only where the chosen authority and geometry genuinely support whole-source removal."
  ],
  "recommendationAndConsequences": "Define travel/crossing versus creation-inside versus targeted-area admission; instant non-projectile effects; counter chains; multi-target effects inside/outside; concentration source and already committed outcomes. No projectile may be invented for a non-projectile spell. Absorption needs a full end-state and provenance receipt.",
  "decisionSelected": false
}
```

Intercept actual local origin/recipient/area/destination or a genuinely supplied traveling path before its payload. No invented projectile chord; an instantaneous area geometric center alone is not a persistent generator, so an outside-caster area with no source-defined propagation resolves recipient-local. End an admitted discrete buff or generator whole; outside generator’s local outputs can be consumed while other recipients/parent survive.

**Reasoning/tradeoff:** The mixed inside/outside Fireball case retains its outside damage and draws the shared pool only because that component survives. A discrete Sight buff does not reappear on exit; a continuous Ward expression can resume with the same spent origin identity.

## RS9-13

Original question (complete):

```json
{
  "id": "RS9-13",
  "spellIds": [
    "resonance-singularity"
  ],
  "exactSourceOrConflict": "No conversion rate is printed. Rank, actual paid base, extras/protected principal, damage and item charges are distinct quantities; waived and rank0 magic still exist.",
  "options": [
    "Use a source-aware conversion measure with explicit treatment of free/cantrip, item/class and ongoing effects.",
    "Use another finite rate/valuation whose source extensions and economy consequences are fully disclosed."
  ],
  "recommendationAndConsequences": "Select a usable conversion rule without presenting an invented formula as printed. Explain magic with no RP-price interface, zero damage, reduced prices, already-refunded costs, protected Barrier X, and partial absorption. Do not equate source rank with actual RP paid or erase free magic merely to avoid the hard case.",
  "decisionSelected": false
}
```

NEW conversion per actual source-use: paid base>0 uses net paid base after real refunds, value0 if net0 else max(1,floor(net/2)); truly zero-paid or genuinely unpriced magic uses intrinsic1. Protected principal, extras, damage, charges, nominal rank price and saved RP never increase it. Unknown payment is not unpriced.

**Reasoning/tradeoff:** This is explicitly not strict global RP conservation. The first eligible partial interception claims the source-use valuation, even if outside components survive. Actual free cantrips can generate1 after real Action/strain. Fully refunded paid casts produce0; adding a hidden daily cap or denying free magic would weaken the source instead of answering it.

## RS9-14

Original question (complete):

```json
{
  "id": "RS9-14",
  "spellIds": [
    "resonance-singularity"
  ],
  "exactSourceOrConflict": "Converts it to Resonance does not specify recipient, container, extraction action, reserve duration, actual pool cap or over-cap disposal.",
  "options": [
    "Credit an explicit eligible recipient at a named checkpoint with actual maximum and lost overflow.",
    "Store a finite identified reserve with explicit legal withdrawal and expiry/ownership rules."
  ],
  "recommendationAndConsequences": "Preserve useful resource conversion. Distinguish current RP, pending credit and stored reserve; no joint maximum, negative debit, duplicate credit or hidden credit to a non-RP Oracle engine. If storage/withdrawal is chosen, make it explicit NEW rather than inheriting all Well limits or Conduit permissions.",
  "decisionSelected": false
}
```

Credit the winning point’s original caster’s actual lawful RP pool at settlement, to current maximum. No reserve, withdrawal, team pool, draw Action, Oracle RC conversion or hidden maximum. Overflow and prohibited/dead/missing-recipient credit are lost with the receipt spent.

**Reasoning/tradeoff:** A live receipt survives the point ending after successful consumption; its original owner and actual recovery permission still control. That is completion of one earned operation, not a returning field or bank.

## RS9-15

Original question (complete):

```json
{
  "id": "RS9-15",
  "spellIds": [
    "resonance-singularity"
  ],
  "exactSourceOrConflict": "Free casts, discounted casts, allied feeding, Efficient Casting refunds and reciprocal Singularity/Nexus effects can create repeated credit from one source or an unbounded cycle.",
  "options": [
    "Use an explicit origin/use ledger and finite transition policy while allowing lawful self/allied magic within the selected scope.",
    "Add a spell-local capacity/use/rate limit only as a separately disclosed NEW balance choice."
  ],
  "recommendationAndConsequences": "Show the complete combined resource ledger, including creation cost and consumed sources; test repeat notifications, saved/reloaded pending absorption, cantrips, actual refunds and reabsorption. Do not equate all authorized resource creation with a forbidden exploit, nor claim conservation from a ledger that omits a refund or source.",
  "decisionSelected": false
}
```

One global origin/use conversion entitlement across instances, targets, pulses and descendants. Record local consumption separately, then pending/refund-settled/spent-before-credit states. Same continuous property can resume but cannot repay on reentry/new point; real later activations are new uses.

**Reasoning/tradeoff:** Friendly feeding is permitted under actual source restrictions. Summons expressly forbidden to generate resources still pay0. The Efficient Casting positive branch rolls its real die, receives the full legal refund, then Singularity receives0—never a reduction of that refund or two shares of the same paid base.

## RS9-16

Original question (complete):

```json
{
  "id": "RS9-16",
  "spellIds": [
    "resonance-singularity"
  ],
  "exactSourceOrConflict": "Overlapping points may try to absorb one magic instance, each other, or the field supplying their own conversion benefit.",
  "options": [
    "Choose one deterministic first eligible absorber per consumable instance with a stable tie rule and retained receipt.",
    "Define a bounded split only if the complete converted quantity and end-state are conserved under an explicit choice."
  ],
  "recommendationAndConsequences": "Resolve simultaneous admission, mutual absorption, self-created magic, suppression/resumption and one point ending another. The same effect cannot be consumed or credited twice; a rejected operation cannot consume authoritative RNG or partially mutate the state.",
  "decisionSelected": false
}
```

Earliest actually established eligible point wins, stable application ID breaks remaining ties. Only existing points intercept a new point’s pre-insertion formation. Local receipts precede callbacks. Self sustaining input and terminal credit/price/teardown bookkeeping are not new payloads.

**Reasoning/tradeoff:** No symmetric immunity for different points is assumed. The combined case shows an older point consuming a real paid new point once, including cap/overflow. The generator branch captures both eligible field anchors, not a conveniently selected subset.

## RS9-17

Original question (complete):

```json
{
  "id": "RS9-17",
  "spellIds": [
    "resonance-singularity"
  ],
  "exactSourceOrConflict": "Absorption at an interruption boundary can interact with prepared/captured payloads and independently persisting results.",
  "options": [
    "Resolve at the exact effect-instance lifecycle checkpoint using the source-specific state.",
    "Require a narrowly named additional interface for an otherwise unresolved interaction."
  ],
  "recommendationAndConsequences": "Include legal ordinary Ready and at least one non-damaging magical effect; preserve costs and completed results. Do not use the pending Rank7 correction, an external held positive case or unselected source cohort as proof of an implemented engine interaction.",
  "decisionSelected": false
}
```

Ready is a real paid/held source: original fees/capture/allowances are unchanged and its actual source/hold deadline remains. A local absorbed release consumes its paid effect without another casting or refund. Discrete nondamaging Sight and stable Ward-expression examples are positive, not damage-only guards.

**Reasoning/tradeoff:** Full Ready world dispatch remains unimplemented. Current accepted Rank7 source-specific Cast Echo timing is available only where that exact source is actually invoked; it does not turn ordinary Ready into a native interrupt.

## NS9-18

Original question (complete):

```json
{
  "id": "NS9-18",
  "spellIds": [
    "resonance-nexus-supreme"
  ],
  "exactSourceOrConflict": "Supreme Nexus enhances ALL MAGIC and halves Resonance costs. Enhancement is a separate printed benefit whose magnitude/type is absent.",
  "options": [
    "Define explicit useful enhancement by relevant native effect categories with unsupported categories diagnosed.",
    "Choose a universal enhancement dimension only if it meaningfully applies to the full selected magic scope without inventing outcomes for qualitative effects."
  ],
  "recommendationAndConsequences": "Do not treat half price alone as the full enhancement clause or automatically double everything. Cover damage, healing, protection, movement, summons, class/item magic and qualitative utility; disclose source conflict where a category has no lawful scalable dimension. No new spell access, recipe, lore or ability arises from enhancement.",
  "decisionSelected": false
}
```

NEW25% one-axis efficacy plus universal+2 integrity against genuinely defined opposed neutralization CHECKS. Preserve the full per-output priority and category map. Do not fabricate a check, rank change, additional truth/action/target or a new effect.

**Reasoning/tradeoff:** Price alone is not enhancement. Positive cases show damage, actual qualitative sensing range, real teleport distance and generated-body HP; protection has a complete paid Barrier example. Source-explicit hard caps/nonamplifiable results remain; a purely qualitative effect with no lawful scalar gains only the concrete integrity protection.

## NS9-19

Original question (complete):

```json
{
  "id": "NS9-19",
  "spellIds": [
    "resonance-nexus-supreme"
  ],
  "exactSourceOrConflict": "All magic and Resonance costs are broader words than the lower-rank Nexus all spells. Actual RP-priced nonspell features and resource transfers have distinct contracts.",
  "options": [
    "Specify exactly which magic activations and RP-cost interfaces qualify, preserving actual non-RP costs separately.",
    "Adopt the lower-rank Nexus spell-price domain only as an explicitly discussed scope choice, not automatic inheritance."
  ],
  "recommendationAndConsequences": "Address enemies and allies, class spell tags versus nonspell magic, item charges, Oracle RC, transfer principal, upkeep, optional riders and actually waived costs. Do not halve HP, materials, protected transfer value or change pool maxima merely because an effect is magical.",
  "decisionSelected": false
}
```

Half ordinary RP spell prices and actual magical nonspell activation fees, indiscriminately allies/enemies, at actual payer-body commitment. Actual non-RP costs, item charges, Oracle RC, protected transfer/conversion principal and pool maxima remain unchanged.

**Reasoning/tradeoff:** Counterpulse is explicitly a magical nonspell Silenced output here; its real1RP triggered fee becomes0 after an actual paid counter. It is not another spell, action, Reaction or new acquisition. Rank9 pending free-cast proposals are not silently used.

## NS9-20

Original question (complete):

```json
{
  "id": "NS9-20",
  "spellIds": [
    "resonance-nexus-supreme"
  ],
  "exactSourceOrConflict": "AC5/AC6 pricing orders, one ordinary Nexus-2, later Dampening+2, final Influence and protected conversion principal already exist.",
  "options": [
    "Add the half-price step at an explicit location with discountable-bucket allocation and existing rounding.",
    "Propose a narrow scoped replacement/composition rule only with exact before/after examples for affected contracts."
  ],
  "recommendationAndConsequences": "Test odd ordinary prices, base-versus-extra allocation, zero/free routes, class minima/waivers, protected Barrier X and Forge principal. Preserve final Influence and actual-paid-base refund attribution. No discounted saving becomes an extra recovery credit. Distinguish floor(total/2) from separately floored buckets where it matters.",
  "decisionSelected": false
}
```

After actual class/source reductions and one ordinary Nexus-2, halve combined B+E once with floor. Allocate savings to B first then E. Add spell-only Dampening+2; apply real final Influence; add protectedP whole. Outputs/refunds use the actual retained B.

**Reasoning/tradeoff:** The complete strained Barrier case derives B10/E1/P2→ordinary B8/E1→half B3/E1→Damp2→Ease B2/E1/Damp2/P2=7. Raw prevention5*(2+2)=20, then the separately authored enhancement yields25. No discount is a recovery event.

## NS9-21

Original question (complete):

```json
{
  "id": "NS9-21",
  "spellIds": [
    "resonance-nexus-supreme"
  ],
  "exactSourceOrConflict": "Existing Nexus cannot finance its own replacement through concentration that already ended at commitment. Ready prices at preparation, not later release.",
  "options": [
    "Apply the settled actual-caster/commitment framework where explicitly adopted, with the new half-price operation isolated.",
    "Select and justify a distinct eligibility checkpoint without retroactive price changes or duplicated payment."
  ],
  "recommendationAndConsequences": "Provide own-field recast, independent other-owner field, enter/leave, suppression before/after commitment, true Reaction cast, Ready release and refund-feature cases. Grand Reservoir only waives its stated base; unsupported mixtures cannot be used to fabricate a legal example.",
  "decisionSelected": false
}
```

Same source payment/commitment boundary as the accepted lower-rank framework, expressly extended only for Supreme’s new half step. Actual Reaction casts qualify; Ready is priced once at preparation. Own replacement loses its old field, but an actually available class-1 reduction still remains.

**Reasoning/tradeoff:** The own-field recast pays25, not a guessed26, because this Wizard actually owns Spell Efficiency and repeats within its true window. Another owner’s field can price a first new26RP source at13. No post-payment repricing or future conversion finances commitment.

## NS9-22

Original question (complete):

```json
{
  "id": "NS9-22",
  "spellIds": [
    "resonance-nexus-supreme"
  ],
  "exactSourceOrConflict": "Overlapping Supreme Nexuses, ordinary Nexus and Arc Furnace may simultaneously affect one cast or damage event.",
  "options": [
    "Define identity-specific duplicate handling and cross-field composition without changing unrelated accepted stacking.",
    "Introduce a disclosed narrow shared family after comparing the actual printed benefits."
  ],
  "recommendationAndConsequences": "Retain useful half-cost and enhancement. Supply an exact stable tie/source record and no repeated discount from geometry rechecks. If copies do not stack, state why and keep distinct owner/control/lifecycle records; no blanket global strongest-only rule.",
  "decisionSelected": false
}
```

One Supreme half step and efficacy operation across duplicates, with separate owner/lifecycle records and stable oldest eligibility. Ordinary Nexus-2 remains before; Furnace1.5 multiplies damage at the one rational stage. These resource fields do not multiply each other’s geometry, duration, coefficients or conversion quantities.

**Reasoning/tradeoff:** The explicit meta-field exclusion prevents recursive amplification; it is not a global nonstacking law. Another Nexus can supply one actual integrity bonus, not repeated mathematical enhancement of the bonus itself.

## RF9-23

Original question (complete):

```json
{
  "id": "RF9-23",
  "spellIds": [
    "arc-furnace",
    "resonance-singularity",
    "resonance-nexus-supreme"
  ],
  "exactSourceOrConflict": "These three fields can alter one another at the same simulation time: amplify a spell, change its price, absorb its effect and issue a resource credit.",
  "options": [
    "Provide one finite operation ordering using existing event phases plus narrowly authored priority where required.",
    "Explicitly isolate only unresolved cross-field interfaces and give complete executable cases for the resolved portion."
  ],
  "recommendationAndConsequences": "Track paid source, amplification owner, effect identity, pending/complete absorption, conversion entitlement and cleanup exactly once. Show a real productive interaction and a mutual/recursive boundary. Do not silently substitute a different easy spell or omit a step that changes the result.",
  "decisionSelected": false
}
```

Finite order: due expiry/source transition; lawful parent/commitment/payment/history/counter windows; actual prohibitions/suppression; local absorption; surviving output enhancement/native consequences; actual source refunds; one conversion settlement. Existing absorber arbitration is stable and local receipts terminate callback loops.

**Reasoning/tradeoff:** The full combined case pays real26,13,13 creation costs, halves a Fireball5→2, consumes one local target, deals39 elsewhere from21×15/8, and converts actualpaid2→1. Additional point formation and generator teardown are separately worked without omitted recipients or funds; actual Greater Dispel captures both generators and shows a29 that would meet28 failing against Furnace’s real Supreme-protectedDC30.

## RF9-24

Original question (complete):

```json
{
  "id": "RF9-24",
  "spellIds": [
    "arc-furnace",
    "resonance-singularity",
    "resonance-nexus-supreme"
  ],
  "exactSourceOrConflict": "Machine-managed field queries can reveal hidden entities, private class sources or Director-only magical provenance through previews and logs.",
  "options": [
    "Expose only permitted eligibility/results while retaining full private provenance for authoritative resolution.",
    "Use a source-backed explicit detection benefit only where one exists."
  ],
  "recommendationAndConsequences": "State observable cues and legal rejection reasons without granting Detect Magic or hidden inventory inspection. Save/load retains IDs, original clocks, paid amounts and consumed receipts; previews do not trigger absorption, price changes, RNG draws or reveal protected cosmology.",
  "decisionSelected": false
}
```

Private authoritative IDs, source/price/refund/lineage data and receipts survive save/reload. Expose actual own-pool changes and ordinary audiovisual results, not hidden spell identities/inventory/rosters or a sixth DE4 channel. Queries/previews do not dispatch costs, RNG or absorption.

**Reasoning/tradeoff:** A legitimate RP change can permit ordinary player inference; the system does not falsify it. It adds no source-specific diagnostic or detection power. Durable serialization/outbox/scheduler adapters remain real implementation obligations, not proof furnished by JSON examples.

