# Complete bestiary evidence handoff — UNSENT

This is a frozen source-conference preparation, not approved creature rules or an installed/public dataset. Read the prepared prompt and existing audits. Source, history, structured candidate, harvesting crosslinks and named spell-output addenda are included in full, with their original questions and stated search limits.

FILE_MANIFEST.json lists every full file and its hash. BESTIARY_COMPLETE_FILE_HANDOFF_SOURCE_CHECK.json verifies67 original dossier texts,26 unchanged public source records,66 stat blocks and full membership counts. Of278 historical source files,272 remain identical; all six changed files have an exact preserved historical counterpart and a complete current file. Original validation reports retain their historical scope; current rules/counts use the included current files and actual review receipts. No historical report is silently treated as a fresh validation of changed bytes.

The five sealed dossiers occur among preserved sources only for routing/containment evidence. Their content and cosmology are outside the pre-push review. Public projection requires actual source authority; a record's presence in this internal archive is not publication permission. Full current gathering/Blacksmithing context and still-pending advanced-craft sources are included with explicit status. No advanced approval is inferred.

Before the future conference, refresh any interfaces changed by actual intervening verdicts. Keep all original archives, manuscripts, source flags and aliases. No build/import scripts were executed, no runtime data or publication filter changed, and no creature, spell, material identity or cosmology decision is made by this preparation.
