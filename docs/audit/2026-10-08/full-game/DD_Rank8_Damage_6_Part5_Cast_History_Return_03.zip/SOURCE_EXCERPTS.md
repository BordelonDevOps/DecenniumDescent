# Cast-history qualification — exact source text

The full source files are unchanged in `cast_history_source/sources/`. Only the actual clauses below are reused; this return invents no encounter-reset policy.

## cast_history_source/sources/wizard.json — /protectedInterfaceOriginal

The first cast of each different prepared Spell Matrix in an encounter generates 0 base Dissonance; repeating a matrix builds Refrain normally.

## cast_history_source/sources/wizard.json — /engine/3

LEGAL RANKS. Maximum Wizard spell rank by Wizard class level is: rank 1 at levels 1-2, rank 2 at 3-4, rank 3 at 5-6, rank 4 at 7-8, rank 5 at 9-10, rank 6 at 11-12, rank 7 at 13-14, rank 8 at 15-16 and rank 9 at 17-20. Grand Tier at level 20 is a special casting permission, not a tenth ordinary rank. A Wizard may learn Wizard-list spells from any school up to the legal rank unless a spell itself has an additional prerequisite.

## cast_history_source/sources/wizard.json — /engine/4

PREPARED SPELL MATRIX. After a long rest, prepare a number of matrices equal to Wizard level + Intelligence modifier, minimum 1, selecting only spells currently recorded in your spellbook and within your legal rank. You cast ordinary Wizard spells only from prepared matrices unless a feature explicitly overrides that restriction. Preparing the full daily matrix set normally requires 1 hour of spellbook study. Matrix Efficiency reduces this to 45 minutes.

## cast_history_source/sources/wizard.json — /engine/5

DUPLICATE PREPARATION. You may prepare the same spell more than once, primarily to carry different Matrix Mastery configurations. Duplicate copies never create additional first-cast Dissonance exemptions. For Refrain and the protected strain rule, all prepared copies sharing the same underlying spell name belong to one matrix family regardless of modification.

## cast_history_source/sources/wizard.json — /engine/11

PROTECTED DISSONANCE INTERFACE. The first cast of each different prepared matrix family during an encounter generates 0 BASE Dissonance. This exemption affects only base strain. Refrain and explicitly printed strain costs still apply; the suite disables generic Overcast and does not layer historical Burn onto Dissonance. Repeating a matrix family follows normal Refrain immediately. Preparing duplicates or differently modified copies of the same underlying spell never refreshes the exemption.

## cast_history_source/sources/wizard.json — /engine/14

Only one concentration effect can normally be maintained. Starting a second concentration effect ends the first. Damage uses the current Core Systems concentration rule; required half-damage rounding is down for this pilot. Spell Tether and the level-17 Tethered Cast are the only Wizard-specific exceptions in this draft, and each has an explicit RP price, duration and one-tether cap.

## cast_history_source/sources/wizard.json — /engine/27

At Wizard 3 enter Arcanist, automatically gain Arcane Tradition as an upgrade of the SAME level-1 school rather than choosing another school, and choose 2 selectable Arch cards, at least 1 Active. Wizard 4 grants one eligible Base/Arch choice. Wizard 5 grants one Base/Arch choice plus automatic School Mastery. Wizard 6 grants one Base/Arch choice plus automatic Arcane Ward. Wizard 7 grants one eligible Arch choice. Wizard 8 grants one Base/Arch choice. Wizard 9 grants one eligible Arch choice plus automatic Dual Cast.

## cast_history_source/sources/wizard.json — /rpByClassLevel/6

```json
24
```

## cast_history_source/sources/wizard.json — /maxSpellRankByClassLevel/6

```json
4
```

## cast_history_source/sources/accepted_interface_registry_06.json — /entries/0

```json
{
  "id": "docs/mechanics/SPELL_INTEGRATION_RULES.md#resolve-a-cast-at-the-table",
  "name": "Ordinary casting and pricing",
  "acceptanceStatus": "current-authoritative-provisional-interface",
  "acceptanceBasis": {
    "basis": "Current operative integration text, reused by exact accepted cohorts; not a new claim of whole-document or canon approval.",
    "cohortEvidence": [
      {
        "path": "docs/audit/2026-10-08/full-game/AC4_EXACT_ACCEPTANCE_03_RECEIPT.json",
        "bytes": 6291,
        "sha256": "8dfee7f8a9cd036df80650079b289895cae245de0d8ca17bd926798de55bce2d",
        "frozenCopy": "docs/audit/2026-10-08/full-game/accelerated-review-01/sources/docs/audit/2026-10-08/full-game/AC4_EXACT_ACCEPTANCE_03_RECEIPT.json"
      },
      {
        "path": "docs/audit/2026-10-08/full-game/AC5_EXACT_ACCEPTANCE_05_RECEIPT.json",
        "bytes": 7471,
        "sha256": "5590d1b66ed59287069835ea19e9ffc3d52ea32a6166a9d0645757c7202885a9",
        "frozenCopy": "docs/audit/2026-10-08/full-game/accelerated-review-01/sources/docs/audit/2026-10-08/full-game/AC5_EXACT_ACCEPTANCE_05_RECEIPT.json"
      }
    ]
  },
  "scope": "Ordinary class-qualified casts",
  "currentAuthoritativeSource": {
    "path": "DescentReviewChanges/ReviewBible/docs/mechanics/SPELL_INTEGRATION_RULES.md",
    "bytes": 67451,
    "sha256": "55f486de8d38a6734f8f0f2f62066401504f5b1311ebe66693175876b3f7aa6d",
    "frozenCopy": "docs/audit/2026-10-08/full-game/accepted-interface-refresh-04/sources/DescentReviewChanges/ReviewBible/docs/mechanics/SPELL_INTEGRATION_RULES.md",
    "heading": "## Resolve a cast at the table",
    "line": 31
  },
  "exactAuthority": "## Resolve a cast at the table\n\n1. Verify the available Action/Bonus Action/Reaction, its exact trigger, components, targets, range and line of effect. No legal target means no activation or payment. A target in an area still needs the card's eligibility. Total cover blocks direct targeting unless expressly overridden.\n2. Choose a spell from your actual repertoire. Determine its class-specific rank and RP cost: rank 0–9 costs **0/2/3/5/7/10/13/17/21/26**. Add explicitly printed extra costs; Resonance Shield adds 1 RP even when the caster receives it as a cantrip. Generic Overcast is excluded.\n3. Read Dissonance **before** casting. Limit = max(4, 2 + PB + max(0, casting modifier)). At limit/limit+3/limit+6, ranked spells cost +1/+2/+3 RP. At limit+6 ordinary rank-1+ casting is blocked. Cantrips have no strain surcharge but still build Refrain. An expressly granted traumatic-casting exception pays the cost and its printed trauma; it grants neither rank nor repertoire access.\n4. Commit the legal cast's RP, materials and other printed costs before any attack/save or interruption. Perform its components and establish concentration if required, ending incompatible prior concentration. An ordinary missed, saved-against or countered legal cast refunds nothing and never restores displaced concentration.\n5. At this cast's beginning, apply ordinary Dissonance and Refrain once: 0 base for rank 0, 1 for ranks 1–5, 2 for ranks 6–9; consecutive same-named casts add Refrain +1/+2/+3, capped at +3. First cast or a different name adds +0. Apply the class's exact protected reduction, routing or vent and any hook whose printed trigger is beginning/casting. Weapon or idle turns do not reset the previous name/Refrain unless the class expressly says so. This chronological commitment occurs before the Counterspell window; a later Reaction cast updates its own history, and resuming the earlier cast does not update that history again.\n6. Open legal cast-interruption Reactions, resolving nested counters last-in, first-out. A surviving cast then resolves its effect: spell attacks are d20 + PB + the actual casting ability modifier; save DC is 8 + PB + that modifier. Use the exact card's hit/failure/success results and ordinary damage/conditions. Outcome-dependent class hooks occur only at their printed timing and with the required actual result. No automatic cantrip scaling applies. A negated spell grants no success/hit/damage effect merely because its casting cost was paid.\n7. Record concentration, exact expiration, per-rest use, summon and companion command obligations. A second spell cannot supply an ungranted Action, duplicate concentration or resource reset. A readied spell commits this casting sequence at preparation; release has no second cast, cost, cadence update or Counterspell window.\n\nCountering requires an actual operational spell or class card, its repertoire/access and a legal remaining Reaction. The ordinary Counterspell is now reviewed; it is separate from the Mage and Wizard class cards. Dispel Minor, Dispel Resonance, Dispel Magic (Lesser) and Dispel Magic use their exact individual scopes. Rank-limited dispels inspect the original generating cast's spell rank, not RP cost or the dispeller's rank. Higher and unassigned source variants retain their own unfinished status.\n\n",
  "authoritySha256": "6edfabe262f2ddb4812e76f2a665403d5cd68ddd412eb908125ff389d27d72fb",
  "trigger": "Legal cast commitment",
  "inputs": "Class/rank, repertoire, actions, components, pre-cast Dissonance, prior spell name, costs",
  "outputs": "Committed resources/concentration/cadence; attack/save/effect resolution",
  "lifecycle": "No refund/restoration on miss/save/interruption; generating rank retained",
  "exceptions": "Exact class exceptions; no generic overcast",
  "knownSourceSpecificExtensions": [],
  "usedBy": [
    "AC4",
    "AC5",
    "all ordinary spells"
  ],
  "usageCoverage": "Explicit known users, not a claim of exhaustive reverse-dependency indexing.",
  "reusableWithinScope": true,
  "summaryAuthority": "The exactAuthority and named source control; normalized fields index them and create no rules.",
  "runtimeImplementedByRegistry": false
}
```

## cast_history_source/sources/accepted_interface_registry_06.json — /entries/3

```json
{
  "id": "docs/mechanics/COMBAT_ACTION_PLAYTEST.md#time-and-event-ordering-—-new",
  "name": "Time and event ordering",
  "acceptanceStatus": "current-authoritative-provisional-interface",
  "acceptanceBasis": {
    "basis": "Current operative integration text, reused by exact accepted cohorts; not a new claim of whole-document or canon approval.",
    "cohortEvidence": [
      {
        "path": "docs/audit/2026-10-08/full-game/AC4_EXACT_ACCEPTANCE_03_RECEIPT.json",
        "bytes": 6291,
        "sha256": "8dfee7f8a9cd036df80650079b289895cae245de0d8ca17bd926798de55bce2d",
        "frozenCopy": "docs/audit/2026-10-08/full-game/accelerated-review-01/sources/docs/audit/2026-10-08/full-game/AC4_EXACT_ACCEPTANCE_03_RECEIPT.json"
      },
      {
        "path": "docs/audit/2026-10-08/full-game/AC5_EXACT_ACCEPTANCE_05_RECEIPT.json",
        "bytes": 7471,
        "sha256": "5590d1b66ed59287069835ea19e9ffc3d52ea32a6166a9d0645757c7202885a9",
        "frozenCopy": "docs/audit/2026-10-08/full-game/accelerated-review-01/sources/docs/audit/2026-10-08/full-game/AC5_EXACT_ACCEPTANCE_05_RECEIPT.json"
      }
    ]
  },
  "scope": "Original regular markers and elapsed time",
  "currentAuthoritativeSource": {
    "path": "DescentReviewChanges/ReviewBible/docs/mechanics/COMBAT_ACTION_PLAYTEST.md",
    "bytes": 30409,
    "sha256": "f90d039142145fbd31c37992ebece70d7926dc4b6081e340f9a2fd9dc7237bc6",
    "frozenCopy": "docs/audit/2026-10-08/full-game/accelerated-review-01/sources/DescentReviewChanges/ReviewBible/docs/mechanics/COMBAT_ACTION_PLAYTEST.md",
    "heading": "## Time and event ordering — NEW",
    "line": 45
  },
  "exactAuthority": "## Time and event ordering — NEW\n\nFor a duration created in initiative, record the relevant original regular start/end marker. Existing effects keep that **virtual marker**, repeating every six seconds if the creature leaves or changes initiative. Reordering, rerolling, extra turns, death/removal or leaving/reentering initiative never restart an existing duration. New effects use the current schedule. Source death still ends concentration, a source-dependent aura/tether or an effect explicitly ending on death.\n\n- A bare hostile target-bound **N rounds** ends at the Nth future regular target-end marker. An in-progress target turn's current end does not count.\n- A bare self/source buff, ally-targeted buff or source-controlled aura **N rounds** ends at the Nth future source-start marker. Explicit target-turn, pulse or absolute timing overrides this default. Activation during source turn 1 for three rounds ends at source turn 4's start.\n- **Next turn** means the next future regular turn of the named creature, not the current turn's still-upcoming end. An unqualified next turn refers to source/user under the existing shared rule. Explicit “this turn” can include the current turn.\n- An outside-initiative bare N-round effect instead gets an absolute application-time + N×6 seconds deadline. Entering initiative preserves that deadline.\n- Explicit periodic profiles retain their registered clocks and tick counts. Never create a second timer merely because a generic duration rule also exists.\n\nThe [exact GPT review](../../../../docs/audit/2026-10-08/full-game/GPT_COMBAT_EXACT_FINDINGS.md) confirms ally-buff source clocks and excluding the current turn for explicit next-turn endpoints. The helper excludes a specific current-end marker only if that marker would otherwise be selected: application during a turn at time1 with end3 excludes3 and selects9; application at/after3 also selects9, without erroneously skipping again to15.\n\nAt a regular turn's **start**, resolve in this order:\n\n1. Expire start-ending effects and apply immediate state changes from those expirations.\n2. Refresh Reaction; tick regular-start recharge/non-action clocks.\n3. Resolve already-due absolute state recovery if now legal, including a previously blocked Stable recovery deadline.\n4. If still alive, dying and at 0 HP with death saves, make that turn's death save.\n5. Resolve other start effects and periodic events in application order.\n6. Begin voluntary turn decisions.\n\nAt **end**, resolve triggered effects, due damage, saves and maintenance before end-ending effects expire; then the slot finishes. No extra turn creates another regular marker. The caller must not reuse a resolved marker.\n\nFor simultaneous effects, earlier application timestamp precedes later. For simultaneous components of one source, its printed internal order controls; otherwise use stable application sequence, with source/mechanical ID as a final tie-break. Record that sequence when creating the effects. Beneficial/harmful labels do not change priority. Periodic family arbitration happens once per family/marker before its damage, retaining the family registry's consumed loser ticks.\n\nExamples: dying at 0 rolls its death save before ordinary start-turn healing; a fatal death save is not undone by ordinary healing. Stable at 0 skips the save, then start-turn damage can break Stable. A natural 20 can restore 1 HP before a due Bleed drops it to 0 as a new drop event. If Decay expires while a Stable recovery deadline is already due, the old deadline resolves once without rerolling recovery time.\n\n",
  "authoritySha256": "2e73bc43c564aef53495aa0166357d7691cd82adff13741f8e21c1939ba0e738",
  "trigger": "A timed event or expiry becomes due",
  "inputs": "Regular schedule, original marker, phase, extra-turn status",
  "outputs": "Ordered due events without duplicate ticks",
  "lifecycle": "Preserve original markers through reorder/absence",
  "exceptions": "Exact source-specific typed event order remains scoped",
  "knownSourceSpecificExtensions": [],
  "usedBy": [
    "AC4",
    "AC5"
  ],
  "usageCoverage": "Explicit known users, not a claim of exhaustive reverse-dependency indexing.",
  "reusableWithinScope": true,
  "summaryAuthority": "The exactAuthority and named source control; normalized fields index them and create no rules.",
  "runtimeImplementedByRegistry": false
}
```

## cast_history_source/sources/accepted_interface_registry_06.json — /entries/8

```json
{
  "id": "docs/mechanics/CLASS_PLAYTEST_RULES.md#targets,-concentration-and-control",
  "name": "Concentration and control",
  "acceptanceStatus": "current-authoritative-provisional-interface",
  "acceptanceBasis": {
    "basis": "Current operative integration text, reused by exact accepted cohorts; not a new claim of whole-document or canon approval.",
    "cohortEvidence": [
      {
        "path": "docs/audit/2026-10-08/full-game/AC4_EXACT_ACCEPTANCE_03_RECEIPT.json",
        "bytes": 6291,
        "sha256": "8dfee7f8a9cd036df80650079b289895cae245de0d8ca17bd926798de55bce2d",
        "frozenCopy": "docs/audit/2026-10-08/full-game/accelerated-review-01/sources/docs/audit/2026-10-08/full-game/AC4_EXACT_ACCEPTANCE_03_RECEIPT.json"
      },
      {
        "path": "docs/audit/2026-10-08/full-game/AC5_EXACT_ACCEPTANCE_05_RECEIPT.json",
        "bytes": 7471,
        "sha256": "5590d1b66ed59287069835ea19e9ffc3d52ea32a6166a9d0645757c7202885a9",
        "frozenCopy": "docs/audit/2026-10-08/full-game/accelerated-review-01/sources/docs/audit/2026-10-08/full-game/AC5_EXACT_ACCEPTANCE_05_RECEIPT.json"
      }
    ]
  },
  "scope": "Shared concentration and bounded control",
  "currentAuthoritativeSource": {
    "path": "DescentReviewChanges/ReviewBible/docs/mechanics/CLASS_PLAYTEST_RULES.md",
    "bytes": 17321,
    "sha256": "adb2f4752b45dc70ce792a675bb30dda362aab5056588061bcde3ba31c4c8a81",
    "frozenCopy": "docs/audit/2026-10-08/full-game/accelerated-review-01/sources/DescentReviewChanges/ReviewBible/docs/mechanics/CLASS_PLAYTEST_RULES.md",
    "heading": "## Targets, concentration and control",
    "line": 21
  },
  "exactAuthority": "## Targets, concentration and control\n\nUnless expressly stated, perceive the target, remain within range and have line of effect; total cover blocks targeting. “Ally” includes self unless it says OTHER. A list cannot contain a creature twice. Select up to the printed limit; an empty target list is not a valid way to farm activation benefits. Zones remain at their chosen point unless described as an aura; allies can leave and lose their benefits. An aura requires its owner conscious unless the card supplies a bounded exception. An effect ending at “end next turn” means the affected creature's next turn only when the card says target's; otherwise the user's.\n\nOne concentration slot for all spells, Chants, Veinweaves, forms or zones that require concentration. Starting another ends the old before the new effect resolves, except for an explicit limited linked-effect rule. Damage prompts CON save against max(10, floor(damage/2)); incapacitation or a failed save ends concentration. The round-down convention is a deliberate pilot interpretation. Concentration does not demand a Bonus Action unless maintenance says so. For a paid 3-pulse effect, start is pulse 1; pay maintenance on each of the next 2 regular turns by turn end for pulses 2/3. Missing payment ends it at that turn's end; otherwise it ends at start of turn 4. No repeated start triggers on maintenance.\n\nForced movement does not provoke opportunity attacks unless explicitly stated, cannot place a creature inside solid matter, and stops at an obstacle. Grapples use the card's save/DC, can be escaped with an Action and STR(Athletics) or DEX(Acrobatics) against that DC, and end beyond reach. A root sets Speed 0 but does not remove Actions. Slows reduce Speed to minimum 0. Silence blocks verbal spells/audible abilities, not all thought or all class features. Charmed effects never determine a player's beliefs; use only the printed action restrictions.\n\nNo repeated hard denial without a new save and cost. For this class suite, a creature can suffer **Stunned, compelled loss of its whole Action/turn, or equivalent hard denial from a given character at most once per encounter**, across that character's class features; later such riders fail while damage and soft riders resolve normally. Record source and target. This draft guard is broader than the older Oracle-only ceiling and is an explicit balance proposal. Reaction denial, Speed reduction, penalties and Frightened do not count as whole-turn loss. Do not silently waive boss immunities, legendary defenses or anatomy.\n\n",
  "authoritySha256": "1d0f7675f29d8051b587c3d6564a373e20829c2b11e14bf90914683572a4bb0e",
  "trigger": "New concentration, damage check or condition ending",
  "inputs": "Old slot, source exception, actual damage/CON save, source-target guard",
  "outputs": "End incompatible old concentration at commitment; exact control effects",
  "lifecycle": "No restoration after failed new cast; source-specific linked effects only",
  "exceptions": "Explicit limited class exceptions remain operative",
  "knownSourceSpecificExtensions": [],
  "usedBy": [
    "AC4",
    "AC5",
    "DE4 (unaccepted proposal)"
  ],
  "usageCoverage": "Explicit known users, not a claim of exhaustive reverse-dependency indexing.",
  "reusableWithinScope": true,
  "summaryAuthority": "The exactAuthority and named source control; normalized fields index them and create no rules.",
  "runtimeImplementedByRegistry": false
}
```

## cast_history_source/sources/accepted_interface_registry_06.json — /entries/22

```json
{
  "id": "dimensional-anchor#procedure",
  "name": "Dimensional Anchor",
  "acceptanceStatus": "accepted-authored-campaign-playtest",
  "acceptanceBasis": {
    "path": "docs/audit/2026-10-08/full-game/AC4_EXACT_ACCEPTANCE_03_RECEIPT.json",
    "bytes": 6291,
    "sha256": "8dfee7f8a9cd036df80650079b289895cae245de0d8ca17bd926798de55bce2d",
    "frozenCopy": "docs/audit/2026-10-08/full-game/accelerated-review-01/sources/docs/audit/2026-10-08/full-game/AC4_EXACT_ACCEPTANCE_03_RECEIPT.json"
  },
  "scope": "Only Dimensional Anchor",
  "currentAuthoritativeSource": {
    "path": "DescentReviewChanges/ReviewBible/data/public/spell_candidates/abjuration_conjuration_rank4_reviewed_03.json",
    "bytes": 144067,
    "sha256": "dc44dfa02289bf0b1f016f01fc9d79cd3a75c913c9e8e8e984e2299ea7c9ed39",
    "frozenCopy": "docs/audit/2026-10-08/full-game/accelerated-review-01/sources/DescentReviewChanges/ReviewBible/data/public/spell_candidates/abjuration_conjuration_rank4_reviewed_03.json",
    "pointer": "/spells/2/procedure"
  },
  "exactAuthority": "Action; range 60 feet; V/S/F. NEW: create a fixed 60-foot-radius sphere centered on a perceived point within range and line of effect, with concentration up to one minute. It prevents an actual teleportation or planar-transition transaction when any transported body’s origin or destination footprint intersects the area. Cargo travels with its actual body; an object transported independently uses its own endpoints. Do not test an imaginary path between two outside endpoints. Ordinary travel through the area remains possible. The rule applies to willing, hostile and self transport using established location records; it creates no destination or plane. A portal can remain present, but transit using a blocked endpoint cannot complete. A known obstruction fails preflight before payment; hidden obstruction or a field established after commitment can defeat a paid transit, leaving the entire transaction at its origin. Atomic group travel fails together, without splitting bodies or inventory. Ending or suppressing the field allows future otherwise legal transactions but does not retry or refund past attempts. The field does not suppress summons, images, mundane movement, physical forced displacement, spells generally, or effects merely because they once crossed space. There is no save or physical cage. An explicit source exception can bypass only the prevention it actually names.",
  "authoritySha256": "263023fc16a0c3f2b6ce4080d88e139a0915123b58a564b4b820db0f9cf02046",
  "trigger": "Exact spell application/endpoint or pricing checkpoint",
  "inputs": "Actual geometry, source state and predicates printed in procedure",
  "outputs": "Exact bounded outcome in authoritative procedure",
  "lifecycle": "Original source duration/concentration; no inferred reset",
  "exceptions": "No generalization to other spells",
  "knownSourceSpecificExtensions": [],
  "usedBy": [
    "AC4",
    "AC5",
    "DE4 (proposal)"
  ],
  "usageCoverage": "Explicit known users, not a claim of exhaustive reverse-dependency indexing.",
  "reusableWithinScope": true,
  "summaryAuthority": "The exactAuthority and named source control; normalized fields index them and create no rules.",
  "runtimeImplementedByRegistry": false
}
```

## cast_history_source/sources/CLASS_PLAYTEST_RULES.md — ## Action and timing limits

## Action and timing limits

One regular Action, one Bonus Action if a feature permits it, normal movement and one Reaction between starts of your turns. A free trigger costs no Action only if expressly stated. All grants share **one extra full Action per creature per round**. An extra Action cannot grant another Action, recharge itself, or start another extra-Action grant. It supplies no extra Bonus Action or Reaction. A card granting additional attacks is not permission to repeat all class riders on every hit: obey each rider's frequency.

Recharge N sets a counter to N after use; reduce once at the start of the owner's regular initiative turn, whether able to act or not. Extra turns/Actions do not tick it. Outside combat tick once per 6 elapsed seconds, without double counting. Recharge 2 used on turn 1 is ready on turn 3. A positive counter can be reset/shortened at most once per ability per round. Zero counters are not legal reset targets and expend no reset use. Resets never restore RP or per-rest uses or grant an immediate activation.

An encounter is a genuine scene of uncertain opposition chosen by the Director, not a player declaration used to reset resources. No encounter gain from attacking allies, one's summons, harmless animals, helpless captives or reused corpses. Out-of-combat abilities retain all printed costs and time. Short-rest means a completed uninterrupted hour of permitted recovery; long-rest means a completed 8-hour Rest Watch. This time convention is a draft integration. Expedition pressure, supplies, safe locations and rest debt still matter. A long rest also refreshes short-rest uses; a short rest never refreshes long-rest uses. Weekly uses refresh after seven full in-world days, not repeated rests.


## cast_history_source/sources/CLASS_PLAYTEST_RULES.md — ## Ordinary spells: one explicit test configuration

## Ordinary spells: one explicit test configuration

Use the manifest-owned **Core Systems Known Descent V 2** class RP tables and rank costs: rank 0–9 costs 0/2/3/5/7/10/13/17/21/26; Grand 32. Follow `src/data/class-spell-progression.js` for each class's rank gates and the existing spell catalog for class/school access. Having enough RP never bypasses a rank gate. Oracle has Revelation Charges, and Soldier/Warrior have no general RP spellcasting. Multiclass spell access is determined separately per class; do not add complete class pools or use total level to unlock a rank. This suite's printed pool tables are single-class; use the existing multiclass pool formula with the new constituent Core V 2 pools for mixed characters.

Four classes have no direct Core V 2 pool row. For this pilot, Crimson Agent uses the Cleric curve multiplied by 0.5; Dragoon, Monk and Thief use that curve multiplied by 0.35, rounded to nearest integer with halves upward, minimum 1. These fallback factors come from the preserved `src/data/resonance-economy.js`; they are explicitly distinguished from direct book tables. The generic Core V 2 Oracle RP row is rejected for this class suite because Oracle's protected class contract uses Revelation Charges only. Oracle never receives RP or ordinary spell access. Retune here means one recovery at the end of a completed short rest, not an unrestricted action.

For a reproducible pilot, retain the protected **Dissonance** layer with Core V 2 numeric RP costs. This combination is a new integration decision: do not also roll a second historical Burn/fizzle system on top of it. Limit=max(4, 2+PB+max(0, casting modifier)). Before a ranked cast, Dissonance at limit/limit+3/limit+6 adds 1/2/3 RP respectively; at limit+6 ordinary casters cannot cast rank 1+. At limit+3 ordinary Overcast is unavailable. A cast then adds base Dissonance 0 at rank 0, 1 at ranks 1–5, 2 at ranks 6–9. Immediate repeated casts of the same named spell add 1, 2, then 3 maximum. Another named spell resets the repeat counter but not accumulated strain. Apply the class's exact cadence reduction/vent; never infer a free RP reduction. Printed class techniques pay printed costs and cause no automatic spell Dissonance unless tagged or expressly described as spells, Echo releases or Matrix casts. For a Mage/Wizard class card tagged as a spell, use the rank printed in normalized data; its rank is fixed at acquisition and does not rise with S. Other techniques are not counterspell able unless their card says so.

Retune recovers max(0, round(max RP/4)+casting modifier), never above maximum, and clears Dissonance. A long rest restores RP and clears Dissonance. Optional 10-minute meditation once/day recovers positive casting modifier RP and reduces Dissonance by PB+positive modifier. A regular turn with no spell or magical class ability loses 1 Dissonance; an Action spent Grounding without casting loses PB instead (not both). Merely ending an encounter does not clear accumulated Dissonance. Refrain survives idle/weapon turns unless a class explicitly clears it. Lich/Necromancer may force ranked casts through Fracture; after resolution take direct unpreventable trauma equal to rank×1/2/3 at the three strained states, minimum 1, based on state before casting. This trauma cannot generate resources or trigger damage-sharing. They still pay RP and meet rank gates.

Generic Overcast is excluded from the initial suite configuration until its options are separately fixed; cards such as Overchannel have their own exact costs and gates. Core V 2's original Burn procedures, older rank×2 costs and smaller companion RP tables remain preserved as alternatives, not silently combined. This configuration is suit able for comparing class drafts, not a claim that all historical magic sources already agree.

