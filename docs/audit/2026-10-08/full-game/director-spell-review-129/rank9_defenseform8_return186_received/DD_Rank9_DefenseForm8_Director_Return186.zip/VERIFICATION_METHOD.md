# Static verification method

No supplied or historical program, game runtime, engine or source builder was executed. Fresh authoring scripts created finite explicit JSON fixtures; a separately written read-only checker imported none of that author code. Source files remain byte-exact.

State SHA-256 uses UTF-8 JSON with Unicode preserved, sorted keys, separators comma/colon, no whitespace or final newline, and no NaN. Whole-file/member hashes use exact raw bytes. Each event forward patch tests the complete prior root and replaces it with the complete subsequent root. Its inverse tests that complete subsequent root then restores the exact prior root. All tests, results, state continuity, monotonic timestamps and per-case mirrors are compared structurally and by SHA-256.

Independent predicates check source access/acquisition, minimum Active choices, preparation and rank gates, real RP/action/recharge/Refrain/Dissonance history, full scheduled regular starts and ends, next marker freshness, original source deadlines, death saves/Ready, actual defense arithmetic, reflection versus transfer roots, component/gear availability, True Seeing and real class Dispel, Haste liability, both Slow modes, energy-body reversion, Sphere support/geometry and serialization in all three modes. Passing scoped predicates do not establish missing source/physical premises. Exact remaining failures are recorded in the semantic report and hold register.

Packaging uses an explicit sorted regular-file allowlist, no hidden path segments or temporary files, full SHA-256/byte count/CRC32 comparison and ZIP central-directory/CRC checks. The saved ZIP must be downloaded again and compared to the local complete bytes before claiming delivery verification.
