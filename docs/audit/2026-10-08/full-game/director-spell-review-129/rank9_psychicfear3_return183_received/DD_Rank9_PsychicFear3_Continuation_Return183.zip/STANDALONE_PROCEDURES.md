# Three unchanged proposed procedures

All remain accepted=false and applied=false. Exact current authority and unresolved branches are in DIRECTOR_DECISION.json.

## psychic-scream

```json
{
  "accepted": false,
  "applied": false,
  "id": "PF182-PROCEDURE-psychic-scream",
  "localProcedure": {
    "enchantment": "NEW conditional physical rider: only when this single damage event actually causes final death, after every valid survival/Null/lifecycle rule, destroy every currently present destructible head of that final body whose physical content record explicitly permits this consequence. If no destructible head exists, no change. Multihead anatomy is not inferred; enumerate only evidenced heads. No extra damage, splash, spell-copy, resource or new death event. No living severance, no second death, no guessed current-form reversion order. Missing anatomy/current-form/lifecycle facts hold the entire positive head branch. Remains and equipment custody are retained with explicit destroyed/intact parts; future revival must satisfy its own unchanged body/time/soul constraints.",
    "evocation": "On initial failed INT and survival, admit Stunned through the original caster's next future regular START (outside initiative+6seconds), with the full shared condition/hard-control gates. No repeated save or concentration. Successful save has no stun. No Enchantment head rider is acquired by Mage/Evocation.",
    "independence": "A source proving psychic immunity prevents damage, not automatically a failed-save Evocation stun. A real stun immunity prevents stun, not damage. Head consequence requires final death by this packet; death prevention, Null final-death restriction or transformation survival cannot be bypassed by the rider.",
    "resolution": "Each selected target independently INT save: failure14d6 psychic; success half. No intelligence-score threshold or hearing requirement is added. Resolve damage, defenses/tempHP, Wound/death and survival before variant rider. Mage psychic damage is not its elemental Focus and creates no Nuke Chain credit. No automatic blend of both native benefits.",
    "selection": "RP9-Q08 A; Q09 A(INT); Q10 A; Q11 A.",
    "targeting": "KEEP Core120ft, up to10 distinct perceived creatures with line of effect. NEW choose any creature, not enemies only. Variant is locked to actual acquired route at commitment: Wizard/Enchantment or Mage/Evocation. Preserve the Illusion book placement verbatim as historical source; it supplies no class access row."
  },
  "nativeBookBindingsUnchanged": [
    {
      "catalogPlacement": {
        "level": 9,
        "name": "Psychic Scream",
        "school": "Enchantment",
        "summary": "Up to 10 creatures take 14d6 psychic damage and heads might explode."
      },
      "currentBookRow": {
        "exactText": "Psychic Scream – Up to 10 creatures take 14d6 psychic damage and heads might explode.",
        "level": 9,
        "line": 9227,
        "name": "Psychic Scream",
        "school": "Enchantment",
        "summary": "Up to 10 creatures take 14d6 psychic damage and heads might explode."
      },
      "spellId": "psychic-scream",
      "summaryDifferencePreserved": false
    },
    {
      "catalogPlacement": {
        "level": 9,
        "name": "Psychic Scream",
        "school": "Evocation",
        "summary": "14d6 psychic damage to up to 10 creatures, stuns them."
      },
      "currentBookRow": {
        "exactText": "Psychic Scream – 14d6 psychic damage to up to 10 creatures, stuns them.",
        "level": 9,
        "line": 9357,
        "name": "Psychic Scream",
        "school": "Evocation",
        "summary": "14d6 psychic damage to up to 10 creatures, stuns them."
      },
      "spellId": "psychic-scream",
      "summaryDifferencePreserved": false
    },
    {
      "catalogPlacement": {
        "level": 9,
        "name": "Psychic Scream",
        "school": "Illusion",
        "summary": "Up to 10 creatures take 14d6 psychic damage and heads might explode."
      },
      "currentBookRow": {
        "exactText": "Psychic Scream – Up to 10 creatures take 14d6 psychic damage and heads might explode.",
        "level": 9,
        "line": 9488,
        "name": "Psychic Scream",
        "school": "Illusion",
        "summary": "Up to 10 creatures take 14d6 psychic damage and heads might explode."
      },
      "spellId": "psychic-scream",
      "summaryDifferencePreserved": false
    }
  ],
  "nativeCardAndAccessUnchanged": {
    "additionalRpCost": 0,
    "classAccess": {
      "Mage": {
        "baseRpCost": 26,
        "minimumClassLevel": 17,
        "rank": 9,
        "school": "Evocation"
      },
      "Wizard": {
        "baseRpCost": 26,
        "minimumClassLevel": 17,
        "rank": 9,
        "school": "Enchantment"
      }
    },
    "id": "psychic-scream",
    "name": "Psychic Scream",
    "operational": null,
    "reviewFlags": [
      "Core resolution requires an explicit operational interpretation",
      "Not selectable in this spell playtest packet until individual operational review"
    ],
    "schools": [
      "Enchantment",
      "Evocation",
      "Illusion"
    ],
    "source": {
      "catalogKey": "psychic-scream",
      "catalogPath": "src/data/spells.js",
      "catalogSha256": "3358a2e1afcbc340dbafd92e45e39a7d2d0a24fed5c0719a3d233263ce530078",
      "coreEntries": [
        {
          "index": 409,
          "original": {
            "casting_time": "1 action",
            "components": "V, S, F",
            "duration": "Instantaneous",
            "effect": "Up to 10 creatures take 14d6 psychic damage and heads might explode.",
            "level": 9,
            "name": "Psychic Scream",
            "range": "120 feet",
            "resolution": "Automatic or opposed as described",
            "rp_cost": 26,
            "school": "Enchantment",
            "source_paragraph": 9485,
            "tags": [
              "Damage"
            ]
          }
        },
        {
          "index": 514,
          "original": {
            "casting_time": "1 action",
            "components": "V, S, F",
            "duration": "Instantaneous",
            "effect": "14d6 psychic damage to up to 10 creatures, stuns them.",
            "level": 9,
            "name": "Psychic Scream",
            "range": "120 feet",
            "resolution": "Automatic or opposed as described",
            "rp_cost": 26,
            "school": "Evocation",
            "source_paragraph": 9615,
            "tags": [
              "Damage"
            ]
          }
        },
        {
          "index": 620,
          "original": {
            "casting_time": "1 action",
            "components": "V, S, F",
            "duration": "Instantaneous",
            "effect": "Up to 10 creatures take 14d6 psychic damage and heads might explode.",
            "level": 9,
            "name": "Psychic Scream",
            "range": "120 feet",
            "resolution": "Automatic or opposed as described",
            "rp_cost": 26,
            "school": "Illusion",
            "source_paragraph": 9746,
            "tags": [
              "Damage"
            ]
          }
        }
      ],
      "corePath": "data/public/Decennium_Descent_Core_Systems_Data_v2_Known_Descent.json",
      "coreSha256": "50c3e9683349e93192191381ab6354ca7d675a24fcc9bb9b039c23e67fecca4f",
      "original": {
        "alternateSummaries": [
          "14d6 psychic damage to up to 10 creatures, stuns them."
        ],
        "castingTime": "Not specified in current rulebook",
        "classLearnLevels": {
          "Mage": 17,
          "Wizard": 17
        },
        "classLevels": {
          "Mage": 9,
          "Wizard": 9
        },
        "classRanks": {
          "Mage": 9,
          "Wizard": 9
        },
        "classSchools": {
          "Mage": "Evocation",
          "Wizard": "Enchantment"
        },
        "classes": [
          "Mage",
          "Wizard"
        ],
        "components": "Not specified in current rulebook",
        "description": "Up to 10 creatures take 14d6 psychic damage and heads might explode.",
        "duration": "Not specified in current rulebook",
        "level": 9,
        "name": "Psychic Scream",
        "placements": [
          {
            "level": 9,
            "name": "Psychic Scream",
            "school": "Enchantment",
            "summary": "Up to 10 creatures take 14d6 psychic damage and heads might explode."
          },
          {
            "level": 9,
            "name": "Psychic Scream",
            "school": "Evocation",
            "summary": "14d6 psychic damage to up to 10 creatures, stuns them."
          },
          {
            "level": 9,
            "name": "Psychic Scream",
            "school": "Illusion",
            "summary": "Up to 10 creatures take 14d6 psychic damage and heads might explode."
          }
        ],
        "range": "Not specified in current rulebook",
        "resonanceRank": 9,
        "school": "Enchantment",
        "schools": [
          "Enchantment",
          "Evocation",
          "Illusion"
        ],
        "source": "Player Rulebook — Spell Lists",
        "status": "canon"
      },
      "possibleHistoricalAliases": []
    },
    "status": "blocked-pending-operational-review",
    "visibility": "public-source-review"
  },
  "originalQuestionsUnchanged": [
    {
      "decisionSelected": false,
      "exactSourceOrConflict": "All actual access is rank9/minimumclasslevel17/base26RP; Psychic Scream has three placements and Weird two, but actual routes do not grant every school.",
      "id": "RP9-Q01",
      "options": "A: preserve actual class-school routes with expressly selected shared or school-specific payloads. B: propose an access correction only with complete source evidence.",
      "recommendationAndConsequences": "Recommend A. Psychic Scream is Mage Evocation and Wizard Enchantment; its Illusion placement supplies history, not an acquired third route. Weird is actually Wizard Enchantment despite two placements. Phantom Armageddon alone includes Cleric/Druid/Wizard Necromancy. Others are Wizard-only. Keep actual repertoire, Action,V/S/F,price/cadence and Ready commitment; no generic upcast or multiple casts from multiple placements.",
      "spellIds": [
        "phantom-armageddon",
        "phantom-cataclysm",
        "psychic-scream",
        "frightful-sovereignty",
        "mass-phantom-killer",
        "weird",
        "reality-break"
      ]
    },
    {
      "decisionSelected": false,
      "exactSourceOrConflict": "Psychic,necrotic and force damage,illusion perception,fear,stun and compulsory movement are distinct components.",
      "id": "RP9-Q03",
      "options": "A: expressly extend applicable accepted damage/condition/root clauses per identity. B: identify a concrete contrary source and select a bounded exception.",
      "recommendationAndConsequences": "Keep each actual damage event and original owner/Null root. Damage immunity does not imply mental/fear/stun immunity; Charmed-only immunity is not universal mental immunity. Control admission is spent only for actual full-Action denial. Preserve real saves,temporaryHP,Wounds,death/concentration and effects independently. True Seeing recognises false images but has only its exact source-qualified removal permissions; do not give blanket dispelling or blindness-based mental immunity.",
      "spellIds": [
        "phantom-armageddon",
        "phantom-cataclysm",
        "psychic-scream",
        "frightful-sovereignty",
        "mass-phantom-killer",
        "weird",
        "reality-break"
      ]
    },
    {
      "decisionSelected": false,
      "exactSourceOrConflict": "Enchantment/Illusion say heads might explode; Evocation says stuns them. All print up to10creatures and14d6psychic.",
      "id": "RP9-Q08",
      "options": "A: preserve actual class-school variants: Evocation stun; Enchantment head-destruction clause. B: explicitly unify all clauses into one selected procedure while recording the added cross-route benefits.",
      "recommendationAndConsequences": "Recommend A for source fidelity unless the director selects a justified union. Preserve all three full placements and actual two access routes. Do not discard either rider or import an external familiar INT-save spell. Shared damage/targeting may be reused,but school cannot be switched freely after commitment.",
      "spellIds": [
        "psychic-scream"
      ]
    },
    {
      "decisionSelected": false,
      "exactSourceOrConflict": "Up to10creatures within Core120feet has no printed save,minimum intelligence,creature-type exclusion or hearing gate.",
      "id": "RP9-Q09",
      "options": "A: NEW initial WIS or INT with explicit full/half/none result. B: automatic damage with separate rider admission.",
      "recommendationAndConsequences": "Select actual save and outcome separately for each school if necessary. Choose legal perceived creatures/line of effect before hidden results; no post-roll substitution. No unprinted intelligence threshold or hearing immunity merely from Scream. Keep all14d6 and at most10 distinct targets; state shared versus independent raw dice and actual damage-before-rider order.",
      "spellIds": [
        "psychic-scream"
      ]
    },
    {
      "decisionSelected": false,
      "exactSourceOrConflict": "Heads MIGHT explode supplies a meaningful conditional body consequence but no trigger/probability.",
      "id": "RP9-Q10",
      "options": "A: NEW destruction only after this event actually causes final death of a target with a destructible head. B: a separately specified probabilistic/threshold body consequence with exact mortality rules.",
      "recommendationAndConsequences": "Confer on the intended benefit. A preserves remains consequences without making damage a hidden instant-death rider; B must supply exact RNG and protections. Define multiheaded/headless bodies,actually vital heads,replacement forms,death prevention,remaining anatomy,revival prerequisites and actual corpse history. Null nonlethal damage cannot secretly kill through a secondary head-loss loophole. No exploding-head area damage or unrelated headless immunity to psychic damage.",
      "spellIds": [
        "psychic-scream"
      ]
    },
    {
      "decisionSelected": false,
      "exactSourceOrConflict": "Evocation stun has no printed duration or escape cadence.",
      "id": "RP9-Q11",
      "options": "A: NEW one-round Stunned with a precise original marker. B: finite longer Stunned with exact repeat saves.",
      "recommendationAndConsequences": "Choose duration as NEW,apply actual hard-control/immunity admission and record source ownership. Damage immunity does not itself prevent stun. A dead target gets no new living condition; genuine survival replacements must be resolved first. Do not import head-destruction into the Evocation route unless Q08 expressly selects it.",
      "spellIds": [
        "psychic-scream"
      ]
    },
    {
      "decisionSelected": false,
      "exactSourceOrConflict": "No earlier complete operational examples exist for this group; source preservation does not prove selected semantics.",
      "id": "RP9-Q23",
      "options": "A: after decisions,write at least two complete source-qualified cases per identity plus every substantive school/state variant. B: explicitly hold only genuinely missing content-dependent branches.",
      "recommendationAndConsequences": "Require all native access/repertoire,actual owner/body/resources,source IDs,3D geometry,clocks,full RNG and intermediate/final states. Psychic Scream needs each actual school and positive head-consequence/stun cases with Null/survival branches; Weird needs real captivity; Sovereignty needs real fleeing; Reality Break needs its whole selected secondary effect sequence. Test immunity,hard-control,suppression,extra turns,source death and actual target changes without invented content. Keep source/semantic/arithmetic/engine/human/balance/cosmology/release gates separate.",
      "spellIds": [
        "phantom-armageddon",
        "phantom-cataclysm",
        "psychic-scream",
        "frightful-sovereignty",
        "mass-phantom-killer",
        "weird",
        "reality-break"
      ]
    },
    {
      "decisionSelected": false,
      "exactSourceOrConflict": "Native placements differ in substantive riders, while the current class routes select only their actual schools. A partial damage-only completion would lose head consequences, nightmare captivity or secondary effects.",
      "id": "PSY129-ADD01",
      "request": "Preserve all native placements and actually acquired routes. Provide a complete positive Enchantment head-consequence case and separate Evocation stun case for Psychic Scream, with explicit vital/headless/multihead/current-form data or named content holds. For Weird select and fully demonstrate real nightmare captivity, including whether its own psychic damage can wake, distinct sleep/mental/fear defenses and allied exposure. For Reality Break supply the complete selected secondary-effect table/sequence and every genuine branch rather than referring to an unspecified effect list.",
      "spellIds": [
        "psychic-scream",
        "weird",
        "reality-break"
      ]
    }
  ],
  "qualifications": {
    "balanceApproved": false,
    "canonicalFilesChanged": false,
    "cosmologyApproved": false,
    "domainClosed": false,
    "humanPlaytested": false,
    "releaseApproved": false,
    "runtimeExecuted": false,
    "staticAuthoredReviewOnly": true,
    "suppliedOrHistoricalProgramsExecuted": false
  },
  "repair182Clarifications": {
    "authorship": "NEW spell-local clarifications only; accepted comparison sources remain within exact original scope",
    "budgetAccounting": "Action/BonusAction/Reaction fields are unspent source allowances, not automatic permission to act. Incapacity blocks eligibility without spending those allowances. Actual regular starts refresh and tick recharge even when incapacitated; death is separately marked inactive. Removing incapacity never refunds a spent allowance.",
    "damageDefenses": "Resolve exact paid defense components separately. Sanctify resistance/fear modes do not union. True Seeing recognizes false imagery without canceling separate damage/control. Mind Blank uses its exact accepted psychic/mental spell scope and willingness; no consent is invented for an unconscious target.",
    "headHold": "Enchantment positive head consequence and headless/multihead/current-form anatomical branches remain whole-case held. The finite avian form profile supplies no head count, vital-head relation or destructibility facts. Death Ward and Null proofs demonstrate their own source stages only, not the missing head consequence.",
    "heldRequiredCaseIds": [
      "RANK9PSYCHICFEAR7-180-PSYCHIC-SCREAM-B/positive-final-death-head-consequence",
      "RANK9PSYCHICFEAR7-180-PSYCHIC-SCREAM-B/headless-multihead-current-form"
    ],
    "repairCaseIds": [
      "RANK9PSYCHICFEAR7-180-PSYCHIC-SCREAM-B/Null-and-survival-prevention",
      "RANK9PSYCHICFEAR7-180-PSYCHIC-SCREAM-B/null-stable-recovery-1",
      "RANK9PSYCHICFEAR7-180-PSYCHIC-SCREAM-B/null-stable-recovery-2",
      "RANK9PSYCHICFEAR7-180-PSYCHIC-SCREAM-B/null-stable-recovery-3",
      "RANK9PSYCHICFEAR7-180-PSYCHIC-SCREAM-B/null-stable-recovery-4"
    ],
    "sourceQualification": "All new actor builds, conditional dice and geometry are explicit static witnesses. No actual campaign acquisition, creature anatomy, authoritative CR, hidden observer knowledge or runtime availability is created. Accepted comparison status may coexist with blocked catalog runtime selection; current authored index binding controls only its recorded authored scope."
  },
  "sharedProcedure": {
    "commitment": "Action,V/S/F; ordinary range and identity checks precede commitment. Choose school variant and any Reality Break mode before paying. Cast spends once. Area membership is snapshotted at manifestation. Ready pays and resolves cast side effects at setup, holds concentration, expires next actual regular own START, and releases once with a legal Reaction after trigger; targeting occurs then. Effect clocks begin at manifestation; no second cast/cost/strain at release. Source component failure, countering, interruption, replacement or expiry refunds nothing already committed.",
    "control": "Before new Stunned or Unconscious admission, resolve survival, actual condition defenses and source-character/target encounter hard-denial allowance. Spend the combined mark once only upon successful new whole-Action denial. Used allowance blocks that new rider only; independent damage remains. No downgraded substitute control or repeated attempt after immunity/suppression. Existing admitted control may resume for its remaining original duration if a suppressor ends; no new costs, mark, duration or fresh side-effect such as another item drop. Full Stunned and Unconscious semantics apply, including ending concentration, no Actions/BonusAction/Reaction, movement prohibition, specified automatic saves and attack consequences. Frightened/flight/slow are not whole-Action denial.",
    "eligibility": "Before commitment bind actor identity, class level, acquired repertoire/prepared matrix, actual class-school row, component availability and focus custody, current life/body, Action eligibility, rank gate and RP. Rank9 minimum class17 and native base26 RP in every route. School placement alone gives no acquired route. Revalidate target/range/line of effect at manifestation. A paid legal cast whose targets later fail remains spent; an illegal precommit attempt spends nothing.",
    "geometryAndInformation": "NEW for these enemy-selective spells: designated enemies are creatures the caster currently perceives and regards as hostile; no objective allegiance oracle. Snapshot ALL qualifying designated enemies in the declared geometry without optional post-roll omissions. A mistaken hostile is affected. A concealed unknown enemy is not discovered. Allies/self are excluded unless perceived hostile designation actually applies; Weird instead snapshots every creature including self, allies and unperceived bodies in its area with source line of effect. Use actual occupied body geometry/full 3D, range and total-cover segments. Unknown scene/body/cover facts hold the affected admission, not invented coordinates.",
    "packet": "One independent damage roll per target per damage event, declared before outcomes, not one shared roll across targets. Binary saves use actual DC/modifiers and advantage/disadvantage, no generic natural1/20 save exception. Save half rounds down before defenses; resistance once, immunity separately, then tempHP, normalHP, instant death, Wound save/injury, zero-HP lifecycle, concentration and living riders in accepted order. No event silently selects Wound/injury/death dice. Hold at the next unavailable input. Surviving damage is never rolled back by rider resistance, awakening, illusion recognition, dispel, suppression, expiry or source death.",
    "phaseBridge": "For target-bound recurring records use actual regular target START damage and END saves. A source-supported companion without an independent regular turn uses its single attached controller-phase START/END once per controller regular turn; controller changes cannot add an exposure or move an existing expiry. Extra/attached actions confer no extra periodic marker. Outside initiative use initial packet then six-second START/END opportunity pairs (packet then save); transition maps each first unresolved opportunity to the next lawful marker without duplicating exposure. Actual grant, controller and phase must be bound; missing genuine extra-turn/companion evidence is held.",
    "qualifications": "No runtime execution, human play, balance judgment, cosmology decision, domain closure or release approval. No world-ending, new planes, summoned beings, memory extraction, hidden knowledge, creature anatomy, campaign immunity, acquisition or revival authorization follows from these names or authored fixtures.",
    "recurringFamily": "NEW explicit local extension of the P20 family/exposure interface for Mass Phantom Killer and Weird only: one packet per named family/recipient/actual numbered round, across owners and including an initial packet. Earliest active eligible application wins; ties use application order then immutable source ID. Mark the family opportunity before defense/HP resolution; losing due applications lose that opportunity. Suppressed sources lose their own due packet, cannot bank it, but do not consume another active source's opportunity. Independent ending WIS saves survive suppression. Family histories survive recasts/ownership copies. Mass Phantom Killer, Weird and Greater Phantasmal Killer are three distinct families.",
    "resources": "Use actual RP, Dissonance, Refrain, surcharges, class discounts and active passives. Base strain rank9=2; Wizard first distinct prepared underlying family=0 base only. Subsequent immediate same-name casts add capped Refrain1/2/3. No generic Overcast. First-cast exceptions never reset by copies, changing school, Ready release, suppression or new recipients. Keep resource history. No assumed reductions or kill-resource farm.",
    "roots": "Every cast has an immutable source owner, class/school, rank, component roots and target admissions. Child damage retains original root, funding, type and Null provenance; a Null-qualified hit preserves its actual recipient lifecycle restriction and cannot acquire a final-death/head-destruction side path. Damage, private perception, body consequence, fear, stun, sleep, voluntary flight and forced displacement are separate records. A source covering only one component affects only that component. No unsourced generic mental immunity or all-effects dispel.",
    "scope": "NEW PF181 spell-local authored selections for exactly the seven IDs. Native text/access is copied intact in each procedure. Proposed overrides of Instantaneous recurrence metadata and missing saves/durations are labeled; no global authority is asserted.",
    "termination": "Concentration ends on actual failure, incapacitation, death, voluntary ending or replacement unless an acquired specific exception applies. For non-concentration target conditions source death does not itself reset/erase their finite virtual endpoints. Target final death removes living conditions, not physical remains or ledger. Dispel ends only its eligible selected source root. Suppression blocks covered active components while clocks, mandatory saves and independently scheduled actors continue; no missed pulse, flight, forced displacement or head consequence replays on resumption. At an absolute maximum deadline expire before a coincident packet.",
    "timing": "Each actor owns its actual regular START/END calendar; spell damage opportunities are separately registered. At START expire due start effects and Ready, refresh Reaction and regular budgets, tick recharge, process legal absolute recovery and required death save before spell start effects and voluntary decisions. END resolves due damage/saves/maintenance then end expiry. Six-second virtual source/target markers preserve old durations across initiative change/removal; extra Actions/extra turns never create a regular marker, recharge tick or death save. A pulse is not an actor turn. Do not use one universal pulse rule."
  },
  "spellId": "psychic-scream",
  "status": "revised authored proposal; per-identity decision in DIRECTOR_DECISION.json"
}
```

## mass-phantom-killer

```json
{
  "accepted": false,
  "applied": false,
  "id": "PF182-PROCEDURE-mass-phantom-killer",
  "localProcedure": {
    "clock": "Apply explicit recurringFamily and phaseBridge clauses; exact expiry before coincident pulse; no extra packet on entering range, changed hostility, recognition, illusion reveal, extra Action, genuine extra turn, controller change or suppression return.",
    "ending": "Each target WIS at every actual regular END including the upcoming END of an already-started turn, even during suppression; success ends only that owner's application. Target death, removal, source concentration loss or absolute60second expiry ends it. Damage already taken remains. Preserve target lifecycle through form changes; if body identity is uncertain hold affected branch. Separate owners maintain independent concentration/admission/DC/endings despite one shared damage exposure. Recognition/True Seeing does not by itself remove the independently real damage source.",
    "resolution": "NEW concentration up to60elapsed seconds, overriding Instantaneous metadata only for this proposed identity. Failed initial admission attempts6d6 psychic immediately, then actual regular target START attempts6d6 under family.mass-phantom-killer once-per-target/numbered-round exposure. Independent rolls for each target and opportunity. No fear, stun, captivity or instantaneous-death rider from the name.",
    "selection": "RP9-Q14 A; Q15 A; Q16 A.",
    "targeting": "KEEP up to5 perceived designated enemies within120ft, distinct and with line of effect at manifestation. NEW initial WIS per target; success creates no record/damage; failure creates an independent application. No ongoing range or hostility tether and no free retarget."
  },
  "nativeBookBindingsUnchanged": [
    {
      "catalogPlacement": {
        "level": 9,
        "name": "Mass Phantom Killer",
        "school": "Illusion",
        "summary": "Up to 5 enemies take 6d6 psychic/round; WIS save ends."
      },
      "currentBookRow": {
        "exactText": "Mass Phantom Killer – Up to 5 enemies take 6d6 psychic/round; WIS save ends.",
        "level": 9,
        "line": 9477,
        "name": "Mass Phantom Killer",
        "school": "Illusion",
        "summary": "Up to 5 enemies take 6d6 psychic/round; WIS save ends."
      },
      "spellId": "mass-phantom-killer",
      "summaryDifferencePreserved": false
    }
  ],
  "nativeCardAndAccessUnchanged": {
    "additionalRpCost": 0,
    "classAccess": {
      "Wizard": {
        "baseRpCost": 26,
        "minimumClassLevel": 17,
        "rank": 9,
        "school": "Illusion"
      }
    },
    "id": "mass-phantom-killer",
    "name": "Mass Phantom Killer",
    "operational": null,
    "reviewFlags": [
      "Not selectable in this spell playtest packet until individual operational review"
    ],
    "schools": [
      "Illusion"
    ],
    "source": {
      "catalogKey": "mass-phantom-killer",
      "catalogPath": "src/data/spells.js",
      "catalogSha256": "3358a2e1afcbc340dbafd92e45e39a7d2d0a24fed5c0719a3d233263ce530078",
      "coreEntries": [
        {
          "index": 609,
          "original": {
            "casting_time": "1 action",
            "components": "V, S, F",
            "duration": "Instantaneous",
            "effect": "Up to 5 enemies take 6d6 psychic/round; WIS save ends.",
            "level": 9,
            "name": "Mass Phantom Killer",
            "range": "120 feet",
            "resolution": "Wisdom save",
            "rp_cost": 26,
            "school": "Illusion",
            "source_paragraph": 9735,
            "tags": [
              "Damage"
            ]
          }
        }
      ],
      "corePath": "data/public/Decennium_Descent_Core_Systems_Data_v2_Known_Descent.json",
      "coreSha256": "50c3e9683349e93192191381ab6354ca7d675a24fcc9bb9b039c23e67fecca4f",
      "original": {
        "alternateSummaries": [],
        "castingTime": "Not specified in current rulebook",
        "classLearnLevels": {
          "Wizard": 17
        },
        "classLevels": {
          "Wizard": 9
        },
        "classRanks": {
          "Wizard": 9
        },
        "classSchools": {
          "Wizard": "Illusion"
        },
        "classes": [
          "Wizard"
        ],
        "components": "Not specified in current rulebook",
        "description": "Up to 5 enemies take 6d6 psychic/round; WIS save ends.",
        "duration": "Not specified in current rulebook",
        "level": 9,
        "name": "Mass Phantom Killer",
        "placements": [
          {
            "level": 9,
            "name": "Mass Phantom Killer",
            "school": "Illusion",
            "summary": "Up to 5 enemies take 6d6 psychic/round; WIS save ends."
          }
        ],
        "range": "Not specified in current rulebook",
        "resonanceRank": 9,
        "school": "Illusion",
        "schools": [
          "Illusion"
        ],
        "source": "Player Rulebook — Spell Lists",
        "status": "canon"
      },
      "possibleHistoricalAliases": []
    },
    "status": "blocked-pending-operational-review",
    "visibility": "public-source-review"
  },
  "originalQuestionsUnchanged": [
    {
      "decisionSelected": false,
      "exactSourceOrConflict": "All actual access is rank9/minimumclasslevel17/base26RP; Psychic Scream has three placements and Weird two, but actual routes do not grant every school.",
      "id": "RP9-Q01",
      "options": "A: preserve actual class-school routes with expressly selected shared or school-specific payloads. B: propose an access correction only with complete source evidence.",
      "recommendationAndConsequences": "Recommend A. Psychic Scream is Mage Evocation and Wizard Enchantment; its Illusion placement supplies history, not an acquired third route. Weird is actually Wizard Enchantment despite two placements. Phantom Armageddon alone includes Cleric/Druid/Wizard Necromancy. Others are Wizard-only. Keep actual repertoire, Action,V/S/F,price/cadence and Ready commitment; no generic upcast or multiple casts from multiple placements.",
      "spellIds": [
        "phantom-armageddon",
        "phantom-cataclysm",
        "psychic-scream",
        "frightful-sovereignty",
        "mass-phantom-killer",
        "weird",
        "reality-break"
      ]
    },
    {
      "decisionSelected": false,
      "exactSourceOrConflict": "Psychic,necrotic and force damage,illusion perception,fear,stun and compulsory movement are distinct components.",
      "id": "RP9-Q03",
      "options": "A: expressly extend applicable accepted damage/condition/root clauses per identity. B: identify a concrete contrary source and select a bounded exception.",
      "recommendationAndConsequences": "Keep each actual damage event and original owner/Null root. Damage immunity does not imply mental/fear/stun immunity; Charmed-only immunity is not universal mental immunity. Control admission is spent only for actual full-Action denial. Preserve real saves,temporaryHP,Wounds,death/concentration and effects independently. True Seeing recognises false images but has only its exact source-qualified removal permissions; do not give blanket dispelling or blindness-based mental immunity.",
      "spellIds": [
        "phantom-armageddon",
        "phantom-cataclysm",
        "psychic-scream",
        "frightful-sovereignty",
        "mass-phantom-killer",
        "weird",
        "reality-break"
      ]
    },
    {
      "decisionSelected": false,
      "exactSourceOrConflict": "Up to FIVE ENEMIES take6d6psychic PERROUND with WIS SAVE ENDS; Core Instantaneous conflicts.",
      "id": "RP9-Q14",
      "options": "A: NEW concentration up to60seconds using explicitly extended Greater Phantasmal Killer admission/START-pulse/END-save rules. B: another finite exact recurring-damage lifecycle.",
      "recommendationAndConsequences": "Recommend A for review. Preserve five independent applications and the full6d6. Select initial WIS and whether failed admission produces an immediate packet. Each target independently ends; one success does not cancel the others. No fear,stun,instant death or attacking phantom follows merely from the title.",
      "spellIds": [
        "mass-phantom-killer"
      ]
    },
    {
      "decisionSelected": false,
      "exactSourceOrConflict": "Selection,changed hostility and ongoing range versus initial120-foot target gate are unspecified.",
      "id": "RP9-Q15",
      "options": "A: select up tofive perceived designated hostile creatures at establishment with no later range/hostility tether. B: explicit continuing tether with its exact ending behavior.",
      "recommendationAndConsequences": "Recommend A as a scoped comparison. Specify initial selection timing under Ready,cover/line of effect and no free retargeting when one recipient dies or saves. Ordinary senses do not reveal hidden affiliations or private nightmare content. Recognition and fear-only defenses cannot remove independent damage without a real source permission.",
      "spellIds": [
        "mass-phantom-killer"
      ]
    },
    {
      "decisionSelected": false,
      "exactSourceOrConflict": "Several owners,initiative changes and suppressed pulses can create duplicate recurring exposure if clocks are underspecified.",
      "id": "RP9-Q16",
      "options": "A: expressly extend named-family once-per-target/numbered-round exposure with independent source saves and original expiry. B: permit independently stacking sources and document the resulting full damage.",
      "recommendationAndConsequences": "Recommend A from Greater Phantasmal Killer as NEW scope. Keep this distinct named family from lower spells unless explicitly merged. Record exposure before the actual packet; immunity/HP floors cannot create another opportunity. Map future START/END markers exactly across initiative and actual companion phases; no new death save from a companion-only phase. Suppressed pulses are lost; scheduled END saves and expiry continue.",
      "spellIds": [
        "mass-phantom-killer"
      ]
    },
    {
      "decisionSelected": false,
      "exactSourceOrConflict": "No earlier complete operational examples exist for this group; source preservation does not prove selected semantics.",
      "id": "RP9-Q23",
      "options": "A: after decisions,write at least two complete source-qualified cases per identity plus every substantive school/state variant. B: explicitly hold only genuinely missing content-dependent branches.",
      "recommendationAndConsequences": "Require all native access/repertoire,actual owner/body/resources,source IDs,3D geometry,clocks,full RNG and intermediate/final states. Psychic Scream needs each actual school and positive head-consequence/stun cases with Null/survival branches; Weird needs real captivity; Sovereignty needs real fleeing; Reality Break needs its whole selected secondary effect sequence. Test immunity,hard-control,suppression,extra turns,source death and actual target changes without invented content. Keep source/semantic/arithmetic/engine/human/balance/cosmology/release gates separate.",
      "spellIds": [
        "phantom-armageddon",
        "phantom-cataclysm",
        "psychic-scream",
        "frightful-sovereignty",
        "mass-phantom-killer",
        "weird",
        "reality-break"
      ]
    },
    {
      "decisionSelected": false,
      "exactSourceOrConflict": "Current Control15, illusion and body/life interfaces have scoped rules for denial, private perception, actual motion and retained state; historical accepted-but-unapplied labels are not current authority.",
      "id": "PSY129-ADD02",
      "request": "Resolve actual current index/status and exact procedures before adopting comparisons. Keep private perceived catastrophe separate from world/body state and each damage, fear, stun, flight and source clock separately admitted. Show a real spent hard-control allowance that blocks only covered new denial, actual independent damage, voluntary-budget flight with unknown or blocked safe route, and recurring effects through extra/attached phases and suppression without replay. Use genuine sources for every immunity or removal instead of a blanket mental-defense label.",
      "spellIds": [
        "phantom-armageddon",
        "phantom-cataclysm",
        "frightful-sovereignty",
        "mass-phantom-killer",
        "weird",
        "reality-break"
      ]
    }
  ],
  "qualifications": {
    "balanceApproved": false,
    "canonicalFilesChanged": false,
    "cosmologyApproved": false,
    "domainClosed": false,
    "humanPlaytested": false,
    "releaseApproved": false,
    "runtimeExecuted": false,
    "staticAuthoredReviewOnly": true,
    "suppliedOrHistoricalProgramsExecuted": false
  },
  "repair182Clarifications": {
    "actualBodyAndPhase": "Same-body form changes, changed hostility and leaving initial cast range do not re-admit or reset an existing root. Actual final recipient death ends that admission without healing; source death ends concentration. A familiar uses only its original attached packet/save checkpoints. A separate real Mage command may authorize exactly one native Dart; it neither duplicates recurring exposure nor supplies another default Dodge after the attack. No independent creature turn or death save is inferred.",
    "authorship": "NEW spell-local clarifications only; accepted comparison sources remain within exact original scope",
    "budgetAccounting": "Action/BonusAction/Reaction fields are unspent source allowances, not automatic permission to act. Incapacity blocks eligibility without spending those allowances. Actual regular starts refresh and tick recharge even when incapacitated; death is separately marked inactive. Removing incapacity never refunds a spent allowance.",
    "damageDefenses": "Resolve exact paid defense components separately. Sanctify resistance/fear modes do not union. True Seeing recognizes false imagery without canceling separate damage/control. Mind Blank uses its exact accepted psychic/mental spell scope and willingness; no consent is invented for an unconscious target.",
    "heldRequiredCaseIds": [
      "RANK9PSYCHICFEAR7-180-MASS-PHANTOM-KILLER-B/genuine-extra-turn-and-attached-phase"
    ],
    "repairCaseIds": [
      "RANK9PSYCHICFEAR7-180-MASS-PHANTOM-KILLER-B/actual-source-death-original-endpoint",
      "RANK9PSYCHICFEAR7-180-MASS-PHANTOM-KILLER-B/commanded-attached-phase-native-dart",
      "RANK9PSYCHICFEAR7-180-MASS-PHANTOM-KILLER-B/source-qualified-attached-phase",
      "RANK9PSYCHICFEAR7-180-MASS-PHANTOM-KILLER-B/target-form-death-hostility-range"
    ],
    "sourceQualification": "All new actor builds, conditional dice and geometry are explicit static witnesses. No actual campaign acquisition, creature anatomy, authoritative CR, hidden observer knowledge or runtime availability is created. Accepted comparison status may coexist with blocked catalog runtime selection; current authored index binding controls only its recorded authored scope.",
    "unprovedExtraTurn": "The procedure has no acquired genuine full-extra-turn example. The required positive extra-turn branch stays whole-case held and this identity remains unaccepted. Actual ordinary, attached, multiple-owner and suppression ledgers are not relabeled as full extra turns."
  },
  "sharedProcedure": {
    "commitment": "Action,V/S/F; ordinary range and identity checks precede commitment. Choose school variant and any Reality Break mode before paying. Cast spends once. Area membership is snapshotted at manifestation. Ready pays and resolves cast side effects at setup, holds concentration, expires next actual regular own START, and releases once with a legal Reaction after trigger; targeting occurs then. Effect clocks begin at manifestation; no second cast/cost/strain at release. Source component failure, countering, interruption, replacement or expiry refunds nothing already committed.",
    "control": "Before new Stunned or Unconscious admission, resolve survival, actual condition defenses and source-character/target encounter hard-denial allowance. Spend the combined mark once only upon successful new whole-Action denial. Used allowance blocks that new rider only; independent damage remains. No downgraded substitute control or repeated attempt after immunity/suppression. Existing admitted control may resume for its remaining original duration if a suppressor ends; no new costs, mark, duration or fresh side-effect such as another item drop. Full Stunned and Unconscious semantics apply, including ending concentration, no Actions/BonusAction/Reaction, movement prohibition, specified automatic saves and attack consequences. Frightened/flight/slow are not whole-Action denial.",
    "eligibility": "Before commitment bind actor identity, class level, acquired repertoire/prepared matrix, actual class-school row, component availability and focus custody, current life/body, Action eligibility, rank gate and RP. Rank9 minimum class17 and native base26 RP in every route. School placement alone gives no acquired route. Revalidate target/range/line of effect at manifestation. A paid legal cast whose targets later fail remains spent; an illegal precommit attempt spends nothing.",
    "geometryAndInformation": "NEW for these enemy-selective spells: designated enemies are creatures the caster currently perceives and regards as hostile; no objective allegiance oracle. Snapshot ALL qualifying designated enemies in the declared geometry without optional post-roll omissions. A mistaken hostile is affected. A concealed unknown enemy is not discovered. Allies/self are excluded unless perceived hostile designation actually applies; Weird instead snapshots every creature including self, allies and unperceived bodies in its area with source line of effect. Use actual occupied body geometry/full 3D, range and total-cover segments. Unknown scene/body/cover facts hold the affected admission, not invented coordinates.",
    "packet": "One independent damage roll per target per damage event, declared before outcomes, not one shared roll across targets. Binary saves use actual DC/modifiers and advantage/disadvantage, no generic natural1/20 save exception. Save half rounds down before defenses; resistance once, immunity separately, then tempHP, normalHP, instant death, Wound save/injury, zero-HP lifecycle, concentration and living riders in accepted order. No event silently selects Wound/injury/death dice. Hold at the next unavailable input. Surviving damage is never rolled back by rider resistance, awakening, illusion recognition, dispel, suppression, expiry or source death.",
    "phaseBridge": "For target-bound recurring records use actual regular target START damage and END saves. A source-supported companion without an independent regular turn uses its single attached controller-phase START/END once per controller regular turn; controller changes cannot add an exposure or move an existing expiry. Extra/attached actions confer no extra periodic marker. Outside initiative use initial packet then six-second START/END opportunity pairs (packet then save); transition maps each first unresolved opportunity to the next lawful marker without duplicating exposure. Actual grant, controller and phase must be bound; missing genuine extra-turn/companion evidence is held.",
    "qualifications": "No runtime execution, human play, balance judgment, cosmology decision, domain closure or release approval. No world-ending, new planes, summoned beings, memory extraction, hidden knowledge, creature anatomy, campaign immunity, acquisition or revival authorization follows from these names or authored fixtures.",
    "recurringFamily": "NEW explicit local extension of the P20 family/exposure interface for Mass Phantom Killer and Weird only: one packet per named family/recipient/actual numbered round, across owners and including an initial packet. Earliest active eligible application wins; ties use application order then immutable source ID. Mark the family opportunity before defense/HP resolution; losing due applications lose that opportunity. Suppressed sources lose their own due packet, cannot bank it, but do not consume another active source's opportunity. Independent ending WIS saves survive suppression. Family histories survive recasts/ownership copies. Mass Phantom Killer, Weird and Greater Phantasmal Killer are three distinct families.",
    "resources": "Use actual RP, Dissonance, Refrain, surcharges, class discounts and active passives. Base strain rank9=2; Wizard first distinct prepared underlying family=0 base only. Subsequent immediate same-name casts add capped Refrain1/2/3. No generic Overcast. First-cast exceptions never reset by copies, changing school, Ready release, suppression or new recipients. Keep resource history. No assumed reductions or kill-resource farm.",
    "roots": "Every cast has an immutable source owner, class/school, rank, component roots and target admissions. Child damage retains original root, funding, type and Null provenance; a Null-qualified hit preserves its actual recipient lifecycle restriction and cannot acquire a final-death/head-destruction side path. Damage, private perception, body consequence, fear, stun, sleep, voluntary flight and forced displacement are separate records. A source covering only one component affects only that component. No unsourced generic mental immunity or all-effects dispel.",
    "scope": "NEW PF181 spell-local authored selections for exactly the seven IDs. Native text/access is copied intact in each procedure. Proposed overrides of Instantaneous recurrence metadata and missing saves/durations are labeled; no global authority is asserted.",
    "termination": "Concentration ends on actual failure, incapacitation, death, voluntary ending or replacement unless an acquired specific exception applies. For non-concentration target conditions source death does not itself reset/erase their finite virtual endpoints. Target final death removes living conditions, not physical remains or ledger. Dispel ends only its eligible selected source root. Suppression blocks covered active components while clocks, mandatory saves and independently scheduled actors continue; no missed pulse, flight, forced displacement or head consequence replays on resumption. At an absolute maximum deadline expire before a coincident packet.",
    "timing": "Each actor owns its actual regular START/END calendar; spell damage opportunities are separately registered. At START expire due start effects and Ready, refresh Reaction and regular budgets, tick recharge, process legal absolute recovery and required death save before spell start effects and voluntary decisions. END resolves due damage/saves/maintenance then end expiry. Six-second virtual source/target markers preserve old durations across initiative change/removal; extra Actions/extra turns never create a regular marker, recharge tick or death save. A pulse is not an actor turn. Do not use one universal pulse rule."
  },
  "spellId": "mass-phantom-killer",
  "status": "revised authored proposal; per-identity decision in DIRECTOR_DECISION.json"
}
```

## weird

```json
{
  "accepted": false,
  "applied": false,
  "id": "PF182-PROCEDURE-weird",
  "localProcedure": {
    "captivity": "Actual magically caused Unconscious is meaningful captivity: no movement/speech/Action/BonusAction/Reaction, unaware, drops held items to current physical support, Prone where physically legal, automatic STR/DEX save failure, attacks against advantage and adjacent hits critical. End concentration on admission; preserve item ownership/custody/position and physical fall/landing consequences. Nightmare content remains private, supplies no false real bodies or caster knowledge. Body/flight/support prerequisite failures hold physical consequences rather than inventing a landing.",
    "ending": "Each admitted target independently WIS at regular END even while asleep or suppressed. Success ends all components of that owner's application. Source concentration ending/death, target final death, eligible dispel or absolute60second expiry also ends it. If caster is inside and becomes incapacitated, its concentration ends immediately, cleaning remaining applications and preventing later components that require a live source. Process targets in fixed admission order declared before rolls. True Seeing recognition alone is not a free Action or waking trigger; exact stronger immunity remains separately honored. Family/phase clock clauses apply.",
    "resolution": "NEW initial WIS: success creates no record or damage; failure creates private nightmare plus separately real4d10 psychic immediately and at future actual regular target STARTs, family.weird exposure, concentration up to60elapsed seconds. Resolve first damage/lifecycle before admitting magically caused Unconscious on eligible survivors. Sleep/Unconscious defenses and hard-denial marks separately gate the captivity; blocked sleep leaves the admitted psychic damage record, not a replacement stun/fear state.",
    "selection": "RP9-Q17 A; Q18 A; Q19 A.",
    "targeting": "KEEP Core30ft and native30ft radius. NEW fixed initial snapshot of all creatures whose actual occupied bodies intersect the full3D30ft sphere at a point within30ft, with caster-to-point and point-to-body line of effect. Include caster/allies and concealed creatures; area damage does not disclose their identity/location. Later entrants are not admitted and leaving is not an escape tether. Actual Wizard/Enchantment route only.",
    "wake": "NEW explicit self-damage exception: psychic damage from this same root does not wake its own captivity. Positive post-temp damage from any other root (including a different Weird), or an adjacent helper's legal Action and physical contact, ends this root's sleep component only. External damage must resolve completely before wake; tempHP-only damage does not meet this chosen wake rule. No new sleep admission after waking, immunity loss or suppression. Prone, dropped equipment, damage and independent Unconscious sources remain. Sleep immunity blocks only sleep; fear immunity blocks nothing here; exact mental-illusion protection may cover the whole application only when its text does."
  },
  "nativeBookBindingsUnchanged": [
    {
      "catalogPlacement": {
        "level": 9,
        "name": "Weird",
        "school": "Enchantment",
        "summary": "Creatures in 30-ft radius trapped in nightmares; 4d10 psychic damage per round."
      },
      "currentBookRow": {
        "exactText": "Weird – Creatures in 30-ft radius trapped in nightmares; 4d10 psychic damage per round.",
        "level": 9,
        "line": 9228,
        "name": "Weird",
        "school": "Enchantment",
        "summary": "Creatures in 30-ft radius trapped in nightmares; 4d10 psychic damage per round."
      },
      "spellId": "weird",
      "summaryDifferencePreserved": false
    },
    {
      "catalogPlacement": {
        "level": 9,
        "name": "Weird",
        "school": "Illusion",
        "summary": "Creatures in 30-foot radius trapped in nightmares; 4d10 psychic damage per round."
      },
      "currentBookRow": {
        "exactText": "Weird – Creatures in 30-foot radius trapped in nightmares; 4d10 psychic damage per round.",
        "level": 9,
        "line": 9484,
        "name": "Weird",
        "school": "Illusion",
        "summary": "Creatures in 30-foot radius trapped in nightmares; 4d10 psychic damage per round."
      },
      "spellId": "weird",
      "summaryDifferencePreserved": false
    }
  ],
  "nativeCardAndAccessUnchanged": {
    "additionalRpCost": 0,
    "classAccess": {
      "Wizard": {
        "baseRpCost": 26,
        "minimumClassLevel": 17,
        "rank": 9,
        "school": "Enchantment"
      }
    },
    "id": "weird",
    "name": "Weird",
    "operational": null,
    "reviewFlags": [
      "Core resolution requires an explicit operational interpretation",
      "Not selectable in this spell playtest packet until individual operational review"
    ],
    "schools": [
      "Enchantment",
      "Illusion"
    ],
    "source": {
      "catalogKey": "weird",
      "catalogPath": "src/data/spells.js",
      "catalogSha256": "3358a2e1afcbc340dbafd92e45e39a7d2d0a24fed5c0719a3d233263ce530078",
      "coreEntries": [
        {
          "index": 410,
          "original": {
            "casting_time": "1 action",
            "components": "V, S, F",
            "duration": "Instantaneous",
            "effect": "Creatures in 30-ft radius trapped in nightmares; 4d10 psychic damage per round.",
            "level": 9,
            "name": "Weird",
            "range": "30 feet",
            "resolution": "Automatic or opposed as described",
            "rp_cost": 26,
            "school": "Enchantment",
            "source_paragraph": 9486,
            "tags": [
              "Damage"
            ]
          }
        },
        {
          "index": 616,
          "original": {
            "casting_time": "1 action",
            "components": "V, S, F",
            "duration": "Instantaneous",
            "effect": "Creatures in 30-foot radius trapped in nightmares; 4d10 psychic damage per round.",
            "level": 9,
            "name": "Weird",
            "range": "30 feet",
            "resolution": "Automatic or opposed as described",
            "rp_cost": 26,
            "school": "Illusion",
            "source_paragraph": 9742,
            "tags": [
              "Damage"
            ]
          }
        }
      ],
      "corePath": "data/public/Decennium_Descent_Core_Systems_Data_v2_Known_Descent.json",
      "coreSha256": "50c3e9683349e93192191381ab6354ca7d675a24fcc9bb9b039c23e67fecca4f",
      "original": {
        "alternateSummaries": [
          "Creatures in 30-foot radius trapped in nightmares; 4d10 psychic damage per round."
        ],
        "castingTime": "Not specified in current rulebook",
        "classLearnLevels": {
          "Wizard": 17
        },
        "classLevels": {
          "Wizard": 9
        },
        "classRanks": {
          "Wizard": 9
        },
        "classSchools": {
          "Wizard": "Enchantment"
        },
        "classes": [
          "Wizard"
        ],
        "components": "Not specified in current rulebook",
        "description": "Creatures in 30-ft radius trapped in nightmares; 4d10 psychic damage per round.",
        "duration": "Not specified in current rulebook",
        "level": 9,
        "name": "Weird",
        "placements": [
          {
            "level": 9,
            "name": "Weird",
            "school": "Enchantment",
            "summary": "Creatures in 30-ft radius trapped in nightmares; 4d10 psychic damage per round."
          },
          {
            "level": 9,
            "name": "Weird",
            "school": "Illusion",
            "summary": "Creatures in 30-foot radius trapped in nightmares; 4d10 psychic damage per round."
          }
        ],
        "range": "Not specified in current rulebook",
        "resonanceRank": 9,
        "school": "Enchantment",
        "schools": [
          "Enchantment",
          "Illusion"
        ],
        "source": "Player Rulebook — Spell Lists",
        "status": "canon"
      },
      "possibleHistoricalAliases": []
    },
    "status": "blocked-pending-operational-review",
    "visibility": "public-source-review"
  },
  "originalQuestionsUnchanged": [
    {
      "decisionSelected": false,
      "exactSourceOrConflict": "All actual access is rank9/minimumclasslevel17/base26RP; Psychic Scream has three placements and Weird two, but actual routes do not grant every school.",
      "id": "RP9-Q01",
      "options": "A: preserve actual class-school routes with expressly selected shared or school-specific payloads. B: propose an access correction only with complete source evidence.",
      "recommendationAndConsequences": "Recommend A. Psychic Scream is Mage Evocation and Wizard Enchantment; its Illusion placement supplies history, not an acquired third route. Weird is actually Wizard Enchantment despite two placements. Phantom Armageddon alone includes Cleric/Druid/Wizard Necromancy. Others are Wizard-only. Keep actual repertoire, Action,V/S/F,price/cadence and Ready commitment; no generic upcast or multiple casts from multiple placements.",
      "spellIds": [
        "phantom-armageddon",
        "phantom-cataclysm",
        "psychic-scream",
        "frightful-sovereignty",
        "mass-phantom-killer",
        "weird",
        "reality-break"
      ]
    },
    {
      "decisionSelected": false,
      "exactSourceOrConflict": "Psychic,necrotic and force damage,illusion perception,fear,stun and compulsory movement are distinct components.",
      "id": "RP9-Q03",
      "options": "A: expressly extend applicable accepted damage/condition/root clauses per identity. B: identify a concrete contrary source and select a bounded exception.",
      "recommendationAndConsequences": "Keep each actual damage event and original owner/Null root. Damage immunity does not imply mental/fear/stun immunity; Charmed-only immunity is not universal mental immunity. Control admission is spent only for actual full-Action denial. Preserve real saves,temporaryHP,Wounds,death/concentration and effects independently. True Seeing recognises false images but has only its exact source-qualified removal permissions; do not give blanket dispelling or blindness-based mental immunity.",
      "spellIds": [
        "phantom-armageddon",
        "phantom-cataclysm",
        "psychic-scream",
        "frightful-sovereignty",
        "mass-phantom-killer",
        "weird",
        "reality-break"
      ]
    },
    {
      "decisionSelected": false,
      "exactSourceOrConflict": "Both placements trap creatures in NIGHTMARES within30-foot radius for4d10psychic PERROUND; actual Wizard route remains Enchantment.",
      "id": "RP9-Q17",
      "options": "A: a selected30-foot-radius sphere at a center within Core30feet with an initial fixed all-creature snapshot. B: a persistent area that admits later entrants under exact exposure/admission rules.",
      "recommendationAndConsequences": "Choose geometry and caster/allied exposure explicitly,without an enemy-only rewrite. Preserve both source placements and the actual single access route. Center perception/line of effect is distinct from individual area-recipient perception. A trapped subject may leave a physical area only according to the selected real state; nightmares are not automatically walls or a plane.",
      "spellIds": [
        "weird"
      ]
    },
    {
      "decisionSelected": false,
      "exactSourceOrConflict": "Trapped in nightmares has no complete control state; merely retaining damage would drop part of its source benefit.",
      "id": "RP9-Q18",
      "options": "A: actual magically caused Unconscious with independently defined nightmare damage/waking. B: a bounded private illusory captivity state with explicit movement/actions/senses. C: another concrete meaningful trapped state.",
      "recommendationAndConsequences": "Confer before choosing. A must resolve whether its own4d10 wakes the sleeper; do not borrow Eyebite waking so the spell defeats itself,or invent an exception silently. B must define real action denial,perceived routes,outside intervention and True Seeing without granting Mental Prison’s damage by analogy. Apply actual sleep/fear/mental immunities only to covered components and whole-Action allowance only when required.",
      "spellIds": [
        "weird"
      ]
    },
    {
      "decisionSelected": false,
      "exactSourceOrConflict": "Instantaneous cannot govern recurring4d10 and ongoing captivity; neither finite duration nor escape saves is native.",
      "id": "RP9-Q19",
      "options": "A: NEW concentration minute,initial WIS and regular END escape,with explicitly selected independent START damage. B: another fully specified finite positive lifecycle.",
      "recommendationAndConsequences": "Select damage/save/control ordering,maximum clock,one family exposure,overlap and actual source/recipient suppression. Define independent component endings,helping or damage-triggered escape if chosen. Preserve admitted state and real damage histories; no repeated entry/recognition/reflection creates extra pulses. At exact expiry end before a coincident pulse; no memory erasure or physical nightmare objects are implied.",
      "spellIds": [
        "weird"
      ]
    },
    {
      "decisionSelected": false,
      "exactSourceOrConflict": "No earlier complete operational examples exist for this group; source preservation does not prove selected semantics.",
      "id": "RP9-Q23",
      "options": "A: after decisions,write at least two complete source-qualified cases per identity plus every substantive school/state variant. B: explicitly hold only genuinely missing content-dependent branches.",
      "recommendationAndConsequences": "Require all native access/repertoire,actual owner/body/resources,source IDs,3D geometry,clocks,full RNG and intermediate/final states. Psychic Scream needs each actual school and positive head-consequence/stun cases with Null/survival branches; Weird needs real captivity; Sovereignty needs real fleeing; Reality Break needs its whole selected secondary effect sequence. Test immunity,hard-control,suppression,extra turns,source death and actual target changes without invented content. Keep source/semantic/arithmetic/engine/human/balance/cosmology/release gates separate.",
      "spellIds": [
        "phantom-armageddon",
        "phantom-cataclysm",
        "psychic-scream",
        "frightful-sovereignty",
        "mass-phantom-killer",
        "weird",
        "reality-break"
      ]
    },
    {
      "decisionSelected": false,
      "exactSourceOrConflict": "Native placements differ in substantive riders, while the current class routes select only their actual schools. A partial damage-only completion would lose head consequences, nightmare captivity or secondary effects.",
      "id": "PSY129-ADD01",
      "request": "Preserve all native placements and actually acquired routes. Provide a complete positive Enchantment head-consequence case and separate Evocation stun case for Psychic Scream, with explicit vital/headless/multihead/current-form data or named content holds. For Weird select and fully demonstrate real nightmare captivity, including whether its own psychic damage can wake, distinct sleep/mental/fear defenses and allied exposure. For Reality Break supply the complete selected secondary-effect table/sequence and every genuine branch rather than referring to an unspecified effect list.",
      "spellIds": [
        "psychic-scream",
        "weird",
        "reality-break"
      ]
    },
    {
      "decisionSelected": false,
      "exactSourceOrConflict": "Current Control15, illusion and body/life interfaces have scoped rules for denial, private perception, actual motion and retained state; historical accepted-but-unapplied labels are not current authority.",
      "id": "PSY129-ADD02",
      "request": "Resolve actual current index/status and exact procedures before adopting comparisons. Keep private perceived catastrophe separate from world/body state and each damage, fear, stun, flight and source clock separately admitted. Show a real spent hard-control allowance that blocks only covered new denial, actual independent damage, voluntary-budget flight with unknown or blocked safe route, and recurring effects through extra/attached phases and suppression without replay. Use genuine sources for every immunity or removal instead of a blanket mental-defense label.",
      "spellIds": [
        "phantom-armageddon",
        "phantom-cataclysm",
        "frightful-sovereignty",
        "mass-phantom-killer",
        "weird",
        "reality-break"
      ]
    }
  ],
  "qualifications": {
    "balanceApproved": false,
    "canonicalFilesChanged": false,
    "cosmologyApproved": false,
    "domainClosed": false,
    "humanPlaytested": false,
    "releaseApproved": false,
    "runtimeExecuted": false,
    "staticAuthoredReviewOnly": true,
    "suppliedOrHistoricalProgramsExecuted": false
  },
  "repair182Clarifications": {
    "authorship": "NEW spell-local clarifications only; accepted comparison sources remain within exact original scope",
    "budgetAccounting": "Action/BonusAction/Reaction fields are unspent source allowances, not automatic permission to act. Incapacity blocks eligibility without spending those allowances. Actual regular starts refresh and tick recharge even when incapacitated; death is separately marked inactive. Removing incapacity never refunds a spent allowance.",
    "damageDefenses": "Resolve exact paid defense components separately. Sanctify resistance/fear modes do not union. True Seeing recognizes false imagery without canceling separate damage/control. Mind Blank uses its exact accepted psychic/mental spell scope and willingness; no consent is invented for an unconscious target.",
    "heldRequiredCaseIds": [
      "RANK9PSYCHICFEAR7-180-WEIRD-B/genuine-extra-turn-source-hold"
    ],
    "repairCaseIds": [
      "RANK9PSYCHICFEAR7-180-WEIRD-B/actual-mind-blank-before-admission",
      "RANK9PSYCHICFEAR7-180-WEIRD-B/fear-immunity-does-not-prevent-magical-sleep",
      "RANK9PSYCHICFEAR7-180-WEIRD-B/hidden-body-captivity",
      "RANK9PSYCHICFEAR7-180-WEIRD-B/incapacitated-familiar-attached-phase",
      "RANK9PSYCHICFEAR7-180-WEIRD-B/sleep-fear-mental-defenses",
      "RANK9PSYCHICFEAR7-180-WEIRD-B/true-seeing-does-not-wake"
    ],
    "sourceQualification": "All new actor builds, conditional dice and geometry are explicit static witnesses. No actual campaign acquisition, creature anatomy, authoritative CR, hidden observer knowledge or runtime availability is created. Accepted comparison status may coexist with blocked catalog runtime selection; current authored index binding controls only its recorded authored scope.",
    "unprovedExtraTurn": "The procedure has no acquired genuine full-extra-turn example. The required positive extra-turn branch stays whole-case held and this identity remains unaccepted. Actual ordinary, attached, multiple-owner and suppression ledgers are not relabeled as full extra turns."
  },
  "sharedProcedure": {
    "commitment": "Action,V/S/F; ordinary range and identity checks precede commitment. Choose school variant and any Reality Break mode before paying. Cast spends once. Area membership is snapshotted at manifestation. Ready pays and resolves cast side effects at setup, holds concentration, expires next actual regular own START, and releases once with a legal Reaction after trigger; targeting occurs then. Effect clocks begin at manifestation; no second cast/cost/strain at release. Source component failure, countering, interruption, replacement or expiry refunds nothing already committed.",
    "control": "Before new Stunned or Unconscious admission, resolve survival, actual condition defenses and source-character/target encounter hard-denial allowance. Spend the combined mark once only upon successful new whole-Action denial. Used allowance blocks that new rider only; independent damage remains. No downgraded substitute control or repeated attempt after immunity/suppression. Existing admitted control may resume for its remaining original duration if a suppressor ends; no new costs, mark, duration or fresh side-effect such as another item drop. Full Stunned and Unconscious semantics apply, including ending concentration, no Actions/BonusAction/Reaction, movement prohibition, specified automatic saves and attack consequences. Frightened/flight/slow are not whole-Action denial.",
    "eligibility": "Before commitment bind actor identity, class level, acquired repertoire/prepared matrix, actual class-school row, component availability and focus custody, current life/body, Action eligibility, rank gate and RP. Rank9 minimum class17 and native base26 RP in every route. School placement alone gives no acquired route. Revalidate target/range/line of effect at manifestation. A paid legal cast whose targets later fail remains spent; an illegal precommit attempt spends nothing.",
    "geometryAndInformation": "NEW for these enemy-selective spells: designated enemies are creatures the caster currently perceives and regards as hostile; no objective allegiance oracle. Snapshot ALL qualifying designated enemies in the declared geometry without optional post-roll omissions. A mistaken hostile is affected. A concealed unknown enemy is not discovered. Allies/self are excluded unless perceived hostile designation actually applies; Weird instead snapshots every creature including self, allies and unperceived bodies in its area with source line of effect. Use actual occupied body geometry/full 3D, range and total-cover segments. Unknown scene/body/cover facts hold the affected admission, not invented coordinates.",
    "packet": "One independent damage roll per target per damage event, declared before outcomes, not one shared roll across targets. Binary saves use actual DC/modifiers and advantage/disadvantage, no generic natural1/20 save exception. Save half rounds down before defenses; resistance once, immunity separately, then tempHP, normalHP, instant death, Wound save/injury, zero-HP lifecycle, concentration and living riders in accepted order. No event silently selects Wound/injury/death dice. Hold at the next unavailable input. Surviving damage is never rolled back by rider resistance, awakening, illusion recognition, dispel, suppression, expiry or source death.",
    "phaseBridge": "For target-bound recurring records use actual regular target START damage and END saves. A source-supported companion without an independent regular turn uses its single attached controller-phase START/END once per controller regular turn; controller changes cannot add an exposure or move an existing expiry. Extra/attached actions confer no extra periodic marker. Outside initiative use initial packet then six-second START/END opportunity pairs (packet then save); transition maps each first unresolved opportunity to the next lawful marker without duplicating exposure. Actual grant, controller and phase must be bound; missing genuine extra-turn/companion evidence is held.",
    "qualifications": "No runtime execution, human play, balance judgment, cosmology decision, domain closure or release approval. No world-ending, new planes, summoned beings, memory extraction, hidden knowledge, creature anatomy, campaign immunity, acquisition or revival authorization follows from these names or authored fixtures.",
    "recurringFamily": "NEW explicit local extension of the P20 family/exposure interface for Mass Phantom Killer and Weird only: one packet per named family/recipient/actual numbered round, across owners and including an initial packet. Earliest active eligible application wins; ties use application order then immutable source ID. Mark the family opportunity before defense/HP resolution; losing due applications lose that opportunity. Suppressed sources lose their own due packet, cannot bank it, but do not consume another active source's opportunity. Independent ending WIS saves survive suppression. Family histories survive recasts/ownership copies. Mass Phantom Killer, Weird and Greater Phantasmal Killer are three distinct families.",
    "resources": "Use actual RP, Dissonance, Refrain, surcharges, class discounts and active passives. Base strain rank9=2; Wizard first distinct prepared underlying family=0 base only. Subsequent immediate same-name casts add capped Refrain1/2/3. No generic Overcast. First-cast exceptions never reset by copies, changing school, Ready release, suppression or new recipients. Keep resource history. No assumed reductions or kill-resource farm.",
    "roots": "Every cast has an immutable source owner, class/school, rank, component roots and target admissions. Child damage retains original root, funding, type and Null provenance; a Null-qualified hit preserves its actual recipient lifecycle restriction and cannot acquire a final-death/head-destruction side path. Damage, private perception, body consequence, fear, stun, sleep, voluntary flight and forced displacement are separate records. A source covering only one component affects only that component. No unsourced generic mental immunity or all-effects dispel.",
    "scope": "NEW PF181 spell-local authored selections for exactly the seven IDs. Native text/access is copied intact in each procedure. Proposed overrides of Instantaneous recurrence metadata and missing saves/durations are labeled; no global authority is asserted.",
    "termination": "Concentration ends on actual failure, incapacitation, death, voluntary ending or replacement unless an acquired specific exception applies. For non-concentration target conditions source death does not itself reset/erase their finite virtual endpoints. Target final death removes living conditions, not physical remains or ledger. Dispel ends only its eligible selected source root. Suppression blocks covered active components while clocks, mandatory saves and independently scheduled actors continue; no missed pulse, flight, forced displacement or head consequence replays on resumption. At an absolute maximum deadline expire before a coincident packet.",
    "timing": "Each actor owns its actual regular START/END calendar; spell damage opportunities are separately registered. At START expire due start effects and Ready, refresh Reaction and regular budgets, tick recharge, process legal absolute recovery and required death save before spell start effects and voluntary decisions. END resolves due damage/saves/maintenance then end expiry. Six-second virtual source/target markers preserve old durations across initiative change/removal; extra Actions/extra turns never create a regular marker, recharge tick or death save. A pulse is not an actor turn. Do not use one universal pulse rule."
  },
  "spellId": "weird",
  "status": "revised authored proposal; per-identity decision in DIRECTOR_DECISION.json"
}
```

