# Summon/Structure5 — complete standalone procedures, Return153

Input authority:713 applied-reviewed /135 pending /0 accepted-unapplied. Canonical files remain unchanged. Director decision is in DIRECTOR_DECISION.json. All source/content/access/physical/runtime holds remain. The exact JSON blocks below are the complete procedure records, including all native/access rows, new local choices and exact child spell comparisons. They are identical to the individual procedure files; no summaries replace their rules.

## summon-greater-water-pet

```json
{
  "id": "summon-greater-water-pet",
  "authorship": "NEW spell-local authored operational proposal",
  "nativeUnchanged": {
    "id": "summon-greater-water-pet",
    "name": "Summon Greater Water Pet",
    "schools": [
      "Conjuration"
    ],
    "status": "blocked-pending-operational-review",
    "visibility": "public-source-review",
    "classAccess": {
      "Druid": {
        "rank": 8,
        "minimumClassLevel": 15,
        "school": "Conjuration",
        "baseRpCost": 21
      },
      "Mage": {
        "rank": 8,
        "minimumClassLevel": 15,
        "school": "Conjuration",
        "baseRpCost": 21
      },
      "Wizard": {
        "rank": 8,
        "minimumClassLevel": 15,
        "school": "Conjuration",
        "baseRpCost": 21
      }
    },
    "operational": null,
    "additionalRpCost": 0,
    "source": {
      "catalogPath": "src/data/spells.js",
      "catalogSha256": "3358a2e1afcbc340dbafd92e45e39a7d2d0a24fed5c0719a3d233263ce530078",
      "catalogKey": "summon-greater-water-pet",
      "original": {
        "name": "Summon Greater Water Pet",
        "level": 8,
        "resonanceRank": 8,
        "school": "Conjuration",
        "schools": [
          "Conjuration"
        ],
        "placements": [
          {
            "name": "Summon Greater Water Pet",
            "school": "Conjuration",
            "level": 8,
            "summary": "HP 90, AC 16, healing wave (3d6 AoE heal) or 2d10 cold blast."
          }
        ],
        "classLevels": {
          "Druid": 8,
          "Mage": 8,
          "Wizard": 8
        },
        "classRanks": {
          "Druid": 8,
          "Mage": 8,
          "Wizard": 8
        },
        "classLearnLevels": {
          "Druid": 15,
          "Mage": 15,
          "Wizard": 15
        },
        "classSchools": {
          "Druid": "Conjuration",
          "Mage": "Conjuration",
          "Wizard": "Conjuration"
        },
        "castingTime": "Not specified in current rulebook",
        "range": "Not specified in current rulebook",
        "components": "Not specified in current rulebook",
        "duration": "Not specified in current rulebook",
        "description": "HP 90, AC 16, healing wave (3d6 AoE heal) or 2d10 cold blast.",
        "alternateSummaries": [],
        "classes": [
          "Druid",
          "Mage",
          "Wizard"
        ],
        "status": "canon",
        "source": "Player Rulebook — Spell Lists"
      },
      "corePath": "data/public/Decennium_Descent_Core_Systems_Data_v2_Known_Descent.json",
      "coreSha256": "50c3e9683349e93192191381ab6354ca7d675a24fcc9bb9b039c23e67fecca4f",
      "coreEntries": [
        {
          "index": 184,
          "original": {
            "school": "Conjuration",
            "level": 8,
            "name": "Summon Greater Water Pet",
            "effect": "HP 90, AC 16, healing wave (3d6 AoE heal) or 2d10 cold blast.",
            "source_paragraph": 9208,
            "casting_time": "1 action",
            "range": "120 feet",
            "duration": "Concentration, up to 1 minute",
            "components": "V, S, F",
            "resolution": "Automatic or opposed as described",
            "tags": [
              "Damage",
              "Healing",
              "Summoning"
            ],
            "rp_cost": 21
          }
        }
      ],
      "possibleHistoricalAliases": []
    },
    "reviewFlags": [
      "Core resolution requires an explicit operational interpretation",
      "Not selectable in this spell playtest packet until individual operational review"
    ]
  },
  "common": {
    "scope": "NEW authorship in this return applies only to the five listed identities. Preserve each complete native card/class-access envelope unchanged, including blocked source status and operational=null. Accepted comparisons remain closed at their exact recorded scopes; current backing bytes and historical525/323 headings do not expand them. This is data-only proposed static authorship, not a runtime, human-play, balance, cosmology, content-rating, release or domain-closure claim.",
    "casting": "Ordinary Action,120ft,V/S/F,rank8/base21RP, native class rank/level/school rows exactly. Require actual acquisition/book/preparation, available Action, components, perception, line of effect, lawful target and full occupied-volume fit. A focus must actually be accessible and S a free hand or an actual exception; V audible speech. No unprinted material price or generic Overcast. Known failure rejects before commitment; hidden later failure consumes a legally committed cast without replacement targets or revealing hidden facts. Range refers to the chosen origin; the whole created body/structure must also have actually known legal space and unobstructed formation, never intersect a creature or existing solid.",
    "payment": "Read Dissonance before casting. Limit=max(4,2+PB+max(0,casting modifier)); ranked costs gain+1/+2/+3 at limit/limit+3/limit+6; ordinary rank1+ blocked at limit+6 absent a real specific traumatic exception. Commit actual costs and Action once. Ordinary rank6–9 baseD2,rank1–5 baseD1,rank0 baseD0; successive same-family casts add Refrain1/2/3 capped3; different family resets to0, idle/weapon turns do not. Wizard first distinct prepared family in an encounter waives baseD only, not Refrain. Native pet actions, healing waves, weapon operation and maintenance are not new spell casts. New parent concentration ends old owner concentration at commitment before counter/outcome; no refund or restoration on failure. Shifting Fortress is expressly nonconcentration.",
    "checks": "Actual spell attacks d20+PB+actual casting modifier; source-specific modifiers only. Natural1 misses,natural20 hits and doubles dice only. Saves DC8+PB+modifier and actual save proficiency/conditions. Current passive defenses, cover and reaction scopes remain exact. Use real Counterspell/dispel acquisition, range, paid cost and check, not names or guessed ranks. Ordinary Wizard class Counterspell is automatic at2,rank1,cost3RP,recharge2,Reaction,60ft,INT+PB versus10+2*targetrank. Wizard class Dispel remains rank3/printed3RP/check10+targetrank; no conversion to acquired Greater Dispel.",
    "ready": "Accepted Ready exception: preparation spends actual Action/cost/components/strain once, starts held concentration and exposes the counter window then. Choose legal target/placement/form/operator list at release and revalidate before spending one Reaction. Invalid/declined occurrences may wait until next regular own-turn START; no refund. Release creates no second cast,cadence or counter window. Its effect duration starts at manifestation. A concentration parent continues the hold; otherwise the Ready hold ends after resolution. No structure can be placed through occupants to provide free boarding.",
    "clocks": "Use original regular START/END markers and stable phase/application sequence. Absolute expiry wins before new events at equality. Existing clocks keep virtual6second markers through initiative changes, extra turns, absence or death; do not multiply opportunities. Source-ending and damage-root callbacks finish under their actual causal order. Five-round Shifting Fortress has the explicit source-START convention below, not a substituted60seconds.",
    "geometryAndCustody": "Bodies have actual whole-body boxes/poses and mass, not point placeholders. Use actual sight versus location versus LoE; no ray through opaque solid solely because an origin is visible. Every real item retains unique ID,owner,custody,weight,Load,condition and charges. Intrinsic conjured gear/ammunition is not transferable stock. Real carried cargo settles at its actual location on ending, or records a real pending placement if no lawful support exists; no teleport to a former anchor. Unsupported real bodies/cargo use accepted Falling: start now; first descent at END of enclosing regular slot next round, or most recent completed slot if between turns, then6second steps up to300ft. Impact min(10,floor(uncontrolledDistance/20))d6,positive actual damage causes Prone. No invented crushing or free slow fall.",
    "ownership": "Store creator,parent source,current controller,actual acting body and damage/healing dealer separately. Companion damage belongs to the pet; actual structure weapon damage belongs to its firing operator, not building/creator. Root Null flag samples that actual dealer at creation; transfers inherit and later independent attacks create new roots. Objects still take ordinary object damage under Null. No corpse, XP,loot,RP,water,ingredient,harvest or class-proc farm follows from these creations. Actual independent source exceptions retain their own narrow scope.",
    "holds": "All absent actual faction/champion/profile, physical geometry/material/support, equipment/weapon proficiency, source access, healing/repair eligibility and topology facts remain whole-case or branch holds. New finite spell profiles and numbers below are explicitly authored specifications, not recovered bestiary/building content or positive campaign examples. A conditional fixture does not discharge its hold."
  },
  "companionRules": {
    "countAndDuration": "One body of this exact spell per original caster, across controllers; successful replacement ends the old same-spell body. All three creature parents require concentration and one absolute manifestation+60seconds deadline. Old parent concentration ends on new concentration commitment even if the replacement fails. Caster death/incapacity ends parent concentration by its actual source; ordinary0HP,expiry,voluntary creator concentration-ending/dismissal or actual removal ends the body with no corpse/loot. Lasting real cargo remains.",
    "command": "NEW explicitly extend the AC6 attached companion schedule and lower Water support accounting to these three bodies. One owner Bonus Action command during an actual regular turn,within60ft and with actual audible speech/perception/LoE, selects one body,finite route and one available Action. It executes once immediately after the entire owner turn, rechecking capability/range/target/LoE. Command expires at the END of that attached phase if impossible,suppressed,unaffordable or budget-starved; no banking,replay,retarget or refund. No autonomous spell/drain/heal/attack without command. All owner assets share one BA-command and one damaging/control/support Action allowance per numbered round; heal,child cast,channel maintenance,native drain and strike each consume that same allowance. Extra turns do not reset it. Creation gives no free Action, but an otherwise unspent creation-turn BA may command the actual attached phase. A command may instead buy Dash/Disengage/Search/defensive movement/Dodge; no automatic Help,grapple,shove,Opportunity Attack,Ready,item activation or extra Reaction.",
    "defaultAndAuthority": "Without a command, one source-attached defensive movement up to current Speed and Dodge at that regular opportunity, only while capable and actual space is legal; no offensive/support effect. Intrinsic physical gripping allows only genuinely possible ordinary pickup/drop with an actual available interaction in that phase, not extra work/proficiency/item activation. A source-qualified controller transfer cancels pending old orders, preserves original owner-wide spent ledgers and source clock, grants no fresh turn, and adopts only the exact new controller source schedule. Without such a source, no takeover is granted. Original source statistics retain their defined provenance.",
    "healingAndNull": "NEW named extension of AC4/AC5/AC6 mechanical living-ally HP eligibility to Greater Water Pet,Archlich Shade and Faction Paragon only, while their finite body exists. Ordinary healing must still actually target them and respect source exclusions,prohibitions,Critical/max limits and modifiers; no biology/soul/resurrection/disease/repair entitlement. Qualifying Null damage at0 leaves the same NullDisabled0 body: Incapacitated,Speed0,no commands/Actions/BA/Reaction,original deadline/concentration continue. Later qualifying Null hits do not recreate or kill it. Actual legal healing above0 restores the same body without clock/budget refresh. Ordinary non-Null0 ends the finite body; independent expiry/removal still ends NullDisabled.",
    "suppression": "NEW adopt AC5/AC6 same-body full-suppression for only these three profiles: operative whole-body suppression triggered by intersection of any actual occupied part preserves body,HP,position,real cargo,Null state and original deadlines. Speed0,no actions,commands,senses supplied by the spell or intrinsic gear function; no pulses. Clocks and gravity continue, so unsupported actual body Falls. Leaving suppression resumes surviving permissions only, never missed commands or healing. Narrow rider-only suppression affects only its named component. Shade child concentration has its separate stricter ending rule below. No Knight disappearance or Soul Wraith ending rule is silently imported."
  },
  "rules": {
    "body": {
      "authorship": "NEW complete finite spell-local profile, not a creature roster/CR claim",
      "size": "Medium",
      "spaceFeet": [
        5,
        5,
        6
      ],
      "massLb": 150,
      "mechanicalType": "Elemental",
      "baseHP": 90,
      "baseAC": 16,
      "scores": {
        "STR": 10,
        "DEX": 10,
        "CON": 10,
        "INT": 10,
        "WIS": 10,
        "CHA": 10
      },
      "walkFeet": 30,
      "swimFeet": 40,
      "flyFeet": 0,
      "hover": false,
      "hands": 2,
      "speech": "understands creator spoken commands; only Shade articulates its own bounded spell components, no private memories or general negotiation",
      "senses": [
        "ordinary sight",
        "ordinary hearing"
      ],
      "saves": "all six save totals = original creating owner currentPB, unless Shade snapshot explicitly overrides",
      "checks": "listed raw ability modifier; no ungranted proficiency",
      "resistances": [],
      "immunities": [],
      "needs": "NEW ordinary air-breathing exposure; no water breathing/amphibious/no-air/no-food/no-sleep privilege. Actual environment/long-term physiology outside this minute remains held.",
      "carry": "BODY actual STR and size capacities; Medium pounds15*STR,LoadSTR; positiveLoad>=half capacity is Burdened. No passenger/mount entitlement; actual compatible custody and anatomy required.",
      "maxHP": "Actual source-qualified creation/current maximum modifiers apply once; capacity rise does not heal, decrease clamps only. No generic owner-level scaling unless the actual class/source grants it.",
      "intrinsicGear": "nontransferable source parts only; cannot be looted, sold, harvested, consumed as equipment or duplicated"
    },
    "creation": "Create one currently perceived fitting unoccupied supported Medium body within120ft/LoE. Two defined gripping extremities do not grant a mount/harness/passenger or tool proficiency. Swim40 is NEW locomotion, not water breathing,fluid squeezing,resistance,free water or an ingredient. Actual supported water placement requires real water volume/buoyancy/support rules; missing facts hold that branch.",
    "wave": "NEW commanded Action: roll exactly one shared3d6 ordinary healing pool, no modifier. Center a10ft-radius sphere at the pet actual body-center origin; snapshot every distinct willing actual eligible ally with a body-interior intersection and a legal LoE witness from that origin. All such recipients, including the pet itself if capable, receive the same base roll once; no recipient ceiling beyond actual finite occupants/geometry. Tangency to an exterior boundary alone is not body-interior intersection. Source-specific healing modifiers,caps,prohibitions and genuine excess are resolved independently; do not pool unused healing,copy it,convert it to resources or add owner Cleric/Radiance hooks. The pet owns this heal, even if the owner is an eligible recipient. Living0/Downed and these named NullDisabled pets are eligible only through the actual healing rules. Ended bodies/dead people/ordinary objects are not restored.",
    "blast": "NEW alternative commanded Action: one ranged spell-attack-type roll from the pet actual body against one perceived physical creature or object within60ft/LoE; original creating-class current spell attack. Hit2d10cold,no modifier; genuine critical4d10. Actual object/material/creature defenses apply. This is a native pet Action, not a new spell or owner cast; range/cover measured from pet,actual dealer pet. No owner Veil or cast/heal/kill hook is inherited.",
    "limits": "Wave OR blast spends the same one shared owner offensive/support allowance. No both-in-one command, free creation pulse, independent repeated heal every tick or outside-combat bypass. Outside initiative use actual6second source opportunities plus real BA command, with the unchanged60second deadline. Self healing consumes the same allowance and cannot be selected while disabled/suppressed. No reserve or per-recipient recharge is created."
  },
  "questionIds": [
    "SS8-Q01",
    "SS8-W01",
    "SS8-W02",
    "SS8-W03",
    "SS8-X01",
    "SS8-X02"
  ]
}
```

## summon-archlich-shade

```json
{
  "id": "summon-archlich-shade",
  "authorship": "NEW spell-local authored operational proposal",
  "nativeUnchanged": {
    "id": "summon-archlich-shade",
    "name": "Summon Archlich Shade",
    "schools": [
      "Necromancy"
    ],
    "status": "blocked-pending-operational-review",
    "visibility": "public-source-review",
    "classAccess": {
      "Cleric": {
        "rank": 8,
        "minimumClassLevel": 15,
        "school": "Necromancy",
        "baseRpCost": 21
      },
      "Druid": {
        "rank": 8,
        "minimumClassLevel": 15,
        "school": "Necromancy",
        "baseRpCost": 21
      },
      "Wizard": {
        "rank": 8,
        "minimumClassLevel": 15,
        "school": "Necromancy",
        "baseRpCost": 21
      }
    },
    "operational": null,
    "additionalRpCost": 0,
    "source": {
      "catalogPath": "src/data/spells.js",
      "catalogSha256": "3358a2e1afcbc340dbafd92e45e39a7d2d0a24fed5c0719a3d233263ce530078",
      "catalogKey": "summon-archlich-shade",
      "original": {
        "name": "Summon Archlich Shade",
        "level": 8,
        "resonanceRank": 8,
        "school": "Necromancy",
        "schools": [
          "Necromancy"
        ],
        "placements": [
          {
            "name": "Summon Archlich Shade",
            "school": "Necromancy",
            "level": 8,
            "summary": "HP 160, casts necrotic spells, drains enemies."
          }
        ],
        "classLevels": {
          "Cleric": 8,
          "Druid": 8,
          "Wizard": 8
        },
        "classRanks": {
          "Cleric": 8,
          "Druid": 8,
          "Wizard": 8
        },
        "classLearnLevels": {
          "Cleric": 15,
          "Druid": 15,
          "Wizard": 15
        },
        "classSchools": {
          "Cleric": "Necromancy",
          "Druid": "Necromancy",
          "Wizard": "Necromancy"
        },
        "castingTime": "Not specified in current rulebook",
        "range": "Not specified in current rulebook",
        "components": "Not specified in current rulebook",
        "duration": "Not specified in current rulebook",
        "description": "HP 160, casts necrotic spells, drains enemies.",
        "alternateSummaries": [],
        "classes": [
          "Cleric",
          "Druid",
          "Wizard"
        ],
        "status": "canon",
        "source": "Player Rulebook — Spell Lists"
      },
      "corePath": "data/public/Decennium_Descent_Core_Systems_Data_v2_Known_Descent.json",
      "coreSha256": "50c3e9683349e93192191381ab6354ca7d675a24fcc9bb9b039c23e67fecca4f",
      "coreEntries": [
        {
          "index": 704,
          "original": {
            "school": "Necromancy",
            "level": 8,
            "name": "Summon Archlich Shade",
            "effect": "HP 160, casts necrotic spells, drains enemies.",
            "source_paragraph": 9853,
            "casting_time": "1 action",
            "range": "120 feet",
            "duration": "Concentration, up to 1 minute",
            "components": "V, S, F",
            "resolution": "Automatic or opposed as described",
            "tags": [
              "Summoning"
            ],
            "rp_cost": 21
          }
        }
      ],
      "possibleHistoricalAliases": []
    },
    "reviewFlags": [
      "Core resolution requires an explicit operational interpretation",
      "Not selectable in this spell playtest packet until individual operational review"
    ]
  },
  "common": {
    "scope": "NEW authorship in this return applies only to the five listed identities. Preserve each complete native card/class-access envelope unchanged, including blocked source status and operational=null. Accepted comparisons remain closed at their exact recorded scopes; current backing bytes and historical525/323 headings do not expand them. This is data-only proposed static authorship, not a runtime, human-play, balance, cosmology, content-rating, release or domain-closure claim.",
    "casting": "Ordinary Action,120ft,V/S/F,rank8/base21RP, native class rank/level/school rows exactly. Require actual acquisition/book/preparation, available Action, components, perception, line of effect, lawful target and full occupied-volume fit. A focus must actually be accessible and S a free hand or an actual exception; V audible speech. No unprinted material price or generic Overcast. Known failure rejects before commitment; hidden later failure consumes a legally committed cast without replacement targets or revealing hidden facts. Range refers to the chosen origin; the whole created body/structure must also have actually known legal space and unobstructed formation, never intersect a creature or existing solid.",
    "payment": "Read Dissonance before casting. Limit=max(4,2+PB+max(0,casting modifier)); ranked costs gain+1/+2/+3 at limit/limit+3/limit+6; ordinary rank1+ blocked at limit+6 absent a real specific traumatic exception. Commit actual costs and Action once. Ordinary rank6–9 baseD2,rank1–5 baseD1,rank0 baseD0; successive same-family casts add Refrain1/2/3 capped3; different family resets to0, idle/weapon turns do not. Wizard first distinct prepared family in an encounter waives baseD only, not Refrain. Native pet actions, healing waves, weapon operation and maintenance are not new spell casts. New parent concentration ends old owner concentration at commitment before counter/outcome; no refund or restoration on failure. Shifting Fortress is expressly nonconcentration.",
    "checks": "Actual spell attacks d20+PB+actual casting modifier; source-specific modifiers only. Natural1 misses,natural20 hits and doubles dice only. Saves DC8+PB+modifier and actual save proficiency/conditions. Current passive defenses, cover and reaction scopes remain exact. Use real Counterspell/dispel acquisition, range, paid cost and check, not names or guessed ranks. Ordinary Wizard class Counterspell is automatic at2,rank1,cost3RP,recharge2,Reaction,60ft,INT+PB versus10+2*targetrank. Wizard class Dispel remains rank3/printed3RP/check10+targetrank; no conversion to acquired Greater Dispel.",
    "ready": "Accepted Ready exception: preparation spends actual Action/cost/components/strain once, starts held concentration and exposes the counter window then. Choose legal target/placement/form/operator list at release and revalidate before spending one Reaction. Invalid/declined occurrences may wait until next regular own-turn START; no refund. Release creates no second cast,cadence or counter window. Its effect duration starts at manifestation. A concentration parent continues the hold; otherwise the Ready hold ends after resolution. No structure can be placed through occupants to provide free boarding.",
    "clocks": "Use original regular START/END markers and stable phase/application sequence. Absolute expiry wins before new events at equality. Existing clocks keep virtual6second markers through initiative changes, extra turns, absence or death; do not multiply opportunities. Source-ending and damage-root callbacks finish under their actual causal order. Five-round Shifting Fortress has the explicit source-START convention below, not a substituted60seconds.",
    "geometryAndCustody": "Bodies have actual whole-body boxes/poses and mass, not point placeholders. Use actual sight versus location versus LoE; no ray through opaque solid solely because an origin is visible. Every real item retains unique ID,owner,custody,weight,Load,condition and charges. Intrinsic conjured gear/ammunition is not transferable stock. Real carried cargo settles at its actual location on ending, or records a real pending placement if no lawful support exists; no teleport to a former anchor. Unsupported real bodies/cargo use accepted Falling: start now; first descent at END of enclosing regular slot next round, or most recent completed slot if between turns, then6second steps up to300ft. Impact min(10,floor(uncontrolledDistance/20))d6,positive actual damage causes Prone. No invented crushing or free slow fall.",
    "ownership": "Store creator,parent source,current controller,actual acting body and damage/healing dealer separately. Companion damage belongs to the pet; actual structure weapon damage belongs to its firing operator, not building/creator. Root Null flag samples that actual dealer at creation; transfers inherit and later independent attacks create new roots. Objects still take ordinary object damage under Null. No corpse, XP,loot,RP,water,ingredient,harvest or class-proc farm follows from these creations. Actual independent source exceptions retain their own narrow scope.",
    "holds": "All absent actual faction/champion/profile, physical geometry/material/support, equipment/weapon proficiency, source access, healing/repair eligibility and topology facts remain whole-case or branch holds. New finite spell profiles and numbers below are explicitly authored specifications, not recovered bestiary/building content or positive campaign examples. A conditional fixture does not discharge its hold."
  },
  "companionRules": {
    "countAndDuration": "One body of this exact spell per original caster, across controllers; successful replacement ends the old same-spell body. All three creature parents require concentration and one absolute manifestation+60seconds deadline. Old parent concentration ends on new concentration commitment even if the replacement fails. Caster death/incapacity ends parent concentration by its actual source; ordinary0HP,expiry,voluntary creator concentration-ending/dismissal or actual removal ends the body with no corpse/loot. Lasting real cargo remains.",
    "command": "NEW explicitly extend the AC6 attached companion schedule and lower Water support accounting to these three bodies. One owner Bonus Action command during an actual regular turn,within60ft and with actual audible speech/perception/LoE, selects one body,finite route and one available Action. It executes once immediately after the entire owner turn, rechecking capability/range/target/LoE. Command expires at the END of that attached phase if impossible,suppressed,unaffordable or budget-starved; no banking,replay,retarget or refund. No autonomous spell/drain/heal/attack without command. All owner assets share one BA-command and one damaging/control/support Action allowance per numbered round; heal,child cast,channel maintenance,native drain and strike each consume that same allowance. Extra turns do not reset it. Creation gives no free Action, but an otherwise unspent creation-turn BA may command the actual attached phase. A command may instead buy Dash/Disengage/Search/defensive movement/Dodge; no automatic Help,grapple,shove,Opportunity Attack,Ready,item activation or extra Reaction.",
    "defaultAndAuthority": "Without a command, one source-attached defensive movement up to current Speed and Dodge at that regular opportunity, only while capable and actual space is legal; no offensive/support effect. Intrinsic physical gripping allows only genuinely possible ordinary pickup/drop with an actual available interaction in that phase, not extra work/proficiency/item activation. A source-qualified controller transfer cancels pending old orders, preserves original owner-wide spent ledgers and source clock, grants no fresh turn, and adopts only the exact new controller source schedule. Without such a source, no takeover is granted. Original source statistics retain their defined provenance.",
    "healingAndNull": "NEW named extension of AC4/AC5/AC6 mechanical living-ally HP eligibility to Greater Water Pet,Archlich Shade and Faction Paragon only, while their finite body exists. Ordinary healing must still actually target them and respect source exclusions,prohibitions,Critical/max limits and modifiers; no biology/soul/resurrection/disease/repair entitlement. Qualifying Null damage at0 leaves the same NullDisabled0 body: Incapacitated,Speed0,no commands/Actions/BA/Reaction,original deadline/concentration continue. Later qualifying Null hits do not recreate or kill it. Actual legal healing above0 restores the same body without clock/budget refresh. Ordinary non-Null0 ends the finite body; independent expiry/removal still ends NullDisabled.",
    "suppression": "NEW adopt AC5/AC6 same-body full-suppression for only these three profiles: operative whole-body suppression triggered by intersection of any actual occupied part preserves body,HP,position,real cargo,Null state and original deadlines. Speed0,no actions,commands,senses supplied by the spell or intrinsic gear function; no pulses. Clocks and gravity continue, so unsupported actual body Falls. Leaving suppression resumes surviving permissions only, never missed commands or healing. Narrow rider-only suppression affects only its named component. Shade child concentration has its separate stricter ending rule below. No Knight disappearance or Soul Wraith ending rule is silently imported."
  },
  "rules": {
    "body": {
      "authorship": "NEW complete finite spell-local profile, not a creature roster/CR claim",
      "size": "Medium",
      "spaceFeet": [
        5,
        5,
        6
      ],
      "massLb": 120,
      "mechanicalType": "Undead",
      "baseHP": 160,
      "baseAC": 15,
      "scores": {
        "STR": 10,
        "DEX": 14,
        "CON": 14,
        "INT": "snapshot creating-class casting score",
        "WIS": 12,
        "CHA": 10
      },
      "walkFeet": 30,
      "swimFeet": 0,
      "flyFeet": 0,
      "hover": false,
      "hands": 2,
      "speech": "audible spoken V components and command acknowledgement only; no lich memories,secrets or independent spellbook",
      "senses": [
        "ordinary sight",
        "ordinary hearing",
        "Darkvision60feet"
      ],
      "saves": "all six save totals = snapshot creatorPB; concentration therefore uses this own CON-save total, not a new owner check.",
      "checks": "listed raw ability modifier; no ungranted proficiency",
      "resistances": [],
      "immunities": [],
      "needs": "NEW ordinary air-breathing exposure; no water breathing/amphibious/no-air/no-food/no-sleep privilege. Actual environment/long-term physiology outside this minute remains held.",
      "carry": "BODY actual STR and size capacities; Medium pounds15*STR,LoadSTR; positiveLoad>=half capacity is Burdened. No passenger/mount entitlement; actual compatible custody and anatomy required.",
      "maxHP": "Actual source-qualified creation/current maximum modifiers apply once; capacity rise does not heal, decrease clamps only. No generic owner-level scaling unless the actual class/source grants it.",
      "intrinsicGear": "nontransferable source parts only; cannot be looted, sold, harvested, consumed as equipment or duplicated",
      "casting": "NEW own INT-based casting using creation snapshot of creator casting ability score and PB; shade INT is that score,spellattack=PB+INTmod,DC8+PB+INTmod,M=max(1,INTmod). No copied class features.",
      "componentAnatomy": "two actual hands,one free for S,other can hold one intrinsic nontransferable focus that is NEW a valid F for this repertoire only; ordinary audible speech required. Bound hands,silence,missing outlet,incapacity or suppression really prevent casting."
    },
    "identity": "Create one bounded physical Medium manifestation at actual fitting supported120ft/LoE space. Appearance is shade-like, but it is corporeal: no hover,flight,incorporeal traversal,phylactery,actual dead lich,private identity,soul ownership,legendary actions,CR or elite-asset permission. Original source160baseHP is not an owner HP bank.",
    "repertoire": "NEW grant this finite shade only three actual reviewed spell activations: Chill Touch rank0/base0RP, Vampiric Touch rank3/base5RP, Enervation rank5/base10RP. Their full native records and complete accepted procedures/shared rules are embedded below unchanged. This is explicit spell-local acquisition for the shade, not a claim that the owner knows/prepares them or has another class. For Chill Touch preserve the creating-class source placement: Wizard Evocation, Cleric/Druid Necromancy; all deal native necrotic damage. No menu substitution,more spells,scroll casting,metamagic,Overcast,spellbook,scribing,owner discounts or owner class matrices are granted.",
    "fundingAndCadence": "Each child spell is genuinely cast by the shade at its attached commanded Action. Before committing, require actual component anatomy,target,rank,shade Dissonance legality and owner available RP. Pay the original owner pool the full child base plus shade strain surcharge and any actual child-source extras, never an owner discount/surcharge/metamagic; owner must still exist with that actually spendable pool. No personal shade RP pool or credit. Shade owns Dissonance/Refrain/lastFamily with ordinary base0/1/1,limit=max(4,2+snapshotPB+max(0,shadeINTmod)); no Wizard first-family exemption, class proc or Arcane Feedback. Failed/countered paid child keeps command/offense,cost and strain; a known unfundable attempt creates no cast and its issued command expires in that phase. Owner has no second cast/cadence/hit/heal/kill event. Recasting a genuinely new shade costs the full parent21RP and ends old parent/child; it creates a finite new shade cadence record only, never refunds ownerRP,used owner round allowance,world assets or existing persistent riders.",
    "childConcentration": "Owner owns parent concentration; shade separately owns at most one child concentration. Casting Enervation starts shade concentration at child commitment, ending an old child before counters/outcome, never owner parent. Vampiric Touch is the exact instantaneous3d6 touch spell, not an invented concentration repeat attack. Chill Touch is actual Touch,not a ranged imported card. Enervation is actual60ft ranged4d8 pulse,60second channel,max10pulses; follow-up maintenance consumes a later real BA command plus the shade single attached Action and shared offense allowance, but no new RP/cast/Refrain. No spare owner Action or extra turn buys pulses. Own regular virtual cycle is original owner attached opportunity; if a future cycle receives no legal maintenance, end at its attached END. Loss of actual target continuity/range/perception/LoE,shade Incapacitated,death/ending,or full suppression ends channel immediately under its native source. Damage to shade tests its own child concentration with CONsave versus max(10,floor(damage/2)); damage to owner tests parent only. Parent ending removes shade and ends child before any later checkpoint. No orphaned beam/missed pulse replay.",
    "spellOwnership": "Shade is actual caster/dealer/heal recipient. Each actual Enervation initial/maintenance attack creates a NEW damage root sampling the shade then-current Veil; subsequent pulses do not inherit an earlier attack root. The owner Veil is irrelevant. Genuine damage transfers preserve that root; healing sums only allowed terminal branches once,including actual tempHP absorbed where native Vampiric Touch/Enervation permit it,excluding overkill,no-derived-heal/no-recovery branches and duplicates. Do not graft the narrower native Drain filter onto these spells. Full damage/life/source-ending consequences precede healing; ended shade is not recreated. Child spell-specific independent timed riders, notably Chill Touch, keep their own endpoint after parent ending unless their own source requires caster persistence; this is not orphaned concentration or a stored pulse. No shade Reaction,Counterspell,Ready,spell copy or owner personal hook is granted.",
    "drain": "NEW alternative native commanded melee Action against one actual enemy creature within5ft/legal reach/perception/LoE: use shade snapshot spellattack; hit2d8necrotic,no modifier,crit4d8. Actual hostility is ordinary scene knowledge, not faction truth detection. After damage and source-ending callbacks, if the same shade remains, heal it floor(eligible actual normalHP lost/2) once under real ordinary healing rules. TemporaryHP loss,overkill,prevented loss and no-recovery/no-derived-healing branches contribute0. Exclude friendly willing batteries,temporary summons/copies/resource-prohibited creations and consumed animated stock from funding; their actual damage eligibility remains separate. No owner healing,RP,maxHP theft or imported class Life Drain. A miss/zero eligible loss/blocked heal creates no reserve or refund. This explicit native drain differs from the unchanged child spells.",
    "exactSpellComparisonsUnchanged": {
      "vampiric-touch": {
        "spellId": "vampiric-touch",
        "source": {
          "path": "DescentReviewChanges/ReviewBible/data/public/spell_playtests/catalog.json",
          "bytes": 4945319,
          "sha256": "f52cf6a4a4673897615a74c7c67dcba798c431362d4357e71ee552cc7c5d31f8"
        },
        "pointer": "/spells/630",
        "completeCurrentCard": {
          "id": "vampiric-touch",
          "name": "Vampiric Touch",
          "schools": [
            "Necromancy"
          ],
          "status": "operational-playtest-draft",
          "visibility": "public-source-review",
          "classAccess": {
            "Cleric": {
              "rank": 3,
              "minimumClassLevel": 5,
              "school": "Necromancy",
              "baseRpCost": 5
            },
            "Crimson Agent": {
              "rank": 3,
              "minimumClassLevel": 8,
              "school": "Necromancy",
              "baseRpCost": 5
            },
            "Druid": {
              "rank": 3,
              "minimumClassLevel": 5,
              "school": "Necromancy",
              "baseRpCost": 5
            },
            "Shaman": {
              "rank": 3,
              "minimumClassLevel": 7,
              "school": "Necromancy",
              "baseRpCost": 5
            },
            "Thief": {
              "rank": 3,
              "minimumClassLevel": 13,
              "school": "Necromancy",
              "baseRpCost": 5
            },
            "Wizard": {
              "rank": 3,
              "minimumClassLevel": 5,
              "school": "Necromancy",
              "baseRpCost": 5
            }
          },
          "operational": {
            "id": "vampiric-touch",
            "name": "Vampiric Touch",
            "school": "Necromancy",
            "rank": 3,
            "identityType": "existing-catalog",
            "activation": "Action",
            "rangeFeet": 0,
            "targets": "One creature in actual touch reach; no creature-type exclusion is added.",
            "duration": "Instantaneous.",
            "concentration": false,
            "components": [
              "V",
              "S",
              "F"
            ],
            "resolution": "One melee spell attack against AC: hit 3d6 necrotic; miss no damage or healing.",
            "effect": "After damage resolves, heal yourself floor(actualDamageDealt / 2), once from that attack packet. Use eligible final recipient branches under damage sharing without counting the unsplit parent or overkill. Ordinary healing modifiers, prohibitions and caps apply; actual target defenses determine damage, including for Undead/Constructs. The healing is one secondary result and cannot reproduce this attack or create a second Vampiric Touch heal for the same cast. It grants no continuing repeat-attack permission or concentration. Unrelated eligible triggers retain their own restrictions.",
            "scaling": "None.",
            "limitations": "No automatic level scaling, generic upcast or new action budget. Use the actual casting source's access, components, costs, shared concentration and Dissonance/Refrain, then the legal interruption window. Countering or later failure refunds no committed use/payment or displaced concentration. Spell attacks use d20 + PB + actual source casting modifier; saves use DC 8 + PB + that modifier. Actual defenses, critical rules, core conditions, ordinary life-state rules and source-specific callbacks retain their scopes. Total cover prevents targeting unless this card expressly allows otherwise. For ancestry casts use ANCESTRY_BACKGROUND_PLAYTEST.md; existing ordinary identities retain their actual class/school/rank access and RP price.",
            "designNotes": "PRESERVED existing catalog/Core identity, source placement, action, range and components. Explicit operational additions are conference decisions.",
            "sourceCoreEntries": [
              {
                "index": 669,
                "original": {
                  "school": "Necromancy",
                  "level": 3,
                  "name": "Vampiric Touch",
                  "effect": "3d6 necrotic damage, heal for half the damage dealt.",
                  "source_paragraph": 9808,
                  "casting_time": "1 action",
                  "range": "Touch",
                  "duration": "Instantaneous",
                  "components": "V, S, F",
                  "resolution": "Automatic or opposed as described",
                  "tags": [
                    "Damage",
                    "Healing"
                  ],
                  "rp_cost": 5
                }
              }
            ],
            "ordinaryClassAccess": {
              "Cleric": {
                "rank": 3,
                "minimumClassLevel": 5,
                "school": "Necromancy",
                "baseRpCost": 5
              },
              "Crimson Agent": {
                "rank": 3,
                "minimumClassLevel": 8,
                "school": "Necromancy",
                "baseRpCost": 5
              },
              "Druid": {
                "rank": 3,
                "minimumClassLevel": 5,
                "school": "Necromancy",
                "baseRpCost": 5
              },
              "Shaman": {
                "rank": 3,
                "minimumClassLevel": 7,
                "school": "Necromancy",
                "baseRpCost": 5
              },
              "Thief": {
                "rank": 3,
                "minimumClassLevel": 13,
                "school": "Necromancy",
                "baseRpCost": 5
              },
              "Wizard": {
                "rank": 3,
                "minimumClassLevel": 5,
                "school": "Necromancy",
                "baseRpCost": 5
              }
            },
            "reviewStatus": "REVIEWED authored operational PLAYTEST manuscript; four exact-review repairs applied; runtime and human balance pending",
            "implementationStatus": "REVIEWED authored operational PLAYTEST manuscript; four exact-review repairs applied; runtime and human balance pending",
            "authoringFile": "data/playtest/spell_drafts/batch_ancestry_dependencies.json"
          },
          "additionalRpCost": 0,
          "source": {
            "catalogPath": "src/data/spells.js",
            "catalogSha256": "3358a2e1afcbc340dbafd92e45e39a7d2d0a24fed5c0719a3d233263ce530078",
            "catalogKey": "vampiric-touch",
            "original": {
              "name": "Vampiric Touch",
              "level": 3,
              "resonanceRank": 3,
              "school": "Necromancy",
              "schools": [
                "Necromancy"
              ],
              "placements": [
                {
                  "name": "Vampiric Touch",
                  "school": "Necromancy",
                  "level": 3,
                  "summary": "3d6 necrotic damage, heal for half the damage dealt."
                }
              ],
              "classLevels": {
                "Cleric": 3,
                "Crimson Agent": 3,
                "Druid": 3,
                "Shaman": 3,
                "Thief": 3,
                "Wizard": 3
              },
              "classRanks": {
                "Cleric": 3,
                "Crimson Agent": 3,
                "Druid": 3,
                "Shaman": 3,
                "Thief": 3,
                "Wizard": 3
              },
              "classLearnLevels": {
                "Cleric": 5,
                "Crimson Agent": 8,
                "Druid": 5,
                "Shaman": 7,
                "Thief": 13,
                "Wizard": 5
              },
              "classSchools": {
                "Cleric": "Necromancy",
                "Crimson Agent": "Necromancy",
                "Druid": "Necromancy",
                "Shaman": "Necromancy",
                "Thief": "Necromancy",
                "Wizard": "Necromancy"
              },
              "castingTime": "Not specified in current rulebook",
              "range": "Not specified in current rulebook",
              "components": "Not specified in current rulebook",
              "duration": "Not specified in current rulebook",
              "description": "3d6 necrotic damage, heal for half the damage dealt.",
              "alternateSummaries": [],
              "classes": [
                "Cleric",
                "Crimson Agent",
                "Druid",
                "Shaman",
                "Thief",
                "Wizard"
              ],
              "status": "canon",
              "source": "Player Rulebook — Spell Lists"
            },
            "corePath": "data/public/Decennium_Descent_Core_Systems_Data_v2_Known_Descent.json",
            "coreSha256": "50c3e9683349e93192191381ab6354ca7d675a24fcc9bb9b039c23e67fecca4f",
            "coreEntries": [
              {
                "index": 669,
                "original": {
                  "school": "Necromancy",
                  "level": 3,
                  "name": "Vampiric Touch",
                  "effect": "3d6 necrotic damage, heal for half the damage dealt.",
                  "source_paragraph": 9808,
                  "casting_time": "1 action",
                  "range": "Touch",
                  "duration": "Instantaneous",
                  "components": "V, S, F",
                  "resolution": "Automatic or opposed as described",
                  "tags": [
                    "Damage",
                    "Healing"
                  ],
                  "rp_cost": 5
                }
              }
            ],
            "possibleHistoricalAliases": []
          },
          "reviewFlags": [
            "Core resolution requires an explicit operational interpretation"
          ]
        },
        "completeSharedRules": {},
        "indexEntry": {
          "id": "vampiric-touch",
          "name": "Vampiric Touch",
          "authoredStatus": "reviewed-authored-operational-playtest",
          "procedureFile": "catalog.json",
          "procedurePointer": "/spells/630/operational",
          "wholeCardPointer": "/spells/630",
          "sourceStatus": "operational-playtest-draft",
          "priorCatalogSelectionStatusUnchanged": true
        },
        "qualification": "Complete actual reviewed source-specific procedure, not automatic adoption for any of these five."
      },
      "chill-touch": {
        "spellId": "chill-touch",
        "source": {
          "path": "DescentReviewChanges/ReviewBible/data/public/spell_playtests/catalog.json",
          "bytes": 4945319,
          "sha256": "f52cf6a4a4673897615a74c7c67dcba798c431362d4357e71ee552cc7c5d31f8"
        },
        "pointer": "/spells/415",
        "completeCurrentCard": {
          "id": "chill-touch",
          "name": "Chill Touch",
          "schools": [
            "Evocation",
            "Necromancy"
          ],
          "status": "operational-playtest-draft",
          "visibility": "public-source-review",
          "classAccess": {
            "Cleric": {
              "rank": 0,
              "minimumClassLevel": 1,
              "school": "Necromancy",
              "baseRpCost": 0
            },
            "Crimson Agent": {
              "rank": 0,
              "minimumClassLevel": 1,
              "school": "Evocation",
              "baseRpCost": 0
            },
            "Dragoon": {
              "rank": 0,
              "minimumClassLevel": 3,
              "school": "Evocation",
              "baseRpCost": 0
            },
            "Druid": {
              "rank": 0,
              "minimumClassLevel": 1,
              "school": "Necromancy",
              "baseRpCost": 0
            },
            "Mage": {
              "rank": 0,
              "minimumClassLevel": 1,
              "school": "Evocation",
              "baseRpCost": 0
            },
            "Shaman": {
              "rank": 0,
              "minimumClassLevel": 1,
              "school": "Necromancy",
              "baseRpCost": 0
            },
            "Thief": {
              "rank": 0,
              "minimumClassLevel": 1,
              "school": "Necromancy",
              "baseRpCost": 0
            },
            "Wizard": {
              "rank": 0,
              "minimumClassLevel": 1,
              "school": "Evocation",
              "baseRpCost": 0
            }
          },
          "operational": {
            "id": "chill-touch",
            "activation": "Action",
            "rangeFeet": 5,
            "targets": "One creature you perceive and can physically touch within your actual legal reach, with line of effect. The 5-foot reference describes ordinary Touch reach; no extended reach is granted. Use the actual Evocation or Necromancy placement available to the chosen class; access is not unioned.",
            "duration": "Instantaneous damage; one target-round broad current-HP-gain prohibition, no concentration. The rider ends at the target’s first future regular-turn END, excluding its entire current turn if already underway. Outside initiative it ends six elapsed seconds after application. Preserve the original regular/virtual marker or outside absolute deadline through initiative changes, extra turns, absence and travel; end-phase events precede expiry cleanup.",
            "concentration": false,
            "components": [
              "V",
              "S"
            ],
            "resolution": "Make one melee spell attack. Miss: no damage or restriction. Hit: deal 1d8 necrotic and establish the independent HP-gain prohibition under its actual defenses.",
            "effect": "While affected, any event increasing the target’s current HP produces 0 gain: spell/feature/potion healing, passive regeneration, natural recovery, natural-20 death-save 1HP, Stable-state 1HP and other direct restoration. Apply HEALING_DEATH_PLAYTEST.md: ordinary healing’s legal amount and genuine excess become0; ordinary activation costs remain committed, while a reserve spent only for actual restored HP spends0. Independent non-HP components still resolve. A blocked natural20 uses the already-reviewed bridge: Stable at0, death counters cleared, immediate d4-hour recovery deadline and preserved used-turn marker. A due Stable1HP recovery remains subject to its existing blocked-deadline procedure; this spell never rerolls or resets that deadline.",
            "scaling": "None. No automatic increase in damage, range, target count, duration, uses or magnitude.",
            "limitations": "No Undead/biological target prerequisite or special Undead rider. The prohibition does not itself block stabilization, successful death-save state changes, temporary HP, condition removal, damage prevention, maximum-HP changes or independent non-HP components. A maximum-HP change does not authorize a separate current-HP increase through this prohibition. Actual resurrection returned HP is the existing LIFE TRANSITION exception and is not blocked; no corpse/soul/resurrection seal is created. Actual death/condition-removal procedures retain their scope, without duplicating an identity or refreshing spent resources. This is an HP-state rule, not a cosmology ruling. A hit establishes the independent rider under its own defenses even if the damage is reduced to 0; immunity to the damage type alone does not prevent that rider. A later independent application retains its own endpoint; ending one removes only that application, and equal penalties/prohibitions do not stack magnitude. Actual class/source access, repertoire, action availability, components, RP, Dissonance/Refrain, concentration transitions, paid commitment and cast/counter/outcome hooks follow SPELL_INTEGRATION_RULES.md. Base rank 0 costs 0 RP but does not waive real extra costs or Refrain. V requires audible speech; S requires the ordinary usable free hand or an actual exception. No F is added. Spell attacks use d20 + PB + actual casting modifier against AC; natural 1 misses, natural 20 hits and doubles only actual damage dice. Saves use DC 8 + PB + actual casting modifier and binary-save rules. An illegal uncommitted attempt supplies no effect; a legally paid cast countered or failing afterward refunds nothing. Actual damage/material/condition defenses retain their own scopes. No automatic level scaling, extra action budget or resource generation.",
            "designNotes": "PRESERVED: both Evocation/Necromancy sources and actual access, Action, Touch, V/S, 1d8 necrotic and cannot regain HP. NEW: melee spell attack, hit-based independent broad current-HP-gain prohibition, explicit future-target-END duration, state-recovery bindings and existing resurrection life-transition boundary. Authoring clarification deliberately refines initial conference healing-only wording to the source’s broader HP-gain scope.",
            "implementationStatus": "REVIEWED authored operational PLAYTEST manuscript; runtime, human balance and broader integration pending",
            "sourcePlacements": [
              {
                "name": "Chill Touch",
                "school": "Evocation",
                "level": 0,
                "summary": "1d8 necrotic damage; target can't regain hit points."
              },
              {
                "name": "Chill Touch",
                "school": "Necromancy",
                "level": 0,
                "summary": "1d8 necrotic damage, prevents healing."
              }
            ],
            "sourceCoreEntries": [
              {
                "index": 429,
                "original": {
                  "school": "Evocation",
                  "level": 0,
                  "name": "Chill Touch",
                  "effect": "1d8 necrotic damage; target can't regain hit points.",
                  "source_paragraph": 9512,
                  "casting_time": "1 action",
                  "range": "Touch",
                  "duration": "Instantaneous",
                  "components": "V, S",
                  "resolution": "Automatic or opposed as described",
                  "tags": [
                    "Damage",
                    "Healing"
                  ],
                  "rp_cost": 0
                }
              },
              {
                "index": 633,
                "original": {
                  "school": "Necromancy",
                  "level": 0,
                  "name": "Chill Touch",
                  "effect": "1d8 necrotic damage, prevents healing.",
                  "source_paragraph": 9766,
                  "casting_time": "1 action",
                  "range": "Touch",
                  "duration": "Instantaneous",
                  "components": "V, S",
                  "resolution": "Automatic or opposed as described",
                  "tags": [
                    "Damage",
                    "Healing"
                  ],
                  "rp_cost": 0
                }
              }
            ],
            "classAccessEvidence": {
              "Cleric": {
                "rank": 0,
                "minimumClassLevel": 1,
                "school": "Necromancy",
                "baseRpCost": 0
              },
              "Crimson Agent": {
                "rank": 0,
                "minimumClassLevel": 1,
                "school": "Evocation",
                "baseRpCost": 0
              },
              "Dragoon": {
                "rank": 0,
                "minimumClassLevel": 3,
                "school": "Evocation",
                "baseRpCost": 0
              },
              "Druid": {
                "rank": 0,
                "minimumClassLevel": 1,
                "school": "Necromancy",
                "baseRpCost": 0
              },
              "Mage": {
                "rank": 0,
                "minimumClassLevel": 1,
                "school": "Evocation",
                "baseRpCost": 0
              },
              "Shaman": {
                "rank": 0,
                "minimumClassLevel": 1,
                "school": "Necromancy",
                "baseRpCost": 0
              },
              "Thief": {
                "rank": 0,
                "minimumClassLevel": 1,
                "school": "Necromancy",
                "baseRpCost": 0
              },
              "Wizard": {
                "rank": 0,
                "minimumClassLevel": 1,
                "school": "Evocation",
                "baseRpCost": 0
              }
            },
            "sourceReview": [
              "docs/audit/2026-10-08/full-game/GPT_EVOCATION_CANTRIP_SOURCE_CONFERENCE.md",
              "docs/audit/2026-10-08/full-game/GPT_EVOCATION_CANTRIP_AUTHORING_CLARIFICATION.md",
              "docs/audit/2026-10-08/full-game/GPT_EVOCATION_CANTRIP_EXACT_REVIEW.md"
            ],
            "reviewEvidence": [
              "docs/audit/2026-10-08/full-game/GPT_EVOCATION_CANTRIP_EXACT_REVIEW.md"
            ],
            "authoringFile": "data/playtest/spell_drafts/batch_evocation_cantrips.json"
          },
          "additionalRpCost": 0,
          "source": {
            "catalogPath": "src/data/spells.js",
            "catalogSha256": "3358a2e1afcbc340dbafd92e45e39a7d2d0a24fed5c0719a3d233263ce530078",
            "catalogKey": "chill-touch",
            "original": {
              "name": "Chill Touch",
              "level": 0,
              "resonanceRank": 0,
              "school": "Evocation",
              "schools": [
                "Evocation",
                "Necromancy"
              ],
              "placements": [
                {
                  "name": "Chill Touch",
                  "school": "Evocation",
                  "level": 0,
                  "summary": "1d8 necrotic damage; target can't regain hit points."
                },
                {
                  "name": "Chill Touch",
                  "school": "Necromancy",
                  "level": 0,
                  "summary": "1d8 necrotic damage, prevents healing."
                }
              ],
              "classLevels": {
                "Cleric": 0,
                "Crimson Agent": 0,
                "Dragoon": 0,
                "Druid": 0,
                "Mage": 0,
                "Shaman": 0,
                "Thief": 0,
                "Wizard": 0
              },
              "classRanks": {
                "Cleric": 0,
                "Crimson Agent": 0,
                "Dragoon": 0,
                "Druid": 0,
                "Mage": 0,
                "Shaman": 0,
                "Thief": 0,
                "Wizard": 0
              },
              "classLearnLevels": {
                "Cleric": 1,
                "Crimson Agent": 1,
                "Dragoon": 3,
                "Druid": 1,
                "Mage": 1,
                "Shaman": 1,
                "Thief": 1,
                "Wizard": 1
              },
              "classSchools": {
                "Cleric": "Necromancy",
                "Crimson Agent": "Evocation",
                "Dragoon": "Evocation",
                "Druid": "Necromancy",
                "Mage": "Evocation",
                "Shaman": "Necromancy",
                "Thief": "Necromancy",
                "Wizard": "Evocation"
              },
              "castingTime": "Not specified in current rulebook",
              "range": "Not specified in current rulebook",
              "components": "Not specified in current rulebook",
              "duration": "Not specified in current rulebook",
              "description": "1d8 necrotic damage; target can't regain hit points.",
              "alternateSummaries": [
                "1d8 necrotic damage, prevents healing."
              ],
              "classes": [
                "Cleric",
                "Crimson Agent",
                "Dragoon",
                "Druid",
                "Mage",
                "Shaman",
                "Thief",
                "Wizard"
              ],
              "status": "canon",
              "source": "Player Rulebook — Spell Lists"
            },
            "corePath": "data/public/Decennium_Descent_Core_Systems_Data_v2_Known_Descent.json",
            "coreSha256": "50c3e9683349e93192191381ab6354ca7d675a24fcc9bb9b039c23e67fecca4f",
            "coreEntries": [
              {
                "index": 429,
                "original": {
                  "school": "Evocation",
                  "level": 0,
                  "name": "Chill Touch",
                  "effect": "1d8 necrotic damage; target can't regain hit points.",
                  "source_paragraph": 9512,
                  "casting_time": "1 action",
                  "range": "Touch",
                  "duration": "Instantaneous",
                  "components": "V, S",
                  "resolution": "Automatic or opposed as described",
                  "tags": [
                    "Damage",
                    "Healing"
                  ],
                  "rp_cost": 0
                }
              },
              {
                "index": 633,
                "original": {
                  "school": "Necromancy",
                  "level": 0,
                  "name": "Chill Touch",
                  "effect": "1d8 necrotic damage, prevents healing.",
                  "source_paragraph": 9766,
                  "casting_time": "1 action",
                  "range": "Touch",
                  "duration": "Instantaneous",
                  "components": "V, S",
                  "resolution": "Automatic or opposed as described",
                  "tags": [
                    "Damage",
                    "Healing"
                  ],
                  "rp_cost": 0
                }
              }
            ],
            "possibleHistoricalAliases": []
          },
          "reviewFlags": [
            "Core resolution requires an explicit operational interpretation"
          ]
        },
        "completeSharedRules": {},
        "indexEntry": {
          "id": "chill-touch",
          "name": "Chill Touch",
          "authoredStatus": "reviewed-authored-operational-playtest",
          "procedureFile": "catalog.json",
          "procedurePointer": "/spells/415/operational",
          "wholeCardPointer": "/spells/415",
          "sourceStatus": "operational-playtest-draft",
          "priorCatalogSelectionStatusUnchanged": true
        },
        "qualification": "Complete actual reviewed source-specific procedure, not automatic adoption for any of these five."
      },
      "enervation": {
        "spellId": "enervation",
        "source": {
          "path": "DescentReviewChanges/ReviewBible/data/public/spell_candidates/persistent_damage_20_reviewed_07.json",
          "bytes": 849980,
          "sha256": "0601bba2d5ece6d12c0c27b3dcca656e7da8bfba7f1a47b5c647d1e03007b55d"
        },
        "pointer": "/spells/14",
        "completeCurrentCard": {
          "id": "enervation",
          "name": "Enervation",
          "riskTier": "B",
          "status": "PENDING complete current procedure with both original-case vectors preserved and expanded; substantive conference and later exact integration acceptance still required.",
          "completeSourceAndAccess": {
            "id": "enervation",
            "name": "Enervation",
            "schools": [
              "Necromancy"
            ],
            "status": "blocked-pending-operational-review",
            "visibility": "public-source-review",
            "classAccess": {
              "Cleric": {
                "rank": 5,
                "minimumClassLevel": 9,
                "school": "Necromancy",
                "baseRpCost": 10
              },
              "Crimson Agent": {
                "rank": 5,
                "minimumClassLevel": 15,
                "school": "Necromancy",
                "baseRpCost": 10
              },
              "Druid": {
                "rank": 5,
                "minimumClassLevel": 9,
                "school": "Necromancy",
                "baseRpCost": 10
              },
              "Shaman": {
                "rank": 5,
                "minimumClassLevel": 13,
                "school": "Necromancy",
                "baseRpCost": 10
              },
              "Wizard": {
                "rank": 5,
                "minimumClassLevel": 9,
                "school": "Necromancy",
                "baseRpCost": 10
              }
            },
            "operational": null,
            "additionalRpCost": 0,
            "source": {
              "catalogPath": "src/data/spells.js",
              "catalogSha256": "3358a2e1afcbc340dbafd92e45e39a7d2d0a24fed5c0719a3d233263ce530078",
              "catalogKey": "enervation",
              "original": {
                "name": "Enervation",
                "level": 5,
                "resonanceRank": 5,
                "school": "Necromancy",
                "schools": [
                  "Necromancy"
                ],
                "placements": [
                  {
                    "name": "Enervation",
                    "school": "Necromancy",
                    "level": 5,
                    "summary": "4d8 necrotic damage per round, heal for half."
                  }
                ],
                "classLevels": {
                  "Cleric": 5,
                  "Crimson Agent": 5,
                  "Druid": 5,
                  "Shaman": 5,
                  "Wizard": 5
                },
                "classRanks": {
                  "Cleric": 5,
                  "Crimson Agent": 5,
                  "Druid": 5,
                  "Shaman": 5,
                  "Wizard": 5
                },
                "classLearnLevels": {
                  "Cleric": 9,
                  "Crimson Agent": 15,
                  "Druid": 9,
                  "Shaman": 13,
                  "Wizard": 9
                },
                "classSchools": {
                  "Cleric": "Necromancy",
                  "Crimson Agent": "Necromancy",
                  "Druid": "Necromancy",
                  "Shaman": "Necromancy",
                  "Wizard": "Necromancy"
                },
                "castingTime": "Not specified in current rulebook",
                "range": "Not specified in current rulebook",
                "components": "Not specified in current rulebook",
                "duration": "Not specified in current rulebook",
                "description": "4d8 necrotic damage per round, heal for half.",
                "alternateSummaries": [],
                "classes": [
                  "Cleric",
                  "Crimson Agent",
                  "Druid",
                  "Shaman",
                  "Wizard"
                ],
                "status": "canon",
                "source": "Player Rulebook — Spell Lists"
              },
              "corePath": "data/public/Decennium_Descent_Core_Systems_Data_v2_Known_Descent.json",
              "coreSha256": "50c3e9683349e93192191381ab6354ca7d675a24fcc9bb9b039c23e67fecca4f",
              "coreEntries": [
                {
                  "index": 685,
                  "original": {
                    "school": "Necromancy",
                    "level": 5,
                    "name": "Enervation",
                    "effect": "4d8 necrotic damage per round, heal for half.",
                    "source_paragraph": 9828,
                    "casting_time": "1 action",
                    "range": "60 feet",
                    "duration": "Instantaneous",
                    "components": "V, S, F",
                    "resolution": "Automatic or opposed as described",
                    "tags": [
                      "Damage",
                      "Healing"
                    ],
                    "rp_cost": 10
                  }
                }
              ],
              "possibleHistoricalAliases": []
            },
            "reviewFlags": [
              "Core resolution requires an explicit operational interpretation",
              "Not selectable in this spell playtest packet until individual operational review"
            ]
          },
          "procedure": "KEEP Action,one perceived creature60feet,4d8necrotic per round and heal half. NEW reconcile Core Instantaneous with a concentration channel lasting at most60seconds, with one initial pulse during the casting Action and at most nine further pulses, never more than ten total. The initial pulse makes a ranged spell attack against the declared creature using the real casting source; hit deals4d8necrotic (ordinary attack critical applies), miss deals none. Only one original target exists; no retarget. At each future regular caster turn an Action may maintain one further pulse against that same still-existing original creature target, with perception/range60/line of effect rechecked. At most one pulse per original regular caster-turn cycle; extra turns/Actions grant none. If no maintenance Action is completed during an available future regular turn, the channel ends at that turn's END; a miss still counts as maintenance. Outside initiative an otherwise capable caster spends the equivalent whole Action at each successive six-second cycle; missed maintenance ends it. Loss of concentration, actual caster incapacity, target death, actual separation beyond60feet, loss of line of effect/perception, removal or expiry ends the channel immediately; suppression makes a pulse unavailable, consumes its scheduled opportunity and therefore causes missed-maintenance ending if it spans the entire relevant turn/cycle. No paused beam or stored future pulse exists. A hit's healing resolves after its damage/life consequences, even if that hit killed the target and thereby ended later pulses: caster receives ordinary base healing floor(actualDamageDealt/2), using this pulse's eligible terminal branches once and excluding duplicated parents, overkill and copied/replayed descendants. Do not halve nominal dice before counting actual damage or require ordinary HP loss when tempHP was truly absorbed. Damage transfer remains one root; sum its actual terminal recipients without healing separately for each. Apply genuine ordinary healing modifiers, broad prohibition, current maximum/Critical ceiling and source causal guards. Full casterHP, blocked healing or a miss stores nothing and refunds nothing. Unlike Lifedraw's expressly narrower profile, this proposal adds no living-nonconstruct/allied/helpless exclusion to the printed damage and heal clause; necrotic defenses still govern actual numbers. Damage/HP cannot be farmed from an invented summon resource pool or overkill. A subsequent paid cast begins a genuinely new channel and concentration, not a free same-channel extra pulse; all real Action/RP/Dissonance costs apply. The proposal's ten-pulse ceiling and continuous maintenance are NEW balance choices for joint review.\n\nCURRENT HEALING-ELIGIBILITY COMPLETION: Exclude any terminal branch whose actual transfer/source flags forbid derived healing or recovery before summing the base-healing pool. The original NE5-06-B arithmetic is conditional on a genuinely permitted split, not a claim that Burden Shared or Life Linked allows it. The two supplied source-qualified vectors show their actual narrower results and retain the original abstract scenario unchanged. Neither vector changes the separate pending broad donor predicate for this spell.\n\nCURRENT TARGET-CONTINUITY COMPLETION — Enervation only: \"Still-existing original creature\" is the target identity/lifecycle predicate, not a new living-anatomy or nonconstruct restriction. A continuing active creature classified as nonliving is not excluded solely by that classification. Its actual defenses, damage/source eligibility and no-resource/no-recovery flags still apply to each packet and any healing funding. A corpse, removed body, ended summon or destroyed entity that no longer qualifies as a creature cannot supply a maintained target. A same identity at 0 HP is tested under its actual continuing-creature/Disabled/death state, not assumed dead or alive from the HP number. The attack that actually ends the target finishes its own causal damage and source-qualified healing before future channel opportunities are canceled. This completion does not import Leeching Plague's hostile-living-nonconstruct donor filter, provide healing to a dead caster, or grant repair, resurrection, resource farming or an exception to another source's exclusion flags.",
          "previousFullProposalUnchanged": {
            "spellId": "enervation",
            "procedure": "KEEP Action,one perceived creature60feet,4d8necrotic per round and heal half. NEW reconcile Core Instantaneous with a concentration channel lasting at most60seconds, with one initial pulse during the casting Action and at most nine further pulses, never more than ten total. The initial pulse makes a ranged spell attack against the declared creature using the real casting source; hit deals4d8necrotic (ordinary attack critical applies), miss deals none. Only one original target exists; no retarget. At each future regular caster turn an Action may maintain one further pulse against that same still-living target, with perception/range60/line of effect rechecked. At most one pulse per original regular caster-turn cycle; extra turns/Actions grant none. If no maintenance Action is completed during an available future regular turn, the channel ends at that turn's END; a miss still counts as maintenance. Outside initiative an otherwise capable caster spends the equivalent whole Action at each successive six-second cycle; missed maintenance ends it. Loss of concentration, actual caster incapacity, target death, actual separation beyond60feet, loss of line of effect/perception, removal or expiry ends the channel immediately; suppression makes a pulse unavailable, consumes its scheduled opportunity and therefore causes missed-maintenance ending if it spans the entire relevant turn/cycle. No paused beam or stored future pulse exists. A hit's healing resolves after its damage/life consequences, even if that hit killed the target and thereby ended later pulses: caster receives ordinary base healing floor(actualDamageDealt/2), using this pulse's eligible terminal branches once and excluding duplicated parents, overkill and copied/replayed descendants. Do not halve nominal dice before counting actual damage or require ordinary HP loss when tempHP was truly absorbed. Damage transfer remains one root; sum its actual terminal recipients without healing separately for each. Apply genuine ordinary healing modifiers, broad prohibition, current maximum/Critical ceiling and source causal guards. Full casterHP, blocked healing or a miss stores nothing and refunds nothing. Unlike Lifedraw's expressly narrower profile, this proposal adds no living-nonconstruct/allied/helpless exclusion to the printed damage and heal clause; necrotic defenses still govern actual numbers. Damage/HP cannot be farmed from an invented summon resource pool or overkill. A subsequent paid cast begins a genuinely new channel and concentration, not a free same-channel extra pulse; all real Action/RP/Dissonance costs apply. The proposal's ten-pulse ceiling and continuous maintenance are NEW balance choices for joint review.",
            "newChoices": "NEW one-target ranged attack channel, concentration60seconds/ten pulses, real future regular-turn maintenance Actions and continuous range/perception tether. Healing uses reviewed actualDamageDealt terminal accounting, without silently extending Lifedraw-specific exclusions.",
            "workedCases": [
              "NE5-06-A: A hit rolls18necrotic against an unresistant creature with5tempHP and8normalHP. It absorbs5tempHP and loses8normalHP, so actualDamageDealt is13and base healing6; the remaining5overkill contributes nothing. If the actual death ends the channel, this already-resolved pulse can still supply its6base healing once.",
              "NE5-06-B: A14damage pulse is legally divided into two terminal branches that actually inflict4and6. Sum10and heal base5once, not half14plus both children. At fullHP the caster restores0and banks nothing. An extra turn grants no second maintenance pulse; missing the next regular turn's Action ends the channel."
            ],
            "questionId": "NE5-06",
            "originalQuestion": "Preserve4d8 NECROTIC EACH ROUND and healing for HALF, Core Action/60ft/Instantaneous. Define one target or another explicit finite scope,initial event and repeated checkpoints,lifetime/concentration,attack/save/outcomes,maintenance actions and range/line requirements. Bind healing to one actual final paid HP-damage event with current rounding; distinguish tempHP,overkill,damage resistance/immunity,transfer,absorbed damage and simultaneous recipients. Identify who heals and how healing prevention/full HP or target death ends or consumes the opportunity. Compare reviewed Vampiric Touch/Lifedraw and damage sharing, without borrowing their attack or duration wholesale. No healing from nominal dice,duplicate shared/copy packets or banked missed ticks; recasts,suppression and extra turns cannot create extra rounds.",
            "fullSourceAndCurrentAccessRecord": {
              "id": "enervation",
              "name": "Enervation",
              "schools": [
                "Necromancy"
              ],
              "status": "blocked-pending-operational-review",
              "visibility": "public-source-review",
              "classAccess": {
                "Cleric": {
                  "rank": 5,
                  "minimumClassLevel": 9,
                  "school": "Necromancy",
                  "baseRpCost": 10
                },
                "Crimson Agent": {
                  "rank": 5,
                  "minimumClassLevel": 15,
                  "school": "Necromancy",
                  "baseRpCost": 10
                },
                "Druid": {
                  "rank": 5,
                  "minimumClassLevel": 9,
                  "school": "Necromancy",
                  "baseRpCost": 10
                },
                "Shaman": {
                  "rank": 5,
                  "minimumClassLevel": 13,
                  "school": "Necromancy",
                  "baseRpCost": 10
                },
                "Wizard": {
                  "rank": 5,
                  "minimumClassLevel": 9,
                  "school": "Necromancy",
                  "baseRpCost": 10
                }
              },
              "operational": null,
              "additionalRpCost": 0,
              "source": {
                "catalogPath": "src/data/spells.js",
                "catalogSha256": "3358a2e1afcbc340dbafd92e45e39a7d2d0a24fed5c0719a3d233263ce530078",
                "catalogKey": "enervation",
                "original": {
                  "name": "Enervation",
                  "level": 5,
                  "resonanceRank": 5,
                  "school": "Necromancy",
                  "schools": [
                    "Necromancy"
                  ],
                  "placements": [
                    {
                      "name": "Enervation",
                      "school": "Necromancy",
                      "level": 5,
                      "summary": "4d8 necrotic damage per round, heal for half."
                    }
                  ],
                  "classLevels": {
                    "Cleric": 5,
                    "Crimson Agent": 5,
                    "Druid": 5,
                    "Shaman": 5,
                    "Wizard": 5
                  },
                  "classRanks": {
                    "Cleric": 5,
                    "Crimson Agent": 5,
                    "Druid": 5,
                    "Shaman": 5,
                    "Wizard": 5
                  },
                  "classLearnLevels": {
                    "Cleric": 9,
                    "Crimson Agent": 15,
                    "Druid": 9,
                    "Shaman": 13,
                    "Wizard": 9
                  },
                  "classSchools": {
                    "Cleric": "Necromancy",
                    "Crimson Agent": "Necromancy",
                    "Druid": "Necromancy",
                    "Shaman": "Necromancy",
                    "Wizard": "Necromancy"
                  },
                  "castingTime": "Not specified in current rulebook",
                  "range": "Not specified in current rulebook",
                  "components": "Not specified in current rulebook",
                  "duration": "Not specified in current rulebook",
                  "description": "4d8 necrotic damage per round, heal for half.",
                  "alternateSummaries": [],
                  "classes": [
                    "Cleric",
                    "Crimson Agent",
                    "Druid",
                    "Shaman",
                    "Wizard"
                  ],
                  "status": "canon",
                  "source": "Player Rulebook — Spell Lists"
                },
                "corePath": "data/public/Decennium_Descent_Core_Systems_Data_v2_Known_Descent.json",
                "coreSha256": "50c3e9683349e93192191381ab6354ca7d675a24fcc9bb9b039c23e67fecca4f",
                "coreEntries": [
                  {
                    "index": 685,
                    "original": {
                      "school": "Necromancy",
                      "level": 5,
                      "name": "Enervation",
                      "effect": "4d8 necrotic damage per round, heal for half.",
                      "source_paragraph": 9828,
                      "casting_time": "1 action",
                      "range": "60 feet",
                      "duration": "Instantaneous",
                      "components": "V, S, F",
                      "resolution": "Automatic or opposed as described",
                      "tags": [
                        "Damage",
                        "Healing"
                      ],
                      "rp_cost": 10
                    }
                  }
                ],
                "possibleHistoricalAliases": []
              },
              "reviewFlags": [
                "Core resolution requires an explicit operational interpretation",
                "Not selectable in this spell playtest packet until individual operational review"
              ]
            },
            "sourceRecordSha256": "318ee143dacb89fdc49b0a25e50460698426d0b30117cc69519993d247274942",
            "status": "unadopted-unsent-operating-proposal",
            "examplesAreRuntimeTests": false
          },
          "previousSharedProposalUnchanged": {
            "status": "UNADOPTED AND UNSENT. Sixteen complete local procedures and thirty-two authored examples await actual GPT discussion and exact review. NEW denotes an explicit design proposal. Sources, catalog access, reviewed status, runtime and cosmology remain unchanged.",
            "casting": "KEEP actual rank-five school access, minimum class levels and base10RP. All sixteen keep Action and range60feet except Mass Decay keeps30feet. All keep V/S/F except Danse Macabre keeps V/S/M/F and the reviewed ordinary material/focus alternative; no unprinted consumed material price is imported. Actual source casting ability, repertoire, components, permissions, RP/strain surcharges, Dissonance/Refrain and countering apply. DC=8+actual PB+actual casting modifier; spell attack=actual PB+actual casting modifier. A legal commitment pays actual costs before hidden target checks and countering, without refunds. Known illegal targets/costs are rejected at preflight. Only explicitly proposed concentration requirements apply; new concentration ends the prior one at its actual commitment, even if the new cast fails. No automatic upcasting, class feature or outside statblock is acquired.",
            "geometry": "Named targets and chosen centers require actual perception and caster line of effect. Areas also require center-to-recipient line of effect; an area alone does not require seeing every indiscriminate recipient. A designated enemy is a perceived creature the caster regards as hostile from current information, not a hidden alignment detector. Choose ordered lists, modes, limbs, shapes and paths before resolution and hidden results. Recheck eligibility/geometry at resolution; hidden failure creates no diagnostic. Actual movement and body volumes cannot pass through walls or other solid/occupied spaces. Forced movement spends no movement budget and causes no ordinary opportunity attack; actual loss of support uses the reviewed Fall Marker, not a second damage event invented by this packet.",
            "clocks": "A proposed minute is60 elapsed seconds, hour3600 and day86400. Expiry wins at its exact deadline. Suppression never resets expiry, used payments, per-round history or recovery history; skip suppressed opportunities without storing them. Genuine extra turns do not advance regular START/END counters or grant another explicitly regular-turn pulse. For the three-round spell endpoint, record the next three future original-source regular END markers, excluding a turn already underway; outside initiative use18elapsed seconds. Preserve that original schedule through death, initiative changes and transition out of combat, with six-second virtual cycles when the source lacks an active turn. This is a NEW finite clock bridge, not permission to halt a spell by removing its caster from initiative.",
            "damageAndHealing": "Use reviewed typed defenses, minimum-HP prevention, temporary HP, Wounds, Instant Death, dying/Stable, actual death and eligible immediate survival responses. Resistance halves the matching component with normal rounding. actualDamageDealt=tempHP absorbed+actual ordinary HP lost, excluding overkill, state-assignment loss and double-counted parent/child transfer packets. Count each eligible terminal damage branch once. Healing based on this number remains ordinary healing unless a procedure explicitly identifies direct state recovery. Broad cannot-regain-HP applies to living direct state recovery; ordinary healing multipliers and Critical ordinary-healing ceilings do not automatically apply to it. HP costs use normal HP only, are not damage and cannot be paid with tempHP, redirected, reduced, prevented or refunded by a failed benefit. No spell here revives an actually dead identity.",
            "companions": "All commanded bodies of one owner share the reviewed one Bonus Action command and one offensive companion Action per numbered round, including other class companions/devices. Issue within60feet with actual owner perception and line of effect. NEW these spell-created/animated undead understand only their owner's simple mental command channel; it grants neither a remote sensory feed nor free speech/knowledge. A BA selects exactly one body and one ordinary Move plus its single profiled Action or ordinary permitted basic Action, executed only in the owner's existing attached phase after the whole owner turn. Every other capable body has only defensive Move and Dodge in that phase. No independent initiative, Reaction, BA, multiattack, spellcasting, Help engine, tool proficiency, resource pool or summon power exists. Committed orders retain reviewed validity rules. Damage/control consumes the shared offensive allowance; support still needs its paid command. Original source owner supplies the current spell attack and PB-based saves; changing controller grants no second cap or new source stats. Each independent application keeps its actual duration and original ownership. Legal ordinary companion healing cannot reconstruct a destroyed body or refill absent resources.",
            "bodyClaims": "One physical identity has one state: living, corpse, consumed or removed. Animate only actual eligible non-summoned, non-copied, non-illusory, not-previously-raised remains; fragments do not become extra bodies. Legal resurrection already completed during immediate death responses marks that same body living before later claims. A reservation by Auto-Raise is not exclusive ownership; still resolve its actual later checkpoint and capacity, consuming no second body. These spells do not grant Wizard Corpse Harvest, Auto-Raise, Infernal Pact or Mage assets. Spell-specific body caps are separate from Wizard's three standard-minion slots and Mage asset slots, but all retain the shared command/offense budget. NEW spent animated remains retain their physical identity and actual inventory, with consumed status: no second raising/harvest fuel and no refreshed recipe donor qualities. An actual resurrection source must meet its reviewed reconstruction requirements for a consumed body; this packet grants none. Created summons leave no corpse/loot. Source-qualified maximum-HP modifiers require genuine access and actual spell provenance; a Wizard spell creation can qualify for its actual Conjuration modifier, never a generic borrowed Wizard level. Printed HP here is base HP before such genuinely applicable modifiers.",
            "zombieProfile": "NEW shared Flood/Danse zombie animation profile: actual Small or Medium eligible body, type Undead; baseAC10, baseHP20, walk20feet only with its original functional walking supports; STR12, DEX6, CON14, INT3, WIS6, CHA3. All six saving throws use original owner's current PB as their total modifier; other checks use the listed ability modifier with no proficiency. Ordinary sight/hearing only, no darkvision, languages, private memory or remote senses. It makes one melee attack at5feet using original owner's current spell-attack modifier, dealing1d6 bludgeoning with its actual available arm/body strike, no ability damage bonus. Native shape/size/weight and missing anatomy remain real: no hand attack without a surviving striking limb; missing legs give no new crawl/flight/swim mode. Physical wounds/injuries and harvest losses persist and restrict the surviving anatomy; the new animation HP pool does not repair them. Existing usable worn armor can replace the baseAC under its own rules without creating proficiency, a new item or a second AC formula. Supplied equipment stays real, encumbers normally, and does not add weapon attacks outside this profile. No resistances, immunities, Undead Fortitude, regeneration, death saves, loot reward, donor substrate or other zombie powers are imported. This is an HP-only animation destroyed at0; destruction or expiry leaves that same consumed inert body and its real surviving gear. It neither restores nor duplicates the former living identity.",
            "materialLedger": "NEW permanent material conversions below are explicit finite transmutation exceptions: output occupies the same selected eligible volume, while its mass becomes that of its new named mundane material. They do not claim both mass and volume conservation. Record each actual source region/lot, volume, old and new composition/mass, contamination, claims, damage and later splits/removals. No original stock remains separately available. No new source-tier, precious mineral, monster property, finished item quality, magical reagent role or trade XP follows from renaming matter. Separating ordinary output does not copy the original region; consumed/sold quantities are gone. Existing tools, actual work, access, Load, transport, finite buyers, provenance and recipe requirements still apply. Transformation is not Fabricate, mining work, an appraisal or a guaranteed sale. A permanent instantaneous result is ordinary matter: later Dispel/suppression does not revert it. Real later physical melting, erosion and use change that actual stock once. Source contamination/embedded foreign matter is not purified by changing its host material. No cosmological origin or universal matter-creation rule follows.",
            "examples": "The32 cases are authored adjudications, not full runtime tests. Unless stated otherwise, caster is Wizard9 with the actual Necromancy/Transmutation repertoire row, PB4, INT+4, maximum/currentRP32, Dissonance0 and a different preceding spell. An otherwise unmodified cast costs10RP (32→22), raises Dissonance to1 with limit10, uses attack+8 and DC16. Scenario-specific immunity, anatomy, positions, HP and other features are explicit premises, not new grants."
          },
          "sourcePromise": "4d8perround and halfheal retained; new attack/maintenance/donor scope requires explicit review.",
          "remainingDecisions": "Actual regular Action maintenance,10pulse ceiling, continuous60ft/perception tether and missing-turn deadline; no extra-turn pulse; actual terminal branch heal and differently scoped donor predicate vs Leeching Plague; named transfer source.",
          "damageRootProposal": {
            "spellId": "enervation",
            "status": "NEW source-specific proposal, requires Director agreement",
            "components": [
              {
                "name": "initial and each separately maintained pulse attack",
                "rootKind": "new root per real Action attack",
                "dealer": "actual original caster character; no creature identity is created for a field, beam or object cannon",
                "creationCheckpoint": "At each genuinely new authorized initial/maintenance attack; sample dealer state then.",
                "descendants": "That pulse and its eligible terminal damage/healing accounting only. Future paid Action attacks are new activations under the maintained channel."
              }
            ],
            "reason": "A retained concentration tether is not itself a reroll or a reason to reuse an earlier attack root. No root for skipped maintenance or extra-turn attempts."
          },
          "originalCaseIds": [
            "NE5-06-A",
            "NE5-06-B"
          ]
        },
        "completeSharedRules": {
          "P20-CASTING-01": "Reuse actual class-access/repertoire, paid costs, component, concentration and Dissonance/Refrain procedures from the exact registry. None of these drafts grants a new class row, rank, upcast or resource maximum. A continuous field, stored rider or command does not itself cast again. Actual target/caster predicates are rechecked at the source-defined checkpoint, without refund or diagnostic disclosure from hidden failure.",
          "P20-DIGITAL-GEOMETRY-01": "NEW bounded clarification for these 20 proposals: measure the actual occupied body against the continuous authored volume/surface, with actual cover/line of effect. Five-foot lengths remain real lengths, not a rounding of positions onto tabletop squares. Source-authored five-foot destructible/fuel partitions remain fixed object identities; changing path sampling, zoom or visual mesh subdivision cannot create more targets, HP or exposure. Evaluate a genuine entry at the first boundary crossing/contact, resolve it once before continuing the same trajectory, and preserve actual remaining movement. Teleport crosses no intermediate path; an arrival can trigger only a source explicitly authorizing arrival. Snapshot simultaneous recipients once before their consequences; destroyed cover creates no second wave.",
          "P20-CLOCKS-01": "NEW explicit cohort bindings: absolute field deadlines are resolution+60 seconds where the procedure states one minute; expiry wins at equality. Source-owned pulses at resolution and +6 through +54 do not require a caster turn or grant a creature turn. A finite target/source marker schedule records its original regular markers at creation under accepted time ordering; reorder, extra turns and departure preserve the original virtual schedule, six seconds apart. Explicit future-turn endpoints exclude an in-progress turn/phase; an ending save expressly including current END keeps that exception. At START, apply accepted expiry/recovery/death-save ordering before periodic damage. At END, due damage/eligible ending saves precede that source endpoint cleanup, except a card explicitly expires before its redundant last save. Suppression consumes a due scheduled opportunity with no damage or catch-up. Ended creature identities have no recipient; administrative deadline bookkeeping never resurrects one.",
          "P20-ATTACHED-PHASE-01": "NEW source-specific bridge for the target-clock proposals in this cohort, not a general companion turn: an owner-attached recipient uses the original owner regular attached-phase beginning/end only for the stated spell packet or ending save. A future phase excludes one already underway. If no such real phase exists, retain a six-second spell-only checkpoint and finite original endpoint. This checkpoint supplies only a due packet/save or expiry that the spell actually grants; it supplies no Action, movement, Bonus Action, Reaction refresh, recharge, or ordinary death save. Source-required real Action/command maintenance cannot execute at an administrative checkpoint. Root identity, prior spent exposures, endpoint and finite tick count survive controller or schedule changes.",
          "P20-FAMILY-EXPOSURE-01": "NEW per-source anti-duplication applies only where the individual procedure names a family cap: record target identity, named spell family, explicit category and numbered round. Different owners/casts share that named ledger; distinct spell names and explicitly separate Wall of Fire categories do not merge. Outside initiative use the scene continuing six-second exposure cycle, fixed before the relevant exposure. Preserve its spent state through a transition to the current combat round until that mapped interval ends; never refresh just by changing timing mode. Immunity/save/prevention after actual admission still consumes the exposure; wholly suppressed or geometrically ineligible sources cannot claim it. Simultaneous eligible sources use established application order then stable identity. Immolation instead uses the already accepted ongoing-fire arbitration at each identical target marker.",
          "P20-DAMAGE-FUNDING-01": "Reuse actual typed defenses, temporary HP, HP floors, Wounds, concentration, death/Null life order and one original recipient event. No inferred damage amount from structural failure or overkill. ActualDamageDealt remains real tempHP absorption plus normal HP loss. Healing/funding is a separate consumer: first exclude any terminal branch whose actual transfer/source flag forbids derived healing or recovery, then apply the spell-specific donor predicate, sum eligible branches once and floor the half once. Never count a split parent again. Burden Shared and Life Linked restrictions remain operative; a numeric branch amount alone is not funding permission. Preserve the distinct pending Leeching Plague donor exclusions and Enervation wider proposal for explicit Director disposition.",
          "P20-RNG-INFORMATION-01": "Authored dice are engine RNG. Original component identity, draw method, save factor and cached ordinal value remain private engine state unless an actual separately accepted presentation policy grants the exact disclosure. This candidate grants no new public dice viewer, hidden-target list, successful-save feedback, enemy-identity scan or Fate eligibility. Shared damage dice do not merge recipient roots. The accepted exact DE4 five-entry presentation policy applies only where its actual source predicates pass; it does not automatically disclose any private periodic, delayed, penalty or random-selection operation in this cohort. An actual qualifying OVERT-ATTACK d20 can use that entry without exposing a hidden Synaptic Static d6, hidden modifier cause or later damage pool. No sixth presentation entry is proposed here. No RNG seed or future draw is exposed. If a source has no admitted recipient and no explicit source-authored event-generation rule, do not invent a damage event merely to publish a roll.",
          "P20-ROOT-01": "Every damage source uses its explicit pending per-source mapping in damageRootProposals. These are NEW decisions requiring concurrence; accepted Forbiddance/Chain Arc/Skybrand and lower nightmare rules do not silently generalize. Root creation alone spends no Action, deals no damage, triggers no Wound, generates no material, and grants no hidden information. Pure transfer retains flags; an attached component can retain an old flag while a genuinely new operated attack creates its own root. Physical fire and Sonic debris mappings are bounded to the exact finite proposed outputs.",
          "P20-SUPPRESSION-01": "Reuse the exact actual suppressor/removal source. Lesser Antimagic, rank limits and source versus expression tests keep their accepted scope. AC6 Globe is not general antimagic: its fixed boundary blocks only its actual incoming rank-0–5 source cases, does not ban all internal casting, and does not erase an already attached buff merely because a creature enters. A fixed external ongoing field and a target-attached rider have different origin facts. A spell object is not a creature; physical Inferno fuel/rubble after actual creation is not a sustained magical field. No suppression pauses a deadline or restores a destroyed body, cleared crystal patch, spent shot or old command."
        },
        "indexEntry": {
          "id": "enervation",
          "name": "Enervation",
          "authoredStatus": "reviewed-authored-operational-playtest",
          "procedureFile": "../spell_candidates/persistent_damage_20_reviewed_07.json",
          "procedurePointer": "/spells/14",
          "wholeCardPointer": "/spells/14",
          "sourceStatus": "blocked-pending-operational-review",
          "priorCatalogSelectionStatusUnchanged": true,
          "sourceCatalogWholeCardPointer": "/spells/645",
          "wholeCardIdField": "id",
          "procedureTextPointer": "/spells/14/procedure",
          "sharedRulesPointer": "/sharedRules",
          "manuscript": "../../../docs/spells/candidates/PERSISTENT_DAMAGE_20_REVIEWED_07.md",
          "reviewId": "DD-PERSISTENT-DAMAGE20-EXACT-REBOUND-07-REVIEW",
          "runtimeSelectionEnabled": false,
          "completeEnvelopeBinding": {
            "path": "DescentReviewChanges/ReviewBible/data/public/spell_candidates/persistent_damage_20_reviewed_07.json",
            "bytes": 849980,
            "sha256": "0601bba2d5ece6d12c0c27b3dcca656e7da8bfba7f1a47b5c647d1e03007b55d"
          },
          "authoredAcceptanceReceipt": {
            "path": "docs/audit/2026-10-08/full-game/PERSISTENT_DAMAGE_20_EXACT07_APPLICATION_RECEIPT.json",
            "bytes": 8279,
            "sha256": "b0f08ab0b9722a309770e7a50281fe212849c9091abc2922a04fda5796d7093a"
          },
          "historicalCandidateLabelsPreserved": true,
          "caseSourceReferenceAliases": {
            "SPELLS_MODEL.json": "DescentReviewChanges/ReviewBible/data/public/spell_candidates/persistent_damage_20_reviewed_07.json",
            "CASEBOOK.json": "DescentReviewChanges/ReviewBible/data/playtest/spell_candidates/persistent_damage_20_cases_07.json",
            "REGISTER.json": "docs/audit/2026-10-08/full-game/persistent-damage20-exact-rebound-07/REGISTER.json"
          }
        },
        "qualification": "Complete actual reviewed source-specific procedure, not automatic adoption for any of these five."
      }
    }
  },
  "questionIds": [
    "SS8-Q01",
    "SS8-S01",
    "SS8-S02",
    "SS8-S03",
    "SS8-S04",
    "SS8-X01",
    "SS8-X02"
  ]
}
```

## faction-paragon

```json
{
  "id": "faction-paragon",
  "authorship": "NEW spell-local authored operational proposal",
  "nativeUnchanged": {
    "id": "faction-paragon",
    "name": "Faction Paragon",
    "schools": [
      "Conjuration"
    ],
    "status": "blocked-pending-operational-review",
    "visibility": "public-source-review",
    "classAccess": {
      "Druid": {
        "rank": 8,
        "minimumClassLevel": 15,
        "school": "Conjuration",
        "baseRpCost": 21
      },
      "Mage": {
        "rank": 8,
        "minimumClassLevel": 15,
        "school": "Conjuration",
        "baseRpCost": 21
      },
      "Wizard": {
        "rank": 8,
        "minimumClassLevel": 15,
        "school": "Conjuration",
        "baseRpCost": 21
      }
    },
    "operational": null,
    "additionalRpCost": 0,
    "source": {
      "catalogPath": "src/data/spells.js",
      "catalogSha256": "3358a2e1afcbc340dbafd92e45e39a7d2d0a24fed5c0719a3d233263ce530078",
      "catalogKey": "faction-paragon",
      "original": {
        "name": "Faction Paragon",
        "level": 8,
        "resonanceRank": 8,
        "school": "Conjuration",
        "schools": [
          "Conjuration"
        ],
        "placements": [
          {
            "name": "Faction Paragon",
            "school": "Conjuration",
            "level": 8,
            "summary": "Summon the champion of your allied faction."
          }
        ],
        "classLevels": {
          "Druid": 8,
          "Mage": 8,
          "Wizard": 8
        },
        "classRanks": {
          "Druid": 8,
          "Mage": 8,
          "Wizard": 8
        },
        "classLearnLevels": {
          "Druid": 15,
          "Mage": 15,
          "Wizard": 15
        },
        "classSchools": {
          "Druid": "Conjuration",
          "Mage": "Conjuration",
          "Wizard": "Conjuration"
        },
        "castingTime": "Not specified in current rulebook",
        "range": "Not specified in current rulebook",
        "components": "Not specified in current rulebook",
        "duration": "Not specified in current rulebook",
        "description": "Summon the champion of your allied faction.",
        "alternateSummaries": [],
        "classes": [
          "Druid",
          "Mage",
          "Wizard"
        ],
        "status": "canon",
        "source": "Player Rulebook — Spell Lists"
      },
      "corePath": "data/public/Decennium_Descent_Core_Systems_Data_v2_Known_Descent.json",
      "coreSha256": "50c3e9683349e93192191381ab6354ca7d675a24fcc9bb9b039c23e67fecca4f",
      "coreEntries": [
        {
          "index": 190,
          "original": {
            "school": "Conjuration",
            "level": 8,
            "name": "Faction Paragon",
            "effect": "Summon the champion of your allied faction.",
            "source_paragraph": 9214,
            "casting_time": "1 action",
            "range": "120 feet",
            "duration": "Concentration, up to 1 minute",
            "components": "V, S, F",
            "resolution": "Automatic or opposed as described",
            "tags": [
              "Summoning",
              "Faction"
            ],
            "rp_cost": 21
          }
        }
      ],
      "possibleHistoricalAliases": []
    },
    "reviewFlags": [
      "Core resolution requires an explicit operational interpretation",
      "Not selectable in this spell playtest packet until individual operational review"
    ]
  },
  "common": {
    "scope": "NEW authorship in this return applies only to the five listed identities. Preserve each complete native card/class-access envelope unchanged, including blocked source status and operational=null. Accepted comparisons remain closed at their exact recorded scopes; current backing bytes and historical525/323 headings do not expand them. This is data-only proposed static authorship, not a runtime, human-play, balance, cosmology, content-rating, release or domain-closure claim.",
    "casting": "Ordinary Action,120ft,V/S/F,rank8/base21RP, native class rank/level/school rows exactly. Require actual acquisition/book/preparation, available Action, components, perception, line of effect, lawful target and full occupied-volume fit. A focus must actually be accessible and S a free hand or an actual exception; V audible speech. No unprinted material price or generic Overcast. Known failure rejects before commitment; hidden later failure consumes a legally committed cast without replacement targets or revealing hidden facts. Range refers to the chosen origin; the whole created body/structure must also have actually known legal space and unobstructed formation, never intersect a creature or existing solid.",
    "payment": "Read Dissonance before casting. Limit=max(4,2+PB+max(0,casting modifier)); ranked costs gain+1/+2/+3 at limit/limit+3/limit+6; ordinary rank1+ blocked at limit+6 absent a real specific traumatic exception. Commit actual costs and Action once. Ordinary rank6–9 baseD2,rank1–5 baseD1,rank0 baseD0; successive same-family casts add Refrain1/2/3 capped3; different family resets to0, idle/weapon turns do not. Wizard first distinct prepared family in an encounter waives baseD only, not Refrain. Native pet actions, healing waves, weapon operation and maintenance are not new spell casts. New parent concentration ends old owner concentration at commitment before counter/outcome; no refund or restoration on failure. Shifting Fortress is expressly nonconcentration.",
    "checks": "Actual spell attacks d20+PB+actual casting modifier; source-specific modifiers only. Natural1 misses,natural20 hits and doubles dice only. Saves DC8+PB+modifier and actual save proficiency/conditions. Current passive defenses, cover and reaction scopes remain exact. Use real Counterspell/dispel acquisition, range, paid cost and check, not names or guessed ranks. Ordinary Wizard class Counterspell is automatic at2,rank1,cost3RP,recharge2,Reaction,60ft,INT+PB versus10+2*targetrank. Wizard class Dispel remains rank3/printed3RP/check10+targetrank; no conversion to acquired Greater Dispel.",
    "ready": "Accepted Ready exception: preparation spends actual Action/cost/components/strain once, starts held concentration and exposes the counter window then. Choose legal target/placement/form/operator list at release and revalidate before spending one Reaction. Invalid/declined occurrences may wait until next regular own-turn START; no refund. Release creates no second cast,cadence or counter window. Its effect duration starts at manifestation. A concentration parent continues the hold; otherwise the Ready hold ends after resolution. No structure can be placed through occupants to provide free boarding.",
    "clocks": "Use original regular START/END markers and stable phase/application sequence. Absolute expiry wins before new events at equality. Existing clocks keep virtual6second markers through initiative changes, extra turns, absence or death; do not multiply opportunities. Source-ending and damage-root callbacks finish under their actual causal order. Five-round Shifting Fortress has the explicit source-START convention below, not a substituted60seconds.",
    "geometryAndCustody": "Bodies have actual whole-body boxes/poses and mass, not point placeholders. Use actual sight versus location versus LoE; no ray through opaque solid solely because an origin is visible. Every real item retains unique ID,owner,custody,weight,Load,condition and charges. Intrinsic conjured gear/ammunition is not transferable stock. Real carried cargo settles at its actual location on ending, or records a real pending placement if no lawful support exists; no teleport to a former anchor. Unsupported real bodies/cargo use accepted Falling: start now; first descent at END of enclosing regular slot next round, or most recent completed slot if between turns, then6second steps up to300ft. Impact min(10,floor(uncontrolledDistance/20))d6,positive actual damage causes Prone. No invented crushing or free slow fall.",
    "ownership": "Store creator,parent source,current controller,actual acting body and damage/healing dealer separately. Companion damage belongs to the pet; actual structure weapon damage belongs to its firing operator, not building/creator. Root Null flag samples that actual dealer at creation; transfers inherit and later independent attacks create new roots. Objects still take ordinary object damage under Null. No corpse, XP,loot,RP,water,ingredient,harvest or class-proc farm follows from these creations. Actual independent source exceptions retain their own narrow scope.",
    "holds": "All absent actual faction/champion/profile, physical geometry/material/support, equipment/weapon proficiency, source access, healing/repair eligibility and topology facts remain whole-case or branch holds. New finite spell profiles and numbers below are explicitly authored specifications, not recovered bestiary/building content or positive campaign examples. A conditional fixture does not discharge its hold."
  },
  "companionRules": {
    "countAndDuration": "One body of this exact spell per original caster, across controllers; successful replacement ends the old same-spell body. All three creature parents require concentration and one absolute manifestation+60seconds deadline. Old parent concentration ends on new concentration commitment even if the replacement fails. Caster death/incapacity ends parent concentration by its actual source; ordinary0HP,expiry,voluntary creator concentration-ending/dismissal or actual removal ends the body with no corpse/loot. Lasting real cargo remains.",
    "command": "NEW explicitly extend the AC6 attached companion schedule and lower Water support accounting to these three bodies. One owner Bonus Action command during an actual regular turn,within60ft and with actual audible speech/perception/LoE, selects one body,finite route and one available Action. It executes once immediately after the entire owner turn, rechecking capability/range/target/LoE. Command expires at the END of that attached phase if impossible,suppressed,unaffordable or budget-starved; no banking,replay,retarget or refund. No autonomous spell/drain/heal/attack without command. All owner assets share one BA-command and one damaging/control/support Action allowance per numbered round; heal,child cast,channel maintenance,native drain and strike each consume that same allowance. Extra turns do not reset it. Creation gives no free Action, but an otherwise unspent creation-turn BA may command the actual attached phase. A command may instead buy Dash/Disengage/Search/defensive movement/Dodge; no automatic Help,grapple,shove,Opportunity Attack,Ready,item activation or extra Reaction.",
    "defaultAndAuthority": "Without a command, one source-attached defensive movement up to current Speed and Dodge at that regular opportunity, only while capable and actual space is legal; no offensive/support effect. Intrinsic physical gripping allows only genuinely possible ordinary pickup/drop with an actual available interaction in that phase, not extra work/proficiency/item activation. A source-qualified controller transfer cancels pending old orders, preserves original owner-wide spent ledgers and source clock, grants no fresh turn, and adopts only the exact new controller source schedule. Without such a source, no takeover is granted. Original source statistics retain their defined provenance.",
    "healingAndNull": "NEW named extension of AC4/AC5/AC6 mechanical living-ally HP eligibility to Greater Water Pet,Archlich Shade and Faction Paragon only, while their finite body exists. Ordinary healing must still actually target them and respect source exclusions,prohibitions,Critical/max limits and modifiers; no biology/soul/resurrection/disease/repair entitlement. Qualifying Null damage at0 leaves the same NullDisabled0 body: Incapacitated,Speed0,no commands/Actions/BA/Reaction,original deadline/concentration continue. Later qualifying Null hits do not recreate or kill it. Actual legal healing above0 restores the same body without clock/budget refresh. Ordinary non-Null0 ends the finite body; independent expiry/removal still ends NullDisabled.",
    "suppression": "NEW adopt AC5/AC6 same-body full-suppression for only these three profiles: operative whole-body suppression triggered by intersection of any actual occupied part preserves body,HP,position,real cargo,Null state and original deadlines. Speed0,no actions,commands,senses supplied by the spell or intrinsic gear function; no pulses. Clocks and gravity continue, so unsupported actual body Falls. Leaving suppression resumes surviving permissions only, never missed commands or healing. Narrow rider-only suppression affects only its named component. Shade child concentration has its separate stricter ending rule below. No Knight disappearance or Soul Wraith ending rule is silently imported."
  },
  "rules": {
    "identityChoice": "NEW director selection: the source champion is represented by one finite temporary champion manifestation of the actual chosen faction, not transported,copied,commandeered or injured as a real NPC. This explicitly extends the lower Champion interpretation for this rank8 spell; the rank8 wording is not claimed to already decide it. It preserves champion aid through one stronger complete martial representative while avoiding unprinted teleport/identity/inventory permissions. No new faction,real champion name,private memories,secrets,official rank,negotiating power,credential or soul is created. Actual faction and champion-designation evidence is still required; missing identity/content keeps the whole positive campaign case held.",
    "gate": "NEW reuse exact AC5 institutional gate for one known canonical factionId: actual spell-specific alliedStatus=true,standing>0,invocationPermission=true,no explicit aid prohibition. Also require actual documented champion designation and permission to represent that champion; no assumed NPC sheet is needed for the fixed profile but the identity/designation itself cannot be invented. Declare the known faction/designation and profile before ordinary payment,or at Ready release. Membership,alignment,positive standing alone or other Faction spells do not substitute. Known failure rejects before payment; hidden failure after lawful commitment spends the cast without identifying the hidden fact or choosing a new faction. Missing factual evidence holds the entire success branch.",
    "body": {
      "authorship": "NEW complete finite spell-local profile, not a creature roster/CR claim",
      "size": "Medium",
      "spaceFeet": [
        5,
        5,
        6
      ],
      "massLb": 180,
      "mechanicalType": "Humanoid",
      "baseHP": 140,
      "baseAC": 19,
      "scores": {
        "STR": 20,
        "DEX": 12,
        "CON": 18,
        "INT": 10,
        "WIS": 14,
        "CHA": 14
      },
      "walkFeet": 30,
      "swimFeet": 0,
      "flyFeet": 0,
      "hover": false,
      "hands": 2,
      "speech": "understands creator spoken commands; only Shade articulates its own bounded spell components, no private memories or general negotiation",
      "senses": [
        "ordinary sight",
        "ordinary hearing"
      ],
      "saves": "all six save totals = original creating owner currentPB, unless Shade snapshot explicitly overrides",
      "checks": "listed raw ability modifier; no ungranted proficiency",
      "resistances": [],
      "immunities": [],
      "needs": "NEW ordinary air-breathing exposure; no water breathing/amphibious/no-air/no-food/no-sleep privilege. Actual environment/long-term physiology outside this minute remains held.",
      "carry": "BODY actual STR and size capacities; Medium pounds15*STR,LoadSTR; positiveLoad>=half capacity is Burdened. No passenger/mount entitlement; actual compatible custody and anatomy required.",
      "maxHP": "Actual source-qualified creation/current maximum modifiers apply once; capacity rise does not heal, decrease clamps only. No generic owner-level scaling unless the actual class/source grants it.",
      "intrinsicGear": "nontransferable source parts only; cannot be looted, sold, harvested, consumed as equipment or duplicated"
    },
    "actions": "NEW one Champion Strike commanded Action,reach5ft,one perceived legal physical creature/object,original creating-class current spellattack versus actual AC:3d8+current original-owner PB slashing; critical doubles only dice to6d8. Its armor,shield and weapon are integral appearance providing AC19/this attack only,not separate equipment,proficiencies,attunements or loot. No Multiattack,aura,spellcasting,healing,authority,work crew,independent turn or Reaction. Actual borrowed gear uses real custody/body capacity and grants no unprinted activation.",
    "gateAfterCreation": "A later standing/aid-permission change does not retrospectively undo an already admitted representative or reveal remote faction facts. It gates later casts only,unless an actual narrower source explicitly ends the current effect. One Paragon per caster across factions; concentration60seconds and the shared companion/Null/healing/suppression rules apply. The real champion gains no injury,death,resource loss or duplicated gear; ended representative has no return-trip/person to relocate."
  },
  "questionIds": [
    "SS8-Q01",
    "SS8-F01",
    "SS8-F02",
    "SS8-F03",
    "SS8-X01",
    "SS8-X02"
  ]
}
```

## conjure-sky-fortress

```json
{
  "id": "conjure-sky-fortress",
  "authorship": "NEW spell-local authored operational proposal",
  "nativeUnchanged": {
    "id": "conjure-sky-fortress",
    "name": "Conjure Sky Fortress",
    "schools": [
      "Conjuration"
    ],
    "status": "blocked-pending-operational-review",
    "visibility": "public-source-review",
    "classAccess": {
      "Druid": {
        "rank": 8,
        "minimumClassLevel": 15,
        "school": "Conjuration",
        "baseRpCost": 21
      },
      "Mage": {
        "rank": 8,
        "minimumClassLevel": 15,
        "school": "Conjuration",
        "baseRpCost": 21
      },
      "Wizard": {
        "rank": 8,
        "minimumClassLevel": 15,
        "school": "Conjuration",
        "baseRpCost": 21
      }
    },
    "operational": null,
    "additionalRpCost": 0,
    "source": {
      "catalogPath": "src/data/spells.js",
      "catalogSha256": "3358a2e1afcbc340dbafd92e45e39a7d2d0a24fed5c0719a3d233263ce530078",
      "catalogKey": "conjure-sky-fortress",
      "original": {
        "name": "Conjure Sky Fortress",
        "level": 8,
        "resonanceRank": 8,
        "school": "Conjuration",
        "schools": [
          "Conjuration"
        ],
        "placements": [
          {
            "name": "Conjure Sky Fortress",
            "school": "Conjuration",
            "level": 8,
            "summary": "Floating platform appears, grants high ground or ranged cover."
          }
        ],
        "classLevels": {
          "Druid": 8,
          "Mage": 8,
          "Wizard": 8
        },
        "classRanks": {
          "Druid": 8,
          "Mage": 8,
          "Wizard": 8
        },
        "classLearnLevels": {
          "Druid": 15,
          "Mage": 15,
          "Wizard": 15
        },
        "classSchools": {
          "Druid": "Conjuration",
          "Mage": "Conjuration",
          "Wizard": "Conjuration"
        },
        "castingTime": "Not specified in current rulebook",
        "range": "Not specified in current rulebook",
        "components": "Not specified in current rulebook",
        "duration": "Not specified in current rulebook",
        "description": "Floating platform appears, grants high ground or ranged cover.",
        "alternateSummaries": [],
        "classes": [
          "Druid",
          "Mage",
          "Wizard"
        ],
        "status": "canon",
        "source": "Player Rulebook — Spell Lists"
      },
      "corePath": "data/public/Decennium_Descent_Core_Systems_Data_v2_Known_Descent.json",
      "coreSha256": "50c3e9683349e93192191381ab6354ca7d675a24fcc9bb9b039c23e67fecca4f",
      "coreEntries": [
        {
          "index": 186,
          "original": {
            "school": "Conjuration",
            "level": 8,
            "name": "Conjure Sky Fortress",
            "effect": "Floating platform appears, grants high ground or ranged cover.",
            "source_paragraph": 9210,
            "casting_time": "1 action",
            "range": "120 feet",
            "duration": "Instantaneous",
            "components": "V, S, F",
            "resolution": "Automatic or opposed as described",
            "tags": [
              "Summoning"
            ],
            "rp_cost": 21
          }
        }
      ],
      "possibleHistoricalAliases": []
    },
    "reviewFlags": [
      "Core resolution requires an explicit operational interpretation",
      "Not selectable in this spell playtest packet until individual operational review"
    ]
  },
  "common": {
    "scope": "NEW authorship in this return applies only to the five listed identities. Preserve each complete native card/class-access envelope unchanged, including blocked source status and operational=null. Accepted comparisons remain closed at their exact recorded scopes; current backing bytes and historical525/323 headings do not expand them. This is data-only proposed static authorship, not a runtime, human-play, balance, cosmology, content-rating, release or domain-closure claim.",
    "casting": "Ordinary Action,120ft,V/S/F,rank8/base21RP, native class rank/level/school rows exactly. Require actual acquisition/book/preparation, available Action, components, perception, line of effect, lawful target and full occupied-volume fit. A focus must actually be accessible and S a free hand or an actual exception; V audible speech. No unprinted material price or generic Overcast. Known failure rejects before commitment; hidden later failure consumes a legally committed cast without replacement targets or revealing hidden facts. Range refers to the chosen origin; the whole created body/structure must also have actually known legal space and unobstructed formation, never intersect a creature or existing solid.",
    "payment": "Read Dissonance before casting. Limit=max(4,2+PB+max(0,casting modifier)); ranked costs gain+1/+2/+3 at limit/limit+3/limit+6; ordinary rank1+ blocked at limit+6 absent a real specific traumatic exception. Commit actual costs and Action once. Ordinary rank6–9 baseD2,rank1–5 baseD1,rank0 baseD0; successive same-family casts add Refrain1/2/3 capped3; different family resets to0, idle/weapon turns do not. Wizard first distinct prepared family in an encounter waives baseD only, not Refrain. Native pet actions, healing waves, weapon operation and maintenance are not new spell casts. New parent concentration ends old owner concentration at commitment before counter/outcome; no refund or restoration on failure. Shifting Fortress is expressly nonconcentration.",
    "checks": "Actual spell attacks d20+PB+actual casting modifier; source-specific modifiers only. Natural1 misses,natural20 hits and doubles dice only. Saves DC8+PB+modifier and actual save proficiency/conditions. Current passive defenses, cover and reaction scopes remain exact. Use real Counterspell/dispel acquisition, range, paid cost and check, not names or guessed ranks. Ordinary Wizard class Counterspell is automatic at2,rank1,cost3RP,recharge2,Reaction,60ft,INT+PB versus10+2*targetrank. Wizard class Dispel remains rank3/printed3RP/check10+targetrank; no conversion to acquired Greater Dispel.",
    "ready": "Accepted Ready exception: preparation spends actual Action/cost/components/strain once, starts held concentration and exposes the counter window then. Choose legal target/placement/form/operator list at release and revalidate before spending one Reaction. Invalid/declined occurrences may wait until next regular own-turn START; no refund. Release creates no second cast,cadence or counter window. Its effect duration starts at manifestation. A concentration parent continues the hold; otherwise the Ready hold ends after resolution. No structure can be placed through occupants to provide free boarding.",
    "clocks": "Use original regular START/END markers and stable phase/application sequence. Absolute expiry wins before new events at equality. Existing clocks keep virtual6second markers through initiative changes, extra turns, absence or death; do not multiply opportunities. Source-ending and damage-root callbacks finish under their actual causal order. Five-round Shifting Fortress has the explicit source-START convention below, not a substituted60seconds.",
    "geometryAndCustody": "Bodies have actual whole-body boxes/poses and mass, not point placeholders. Use actual sight versus location versus LoE; no ray through opaque solid solely because an origin is visible. Every real item retains unique ID,owner,custody,weight,Load,condition and charges. Intrinsic conjured gear/ammunition is not transferable stock. Real carried cargo settles at its actual location on ending, or records a real pending placement if no lawful support exists; no teleport to a former anchor. Unsupported real bodies/cargo use accepted Falling: start now; first descent at END of enclosing regular slot next round, or most recent completed slot if between turns, then6second steps up to300ft. Impact min(10,floor(uncontrolledDistance/20))d6,positive actual damage causes Prone. No invented crushing or free slow fall.",
    "ownership": "Store creator,parent source,current controller,actual acting body and damage/healing dealer separately. Companion damage belongs to the pet; actual structure weapon damage belongs to its firing operator, not building/creator. Root Null flag samples that actual dealer at creation; transfers inherit and later independent attacks create new roots. Objects still take ordinary object damage under Null. No corpse, XP,loot,RP,water,ingredient,harvest or class-proc farm follows from these creations. Actual independent source exceptions retain their own narrow scope.",
    "holds": "All absent actual faction/champion/profile, physical geometry/material/support, equipment/weapon proficiency, source access, healing/repair eligibility and topology facts remain whole-case or branch holds. New finite spell profiles and numbers below are explicitly authored specifications, not recovered bestiary/building content or positive campaign examples. A conditional fixture does not discharge its hold."
  },
  "companionRules": null,
  "rules": {
    "profile": {
      "authorship": "NEW bounded profile,not a literal fortress settlement",
      "geometry": {
        "deckFeet": [
          20,
          20
        ],
        "deckThicknessFeet": 1,
        "anchor": "center of upper walking surface; deck solid relative x/y[-10,+10],z[-1,0]",
        "parapet": "one fixed selected N/E/S/W edge;North solid local x[-10,10],y[9.5,10],z[0,3];rotate by90degree increments for other sides;all solid volume included in preflight",
        "occupiedVolume": "deck+one parapet only; open air elsewhere; no rooms,canopy,weapons,stairs or elevator"
      },
      "massLb": 1000,
      "AC": 15,
      "structuralHP": 120,
      "capacity": {
        "externalPounds": 4000,
        "externalLoad": 40,
        "includes": "all real occupants body+equipment,containers and cargo exactly once; its own intrinsic mass excluded from cargo cap but retained for world support predicates"
      },
      "damage": "NEW noncreature object. Legal physical/fire/cold/lightning/necrotic and other applicable object damage use actual source/defenses; no implied force-wall immunity. Poison/psychic damage cannot harm this unthinking unpoisonable manifestation as an explicit profile choice. PositiveHP damage leaves geometry intact;0 ends the entire source. Other real source-granted geometry changes require their actual scope/physical facts.",
      "repair": "No automatic living healing,Mending,vehicle repair or HP reset. A genuinely applicable explicit repair source is required; absent evidence,repair branch held."
    },
    "creationAndDuration": "NEW reconcile native Instantaneous with one60elapsedsecond concentration platform after manifestation. Choose fixed horizontal anchor and one parapet orientation within120ft, actual clear whole solid volume,all bearing/occupant fit and reachable formation LoE. A valid clear unsupported airborne space is permitted because this source supplies magical support; range is not free access through a wall or arbitrary altitude. Create it empty; no body lifts,free boarding,instant relocation or displacement. One platform per creator; new concentration commitment ends old platform before outcome, releasing real occupants/cargo under their actual support states.",
    "accessAndCover": "Actual creatures,friend or foe, may enter via real walking/climbing/jumping/flight/adjacent support permitted by their own sources; this spell grants no ladder,stairs,jump,flight or safe descent. Occupants must fit and pay actual movement/action costs. High ground means the real elevation/lines and possible clear views; no universal to-hit bonus or advantage. The chosen parapet can provide actual half-cover+2AC/DEXsave when its real geometry supplies that cover; stronger actual3/4cover+5 or total obstruction uses the current best-only rule,never add+2/+5. Wrong-side/above rays can give no cover. Trace attacks from their actual actor/muzzle and areas from their actual origin; a platform is not an automatic ally-only protective aura.",
    "fixedSupport": "NEW spatially fixed world anchor/orientation for its entire surviving existence; no pilot,movement,Dash,lift,travel or ride-home operation. Magic supports the platform in air only while source remains. External load exceeding either4000lb or40Load ends the platform immediately after the real load-changing event,with no invented collision/crushing damage. Unknown mass/Load/support/carry permissions hold the dependent event; do not invent a loading crane or teleport cargo.",
    "endingAndSuppression": "NEW full sustaining-source suppression that actually affects any occupied solid part ends this entire platform source,not a paused body. This is a Sky-platform-only chosen endpoint; it is not generic antimagic behavior and does not import Wall of Force panel rules. No resumption after the source ends. Narrow independent rider suppression acts only on that rider. Structural0,expiry,concentration ending,dismissal or actual removal also erases only the created deck/parapet. Real occupants and cargo keep their exact coordinates,HP,condition,custody and motion; actual support elsewhere prevents Falling,otherwise start accepted Falling at that instant. No free evacuation,slow descent,salvage,corpse or recreated items."
  },
  "questionIds": [
    "SS8-Q01",
    "SS8-K01",
    "SS8-K02",
    "SS8-K03",
    "SS8-X01",
    "SS8-X02"
  ]
}
```

## shifting-fortress

```json
{
  "id": "shifting-fortress",
  "authorship": "NEW spell-local authored operational proposal",
  "nativeUnchanged": {
    "id": "shifting-fortress",
    "name": "Shifting Fortress",
    "schools": [
      "Transmutation"
    ],
    "status": "blocked-pending-operational-review",
    "visibility": "public-source-review",
    "classAccess": {
      "Druid": {
        "rank": 8,
        "minimumClassLevel": 15,
        "school": "Transmutation",
        "baseRpCost": 21
      },
      "Mage": {
        "rank": 8,
        "minimumClassLevel": 15,
        "school": "Transmutation",
        "baseRpCost": 21
      },
      "Wizard": {
        "rank": 8,
        "minimumClassLevel": 15,
        "school": "Transmutation",
        "baseRpCost": 21
      }
    },
    "operational": null,
    "additionalRpCost": 0,
    "source": {
      "catalogPath": "src/data/spells.js",
      "catalogSha256": "3358a2e1afcbc340dbafd92e45e39a7d2d0a24fed5c0719a3d233263ce530078",
      "catalogKey": "shifting-fortress",
      "original": {
        "name": "Shifting Fortress",
        "level": 8,
        "resonanceRank": 8,
        "school": "Transmutation",
        "schools": [
          "Transmutation"
        ],
        "placements": [
          {
            "name": "Shifting Fortress",
            "school": "Transmutation",
            "level": 8,
            "summary": "Conjure mobile stone building with siege weapons; lasts 5 rounds."
          }
        ],
        "classLevels": {
          "Druid": 8,
          "Mage": 8,
          "Wizard": 8
        },
        "classRanks": {
          "Druid": 8,
          "Mage": 8,
          "Wizard": 8
        },
        "classLearnLevels": {
          "Druid": 15,
          "Mage": 15,
          "Wizard": 15
        },
        "classSchools": {
          "Druid": "Transmutation",
          "Mage": "Transmutation",
          "Wizard": "Transmutation"
        },
        "castingTime": "Not specified in current rulebook",
        "range": "Not specified in current rulebook",
        "components": "Not specified in current rulebook",
        "duration": "Not specified in current rulebook",
        "description": "Conjure mobile stone building with siege weapons; lasts 5 rounds.",
        "alternateSummaries": [],
        "classes": [
          "Druid",
          "Mage",
          "Wizard"
        ],
        "status": "canon",
        "source": "Player Rulebook — Spell Lists"
      },
      "corePath": "data/public/Decennium_Descent_Core_Systems_Data_v2_Known_Descent.json",
      "coreSha256": "50c3e9683349e93192191381ab6354ca7d675a24fcc9bb9b039c23e67fecca4f",
      "coreEntries": [
        {
          "index": 809,
          "original": {
            "school": "Transmutation",
            "level": 8,
            "name": "Shifting Fortress",
            "effect": "Conjure mobile stone building with siege weapons; lasts 5 rounds.",
            "source_paragraph": 9983,
            "casting_time": "1 action",
            "range": "120 feet",
            "duration": "Instantaneous",
            "components": "V, S, F",
            "resolution": "Automatic or opposed as described",
            "tags": [
              "Summoning"
            ],
            "rp_cost": 21
          }
        }
      ],
      "possibleHistoricalAliases": []
    },
    "reviewFlags": [
      "Core resolution requires an explicit operational interpretation",
      "Not selectable in this spell playtest packet until individual operational review"
    ]
  },
  "common": {
    "scope": "NEW authorship in this return applies only to the five listed identities. Preserve each complete native card/class-access envelope unchanged, including blocked source status and operational=null. Accepted comparisons remain closed at their exact recorded scopes; current backing bytes and historical525/323 headings do not expand them. This is data-only proposed static authorship, not a runtime, human-play, balance, cosmology, content-rating, release or domain-closure claim.",
    "casting": "Ordinary Action,120ft,V/S/F,rank8/base21RP, native class rank/level/school rows exactly. Require actual acquisition/book/preparation, available Action, components, perception, line of effect, lawful target and full occupied-volume fit. A focus must actually be accessible and S a free hand or an actual exception; V audible speech. No unprinted material price or generic Overcast. Known failure rejects before commitment; hidden later failure consumes a legally committed cast without replacement targets or revealing hidden facts. Range refers to the chosen origin; the whole created body/structure must also have actually known legal space and unobstructed formation, never intersect a creature or existing solid.",
    "payment": "Read Dissonance before casting. Limit=max(4,2+PB+max(0,casting modifier)); ranked costs gain+1/+2/+3 at limit/limit+3/limit+6; ordinary rank1+ blocked at limit+6 absent a real specific traumatic exception. Commit actual costs and Action once. Ordinary rank6–9 baseD2,rank1–5 baseD1,rank0 baseD0; successive same-family casts add Refrain1/2/3 capped3; different family resets to0, idle/weapon turns do not. Wizard first distinct prepared family in an encounter waives baseD only, not Refrain. Native pet actions, healing waves, weapon operation and maintenance are not new spell casts. New parent concentration ends old owner concentration at commitment before counter/outcome; no refund or restoration on failure. Shifting Fortress is expressly nonconcentration.",
    "checks": "Actual spell attacks d20+PB+actual casting modifier; source-specific modifiers only. Natural1 misses,natural20 hits and doubles dice only. Saves DC8+PB+modifier and actual save proficiency/conditions. Current passive defenses, cover and reaction scopes remain exact. Use real Counterspell/dispel acquisition, range, paid cost and check, not names or guessed ranks. Ordinary Wizard class Counterspell is automatic at2,rank1,cost3RP,recharge2,Reaction,60ft,INT+PB versus10+2*targetrank. Wizard class Dispel remains rank3/printed3RP/check10+targetrank; no conversion to acquired Greater Dispel.",
    "ready": "Accepted Ready exception: preparation spends actual Action/cost/components/strain once, starts held concentration and exposes the counter window then. Choose legal target/placement/form/operator list at release and revalidate before spending one Reaction. Invalid/declined occurrences may wait until next regular own-turn START; no refund. Release creates no second cast,cadence or counter window. Its effect duration starts at manifestation. A concentration parent continues the hold; otherwise the Ready hold ends after resolution. No structure can be placed through occupants to provide free boarding.",
    "clocks": "Use original regular START/END markers and stable phase/application sequence. Absolute expiry wins before new events at equality. Existing clocks keep virtual6second markers through initiative changes, extra turns, absence or death; do not multiply opportunities. Source-ending and damage-root callbacks finish under their actual causal order. Five-round Shifting Fortress has the explicit source-START convention below, not a substituted60seconds.",
    "geometryAndCustody": "Bodies have actual whole-body boxes/poses and mass, not point placeholders. Use actual sight versus location versus LoE; no ray through opaque solid solely because an origin is visible. Every real item retains unique ID,owner,custody,weight,Load,condition and charges. Intrinsic conjured gear/ammunition is not transferable stock. Real carried cargo settles at its actual location on ending, or records a real pending placement if no lawful support exists; no teleport to a former anchor. Unsupported real bodies/cargo use accepted Falling: start now; first descent at END of enclosing regular slot next round, or most recent completed slot if between turns, then6second steps up to300ft. Impact min(10,floor(uncontrolledDistance/20))d6,positive actual damage causes Prone. No invented crushing or free slow fall.",
    "ownership": "Store creator,parent source,current controller,actual acting body and damage/healing dealer separately. Companion damage belongs to the pet; actual structure weapon damage belongs to its firing operator, not building/creator. Root Null flag samples that actual dealer at creation; transfers inherit and later independent attacks create new roots. Objects still take ordinary object damage under Null. No corpse, XP,loot,RP,water,ingredient,harvest or class-proc farm follows from these creations. Actual independent source exceptions retain their own narrow scope.",
    "holds": "All absent actual faction/champion/profile, physical geometry/material/support, equipment/weapon proficiency, source access, healing/repair eligibility and topology facts remain whole-case or branch holds. New finite spell profiles and numbers below are explicitly authored specifications, not recovered bestiary/building content or positive campaign examples. A conditional fixture does not discharge its hold."
  },
  "companionRules": null,
  "rules": {
    "profile": {
      "authorship": "NEW complete spell-local mobile stone chassis and two weapons; no recovered siege-engine statblock",
      "geometry": {
        "buildingBoxFeet": [
          20,
          20,
          10.5
        ],
        "anchor": "center of bottom support plane; local x/y[-10,+10],z[0,10.5]",
        "floor": "solid z[0,0.5]; interior floor z0.5",
        "roof": "solid z[10,10.5]",
        "walls": "0.5ft thick around four sides; internal clear x/y[-9.5,+9.5],z[0.5,10]",
        "door": "west wall x[-10,-9.5],y[-3,+3],z[0.5,7.5] open passage; no conjured lock/door leaf",
        "entryRamp": "integral6ft-wide ramp extending local x[-15,-10],y[-3,+3],rising0→0.5; included in all swept fit and creation space",
        "weaponBays": "two integral emplacements occupy local x[6,9],y[-6,-4] and[4,6],z[0.5,4.5]; actual operators cannot overlap them",
        "ports": "east wall apertures centered y−5/+5,z4;2ft wide,2ft tall; fixed muzzle local(10.5,±5,4). Each solid barrel local x[9,10.5],y[center−0.25,center+0.25],z[3.75,4.25] is included in all creation/swept bounds; total envelope including ramp/barrels x[-15,10.5],y[-10,10],z[0,10.5].",
        "helm": "interior operator access near local(−5,+5,0.5),requires actual reachable hands and line/control of mechanism",
        "noExtra": "no roof access stairs,secret tunnels,extra rooms,free beds,inventory,mounts or inhabitants"
      },
      "massLb": 20000,
      "AC": 18,
      "hullHP": 240,
      "supportHP": {
        "NW": 40,
        "NE": 40,
        "SW": 40,
        "SE": 40
      },
      "weaponHP": {
        "left": 40,
        "right": 40
      },
      "speedFeet": 20,
      "capacity": {
        "externalPounds": 16000,
        "externalLoad": 120
      },
      "material": "NEW manifested stone physical response: object,unthinking/unpoisonable,poison/psychic ineffective; other legally applicable damage follows actual source defenses,without default resistance,damage threshold,magic immunity or generic siege-double damage. Mass is an authored magical-profile value,not a real-world density calculation.",
      "componentDamage": "An attack selects one actual legal hull/support/weapon component. Apply damage only to that selected pool,not all pools or duplicate hull damage. Positive hull/supportHP does not create unspecified holes. A support0 or hull0 ends whole source; a weapon0 disables only that emplacement and its load/aim state; any loaded projectile becomes inert wrecked intrinsic matter recorded until source end,not usable or transferable ammunition;broken intrinsic matter remains part of structure until source ends. No automatic repairs or replenishment.",
      "weapons": {
        "count": 2,
        "kind": "NEW fixed stone-projectile engine,not the equipment Siege Engineer kit",
        "rangeFeet": {
          "normal": 300,
          "long": 900
        },
        "arc": "fixedforward+X hemisphere limited to±45degrees yaw and±30degrees elevation; rotate only aim inside that arc,no building turn/teleport",
        "attack": "d20+actual firing operator DEX modifier; add PB only with an actual specifically applicable proficiency source. No proficiency is granted by this spell or a Siege Engineer kit. Long range applies ordinary disadvantage; actual cover/LoE applies from muzzle.",
        "damage": "one4d10bludgeoning packet,zero flat modifier; genuine attack critical8d10. Legally target one perceived physical creature or object/component; actual defenses remain. Physical projectile is not automatically magical weapon damage.",
        "ammunition": "six unique inseparable intrinsic projectiles per emplacement,12total;no real external ammo accepted by this fixed menu. Loaded projectile belongs to its one bay,never inventory or harvest;ends on resolution,destruction/suppression interception or source expiry. Each actual fire consumes one even on miss/countervailing prevention.",
        "sequence": "three distinct actual operator Actions: LOAD one remaining intrinsic projectile into that empty intact bay; AIM one actually perceived legal target and exact muzzle/target solution; FIRE one loaded validly aimed shot. May be different authorized real operators but each pays an Action and actual reachable station. No combined free load/aim/fire or automatic volley. Loaded state persists while source/bay exists; aim persists only while target solution,muzzle and required visibility/LoE remain unchanged. Source movement,operator-observed loss of solution,suppression or bay destruction clears aim,not spent ammo. Known stale/illegal fire rejects before Action; a hidden changed fact after lawful fire consumes Action/projectile and resolves actual miss/block without revealing hidden facts.",
        "rate": "at most one shot per bay per original owner regular opportunity/numbered round,shared across operators; extra Actions/turns do not reset it. Two bays require their own complete actions/ammo. No independent building turn."
      }
    },
    "creationAndDuration": "NEW use the printed5rounds and no added concentration,despite Core Instantaneous. In initiative count five future original creator regular START markers,excluding the casting START; preserve virtual markers if creator dies,leaves or reorders. Outside initiative use manifestation+30seconds and retain that endpoint if initiative later starts. At equality expire before refresh/voluntary operation. One live Shifting Fortress per creator; successful new establishment ends older source only after verifying the new genuinely clear whole volume,not by using still-occupied old stone as free placement. Failed/countered replacement leaves old nonconcentration source. Range120 selects actual known supported clear formation,including entry ramp,weapons and solid volumes. No people/items spawn inside; existing real people may occupy a pre-existing genuinely clear interior air volume only if complete all-outcome placement proves no free support/lift or solid intersection; default cases create empty and board normally.",
    "operators": "NEW creator plus up to four actually designated willing operator IDs at establishment may operate helm/engines. They need actual physical access,reach,free handling anatomy,perception and available ordinary Actions. Others may enter/use ordinary cover but acquire no machine-control permission; no remote commands. Creator may use an actual Action at the helm to add/replace/revoke one designated operator; this changes no past action/ammo/movement ledger. Existing permissions persist through creator death until source expiry. Control replacement never refreshes budgets. No new equipment/proficiency/weapon content beyond this fixed source menu is granted.",
    "movement": "One authorized operator at helm spends one actual Action to move up to20ft along a declared finite straight level-ground route,at most once per original owner regular opportunity. No Dash,flight,ram,rotation,teleport,climb,step or slope: maximum step0,slope0 for this first finite chassis. Require continuous actual load-bearing support beneath all four supports and whole-base swept clearance for building,ramp,weapons and all external cargo/occupants. No squeezing the rigid building. A known illegal route rejects before Action; hidden new obstruction halts at last legal nonintersecting support,spends Action/opportunity and actual traveled distance,no rewind,crushing,forced overlap or invented damage. Real occupants/cargo at rest on it translate rigidly by the actual displacement,without granting voluntary movement/Action; their own movement budgets remain used. Actual external restraints/tethers/overhang fit may stop it. Movement clears both aims,not load/ammunition/HP.",
    "physicalLifecycle": "Keep actual mass/Load and distinct component pools. Overload of either16000lb or120Load,loss of a required actual supporting surface,a support0,hull0,expiry or real source removal ends the entire created building. This explicit source-local ending prevents an unspecified falling/crushing castle simulation; it grants no protection from the independent real load/support-changing event. Weapon0 alone disables only that bay. No generic creature healing,Mending or vehicle repair permission; an actual source must explicitly apply before any repair,otherwise hold. No generated stone/projectile/weapon salvage or global material-conversion authority.",
    "suppression": "NEW full suppression triggered by operative intersection of any solid part keeps this same physical building,HP,position,cargo and remaining intrinsic ammunition,with source clock advancing. It still occupies space and provides ordinary physical support/cover,unless an actual narrower source says otherwise; locomotion,loading,aiming,firing and source-granted machinery cease. Clear both aim solutions and all pending commands; loaded projectile remains inert in its own bay. No operation or stored shot replays on resumption; later capable operators must pay new real Actions. A fired intrinsic projectile crossing an actual source-qualified suppression/interception volume ends there with its ammo already spent and no hit. Null alone does not disable machinery or make structure damage nonlethal. If source expires or support fails while suppressed,ordinary source ending still occurs.",
    "ending": "Remove only intrinsic building,engines,ramps and projectiles. Real occupants/external cargo retain positions,motion,custody,HP,condition,charges and used turn/actions; do not teleport them to original ground,restore old gear,heal damage or multiply ammunition. Real remaining support prevents Falling; otherwise use accepted Falling from current coordinates. No body/XP/death reward or harvest award. An actual owner recast pays21RP/strain again and never refreshes external items or current-round operation limits."
  },
  "questionIds": [
    "SS8-Q01",
    "SS8-T01",
    "SS8-T02",
    "SS8-T03",
    "SS8-T04",
    "SS8-X01",
    "SS8-X02"
  ]
}
```
