# Psychic Fear7 Director Return182

Authority remains755 applied /93 pending /0 accepted-unapplied in the untouched live index. Separate exact director decision accepts four identities for static authored review only; three remain blocked. No application occurred. Native cards/access and original selections below are preserved. NEW additions remain spell-local.

## phantom-armageddon

Complete proposed payload; per-identity acceptance is in DIRECTOR_DECISION.json.

```json
{
  "accepted": false,
  "applied": false,
  "id": "PF182-PROCEDURE-phantom-armageddon",
  "localProcedure": {
    "information": "Frightened gives disadvantage to attacks/ability checks only while fear source visible and prohibits willing closer movement using actually known source location. Unknown location supplies no tracking direction or new knowledge. Merely recognizing the depiction does not heal necrotic damage or end actual fear. Suppression hides covered fear penalties for the interval; END saves/deadline continue.",
    "lifecycle": "NEW Frightened for three future regular target END markers excluding an in-progress current turn for the maximum-duration count; outside initiative manifestation+18seconds. Initial application has no extra damage later. At each actual regular target END while the record remains, including an in-progress turn's END, WIS against original source DC ends that source's fear on success. If maximum coincides, expire without an unnecessary final save. Marker endpoints remain after source death; no concentration.",
    "resolution": "Each target makes initial WIS. Failure:12d10 necrotic; success:floor(12d10/2). Resolve each complete damage event first. On failure and survival separately admit Frightened of the caster, subject to fear immunity. No Stunned, forced flight or real apocalyptic phenomenon.",
    "selection": "RP9-Q04 A; Q05 A; no concentration.",
    "targeting": "KEEP native60ft placement range and60ft radius. NEW choose a perceived legal point within60ft with source line of effect; snapshot all perceived designated enemies intersecting its full3D60ft sphere with point-to-body line of effect. No arbitrary enemy cap. Caster position is not substituted for the declared point."
  },
  "nativeBookBindingsUnchanged": [
    {
      "catalogPlacement": {
        "level": 9,
        "name": "Phantom Armageddon",
        "school": "Necromancy",
        "summary": "60 ft radius, 12d10 necrotic and fear to all enemies."
      },
      "currentBookRow": {
        "exactText": "Phantom Armageddon – 60 ft radius, 12d10 necrotic and fear to all enemies.",
        "level": 9,
        "line": 9611,
        "name": "Phantom Armageddon",
        "school": "Necromancy",
        "summary": "60 ft radius, 12d10 necrotic and fear to all enemies."
      },
      "spellId": "phantom-armageddon",
      "summaryDifferencePreserved": false
    }
  ],
  "nativeCardAndAccessUnchanged": {
    "additionalRpCost": 0,
    "classAccess": {
      "Cleric": {
        "baseRpCost": 26,
        "minimumClassLevel": 17,
        "rank": 9,
        "school": "Necromancy"
      },
      "Druid": {
        "baseRpCost": 26,
        "minimumClassLevel": 17,
        "rank": 9,
        "school": "Necromancy"
      },
      "Wizard": {
        "baseRpCost": 26,
        "minimumClassLevel": 17,
        "rank": 9,
        "school": "Necromancy"
      }
    },
    "id": "phantom-armageddon",
    "name": "Phantom Armageddon",
    "operational": null,
    "reviewFlags": [
      "Core resolution requires an explicit operational interpretation",
      "Not selectable in this spell playtest packet until individual operational review"
    ],
    "schools": [
      "Necromancy"
    ],
    "source": {
      "catalogKey": "phantom-armageddon",
      "catalogPath": "src/data/spells.js",
      "catalogSha256": "3358a2e1afcbc340dbafd92e45e39a7d2d0a24fed5c0719a3d233263ce530078",
      "coreEntries": [
        {
          "index": 718,
          "original": {
            "casting_time": "1 action",
            "components": "V, S, F",
            "duration": "Instantaneous",
            "effect": "60 ft radius, 12d10 necrotic and fear to all enemies.",
            "level": 9,
            "name": "Phantom Armageddon",
            "range": "60 feet",
            "resolution": "Automatic or opposed as described",
            "rp_cost": 26,
            "school": "Necromancy",
            "source_paragraph": 9869,
            "tags": [
              "Damage",
              "Fear"
            ]
          }
        }
      ],
      "corePath": "data/public/Decennium_Descent_Core_Systems_Data_v2_Known_Descent.json",
      "coreSha256": "50c3e9683349e93192191381ab6354ca7d675a24fcc9bb9b039c23e67fecca4f",
      "original": {
        "alternateSummaries": [],
        "castingTime": "Not specified in current rulebook",
        "classLearnLevels": {
          "Cleric": 17,
          "Druid": 17,
          "Wizard": 17
        },
        "classLevels": {
          "Cleric": 9,
          "Druid": 9,
          "Wizard": 9
        },
        "classRanks": {
          "Cleric": 9,
          "Druid": 9,
          "Wizard": 9
        },
        "classSchools": {
          "Cleric": "Necromancy",
          "Druid": "Necromancy",
          "Wizard": "Necromancy"
        },
        "classes": [
          "Cleric",
          "Druid",
          "Wizard"
        ],
        "components": "Not specified in current rulebook",
        "description": "60 ft radius, 12d10 necrotic and fear to all enemies.",
        "duration": "Not specified in current rulebook",
        "level": 9,
        "name": "Phantom Armageddon",
        "placements": [
          {
            "level": 9,
            "name": "Phantom Armageddon",
            "school": "Necromancy",
            "summary": "60 ft radius, 12d10 necrotic and fear to all enemies."
          }
        ],
        "range": "Not specified in current rulebook",
        "resonanceRank": 9,
        "school": "Necromancy",
        "schools": [
          "Necromancy"
        ],
        "source": "Player Rulebook — Spell Lists",
        "status": "canon"
      },
      "possibleHistoricalAliases": []
    },
    "status": "blocked-pending-operational-review",
    "visibility": "public-source-review"
  },
  "originalQuestionsUnchanged": [
    {
      "decisionSelected": false,
      "exactSourceOrConflict": "All actual access is rank9/minimumclasslevel17/base26RP; Psychic Scream has three placements and Weird two, but actual routes do not grant every school.",
      "id": "RP9-Q01",
      "options": "A: preserve actual class-school routes with expressly selected shared or school-specific payloads. B: propose an access correction only with complete source evidence.",
      "recommendationAndConsequences": "Recommend A. Psychic Scream is Mage Evocation and Wizard Enchantment; its Illusion placement supplies history, not an acquired third route. Weird is actually Wizard Enchantment despite two placements. Phantom Armageddon alone includes Cleric/Druid/Wizard Necromancy. Others are Wizard-only. Keep actual repertoire, Action,V/S/F,price/cadence and Ready commitment; no generic upcast or multiple casts from multiple placements.",
      "spellIds": [
        "phantom-armageddon",
        "phantom-cataclysm",
        "psychic-scream",
        "frightful-sovereignty",
        "mass-phantom-killer",
        "weird",
        "reality-break"
      ]
    },
    {
      "decisionSelected": false,
      "exactSourceOrConflict": "All enemies is explicit; only Phantom Armageddon gives a60-foot radius. Core casting ranges do not automatically define other areas.",
      "id": "RP9-Q02",
      "options": "A: explicitly select perceived designated hostile creatures in a specified full3D area. B: an indiscriminate area or other complete information contract with its source reconciliation.",
      "recommendationAndConsequences": "A is a narrow accepted-interface comparison, not automatic authority. Select center/radius separately: Armageddon retains60-foot radius and60-foot placement range; Cataclysm/Sovereignty have120-foot Core range but no stated area. Preserve ALL qualifying enemies without arbitrary caps or post-roll omission. Do not grant objective hidden allegiance detection. Set false hostility, cover, line of effect, allies and caster consequences explicitly.",
      "spellIds": [
        "phantom-armageddon",
        "phantom-cataclysm",
        "frightful-sovereignty"
      ]
    },
    {
      "decisionSelected": false,
      "exactSourceOrConflict": "Psychic,necrotic and force damage,illusion perception,fear,stun and compulsory movement are distinct components.",
      "id": "RP9-Q03",
      "options": "A: expressly extend applicable accepted damage/condition/root clauses per identity. B: identify a concrete contrary source and select a bounded exception.",
      "recommendationAndConsequences": "Keep each actual damage event and original owner/Null root. Damage immunity does not imply mental/fear/stun immunity; Charmed-only immunity is not universal mental immunity. Control admission is spent only for actual full-Action denial. Preserve real saves,temporaryHP,Wounds,death/concentration and effects independently. True Seeing recognises false images but has only its exact source-qualified removal permissions; do not give blanket dispelling or blindness-based mental immunity.",
      "spellIds": [
        "phantom-armageddon",
        "phantom-cataclysm",
        "psychic-scream",
        "frightful-sovereignty",
        "mass-phantom-killer",
        "weird",
        "reality-break"
      ]
    },
    {
      "decisionSelected": false,
      "exactSourceOrConflict": "12d10necrotic and FEAR in60-foot radius have no initial save or outcome split.",
      "id": "RP9-Q04",
      "options": "A: NEW WIS full/half damage and failed-save independent Frightened. B: automatic damage plus WIS fear. C: another fully specified resolution.",
      "recommendationAndConsequences": "Confer on this distinction; A reduces successful-save damage while B preserves an independent full packet. Declare caster-as-fear-source or another actual source before case authorship. Roll exactly12d10 once under the selected shared/per-recipient policy. No actual apocalypse,phantom creature,forced flight or additional damage pulse follows from the name.",
      "spellIds": [
        "phantom-armageddon"
      ]
    },
    {
      "decisionSelected": false,
      "exactSourceOrConflict": "Core Instantaneous cannot supply the duration of admitted fear.",
      "id": "RP9-Q05",
      "options": "A: NEW three-round Frightened with actual END saves and no concentration. B: NEW concentration minute with a fully specified ending cadence. C: another finite fear endpoint.",
      "recommendationAndConsequences": "Choose a source-local lifetime; neither candidate is recovered canon. Retain actual visibility-dependent penalties and approach prohibition. Specify original regular markers,out-of-initiative clock,source death/last known location and independent removal. No secret locator,save replay,automatic fear refresh or restoration of damage after suppression.",
      "spellIds": [
        "phantom-armageddon"
      ]
    },
    {
      "decisionSelected": false,
      "exactSourceOrConflict": "No earlier complete operational examples exist for this group; source preservation does not prove selected semantics.",
      "id": "RP9-Q23",
      "options": "A: after decisions,write at least two complete source-qualified cases per identity plus every substantive school/state variant. B: explicitly hold only genuinely missing content-dependent branches.",
      "recommendationAndConsequences": "Require all native access/repertoire,actual owner/body/resources,source IDs,3D geometry,clocks,full RNG and intermediate/final states. Psychic Scream needs each actual school and positive head-consequence/stun cases with Null/survival branches; Weird needs real captivity; Sovereignty needs real fleeing; Reality Break needs its whole selected secondary effect sequence. Test immunity,hard-control,suppression,extra turns,source death and actual target changes without invented content. Keep source/semantic/arithmetic/engine/human/balance/cosmology/release gates separate.",
      "spellIds": [
        "phantom-armageddon",
        "phantom-cataclysm",
        "psychic-scream",
        "frightful-sovereignty",
        "mass-phantom-killer",
        "weird",
        "reality-break"
      ]
    },
    {
      "decisionSelected": false,
      "exactSourceOrConflict": "Current Control15, illusion and body/life interfaces have scoped rules for denial, private perception, actual motion and retained state; historical accepted-but-unapplied labels are not current authority.",
      "id": "PSY129-ADD02",
      "request": "Resolve actual current index/status and exact procedures before adopting comparisons. Keep private perceived catastrophe separate from world/body state and each damage, fear, stun, flight and source clock separately admitted. Show a real spent hard-control allowance that blocks only covered new denial, actual independent damage, voluntary-budget flight with unknown or blocked safe route, and recurring effects through extra/attached phases and suppression without replay. Use genuine sources for every immunity or removal instead of a blanket mental-defense label.",
      "spellIds": [
        "phantom-armageddon",
        "phantom-cataclysm",
        "frightful-sovereignty",
        "mass-phantom-killer",
        "weird",
        "reality-break"
      ]
    }
  ],
  "qualifications": {
    "balanceApproved": false,
    "canonicalFilesChanged": false,
    "cosmologyApproved": false,
    "domainClosed": false,
    "humanPlaytested": false,
    "releaseApproved": false,
    "runtimeExecuted": false,
    "staticAuthoredReviewOnly": true,
    "suppliedOrHistoricalProgramsExecuted": false
  },
  "repair182Clarifications": {
    "authorship": "NEW spell-local clarifications only; accepted comparison sources remain within exact original scope",
    "budgetAccounting": "Action/BonusAction/Reaction fields are unspent source allowances, not automatic permission to act. Incapacity blocks eligibility without spending those allowances. Actual regular starts refresh and tick recharge even when incapacitated; death is separately marked inactive. Removing incapacity never refunds a spent allowance.",
    "damageDefenses": "Resolve exact paid defense components separately. Sanctify resistance/fear modes do not union. True Seeing recognizes false imagery without canceling separate damage/control. Mind Blank uses its exact accepted psychic/mental spell scope and willingness; no consent is invented for an unconscious target.",
    "heldRequiredCaseIds": [],
    "repairCaseIds": [
      "RANK9PSYCHICFEAR7-180-PHANTOM-ARMAGEDDON-B/actual-hidden-fear-source-no-locator",
      "RANK9PSYCHICFEAR7-180-PHANTOM-ARMAGEDDON-B/actual-necrotic-and-fear-defense-profile",
      "RANK9PSYCHICFEAR7-180-PHANTOM-ARMAGEDDON-B/actual-source-death-original-endpoint",
      "RANK9PSYCHICFEAR7-180-PHANTOM-ARMAGEDDON-B/fear-immunity-only",
      "RANK9PSYCHICFEAR7-180-PHANTOM-ARMAGEDDON-B/necrotic-resistance-only"
    ],
    "sourceQualification": "All new actor builds, conditional dice and geometry are explicit static witnesses. No actual campaign acquisition, creature anatomy, authoritative CR, hidden observer knowledge or runtime availability is created. Accepted comparison status may coexist with blocked catalog runtime selection; current authored index binding controls only its recorded authored scope."
  },
  "sharedProcedure": {
    "commitment": "Action,V/S/F; ordinary range and identity checks precede commitment. Choose school variant and any Reality Break mode before paying. Cast spends once. Area membership is snapshotted at manifestation. Ready pays and resolves cast side effects at setup, holds concentration, expires next actual regular own START, and releases once with a legal Reaction after trigger; targeting occurs then. Effect clocks begin at manifestation; no second cast/cost/strain at release. Source component failure, countering, interruption, replacement or expiry refunds nothing already committed.",
    "control": "Before new Stunned or Unconscious admission, resolve survival, actual condition defenses and source-character/target encounter hard-denial allowance. Spend the combined mark once only upon successful new whole-Action denial. Used allowance blocks that new rider only; independent damage remains. No downgraded substitute control or repeated attempt after immunity/suppression. Existing admitted control may resume for its remaining original duration if a suppressor ends; no new costs, mark, duration or fresh side-effect such as another item drop. Full Stunned and Unconscious semantics apply, including ending concentration, no Actions/BonusAction/Reaction, movement prohibition, specified automatic saves and attack consequences. Frightened/flight/slow are not whole-Action denial.",
    "eligibility": "Before commitment bind actor identity, class level, acquired repertoire/prepared matrix, actual class-school row, component availability and focus custody, current life/body, Action eligibility, rank gate and RP. Rank9 minimum class17 and native base26 RP in every route. School placement alone gives no acquired route. Revalidate target/range/line of effect at manifestation. A paid legal cast whose targets later fail remains spent; an illegal precommit attempt spends nothing.",
    "geometryAndInformation": "NEW for these enemy-selective spells: designated enemies are creatures the caster currently perceives and regards as hostile; no objective allegiance oracle. Snapshot ALL qualifying designated enemies in the declared geometry without optional post-roll omissions. A mistaken hostile is affected. A concealed unknown enemy is not discovered. Allies/self are excluded unless perceived hostile designation actually applies; Weird instead snapshots every creature including self, allies and unperceived bodies in its area with source line of effect. Use actual occupied body geometry/full 3D, range and total-cover segments. Unknown scene/body/cover facts hold the affected admission, not invented coordinates.",
    "packet": "One independent damage roll per target per damage event, declared before outcomes, not one shared roll across targets. Binary saves use actual DC/modifiers and advantage/disadvantage, no generic natural1/20 save exception. Save half rounds down before defenses; resistance once, immunity separately, then tempHP, normalHP, instant death, Wound save/injury, zero-HP lifecycle, concentration and living riders in accepted order. No event silently selects Wound/injury/death dice. Hold at the next unavailable input. Surviving damage is never rolled back by rider resistance, awakening, illusion recognition, dispel, suppression, expiry or source death.",
    "phaseBridge": "For target-bound recurring records use actual regular target START damage and END saves. A source-supported companion without an independent regular turn uses its single attached controller-phase START/END once per controller regular turn; controller changes cannot add an exposure or move an existing expiry. Extra/attached actions confer no extra periodic marker. Outside initiative use initial packet then six-second START/END opportunity pairs (packet then save); transition maps each first unresolved opportunity to the next lawful marker without duplicating exposure. Actual grant, controller and phase must be bound; missing genuine extra-turn/companion evidence is held.",
    "qualifications": "No runtime execution, human play, balance judgment, cosmology decision, domain closure or release approval. No world-ending, new planes, summoned beings, memory extraction, hidden knowledge, creature anatomy, campaign immunity, acquisition or revival authorization follows from these names or authored fixtures.",
    "recurringFamily": "NEW explicit local extension of the P20 family/exposure interface for Mass Phantom Killer and Weird only: one packet per named family/recipient/actual numbered round, across owners and including an initial packet. Earliest active eligible application wins; ties use application order then immutable source ID. Mark the family opportunity before defense/HP resolution; losing due applications lose that opportunity. Suppressed sources lose their own due packet, cannot bank it, but do not consume another active source's opportunity. Independent ending WIS saves survive suppression. Family histories survive recasts/ownership copies. Mass Phantom Killer, Weird and Greater Phantasmal Killer are three distinct families.",
    "resources": "Use actual RP, Dissonance, Refrain, surcharges, class discounts and active passives. Base strain rank9=2; Wizard first distinct prepared underlying family=0 base only. Subsequent immediate same-name casts add capped Refrain1/2/3. No generic Overcast. First-cast exceptions never reset by copies, changing school, Ready release, suppression or new recipients. Keep resource history. No assumed reductions or kill-resource farm.",
    "roots": "Every cast has an immutable source owner, class/school, rank, component roots and target admissions. Child damage retains original root, funding, type and Null provenance; a Null-qualified hit preserves its actual recipient lifecycle restriction and cannot acquire a final-death/head-destruction side path. Damage, private perception, body consequence, fear, stun, sleep, voluntary flight and forced displacement are separate records. A source covering only one component affects only that component. No unsourced generic mental immunity or all-effects dispel.",
    "scope": "NEW PF181 spell-local authored selections for exactly the seven IDs. Native text/access is copied intact in each procedure. Proposed overrides of Instantaneous recurrence metadata and missing saves/durations are labeled; no global authority is asserted.",
    "termination": "Concentration ends on actual failure, incapacitation, death, voluntary ending or replacement unless an acquired specific exception applies. For non-concentration target conditions source death does not itself reset/erase their finite virtual endpoints. Target final death removes living conditions, not physical remains or ledger. Dispel ends only its eligible selected source root. Suppression blocks covered active components while clocks, mandatory saves and independently scheduled actors continue; no missed pulse, flight, forced displacement or head consequence replays on resumption. At an absolute maximum deadline expire before a coincident packet.",
    "timing": "Each actor owns its actual regular START/END calendar; spell damage opportunities are separately registered. At START expire due start effects and Ready, refresh Reaction and regular budgets, tick recharge, process legal absolute recovery and required death save before spell start effects and voluntary decisions. END resolves due damage/saves/maintenance then end expiry. Six-second virtual source/target markers preserve old durations across initiative change/removal; extra Actions/extra turns never create a regular marker, recharge tick or death save. A pulse is not an actor turn. Do not use one universal pulse rule."
  },
  "spellId": "phantom-armageddon",
  "status": "revised authored proposal; per-identity decision in DIRECTOR_DECISION.json"
}
```

## phantom-cataclysm

Complete proposed payload; per-identity acceptance is in DIRECTOR_DECISION.json.

```json
{
  "accepted": false,
  "applied": false,
  "id": "PF182-PROCEDURE-phantom-cataclysm",
  "localProcedure": {
    "lifecycle": "Stunned expires at the original caster's next future regular START, or manifestation+6seconds outside initiative; no concentration or repeated save. Preserve original virtual marker after initiative reorder or caster death. A used hard-control mark does not prevent psychic damage or grant a weaker control fallback. Source suppression never retries initial stun. True Seeing only its exact sourced permission, not automatic damage/rider erasure.",
    "resolution": "Each target WIS; failure12d10 psychic, success half. Resolve damage/lifecycle fully, then only failed living targets may receive the one-round Stunned rider subject to actual defense and shared hard-denial allowance. Private belief that the world ends changes perception only; no real world, terrain, creature, item or plane destruction and no grant of secret imagery.",
    "selection": "RP9-Q06 A; Q07 A.",
    "targeting": "KEEP120ft range. NEW explicitly define caster-centered120ft full3D sphere at manifestation, snapshot ALL perceived designated enemies with line of effect. This radius is new local authorship resolving missing area, not recovered Core geometry."
  },
  "nativeBookBindingsUnchanged": [
    {
      "catalogPlacement": {
        "level": 9,
        "name": "Phantom Cataclysm",
        "school": "Illusion",
        "summary": "Enemies believe world ends: 12d10 psychic, stunned 1 round."
      },
      "currentBookRow": {
        "exactText": "Phantom Cataclysm – Enemies believe world ends: 12d10 psychic, stunned 1 round.",
        "level": 9,
        "line": 9483,
        "name": "Phantom Cataclysm",
        "school": "Illusion",
        "summary": "Enemies believe world ends: 12d10 psychic, stunned 1 round."
      },
      "spellId": "phantom-cataclysm",
      "summaryDifferencePreserved": false
    }
  ],
  "nativeCardAndAccessUnchanged": {
    "additionalRpCost": 0,
    "classAccess": {
      "Wizard": {
        "baseRpCost": 26,
        "minimumClassLevel": 17,
        "rank": 9,
        "school": "Illusion"
      }
    },
    "id": "phantom-cataclysm",
    "name": "Phantom Cataclysm",
    "operational": null,
    "reviewFlags": [
      "Core resolution requires an explicit operational interpretation",
      "Not selectable in this spell playtest packet until individual operational review"
    ],
    "schools": [
      "Illusion"
    ],
    "source": {
      "catalogKey": "phantom-cataclysm",
      "catalogPath": "src/data/spells.js",
      "catalogSha256": "3358a2e1afcbc340dbafd92e45e39a7d2d0a24fed5c0719a3d233263ce530078",
      "coreEntries": [
        {
          "index": 615,
          "original": {
            "casting_time": "1 action",
            "components": "V, S, F",
            "duration": "Instantaneous",
            "effect": "Enemies believe world ends: 12d10 psychic, stunned 1 round.",
            "level": 9,
            "name": "Phantom Cataclysm",
            "range": "120 feet",
            "resolution": "Automatic or opposed as described",
            "rp_cost": 26,
            "school": "Illusion",
            "source_paragraph": 9741,
            "tags": [
              "Damage"
            ]
          }
        }
      ],
      "corePath": "data/public/Decennium_Descent_Core_Systems_Data_v2_Known_Descent.json",
      "coreSha256": "50c3e9683349e93192191381ab6354ca7d675a24fcc9bb9b039c23e67fecca4f",
      "original": {
        "alternateSummaries": [],
        "castingTime": "Not specified in current rulebook",
        "classLearnLevels": {
          "Wizard": 17
        },
        "classLevels": {
          "Wizard": 9
        },
        "classRanks": {
          "Wizard": 9
        },
        "classSchools": {
          "Wizard": "Illusion"
        },
        "classes": [
          "Wizard"
        ],
        "components": "Not specified in current rulebook",
        "description": "Enemies believe world ends: 12d10 psychic, stunned 1 round.",
        "duration": "Not specified in current rulebook",
        "level": 9,
        "name": "Phantom Cataclysm",
        "placements": [
          {
            "level": 9,
            "name": "Phantom Cataclysm",
            "school": "Illusion",
            "summary": "Enemies believe world ends: 12d10 psychic, stunned 1 round."
          }
        ],
        "range": "Not specified in current rulebook",
        "resonanceRank": 9,
        "school": "Illusion",
        "schools": [
          "Illusion"
        ],
        "source": "Player Rulebook — Spell Lists",
        "status": "canon"
      },
      "possibleHistoricalAliases": []
    },
    "status": "blocked-pending-operational-review",
    "visibility": "public-source-review"
  },
  "originalQuestionsUnchanged": [
    {
      "decisionSelected": false,
      "exactSourceOrConflict": "All actual access is rank9/minimumclasslevel17/base26RP; Psychic Scream has three placements and Weird two, but actual routes do not grant every school.",
      "id": "RP9-Q01",
      "options": "A: preserve actual class-school routes with expressly selected shared or school-specific payloads. B: propose an access correction only with complete source evidence.",
      "recommendationAndConsequences": "Recommend A. Psychic Scream is Mage Evocation and Wizard Enchantment; its Illusion placement supplies history, not an acquired third route. Weird is actually Wizard Enchantment despite two placements. Phantom Armageddon alone includes Cleric/Druid/Wizard Necromancy. Others are Wizard-only. Keep actual repertoire, Action,V/S/F,price/cadence and Ready commitment; no generic upcast or multiple casts from multiple placements.",
      "spellIds": [
        "phantom-armageddon",
        "phantom-cataclysm",
        "psychic-scream",
        "frightful-sovereignty",
        "mass-phantom-killer",
        "weird",
        "reality-break"
      ]
    },
    {
      "decisionSelected": false,
      "exactSourceOrConflict": "All enemies is explicit; only Phantom Armageddon gives a60-foot radius. Core casting ranges do not automatically define other areas.",
      "id": "RP9-Q02",
      "options": "A: explicitly select perceived designated hostile creatures in a specified full3D area. B: an indiscriminate area or other complete information contract with its source reconciliation.",
      "recommendationAndConsequences": "A is a narrow accepted-interface comparison, not automatic authority. Select center/radius separately: Armageddon retains60-foot radius and60-foot placement range; Cataclysm/Sovereignty have120-foot Core range but no stated area. Preserve ALL qualifying enemies without arbitrary caps or post-roll omission. Do not grant objective hidden allegiance detection. Set false hostility, cover, line of effect, allies and caster consequences explicitly.",
      "spellIds": [
        "phantom-armageddon",
        "phantom-cataclysm",
        "frightful-sovereignty"
      ]
    },
    {
      "decisionSelected": false,
      "exactSourceOrConflict": "Psychic,necrotic and force damage,illusion perception,fear,stun and compulsory movement are distinct components.",
      "id": "RP9-Q03",
      "options": "A: expressly extend applicable accepted damage/condition/root clauses per identity. B: identify a concrete contrary source and select a bounded exception.",
      "recommendationAndConsequences": "Keep each actual damage event and original owner/Null root. Damage immunity does not imply mental/fear/stun immunity; Charmed-only immunity is not universal mental immunity. Control admission is spent only for actual full-Action denial. Preserve real saves,temporaryHP,Wounds,death/concentration and effects independently. True Seeing recognises false images but has only its exact source-qualified removal permissions; do not give blanket dispelling or blindness-based mental immunity.",
      "spellIds": [
        "phantom-armageddon",
        "phantom-cataclysm",
        "psychic-scream",
        "frightful-sovereignty",
        "mass-phantom-killer",
        "weird",
        "reality-break"
      ]
    },
    {
      "decisionSelected": false,
      "exactSourceOrConflict": "Enemies believe the world ends;12d10psychic and Stunned1round. Initial save and sensory admission are unspecified.",
      "id": "RP9-Q06",
      "options": "A: NEW WIS full/half psychic and failed-save independent Stunned. B: initial WIS negates both. C: another exact outcome preserving both native components.",
      "recommendationAndConsequences": "Preserve real psychic damage and the subjective catastrophe. Mental impression need not require ordinary hearing/vision unless expressly selected. No real world destruction,authenticated prophecy or extracted private memories. State whether damage precedes stun and apply actual target-death/survival eligibility; used hard-control history blocks only new stun,without inventing a soft fallback.",
      "spellIds": [
        "phantom-cataclysm"
      ]
    },
    {
      "decisionSelected": false,
      "exactSourceOrConflict": "One round of Stunned requires an exact endpoint and source-specific illusion interaction.",
      "id": "RP9-Q07",
      "options": "A: original caster next future regular START or6seconds outside initiative,no concentration. B: target next future regular END or another explicitly selected one-round marker.",
      "recommendationAndConsequences": "Recommend A by exact Vision of Ruin comparison,not a silent global extension. No repeat save is printed. Preserve the original marker through absence,extra turns and suppression. Recognition does not reverse real damage; determine actual True Seeing applicability from its accepted wording. No stun retry after initial prevention or resource/Action refund.",
      "spellIds": [
        "phantom-cataclysm"
      ]
    },
    {
      "decisionSelected": false,
      "exactSourceOrConflict": "No earlier complete operational examples exist for this group; source preservation does not prove selected semantics.",
      "id": "RP9-Q23",
      "options": "A: after decisions,write at least two complete source-qualified cases per identity plus every substantive school/state variant. B: explicitly hold only genuinely missing content-dependent branches.",
      "recommendationAndConsequences": "Require all native access/repertoire,actual owner/body/resources,source IDs,3D geometry,clocks,full RNG and intermediate/final states. Psychic Scream needs each actual school and positive head-consequence/stun cases with Null/survival branches; Weird needs real captivity; Sovereignty needs real fleeing; Reality Break needs its whole selected secondary effect sequence. Test immunity,hard-control,suppression,extra turns,source death and actual target changes without invented content. Keep source/semantic/arithmetic/engine/human/balance/cosmology/release gates separate.",
      "spellIds": [
        "phantom-armageddon",
        "phantom-cataclysm",
        "psychic-scream",
        "frightful-sovereignty",
        "mass-phantom-killer",
        "weird",
        "reality-break"
      ]
    },
    {
      "decisionSelected": false,
      "exactSourceOrConflict": "Current Control15, illusion and body/life interfaces have scoped rules for denial, private perception, actual motion and retained state; historical accepted-but-unapplied labels are not current authority.",
      "id": "PSY129-ADD02",
      "request": "Resolve actual current index/status and exact procedures before adopting comparisons. Keep private perceived catastrophe separate from world/body state and each damage, fear, stun, flight and source clock separately admitted. Show a real spent hard-control allowance that blocks only covered new denial, actual independent damage, voluntary-budget flight with unknown or blocked safe route, and recurring effects through extra/attached phases and suppression without replay. Use genuine sources for every immunity or removal instead of a blanket mental-defense label.",
      "spellIds": [
        "phantom-armageddon",
        "phantom-cataclysm",
        "frightful-sovereignty",
        "mass-phantom-killer",
        "weird",
        "reality-break"
      ]
    }
  ],
  "qualifications": {
    "balanceApproved": false,
    "canonicalFilesChanged": false,
    "cosmologyApproved": false,
    "domainClosed": false,
    "humanPlaytested": false,
    "releaseApproved": false,
    "runtimeExecuted": false,
    "staticAuthoredReviewOnly": true,
    "suppliedOrHistoricalProgramsExecuted": false
  },
  "repair182Clarifications": {
    "authorship": "NEW spell-local clarifications only; accepted comparison sources remain within exact original scope",
    "budgetAccounting": "Action/BonusAction/Reaction fields are unspent source allowances, not automatic permission to act. Incapacity blocks eligibility without spending those allowances. Actual regular starts refresh and tick recharge even when incapacitated; death is separately marked inactive. Removing incapacity never refunds a spent allowance.",
    "damageDefenses": "Resolve exact paid defense components separately. Sanctify resistance/fear modes do not union. True Seeing recognizes false imagery without canceling separate damage/control. Mind Blank uses its exact accepted psychic/mental spell scope and willingness; no consent is invented for an unconscious target.",
    "heldRequiredCaseIds": [],
    "repairCaseIds": [
      "RANK9PSYCHICFEAR7-180-PHANTOM-CATACLYSM-B/actual-mind-blank-before-admission",
      "RANK9PSYCHICFEAR7-180-PHANTOM-CATACLYSM-B/actual-source-death-original-endpoint",
      "RANK9PSYCHICFEAR7-180-PHANTOM-CATACLYSM-B/bastion-damage-immunity-does-not-prevent-stun",
      "RANK9PSYCHICFEAR7-180-PHANTOM-CATACLYSM-B/true-seeing-survival-body-transition"
    ],
    "sourceQualification": "All new actor builds, conditional dice and geometry are explicit static witnesses. No actual campaign acquisition, creature anatomy, authoritative CR, hidden observer knowledge or runtime availability is created. Accepted comparison status may coexist with blocked catalog runtime selection; current authored index binding controls only its recorded authored scope."
  },
  "sharedProcedure": {
    "commitment": "Action,V/S/F; ordinary range and identity checks precede commitment. Choose school variant and any Reality Break mode before paying. Cast spends once. Area membership is snapshotted at manifestation. Ready pays and resolves cast side effects at setup, holds concentration, expires next actual regular own START, and releases once with a legal Reaction after trigger; targeting occurs then. Effect clocks begin at manifestation; no second cast/cost/strain at release. Source component failure, countering, interruption, replacement or expiry refunds nothing already committed.",
    "control": "Before new Stunned or Unconscious admission, resolve survival, actual condition defenses and source-character/target encounter hard-denial allowance. Spend the combined mark once only upon successful new whole-Action denial. Used allowance blocks that new rider only; independent damage remains. No downgraded substitute control or repeated attempt after immunity/suppression. Existing admitted control may resume for its remaining original duration if a suppressor ends; no new costs, mark, duration or fresh side-effect such as another item drop. Full Stunned and Unconscious semantics apply, including ending concentration, no Actions/BonusAction/Reaction, movement prohibition, specified automatic saves and attack consequences. Frightened/flight/slow are not whole-Action denial.",
    "eligibility": "Before commitment bind actor identity, class level, acquired repertoire/prepared matrix, actual class-school row, component availability and focus custody, current life/body, Action eligibility, rank gate and RP. Rank9 minimum class17 and native base26 RP in every route. School placement alone gives no acquired route. Revalidate target/range/line of effect at manifestation. A paid legal cast whose targets later fail remains spent; an illegal precommit attempt spends nothing.",
    "geometryAndInformation": "NEW for these enemy-selective spells: designated enemies are creatures the caster currently perceives and regards as hostile; no objective allegiance oracle. Snapshot ALL qualifying designated enemies in the declared geometry without optional post-roll omissions. A mistaken hostile is affected. A concealed unknown enemy is not discovered. Allies/self are excluded unless perceived hostile designation actually applies; Weird instead snapshots every creature including self, allies and unperceived bodies in its area with source line of effect. Use actual occupied body geometry/full 3D, range and total-cover segments. Unknown scene/body/cover facts hold the affected admission, not invented coordinates.",
    "packet": "One independent damage roll per target per damage event, declared before outcomes, not one shared roll across targets. Binary saves use actual DC/modifiers and advantage/disadvantage, no generic natural1/20 save exception. Save half rounds down before defenses; resistance once, immunity separately, then tempHP, normalHP, instant death, Wound save/injury, zero-HP lifecycle, concentration and living riders in accepted order. No event silently selects Wound/injury/death dice. Hold at the next unavailable input. Surviving damage is never rolled back by rider resistance, awakening, illusion recognition, dispel, suppression, expiry or source death.",
    "phaseBridge": "For target-bound recurring records use actual regular target START damage and END saves. A source-supported companion without an independent regular turn uses its single attached controller-phase START/END once per controller regular turn; controller changes cannot add an exposure or move an existing expiry. Extra/attached actions confer no extra periodic marker. Outside initiative use initial packet then six-second START/END opportunity pairs (packet then save); transition maps each first unresolved opportunity to the next lawful marker without duplicating exposure. Actual grant, controller and phase must be bound; missing genuine extra-turn/companion evidence is held.",
    "qualifications": "No runtime execution, human play, balance judgment, cosmology decision, domain closure or release approval. No world-ending, new planes, summoned beings, memory extraction, hidden knowledge, creature anatomy, campaign immunity, acquisition or revival authorization follows from these names or authored fixtures.",
    "recurringFamily": "NEW explicit local extension of the P20 family/exposure interface for Mass Phantom Killer and Weird only: one packet per named family/recipient/actual numbered round, across owners and including an initial packet. Earliest active eligible application wins; ties use application order then immutable source ID. Mark the family opportunity before defense/HP resolution; losing due applications lose that opportunity. Suppressed sources lose their own due packet, cannot bank it, but do not consume another active source's opportunity. Independent ending WIS saves survive suppression. Family histories survive recasts/ownership copies. Mass Phantom Killer, Weird and Greater Phantasmal Killer are three distinct families.",
    "resources": "Use actual RP, Dissonance, Refrain, surcharges, class discounts and active passives. Base strain rank9=2; Wizard first distinct prepared underlying family=0 base only. Subsequent immediate same-name casts add capped Refrain1/2/3. No generic Overcast. First-cast exceptions never reset by copies, changing school, Ready release, suppression or new recipients. Keep resource history. No assumed reductions or kill-resource farm.",
    "roots": "Every cast has an immutable source owner, class/school, rank, component roots and target admissions. Child damage retains original root, funding, type and Null provenance; a Null-qualified hit preserves its actual recipient lifecycle restriction and cannot acquire a final-death/head-destruction side path. Damage, private perception, body consequence, fear, stun, sleep, voluntary flight and forced displacement are separate records. A source covering only one component affects only that component. No unsourced generic mental immunity or all-effects dispel.",
    "scope": "NEW PF181 spell-local authored selections for exactly the seven IDs. Native text/access is copied intact in each procedure. Proposed overrides of Instantaneous recurrence metadata and missing saves/durations are labeled; no global authority is asserted.",
    "termination": "Concentration ends on actual failure, incapacitation, death, voluntary ending or replacement unless an acquired specific exception applies. For non-concentration target conditions source death does not itself reset/erase their finite virtual endpoints. Target final death removes living conditions, not physical remains or ledger. Dispel ends only its eligible selected source root. Suppression blocks covered active components while clocks, mandatory saves and independently scheduled actors continue; no missed pulse, flight, forced displacement or head consequence replays on resumption. At an absolute maximum deadline expire before a coincident packet.",
    "timing": "Each actor owns its actual regular START/END calendar; spell damage opportunities are separately registered. At START expire due start effects and Ready, refresh Reaction and regular budgets, tick recharge, process legal absolute recovery and required death save before spell start effects and voluntary decisions. END resolves due damage/saves/maintenance then end expiry. Six-second virtual source/target markers preserve old durations across initiative change/removal; extra Actions/extra turns never create a regular marker, recharge tick or death save. A pulse is not an actor turn. Do not use one universal pulse rule."
  },
  "spellId": "phantom-cataclysm",
  "status": "revised authored proposal; per-identity decision in DIRECTOR_DECISION.json"
}
```

## psychic-scream

Complete proposed payload; per-identity acceptance is in DIRECTOR_DECISION.json.

```json
{
  "accepted": false,
  "applied": false,
  "id": "PF182-PROCEDURE-psychic-scream",
  "localProcedure": {
    "enchantment": "NEW conditional physical rider: only when this single damage event actually causes final death, after every valid survival/Null/lifecycle rule, destroy every currently present destructible head of that final body whose physical content record explicitly permits this consequence. If no destructible head exists, no change. Multihead anatomy is not inferred; enumerate only evidenced heads. No extra damage, splash, spell-copy, resource or new death event. No living severance, no second death, no guessed current-form reversion order. Missing anatomy/current-form/lifecycle facts hold the entire positive head branch. Remains and equipment custody are retained with explicit destroyed/intact parts; future revival must satisfy its own unchanged body/time/soul constraints.",
    "evocation": "On initial failed INT and survival, admit Stunned through the original caster's next future regular START (outside initiative+6seconds), with the full shared condition/hard-control gates. No repeated save or concentration. Successful save has no stun. No Enchantment head rider is acquired by Mage/Evocation.",
    "independence": "A source proving psychic immunity prevents damage, not automatically a failed-save Evocation stun. A real stun immunity prevents stun, not damage. Head consequence requires final death by this packet; death prevention, Null final-death restriction or transformation survival cannot be bypassed by the rider.",
    "resolution": "Each selected target independently INT save: failure14d6 psychic; success half. No intelligence-score threshold or hearing requirement is added. Resolve damage, defenses/tempHP, Wound/death and survival before variant rider. Mage psychic damage is not its elemental Focus and creates no Nuke Chain credit. No automatic blend of both native benefits.",
    "selection": "RP9-Q08 A; Q09 A(INT); Q10 A; Q11 A.",
    "targeting": "KEEP Core120ft, up to10 distinct perceived creatures with line of effect. NEW choose any creature, not enemies only. Variant is locked to actual acquired route at commitment: Wizard/Enchantment or Mage/Evocation. Preserve the Illusion book placement verbatim as historical source; it supplies no class access row."
  },
  "nativeBookBindingsUnchanged": [
    {
      "catalogPlacement": {
        "level": 9,
        "name": "Psychic Scream",
        "school": "Enchantment",
        "summary": "Up to 10 creatures take 14d6 psychic damage and heads might explode."
      },
      "currentBookRow": {
        "exactText": "Psychic Scream – Up to 10 creatures take 14d6 psychic damage and heads might explode.",
        "level": 9,
        "line": 9227,
        "name": "Psychic Scream",
        "school": "Enchantment",
        "summary": "Up to 10 creatures take 14d6 psychic damage and heads might explode."
      },
      "spellId": "psychic-scream",
      "summaryDifferencePreserved": false
    },
    {
      "catalogPlacement": {
        "level": 9,
        "name": "Psychic Scream",
        "school": "Evocation",
        "summary": "14d6 psychic damage to up to 10 creatures, stuns them."
      },
      "currentBookRow": {
        "exactText": "Psychic Scream – 14d6 psychic damage to up to 10 creatures, stuns them.",
        "level": 9,
        "line": 9357,
        "name": "Psychic Scream",
        "school": "Evocation",
        "summary": "14d6 psychic damage to up to 10 creatures, stuns them."
      },
      "spellId": "psychic-scream",
      "summaryDifferencePreserved": false
    },
    {
      "catalogPlacement": {
        "level": 9,
        "name": "Psychic Scream",
        "school": "Illusion",
        "summary": "Up to 10 creatures take 14d6 psychic damage and heads might explode."
      },
      "currentBookRow": {
        "exactText": "Psychic Scream – Up to 10 creatures take 14d6 psychic damage and heads might explode.",
        "level": 9,
        "line": 9488,
        "name": "Psychic Scream",
        "school": "Illusion",
        "summary": "Up to 10 creatures take 14d6 psychic damage and heads might explode."
      },
      "spellId": "psychic-scream",
      "summaryDifferencePreserved": false
    }
  ],
  "nativeCardAndAccessUnchanged": {
    "additionalRpCost": 0,
    "classAccess": {
      "Mage": {
        "baseRpCost": 26,
        "minimumClassLevel": 17,
        "rank": 9,
        "school": "Evocation"
      },
      "Wizard": {
        "baseRpCost": 26,
        "minimumClassLevel": 17,
        "rank": 9,
        "school": "Enchantment"
      }
    },
    "id": "psychic-scream",
    "name": "Psychic Scream",
    "operational": null,
    "reviewFlags": [
      "Core resolution requires an explicit operational interpretation",
      "Not selectable in this spell playtest packet until individual operational review"
    ],
    "schools": [
      "Enchantment",
      "Evocation",
      "Illusion"
    ],
    "source": {
      "catalogKey": "psychic-scream",
      "catalogPath": "src/data/spells.js",
      "catalogSha256": "3358a2e1afcbc340dbafd92e45e39a7d2d0a24fed5c0719a3d233263ce530078",
      "coreEntries": [
        {
          "index": 409,
          "original": {
            "casting_time": "1 action",
            "components": "V, S, F",
            "duration": "Instantaneous",
            "effect": "Up to 10 creatures take 14d6 psychic damage and heads might explode.",
            "level": 9,
            "name": "Psychic Scream",
            "range": "120 feet",
            "resolution": "Automatic or opposed as described",
            "rp_cost": 26,
            "school": "Enchantment",
            "source_paragraph": 9485,
            "tags": [
              "Damage"
            ]
          }
        },
        {
          "index": 514,
          "original": {
            "casting_time": "1 action",
            "components": "V, S, F",
            "duration": "Instantaneous",
            "effect": "14d6 psychic damage to up to 10 creatures, stuns them.",
            "level": 9,
            "name": "Psychic Scream",
            "range": "120 feet",
            "resolution": "Automatic or opposed as described",
            "rp_cost": 26,
            "school": "Evocation",
            "source_paragraph": 9615,
            "tags": [
              "Damage"
            ]
          }
        },
        {
          "index": 620,
          "original": {
            "casting_time": "1 action",
            "components": "V, S, F",
            "duration": "Instantaneous",
            "effect": "Up to 10 creatures take 14d6 psychic damage and heads might explode.",
            "level": 9,
            "name": "Psychic Scream",
            "range": "120 feet",
            "resolution": "Automatic or opposed as described",
            "rp_cost": 26,
            "school": "Illusion",
            "source_paragraph": 9746,
            "tags": [
              "Damage"
            ]
          }
        }
      ],
      "corePath": "data/public/Decennium_Descent_Core_Systems_Data_v2_Known_Descent.json",
      "coreSha256": "50c3e9683349e93192191381ab6354ca7d675a24fcc9bb9b039c23e67fecca4f",
      "original": {
        "alternateSummaries": [
          "14d6 psychic damage to up to 10 creatures, stuns them."
        ],
        "castingTime": "Not specified in current rulebook",
        "classLearnLevels": {
          "Mage": 17,
          "Wizard": 17
        },
        "classLevels": {
          "Mage": 9,
          "Wizard": 9
        },
        "classRanks": {
          "Mage": 9,
          "Wizard": 9
        },
        "classSchools": {
          "Mage": "Evocation",
          "Wizard": "Enchantment"
        },
        "classes": [
          "Mage",
          "Wizard"
        ],
        "components": "Not specified in current rulebook",
        "description": "Up to 10 creatures take 14d6 psychic damage and heads might explode.",
        "duration": "Not specified in current rulebook",
        "level": 9,
        "name": "Psychic Scream",
        "placements": [
          {
            "level": 9,
            "name": "Psychic Scream",
            "school": "Enchantment",
            "summary": "Up to 10 creatures take 14d6 psychic damage and heads might explode."
          },
          {
            "level": 9,
            "name": "Psychic Scream",
            "school": "Evocation",
            "summary": "14d6 psychic damage to up to 10 creatures, stuns them."
          },
          {
            "level": 9,
            "name": "Psychic Scream",
            "school": "Illusion",
            "summary": "Up to 10 creatures take 14d6 psychic damage and heads might explode."
          }
        ],
        "range": "Not specified in current rulebook",
        "resonanceRank": 9,
        "school": "Enchantment",
        "schools": [
          "Enchantment",
          "Evocation",
          "Illusion"
        ],
        "source": "Player Rulebook — Spell Lists",
        "status": "canon"
      },
      "possibleHistoricalAliases": []
    },
    "status": "blocked-pending-operational-review",
    "visibility": "public-source-review"
  },
  "originalQuestionsUnchanged": [
    {
      "decisionSelected": false,
      "exactSourceOrConflict": "All actual access is rank9/minimumclasslevel17/base26RP; Psychic Scream has three placements and Weird two, but actual routes do not grant every school.",
      "id": "RP9-Q01",
      "options": "A: preserve actual class-school routes with expressly selected shared or school-specific payloads. B: propose an access correction only with complete source evidence.",
      "recommendationAndConsequences": "Recommend A. Psychic Scream is Mage Evocation and Wizard Enchantment; its Illusion placement supplies history, not an acquired third route. Weird is actually Wizard Enchantment despite two placements. Phantom Armageddon alone includes Cleric/Druid/Wizard Necromancy. Others are Wizard-only. Keep actual repertoire, Action,V/S/F,price/cadence and Ready commitment; no generic upcast or multiple casts from multiple placements.",
      "spellIds": [
        "phantom-armageddon",
        "phantom-cataclysm",
        "psychic-scream",
        "frightful-sovereignty",
        "mass-phantom-killer",
        "weird",
        "reality-break"
      ]
    },
    {
      "decisionSelected": false,
      "exactSourceOrConflict": "Psychic,necrotic and force damage,illusion perception,fear,stun and compulsory movement are distinct components.",
      "id": "RP9-Q03",
      "options": "A: expressly extend applicable accepted damage/condition/root clauses per identity. B: identify a concrete contrary source and select a bounded exception.",
      "recommendationAndConsequences": "Keep each actual damage event and original owner/Null root. Damage immunity does not imply mental/fear/stun immunity; Charmed-only immunity is not universal mental immunity. Control admission is spent only for actual full-Action denial. Preserve real saves,temporaryHP,Wounds,death/concentration and effects independently. True Seeing recognises false images but has only its exact source-qualified removal permissions; do not give blanket dispelling or blindness-based mental immunity.",
      "spellIds": [
        "phantom-armageddon",
        "phantom-cataclysm",
        "psychic-scream",
        "frightful-sovereignty",
        "mass-phantom-killer",
        "weird",
        "reality-break"
      ]
    },
    {
      "decisionSelected": false,
      "exactSourceOrConflict": "Enchantment/Illusion say heads might explode; Evocation says stuns them. All print up to10creatures and14d6psychic.",
      "id": "RP9-Q08",
      "options": "A: preserve actual class-school variants: Evocation stun; Enchantment head-destruction clause. B: explicitly unify all clauses into one selected procedure while recording the added cross-route benefits.",
      "recommendationAndConsequences": "Recommend A for source fidelity unless the director selects a justified union. Preserve all three full placements and actual two access routes. Do not discard either rider or import an external familiar INT-save spell. Shared damage/targeting may be reused,but school cannot be switched freely after commitment.",
      "spellIds": [
        "psychic-scream"
      ]
    },
    {
      "decisionSelected": false,
      "exactSourceOrConflict": "Up to10creatures within Core120feet has no printed save,minimum intelligence,creature-type exclusion or hearing gate.",
      "id": "RP9-Q09",
      "options": "A: NEW initial WIS or INT with explicit full/half/none result. B: automatic damage with separate rider admission.",
      "recommendationAndConsequences": "Select actual save and outcome separately for each school if necessary. Choose legal perceived creatures/line of effect before hidden results; no post-roll substitution. No unprinted intelligence threshold or hearing immunity merely from Scream. Keep all14d6 and at most10 distinct targets; state shared versus independent raw dice and actual damage-before-rider order.",
      "spellIds": [
        "psychic-scream"
      ]
    },
    {
      "decisionSelected": false,
      "exactSourceOrConflict": "Heads MIGHT explode supplies a meaningful conditional body consequence but no trigger/probability.",
      "id": "RP9-Q10",
      "options": "A: NEW destruction only after this event actually causes final death of a target with a destructible head. B: a separately specified probabilistic/threshold body consequence with exact mortality rules.",
      "recommendationAndConsequences": "Confer on the intended benefit. A preserves remains consequences without making damage a hidden instant-death rider; B must supply exact RNG and protections. Define multiheaded/headless bodies,actually vital heads,replacement forms,death prevention,remaining anatomy,revival prerequisites and actual corpse history. Null nonlethal damage cannot secretly kill through a secondary head-loss loophole. No exploding-head area damage or unrelated headless immunity to psychic damage.",
      "spellIds": [
        "psychic-scream"
      ]
    },
    {
      "decisionSelected": false,
      "exactSourceOrConflict": "Evocation stun has no printed duration or escape cadence.",
      "id": "RP9-Q11",
      "options": "A: NEW one-round Stunned with a precise original marker. B: finite longer Stunned with exact repeat saves.",
      "recommendationAndConsequences": "Choose duration as NEW,apply actual hard-control/immunity admission and record source ownership. Damage immunity does not itself prevent stun. A dead target gets no new living condition; genuine survival replacements must be resolved first. Do not import head-destruction into the Evocation route unless Q08 expressly selects it.",
      "spellIds": [
        "psychic-scream"
      ]
    },
    {
      "decisionSelected": false,
      "exactSourceOrConflict": "No earlier complete operational examples exist for this group; source preservation does not prove selected semantics.",
      "id": "RP9-Q23",
      "options": "A: after decisions,write at least two complete source-qualified cases per identity plus every substantive school/state variant. B: explicitly hold only genuinely missing content-dependent branches.",
      "recommendationAndConsequences": "Require all native access/repertoire,actual owner/body/resources,source IDs,3D geometry,clocks,full RNG and intermediate/final states. Psychic Scream needs each actual school and positive head-consequence/stun cases with Null/survival branches; Weird needs real captivity; Sovereignty needs real fleeing; Reality Break needs its whole selected secondary effect sequence. Test immunity,hard-control,suppression,extra turns,source death and actual target changes without invented content. Keep source/semantic/arithmetic/engine/human/balance/cosmology/release gates separate.",
      "spellIds": [
        "phantom-armageddon",
        "phantom-cataclysm",
        "psychic-scream",
        "frightful-sovereignty",
        "mass-phantom-killer",
        "weird",
        "reality-break"
      ]
    },
    {
      "decisionSelected": false,
      "exactSourceOrConflict": "Native placements differ in substantive riders, while the current class routes select only their actual schools. A partial damage-only completion would lose head consequences, nightmare captivity or secondary effects.",
      "id": "PSY129-ADD01",
      "request": "Preserve all native placements and actually acquired routes. Provide a complete positive Enchantment head-consequence case and separate Evocation stun case for Psychic Scream, with explicit vital/headless/multihead/current-form data or named content holds. For Weird select and fully demonstrate real nightmare captivity, including whether its own psychic damage can wake, distinct sleep/mental/fear defenses and allied exposure. For Reality Break supply the complete selected secondary-effect table/sequence and every genuine branch rather than referring to an unspecified effect list.",
      "spellIds": [
        "psychic-scream",
        "weird",
        "reality-break"
      ]
    }
  ],
  "qualifications": {
    "balanceApproved": false,
    "canonicalFilesChanged": false,
    "cosmologyApproved": false,
    "domainClosed": false,
    "humanPlaytested": false,
    "releaseApproved": false,
    "runtimeExecuted": false,
    "staticAuthoredReviewOnly": true,
    "suppliedOrHistoricalProgramsExecuted": false
  },
  "repair182Clarifications": {
    "authorship": "NEW spell-local clarifications only; accepted comparison sources remain within exact original scope",
    "budgetAccounting": "Action/BonusAction/Reaction fields are unspent source allowances, not automatic permission to act. Incapacity blocks eligibility without spending those allowances. Actual regular starts refresh and tick recharge even when incapacitated; death is separately marked inactive. Removing incapacity never refunds a spent allowance.",
    "damageDefenses": "Resolve exact paid defense components separately. Sanctify resistance/fear modes do not union. True Seeing recognizes false imagery without canceling separate damage/control. Mind Blank uses its exact accepted psychic/mental spell scope and willingness; no consent is invented for an unconscious target.",
    "headHold": "Enchantment positive head consequence and headless/multihead/current-form anatomical branches remain whole-case held. The finite avian form profile supplies no head count, vital-head relation or destructibility facts. Death Ward and Null proofs demonstrate their own source stages only, not the missing head consequence.",
    "heldRequiredCaseIds": [
      "RANK9PSYCHICFEAR7-180-PSYCHIC-SCREAM-B/positive-final-death-head-consequence",
      "RANK9PSYCHICFEAR7-180-PSYCHIC-SCREAM-B/headless-multihead-current-form"
    ],
    "repairCaseIds": [
      "RANK9PSYCHICFEAR7-180-PSYCHIC-SCREAM-B/Null-and-survival-prevention",
      "RANK9PSYCHICFEAR7-180-PSYCHIC-SCREAM-B/null-stable-recovery-1",
      "RANK9PSYCHICFEAR7-180-PSYCHIC-SCREAM-B/null-stable-recovery-2",
      "RANK9PSYCHICFEAR7-180-PSYCHIC-SCREAM-B/null-stable-recovery-3",
      "RANK9PSYCHICFEAR7-180-PSYCHIC-SCREAM-B/null-stable-recovery-4"
    ],
    "sourceQualification": "All new actor builds, conditional dice and geometry are explicit static witnesses. No actual campaign acquisition, creature anatomy, authoritative CR, hidden observer knowledge or runtime availability is created. Accepted comparison status may coexist with blocked catalog runtime selection; current authored index binding controls only its recorded authored scope."
  },
  "sharedProcedure": {
    "commitment": "Action,V/S/F; ordinary range and identity checks precede commitment. Choose school variant and any Reality Break mode before paying. Cast spends once. Area membership is snapshotted at manifestation. Ready pays and resolves cast side effects at setup, holds concentration, expires next actual regular own START, and releases once with a legal Reaction after trigger; targeting occurs then. Effect clocks begin at manifestation; no second cast/cost/strain at release. Source component failure, countering, interruption, replacement or expiry refunds nothing already committed.",
    "control": "Before new Stunned or Unconscious admission, resolve survival, actual condition defenses and source-character/target encounter hard-denial allowance. Spend the combined mark once only upon successful new whole-Action denial. Used allowance blocks that new rider only; independent damage remains. No downgraded substitute control or repeated attempt after immunity/suppression. Existing admitted control may resume for its remaining original duration if a suppressor ends; no new costs, mark, duration or fresh side-effect such as another item drop. Full Stunned and Unconscious semantics apply, including ending concentration, no Actions/BonusAction/Reaction, movement prohibition, specified automatic saves and attack consequences. Frightened/flight/slow are not whole-Action denial.",
    "eligibility": "Before commitment bind actor identity, class level, acquired repertoire/prepared matrix, actual class-school row, component availability and focus custody, current life/body, Action eligibility, rank gate and RP. Rank9 minimum class17 and native base26 RP in every route. School placement alone gives no acquired route. Revalidate target/range/line of effect at manifestation. A paid legal cast whose targets later fail remains spent; an illegal precommit attempt spends nothing.",
    "geometryAndInformation": "NEW for these enemy-selective spells: designated enemies are creatures the caster currently perceives and regards as hostile; no objective allegiance oracle. Snapshot ALL qualifying designated enemies in the declared geometry without optional post-roll omissions. A mistaken hostile is affected. A concealed unknown enemy is not discovered. Allies/self are excluded unless perceived hostile designation actually applies; Weird instead snapshots every creature including self, allies and unperceived bodies in its area with source line of effect. Use actual occupied body geometry/full 3D, range and total-cover segments. Unknown scene/body/cover facts hold the affected admission, not invented coordinates.",
    "packet": "One independent damage roll per target per damage event, declared before outcomes, not one shared roll across targets. Binary saves use actual DC/modifiers and advantage/disadvantage, no generic natural1/20 save exception. Save half rounds down before defenses; resistance once, immunity separately, then tempHP, normalHP, instant death, Wound save/injury, zero-HP lifecycle, concentration and living riders in accepted order. No event silently selects Wound/injury/death dice. Hold at the next unavailable input. Surviving damage is never rolled back by rider resistance, awakening, illusion recognition, dispel, suppression, expiry or source death.",
    "phaseBridge": "For target-bound recurring records use actual regular target START damage and END saves. A source-supported companion without an independent regular turn uses its single attached controller-phase START/END once per controller regular turn; controller changes cannot add an exposure or move an existing expiry. Extra/attached actions confer no extra periodic marker. Outside initiative use initial packet then six-second START/END opportunity pairs (packet then save); transition maps each first unresolved opportunity to the next lawful marker without duplicating exposure. Actual grant, controller and phase must be bound; missing genuine extra-turn/companion evidence is held.",
    "qualifications": "No runtime execution, human play, balance judgment, cosmology decision, domain closure or release approval. No world-ending, new planes, summoned beings, memory extraction, hidden knowledge, creature anatomy, campaign immunity, acquisition or revival authorization follows from these names or authored fixtures.",
    "recurringFamily": "NEW explicit local extension of the P20 family/exposure interface for Mass Phantom Killer and Weird only: one packet per named family/recipient/actual numbered round, across owners and including an initial packet. Earliest active eligible application wins; ties use application order then immutable source ID. Mark the family opportunity before defense/HP resolution; losing due applications lose that opportunity. Suppressed sources lose their own due packet, cannot bank it, but do not consume another active source's opportunity. Independent ending WIS saves survive suppression. Family histories survive recasts/ownership copies. Mass Phantom Killer, Weird and Greater Phantasmal Killer are three distinct families.",
    "resources": "Use actual RP, Dissonance, Refrain, surcharges, class discounts and active passives. Base strain rank9=2; Wizard first distinct prepared underlying family=0 base only. Subsequent immediate same-name casts add capped Refrain1/2/3. No generic Overcast. First-cast exceptions never reset by copies, changing school, Ready release, suppression or new recipients. Keep resource history. No assumed reductions or kill-resource farm.",
    "roots": "Every cast has an immutable source owner, class/school, rank, component roots and target admissions. Child damage retains original root, funding, type and Null provenance; a Null-qualified hit preserves its actual recipient lifecycle restriction and cannot acquire a final-death/head-destruction side path. Damage, private perception, body consequence, fear, stun, sleep, voluntary flight and forced displacement are separate records. A source covering only one component affects only that component. No unsourced generic mental immunity or all-effects dispel.",
    "scope": "NEW PF181 spell-local authored selections for exactly the seven IDs. Native text/access is copied intact in each procedure. Proposed overrides of Instantaneous recurrence metadata and missing saves/durations are labeled; no global authority is asserted.",
    "termination": "Concentration ends on actual failure, incapacitation, death, voluntary ending or replacement unless an acquired specific exception applies. For non-concentration target conditions source death does not itself reset/erase their finite virtual endpoints. Target final death removes living conditions, not physical remains or ledger. Dispel ends only its eligible selected source root. Suppression blocks covered active components while clocks, mandatory saves and independently scheduled actors continue; no missed pulse, flight, forced displacement or head consequence replays on resumption. At an absolute maximum deadline expire before a coincident packet.",
    "timing": "Each actor owns its actual regular START/END calendar; spell damage opportunities are separately registered. At START expire due start effects and Ready, refresh Reaction and regular budgets, tick recharge, process legal absolute recovery and required death save before spell start effects and voluntary decisions. END resolves due damage/saves/maintenance then end expiry. Six-second virtual source/target markers preserve old durations across initiative change/removal; extra Actions/extra turns never create a regular marker, recharge tick or death save. A pulse is not an actor turn. Do not use one universal pulse rule."
  },
  "spellId": "psychic-scream",
  "status": "revised authored proposal; per-identity decision in DIRECTOR_DECISION.json"
}
```

## frightful-sovereignty

Complete proposed payload; per-identity acceptance is in DIRECTOR_DECISION.json.

```json
{
  "accepted": false,
  "applied": false,
  "id": "PF182-PROCEDURE-frightful-sovereignty",
  "localProcedure": {
    "flight": "At each actual regular target START after mandatory processing, if fear/flight is operative, use only that turn's available ordinary movement along the shortest known legal route that strictly increases distance from the actually known fear source. Spend actual terrain costs up to available movement; equal safe routes are chosen by the affected controller before motion. Do not enter known harmful terrain, leave support, pass solid matter or occupied space, force Dash, use an Action/BonusAction/Reaction or invent a route. No known source or safe route means no compulsory motion this opportunity; Frightened's other lawful effects remain. Actions are retained; ordinary opportunity attacks caused by this actual self-propelled movement remain independently resolvable. Unknown opportunity-attack outcomes stop at their own input gate. Forced external displacement is separate and does not spend this budget.",
    "lifecycle": "KEEP three future regular target END endpoints, excluding current in-progress END from the count; outside initiative+18seconds. Native Wizard Enchantment school passive may extend this printed duration by one round only if actually acquired/elected and initial save failed; record four endpoints in that branch. No other silent duration addition. Source death leaves original fear endpoint, but unknown-location flight cannot track the corpse. Suppressed opportunities are lost; a lawful attached companion phase uses only its actual movement and no extra damaging command/turn.",
    "resolution": "Full6d6 psychic independently of WIS. Resolve damage/lifecycle, then initial WIS only governs three-round Frightened of caster plus movement-only flight. Fear immunity prevents the fear/flight component, not psychic damage. No repeated damage and no later escape saves are added.",
    "selection": "RP9-Q12 A; Q13 A.",
    "targeting": "KEEP120ft range. NEW explicitly caster-centered120ft full3D sphere, all perceived designated enemies with line of effect at manifestation; no arbitrary cap and no objective allegiance sensing."
  },
  "nativeBookBindingsUnchanged": [
    {
      "catalogPlacement": {
        "level": 9,
        "name": "Frightful Sovereignty",
        "school": "Enchantment",
        "summary": "All enemies take 6d6 psychic, WIS save or flee for 3 rounds."
      },
      "currentBookRow": {
        "exactText": "Frightful Sovereignty – All enemies take 6d6 psychic, WIS save or flee for 3 rounds.",
        "level": 9,
        "line": 9220,
        "name": "Frightful Sovereignty",
        "school": "Enchantment",
        "summary": "All enemies take 6d6 psychic, WIS save or flee for 3 rounds."
      },
      "spellId": "frightful-sovereignty",
      "summaryDifferencePreserved": false
    }
  ],
  "nativeCardAndAccessUnchanged": {
    "additionalRpCost": 0,
    "classAccess": {
      "Wizard": {
        "baseRpCost": 26,
        "minimumClassLevel": 17,
        "rank": 9,
        "school": "Enchantment"
      }
    },
    "id": "frightful-sovereignty",
    "name": "Frightful Sovereignty",
    "operational": null,
    "reviewFlags": [
      "Not selectable in this spell playtest packet until individual operational review"
    ],
    "schools": [
      "Enchantment"
    ],
    "source": {
      "catalogKey": "frightful-sovereignty",
      "catalogPath": "src/data/spells.js",
      "catalogSha256": "3358a2e1afcbc340dbafd92e45e39a7d2d0a24fed5c0719a3d233263ce530078",
      "coreEntries": [
        {
          "index": 402,
          "original": {
            "casting_time": "1 action",
            "components": "V, S, F",
            "duration": "3 rounds",
            "effect": "All enemies take 6d6 psychic, WIS save or flee for 3 rounds.",
            "level": 9,
            "name": "Frightful Sovereignty",
            "range": "120 feet",
            "resolution": "Wisdom save",
            "rp_cost": 26,
            "school": "Enchantment",
            "source_paragraph": 9478,
            "tags": [
              "Damage",
              "Control",
              "Fear"
            ]
          }
        }
      ],
      "corePath": "data/public/Decennium_Descent_Core_Systems_Data_v2_Known_Descent.json",
      "coreSha256": "50c3e9683349e93192191381ab6354ca7d675a24fcc9bb9b039c23e67fecca4f",
      "original": {
        "alternateSummaries": [],
        "castingTime": "Not specified in current rulebook",
        "classLearnLevels": {
          "Wizard": 17
        },
        "classLevels": {
          "Wizard": 9
        },
        "classRanks": {
          "Wizard": 9
        },
        "classSchools": {
          "Wizard": "Enchantment"
        },
        "classes": [
          "Wizard"
        ],
        "components": "Not specified in current rulebook",
        "description": "All enemies take 6d6 psychic, WIS save or flee for 3 rounds.",
        "duration": "Not specified in current rulebook",
        "level": 9,
        "name": "Frightful Sovereignty",
        "placements": [
          {
            "level": 9,
            "name": "Frightful Sovereignty",
            "school": "Enchantment",
            "summary": "All enemies take 6d6 psychic, WIS save or flee for 3 rounds."
          }
        ],
        "range": "Not specified in current rulebook",
        "resonanceRank": 9,
        "school": "Enchantment",
        "schools": [
          "Enchantment"
        ],
        "source": "Player Rulebook — Spell Lists",
        "status": "canon"
      },
      "possibleHistoricalAliases": []
    },
    "status": "blocked-pending-operational-review",
    "visibility": "public-source-review"
  },
  "originalQuestionsUnchanged": [
    {
      "decisionSelected": false,
      "exactSourceOrConflict": "All actual access is rank9/minimumclasslevel17/base26RP; Psychic Scream has three placements and Weird two, but actual routes do not grant every school.",
      "id": "RP9-Q01",
      "options": "A: preserve actual class-school routes with expressly selected shared or school-specific payloads. B: propose an access correction only with complete source evidence.",
      "recommendationAndConsequences": "Recommend A. Psychic Scream is Mage Evocation and Wizard Enchantment; its Illusion placement supplies history, not an acquired third route. Weird is actually Wizard Enchantment despite two placements. Phantom Armageddon alone includes Cleric/Druid/Wizard Necromancy. Others are Wizard-only. Keep actual repertoire, Action,V/S/F,price/cadence and Ready commitment; no generic upcast or multiple casts from multiple placements.",
      "spellIds": [
        "phantom-armageddon",
        "phantom-cataclysm",
        "psychic-scream",
        "frightful-sovereignty",
        "mass-phantom-killer",
        "weird",
        "reality-break"
      ]
    },
    {
      "decisionSelected": false,
      "exactSourceOrConflict": "All enemies is explicit; only Phantom Armageddon gives a60-foot radius. Core casting ranges do not automatically define other areas.",
      "id": "RP9-Q02",
      "options": "A: explicitly select perceived designated hostile creatures in a specified full3D area. B: an indiscriminate area or other complete information contract with its source reconciliation.",
      "recommendationAndConsequences": "A is a narrow accepted-interface comparison, not automatic authority. Select center/radius separately: Armageddon retains60-foot radius and60-foot placement range; Cataclysm/Sovereignty have120-foot Core range but no stated area. Preserve ALL qualifying enemies without arbitrary caps or post-roll omission. Do not grant objective hidden allegiance detection. Set false hostility, cover, line of effect, allies and caster consequences explicitly.",
      "spellIds": [
        "phantom-armageddon",
        "phantom-cataclysm",
        "frightful-sovereignty"
      ]
    },
    {
      "decisionSelected": false,
      "exactSourceOrConflict": "Psychic,necrotic and force damage,illusion perception,fear,stun and compulsory movement are distinct components.",
      "id": "RP9-Q03",
      "options": "A: expressly extend applicable accepted damage/condition/root clauses per identity. B: identify a concrete contrary source and select a bounded exception.",
      "recommendationAndConsequences": "Keep each actual damage event and original owner/Null root. Damage immunity does not imply mental/fear/stun immunity; Charmed-only immunity is not universal mental immunity. Control admission is spent only for actual full-Action denial. Preserve real saves,temporaryHP,Wounds,death/concentration and effects independently. True Seeing recognises false images but has only its exact source-qualified removal permissions; do not give blanket dispelling or blindness-based mental immunity.",
      "spellIds": [
        "phantom-armageddon",
        "phantom-cataclysm",
        "psychic-scream",
        "frightful-sovereignty",
        "mass-phantom-killer",
        "weird",
        "reality-break"
      ]
    },
    {
      "decisionSelected": false,
      "exactSourceOrConflict": "All enemies TAKE6d6psychic,WISsave OR FLEE3rounds; the grammar does not explicitly halve successful-save damage.",
      "id": "RP9-Q12",
      "options": "A: damage remains full6d6 independently; WIS governs only flight. B: explicitly author save-dependent damage as well.",
      "recommendationAndConsequences": "Recommend A as the closer reading,with one damage event only. Preserve three-round flight,not repeated6d6. Decide whether flight is linked to actual Frightened and how fear immunity affects the instruction. Damage and command defenses remain separate. Current Eyebite Panicked is a useful exact accepted-but-unapplied comparison,not automatically this spell.",
      "spellIds": [
        "frightful-sovereignty"
      ]
    },
    {
      "decisionSelected": false,
      "exactSourceOrConflict": "Flee does not specify movement budget,Action consumption,path safety or escape saves.",
      "id": "RP9-Q13",
      "options": "A: expressly extend Eyebite safe movement-only flight,using available ordinary movement each real regular START. B: mandate Dash or another full Action with explicit hard-control admission and safe-route rules.",
      "recommendationAndConsequences": "Recommend A unless intended scope demands B. Retain actual known fear-source location,legal locomotion/terrain costs,blocked routes and opportunity attacks. No free movement,secret locator,forced suicidal route or spending RP. Fix three-round endpoint and whether new END saves are added; no repeat save is native. An attached companion gets only a real phase,not a fabricated turn. Suppression cannot replay missed flight or refund spent movement.",
      "spellIds": [
        "frightful-sovereignty"
      ]
    },
    {
      "decisionSelected": false,
      "exactSourceOrConflict": "No earlier complete operational examples exist for this group; source preservation does not prove selected semantics.",
      "id": "RP9-Q23",
      "options": "A: after decisions,write at least two complete source-qualified cases per identity plus every substantive school/state variant. B: explicitly hold only genuinely missing content-dependent branches.",
      "recommendationAndConsequences": "Require all native access/repertoire,actual owner/body/resources,source IDs,3D geometry,clocks,full RNG and intermediate/final states. Psychic Scream needs each actual school and positive head-consequence/stun cases with Null/survival branches; Weird needs real captivity; Sovereignty needs real fleeing; Reality Break needs its whole selected secondary effect sequence. Test immunity,hard-control,suppression,extra turns,source death and actual target changes without invented content. Keep source/semantic/arithmetic/engine/human/balance/cosmology/release gates separate.",
      "spellIds": [
        "phantom-armageddon",
        "phantom-cataclysm",
        "psychic-scream",
        "frightful-sovereignty",
        "mass-phantom-killer",
        "weird",
        "reality-break"
      ]
    },
    {
      "decisionSelected": false,
      "exactSourceOrConflict": "Current Control15, illusion and body/life interfaces have scoped rules for denial, private perception, actual motion and retained state; historical accepted-but-unapplied labels are not current authority.",
      "id": "PSY129-ADD02",
      "request": "Resolve actual current index/status and exact procedures before adopting comparisons. Keep private perceived catastrophe separate from world/body state and each damage, fear, stun, flight and source clock separately admitted. Show a real spent hard-control allowance that blocks only covered new denial, actual independent damage, voluntary-budget flight with unknown or blocked safe route, and recurring effects through extra/attached phases and suppression without replay. Use genuine sources for every immunity or removal instead of a blanket mental-defense label.",
      "spellIds": [
        "phantom-armageddon",
        "phantom-cataclysm",
        "frightful-sovereignty",
        "mass-phantom-killer",
        "weird",
        "reality-break"
      ]
    }
  ],
  "qualifications": {
    "balanceApproved": false,
    "canonicalFilesChanged": false,
    "cosmologyApproved": false,
    "domainClosed": false,
    "humanPlaytested": false,
    "releaseApproved": false,
    "runtimeExecuted": false,
    "staticAuthoredReviewOnly": true,
    "suppliedOrHistoricalProgramsExecuted": false
  },
  "repair182Clarifications": {
    "authorship": "NEW spell-local clarifications only; accepted comparison sources remain within exact original scope",
    "budgetAccounting": "Action/BonusAction/Reaction fields are unspent source allowances, not automatic permission to act. Incapacity blocks eligibility without spending those allowances. Actual regular starts refresh and tick recharge even when incapacitated; death is separately marked inactive. Removing incapacity never refunds a spent allowance.",
    "companionFlight": "For a source-supported Mage familiar, freeze the attached checkpoint once within each original controller regular turn. A paid shared command permits one normal Speed allowance and one native damaging/control action. Required away movement consumes that allowance first, then the command action rechecks range/legality and expires if unavailable. No second move, free Dash or free offensive action follows. Without a command, retain only the source default move-near/Dodge; if move-near conflicts with compelled away movement, no legal movement occurs. Third future original attached END ends fear. The checkpoint creates no action/reaction/recharge/death-save grant. An unsupported controller-transfer attempt fails without changing the existing bridge.",
    "damageDefenses": "Resolve exact paid defense components separately. Sanctify resistance/fear modes do not union. True Seeing recognizes false imagery without canceling separate damage/control. Mind Blank uses its exact accepted psychic/mental spell scope and willingness; no consent is invented for an unconscious target.",
    "heldRequiredCaseIds": [],
    "repairCaseIds": [
      "RANK9PSYCHICFEAR7-180-FRIGHTFUL-SOVEREIGNTY-B/actual-fear-immunity",
      "RANK9PSYCHICFEAR7-180-FRIGHTFUL-SOVEREIGNTY-B/attached-companion-phase",
      "RANK9PSYCHICFEAR7-180-FRIGHTFUL-SOVEREIGNTY-B/uncommanded-companion-no-free-movement"
    ],
    "sourceQualification": "All new actor builds, conditional dice and geometry are explicit static witnesses. No actual campaign acquisition, creature anatomy, authoritative CR, hidden observer knowledge or runtime availability is created. Accepted comparison status may coexist with blocked catalog runtime selection; current authored index binding controls only its recorded authored scope."
  },
  "sharedProcedure": {
    "commitment": "Action,V/S/F; ordinary range and identity checks precede commitment. Choose school variant and any Reality Break mode before paying. Cast spends once. Area membership is snapshotted at manifestation. Ready pays and resolves cast side effects at setup, holds concentration, expires next actual regular own START, and releases once with a legal Reaction after trigger; targeting occurs then. Effect clocks begin at manifestation; no second cast/cost/strain at release. Source component failure, countering, interruption, replacement or expiry refunds nothing already committed.",
    "control": "Before new Stunned or Unconscious admission, resolve survival, actual condition defenses and source-character/target encounter hard-denial allowance. Spend the combined mark once only upon successful new whole-Action denial. Used allowance blocks that new rider only; independent damage remains. No downgraded substitute control or repeated attempt after immunity/suppression. Existing admitted control may resume for its remaining original duration if a suppressor ends; no new costs, mark, duration or fresh side-effect such as another item drop. Full Stunned and Unconscious semantics apply, including ending concentration, no Actions/BonusAction/Reaction, movement prohibition, specified automatic saves and attack consequences. Frightened/flight/slow are not whole-Action denial.",
    "eligibility": "Before commitment bind actor identity, class level, acquired repertoire/prepared matrix, actual class-school row, component availability and focus custody, current life/body, Action eligibility, rank gate and RP. Rank9 minimum class17 and native base26 RP in every route. School placement alone gives no acquired route. Revalidate target/range/line of effect at manifestation. A paid legal cast whose targets later fail remains spent; an illegal precommit attempt spends nothing.",
    "geometryAndInformation": "NEW for these enemy-selective spells: designated enemies are creatures the caster currently perceives and regards as hostile; no objective allegiance oracle. Snapshot ALL qualifying designated enemies in the declared geometry without optional post-roll omissions. A mistaken hostile is affected. A concealed unknown enemy is not discovered. Allies/self are excluded unless perceived hostile designation actually applies; Weird instead snapshots every creature including self, allies and unperceived bodies in its area with source line of effect. Use actual occupied body geometry/full 3D, range and total-cover segments. Unknown scene/body/cover facts hold the affected admission, not invented coordinates.",
    "packet": "One independent damage roll per target per damage event, declared before outcomes, not one shared roll across targets. Binary saves use actual DC/modifiers and advantage/disadvantage, no generic natural1/20 save exception. Save half rounds down before defenses; resistance once, immunity separately, then tempHP, normalHP, instant death, Wound save/injury, zero-HP lifecycle, concentration and living riders in accepted order. No event silently selects Wound/injury/death dice. Hold at the next unavailable input. Surviving damage is never rolled back by rider resistance, awakening, illusion recognition, dispel, suppression, expiry or source death.",
    "phaseBridge": "For target-bound recurring records use actual regular target START damage and END saves. A source-supported companion without an independent regular turn uses its single attached controller-phase START/END once per controller regular turn; controller changes cannot add an exposure or move an existing expiry. Extra/attached actions confer no extra periodic marker. Outside initiative use initial packet then six-second START/END opportunity pairs (packet then save); transition maps each first unresolved opportunity to the next lawful marker without duplicating exposure. Actual grant, controller and phase must be bound; missing genuine extra-turn/companion evidence is held.",
    "qualifications": "No runtime execution, human play, balance judgment, cosmology decision, domain closure or release approval. No world-ending, new planes, summoned beings, memory extraction, hidden knowledge, creature anatomy, campaign immunity, acquisition or revival authorization follows from these names or authored fixtures.",
    "recurringFamily": "NEW explicit local extension of the P20 family/exposure interface for Mass Phantom Killer and Weird only: one packet per named family/recipient/actual numbered round, across owners and including an initial packet. Earliest active eligible application wins; ties use application order then immutable source ID. Mark the family opportunity before defense/HP resolution; losing due applications lose that opportunity. Suppressed sources lose their own due packet, cannot bank it, but do not consume another active source's opportunity. Independent ending WIS saves survive suppression. Family histories survive recasts/ownership copies. Mass Phantom Killer, Weird and Greater Phantasmal Killer are three distinct families.",
    "resources": "Use actual RP, Dissonance, Refrain, surcharges, class discounts and active passives. Base strain rank9=2; Wizard first distinct prepared underlying family=0 base only. Subsequent immediate same-name casts add capped Refrain1/2/3. No generic Overcast. First-cast exceptions never reset by copies, changing school, Ready release, suppression or new recipients. Keep resource history. No assumed reductions or kill-resource farm.",
    "roots": "Every cast has an immutable source owner, class/school, rank, component roots and target admissions. Child damage retains original root, funding, type and Null provenance; a Null-qualified hit preserves its actual recipient lifecycle restriction and cannot acquire a final-death/head-destruction side path. Damage, private perception, body consequence, fear, stun, sleep, voluntary flight and forced displacement are separate records. A source covering only one component affects only that component. No unsourced generic mental immunity or all-effects dispel.",
    "scope": "NEW PF181 spell-local authored selections for exactly the seven IDs. Native text/access is copied intact in each procedure. Proposed overrides of Instantaneous recurrence metadata and missing saves/durations are labeled; no global authority is asserted.",
    "termination": "Concentration ends on actual failure, incapacitation, death, voluntary ending or replacement unless an acquired specific exception applies. For non-concentration target conditions source death does not itself reset/erase their finite virtual endpoints. Target final death removes living conditions, not physical remains or ledger. Dispel ends only its eligible selected source root. Suppression blocks covered active components while clocks, mandatory saves and independently scheduled actors continue; no missed pulse, flight, forced displacement or head consequence replays on resumption. At an absolute maximum deadline expire before a coincident packet.",
    "timing": "Each actor owns its actual regular START/END calendar; spell damage opportunities are separately registered. At START expire due start effects and Ready, refresh Reaction and regular budgets, tick recharge, process legal absolute recovery and required death save before spell start effects and voluntary decisions. END resolves due damage/saves/maintenance then end expiry. Six-second virtual source/target markers preserve old durations across initiative change/removal; extra Actions/extra turns never create a regular marker, recharge tick or death save. A pulse is not an actor turn. Do not use one universal pulse rule."
  },
  "spellId": "frightful-sovereignty",
  "status": "revised authored proposal; per-identity decision in DIRECTOR_DECISION.json"
}
```

## mass-phantom-killer

Complete proposed payload; per-identity acceptance is in DIRECTOR_DECISION.json.

```json
{
  "accepted": false,
  "applied": false,
  "id": "PF182-PROCEDURE-mass-phantom-killer",
  "localProcedure": {
    "clock": "Apply explicit recurringFamily and phaseBridge clauses; exact expiry before coincident pulse; no extra packet on entering range, changed hostility, recognition, illusion reveal, extra Action, genuine extra turn, controller change or suppression return.",
    "ending": "Each target WIS at every actual regular END including the upcoming END of an already-started turn, even during suppression; success ends only that owner's application. Target death, removal, source concentration loss or absolute60second expiry ends it. Damage already taken remains. Preserve target lifecycle through form changes; if body identity is uncertain hold affected branch. Separate owners maintain independent concentration/admission/DC/endings despite one shared damage exposure. Recognition/True Seeing does not by itself remove the independently real damage source.",
    "resolution": "NEW concentration up to60elapsed seconds, overriding Instantaneous metadata only for this proposed identity. Failed initial admission attempts6d6 psychic immediately, then actual regular target START attempts6d6 under family.mass-phantom-killer once-per-target/numbered-round exposure. Independent rolls for each target and opportunity. No fear, stun, captivity or instantaneous-death rider from the name.",
    "selection": "RP9-Q14 A; Q15 A; Q16 A.",
    "targeting": "KEEP up to5 perceived designated enemies within120ft, distinct and with line of effect at manifestation. NEW initial WIS per target; success creates no record/damage; failure creates an independent application. No ongoing range or hostility tether and no free retarget."
  },
  "nativeBookBindingsUnchanged": [
    {
      "catalogPlacement": {
        "level": 9,
        "name": "Mass Phantom Killer",
        "school": "Illusion",
        "summary": "Up to 5 enemies take 6d6 psychic/round; WIS save ends."
      },
      "currentBookRow": {
        "exactText": "Mass Phantom Killer – Up to 5 enemies take 6d6 psychic/round; WIS save ends.",
        "level": 9,
        "line": 9477,
        "name": "Mass Phantom Killer",
        "school": "Illusion",
        "summary": "Up to 5 enemies take 6d6 psychic/round; WIS save ends."
      },
      "spellId": "mass-phantom-killer",
      "summaryDifferencePreserved": false
    }
  ],
  "nativeCardAndAccessUnchanged": {
    "additionalRpCost": 0,
    "classAccess": {
      "Wizard": {
        "baseRpCost": 26,
        "minimumClassLevel": 17,
        "rank": 9,
        "school": "Illusion"
      }
    },
    "id": "mass-phantom-killer",
    "name": "Mass Phantom Killer",
    "operational": null,
    "reviewFlags": [
      "Not selectable in this spell playtest packet until individual operational review"
    ],
    "schools": [
      "Illusion"
    ],
    "source": {
      "catalogKey": "mass-phantom-killer",
      "catalogPath": "src/data/spells.js",
      "catalogSha256": "3358a2e1afcbc340dbafd92e45e39a7d2d0a24fed5c0719a3d233263ce530078",
      "coreEntries": [
        {
          "index": 609,
          "original": {
            "casting_time": "1 action",
            "components": "V, S, F",
            "duration": "Instantaneous",
            "effect": "Up to 5 enemies take 6d6 psychic/round; WIS save ends.",
            "level": 9,
            "name": "Mass Phantom Killer",
            "range": "120 feet",
            "resolution": "Wisdom save",
            "rp_cost": 26,
            "school": "Illusion",
            "source_paragraph": 9735,
            "tags": [
              "Damage"
            ]
          }
        }
      ],
      "corePath": "data/public/Decennium_Descent_Core_Systems_Data_v2_Known_Descent.json",
      "coreSha256": "50c3e9683349e93192191381ab6354ca7d675a24fcc9bb9b039c23e67fecca4f",
      "original": {
        "alternateSummaries": [],
        "castingTime": "Not specified in current rulebook",
        "classLearnLevels": {
          "Wizard": 17
        },
        "classLevels": {
          "Wizard": 9
        },
        "classRanks": {
          "Wizard": 9
        },
        "classSchools": {
          "Wizard": "Illusion"
        },
        "classes": [
          "Wizard"
        ],
        "components": "Not specified in current rulebook",
        "description": "Up to 5 enemies take 6d6 psychic/round; WIS save ends.",
        "duration": "Not specified in current rulebook",
        "level": 9,
        "name": "Mass Phantom Killer",
        "placements": [
          {
            "level": 9,
            "name": "Mass Phantom Killer",
            "school": "Illusion",
            "summary": "Up to 5 enemies take 6d6 psychic/round; WIS save ends."
          }
        ],
        "range": "Not specified in current rulebook",
        "resonanceRank": 9,
        "school": "Illusion",
        "schools": [
          "Illusion"
        ],
        "source": "Player Rulebook — Spell Lists",
        "status": "canon"
      },
      "possibleHistoricalAliases": []
    },
    "status": "blocked-pending-operational-review",
    "visibility": "public-source-review"
  },
  "originalQuestionsUnchanged": [
    {
      "decisionSelected": false,
      "exactSourceOrConflict": "All actual access is rank9/minimumclasslevel17/base26RP; Psychic Scream has three placements and Weird two, but actual routes do not grant every school.",
      "id": "RP9-Q01",
      "options": "A: preserve actual class-school routes with expressly selected shared or school-specific payloads. B: propose an access correction only with complete source evidence.",
      "recommendationAndConsequences": "Recommend A. Psychic Scream is Mage Evocation and Wizard Enchantment; its Illusion placement supplies history, not an acquired third route. Weird is actually Wizard Enchantment despite two placements. Phantom Armageddon alone includes Cleric/Druid/Wizard Necromancy. Others are Wizard-only. Keep actual repertoire, Action,V/S/F,price/cadence and Ready commitment; no generic upcast or multiple casts from multiple placements.",
      "spellIds": [
        "phantom-armageddon",
        "phantom-cataclysm",
        "psychic-scream",
        "frightful-sovereignty",
        "mass-phantom-killer",
        "weird",
        "reality-break"
      ]
    },
    {
      "decisionSelected": false,
      "exactSourceOrConflict": "Psychic,necrotic and force damage,illusion perception,fear,stun and compulsory movement are distinct components.",
      "id": "RP9-Q03",
      "options": "A: expressly extend applicable accepted damage/condition/root clauses per identity. B: identify a concrete contrary source and select a bounded exception.",
      "recommendationAndConsequences": "Keep each actual damage event and original owner/Null root. Damage immunity does not imply mental/fear/stun immunity; Charmed-only immunity is not universal mental immunity. Control admission is spent only for actual full-Action denial. Preserve real saves,temporaryHP,Wounds,death/concentration and effects independently. True Seeing recognises false images but has only its exact source-qualified removal permissions; do not give blanket dispelling or blindness-based mental immunity.",
      "spellIds": [
        "phantom-armageddon",
        "phantom-cataclysm",
        "psychic-scream",
        "frightful-sovereignty",
        "mass-phantom-killer",
        "weird",
        "reality-break"
      ]
    },
    {
      "decisionSelected": false,
      "exactSourceOrConflict": "Up to FIVE ENEMIES take6d6psychic PERROUND with WIS SAVE ENDS; Core Instantaneous conflicts.",
      "id": "RP9-Q14",
      "options": "A: NEW concentration up to60seconds using explicitly extended Greater Phantasmal Killer admission/START-pulse/END-save rules. B: another finite exact recurring-damage lifecycle.",
      "recommendationAndConsequences": "Recommend A for review. Preserve five independent applications and the full6d6. Select initial WIS and whether failed admission produces an immediate packet. Each target independently ends; one success does not cancel the others. No fear,stun,instant death or attacking phantom follows merely from the title.",
      "spellIds": [
        "mass-phantom-killer"
      ]
    },
    {
      "decisionSelected": false,
      "exactSourceOrConflict": "Selection,changed hostility and ongoing range versus initial120-foot target gate are unspecified.",
      "id": "RP9-Q15",
      "options": "A: select up tofive perceived designated hostile creatures at establishment with no later range/hostility tether. B: explicit continuing tether with its exact ending behavior.",
      "recommendationAndConsequences": "Recommend A as a scoped comparison. Specify initial selection timing under Ready,cover/line of effect and no free retargeting when one recipient dies or saves. Ordinary senses do not reveal hidden affiliations or private nightmare content. Recognition and fear-only defenses cannot remove independent damage without a real source permission.",
      "spellIds": [
        "mass-phantom-killer"
      ]
    },
    {
      "decisionSelected": false,
      "exactSourceOrConflict": "Several owners,initiative changes and suppressed pulses can create duplicate recurring exposure if clocks are underspecified.",
      "id": "RP9-Q16",
      "options": "A: expressly extend named-family once-per-target/numbered-round exposure with independent source saves and original expiry. B: permit independently stacking sources and document the resulting full damage.",
      "recommendationAndConsequences": "Recommend A from Greater Phantasmal Killer as NEW scope. Keep this distinct named family from lower spells unless explicitly merged. Record exposure before the actual packet; immunity/HP floors cannot create another opportunity. Map future START/END markers exactly across initiative and actual companion phases; no new death save from a companion-only phase. Suppressed pulses are lost; scheduled END saves and expiry continue.",
      "spellIds": [
        "mass-phantom-killer"
      ]
    },
    {
      "decisionSelected": false,
      "exactSourceOrConflict": "No earlier complete operational examples exist for this group; source preservation does not prove selected semantics.",
      "id": "RP9-Q23",
      "options": "A: after decisions,write at least two complete source-qualified cases per identity plus every substantive school/state variant. B: explicitly hold only genuinely missing content-dependent branches.",
      "recommendationAndConsequences": "Require all native access/repertoire,actual owner/body/resources,source IDs,3D geometry,clocks,full RNG and intermediate/final states. Psychic Scream needs each actual school and positive head-consequence/stun cases with Null/survival branches; Weird needs real captivity; Sovereignty needs real fleeing; Reality Break needs its whole selected secondary effect sequence. Test immunity,hard-control,suppression,extra turns,source death and actual target changes without invented content. Keep source/semantic/arithmetic/engine/human/balance/cosmology/release gates separate.",
      "spellIds": [
        "phantom-armageddon",
        "phantom-cataclysm",
        "psychic-scream",
        "frightful-sovereignty",
        "mass-phantom-killer",
        "weird",
        "reality-break"
      ]
    },
    {
      "decisionSelected": false,
      "exactSourceOrConflict": "Current Control15, illusion and body/life interfaces have scoped rules for denial, private perception, actual motion and retained state; historical accepted-but-unapplied labels are not current authority.",
      "id": "PSY129-ADD02",
      "request": "Resolve actual current index/status and exact procedures before adopting comparisons. Keep private perceived catastrophe separate from world/body state and each damage, fear, stun, flight and source clock separately admitted. Show a real spent hard-control allowance that blocks only covered new denial, actual independent damage, voluntary-budget flight with unknown or blocked safe route, and recurring effects through extra/attached phases and suppression without replay. Use genuine sources for every immunity or removal instead of a blanket mental-defense label.",
      "spellIds": [
        "phantom-armageddon",
        "phantom-cataclysm",
        "frightful-sovereignty",
        "mass-phantom-killer",
        "weird",
        "reality-break"
      ]
    }
  ],
  "qualifications": {
    "balanceApproved": false,
    "canonicalFilesChanged": false,
    "cosmologyApproved": false,
    "domainClosed": false,
    "humanPlaytested": false,
    "releaseApproved": false,
    "runtimeExecuted": false,
    "staticAuthoredReviewOnly": true,
    "suppliedOrHistoricalProgramsExecuted": false
  },
  "repair182Clarifications": {
    "actualBodyAndPhase": "Same-body form changes, changed hostility and leaving initial cast range do not re-admit or reset an existing root. Actual final recipient death ends that admission without healing; source death ends concentration. A familiar uses only its original attached packet/save checkpoints. A separate real Mage command may authorize exactly one native Dart; it neither duplicates recurring exposure nor supplies another default Dodge after the attack. No independent creature turn or death save is inferred.",
    "authorship": "NEW spell-local clarifications only; accepted comparison sources remain within exact original scope",
    "budgetAccounting": "Action/BonusAction/Reaction fields are unspent source allowances, not automatic permission to act. Incapacity blocks eligibility without spending those allowances. Actual regular starts refresh and tick recharge even when incapacitated; death is separately marked inactive. Removing incapacity never refunds a spent allowance.",
    "damageDefenses": "Resolve exact paid defense components separately. Sanctify resistance/fear modes do not union. True Seeing recognizes false imagery without canceling separate damage/control. Mind Blank uses its exact accepted psychic/mental spell scope and willingness; no consent is invented for an unconscious target.",
    "heldRequiredCaseIds": [
      "RANK9PSYCHICFEAR7-180-MASS-PHANTOM-KILLER-B/genuine-extra-turn-and-attached-phase"
    ],
    "repairCaseIds": [
      "RANK9PSYCHICFEAR7-180-MASS-PHANTOM-KILLER-B/actual-source-death-original-endpoint",
      "RANK9PSYCHICFEAR7-180-MASS-PHANTOM-KILLER-B/commanded-attached-phase-native-dart",
      "RANK9PSYCHICFEAR7-180-MASS-PHANTOM-KILLER-B/source-qualified-attached-phase",
      "RANK9PSYCHICFEAR7-180-MASS-PHANTOM-KILLER-B/target-form-death-hostility-range"
    ],
    "sourceQualification": "All new actor builds, conditional dice and geometry are explicit static witnesses. No actual campaign acquisition, creature anatomy, authoritative CR, hidden observer knowledge or runtime availability is created. Accepted comparison status may coexist with blocked catalog runtime selection; current authored index binding controls only its recorded authored scope.",
    "unprovedExtraTurn": "The procedure has no acquired genuine full-extra-turn example. The required positive extra-turn branch stays whole-case held and this identity remains unaccepted. Actual ordinary, attached, multiple-owner and suppression ledgers are not relabeled as full extra turns."
  },
  "sharedProcedure": {
    "commitment": "Action,V/S/F; ordinary range and identity checks precede commitment. Choose school variant and any Reality Break mode before paying. Cast spends once. Area membership is snapshotted at manifestation. Ready pays and resolves cast side effects at setup, holds concentration, expires next actual regular own START, and releases once with a legal Reaction after trigger; targeting occurs then. Effect clocks begin at manifestation; no second cast/cost/strain at release. Source component failure, countering, interruption, replacement or expiry refunds nothing already committed.",
    "control": "Before new Stunned or Unconscious admission, resolve survival, actual condition defenses and source-character/target encounter hard-denial allowance. Spend the combined mark once only upon successful new whole-Action denial. Used allowance blocks that new rider only; independent damage remains. No downgraded substitute control or repeated attempt after immunity/suppression. Existing admitted control may resume for its remaining original duration if a suppressor ends; no new costs, mark, duration or fresh side-effect such as another item drop. Full Stunned and Unconscious semantics apply, including ending concentration, no Actions/BonusAction/Reaction, movement prohibition, specified automatic saves and attack consequences. Frightened/flight/slow are not whole-Action denial.",
    "eligibility": "Before commitment bind actor identity, class level, acquired repertoire/prepared matrix, actual class-school row, component availability and focus custody, current life/body, Action eligibility, rank gate and RP. Rank9 minimum class17 and native base26 RP in every route. School placement alone gives no acquired route. Revalidate target/range/line of effect at manifestation. A paid legal cast whose targets later fail remains spent; an illegal precommit attempt spends nothing.",
    "geometryAndInformation": "NEW for these enemy-selective spells: designated enemies are creatures the caster currently perceives and regards as hostile; no objective allegiance oracle. Snapshot ALL qualifying designated enemies in the declared geometry without optional post-roll omissions. A mistaken hostile is affected. A concealed unknown enemy is not discovered. Allies/self are excluded unless perceived hostile designation actually applies; Weird instead snapshots every creature including self, allies and unperceived bodies in its area with source line of effect. Use actual occupied body geometry/full 3D, range and total-cover segments. Unknown scene/body/cover facts hold the affected admission, not invented coordinates.",
    "packet": "One independent damage roll per target per damage event, declared before outcomes, not one shared roll across targets. Binary saves use actual DC/modifiers and advantage/disadvantage, no generic natural1/20 save exception. Save half rounds down before defenses; resistance once, immunity separately, then tempHP, normalHP, instant death, Wound save/injury, zero-HP lifecycle, concentration and living riders in accepted order. No event silently selects Wound/injury/death dice. Hold at the next unavailable input. Surviving damage is never rolled back by rider resistance, awakening, illusion recognition, dispel, suppression, expiry or source death.",
    "phaseBridge": "For target-bound recurring records use actual regular target START damage and END saves. A source-supported companion without an independent regular turn uses its single attached controller-phase START/END once per controller regular turn; controller changes cannot add an exposure or move an existing expiry. Extra/attached actions confer no extra periodic marker. Outside initiative use initial packet then six-second START/END opportunity pairs (packet then save); transition maps each first unresolved opportunity to the next lawful marker without duplicating exposure. Actual grant, controller and phase must be bound; missing genuine extra-turn/companion evidence is held.",
    "qualifications": "No runtime execution, human play, balance judgment, cosmology decision, domain closure or release approval. No world-ending, new planes, summoned beings, memory extraction, hidden knowledge, creature anatomy, campaign immunity, acquisition or revival authorization follows from these names or authored fixtures.",
    "recurringFamily": "NEW explicit local extension of the P20 family/exposure interface for Mass Phantom Killer and Weird only: one packet per named family/recipient/actual numbered round, across owners and including an initial packet. Earliest active eligible application wins; ties use application order then immutable source ID. Mark the family opportunity before defense/HP resolution; losing due applications lose that opportunity. Suppressed sources lose their own due packet, cannot bank it, but do not consume another active source's opportunity. Independent ending WIS saves survive suppression. Family histories survive recasts/ownership copies. Mass Phantom Killer, Weird and Greater Phantasmal Killer are three distinct families.",
    "resources": "Use actual RP, Dissonance, Refrain, surcharges, class discounts and active passives. Base strain rank9=2; Wizard first distinct prepared underlying family=0 base only. Subsequent immediate same-name casts add capped Refrain1/2/3. No generic Overcast. First-cast exceptions never reset by copies, changing school, Ready release, suppression or new recipients. Keep resource history. No assumed reductions or kill-resource farm.",
    "roots": "Every cast has an immutable source owner, class/school, rank, component roots and target admissions. Child damage retains original root, funding, type and Null provenance; a Null-qualified hit preserves its actual recipient lifecycle restriction and cannot acquire a final-death/head-destruction side path. Damage, private perception, body consequence, fear, stun, sleep, voluntary flight and forced displacement are separate records. A source covering only one component affects only that component. No unsourced generic mental immunity or all-effects dispel.",
    "scope": "NEW PF181 spell-local authored selections for exactly the seven IDs. Native text/access is copied intact in each procedure. Proposed overrides of Instantaneous recurrence metadata and missing saves/durations are labeled; no global authority is asserted.",
    "termination": "Concentration ends on actual failure, incapacitation, death, voluntary ending or replacement unless an acquired specific exception applies. For non-concentration target conditions source death does not itself reset/erase their finite virtual endpoints. Target final death removes living conditions, not physical remains or ledger. Dispel ends only its eligible selected source root. Suppression blocks covered active components while clocks, mandatory saves and independently scheduled actors continue; no missed pulse, flight, forced displacement or head consequence replays on resumption. At an absolute maximum deadline expire before a coincident packet.",
    "timing": "Each actor owns its actual regular START/END calendar; spell damage opportunities are separately registered. At START expire due start effects and Ready, refresh Reaction and regular budgets, tick recharge, process legal absolute recovery and required death save before spell start effects and voluntary decisions. END resolves due damage/saves/maintenance then end expiry. Six-second virtual source/target markers preserve old durations across initiative change/removal; extra Actions/extra turns never create a regular marker, recharge tick or death save. A pulse is not an actor turn. Do not use one universal pulse rule."
  },
  "spellId": "mass-phantom-killer",
  "status": "revised authored proposal; per-identity decision in DIRECTOR_DECISION.json"
}
```

## weird

Complete proposed payload; per-identity acceptance is in DIRECTOR_DECISION.json.

```json
{
  "accepted": false,
  "applied": false,
  "id": "PF182-PROCEDURE-weird",
  "localProcedure": {
    "captivity": "Actual magically caused Unconscious is meaningful captivity: no movement/speech/Action/BonusAction/Reaction, unaware, drops held items to current physical support, Prone where physically legal, automatic STR/DEX save failure, attacks against advantage and adjacent hits critical. End concentration on admission; preserve item ownership/custody/position and physical fall/landing consequences. Nightmare content remains private, supplies no false real bodies or caster knowledge. Body/flight/support prerequisite failures hold physical consequences rather than inventing a landing.",
    "ending": "Each admitted target independently WIS at regular END even while asleep or suppressed. Success ends all components of that owner's application. Source concentration ending/death, target final death, eligible dispel or absolute60second expiry also ends it. If caster is inside and becomes incapacitated, its concentration ends immediately, cleaning remaining applications and preventing later components that require a live source. Process targets in fixed admission order declared before rolls. True Seeing recognition alone is not a free Action or waking trigger; exact stronger immunity remains separately honored. Family/phase clock clauses apply.",
    "resolution": "NEW initial WIS: success creates no record or damage; failure creates private nightmare plus separately real4d10 psychic immediately and at future actual regular target STARTs, family.weird exposure, concentration up to60elapsed seconds. Resolve first damage/lifecycle before admitting magically caused Unconscious on eligible survivors. Sleep/Unconscious defenses and hard-denial marks separately gate the captivity; blocked sleep leaves the admitted psychic damage record, not a replacement stun/fear state.",
    "selection": "RP9-Q17 A; Q18 A; Q19 A.",
    "targeting": "KEEP Core30ft and native30ft radius. NEW fixed initial snapshot of all creatures whose actual occupied bodies intersect the full3D30ft sphere at a point within30ft, with caster-to-point and point-to-body line of effect. Include caster/allies and concealed creatures; area damage does not disclose their identity/location. Later entrants are not admitted and leaving is not an escape tether. Actual Wizard/Enchantment route only.",
    "wake": "NEW explicit self-damage exception: psychic damage from this same root does not wake its own captivity. Positive post-temp damage from any other root (including a different Weird), or an adjacent helper's legal Action and physical contact, ends this root's sleep component only. External damage must resolve completely before wake; tempHP-only damage does not meet this chosen wake rule. No new sleep admission after waking, immunity loss or suppression. Prone, dropped equipment, damage and independent Unconscious sources remain. Sleep immunity blocks only sleep; fear immunity blocks nothing here; exact mental-illusion protection may cover the whole application only when its text does."
  },
  "nativeBookBindingsUnchanged": [
    {
      "catalogPlacement": {
        "level": 9,
        "name": "Weird",
        "school": "Enchantment",
        "summary": "Creatures in 30-ft radius trapped in nightmares; 4d10 psychic damage per round."
      },
      "currentBookRow": {
        "exactText": "Weird – Creatures in 30-ft radius trapped in nightmares; 4d10 psychic damage per round.",
        "level": 9,
        "line": 9228,
        "name": "Weird",
        "school": "Enchantment",
        "summary": "Creatures in 30-ft radius trapped in nightmares; 4d10 psychic damage per round."
      },
      "spellId": "weird",
      "summaryDifferencePreserved": false
    },
    {
      "catalogPlacement": {
        "level": 9,
        "name": "Weird",
        "school": "Illusion",
        "summary": "Creatures in 30-foot radius trapped in nightmares; 4d10 psychic damage per round."
      },
      "currentBookRow": {
        "exactText": "Weird – Creatures in 30-foot radius trapped in nightmares; 4d10 psychic damage per round.",
        "level": 9,
        "line": 9484,
        "name": "Weird",
        "school": "Illusion",
        "summary": "Creatures in 30-foot radius trapped in nightmares; 4d10 psychic damage per round."
      },
      "spellId": "weird",
      "summaryDifferencePreserved": false
    }
  ],
  "nativeCardAndAccessUnchanged": {
    "additionalRpCost": 0,
    "classAccess": {
      "Wizard": {
        "baseRpCost": 26,
        "minimumClassLevel": 17,
        "rank": 9,
        "school": "Enchantment"
      }
    },
    "id": "weird",
    "name": "Weird",
    "operational": null,
    "reviewFlags": [
      "Core resolution requires an explicit operational interpretation",
      "Not selectable in this spell playtest packet until individual operational review"
    ],
    "schools": [
      "Enchantment",
      "Illusion"
    ],
    "source": {
      "catalogKey": "weird",
      "catalogPath": "src/data/spells.js",
      "catalogSha256": "3358a2e1afcbc340dbafd92e45e39a7d2d0a24fed5c0719a3d233263ce530078",
      "coreEntries": [
        {
          "index": 410,
          "original": {
            "casting_time": "1 action",
            "components": "V, S, F",
            "duration": "Instantaneous",
            "effect": "Creatures in 30-ft radius trapped in nightmares; 4d10 psychic damage per round.",
            "level": 9,
            "name": "Weird",
            "range": "30 feet",
            "resolution": "Automatic or opposed as described",
            "rp_cost": 26,
            "school": "Enchantment",
            "source_paragraph": 9486,
            "tags": [
              "Damage"
            ]
          }
        },
        {
          "index": 616,
          "original": {
            "casting_time": "1 action",
            "components": "V, S, F",
            "duration": "Instantaneous",
            "effect": "Creatures in 30-foot radius trapped in nightmares; 4d10 psychic damage per round.",
            "level": 9,
            "name": "Weird",
            "range": "30 feet",
            "resolution": "Automatic or opposed as described",
            "rp_cost": 26,
            "school": "Illusion",
            "source_paragraph": 9742,
            "tags": [
              "Damage"
            ]
          }
        }
      ],
      "corePath": "data/public/Decennium_Descent_Core_Systems_Data_v2_Known_Descent.json",
      "coreSha256": "50c3e9683349e93192191381ab6354ca7d675a24fcc9bb9b039c23e67fecca4f",
      "original": {
        "alternateSummaries": [
          "Creatures in 30-foot radius trapped in nightmares; 4d10 psychic damage per round."
        ],
        "castingTime": "Not specified in current rulebook",
        "classLearnLevels": {
          "Wizard": 17
        },
        "classLevels": {
          "Wizard": 9
        },
        "classRanks": {
          "Wizard": 9
        },
        "classSchools": {
          "Wizard": "Enchantment"
        },
        "classes": [
          "Wizard"
        ],
        "components": "Not specified in current rulebook",
        "description": "Creatures in 30-ft radius trapped in nightmares; 4d10 psychic damage per round.",
        "duration": "Not specified in current rulebook",
        "level": 9,
        "name": "Weird",
        "placements": [
          {
            "level": 9,
            "name": "Weird",
            "school": "Enchantment",
            "summary": "Creatures in 30-ft radius trapped in nightmares; 4d10 psychic damage per round."
          },
          {
            "level": 9,
            "name": "Weird",
            "school": "Illusion",
            "summary": "Creatures in 30-foot radius trapped in nightmares; 4d10 psychic damage per round."
          }
        ],
        "range": "Not specified in current rulebook",
        "resonanceRank": 9,
        "school": "Enchantment",
        "schools": [
          "Enchantment",
          "Illusion"
        ],
        "source": "Player Rulebook — Spell Lists",
        "status": "canon"
      },
      "possibleHistoricalAliases": []
    },
    "status": "blocked-pending-operational-review",
    "visibility": "public-source-review"
  },
  "originalQuestionsUnchanged": [
    {
      "decisionSelected": false,
      "exactSourceOrConflict": "All actual access is rank9/minimumclasslevel17/base26RP; Psychic Scream has three placements and Weird two, but actual routes do not grant every school.",
      "id": "RP9-Q01",
      "options": "A: preserve actual class-school routes with expressly selected shared or school-specific payloads. B: propose an access correction only with complete source evidence.",
      "recommendationAndConsequences": "Recommend A. Psychic Scream is Mage Evocation and Wizard Enchantment; its Illusion placement supplies history, not an acquired third route. Weird is actually Wizard Enchantment despite two placements. Phantom Armageddon alone includes Cleric/Druid/Wizard Necromancy. Others are Wizard-only. Keep actual repertoire, Action,V/S/F,price/cadence and Ready commitment; no generic upcast or multiple casts from multiple placements.",
      "spellIds": [
        "phantom-armageddon",
        "phantom-cataclysm",
        "psychic-scream",
        "frightful-sovereignty",
        "mass-phantom-killer",
        "weird",
        "reality-break"
      ]
    },
    {
      "decisionSelected": false,
      "exactSourceOrConflict": "Psychic,necrotic and force damage,illusion perception,fear,stun and compulsory movement are distinct components.",
      "id": "RP9-Q03",
      "options": "A: expressly extend applicable accepted damage/condition/root clauses per identity. B: identify a concrete contrary source and select a bounded exception.",
      "recommendationAndConsequences": "Keep each actual damage event and original owner/Null root. Damage immunity does not imply mental/fear/stun immunity; Charmed-only immunity is not universal mental immunity. Control admission is spent only for actual full-Action denial. Preserve real saves,temporaryHP,Wounds,death/concentration and effects independently. True Seeing recognises false images but has only its exact source-qualified removal permissions; do not give blanket dispelling or blindness-based mental immunity.",
      "spellIds": [
        "phantom-armageddon",
        "phantom-cataclysm",
        "psychic-scream",
        "frightful-sovereignty",
        "mass-phantom-killer",
        "weird",
        "reality-break"
      ]
    },
    {
      "decisionSelected": false,
      "exactSourceOrConflict": "Both placements trap creatures in NIGHTMARES within30-foot radius for4d10psychic PERROUND; actual Wizard route remains Enchantment.",
      "id": "RP9-Q17",
      "options": "A: a selected30-foot-radius sphere at a center within Core30feet with an initial fixed all-creature snapshot. B: a persistent area that admits later entrants under exact exposure/admission rules.",
      "recommendationAndConsequences": "Choose geometry and caster/allied exposure explicitly,without an enemy-only rewrite. Preserve both source placements and the actual single access route. Center perception/line of effect is distinct from individual area-recipient perception. A trapped subject may leave a physical area only according to the selected real state; nightmares are not automatically walls or a plane.",
      "spellIds": [
        "weird"
      ]
    },
    {
      "decisionSelected": false,
      "exactSourceOrConflict": "Trapped in nightmares has no complete control state; merely retaining damage would drop part of its source benefit.",
      "id": "RP9-Q18",
      "options": "A: actual magically caused Unconscious with independently defined nightmare damage/waking. B: a bounded private illusory captivity state with explicit movement/actions/senses. C: another concrete meaningful trapped state.",
      "recommendationAndConsequences": "Confer before choosing. A must resolve whether its own4d10 wakes the sleeper; do not borrow Eyebite waking so the spell defeats itself,or invent an exception silently. B must define real action denial,perceived routes,outside intervention and True Seeing without granting Mental Prison’s damage by analogy. Apply actual sleep/fear/mental immunities only to covered components and whole-Action allowance only when required.",
      "spellIds": [
        "weird"
      ]
    },
    {
      "decisionSelected": false,
      "exactSourceOrConflict": "Instantaneous cannot govern recurring4d10 and ongoing captivity; neither finite duration nor escape saves is native.",
      "id": "RP9-Q19",
      "options": "A: NEW concentration minute,initial WIS and regular END escape,with explicitly selected independent START damage. B: another fully specified finite positive lifecycle.",
      "recommendationAndConsequences": "Select damage/save/control ordering,maximum clock,one family exposure,overlap and actual source/recipient suppression. Define independent component endings,helping or damage-triggered escape if chosen. Preserve admitted state and real damage histories; no repeated entry/recognition/reflection creates extra pulses. At exact expiry end before a coincident pulse; no memory erasure or physical nightmare objects are implied.",
      "spellIds": [
        "weird"
      ]
    },
    {
      "decisionSelected": false,
      "exactSourceOrConflict": "No earlier complete operational examples exist for this group; source preservation does not prove selected semantics.",
      "id": "RP9-Q23",
      "options": "A: after decisions,write at least two complete source-qualified cases per identity plus every substantive school/state variant. B: explicitly hold only genuinely missing content-dependent branches.",
      "recommendationAndConsequences": "Require all native access/repertoire,actual owner/body/resources,source IDs,3D geometry,clocks,full RNG and intermediate/final states. Psychic Scream needs each actual school and positive head-consequence/stun cases with Null/survival branches; Weird needs real captivity; Sovereignty needs real fleeing; Reality Break needs its whole selected secondary effect sequence. Test immunity,hard-control,suppression,extra turns,source death and actual target changes without invented content. Keep source/semantic/arithmetic/engine/human/balance/cosmology/release gates separate.",
      "spellIds": [
        "phantom-armageddon",
        "phantom-cataclysm",
        "psychic-scream",
        "frightful-sovereignty",
        "mass-phantom-killer",
        "weird",
        "reality-break"
      ]
    },
    {
      "decisionSelected": false,
      "exactSourceOrConflict": "Native placements differ in substantive riders, while the current class routes select only their actual schools. A partial damage-only completion would lose head consequences, nightmare captivity or secondary effects.",
      "id": "PSY129-ADD01",
      "request": "Preserve all native placements and actually acquired routes. Provide a complete positive Enchantment head-consequence case and separate Evocation stun case for Psychic Scream, with explicit vital/headless/multihead/current-form data or named content holds. For Weird select and fully demonstrate real nightmare captivity, including whether its own psychic damage can wake, distinct sleep/mental/fear defenses and allied exposure. For Reality Break supply the complete selected secondary-effect table/sequence and every genuine branch rather than referring to an unspecified effect list.",
      "spellIds": [
        "psychic-scream",
        "weird",
        "reality-break"
      ]
    },
    {
      "decisionSelected": false,
      "exactSourceOrConflict": "Current Control15, illusion and body/life interfaces have scoped rules for denial, private perception, actual motion and retained state; historical accepted-but-unapplied labels are not current authority.",
      "id": "PSY129-ADD02",
      "request": "Resolve actual current index/status and exact procedures before adopting comparisons. Keep private perceived catastrophe separate from world/body state and each damage, fear, stun, flight and source clock separately admitted. Show a real spent hard-control allowance that blocks only covered new denial, actual independent damage, voluntary-budget flight with unknown or blocked safe route, and recurring effects through extra/attached phases and suppression without replay. Use genuine sources for every immunity or removal instead of a blanket mental-defense label.",
      "spellIds": [
        "phantom-armageddon",
        "phantom-cataclysm",
        "frightful-sovereignty",
        "mass-phantom-killer",
        "weird",
        "reality-break"
      ]
    }
  ],
  "qualifications": {
    "balanceApproved": false,
    "canonicalFilesChanged": false,
    "cosmologyApproved": false,
    "domainClosed": false,
    "humanPlaytested": false,
    "releaseApproved": false,
    "runtimeExecuted": false,
    "staticAuthoredReviewOnly": true,
    "suppliedOrHistoricalProgramsExecuted": false
  },
  "repair182Clarifications": {
    "authorship": "NEW spell-local clarifications only; accepted comparison sources remain within exact original scope",
    "budgetAccounting": "Action/BonusAction/Reaction fields are unspent source allowances, not automatic permission to act. Incapacity blocks eligibility without spending those allowances. Actual regular starts refresh and tick recharge even when incapacitated; death is separately marked inactive. Removing incapacity never refunds a spent allowance.",
    "damageDefenses": "Resolve exact paid defense components separately. Sanctify resistance/fear modes do not union. True Seeing recognizes false imagery without canceling separate damage/control. Mind Blank uses its exact accepted psychic/mental spell scope and willingness; no consent is invented for an unconscious target.",
    "heldRequiredCaseIds": [
      "RANK9PSYCHICFEAR7-180-WEIRD-B/genuine-extra-turn-source-hold"
    ],
    "repairCaseIds": [
      "RANK9PSYCHICFEAR7-180-WEIRD-B/actual-mind-blank-before-admission",
      "RANK9PSYCHICFEAR7-180-WEIRD-B/fear-immunity-does-not-prevent-magical-sleep",
      "RANK9PSYCHICFEAR7-180-WEIRD-B/hidden-body-captivity",
      "RANK9PSYCHICFEAR7-180-WEIRD-B/incapacitated-familiar-attached-phase",
      "RANK9PSYCHICFEAR7-180-WEIRD-B/sleep-fear-mental-defenses",
      "RANK9PSYCHICFEAR7-180-WEIRD-B/true-seeing-does-not-wake"
    ],
    "sourceQualification": "All new actor builds, conditional dice and geometry are explicit static witnesses. No actual campaign acquisition, creature anatomy, authoritative CR, hidden observer knowledge or runtime availability is created. Accepted comparison status may coexist with blocked catalog runtime selection; current authored index binding controls only its recorded authored scope.",
    "unprovedExtraTurn": "The procedure has no acquired genuine full-extra-turn example. The required positive extra-turn branch stays whole-case held and this identity remains unaccepted. Actual ordinary, attached, multiple-owner and suppression ledgers are not relabeled as full extra turns."
  },
  "sharedProcedure": {
    "commitment": "Action,V/S/F; ordinary range and identity checks precede commitment. Choose school variant and any Reality Break mode before paying. Cast spends once. Area membership is snapshotted at manifestation. Ready pays and resolves cast side effects at setup, holds concentration, expires next actual regular own START, and releases once with a legal Reaction after trigger; targeting occurs then. Effect clocks begin at manifestation; no second cast/cost/strain at release. Source component failure, countering, interruption, replacement or expiry refunds nothing already committed.",
    "control": "Before new Stunned or Unconscious admission, resolve survival, actual condition defenses and source-character/target encounter hard-denial allowance. Spend the combined mark once only upon successful new whole-Action denial. Used allowance blocks that new rider only; independent damage remains. No downgraded substitute control or repeated attempt after immunity/suppression. Existing admitted control may resume for its remaining original duration if a suppressor ends; no new costs, mark, duration or fresh side-effect such as another item drop. Full Stunned and Unconscious semantics apply, including ending concentration, no Actions/BonusAction/Reaction, movement prohibition, specified automatic saves and attack consequences. Frightened/flight/slow are not whole-Action denial.",
    "eligibility": "Before commitment bind actor identity, class level, acquired repertoire/prepared matrix, actual class-school row, component availability and focus custody, current life/body, Action eligibility, rank gate and RP. Rank9 minimum class17 and native base26 RP in every route. School placement alone gives no acquired route. Revalidate target/range/line of effect at manifestation. A paid legal cast whose targets later fail remains spent; an illegal precommit attempt spends nothing.",
    "geometryAndInformation": "NEW for these enemy-selective spells: designated enemies are creatures the caster currently perceives and regards as hostile; no objective allegiance oracle. Snapshot ALL qualifying designated enemies in the declared geometry without optional post-roll omissions. A mistaken hostile is affected. A concealed unknown enemy is not discovered. Allies/self are excluded unless perceived hostile designation actually applies; Weird instead snapshots every creature including self, allies and unperceived bodies in its area with source line of effect. Use actual occupied body geometry/full 3D, range and total-cover segments. Unknown scene/body/cover facts hold the affected admission, not invented coordinates.",
    "packet": "One independent damage roll per target per damage event, declared before outcomes, not one shared roll across targets. Binary saves use actual DC/modifiers and advantage/disadvantage, no generic natural1/20 save exception. Save half rounds down before defenses; resistance once, immunity separately, then tempHP, normalHP, instant death, Wound save/injury, zero-HP lifecycle, concentration and living riders in accepted order. No event silently selects Wound/injury/death dice. Hold at the next unavailable input. Surviving damage is never rolled back by rider resistance, awakening, illusion recognition, dispel, suppression, expiry or source death.",
    "phaseBridge": "For target-bound recurring records use actual regular target START damage and END saves. A source-supported companion without an independent regular turn uses its single attached controller-phase START/END once per controller regular turn; controller changes cannot add an exposure or move an existing expiry. Extra/attached actions confer no extra periodic marker. Outside initiative use initial packet then six-second START/END opportunity pairs (packet then save); transition maps each first unresolved opportunity to the next lawful marker without duplicating exposure. Actual grant, controller and phase must be bound; missing genuine extra-turn/companion evidence is held.",
    "qualifications": "No runtime execution, human play, balance judgment, cosmology decision, domain closure or release approval. No world-ending, new planes, summoned beings, memory extraction, hidden knowledge, creature anatomy, campaign immunity, acquisition or revival authorization follows from these names or authored fixtures.",
    "recurringFamily": "NEW explicit local extension of the P20 family/exposure interface for Mass Phantom Killer and Weird only: one packet per named family/recipient/actual numbered round, across owners and including an initial packet. Earliest active eligible application wins; ties use application order then immutable source ID. Mark the family opportunity before defense/HP resolution; losing due applications lose that opportunity. Suppressed sources lose their own due packet, cannot bank it, but do not consume another active source's opportunity. Independent ending WIS saves survive suppression. Family histories survive recasts/ownership copies. Mass Phantom Killer, Weird and Greater Phantasmal Killer are three distinct families.",
    "resources": "Use actual RP, Dissonance, Refrain, surcharges, class discounts and active passives. Base strain rank9=2; Wizard first distinct prepared underlying family=0 base only. Subsequent immediate same-name casts add capped Refrain1/2/3. No generic Overcast. First-cast exceptions never reset by copies, changing school, Ready release, suppression or new recipients. Keep resource history. No assumed reductions or kill-resource farm.",
    "roots": "Every cast has an immutable source owner, class/school, rank, component roots and target admissions. Child damage retains original root, funding, type and Null provenance; a Null-qualified hit preserves its actual recipient lifecycle restriction and cannot acquire a final-death/head-destruction side path. Damage, private perception, body consequence, fear, stun, sleep, voluntary flight and forced displacement are separate records. A source covering only one component affects only that component. No unsourced generic mental immunity or all-effects dispel.",
    "scope": "NEW PF181 spell-local authored selections for exactly the seven IDs. Native text/access is copied intact in each procedure. Proposed overrides of Instantaneous recurrence metadata and missing saves/durations are labeled; no global authority is asserted.",
    "termination": "Concentration ends on actual failure, incapacitation, death, voluntary ending or replacement unless an acquired specific exception applies. For non-concentration target conditions source death does not itself reset/erase their finite virtual endpoints. Target final death removes living conditions, not physical remains or ledger. Dispel ends only its eligible selected source root. Suppression blocks covered active components while clocks, mandatory saves and independently scheduled actors continue; no missed pulse, flight, forced displacement or head consequence replays on resumption. At an absolute maximum deadline expire before a coincident packet.",
    "timing": "Each actor owns its actual regular START/END calendar; spell damage opportunities are separately registered. At START expire due start effects and Ready, refresh Reaction and regular budgets, tick recharge, process legal absolute recovery and required death save before spell start effects and voluntary decisions. END resolves due damage/saves/maintenance then end expiry. Six-second virtual source/target markers preserve old durations across initiative change/removal; extra Actions/extra turns never create a regular marker, recharge tick or death save. A pulse is not an actor turn. Do not use one universal pulse rule."
  },
  "spellId": "weird",
  "status": "revised authored proposal; per-identity decision in DIRECTOR_DECISION.json"
}
```

## reality-break

Complete proposed payload; per-identity acceptance is in DIRECTOR_DECISION.json.

```json
{
  "accepted": false,
  "applied": false,
  "id": "PF182-PROCEDURE-reality-break",
  "localProcedure": {
    "lifecycle": "NEW no concentration. Maximum three future regular target END markers excluding current in-progress END from maximum count; outside initiative+18seconds. At each actual regular END while the secondary record remains, including current upcoming END, WIS against original source DC ends it; no unnecessary final save at expiry. Source death keeps virtual endpoint. Suppression suspends only covered ongoing components, never replays initial force/displacement or rerolls/reselects mode. Distinct source roots retain separate END saves; named penalties do not stack.",
    "modes": [
      {
        "effect": "Stunned through at most three future regular target END markers; no temporal turn, clock pause or world change. Apply whole-Action allowance and actual Stunned defense exactly once. END WIS ends this source; blocked admission has no fallback.",
        "id": "fractured-time"
      },
      {
        "effect": "One initial forced straight-line displacement of up to10feet away from caster along the actual caster-to-target center vector, stopping before solid matter/occupied space or loss of verified safe support. If coincident centers or required body/scene data absent, the motion component is held; if verified no legal positive segment, zero movement. Does not provoke, spend ordinary movement or deal collision/falling damage by itself. On the same failed admission separately reduce current Speed by10feet,min0, until ending/expiry; anchoring blocks only the displacement unless its source also blocks slow. No further displacement, including after suppression.",
        "id": "spatial-shear"
      },
      {
        "effect": "A private false overlay disorients this target: -2 to its attack rolls and WIS(Perception) ability checks until ending/expiry. No save/DC/AC penalty, sight loss, Blinded, Frightened, Stunned, route compulsion, Action denial or secret information. An exact effect neutralizing private mental illusions may block this mode; mere identification as false is not a removal effect. No physical objects/world alterations.",
        "id": "private-dislocation"
      }
    ],
    "resolution": "Always one10d12 force event, independent of WIS. Resolve complete damage/lifecycle first. Living target then initial WIS; success prevents the secondary mode. Failure admits only the predeclared mode subject to its own defenses. No later force packets.",
    "selection": "RP9-Q20 B; Q21 B; Q22 A.",
    "targeting": "KEEP one perceived creature within120ft with line of effect. NEW select exactly one of the following three modes before commitment and record it in cast/Ready/root. No random table, weights, rerolls, post-save choices or undeclared external effect list."
  },
  "nativeBookBindingsUnchanged": [
    {
      "catalogPlacement": {
        "level": 9,
        "name": "Reality Break",
        "school": "Illusion",
        "summary": "Target takes 10d12 force damage and must make WIS saves or suffer effects."
      },
      "currentBookRow": {
        "exactText": "Reality Break – Target takes 10d12 force damage and must make WIS saves or suffer effects.",
        "level": 9,
        "line": 9489,
        "name": "Reality Break",
        "school": "Illusion",
        "summary": "Target takes 10d12 force damage and must make WIS saves or suffer effects."
      },
      "spellId": "reality-break",
      "summaryDifferencePreserved": false
    }
  ],
  "nativeCardAndAccessUnchanged": {
    "additionalRpCost": 0,
    "classAccess": {
      "Wizard": {
        "baseRpCost": 26,
        "minimumClassLevel": 17,
        "rank": 9,
        "school": "Illusion"
      }
    },
    "id": "reality-break",
    "name": "Reality Break",
    "operational": null,
    "reviewFlags": [
      "Not selectable in this spell playtest packet until individual operational review"
    ],
    "schools": [
      "Illusion"
    ],
    "source": {
      "catalogKey": "reality-break",
      "catalogPath": "src/data/spells.js",
      "catalogSha256": "3358a2e1afcbc340dbafd92e45e39a7d2d0a24fed5c0719a3d233263ce530078",
      "coreEntries": [
        {
          "index": 621,
          "original": {
            "casting_time": "1 action",
            "components": "V, S, F",
            "duration": "Instantaneous",
            "effect": "Target takes 10d12 force damage and must make WIS saves or suffer effects.",
            "level": 9,
            "name": "Reality Break",
            "range": "120 feet",
            "resolution": "Wisdom save",
            "rp_cost": 26,
            "school": "Illusion",
            "source_paragraph": 9747,
            "tags": [
              "Damage"
            ]
          }
        }
      ],
      "corePath": "data/public/Decennium_Descent_Core_Systems_Data_v2_Known_Descent.json",
      "coreSha256": "50c3e9683349e93192191381ab6354ca7d675a24fcc9bb9b039c23e67fecca4f",
      "original": {
        "alternateSummaries": [],
        "castingTime": "Not specified in current rulebook",
        "classLearnLevels": {
          "Wizard": 17
        },
        "classLevels": {
          "Wizard": 9
        },
        "classRanks": {
          "Wizard": 9
        },
        "classSchools": {
          "Wizard": "Illusion"
        },
        "classes": [
          "Wizard"
        ],
        "components": "Not specified in current rulebook",
        "description": "Target takes 10d12 force damage and must make WIS saves or suffer effects.",
        "duration": "Not specified in current rulebook",
        "level": 9,
        "name": "Reality Break",
        "placements": [
          {
            "level": 9,
            "name": "Reality Break",
            "school": "Illusion",
            "summary": "Target takes 10d12 force damage and must make WIS saves or suffer effects."
          }
        ],
        "range": "Not specified in current rulebook",
        "resonanceRank": 9,
        "school": "Illusion",
        "schools": [
          "Illusion"
        ],
        "source": "Player Rulebook — Spell Lists",
        "status": "canon"
      },
      "possibleHistoricalAliases": []
    },
    "status": "blocked-pending-operational-review",
    "visibility": "public-source-review"
  },
  "originalQuestionsUnchanged": [
    {
      "decisionSelected": false,
      "exactSourceOrConflict": "All actual access is rank9/minimumclasslevel17/base26RP; Psychic Scream has three placements and Weird two, but actual routes do not grant every school.",
      "id": "RP9-Q01",
      "options": "A: preserve actual class-school routes with expressly selected shared or school-specific payloads. B: propose an access correction only with complete source evidence.",
      "recommendationAndConsequences": "Recommend A. Psychic Scream is Mage Evocation and Wizard Enchantment; its Illusion placement supplies history, not an acquired third route. Weird is actually Wizard Enchantment despite two placements. Phantom Armageddon alone includes Cleric/Druid/Wizard Necromancy. Others are Wizard-only. Keep actual repertoire, Action,V/S/F,price/cadence and Ready commitment; no generic upcast or multiple casts from multiple placements.",
      "spellIds": [
        "phantom-armageddon",
        "phantom-cataclysm",
        "psychic-scream",
        "frightful-sovereignty",
        "mass-phantom-killer",
        "weird",
        "reality-break"
      ]
    },
    {
      "decisionSelected": false,
      "exactSourceOrConflict": "Psychic,necrotic and force damage,illusion perception,fear,stun and compulsory movement are distinct components.",
      "id": "RP9-Q03",
      "options": "A: expressly extend applicable accepted damage/condition/root clauses per identity. B: identify a concrete contrary source and select a bounded exception.",
      "recommendationAndConsequences": "Keep each actual damage event and original owner/Null root. Damage immunity does not imply mental/fear/stun immunity; Charmed-only immunity is not universal mental immunity. Control admission is spent only for actual full-Action denial. Preserve real saves,temporaryHP,Wounds,death/concentration and effects independently. True Seeing recognises false images but has only its exact source-qualified removal permissions; do not give blanket dispelling or blindness-based mental immunity.",
      "spellIds": [
        "phantom-armageddon",
        "phantom-cataclysm",
        "psychic-scream",
        "frightful-sovereignty",
        "mass-phantom-killer",
        "weird",
        "reality-break"
      ]
    },
    {
      "decisionSelected": false,
      "exactSourceOrConflict": "One target takes10d12 FORCE and must make WIS SAVES OR ADDITIONAL EFFECTS. No finite table or schedule exists.",
      "id": "RP9-Q20",
      "options": "A: one initial10d12 event plus a finite selected sequence of additional effects. B: one selected secondary effect with recurring WIS ending saves.",
      "recommendationAndConsequences": "Choose whether initial WIS changes damage or only secondary effects. Keep10d12force exactly once unless extra damage is explicitly authored. The complete native effect list must be supplied before acceptance; reject a foreign Reality Break table as assumed source. A list of unspecified effects or rejection-only outcomes is not a finished procedure.",
      "spellIds": [
        "reality-break"
      ]
    },
    {
      "decisionSelected": false,
      "exactSourceOrConflict": "The missing effects can span control,movement and perception,each with different costs and defenses.",
      "id": "RP9-Q21",
      "options": "A: a finite source-local table using explicitly selected existing primitives,with exact random/choice distribution. B: a fixed declared effect chosen before commitment.",
      "recommendationAndConsequences": "Confer on a complete useful proposal including magnitudes,conditions,durations,target legality and ordering. A requires all weights and RNG ownership; B cannot permit post-save selection or hidden-information fishing. Actual Stunned uses hard-control admission; movement needs legal bodies/support; private distortion gives no real plane,world rewrite or secret knowledge. Existing condition names retain their full scope unless a distinct new scoped state is expressly authored.",
      "spellIds": [
        "reality-break"
      ]
    },
    {
      "decisionSelected": false,
      "exactSourceOrConflict": "Plural WIS saves and continuing effects need exact clocks and suppression/ending behavior.",
      "id": "RP9-Q22",
      "options": "A: NEW finite three-round maximum with independent END escape saves and a fixed effect selected at admission. B: finite staged effects with explicit per-stage WIS and shared original expiry.",
      "recommendationAndConsequences": "Choose a positive complete lifecycle rather than carrying Instantaneous forward. Preserve original damage root,real defense consumption,spent hard-control and movement. State whether ending one stage ends all future stages and how failed hard-control admission affects other eligible effects. Suppression never rerolls a table,restores earlier resources or replays spent events. Counter/Ready timing remains ordinary unless a concrete exception is selected.",
      "spellIds": [
        "reality-break"
      ]
    },
    {
      "decisionSelected": false,
      "exactSourceOrConflict": "No earlier complete operational examples exist for this group; source preservation does not prove selected semantics.",
      "id": "RP9-Q23",
      "options": "A: after decisions,write at least two complete source-qualified cases per identity plus every substantive school/state variant. B: explicitly hold only genuinely missing content-dependent branches.",
      "recommendationAndConsequences": "Require all native access/repertoire,actual owner/body/resources,source IDs,3D geometry,clocks,full RNG and intermediate/final states. Psychic Scream needs each actual school and positive head-consequence/stun cases with Null/survival branches; Weird needs real captivity; Sovereignty needs real fleeing; Reality Break needs its whole selected secondary effect sequence. Test immunity,hard-control,suppression,extra turns,source death and actual target changes without invented content. Keep source/semantic/arithmetic/engine/human/balance/cosmology/release gates separate.",
      "spellIds": [
        "phantom-armageddon",
        "phantom-cataclysm",
        "psychic-scream",
        "frightful-sovereignty",
        "mass-phantom-killer",
        "weird",
        "reality-break"
      ]
    },
    {
      "decisionSelected": false,
      "exactSourceOrConflict": "Native placements differ in substantive riders, while the current class routes select only their actual schools. A partial damage-only completion would lose head consequences, nightmare captivity or secondary effects.",
      "id": "PSY129-ADD01",
      "request": "Preserve all native placements and actually acquired routes. Provide a complete positive Enchantment head-consequence case and separate Evocation stun case for Psychic Scream, with explicit vital/headless/multihead/current-form data or named content holds. For Weird select and fully demonstrate real nightmare captivity, including whether its own psychic damage can wake, distinct sleep/mental/fear defenses and allied exposure. For Reality Break supply the complete selected secondary-effect table/sequence and every genuine branch rather than referring to an unspecified effect list.",
      "spellIds": [
        "psychic-scream",
        "weird",
        "reality-break"
      ]
    },
    {
      "decisionSelected": false,
      "exactSourceOrConflict": "Current Control15, illusion and body/life interfaces have scoped rules for denial, private perception, actual motion and retained state; historical accepted-but-unapplied labels are not current authority.",
      "id": "PSY129-ADD02",
      "request": "Resolve actual current index/status and exact procedures before adopting comparisons. Keep private perceived catastrophe separate from world/body state and each damage, fear, stun, flight and source clock separately admitted. Show a real spent hard-control allowance that blocks only covered new denial, actual independent damage, voluntary-budget flight with unknown or blocked safe route, and recurring effects through extra/attached phases and suppression without replay. Use genuine sources for every immunity or removal instead of a blanket mental-defense label.",
      "spellIds": [
        "phantom-armageddon",
        "phantom-cataclysm",
        "frightful-sovereignty",
        "mass-phantom-killer",
        "weird",
        "reality-break"
      ]
    }
  ],
  "qualifications": {
    "balanceApproved": false,
    "canonicalFilesChanged": false,
    "cosmologyApproved": false,
    "domainClosed": false,
    "humanPlaytested": false,
    "releaseApproved": false,
    "runtimeExecuted": false,
    "staticAuthoredReviewOnly": true,
    "suppliedOrHistoricalProgramsExecuted": false
  },
  "repair182Clarifications": {
    "authorship": "NEW spell-local clarifications only; accepted comparison sources remain within exact original scope",
    "budgetAccounting": "Action/BonusAction/Reaction fields are unspent source allowances, not automatic permission to act. Incapacity blocks eligibility without spending those allowances. Actual regular starts refresh and tick recharge even when incapacitated; death is separately marked inactive. Removing incapacity never refunds a spent allowance.",
    "damageDefenses": "Resolve exact paid defense components separately. Sanctify resistance/fear modes do not union. True Seeing recognizes false imagery without canceling separate damage/control. Mind Blank uses its exact accepted psychic/mental spell scope and willingness; no consent is invented for an unconscious target.",
    "heldRequiredCaseIds": [],
    "movementAndRemoval": "Stone Shell requires the exact acquired Tank/Tortoise card, unarmored active stance, Ki>=3 and no more than one-size-larger forcing creature. It blocks only covered forced movement. Actual support/occupied footprint bounds stop the remainder without a queued displacement. Exact Wizard Arch Dispel is rank3,Action3RP,range60,recharge2 and INT+PB versus10+original rank for higher ranks; no Greater Dispel or rank5 acquisition is asserted. The demonstrated private aura is first made perceivable by an acquired Arcane Sight Action,2RP,rank2,concentration and Recharge2 on an earlier lawful turn; Dispel then pays its own3RP/Action. H total payment is5RP, not3RP.",
    "repairCaseIds": [
      "RANK9PSYCHICFEAR7-180-REALITY-BREAK-B/Oracle5-stun-immunity-retains-force",
      "RANK9PSYCHICFEAR7-180-REALITY-BREAK-B/actual-source-death-original-endpoint",
      "RANK9PSYCHICFEAR7-180-REALITY-BREAK-B/anchoring-and-unsupported-displacement",
      "RANK9PSYCHICFEAR7-180-REALITY-BREAK-B/occupied-space-stops-displacement",
      "RANK9PSYCHICFEAR7-180-REALITY-BREAK-B/source-death-and-actual-dispel",
      "RANK9PSYCHICFEAR7-180-REALITY-BREAK-B/support-boundary-stops-displacement"
    ],
    "sourceQualification": "All new actor builds, conditional dice and geometry are explicit static witnesses. No actual campaign acquisition, creature anatomy, authoritative CR, hidden observer knowledge or runtime availability is created. Accepted comparison status may coexist with blocked catalog runtime selection; current authored index binding controls only its recorded authored scope."
  },
  "sharedProcedure": {
    "commitment": "Action,V/S/F; ordinary range and identity checks precede commitment. Choose school variant and any Reality Break mode before paying. Cast spends once. Area membership is snapshotted at manifestation. Ready pays and resolves cast side effects at setup, holds concentration, expires next actual regular own START, and releases once with a legal Reaction after trigger; targeting occurs then. Effect clocks begin at manifestation; no second cast/cost/strain at release. Source component failure, countering, interruption, replacement or expiry refunds nothing already committed.",
    "control": "Before new Stunned or Unconscious admission, resolve survival, actual condition defenses and source-character/target encounter hard-denial allowance. Spend the combined mark once only upon successful new whole-Action denial. Used allowance blocks that new rider only; independent damage remains. No downgraded substitute control or repeated attempt after immunity/suppression. Existing admitted control may resume for its remaining original duration if a suppressor ends; no new costs, mark, duration or fresh side-effect such as another item drop. Full Stunned and Unconscious semantics apply, including ending concentration, no Actions/BonusAction/Reaction, movement prohibition, specified automatic saves and attack consequences. Frightened/flight/slow are not whole-Action denial.",
    "eligibility": "Before commitment bind actor identity, class level, acquired repertoire/prepared matrix, actual class-school row, component availability and focus custody, current life/body, Action eligibility, rank gate and RP. Rank9 minimum class17 and native base26 RP in every route. School placement alone gives no acquired route. Revalidate target/range/line of effect at manifestation. A paid legal cast whose targets later fail remains spent; an illegal precommit attempt spends nothing.",
    "geometryAndInformation": "NEW for these enemy-selective spells: designated enemies are creatures the caster currently perceives and regards as hostile; no objective allegiance oracle. Snapshot ALL qualifying designated enemies in the declared geometry without optional post-roll omissions. A mistaken hostile is affected. A concealed unknown enemy is not discovered. Allies/self are excluded unless perceived hostile designation actually applies; Weird instead snapshots every creature including self, allies and unperceived bodies in its area with source line of effect. Use actual occupied body geometry/full 3D, range and total-cover segments. Unknown scene/body/cover facts hold the affected admission, not invented coordinates.",
    "packet": "One independent damage roll per target per damage event, declared before outcomes, not one shared roll across targets. Binary saves use actual DC/modifiers and advantage/disadvantage, no generic natural1/20 save exception. Save half rounds down before defenses; resistance once, immunity separately, then tempHP, normalHP, instant death, Wound save/injury, zero-HP lifecycle, concentration and living riders in accepted order. No event silently selects Wound/injury/death dice. Hold at the next unavailable input. Surviving damage is never rolled back by rider resistance, awakening, illusion recognition, dispel, suppression, expiry or source death.",
    "phaseBridge": "For target-bound recurring records use actual regular target START damage and END saves. A source-supported companion without an independent regular turn uses its single attached controller-phase START/END once per controller regular turn; controller changes cannot add an exposure or move an existing expiry. Extra/attached actions confer no extra periodic marker. Outside initiative use initial packet then six-second START/END opportunity pairs (packet then save); transition maps each first unresolved opportunity to the next lawful marker without duplicating exposure. Actual grant, controller and phase must be bound; missing genuine extra-turn/companion evidence is held.",
    "qualifications": "No runtime execution, human play, balance judgment, cosmology decision, domain closure or release approval. No world-ending, new planes, summoned beings, memory extraction, hidden knowledge, creature anatomy, campaign immunity, acquisition or revival authorization follows from these names or authored fixtures.",
    "recurringFamily": "NEW explicit local extension of the P20 family/exposure interface for Mass Phantom Killer and Weird only: one packet per named family/recipient/actual numbered round, across owners and including an initial packet. Earliest active eligible application wins; ties use application order then immutable source ID. Mark the family opportunity before defense/HP resolution; losing due applications lose that opportunity. Suppressed sources lose their own due packet, cannot bank it, but do not consume another active source's opportunity. Independent ending WIS saves survive suppression. Family histories survive recasts/ownership copies. Mass Phantom Killer, Weird and Greater Phantasmal Killer are three distinct families.",
    "resources": "Use actual RP, Dissonance, Refrain, surcharges, class discounts and active passives. Base strain rank9=2; Wizard first distinct prepared underlying family=0 base only. Subsequent immediate same-name casts add capped Refrain1/2/3. No generic Overcast. First-cast exceptions never reset by copies, changing school, Ready release, suppression or new recipients. Keep resource history. No assumed reductions or kill-resource farm.",
    "roots": "Every cast has an immutable source owner, class/school, rank, component roots and target admissions. Child damage retains original root, funding, type and Null provenance; a Null-qualified hit preserves its actual recipient lifecycle restriction and cannot acquire a final-death/head-destruction side path. Damage, private perception, body consequence, fear, stun, sleep, voluntary flight and forced displacement are separate records. A source covering only one component affects only that component. No unsourced generic mental immunity or all-effects dispel.",
    "scope": "NEW PF181 spell-local authored selections for exactly the seven IDs. Native text/access is copied intact in each procedure. Proposed overrides of Instantaneous recurrence metadata and missing saves/durations are labeled; no global authority is asserted.",
    "termination": "Concentration ends on actual failure, incapacitation, death, voluntary ending or replacement unless an acquired specific exception applies. For non-concentration target conditions source death does not itself reset/erase their finite virtual endpoints. Target final death removes living conditions, not physical remains or ledger. Dispel ends only its eligible selected source root. Suppression blocks covered active components while clocks, mandatory saves and independently scheduled actors continue; no missed pulse, flight, forced displacement or head consequence replays on resumption. At an absolute maximum deadline expire before a coincident packet.",
    "timing": "Each actor owns its actual regular START/END calendar; spell damage opportunities are separately registered. At START expire due start effects and Ready, refresh Reaction and regular budgets, tick recharge, process legal absolute recovery and required death save before spell start effects and voluntary decisions. END resolves due damage/saves/maintenance then end expiry. Six-second virtual source/target markers preserve old durations across initiative change/removal; extra Actions/extra turns never create a regular marker, recharge tick or death save. A pulse is not an actor turn. Do not use one universal pulse rule."
  },
  "spellId": "reality-break",
  "status": "revised authored proposal; per-identity decision in DIRECTOR_DECISION.json"
}
```

