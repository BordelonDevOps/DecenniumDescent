# Storm Control6 Director Return176

**UNACCEPTED / UNAPPLIED. Accepted IDs: none. Authority remains 749 applied-reviewed / 99 pending / 0 accepted-unapplied.**

The six proposed procedure texts and all 27 explicit question selections are supplied. The failure check retains two source/access evidence blockers and a third defect in the newly authored case clock accounting. No canonical files were edited. The proposed package does not meet acceptance requirements.

## Exact blockers

### ST176-B01

The required positive genuine-extra-turn premise is not established by the packet or recovered exact comparison sources. Six records explicitly stop before a dependent effect instead of inventing an extra-turn flag. Time Echo phaseBudget expressly says its replay entitlements are not another regular/extra turn; Oracle Time Prophecy expressly grants no immediate extra normal turn. Additional Actions and initiative reordering do not satisfy the requested genuine turn. No universal claim is made that no such source exists elsewhere.

Required correction: Bind an exact currently authorized genuine-turn source and its legal acquired actor, then replace only the six held precondition traces with full source-qualified chronological traces (including no added pulse/ending save/command entitlement). Alternatively the director must explicitly qualify or revise this required positive-evidence obligation; this return does not waive it.

### ST176-B02

The new Monk9 fixture selects Stone Shell and Breath of Focus at level3. The source requires at least one active Arch selection, but Breath of Focus is labelled sourceKind=passive despite activation=Action. Treating an action-bearing passive as an Active selection would resolve a class acquisition ambiguity outside these six spell scopes. The conditional Stone Shell/Bastion traces therefore do not prove unconditional actor access, even though their Ki, costs, immunity/anchoring predicates and event arithmetic are represented.

Required correction: Supply exact existing acceptance evidence that resolves the selection classification, or substitute another fully proved accessible anchoring and damage-immunity profile. Do not rewrite Monk acquisition or invent a creature/immunity to close this spell review. Preserve the demonstrated source-local damage-versus-control separation.

### ST176-B03

43 newly authored case traces (213 actor records) advance final elapsed time beyond their own nextRegularStart without complete intervening ordinary-turn accounting. This is a defect in the proposed return, not in the source packet. At23.9, both real-ready-dispel-during-group branches leave W nextRegularStart11.6 and Arch Dispel recharge2; Frozen Eternity B leaves T nextRegularStart12.1 and recharge1; its dying-and-recharge branch leaves T Dying with two successes/one failure and nextRegularStart18.1. The required18.1 death save is absent. Hellstorm A leaves A Action0 and nextRegularStart11.8 at23.9. Hashes and inverses correctly reproduce these incomplete states, so their pass does not close this semantic defect.

Required correction: Complete only the affected actor-clock and dependent lifecycle/resource portions of the new traces, using each actual actor schedule. Record skipped normal START/END, budget refresh, recharge, Ready expiry and required death-save outcomes before advancing final time; then recompute all affected full-state hashes/inverses/mirrors. Retain each spell original source-relative opportunity ledger; do not replace it with a universal pulse/turn scheduler. REGULAR_CLOCK_FAILURE_CHECK.json lists every affected case/actor and five exact examples.

## Evidence counts

```json
{
  "procedures": 6,
  "questions": 27,
  "mainCases": 12,
  "branches": 42,
  "caseRecords": 54,
  "events": 520,
  "eventOperations": 2080,
  "proposalOperations": 24,
  "heldRecords": 50,
  "originalQuestions": 25,
  "focusedAdditionalQuestions": 2,
  "originalFutureObligations": 10,
  "substantiveFullStateTraces": 48,
  "heldPreconditionOnlyRecords": 6,
  "localHolds": 9,
  "inheritedHoldRecords": 87,
  "totalScopedHoldRecords": 96,
  "sourceChecks": 311,
  "acceptedComparisonChecks": 106,
  "auxiliarySourceChecks": 10,
  "dataChecks": 20814,
  "semanticBlockers": 3,
  "casesWithClockSemanticDefect": 43,
  "actorRecordsWithClockSemanticDefect": 213
}
```

## Reading order

DIRECTOR_DECISION.json; SEMANTIC_FAILURE_CHECK.json; REGULAR_CLOCK_FAILURE_CHECK.json; PROCEDURES.json and STANDALONE_PROCEDURES.md; QUESTION_DISPOSITIONS.json; CASE_DISPOSITIONS.json; CASEBOOK.json and exact case mirrors; HOLD_REGISTER.json; SOURCE_VERIFICATION.json; ACCEPTED_COMPARISON_VERIFICATION.json; AUXILIARY_SOURCE_VERIFICATION.json; DATA_VALIDATION.json.

Six one-event records are explicit held precondition records. They do not count as positive genuine-turn demonstrations. Forty-three proposed traces have independently identified clock defects; see their exact fields in REGULAR_CLOCK_FAILURE_CHECK.json. Other geometry/lifecycle holds remain whole-case campaign qualifications, even where full conditional data traces exist.

The manifest binds every payload member. The manifest itself is bound by the separate delivery record to avoid self-reference. Source archive and candidate remain byte-exact.

Static authored evidence only: no runtime, human play, balance, cosmology, domain closure or release approval. Historical programs are retained only inside exact provenance archives and were never executed.
