# Bound source clauses

These are exact submitted values/lines. Paths and hashes refer to PACKAGE_MANIFEST.json, not a remote repository verification.

## S-FS01

`DescentReviewChanges/ReviewBible/data/public/feat_candidates/exact_01/shared_rules.json` /rules/0

SHA256 `bf8483fa6b70cbfc87404df5c68c48e6b849f808ec4667dcd529a89cd9b0dfb6`

```json
{
  "id": "FS-01",
  "title": "Authority, identity and acquisition",
  "disposition": "ADOPT EXPLICIT NEW COMPLETION",
  "wording": "These are source/proposal-authoring directions for 327 exact existing IDs, not approval of assembled operational cards. Preserve all 335 originals, eight already-reviewed full feats, every description/effect/legacy alternative, original questions, absent/null distinctions and prior labels. A real class-scheduled feat/ASI opportunity pays for a grant; merely reaching a total level, possessing an item, meeting prerequisites or reading this register gives no selection. Unqualified Level means total character level; named Warrior or other class gates use that class level. Check printed permanent ability, actual feat ownership and credential prerequisites at acquisition. A half-feat ability increase is capped at 20, contributes zero rather than reducing a higher score, and does not grant another selection. The pure ASI option requires its full legal allocation. Numerical skill prerequisites require actual proficiency and permanent governing ability modifier plus the applicable normal PB or replacing Expertise contribution, excluding equipment, temporary modifiers, situational feats, Help and advantage. Preserve the acquisition snapshot. Later prerequisite loss does not erase a grant; ongoing equipped/active/body requirements can disable its use.\nNEW nonrepeatability: each identity is acquired once, except the explicitly repeatable ASI, Armor Proficiency for a distinct missing tier, Resilient for a different save, and Weapon Focus for a different actual weapon type. Elemental Affinity/Adept, Spell Focus and other chosen-type feats do not gain unprinted repeatability. One same-named source represented in two catalogs is not two selections. The twelve explicitly mapped Warrior mutation-feat pairs are one paid identity; their actual class gates and active-mutation conditions control as stated in HM rows. Other shared names do NOT merge class, ancestry, item, feat, ordinary-spell or supplement permissions.\n\nWarrior mutation-feat acquisition uses the equipped-loadout rules in the Warrior engine as corrected by FEAT327-ACQ-02: at most two equipped Advanced mutations per actual tree and at most one equipped Apex mutation across all trees, within the actual unlocked total slots. Dormant equipped mutations count toward those ceilings. Evaluate each feat's equipped and active prerequisites only at the acquisition or use-time checkpoints that its exact procedure specifies. A temporary all-equipped activation does not supply an equipped prerequisite, slot, mutation, class level or feat opportunity. Preserve each feat's acquisition snapshot and existing ongoing operating conditions.",
  "basis": [
    "All nine sharedProposal objects",
    "CHARACTER_CREATION_PLAYTEST.md",
    "MAXIMUM_HP_PLAYTEST.md",
    "heritage_mutation/originalWarriorCounterpartPairs"
  ],
  "exactCardApproval": false
}
```

## S-FS02

`DescentReviewChanges/ReviewBible/data/public/feat_candidates/exact_01/shared_rules.json` /rules/1

SHA256 `bf8483fa6b70cbfc87404df5c68c48e6b849f808ec4667dcd529a89cd9b0dfb6`

```json
{
  "id": "FS-02",
  "title": "Credentials, training snapshots and real study",
  "disposition": "ADOPT EXPLICIT NEW COMPLETION",
  "wording": "Use actual current credentials, one proficiency contribution and the feat's selected branch. Thievery is the bounded thieves'-tools/DEX acquisition bridge, not a new universal skill. Mechanical Disable Device means an actual Engineering or thieves'-tools disarm interface; it does not authorize magical disarming. Knowledge (Monstrous Humanoids) remains an existing valid legacy credential; proficient INT(Nature) for that bounded anatomy is the NEW alternative bridge, with printed Survival still valid. Culture Lore may be an actual bounded credential or the explicitly selected History specialization. Agility means the stated Dexterity option, not another ability. Spellcraft is not silently aliased to Arcana; an actual legacy credential receipt is required where it is printed as a prerequisite, unless another printed alternative qualifies. Half-elf, Half-orc, Dragonborn, Sorcerer and Warlock labels are not silently turned into present ancestry/class identities. Existing genuinely authorized legacy grants remain evidenced; no new builder option follows.\n\n**Weapon prerequisite bridge.** Apply this bridge only to an actual printed feat prerequisite, subject to any more specific acquisition direction in that feat’s final procedure. Where a prerequisite names a weapon or weapon type, require actual proficiency with that named current weapon profile/type. A generic Melee or Melee Proficiency prerequisite requires actual proficiency with at least one current melee-weapon profile; Ranged or Ranged Proficiency requires actual proficiency with at least one current ranged-weapon profile. Use the weapon profile’s actual classification, not merely the attack’s melee or ranged delivery: throwing a melee-class weapon does not by itself satisfy Ranged acquisition, and making a ranged spell attack supplies no weapon proficiency. An otherwise generic martial-weapon proficiency prerequisite requires proficiency with at least one actual martial-weapon profile, not all martial weapons; an explicitly stricter per-feat prerequisite remains stricter. Two-Handed or 2H Weapon acquisition requires actual proficiency with a weapon whose current profile possesses the Two-Handed property; proficiency with a Versatile-only weapon held in two hands does not satisfy that gate. Record the qualifying proficiency grant and weapon profile/type in the acquisition snapshot. These are acquisition credentials: they neither supply an item or proficiency nor make an otherwise unproficient attack proficient. They do not impose a new requirement to use the acquisition-qualifying weapon for every later feat event. Actual use-time weapon, proficiency where expressly required, grip, body, range, ammunition, action and other predicates remain those of the exact feat and governing procedure. All other printed ability, level, prerequisite-feat, class-access and earned-opportunity requirements remain mandatory. Class, feat, ancestry and item grants with similar names otherwise remain separate permissions.\nCasting-prerequisite snapshot bridge — FEAT327-ACQ-03. NEW acquisition completion. Apply this bridge only to an actual feat acquisition prerequisite or its expressly required acquisition selection, subject to a more specific acquisition rule in that feat’s final procedure. A casting prerequisite requires a source-qualified personal spellcasting entitlement already acquired by the character and still retained at the acquisition snapshot. Record the actual grant, exact spell identity and source version, casting route, relevant class/rank gates, and the repertoire or preparation evidence that makes that route available. Class-level capacity, an RP or RC pool, a spell merely appearing on a permitted list, ownership of a spellbook or scroll, item-enabled casting, an unacquired class feature, and the prospective benefit of the feat being acquired do not by themselves supply this entitlement.\n\nRetained entitlement versus immediate casting legality. A retained personal grant does not lose its acquisition credential merely because its renewable charge is currently empty, RP is insufficient, components or a suitable casting hand/voice are unavailable, the character is unconscious, or an existing temporary prohibition or suppression prevents casting. Ignore those immediate-use impediments only when evaluating this casting credential. Do not refill a resource, restore components, lift a prohibition, perform a cast, or establish that the feat-selection transaction itself is otherwise lawful. Actual casting still requires every current action, component, body, target, range, payment, concentration, strain and source-specific condition. An expressly ongoing or currently-active prerequisite in a particular feat remains an ongoing or currently-active prerequisite.\n\nQualifying repertoire and preparation. For a known-spell route, require the exact spell actually learned or personally granted, with its applicable source gates satisfied. For an ordinary prepared route, require the spell actually prepared at the snapshot, an actually acquired always-prepared grant, or another already-established source exception that authorizes casting it without ordinary preparation. An unprepared spellbook entry and the ability to prepare or substitute it later are insufficient for that spell’s credential. A future study period, rest, substitution, level-up selection or other repertoire change cannot be anticipated. A ritual route qualifies when the character actually possesses its ritual-casting permission and the particular spell meets that permission’s exact book, tag, rank and other repertoire requirements; no ritual need already have been cast. Do not extend one spell’s ritual overlay to another spell. Loss of a required repertoire source follows the actual class procedure: Wizard’s surviving prepared matrices remain available under its spellbook-loss rule, while an unprepared lost-book entry is not made available by merely planning its reconstruction.\n\nGeneric and specific predicates. “Spellcasting ability,” “Actual personal spellcasting ability,” and “Ability to cast at least one spell” require at least one qualifying personal spell route under this bridge; a qualifying rank-0 spell is sufficient. “Ability to cast cantrips” requires a qualifying rank-0 route. A named-spell prerequisite requires the exact required spell identity and permitted source version, not a similarly named class technique or item effect. A school prerequisite requires an actual matching school on the qualifying route. A rank prerequisite uses the spell rank actually supplied by that route and the final normalized predicate’s existing exact-rank or minimum-rank comparison, not total character level, maximum possible class rank, available RP, damage, or a higher price paid for a lower-rank spell. Where one predicate combines identity, school, rank or route restrictions, one qualifying route must satisfy that complete predicate; do not combine different routes’ most favorable fields. Distinct alternatives retain their existing AND/OR structure.\n\nRemoval, replacement and expiry. Reevaluate the retained grant and repertoire for every new feat acquisition. An actually removed, expired or lawfully retrained-away grant cannot support a new acquisition unless another independently qualifying route exists. Replacing a prepared matrix removes that ordinary prepared route for later snapshots unless another valid route to the spell remains. Temporary suppression or renewable depletion is not removal. Exhausting a genuinely nonrenewable permission follows its actual source: if the permission terminates, it no longer supplies a retained route. Under FS-01, a previously acquired feat keeps its original acquisition snapshot; later prerequisite loss does not erase that historical acquisition or waive any of the feat’s actual ongoing operating conditions.\n\nUnassigned schools and required school choices. Preserve each source spell’s actual school value, explicit null or absent field. An absent, null or unassigned school is not Universal, Enchantment, Evocation, a wildcard, or a school inferred from damage type or a grant’s name. A school-unassigned personal rank-0 grant can satisfy generic spellcasting and cantrip predicates, but cannot itself satisfy a school-specific predicate. Supplementary Spell Focus additionally requires its mandatory permanent selection of an actual school supported by at least one qualifying acquired spell route at that same snapshot. Satisfying its generic spellcasting prerequisite without a supported school choice is insufficient to complete its acquisition. Another genuine route may support that choice. Subsequent loss or suppression of the supporting route does not reselect the school or erase the original acquisition; later benefits still require actual eligible casts through that fixed school.\n\nAuthored-candidate evidence versus runtime selection. For authored-candidate qualification, use the exact complete controlling authored spell procedure and its actual source-access binding, supported by the applicable review and fulfillment chain. A preserved earlier blocked catalog snapshot does not override an explicitly reviewed, version-linked operational descendant merely because the original remains unchanged. A separate selectionEnabled:false or disabled runtime adapter does not by itself invalidate that authored evidence. Neither a favorable label nor the existence of a reviewed spell supplies the character’s personal grant or repertoire history. Genuinely unfinished, null, unsupported or operationally unavailable payloads remain unavailable as positive casting witnesses. Preserve original statuses and live selection flags; this acquisition bridge neither enables runtime selection nor promotes another card.\n\nSnapshot and payment. Preserve the exact prerequisite text and record the qualifying grant, spell/source/mode, actual school-field state and rank, repertoire/preparation or ritual basis, applicable class gates, controlling authored-procedure reference, and acquisition time. Temporary use blocks may be recorded separately but are not treated as grant removal. Missing grant, preparation, source-version or required-school evidence leaves that predicate unestablished rather than assumed true. Check all other printed ability, level, ownership, credential and earned-opportunity requirements independently. The feat’s own prospective spell grant cannot bootstrap its prerequisite, and one paid opportunity cannot fund two acquisitions.\n\nFor the six exploration training entries, snapshot each named skill separately at acquisition: grant proficiency if absent; grant the explicitly printed replacing Expertise only if already proficient. An acquired proficiency does not become Expertise merely because proficiency is later acquired elsewhere. If a fixed grant lacks that branch, duplication yields no replacement skill or Expertise. Skill Expert and Prodigy's ordered explicit selections use their own rules. Study, tutoring, language learning, formula research, copying and crafting are different tasks; a bonus or time discount on one does not migrate to another. Apply the actual minimum phase, calendar, rest and physical requirements.\n\nExternal-credential evidence — FEAT327-ACQ-04. NEW evidence-contract completion; the four existing feat procedures and their prerequisite alternatives are retained. For frenzied_rage, divine_favor, elemental_body and dragon_blood, evaluate a required external credential under ACQ04-EC1 against the same character, world and ordered acquisition snapshot, using the exact operative prerequisite and source version, linked credential or event evidence, and that world's established authority for recording that fact. A source file establishes wording, not that a particular character acquired a feature, worships a deity, experienced an event or possesses a lineage. A name, nonempty story label, unchecked Boolean, prospective feat benefit or unrelated class/ancestry/item grant supplies no credential. The supporting grant, worship state or exposure event must already qualify before acquisition; same-time events require an authoritative earlier sequence. Worship must be established at that snapshot; exposure is a qualifying prior event, not a requirement to remain exposed. Apply the branch-specific facts and required choices in ACQ04-EC1 without adding doctrine, an exposure threshold, an element-to-plane matching rule or a legacy alias. A conditional, opaque test-world fixture can establish only a CONDITIONAL_ONLY predicate result within that fixture. It supplies no actual campaign history, selectable option, class feature, cosmology approval or entitlement. Missing, unbound, mismatched or insufficient evidence leaves a predicate UNESTABLISHED; affirmative incompatible evidence is CONTRADICTED. Neither result satisfies a required AND node, although a separately satisfied printed OR alternative remains valid. An ESTABLISHED_FOR_SNAPSHOT result requires independently admitted actual-world evidence and is not supplied by this review. Preserve all original source fields, absence/null distinctions, acquisition history and current status/selection flags. All other permanent-ability, level, parent-feat, mandatory-choice and earned-opportunity predicates remain independently required; one paid opportunity cannot fund two acquisitions. Later use still requires the exact feat's ongoing predicates. This evidence policy does not reopen ACQ-03 or change its casting-snapshot rules.",
  "basis": [
    "skill/sharedProposal",
    "general_exploration training entries",
    "TEX and LAX governing files",
    "CRAFTING_TRADE_REFERENCE.md"
  ],
  "exactCardApproval": false
}
```

## S-FS06

`DescentReviewChanges/ReviewBible/data/public/feat_candidates/exact_01/shared_rules.json` /rules/5

SHA256 `bf8483fa6b70cbfc87404df5c68c48e6b849f808ec4667dcd529a89cd9b0dfb6`

```json
{
  "id": "FS-06",
  "title": "One clock, deadlines, rests and initial uses",
  "disposition": "ADOPT EXPLICIT NEW COMPLETION",
  "wording": "Use EX58's single elapsed clock, eight-hour Watches, actual task minutes, two-active-work-Watch ceiling and scheduled Rest. A change of scene, gate, holder, location, initiative, class representation or calendar label does not reset a resource. SR/LR in these new procedures mean the actual beneficial completed owner rest, with one beneficial Long Rest per 24 elapsed hours and at most two beneficial Short Rests between beneficial Long Rests. A qualifying long rest restores a short-rest allowance as already governed. Extra safe Rest paying Rest Debt alone provides no second resource recovery. Recipient-rest limits use the actual named recipient's rest epoch.\nNEW initial acquisition completion: the newly acquired limited-use feat begins with its specified full finite allowance, unless it expressly starts empty (such as accumulated stacks/charges). Reacquisition/alias duplication cannot initialize it again. An increase in a PB-based maximum increases capacity only, not current unspent uses. Genuine maximum-HP/RP/RC, Hit Die, reserve and slot changes never heal or refill unrelated current values.\nUse each explicit own-turn/any-turn/round predicate literally. A per-round allowance has one numbered global-round identity; extra turns do not refresh it. A default 'your turn' feat allowance uses the owner's regular interval unless its exact source direction expressly retains any actual turn. Newly completed missing durations use the next future original regular marker specified by the row, not the already-underway marker, retaining virtual/absolute deadlines across schedule changes. Outside initiative use the governed six-second phase without double ticks. A missed trigger is not queued for later. An early ending does not refund time or a use.",
  "basis": [
    "EX58 FL-03",
    "CLASS_PLAYTEST_RULES.md",
    "TEX-ADD regular-turn recharge correction",
    "all cohort resource conventions"
  ],
  "exactCardApproval": false
}
```

## S-FS09

`DescentReviewChanges/ReviewBible/data/public/feat_candidates/exact_01/shared_rules.json` /rules/8

SHA256 `bf8483fa6b70cbfc87404df5c68c48e6b849f808ec4667dcd529a89cd9b0dfb6`

```json
{
  "id": "FS-09",
  "title": "Feat-only grants, schools and casting prices",
  "disposition": "ADOPT EXPLICIT NEW COMPLETION",
  "wording": "ADOPT the supplied bounded feat-casting route as NEW. Choose and record the exact curriculum where applicable, spell identity and source version, grant rank and permanent casting ability at acquisition from the allowed source-linked list. Preserve the source’s actual school value, explicit null or absent school field; recording source identity does not authorize assigning a missing school. Apply FEAT327-ACQ-03 to casting-prerequisite snapshots and required school selections. Preserve every curriculum’s exact permitted spell, class placement, mode and casting ability; this clarification does not enlarge a curriculum or waive a required source-linked choice. It gives only that feat's repertoire/charge, no ordinary class levels, rank progression, RP pool, prepared positions or class engine. Generic and named Magic Initiate for the same curriculum share one acquisition entitlement; a different name cannot give duplicate charges for that same grant. Actual source-specific versions/modes/components/range remain; no lowest-price or school-union shortcut. Named Sorcerer/Warlock curricula are limited feat lists, not newly created classes. When a granted payload explicitly scales by casting class level, NEW feat route uses total character level only for that payload's printed scaling; it invents no scaling otherwise.\nA finite 'cast without RP' grant waives its normal rank/ordinary price and price-derived Dissonance surcharge only, not an explicitly consumed independent RP payment such as Resonance Shield's 1 RP, Silent/Still surcharge, material, maintenance, blood cost or charge. The feat route uses actual total PB and its specified ability, DC8+PB+ability, attackPB+ability. With no acquired class casting-engine override for that feat route, NEW base Dissonance is0 for rank0,1 for ranks1–5 and2 for ranks6–9; use ordinary Refrain and Limit=max(4,2PB+casting modifier), including the governed ranked-block threshold and component/interruption rules. Being a Wizard does not make an independently acquired feat charge a prepared Wizard matrix.\nFor ordinary priced spells, apply actual existing discounts, Dissonance-price addition, source independent additions, armor and final source multipliers in their reviewed order; apply Efficient Caster only at its stated stage to an actual price of at least2 and never below1 at that stage. Heighten substitutes only the proper ordinary class route's higher base rank-price, not the identity/rank of the resulting spell or a fictitious price for a free charge. Silent and Still each add1 real independent RP when used; they do not pay themselves from a zero-capacity pool. Keep source-specific minimum prices and no-refund rules.",
  "basis": [
    "magic_core/sharedProposal",
    "magicInitiateCurricula",
    "SPELL_INTEGRATION_RULES.md",
    "CLASS_PLAYTEST_RULES.md",
    "current Resonance Shield record"
  ],
  "exactCardApproval": false
}
```

## S-FLORA-DC

`DescentReviewChanges/ReviewBible/data/public/feat_candidates/exact_01/supplements.json` /groups/6/value/floraBody/dc

SHA256 `59635b07655f06f4d3fab872b2665638a683702ad89a5322fe2df426fcd96146`

At acquisition select one actual possessed spellcasting route; use DC 8+current PB+that route’s current ability modifier. No phantom Wisdom/Spellcraft statistic. Actual source-specific component/target defenses still apply.

## S-CURRICULUM-Dragoon

`DescentReviewChanges/ReviewBible/data/public/feat_candidates/exact_01/supplements.json` /groups/3/value/Dragoon/featCastingAbility

SHA256 `59635b07655f06f4d3fab872b2665638a683702ad89a5322fe2df426fcd96146`

STR

## S-CURRICULUM-Monk

`DescentReviewChanges/ReviewBible/data/public/feat_candidates/exact_01/supplements.json` /groups/3/value/Monk/featCastingAbility

SHA256 `59635b07655f06f4d3fab872b2665638a683702ad89a5322fe2df426fcd96146`

DEX

## S-CURRICULUM-Thief

`DescentReviewChanges/ReviewBible/data/public/feat_candidates/exact_01/supplements.json` /groups/3/value/Thief/featCastingAbility

SHA256 `59635b07655f06f4d3fab872b2665638a683702ad89a5322fe2df426fcd96146`

DEX

## S-UNARMED

`DescentReviewChanges/ReviewBible/data/playtest/equipment_source_catalog.json` /records/75

SHA256 `ff22f5974a1c95b4fb4e2a49b460726b956c093ce7990470c31eaa51238cf5c4`

```json
{
  "id": "simple-melee-weapons.unarmed-strike",
  "name": "Unarmed strike",
  "category": "Simple melee weapons",
  "group": null,
  "status": "source-projection-only",
  "sourceLine": 6776,
  "sourceFields": {
    "Weapon": "Unarmed strike",
    "Cost": ",",
    "Damage": "1 bludgeoning",
    "Weight": ",",
    "Properties": ","
  },
  "sourcePriceCp": null,
  "sourceWeightLb": null,
  "sourceWeightIncludesContents": false
}
```

## S-MONK-TRAINING

`DescentReviewChanges/ReviewBible/data/playtest/character_foundation.json` /classes/7

SHA256 `21e12af81f191abe52d1e3272ed1f57c6446ed3d4487cafbd5609dff08e56a77`

```json
{
  "class": "Monk",
  "slug": "monk",
  "hitDie": 8,
  "fixedLaterLevelHpBase": 5,
  "savingThrowProficiencies": [
    "STR",
    "DEX"
  ],
  "weaveTier": "minor",
  "armor": "None",
  "weapons": "Simple weapons; kama; nunchaku; staff",
  "tools": "One artisan's tool",
  "skillChoices": 2,
  "skillOptions": [
    "Acrobatics",
    "Athletics",
    "History",
    "Insight",
    "Religion",
    "Stealth"
  ],
  "startingWealth": {
    "diceCount": 5,
    "dieSides": 4,
    "multiplierGp": 1
  },
  "multiclassPrerequisites": {
    "DEX": 13,
    "WIS": 13
  },
  "multiclassProficiencies": "Simple weapons; shortswords",
  "rpByClassLevel": [
    1,
    1,
    2,
    3,
    4,
    5,
    6,
    7,
    8,
    9,
    11,
    12,
    13,
    14,
    15,
    16,
    17,
    18,
    19,
    20
  ],
  "asiClassLevels": [
    4,
    8,
    12,
    16,
    19
  ],
  "classCandidatePath": "DescentReviewChanges/ReviewBible/data/public/class_playtests/monk.json",
  "classCandidateSha256": "18a8bac9168cb4c87c641b4f2e792d31ed5ae2ae56240b3fbeced9f6ada74fc9",
  "sourceChassisLines": [
    3217,
    3218,
    3219,
    3220
  ],
  "sourceComparison": "docs/audit/2026-10-08/full-game/CHARACTER_FOUNDATION_SOURCE_EVIDENCE.json"
}
```

## S-MONK-UNARMED

`DescentReviewChanges/ReviewBible/data/public/class_playtests/monk.json` /engine/17

SHA256 `18a8bac9168cb4c87c641b4f2e792d31ed5ae2ae56240b3fbeced9f6ada74fc9`

Unarmored Flow completion: while wearing no armor or shield, AC=10+DEX modifier+WIS modifier, or ordinary armorless AC if higher, never both. Unarmed strikes use DEX for attack/damage and 1d6 at 1, 1d8 at 5, 1d10 at 11, 1d12 at 17. This is a new numeric completion; no automatic Extra Attack beyond printed techniques.

## S-TROLL-CLAWS

`DescentReviewChanges/ReviewBible/data/playtest/ancestry_background_candidate.json` /ancestries/12/traits/6

SHA256 `d8e728a1c5b9d28b7e42a035aedf99c295f7d90aa69ddae5a46f2f76959aadfb`

```json
{
  "name": "Claws",
  "sourceLine": 1500,
  "text": "Your claws are natural weapons, which you can use to make unarmed strikes. If you hit with them, you deal slashing damage equal to 1d4 + your Strength modifier, instead of the bludgeoning damage normal for an unarmed strike.",
  "id": "troll--claws",
  "status": "original-source-preserved; apply-reviewed-integration-guide"
}
```

## S-FEAT-weaponFocus

`docs/audit/2026-10-08/full-game/FEAT_EXACT_01_ACQUISITION_CONTRACTS.json` /records/283/completeOperativeProcedure

SHA256 `d9b4c2379a65c3477be90e5fc562a2a44fcb8db65d28fea951d38d6772940195`

Choose one exact current weapon type/profile for which you have actual proficiency. NEW this feat may be selected again only for a different type, spending a real feat choice each time. Gain+1 on attack rolls actually using that chosen profile while that proficiency remains operative; no damage bonus. Melee/thrown use of that actual weapon qualifies if it retains the chosen profile; improvised use that changes it to a generic object does not. A specific natural-weapon profile or unarmed-strike profile can be chosen only with an actual proficiency receipt for that profile; do not select all weapons, all natural attacks or a damage type as one choice. Losing the usable profile/proficiency suppresses the bonus without erasing the record. Distinct eligible Precision Throw can add+1, while duplicate Focus on the same type cannot.

## S-FEAT-weapon_mastery

`docs/audit/2026-10-08/full-game/FEAT_EXACT_01_ACQUISITION_CONTRACTS.json` /records/285/completeOperativeProcedure

SHA256 `d9b4c2379a65c3477be90e5fc562a2a44fcb8db65d28fea951d38d6772940195`

At acquisition, choose one actual weapon profile/type in which you are proficient; permanent choice, nonrepeatable. At total character level6+, attacks with that type have critical range19–20 instead of the ordinary20. NEW the printed+1 range is one downward threshold step from the ordinary20, not an additive modifier on another expanded range. Compare all applicable actual critical ranges and use the broadest, consistent with reviewed Core. Natural19 must still meetAC; natural20 retains its automatic-hit rule. Melee or thrown use of the chosen weapon type qualifies, but improvised use without that profile does not. A specific natural weapon may be chosen only if it is a genuine proficient weapon profile, not all natural/unarmed attacks by umbrella label. No external weapon-mastery maneuver system is imported.

## S-FEAT-tavern_brawler

`docs/audit/2026-10-08/full-game/FEAT_EXACT_01_ACQUISITION_CONTRACTS.json` /records/262/completeOperativeProcedure

SHA256 `d9b4c2379a65c3477be90e5fc562a2a44fcb8db65d28fea951d38d6772940195`

Gain actual improvised-weapon and unarmed-strike proficiency. Use the reviewed improvised object profile: an actually similar existing weapon can use its agreed full profile, otherwise1d4 appropriate physical type and20/60 throwing range. Ordinary unarmed damage is unchanged by this feat unless another actual source, such as Brawler, changes it. After your unarmed strike hits a creature on your own turn, you may spendBA that same turn for one ordinary Grapple of that same creature. NEW target must still be within actual reach and no more than one size larger, with a usable free grasping hand; use ordinary Athletics opposed by Athletics/Acrobatics. No damage or automatic success from the grapple. An improvised-weapon hit is not an unarmed hit for this trigger. Brawler's independently unconditionalBAgrapple remains broader; neither grants a secondBA or unprinted ability increase.

## S-FEAT-conjure_flora

`docs/audit/2026-10-08/full-game/FEAT_EXACT_01_ACQUISITION_CONTRACTS.json` /records/298/completeOperativeProcedure

SHA256 `d9b4c2379a65c3477be90e5fc562a2a44fcb8db65d28fea951d38d6772940195`

Once per beneficial SR/LR use an Action to create one of the three complete NEW seedling profiles below on visible supported ground within 30 ft and line of effect. It lasts one minute on original source-start markers, needs no concentration, and is a magical nonspell conjured body. Capacity is 1, or 2 at total level 10. NEW to make the second-capacity clause usable, at level 10 this same committed use permits one additional Action before the first plant expires to create one second plant; no second rest use, no later replacement of that spent creation. This is an explicit proposed addition to the printed one-seedling creation, not a recovered rule. Each plant gets its own minute. Choose its mode/burst type at creation. One BA may command all active plants within 60 ft able to perceive you, but produces only ONE selected mode outcome per round under the shared offensive-companion allowance. Lash chooses one creature within 10 ft of any participating plant for 1d6 piercing, DEX save half. Spore and entangle use their full profiles. No autonomous turn, opportunity attacks, harvest, loot, Supply, corpse or resource-generating death. Destruction/expiry permanently consumes the body.
NEW ordinary command scheduling: each plant has one attached phase immediately after its owner’s regular turn, not an independent initiative turn. Its ordinary commanded action requires the owner’s shared Bonus Action within60ft through the specified perceivable command channel and spends the one offensive companion allowance per owner per numbered round if offensive. With no legal command it has no autonomous attack. Trapcasting’s explicitly adopted entry-trigger or burst is a separate narrow exception spending that same shared offensive allowance, never another free attack.

## S-FEAT-stormcaller

`docs/audit/2026-10-08/full-game/FEAT_EXACT_01_ACQUISITION_CONTRACTS.json` /records/327/completeOperativeProcedure

SHA256 `d9b4c2379a65c3477be90e5fc562a2a44fcb8db65d28fea951d38d6772940195`

Require actual spellcasting AND (Nature proficiency OR a separately established Spellcraft credential). Spellcraft is not an Arcana alias; if absent, use the Nature alternative. Once per beneficial SR/LR, an Action places a fixed 15 ft radius Static Field at a perceived point within 60 ft and line of effect, requiring concentration for up to one minute. It affects all creatures, including allies: first actual entry or regular start inside per target per numbered round deals 1d6 lightning automatically. Placement covering a creature counts as entry once. While inside an active field, creatures have disadvantage on DEX saves, ending immediately on exit; actual immunities/suppression apply. Outdoors during an established storm, choose a 20 ft radius at creation. A separate once-SR/LR Action, Stormstep, teleports you up to 30 ft to a visible fitting unoccupied space with line of effect. Every other creature within 5 ft of arrival makes a DEX save against your actual casting DC for 1d8 thunder, half on success. NEW select the actual owned casting route at acquisition for both feat activations. Your afterimage supplies half cover until your next regular start only when the geometric ray from the incoming effect origin to your new position passes through your previous occupied space; it is not a solid object or general AC bonus. During an actual outdoor storm, your lightning spells also ignore half cover, but not stronger cover. These activations are nonspell magical feat techniques; they do not create weather, RP or extra casting resources.
NEW storm-size choice is fixed at creation, as this proposal specifies:20ft requires actual outdoor-storm premises at that placement. A later weather change does not enlarge or shrink the placed field; suppression, concentration and its original minute deadline still end it. The separate half-cover benefit checks the actual outdoor-storm predicate when each lightning spell attack resolves. These are source-authoring completions, not permission to interpret the named storm’s setting origin.

## S-FEAT-voltyros_pact

`docs/audit/2026-10-08/full-game/FEAT_EXACT_01_ACQUISITION_CONTRACTS.json` /records/333/completeOperativeProcedure

SHA256 `d9b4c2379a65c3477be90e5fc562a2a44fcb8db65d28fea951d38d6772940195`

Require character 6 AND (Stormcaller OR Lightning Affinity); preserve the named pact/plane story undecided. Once per personal noncopy lightning spell’s initial resolution, choose one additional creature within 15 ft of one original recipient, perceived with line of effect from that recipient. It must satisfy original creature eligibility and not already be targeted by that cast. Deal only half the selected original native lightning packet before defenses, rounded down; use the original DC/save ability for a fresh save or original attack bonus for a fresh attack, with original half/none on success. No other riders, new cast or chain from a chain. After one entire original start-to-next-start interval without any position change, gain Eye of the Tempest: resistance to all damage and+2 to one immediate native packet/shared roll of each personal spell until the following regular start. Any movement, teleport or forced displacement ends Eye immediately; riding a moving mount counts as movement. Repeated stationary intervals may renew without stacking. Separately, once LR use Action for a 30 ft-long 5 ft-wide lightning line: all creatures DEX save,4d6 lightning half success. DC=8+PB+one actual casting ability selected at acquisition, or INT if no casting source. The line is a magical nonspell feat technique, with noRPpool or weather creation.
The Eye bonus is+2 to one immediate native packet/shared roll of each personal spell as printed here; it is not limited to lightning spells. Half-damage chaining uses a resolved native lightning packet, not an attack that missed, a reflected/copy result, external rider or new target-independent resource event. Existing stance, terrain, body and actual stationary interval rules remain.

## S-FEAT-soul_cage

`docs/audit/2026-10-08/full-game/FEAT_EXACT_01_ACQUISITION_CONTRACTS.json` /records/325/completeOperativeProcedure

SHA256 `d9b4c2379a65c3477be90e5fc562a2a44fcb8db65d28fea951d38d6772940195`

## Soul Cage feat — Magic; level8+ and (Lifeleech **or** actual spellcasting ability)

On acquisition, lock one actually possessed spellcasting source/ability as this feat's DC provider. Agony uses that source's current normal spell-save DC. No freely switchable DC ability or general retraining is created.

**Shared Soul Charges:** each owner has one persistent pool0..3, shared with Lifeleech. A charge is a soul **spark/residue**, not custody of the whole soul. It neither prevents resurrection nor replaces/removes Soul Bind. The ordinary Soul Cage spell is a separate rank6/13RP spell awaiting its own operational review. Soulrender's separate whole-soul ritual unlock still requires actually binding the soul of a living named enemy; residue cannot satisfy it.

At an eligible hostile soul-bearing creature's actual death within30ft, with perception and legal line of effect, Soul Cage permits immediate optional capture with no Action or Reaction. A discrete physical black crystal must actually be possessed and available. Lifeleech collection is automatic and needs no crystal. Owning both never gives two charges for the same death.

Each owner permanently records the exact death event as evaluated, including ineligible events. There is no later corpse rescan after moving closer, gaining a feat/crystal or improving perception. For an eligible event, also reserve the immutable body for that owner's current completed-long-rest epoch. Declining or being at full capacity consumes that entitlement; there is no latent fourth charge. A new real death after resurrection is a new event, but the same body cannot supply the owner again in the same epoch. A future completed rest can permit a future new death, never the old corpse. Different owners evaluate independently.

Created/generated farming bodies and immutable object-origin transformed creatures are ineligible. Soul status otherwise follows actual source/canon or Director adjudication; this feat does not declare every undead/construct category soulless. Death/root/body identities persist through forms.

Charges live on the owner and do not decay automatically. Losing/destroying/transferring the crystal transfers or erases **zero** charges; Soul Cage capture/spending is unavailable without another actual legal black crystal. Another feat owner can use the transferred physical crystal for their own pool. There is no invented price, attunement, HP, durability or crystal charge capacity. During one uninterrupted quiet minute handling the crystal, you may voluntarily dissipate owned charges; this does nothing to any deceased soul.

**Shield:** Bonus Action; pay1 Soul Charge; one legal ally within30ft, including yourself; roll2d8 temporary HP with default lifetime. Pay before strongest-only comparison. An equal/stronger old shield does not refund the charge or Bonus Action.

**Agony Lance:** Action; pay2 Soul Charges; one perceived legal creature within60ft; CON save against the locked provider's current DC. Deal3d8 necrotic damage, half rounded down on success, then ordinary defenses/Core apply once. This is feat damage owned by you, not a spell, RP expenditure or spellcasting trigger.

The target also gains one **Agony healing-suppression family** record until the next committed ordinary HP-healing event with positive pre-reduction potential, or one elapsed minute. That next healing receives an exact×1/2 factor in the canonical healing pipeline. Save success or necrotic immunity affects damage but does not remove this separate rider. Multiple Agony Lances never multiply to1/4: a new paid application refreshes the single endpoint to `max(old expiry, new application+60s)` and retains contributor history.

Consume the suppression on the first applicable committed healing event even if a stronger arithmetic branch wins or actual healing is later capped/prohibited. Suppressed/inapplicable records do not apply or consume; absolute time continues. Temporary HP, stabilization, resurrection, prevention and maximum-HP changes are not ordinary HP healing and do not consume it. Removal requires an exact source capable of removing this magical suppression/debuff; generic cure is insufficient.

**NEW:** prerequisite parsing, residue identity, shared resource/death transaction, conduit role, activations/ranges/DC and the exact healing-suppression conversion. Original source IDs and relationships remain distinct.


## S-FEAT-lifeleech

`docs/audit/2026-10-08/full-game/FEAT_EXACT_01_ACQUISITION_CONTRACTS.json` /records/315/completeOperativeProcedure

SHA256 `d9b4c2379a65c3477be90e5fc562a2a44fcb8db65d28fea951d38d6772940195`

## Lifeleech — Magic; actual spellcasting ability

Before your spell's damage resolves, designate one eligible hostile target for that spell root and canonical round/window. Your first positive actual necrotic damage to that target in the window commits the entitlement, even if the eventual healing is0, prohibited, capped or unfunded. No retargeting after observing results; area spells do not harvest a separate heal from every target. The same continuing spell can qualify again in a later real round/window.

Raw self-healing is `floor(actual necrotic damage dealt /2)`. Use only the actual necrotic component, including actual temporary-HP absorption and normal HP lost under the existing actual-damage interface; no overkill. Targets must be genuine hostile opposition, not friendly/staged/trivial sacrifices or owner/ally-generated farming bodies. Natural attacks, Agony Lance and the Necrotic Affinity die alone are not spells. The feat removes no Wounds and cannot resurrect its dead owner.

**NEW finite resource — Lifeleech Recovery Reserve:** newly acquiring the feat starts at0. At each actual completed long rest set its capacity and remaining points to `2 × current character level`, snapshotted then. Level/PB changes between rests do not refill/recompute it. This reserve is neither RP nor Mutation Recovery Reserve. Persistent save imports must preserve validated spent state.

Run the ordinary two-pass healing modifiers/reductions/prohibitions. Preview uses available reserve to determine whether conditional bonuses requiring positive actual HP restoration qualify. Apply reductions before funding. Cap final legal healing potential by remaining reserve; spend that **entire funded amount** on commitment, including funded excess. All lawful healing bonuses consume this same reserve. Then restore HP subject to ordinary maximum HP and Critical ceiling, and calculate `genuine excess = max(0, funded amount − ordinary missing HP)`.

A broad HP-gain prohibition produces0 legal amount, spends0 reserve and creates0 excess. At reserve0 the round/root trigger still commits, but it produces neither restoration nor excess. Full HP can produce funded excess, but does not enable conditional bonuses requiring actual HP restoration. Critical's ceiling does not itself turn all unrestored points into excess.

Lifeleech provides no intrinsic excess converter. A separately authorized converter must have its own eligibility/cost/cadence/cap and consume each funded excess point once. An explicitly legal resource-output converter remains possible; incidental heal-triggered resource production is blocked. The child heal carries `noLifeleechRetrigger`, `blockHealCopyTriggers` and `blockResourceTriggers`; propagate these to downstream callers. The resource flag blocks incidental triggers, not an exact, separately paid excess-conversion transaction. No new resource converter is granted here.

Lifeleech also automatically collects one Soul Charge at an eligible hostile soul-bearing creature's actual death within30ft, perceived with legal line of effect. No crystal is required for Lifeleech's own collection. Use the shared resource/death rules below. Lifeleech alone cannot spend charges through abilities from the unowned Soul Cage feat.


## S-FEAT-life_drinker

`docs/audit/2026-10-08/full-game/FEAT_EXACT_01_ACQUISITION_CONTRACTS.json` /records/314/completeOperativeProcedure

SHA256 `d9b4c2379a65c3477be90e5fc562a2a44fcb8db65d28fea951d38d6772940195`

Acquisition requires the exact source feat dark_affinity OR hemocraft, legitimately acquired under its eventual reviewed procedure; neither is silently granted or approved here. NEW finite Life Drinker Recovery Reserve=2×total character level, initially full on feat acquisition and refilled only by a completed LR. Level increases raise capacity without refilling current reserve; capacity reductions clamp without damage. This is a distinct personal feat reserve, not Mutation Recovery Reserve. After your direct melee critical against an independent meaningful hostile resolves, one healing event has base floor(actualDamageDealt/2), using the reviewed metric tempAbsorbed+actualHpDamage with no overkill, floor-protected or state-assignment loss. After your direct melee attack reduces such a hostile from positiveHP to0, a separate healing event has base current total level. NEW resolve critical healing then drop healing if both trigger, spending actualHP restored from the same finite reserve; available reserve caps each after ordinary healing modifiers/prohibitions/max/Critical ceiling. No healing on dead self, no Wound cure, resurrection, copied-damage reward or artificial resource farm. Suppress secondary healing/resource/excess-conversion triggers from these recovery events as an explicit anti-loop choice. Blocked/fullHP healing spends0 reserve but grants no stored heal. While your actual normalHP is strictly below half your current effective maximum before an attack's damage (tempHP excluded), melee weapon attacks against creatures with actual blood add1d4 necrotic before defenses and critical doubling. Actual blood fact, not type-name inference; no rider against known bloodless bodies. The extra die may contribute to that same legitimate critical's numeric damage, never copied again. Healing after the hit cannot retroactively remove its already-qualified die.

## S-FEAT-hemocraft

`docs/audit/2026-10-08/full-game/FEAT_EXACT_01_ACQUISITION_CONTRACTS.json` /records/313/completeOperativeProcedure

SHA256 `d9b4c2379a65c3477be90e5fc562a2a44fcb8db65d28fea951d38d6772940195`

After a personal genuine melee critical hit against meaningful opposition, apply one NEW Hemocraft Bleed record to the still-living eligible target. It pulses 1d4 slashing at each of its next three regular starts; source immunity/anatomy restrictions and the existing Bleeding-family arbitration/cures remain. NEW max 3 own records per target; at cap refresh the earliest deadline without adding a fourth. Same-family parallel records do not all deal damage: existing strongest-die arbitration selects one, but distinct consumable records retain identity. Once per numbered round use BA to consume one present unexpired own Hemocraft record on a creature you perceive within 30 ft/line of effect, including one temporarily suppressed record, choosing 1d8 ordinary self-healing OR one 1d8 necrotic packet to that creature withCONsave against DC 8+PB+your chosenINTor CHA modifier for half. Choose stat permanently at feat acquisition. Pay by ending that exact record before outcome; no refund or consumption of another source’s Bleed. Healing spends a NEW finite Hemocraft Reserve of 2×character level set only at beneficial LR, paying actual restored HP, no excess/copy/resource outputs. Reserve starts 0 on acquisition. No consuming historical/already-cured Bleed or staged victims. The record’s ordinary Medicine-ending DC is the same chosen feat DC; actual positive-potential magical healing ends eligible Bleed through the existing cure procedure.

## S-FEAT-runic_shield

`docs/audit/2026-10-08/full-game/FEAT_EXACT_01_ACQUISITION_CONTRACTS.json` /records/228/completeOperativeProcedure

SHA256 `d9b4c2379a65c3477be90e5fc562a2a44fcb8db65d28fea951d38d6772940195`

NEW select 15 ward HP over preserved 50. The feat has one armed grant per beneficial SR/LR; acquisition arms it. At the first real encounter start after arming, automatically create one personal runic ward with 15 points and spend that entitlement, even if surprised/incapacitated; a dead creature receives none. It persists between encounters until depleted or the next beneficial SR/LR, when any old ward ends and entitlement rearms for the next combat, not immediate refill in combat. Repeated initiative does not refill it. This is a distinct spell-only ward, not temp HP: after ordinary defenses and before temp HP, intercept up to its remaining points of actual incoming spell damage in stable component order. Nonspell damage bypasses it. Record ward absorption separately, excluded from actual damage received by the body, Wound/death thresholds and concentration checks; any surviving packet resolves once normally. No transfer, double ledger, HP healing, return on revival or resource proc from ward absorption. Counterspell/dispel cannot target this nonspell passive ward without explicit applicable source permission.

## S-FEAT-spell_reservoir

`docs/audit/2026-10-08/full-game/FEAT_EXACT_01_ACQUISITION_CONTRACTS.json` /records/249/completeOperativeProcedure

SHA256 `d9b4c2379a65c3477be90e5fc562a2a44fcb8db65d28fea951d38d6772940195`

Once LR, immediately after completing a beneficial SR and its ordinary recovery, optionally restore currentPBactual RP capped by remaining merged-pool headroom. Commit theLRuse and that actual rest-event claim together; another listener, duplicate receipt or resumed rest completion cannot claim again. If no headroom, you may decline without spending, but cannot bank that past rest’s trigger for later; a later beneficial SR can supply a new opportunity while theLRuse remains. It creates no maximumRPincrease, charge, slot, second classpool or independent Retune. A long rest alone does not count as the printedSRtrigger. PB changes before a future legal use affect that use’s amount but never refresh spent entitlement.

## S-FEAT-tough

`docs/audit/2026-10-08/full-game/FEAT_EXACT_01_ACQUISITION_CONTRACTS.json` /records/269/completeOperativeProcedure

SHA256 `d9b4c2379a65c3477be90e5fc562a2a44fcb8db65d28fea951d38d6772940195`

Acquire Tough through one legal feat opportunity and record total character level at that moment. RETAIN the reviewed component decision: its maximum-HP bonus is twice that acquisition-level snapshot, with no automatic later increment from Tough itself. Keep that snapshot through current level changes, temporary suppression and save loading; do not rewrite it to current level or borrow Tough as Nails' later-level clause. Distinct maximum-HP feat identities add under the reviewed ledger, but duplicate Tough copies do not. Capacity increases give no current HP; removal/suppression can clamp current HP without damage or healing triggers. NEW full-feat completion: nonrepeatable, with no ordinary re-acquisition loop to replace the snapshot at a higher level. Only a separately authorized actual retraining/removal procedure could create a genuinely new acquisition event; this feat supplies none.

## S-FEAT-tenacity

`docs/audit/2026-10-08/full-game/FEAT_EXACT_01_ACQUISITION_CONTRACTS.json` /records/266/completeOperativeProcedure

SHA256 `d9b4c2379a65c3477be90e5fc562a2a44fcb8db65d28fea951d38d6772940195`

At total character level 4 or higher, acquire Tenacity through a legal feat opportunity. RETAIN its reviewed maximum-HP component: one bonus record equal to your current total character level, including already attained levels. It updates with genuine later level changes; do not snapshot it at acquisition. It is one identity and cannot be counted twice through aliases, engine descriptions or repeated registration. Distinct Tough, Tough as Nails and Dark Fortitude records add under the already reviewed maximum-HP contract. Apply systemic factors and reductions in that contract's order. Gaining or restoring this bonus increases capacity only; losing/suppressing it recomputes capacity and clamps current HP if necessary without damage, Wounds, healing, death-failure or first-fall triggers. NEW full-feat completion: nonrepeatable acquisition and retention under ordinary later prerequisite loss; no free retraining or HP refill.

## S-FEAT-tough_as_nails

`docs/audit/2026-10-08/full-game/FEAT_EXACT_01_ACQUISITION_CONTRACTS.json` /records/270/completeOperativeProcedure

SHA256 `d9b4c2379a65c3477be90e5fc562a2a44fcb8db65d28fea951d38d6772940195`

Require total character level 5 at acquisition. RETAIN the reviewed maximum-HP component: +2 for each total character level already gained, and +2 for each genuine later gained level. Record acquisition level and each subsequent actual advancement so that the benefit tracks the actual attained-level history without replaying level events. NEW edge completion: if a separately authorized level-loss rule removes a level and its benefits, remove the corresponding later-level +2 contribution; restoration of that same level restores that contribution once, not an additional duplicate. The ordinary candidate currently grants no free level loss/retraining mechanism. Preserve source description/legacy +10-percent wording as an inactive alternative, not a second bonus. Distinct HP feat identities add under the already reviewed ledger. Capacity changes never heal and clamps are not damage. This feat is nonrepeatable.

## S-NONINVENTORY

`DescentReviewChanges/ReviewBible/docs/mechanics/EQUIPMENT_ACQUISITION_PLAYTEST.md` 

SHA256 `406c68622102b444c6afb005e2d50cfd75171fe8d90db36a06d02df2d67bf27d`

The source catalog retains unknown fields as null. Its printed price or weight can apply to a bundle, such as twenty arrows, rather than one unit. The operational projection records bundle size and unit values separately. Unarmed strike is an attack option, not an inventory object. Services and living mounts are not generic mundane objects with a weapon's durability.
