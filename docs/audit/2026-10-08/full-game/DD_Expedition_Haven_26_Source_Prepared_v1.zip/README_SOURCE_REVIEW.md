# Expedition to Haven —26 complete source cases, UNSENT

The original preparation, audit, text packet and status remain unchanged. Read the prepared complete-file prompt and EXPEDITION_HAVEN_FLOW_SOURCE_PREPARATION.json. All84 historical protected files and all386 actual bound Word-book paragraphs match. Full current class guides, original class evidence, operational interfaces, gathering receipts and reconciled newcomer references supplement the old packet.

FILE_MANIFEST.json inventories complete files at repository-relative paths. Historical embedded scheduling and review-count text does not control current status. The advanced-crafting material is still pending source evidence, not approved recipe mechanics. The current startup guides summarize existing authorities but do not close the expedition questions or final starter-session flow.

Refresh this package after actual intervening decisions, retaining this snapshot. Preparation grants no source decision, operational approval, balance result or software parity. Source cosmic terms remain literal and uninterpreted; excluded cosmology/seasonal content stays outside the pre-push review. Final whole-game flow, authorized GitHub delivery and remote verification precede the careful cosmology review.
