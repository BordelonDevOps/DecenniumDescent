Read docs/audit/2026-10-08/full-game/EXPEDITION_COMPLETE_FILE_HANDOFF_V2_SCOPE.md first. Prepared and UNSENT. Full historical/current evidence is included. No new approvals.
