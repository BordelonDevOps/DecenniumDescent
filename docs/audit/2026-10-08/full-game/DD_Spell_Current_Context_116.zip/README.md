# Current context for the rank-seven mechanics16 review

Read CONTEXT.json and use this supplement with the unchanged DD_Rank7_Mechanics_16_Source_Conference_01.zip. Complete current accepted models and receipts are supplied, not promoted into canonical implementation. Do not execute downloaded scripts or rerun historical case runners. Return full procedures, decisions and current cases with exact input/output binding and retained holds.
