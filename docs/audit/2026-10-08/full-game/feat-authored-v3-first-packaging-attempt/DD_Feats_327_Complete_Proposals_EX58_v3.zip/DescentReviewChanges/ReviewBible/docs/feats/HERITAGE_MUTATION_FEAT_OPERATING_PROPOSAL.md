# Heritage and mutation feats: complete operating proposal

**UNADOPTED — all22 source feats remain pending full review.** This manuscript supplies one complete procedure and two authored adjudications for every HM-01–22 question. It preserves all standalone promises and all12 Warrior counterparts. Every proposed normalization and missing procedure requires actual joint agreement.

[Full structured proposal and source comparisons](../../data/director/heritage_mutation_feat_operating_proposal_internal.json) · [Original source audit](../../../../docs/audit/2026-10-08/full-game/HERITAGE_MUTATION_FEAT_SOURCE_AUDIT.md) · [Preservation/arithmetic receipt](../../../../docs/audit/2026-10-08/full-game/HERITAGE_MUTATION_22_OPERATING_PROPOSAL_CHECK.json)

The44 worked examples are authored expectations, not full feat runtime tests or human balance evidence. No public registry, class card, ancestry grant, source book or cosmology is revised here.

## Shared proposed interfaces

### Authority

All22 entries remain UNADOPTED and UNSENT. Every original source object, full question, Warrior counterpart and applicable narrow review binding is retained. No heritage, world origin, cosmology, source deletion or public feat activation is decided here. Reviewed condition, healing, timing, maximumHP, equipment and source-specific interfaces continue in their actual scopes; whole-feat/class approval is not inferred from a reviewed component.

### One paid identity

NEW reconcile each of the12 named Warrior mutation-feat pairs as one feat grant with two preserved source representations. The proposed operating rule is the specific procedure below, using the counterpart actual Warrior-level/equipped gates and explicitly identifying changes from standalone wording. Choosing through a general feat opportunity or the Warrior supplement spends one real feat choice, never both and never a free mutation selection. No duplicate benefits, charges or ledgers. These feats consume no mutation slot, but their prerequisites do. Minimum Warrior levels are class levels; ability prerequisites use permanent ability scores. The source category Aberrant_mutation alone does not add a Warrior gate to Aberrant Mind, which has no counterpart.

### Equipped and active

Equipped mutations occupy real unlocked slots and satisfy acquisition requirements. Active means a legally activated and currently unsuppressed mutation; dormant/equipped-only never supplies an active benefit. Current Warrior slot, simultaneous-active, Basic/Advanced/Apex, serum-dose, Strain, duration and unique-name limits remain. Mutation Efficiency and actual temporary exceptions must already be acquired. Each procedure states required active mutations. Suppression removes the relevant benefit without refilling resources; original clocks continue. Removing a required equipped prerequisite suppresses the feat until legitimately restored, without deleting its acquisition record. No feat creates serum doses, mutation access, BT or a class engine except its explicit bounded grant.

### Cadence and causal rules

Use current original regular-turn markers; extra turns neither create new per-round allowances nor advance periodic clocks. A numbered encounter round has one shared identity across actors. Once-per-combat means once in a real encounter with meaningful risk; exit/reentry, waves and staged sparring do not refresh. Per-day means24 elapsed hours from committed activation, distinct from beneficial rests. Per-rest here means completed beneficial SR or LR; LR-only remains LR-only. Retain the shared one additional fullAction and source-character/target/encounter hard-denial guards. A legal committed attempt pays even on failure; reject illegal attempts before payment.

### Heritage eligibility

NEW each named heritage prerequisite requires the actual chosen base ancestry record in the current reviewed ancestry candidate, or a later explicit reviewed heritage receipt. Its own variants qualify through that base; a costume, temporary form, similar name or an unadopted alternative builder variant does not. No mixed-heritage grant is invented. Source identity and heritage eligibility are rules receipts, not claims about origin, personality or culture. Feats are separate paid choices; ancestry traits do not supply them free.

### Arithmetic and scope

Preserve current native attack/spell, damage-event and source-owner distinctions. Resistance to the same type never stacks. Numeric actual damage means actualHP damage plus temporaryHP actually absorbed, excluding overkill and mere state assignment; a hit can occur without positive damage. Distinct compatible percentage bonuses use the existing unadopted combat proposal: apply each floored increment to the same native pre-percentage amount after critical/flat additions and before defenses, never multiply each other. Actual packet boundaries remain. Same feat-family repeated records do not add magnitudes unless the feat explicitly supplies its finite stack counter. No copy/reflection/companion packet becomes a new personal attack or kill.

### Preserved disagreements

The proposed choices are not recovered canon: broader standalone action denial becomes the counterpart Reaction loss; Synaptic Rot follows actual Silenced, not universal spell shutdown; Living Fortress denies only real flanking-derived advantage; Bloodthick enhancement stays a finite modifier; temporary ancestry effects receive explicit clocks and scope. Every original promise remains visible beside these proposed resolutions for GPT to accept, revise or reject.

## All22 original source questions

### HM-01 — Aberrant Mind

Source identity: `aberrant_mind`. Original prerequisite: **Intelligence 15+**.

**Original effect, unchanged**

You can communicate telepathically with aberrations and have resistance to psychic damage.

**Proposed complete procedure**

Retain permanentINT15 prerequisite and resistance to psychic damage, subject to one same-type resistance. NEW while conscious, initiate one two-way telepathic conversation with one actual Aberration you perceive within60ft and line of effect. A brief message uses the ordinary free communication allowance on your own regular turn; an invited willing recipient may reply briefly without Action, including off-turn, without gaining another action. Both must know at least one language, but need not share one. No automatic type detection: choosing a non-Aberration produces no channel, not a diagnosis of why it failed. Recipient may refuse/end communication; you cannot read thoughts, memories, emotions or intentions, compel responses, or impersonate a voice. Maintain actual range/line of effect; loss ends the link. Silence/Deafened alone does not block purely mental speech, but Unconscious or explicit telepathy/mental-communication protection does. One channel at a time, no relay or shared senses. This grants no Aberration creature type, mutation activation or alien-origin fact.

**Explicit NEW choices:** 60ft single willing channel, language capacity without shared language, free brief exchange and strict information limits.

**Worked adjudications**

- A willing Aberration knowing a different language may converse mentally within60ft; the feat reveals only its voluntary message.

- A wall giving total cover ends the channel. Psychic resistance still applies to an otherwise legal psychic packet.

**Dependencies:** Current reviewed Core, action, condition, healing, ancestry and equipment interfaces; Exact preserved Warrior/ancestry source evidence where applicable; Shared proposed feat conventions; actual expedition verdict still pending.

<details><summary>Complete original source, counterpart and question</summary>

```json
{
  "sourceObject": {
    "id": "aberrant_mind",
    "name": "Aberrant Mind",
    "description": "Your mind has been touched by alien intelligence.",
    "prerequisite": "Intelligence 15+",
    "effect": "You can communicate telepathically with aberrations and have resistance to psychic damage.",
    "type": "Aberrant_mutation",
    "draft": false,
    "deprecated": false,
    "needsReview": false
  },
  "completeClassCounterpart": null
}
```

Preserve telepathy with aberrations and psychic resistance under Intelligence15. Define actual creature-type eligibility,range,senses,language,directionality,consent/actions and informational limits. Source category does not by itself require Warrior or change creature type. No alien origin, universal cognition or cosmology decision is inferred.

</details>

### HM-02 — Backlash Engine

Source identity: `backlashEngine`. Original prerequisite: **Adrenal Backlash Core mutation**.

**Original effect, unchanged**

Each time you're hit while mutated, gain +1 BT

**Actual class counterpart, unchanged:** warrior.supplement.backlash-engine

**Counterpart prerequisite:** Warrior 8; Adrenal Backlash Core equipped; eligible feat grant

**Counterpart effect:** While Adrenal Backlash Core is active, the first time each round you take actual damage, gain 1 BT, never above the current cap.

**Proposed complete procedure**

NEW select the actual Warrior8 counterpart over unlimited each-hit generation: require Adrenal Backlash Core equipped and active. The first qualifying actual-damage event in a numbered round may grant1BT, no Action, subject to current BT cap3 or actual Stack Overflow4. Use positive numeric actualDamageDealt to you, so real temporaryHP absorption counts; a zero-damage hit, floor-prevented loss with no temp absorption or direct HP sacrifice does not. Recheck survival and active mutation after the full damage/death sequence; no gain after actual death or ended mutation. Current hostile-threat anti-farming restrictions apply; environmental damage without a meaningful hostile cause grants noBT under this NEW feat completion. This explicit card gain bypasses the normal combined2BT-generation ceiling but not its own once-round cap or stored maximum. It adds no Brutality Progress and remains the same gain whether selected from the feat registry or Warrior supplement. Ordinary qualifying damage-taken BT may also resolve once under its own threshold/cap; neither effect duplicates the other.

**Explicit NEW choices:** Warrior8, active Adrenal, once-round numeric actual damage and explicit generation-ceiling exception.

**Worked adjudications**

- A hostile hit removes2tempHP: Backlash may add1BT despite no normalHP loss, if its round allowance and current cap permit.

- AtBT3 without Stack Overflow the grant adds0. Another hit that round cannot create a second Backlash gain.

**Dependencies:** Current reviewed Core, action, condition, healing, ancestry and equipment interfaces; Exact preserved Warrior/ancestry source evidence where applicable; Shared proposed feat conventions; actual expedition verdict still pending.

<details><summary>Complete original source, counterpart and question</summary>

```json
{
  "sourceObject": {
    "id": "backlashEngine",
    "name": "Backlash Engine",
    "description": "Taking damage while mutated builds up energy.",
    "prerequisite": "Adrenal Backlash Core mutation",
    "effect": "Each time you're hit while mutated, gain +1 BT",
    "type": "Combat_mutation",
    "draft": false,
    "deprecated": false,
    "needsReview": false
  },
  "completeClassCounterpart": {
    "id": "warrior.supplement.backlash-engine",
    "name": "Backlash Engine",
    "className": "Warrior",
    "band": "Arch",
    "path": null,
    "sourceKind": "mutationFeat",
    "minimumClassLevel": 8,
    "acquisition": "supplement",
    "activation": "Triggered",
    "cost": "Feat choice",
    "rangeAndTarget": "Self",
    "duration": "Instantaneous",
    "frequency": "At most once per round",
    "effect": "While Adrenal Backlash Core is active, the first time each round you take actual damage, gain 1 BT, never above the current cap.",
    "prerequisite": "Warrior 8; Adrenal Backlash Core equipped; eligible feat grant",
    "source": {
      "line": 5002,
      "reference": null,
      "originalText": "| Backlash Engine | Adrenal Backlash Core | Each time you're hit while mutated, gain +1 BT |",
      "status": "source-derived"
    },
    "designStatus": "provisional-playtest",
    "spellRank": null
  }
}
```

Reconcile standalone each hit while mutated with the full Warrior counterpart: Warrior8,Adrenal Backlash Core equipped/active,actual damage and once per round. Resolve source-defined BT cap/generation exceptions,hostile-threat rules,damage packets and zeroHP. Do not approve broader hit farming or grant this twice through class and feat catalogs.

</details>

### HM-03 — Bio-Stabilizer

Source identity: `bioStabilizer`. Original prerequisite: **Bloodthick Node mutation**.

**Original effect, unchanged**

+1 regeneration while under the effect of 2+ mutations

**Actual class counterpart, unchanged:** warrior.supplement.bio-stabilizer

**Counterpart prerequisite:** Warrior 4; Bloodthick Node equipped; eligible feat grant

**Counterpart effect:** While at least two mutations are active, Bloodthick Node heals 1 additional HP on each of its valid encounter-only regeneration pulses.

**Proposed complete procedure**

NEW adopt Warrior4 and actual equipped Bloodthick Node. At each valid original Bloodthick regular-start pulse, if Bloodthick and at least one other mutation are actually active, add1 to that same pulse base before ordinary healing modifiers/caps. Bloodthick base remains currentBT capped3, or4 with actual Stack Overflow; the extra1 can make base4 or5. NEW a lawful Bloodthick pulse atBT0 may have base1 from this modifier, but there is no independent pulse and no healing outside a real encounter. Every HP actually restored spends1 from the same Mutation Recovery Reserve (3×Warrior level+M after LR); no reserve refill from SR, encounter, form or bonus. Apply broad/passive-regeneration prohibitions, source eligibility, current maximum and Critical3-Wound healing ceiling max(1,maxHP−1). It does not remove Wounds, cure death or manufacture zeroHP action permission. NEW an already active Bloodthick pulse may heal a living0HP owner after that start's prior death-save processing if the owner survives and no actual source prohibition blocks it; incapacitation alone does not retroactively cancel this non-concentration passive mutation. A dead owner receives nothing. No excess-healing conversion from this unpaid regeneration, even at fullHP.

**Explicit NEW choices:** One pulse, active-count snapshot, explicit BT0/zeroHP completion, shared finite reserve and unchanged reviewed exclusions.

**Worked adjudications**

- BT2 plus this modifier gives base3; with only1Reserve remaining and sufficient missingHP, restore1 and spend1.

- At fullHP the pulse spends0Reserve and cannot convert its mathematical excess to another resource.

**Dependencies:** Current reviewed Core, action, condition, healing, ancestry and equipment interfaces; Exact preserved Warrior/ancestry source evidence where applicable; Shared proposed feat conventions; actual expedition verdict still pending.

<details><summary>Complete original source, counterpart and question</summary>

```json
{
  "sourceObject": {
    "id": "bioStabilizer",
    "name": "Bio-Stabilizer",
    "description": "Your mutations have stabilized, providing enhanced regeneration.",
    "prerequisite": "Bloodthick Node mutation",
    "effect": "+1 regeneration while under the effect of 2+ mutations",
    "type": "Vital_mutation",
    "draft": false,
    "deprecated": false,
    "needsReview": false
  },
  "completeClassCounterpart": {
    "id": "warrior.supplement.bio-stabilizer",
    "name": "Bio-Stabilizer",
    "className": "Warrior",
    "band": "Arch",
    "path": null,
    "sourceKind": "mutationFeat",
    "minimumClassLevel": 4,
    "acquisition": "supplement",
    "activation": "Passive",
    "cost": "Feat choice",
    "rangeAndTarget": "Self",
    "duration": "Permanent",
    "frequency": "Always",
    "effect": "While at least two mutations are active, Bloodthick Node heals 1 additional HP on each of its valid encounter-only regeneration pulses.",
    "prerequisite": "Warrior 4; Bloodthick Node equipped; eligible feat grant",
    "source": {
      "line": 4960,
      "reference": null,
      "originalText": "| Bio-Stabilizer | Bloodthick Node | +1 regen while under the effect of 2+ mutations |",
      "status": "source-derived"
    },
    "designStatus": "provisional-playtest",
    "spellRank": null
  }
}
```

Reconcile standalone+1 regeneration with Warrior4/Bloodthick equipped and the reviewed scheduling-only modifier. Require actual Bloodthick activation and two active mutations; define one added HP on the same pulse,shared Mutation Recovery Reserve,zeroHP/Wound gates and finite healing. No second pulse or free reserve refill.

</details>

### HM-04 — Born to Horrify

Source identity: `bornToHorrify`. Original prerequisite: **Any Apex Mutation**.

**Original effect, unchanged**

While your Apex mutation is active, you may reroll 1 save per turn

**Actual class counterpart, unchanged:** warrior.supplement.born-to-horrify

**Counterpart prerequisite:** Warrior 16; any Apex mutation equipped; eligible feat grant

**Counterpart effect:** When you fail a saving throw while an Apex mutation is active, reroll it and use the new result. This can occur at most once on each of your regular turns, not once per enemy turn.

**Proposed complete procedure**

NEW use the Warrior16 counterpart with any actual Apex mutation equipped and active: once on your own original regular turn, after your saving throw has failed but before consequences, optionally reroll the whole save and use the new result. Preserve its actual advantage/disadvantage configuration, rolling the appropriate new d20 set, not choosing freely among old and new dice. No Action/Reaction is required. The new result may be worse; a failed reroll cannot invoke this feat again on the same event. It can affect ordinary or death saves actually rolled on that turn if Apex remains active and source-specific zeroHP restrictions permit the passive reroll; it cannot replace an automatic failure without a roll. Off-turn saves and extra turns grant no entitlement, even if the standalone source says per turn. No banking. Applicable other reroll features retain their real limits; choose a legal order, never revisit a consumed stage.

**Explicit NEW choices:** Owner-regular-turn failed-save restriction and whole-roll mandatory replacement; preserves broader standalone alternative.

**Worked adjudications**

- On your own turn a failedCONsave with advantage rerolls two newd20s and keeps their higher result, discarding both old dice.

- A failedWISsave during an enemy turn cannot use this feat, despite an active Apex mutation.

**Dependencies:** Current reviewed Core, action, condition, healing, ancestry and equipment interfaces; Exact preserved Warrior/ancestry source evidence where applicable; Shared proposed feat conventions; actual expedition verdict still pending.

<details><summary>Complete original source, counterpart and question</summary>

```json
{
  "sourceObject": {
    "id": "bornToHorrify",
    "name": "Born to Horrify",
    "description": "Your apex mutations grant enhanced resilience.",
    "prerequisite": "Any Apex Mutation",
    "effect": "While your Apex mutation is active, you may reroll 1 save per turn",
    "type": "Aberrant_mutation",
    "draft": false,
    "deprecated": false,
    "needsReview": false
  },
  "completeClassCounterpart": {
    "id": "warrior.supplement.born-to-horrify",
    "name": "Born to Horrify",
    "className": "Warrior",
    "band": "Hero",
    "path": null,
    "sourceKind": "mutationFeat",
    "minimumClassLevel": 16,
    "acquisition": "supplement",
    "activation": "Triggered",
    "cost": "Feat choice",
    "rangeAndTarget": "Self",
    "duration": "Instantaneous",
    "frequency": "Once per regular turn while an Apex mutation is active",
    "effect": "When you fail a saving throw while an Apex mutation is active, reroll it and use the new result. This can occur at most once on each of your regular turns, not once per enemy turn.",
    "prerequisite": "Warrior 16; any Apex mutation equipped; eligible feat grant",
    "source": {
      "line": 5044,
      "reference": null,
      "originalText": "| Born to Horrify | Any Apex Mutation | While your Apex mutation is active, you may reroll 1 save per turn |",
      "status": "source-derived"
    },
    "designStatus": "provisional-playtest",
    "spellRank": null
  }
}
```

Reconcile per-turn standalone wording with Warrior16 counterpart limiting failure rerolls to the owner regular turn while Apex active. Define optional declaration after die/result,advantage/disadvantage dice,new result,one ledger and off-turn saves; do not silently treat every enemy turn as another use.

</details>

### HM-05 — Contraption Crafter

Source identity: `contraption_crafter`. Original prerequisite: **Gnome heritage**.

**Original effect, unchanged**

Construct and deploy a temporary gadget with random utility (1/day).

**Proposed complete procedure**

Require actual Gnome heritage. NEW once per24 elapsed hours, spend10 uninterrupted minutes with actual usable tinkers tools and5gp of suitable owned mundane parts; commit the use and parts at construction start. The feat grants construction permission with these tools but no general tool proficiency. On completion roll1d4 openly on the four complete profiles below; no choice, reroll, duplicate product or refund for an unwanted result. One active feat gadget at a time; beginning a new legal construction ends the old gadget. Interrupted work loses the committed parts/use and yields no working gadget. The Tiny mundane object is1lb, AC10, HP1, has no creature turn/actions, and stops after1hour from completion or destruction. Place it in a reachable legal space or activate it with the profile's Action; moving/holding uses actual hands/object rules. Ownership can pass with the real object; its expiry/remaining uses travel with it and never reset. At expiry/dismantling it becomes inert spent parts with no reusable credited crafting value; no purchased tool/supply/consumable is replenished. Explicitly NEW economics, not a claim that original source named a price. It does not inherit Tinker Gnome's separate four clockwork profiles,10gp reclaim or maintenance loop, and creates no Tinker class device/attack/companion.

**Explicit NEW choices:** Finite1d4 utility menu,10minute/5gp manufacture,24elapsed-hour cadence, real object and1hour expiry.

**Worked adjudications**

- Construction completes with a3 on the table: it produces the clamp profile only; the creator cannot reroll into a lantern.

- Giving the gadget to an ally passes the same object with its existing deadline; midnight or a rest does not refresh the feat.

**Dependencies:** Current reviewed Core, action, condition, healing, ancestry and equipment interfaces; Exact preserved Warrior/ancestry source evidence where applicable; Shared proposed feat conventions; actual expedition verdict still pending.

<details><summary>Complete original source, counterpart and question</summary>

```json
{
  "sourceObject": {
    "id": "contraption_crafter",
    "name": "Contraption Crafter",
    "description": "Racial feat tied to Gnome heritage.",
    "prerequisite": "Gnome heritage",
    "effect": "Construct and deploy a temporary gadget with random utility (1/day).",
    "type": "Racial",
    "draft": false,
    "deprecated": false,
    "needsReview": false
  },
  "completeClassCounterpart": null
}
```

Bind actual Gnome heritage eligibility and one/day recovery clock. Define a finite random-utility gadget table with creation/deployment actions,actual tools/materials,physical profile,duration,ownership,usage and end disposition. Compare Tinker Gnome ancestry and pending Tinker class/recipes without free permanent products,random undefined powers or automatic class access.

</details>

### HM-06 — Crushing Advance

Source identity: `crushing_advance`. Original prerequisite: **Ogre heritage**.

**Original effect, unchanged**

Your melee hits knock targets back 5 feet if you're moving.

**Proposed complete procedure**

Require actual Ogre heritage. NEW once on your own original regular turn, after moving at least5ft of voluntary continuous movement directly toward a target immediately before your next personal melee attack against it, a hit may push it5ft directly away. The approach must use a real movement mode and paid path with no intervening action/attack/teleport/forced displacement; the attack itself is the endpoint. The melee attack can be weapon, unarmed or spell if otherwise legal. No extra movement, attack or damage. NEW no saving throw and target at most one size larger than your actual body, not Powerful Build; choose use after hit before resolving push. Resolve damage/immediate riders first; target must still exist and be legally movable. Push uses ordinary forced-movement collision, occupies legal space and stops before a barrier, never adds collision damage or ordinary opportunity attacks. If no legal positive displacement remains, no movement occurs and the chosen attempt remains used. Other independently qualified source pushes retain their exact stacking rules; this is no once-per-hit loop.

**Explicit NEW choices:** 5ft direct approach, one own-turn trigger, one-size limit and no-save post-hit5ft push.

**Worked adjudications**

- A Large Ogre approaches5ft, hits a Huge target and may push it5ft if the path is clear.

- An ally shoving the Ogre toward a foe does not meet voluntary approach; striking a wall-backed target adds no impact damage.

**Dependencies:** Current reviewed Core, action, condition, healing, ancestry and equipment interfaces; Exact preserved Warrior/ancestry source evidence where applicable; Shared proposed feat conventions; actual expedition verdict still pending.

<details><summary>Complete original source, counterpart and question</summary>

```json
{
  "sourceObject": {
    "id": "crushing_advance",
    "name": "Crushing Advance",
    "description": "Racial feat tied to Ogre heritage.",
    "prerequisite": "Ogre heritage",
    "effect": "Your melee hits knock targets back 5 feet if you're moving.",
    "type": "Racial",
    "draft": false,
    "deprecated": false,
    "needsReview": false
  },
  "completeClassCounterpart": null
}
```

Bind actual Ogre heritage,melee hit and precise moving requirement: own movement distance,straight path,timing,one hit versus every hit and cooldown. Define5ft push direction,target-size/save/space/collision,forced movement,reach and no source-implied bonus damage or extra attacks.

</details>

### HM-07 — Cultural Legacy

Source identity: `cultural_legacy`. Original prerequisite: **Goblin heritage**.

**Original effect, unchanged**

You gain +10% effectiveness with your race’s favored skills.

**Proposed complete procedure**

Require actual Goblin heritage. NEW favored-skill scope is fixed from its actual chosen variant evidence: all Goblins gain Stealth checks through base Nimble Escape; Boom adds INT checks specifically concerning alchemy/explosives/incendiaries under Demolition Expert; Scrap adds WIS Perception to find useful junk or hidden objects and DEX Sleight of Hand to find hidden objects under its printed scavenging clauses; Shadow retains Stealth only. This is a task list derived for the feat, not a cultural truth or a new proficiency grant. On a qualifying actually rolled check, compute ordinary totalT after other legal modifiers, add floor(max(0,T)/10), then compare toDC/opposed total and apply normal task natural-result shifts. This is an explicit NEW10%-of-nonnegative-check-total interpretation of effectiveness, preserving the original percentage rather than substituting a flat bonus. No recursive multiplication, passive-perception multiplier, extra loot, reduced cost/time, spell/save/attack bonus or unprinted explosive creation. On opposed checks only your own eligible total changes. A natural1/20 retains its normal task shift; the bonus cannot abolish it. No re-roll or extra proficiency; zero/negative totals add0.

**Explicit NEW choices:** Finite variant/task list and explicit10%-of-check-total arithmetic; no invented lore or blanket reward.

**Worked adjudications**

- An eligible Stealth check total19 adds1, becoming20 before task-degree/natural-shift resolution.

- A Scrap Goblin's unrelatedMedicine check gets no bonus. An eligible check total−2 remains−2.

**Dependencies:** Current reviewed Core, action, condition, healing, ancestry and equipment interfaces; Exact preserved Warrior/ancestry source evidence where applicable; Shared proposed feat conventions; actual expedition verdict still pending.

<details><summary>Complete original source, counterpart and question</summary>

```json
{
  "sourceObject": {
    "id": "cultural_legacy",
    "name": "Cultural Legacy",
    "description": "Racial feat tied to Goblin heritage.",
    "prerequisite": "Goblin heritage",
    "effect": "You gain +10% effectiveness with your race’s favored skills.",
    "type": "Racial",
    "draft": false,
    "deprecated": false,
    "needsReview": false
  },
  "completeClassCounterpart": null
}
```

Bind Goblin heritage and identify an actual finite favored-skill list from supplied base/variant traits. Define10percent effectiveness against d20 check totals,task degrees or another explicit numerical result,including rounding/stacking. Do not invent culture/lore,apply a universal multiplier or silently replace the current percentage.

</details>

### HM-08 — Distorted Dominance

Source identity: `distortedDominance`. Original prerequisite: **Any Aberrant Mutation**.

**Original effect, unchanged**

Enemies who fail saves vs your effects also lose 1 action

**Actual class counterpart, unchanged:** warrior.supplement.distorted-dominance

**Counterpart prerequisite:** Warrior 4; any Aberrant mutation equipped; eligible feat grant

**Counterpart effect:** When a creature fails a save against your Aberrant mutation, it loses its Reaction until the end of its next turn. This provisional normalization replaces the source's undefined loss of an action and does not fully deny the target's turn.

**Proposed complete procedure**

NEW select the Warrior4 counterpart's Reaction denial, explicitly replacing the standalone oneAction loss for this proposal. Require an Aberrant mutation equipped and at least the actual generating Aberrant mutation active. When an actual hostile fails a save against your directly applied Aberrant mutation effect, it loses its Reaction through the end of its next future regular turn. This is triggered, costs no extra action, and is once per actual target per encounter across both catalog representations. Range/target legality comes from that mutation, not an additional universal aura. Source immunity/prevention blocks the applicable rider; do not add Charmed, Stunned, silence, Speed0 or new hard denial. Reaction denial affects ordinary and extra Reaction tokens but does not spend or create them; expiry reveals any other still-operative restriction. A failed save against an unrelated spell, ally effect, periodic damage without a save or equipped-but-dormant mutation does not qualify. No loss of normalAction or guarantee of surrender. Retain the broader original wording as the explicit rejected alternative pending joint decision.

**Explicit NEW choices:** Named counterpart normalization: qualifying active Aberrant save, once-target-encounter Reaction loss only.

**Worked adjudications**

- A legal active Aberrant effect causes a failedsave; the hostile loses Reactions but still acts/moves on its turn.

- A failed save against the Warrior's unrelated ordinary spell does not trigger Distorted Dominance.

**Dependencies:** Current reviewed Core, action, condition, healing, ancestry and equipment interfaces; Exact preserved Warrior/ancestry source evidence where applicable; Shared proposed feat conventions; actual expedition verdict still pending.

<details><summary>Complete original source, counterpart and question</summary>

```json
{
  "sourceObject": {
    "id": "distortedDominance",
    "name": "Distorted Dominance",
    "description": "Your aberrant nature overwhelms enemy actions.",
    "prerequisite": "Any Aberrant Mutation",
    "effect": "Enemies who fail saves vs your effects also lose 1 action",
    "type": "Aberrant_mutation",
    "draft": false,
    "deprecated": false,
    "needsReview": false
  },
  "completeClassCounterpart": {
    "id": "warrior.supplement.distorted-dominance",
    "name": "Distorted Dominance",
    "className": "Warrior",
    "band": "Arch",
    "path": null,
    "sourceKind": "mutationFeat",
    "minimumClassLevel": 4,
    "acquisition": "supplement",
    "activation": "Triggered",
    "cost": "Feat choice",
    "rangeAndTarget": "Creature failing a save against your Aberrant mutation",
    "duration": "Until end of target's next turn",
    "frequency": "Once per target per encounter",
    "effect": "When a creature fails a save against your Aberrant mutation, it loses its Reaction until the end of its next turn. This provisional normalization replaces the source's undefined loss of an action and does not fully deny the target's turn.",
    "prerequisite": "Warrior 4; any Aberrant mutation equipped; eligible feat grant",
    "source": {
      "line": 5042,
      "reference": null,
      "originalText": "| Distorted Dominance | Any Aberrant Mutation | Enemies who fail saves vs your effects also lose 1 action |",
      "status": "source-derived"
    },
    "designStatus": "provisional-playtest",
    "spellRank": null
  }
}
```

Reconcile standalone loss of one action on failed saves versus provisional Warrior4 Aberrant-only Reaction denial. Preserve both texts and any already-reviewed component scope. Resolve target/range/duration/encounter ledger,actual mutation activation and hard-control guard; any retained Action denial requires an explicit bounded decision.

</details>

### HM-09 — Elven Grace

Source identity: `elven_grace`. Original prerequisite: **Elf heritage**.

**Original effect, unchanged**

Once per combat, evade any one AoE or ranged attack completely.

**Proposed complete procedure**

Require actual Elf heritage. NEW once per real encounter, while conscious and able to take a Reaction, after one ranged attack result or one instantaneous area-effect/save result against you is known but before any of its consequences commit, spend Reaction/use to evade that one event completely. It can prevent the automatic hit/damage of a legal ranged effect only if the source actually calls it a ranged attack; a save-only single-target spell is not an area attack. A qualifying area event has one simultaneous affected-area resolution, including a breath or explosion. Against you that event deals0damage and applies none of its attached conditions, forced movement or other direct adverse riders; other targets resolve normally. No movement is created and the area/source is not erased. A continuing zone remains: this can evade one eligible initial/tick event, not later independent ticks, entry consequences or the entire duration. Separate missiles/attacks are separate events; one Reaction prevents one. An existing condition, direct HP sacrifice/death without an eligible event or self-chosen cost is not evaded. No use at0HP if ordinary zeroHP Reaction loss applies; no postdeath revival.

**Explicit NEW choices:** Reaction after result before consequences; complete one-event immunity with finite encounter ledger, no zone deletion.

**Worked adjudications**

- Grace evades one incoming critical arrow and its attachedpoison before damage; another arrow still resolves normally.

- Evading an explosion prevents its damage and push on the Elf; the burning ground it leaves can still harm the Elf on a later event.

**Dependencies:** Current reviewed Core, action, condition, healing, ancestry and equipment interfaces; Exact preserved Warrior/ancestry source evidence where applicable; Shared proposed feat conventions; actual expedition verdict still pending.

<details><summary>Complete original source, counterpart and question</summary>

```json
{
  "sourceObject": {
    "id": "elven_grace",
    "name": "Elven Grace",
    "description": "Racial feat tied to Elf heritage.",
    "prerequisite": "Elf heritage",
    "effect": "Once per combat, evade any one AoE or ranged attack completely.",
    "type": "Racial",
    "draft": false,
    "deprecated": false,
    "needsReview": false
  },
  "completeClassCounterpart": null
}
```

Define Elf heritage,once-per-real-combat ledger,voluntary declaration before/after attack/save,actual action/Reaction and eligible AoE or ranged event. Resolve multiple packets/ongoing zones/automatic damage,damage versus conditions/displacement and zeroHP permissions. No fabricated movement or broad immunity from evade.

</details>

### HM-10 — Eviscerator Protocol

Source identity: `evisceratorProtocol`. Original prerequisite: **Echo Knuckles + Talons mutations**.

**Original effect, unchanged**

Free offhand hits now apply Bleed or Weakened (player choice)

**Actual class counterpart, unchanged:** warrior.supplement.eviscerator-protocol

**Counterpart prerequisite:** Warrior 8; Echo Knuckles and Warpgrip Talons equipped; eligible feat grant

**Counterpart effect:** Choose Bleed or Weakened. Bleed deals 1d4 damage at the start of the target's next 2 turns. Weakened causes -1 damage on weapon and natural-weapon hits for 2 rounds. Reapplication refreshes rather than stacks.

**Proposed complete procedure**

NEW require Warrior8, exact Echo Knuckles and Warpgrip Talons equipped and both active when the real Echo Knuckles offhand slam hits. Talons in the standalone source binds only to that actual named card, not every claw. Once per numbered round, immediately on that hit choose one reviewed rider: Mutation Bleed1d4physical at starts of the next two regular target turns, or warrior.weakened−1total damage per weapon/natural-weapon hit, minimum0, until the end of its second future regular turn. NEW use slashing for the otherwise unspecified Bleed physical type; snapshot Warrior techniqueDC for its Medicine cure. Bleed joins current unified family arbitration; losing or suppressed due ticks are consumed normally. Same owner/profile refreshes without extra dice; ordinary positive-potential magical healing ends all eligible automatic-cure Bleeds, and ActionWISMedicine by self/adjacent helper ends one chosen record on success. Weakened does not stack its magnitude with Warpgrip or another warrior.weakened application; independent deadlines remain. No new saving throw or additional free hit. Actual immunity/source restrictions apply. Echo remains once-round, same target/reach and no recursive free attacks; this feat cannot turn the derived hit into another attack grant. Later mutation expiry does not erase an already applied rider unless its own source says so.

**Explicit NEW choices:** Exact Talons identity, both active, one Echo-hit rider and current reviewed Bleed/Weakened lifecycle.

**Worked adjudications**

- One qualifying offhand hit may apply1d4Bleed for two due starts; it never supplies a second Echo attack.

- Applying Weakened to an already−1 warrior.weakened target preserves legal deadlines but never makes−2 from this same profile.

**Dependencies:** Current reviewed Core, action, condition, healing, ancestry and equipment interfaces; Exact preserved Warrior/ancestry source evidence where applicable; Shared proposed feat conventions; actual expedition verdict still pending.

<details><summary>Complete original source, counterpart and question</summary>

```json
{
  "sourceObject": {
    "id": "evisceratorProtocol",
    "name": "Eviscerator Protocol",
    "description": "Your enhanced attacks apply debilitating effects.",
    "prerequisite": "Echo Knuckles + Talons mutations",
    "effect": "Free offhand hits now apply Bleed or Weakened (player choice)",
    "type": "Combat_mutation",
    "draft": false,
    "deprecated": false,
    "needsReview": false
  },
  "completeClassCounterpart": {
    "id": "warrior.supplement.eviscerator-protocol",
    "name": "Eviscerator Protocol",
    "className": "Warrior",
    "band": "Arch",
    "path": null,
    "sourceKind": "mutationFeat",
    "minimumClassLevel": 8,
    "acquisition": "supplement",
    "activation": "Passive",
    "cost": "Feat choice",
    "rangeAndTarget": "Echo Knuckles target",
    "duration": "As chosen condition",
    "frequency": "When Echo Knuckles hits, once per round",
    "effect": "Choose Bleed or Weakened. Bleed deals 1d4 damage at the start of the target's next 2 turns. Weakened causes -1 damage on weapon and natural-weapon hits for 2 rounds. Reapplication refreshes rather than stacks.",
    "prerequisite": "Warrior 8; Echo Knuckles and Warpgrip Talons equipped; eligible feat grant",
    "source": {
      "line": 5003,
      "reference": null,
      "originalText": "| Eviscerator Protocol | Echo Knuckles + Talons | Free offhand hits now apply Bleed or Weakened (player choice) |",
      "status": "source-derived"
    },
    "designStatus": "provisional-playtest",
    "spellRank": null
  }
}
```

Reconcile Echo Knuckles plus Talons with actual Warpgrip Talons counterpart and Warrior8 gate. Define equipped versus active requirements,one real offhand hit,choice of Bleed/Weakened,source ownership,pulse/expiry/cure/stacking. Preserve reviewed free-attack limits and no recursive on-hit/free-attack generation.

</details>

### HM-11 — Evolution Under Fire

Source identity: `evolutionUnderFire`. Original prerequisite: **Any Apex Mutation**.

**Original effect, unchanged**

When you take >15 damage from a single hit, reduce cooldowns by 1 round

**Actual class counterpart, unchanged:** warrior.supplement.evolution-under-fire

**Counterpart prerequisite:** Warrior 16; any Apex mutation equipped; eligible feat grant

**Counterpart effect:** When one damage event deals more than 15 actual damage to you, reduce one positive Warrior round-recharge counter by 1, minimum 0, subject to the universal reset/shortening cap.

**Proposed complete procedure**

NEW adopt Warrior16, an actual Apex equipped and active, and the counterpart one damage-event definition in place of single-hit-only wording. After one hostile-caused event deals numeric actualDamageDealt greater than15 to you and you survive with the Apex still active, you may shorten one positive Warrior round-recharge counter by1, minimum0, at most once per numbered round. TempHP actually absorbed counts; uncapped resolved/post-temp amounts and overkill do not. Sixteen qualifies, fifteen does not. Mixed types from one event add once; separate hits never combine. Choose an actual acquired Warrior ability with a positive counter that has not already received its one reset/shortening this round; this consumes that ability's shared shortening allowance. A zero counter, RP, serum dose, Mutation Reserve, BT, SR/LR use or another class's counter is ineligible. Recheck after fatal/threshold consequences; Butcherform ending belowquarter prevents its use as the required activeApex. Friendly/staged/self damage and HP sacrifice cannot farm recharge. Outside a real encounter there is no hostile round-shortening loop.

**Explicit NEW choices:** ActiveApex and hostile numeric actual damage>15, one counter and one round cap; counterpart event scope explicit.

**Worked adjudications**

- An enemy event absorbs10tempHP and removes6normalHP:16actual permits shorteningRecharge2 to1.

- AtHP3 with no tempHP a20damage hit has at most3actualHPdamage before other replacement limits; it does not meet16, even though raw damage was20.

**Dependencies:** Current reviewed Core, action, condition, healing, ancestry and equipment interfaces; Exact preserved Warrior/ancestry source evidence where applicable; Shared proposed feat conventions; actual expedition verdict still pending.

<details><summary>Complete original source, counterpart and question</summary>

```json
{
  "sourceObject": {
    "id": "evolutionUnderFire",
    "name": "Evolution Under Fire",
    "description": "Severe damage triggers rapid adaptation.",
    "prerequisite": "Any Apex Mutation",
    "effect": "When you take >15 damage from a single hit, reduce cooldowns by 1 round",
    "type": "Vital_mutation",
    "draft": false,
    "deprecated": false,
    "needsReview": false
  },
  "completeClassCounterpart": {
    "id": "warrior.supplement.evolution-under-fire",
    "name": "Evolution Under Fire",
    "className": "Warrior",
    "band": "Hero",
    "path": null,
    "sourceKind": "mutationFeat",
    "minimumClassLevel": 16,
    "acquisition": "supplement",
    "activation": "Triggered",
    "cost": "Feat choice",
    "rangeAndTarget": "One Warrior ability with positive recharge",
    "duration": "Instantaneous",
    "frequency": "At most once per round",
    "effect": "When one damage event deals more than 15 actual damage to you, reduce one positive Warrior round-recharge counter by 1, minimum 0, subject to the universal reset/shortening cap.",
    "prerequisite": "Warrior 16; any Apex mutation equipped; eligible feat grant",
    "source": {
      "line": 4963,
      "reference": null,
      "originalText": "| Evolution Under Fire | Any Apex Mutation | Whenever you take >15 damage from a single hit, reduce cooldowns by 1 round |",
      "status": "source-derived"
    },
    "designStatus": "provisional-playtest",
    "spellRank": null
  }
}
```

Reconcile single hit>15 versus counterpart actual damage event>15,Warrior16,one positive Warrior recharge counter and once-per-round shortening cap. Specify mitigation/tempHP/ward quantities,threshold exactness,which counter,active Apex requirement and no spent rest-use restoration.

</details>

### HM-12 — Glamourborn

Source identity: `glamourborn`. Original prerequisite: **Feykin heritage**.

**Original effect, unchanged**

Enemies attacking you for the first time have a 20% miss chance.

**Proposed complete procedure**

Require actual Feykin heritage. NEW for each actual hostile identity in one real encounter, its first legally declared attack against you faces a20% miss check: roll1d100 once,1–20 makes that attack miss,21–100 proceeds normally. Commit the attacker's action, ammunition and source costs first, then roll this check before its ordinary attack die or automatic-hit resolution. The first legal attack consumes that attacker's encounter record even if the percentage check succeeds or its later attack roll would miss. No record is spent by an illegal/out-of-range declaration. It applies to real melee/ranged weapon, unarmed and spell attacks, including a source-qualified automatic-hit attack; an automatic damaging effect without attack classification, save-only effect, ongoing tick or environmental damage is not an attack. A blocked first attack has no on-hit/critical result, but actual miss riders can operate. For a multiattack sequence only its first attack faces this roll; one attack with several components faces one check. No sight requirement on either combatant is invented. Leaving/reentering, disguise, charm changes or a new form of the same attacker never resets the record. This is a supernatural feat defense with no creature-type, invisibility or cosmology grant.

**Explicit NEW choices:** Exactd10020% stage, first legal attack per hostile identity per encounter, no saving-effect immunity.

**Worked adjudications**

- The first enemy arrow rolls17 on the miss check and misses; its ammunition is spent and its second arrow rolls normally.

- An enemy first uses a save-only spell, then a sword attack: the sword is still its first qualifying attack against you.

**Dependencies:** Current reviewed Core, action, condition, healing, ancestry and equipment interfaces; Exact preserved Warrior/ancestry source evidence where applicable; Shared proposed feat conventions; actual expedition verdict still pending.

<details><summary>Complete original source, counterpart and question</summary>

```json
{
  "sourceObject": {
    "id": "glamourborn",
    "name": "Glamourborn",
    "description": "Racial feat tied to Feykin heritage.",
    "prerequisite": "Feykin heritage",
    "effect": "Enemies attacking you for the first time have a 20% miss chance.",
    "type": "Racial",
    "draft": false,
    "deprecated": false,
    "needsReview": false
  },
  "completeClassCounterpart": null
}
```

Bind Feykin heritage,each enemy first attack timing and what resets that record. Define actual20percent miss roll,order versus attack/critical/advantage,ranged/melee/spell attacks,unseen enemies,multiple attacks and invalid declarations. No spell-save immunity,invisibility or Fey cosmology inference.

</details>

### HM-13 — Hypermutation Spike

Source identity: `hypermutationSpike`. Original prerequisite: **Butcherform Chassis (Apex) mutation**.

**Original effect, unchanged**

Once per long rest, extend Butcherform to 5 rounds and become immune to stun/slow during duration

**Actual class counterpart, unchanged:** warrior.supplement.hypermutation-spike

**Counterpart prerequisite:** Warrior 16; Butcherform Chassis equipped; eligible feat grant

**Counterpart effect:** When Butcherform Chassis activates, extend its maximum duration from 3 rounds to 5. During that activation you are immune to Stunned and your Speed cannot be reduced below half its normal value.

**Proposed complete procedure**

NEW use Warrior16, actual equipped Butcherform Chassis and its legal activation. At that activation, optionally spend this feat's1/LR use to set that activation's maximum duration to five rounds instead of three, retaining its original owner regular-start expiry clock and all shorter ending conditions. It is one enhanced activation, not five additional rounds, a later free extension or a refreshed serum dose. CurrentHP strictly below one-quarter effective maximum ends Butcherform and this enhancement immediately; exact quarter remains legal. Increasing maximum can end it. During that same active unsuppressed activation, immune to Stunned and apply the already reviewed Hypermutation per-mode Speed floor: snapshot ordinary permanent/qualifying-persistent sheet modes at activation, excluding temporary buffs, stances, Strain, cargo, Exhaustion and the feat; floor for each is floor(snapshot/2). Apply after numeric changes/multipliers, but never defeat explicit Speed0, Root, Grappled/Restrained, Exhaustion5, absent modes, terrain costs or separate voluntary-movement prohibition. The standalone broad slow immunity is explicitly normalized to this reviewed narrower floor. Temporary suppression disables both new benefits while clocks continue; unsuppression before true expiry returns the same snapshot/use, never a fresh five rounds. Actual ended mutation cannot return without new paid activation. Stunned records follow current immunity/suppression rules; the feat does not erase unrelated conditions.

**Explicit NEW choices:** One1/LR activation and five-round maximum, active Stun immunity plus exact reviewed Speed snapshot/floor rather than generic slow immunity.

**Worked adjudications**

- An ordinary capturedwalk30 has floor15, but a realGrappled record still makes movement unavailable.

- HP10/max40 remains exactlyquarter; max rising to41 ends Butcherform without damage and loses the enhancement.

**Dependencies:** Current reviewed Core, action, condition, healing, ancestry and equipment interfaces; Exact preserved Warrior/ancestry source evidence where applicable; Shared proposed feat conventions; actual expedition verdict still pending.

<details><summary>Complete original source, counterpart and question</summary>

```json
{
  "sourceObject": {
    "id": "hypermutationSpike",
    "name": "Hypermutation Spike",
    "description": "Extend your apex transformation beyond normal limits.",
    "prerequisite": "Butcherform Chassis (Apex) mutation",
    "effect": "Once per long rest, extend Butcherform to 5 rounds and become immune to stun/slow during duration",
    "type": "Combat_mutation",
    "draft": false,
    "deprecated": false,
    "needsReview": false
  },
  "completeClassCounterpart": {
    "id": "warrior.supplement.hypermutation-spike",
    "name": "Hypermutation Spike",
    "className": "Warrior",
    "band": "Hero",
    "path": null,
    "sourceKind": "mutationFeat",
    "minimumClassLevel": 16,
    "acquisition": "supplement",
    "activation": "Triggered",
    "cost": "Feat choice",
    "rangeAndTarget": "Self",
    "duration": "For one Butcherform activation",
    "frequency": "1/long rest",
    "effect": "When Butcherform Chassis activates, extend its maximum duration from 3 rounds to 5. During that activation you are immune to Stunned and your Speed cannot be reduced below half its normal value.",
    "prerequisite": "Warrior 16; Butcherform Chassis equipped; eligible feat grant",
    "source": {
      "line": 5004,
      "reference": null,
      "originalText": "| Hypermutation Spike | Butcherform Chassis (Apex) | Once per long rest, extend Butcherform to 5 rounds and become immune to stun/slow during duration |",
      "status": "source-derived"
    },
    "designStatus": "provisional-playtest",
    "spellRank": null
  }
}
```

Reconcile source stun/slow immunity with Warrior16 five-round Butcherform and the reviewed per-mode Speed-floor procedure. Define one activation,Long Rest expenditure,currentHP quarter-threshold ending,loss/suppression/return and Stunned scope. Keep existing physical restraint and root rules; no broad immunity created from slow wording.

</details>

### HM-14 — Juggernaut's Core

Source identity: `juggernautCore`. Original prerequisite: **Ossified Core mutation**.

**Original effect, unchanged**

If you are immune to critical hits, gain resistance to sneak attack damage

**Actual class counterpart, unchanged:** warrior.supplement.juggernaut-s-core

**Counterpart prerequisite:** Warrior 8; Ossified Core equipped; eligible feat grant

**Counterpart effect:** While Ossified Core is active, reduce extra damage explicitly granted by Sneak Attack or equivalent precision-damage features by half, rounded down. Ordinary weapon damage is unaffected.

**Proposed complete procedure**

NEW require Warrior8 and equipped/active Ossified Core. Its existing extra-critical-dice prevention is the qualifying critical-protection state; the feat does not declare every critical hit a normal hit or prevent critical-triggered riders. Adopt the counterpart scope: halve only bonus damage explicitly identified by an actual source as Sneak Attack or equivalent precision damage. A critical, poison, elemental infusion, spell rider or ordinary ability modifier is not automatically precision. NEW this halving is a source-specific precision resistance layer: halve each typed precision component once, rounding down; an existing same-type damage resistance also covering that component does not halve it again. Other nonprecision damage remains subject to its own ordinary defenses; vulnerability/immunity and fixed reduction use current damage ordering. If mixed precision types have already been separated, apply their own immunity/resistance once each; do not halve the entire weapon packet because one part is precision. Ossified's separate post-resistance piercing−2 applies once by its own event contract. Benefits stop when Ossified is not active. No new resistance to every critical or all physical damage.

**Explicit NEW choices:** Ossified-specific qualification, explicit source-tagged precision component and one same-component resistance calculation.

**Worked adjudications**

- A piercing hit has8ordinary plus7Sneak Attack: the feat makes precision3, producing11 before other applicable fixed defenses.

- If piercing resistance already halves both parts, the7precision becomes3 once; Juggernaut's Core does not quarter it to1.

**Dependencies:** Current reviewed Core, action, condition, healing, ancestry and equipment interfaces; Exact preserved Warrior/ancestry source evidence where applicable; Shared proposed feat conventions; actual expedition verdict still pending.

<details><summary>Complete original source, counterpart and question</summary>

```json
{
  "sourceObject": {
    "id": "juggernautCore",
    "name": "Juggernaut's Core",
    "description": "Your ossified core provides protection against precision attacks.",
    "prerequisite": "Ossified Core mutation",
    "effect": "If you are immune to critical hits, gain resistance to sneak attack damage",
    "type": "Vital_mutation",
    "draft": false,
    "deprecated": false,
    "needsReview": false
  },
  "completeClassCounterpart": {
    "id": "warrior.supplement.juggernaut-s-core",
    "name": "Juggernaut's Core",
    "className": "Warrior",
    "band": "Arch",
    "path": null,
    "sourceKind": "mutationFeat",
    "minimumClassLevel": 8,
    "acquisition": "supplement",
    "activation": "Passive",
    "cost": "Feat choice",
    "rangeAndTarget": "Self",
    "duration": "Permanent",
    "frequency": "While Ossified Core is active",
    "effect": "While Ossified Core is active, reduce extra damage explicitly granted by Sneak Attack or equivalent precision-damage features by half, rounded down. Ordinary weapon damage is unaffected.",
    "prerequisite": "Warrior 8; Ossified Core equipped; eligible feat grant",
    "source": {
      "line": 4961,
      "reference": null,
      "originalText": "| Juggernaut's Core | Ossified Core | If you are immune to crits, gain resistance to sneak attack damage |",
      "status": "source-derived"
    },
    "designStatus": "provisional-playtest",
    "spellRank": null
  }
}
```

Reconcile critical immunity condition with actual Ossified Core suppression of extra critical dice and Warrior8 precision-damage halving. Define active mutation,actual Sneak Attack/other precision scope,only the extra component,rounding/order versus resistance and mixed types. Ordinary weapon damage and critical-trigger effects remain distinct.

</details>

### HM-15 — Kill-Chain Adaptation

Source identity: `killChainAdaptation`. Original prerequisite: **2 Combat Mutations**.

**Original effect, unchanged**

After a melee kill, gain +10 ft movement and +1 to hit

**Actual class counterpart, unchanged:** warrior.supplement.kill-chain-adaptation

**Counterpart prerequisite:** Warrior 4; two Combat mutations equipped; eligible feat grant

**Counterpart effect:** After you personally reduce a meaningful hostile creature to 0 HP with a melee attack, gain +10 feet Speed and +1 on your next melee attack roll before the end of your next regular turn.

**Proposed complete procedure**

NEW require Warrior4 and two actual Combat mutations equipped and active at the trigger. Once per numbered round, after your personal direct melee attack reduces an independent meaningful hostile from positiveHP to0, gain+10ft to each existing usable Speed mode and one+1 entitlement on your next melee attack roll, both ending at the end of your next future original regular turn. This intentionally selects the counterpart zeroHP trigger rather than requiring actual death; resolve floors/knockout/death replacements first. The trigger grants no attack or fullAction. Copies, owned companion damage, ongoing ticks, captives, harmless targets and recycled bodies do not qualify. Modes derived from another Speed include this bonus once, not twice; previously spent movement remains spent. The attack entitlement consumes on the next legal melee attack roll, hit or miss; a save-only melee effect does not consume it. Same-family new trigger may refresh an unexpired record under the once-round cap but never gives+20ft or queued+1s. It ends if required equipped or active mutation eligibility is lost, even before its deadline. Encounter transitions do not extend or refresh either benefit.

**Explicit NEW choices:** Warrior4 and two activeCombat, genuine positive-to-zero trigger, one round grant with bounded Speed and nextattack effects.

**Worked adjudications**

- A qualifying melee down adds10 towalk30, but moving30 earlier still leaves only10 ordinary movement after the newSpeed40.

- A second down in the same round adds nothing. The next legal melee attack consumes+1 even if it misses.

**Dependencies:** Current reviewed Core, action, condition, healing, ancestry and equipment interfaces; Exact preserved Warrior/ancestry source evidence where applicable; Shared proposed feat conventions; actual expedition verdict still pending.

<details><summary>Complete original source, counterpart and question</summary>

```json
{
  "sourceObject": {
    "id": "killChainAdaptation",
    "name": "Kill-Chain Adaptation",
    "description": "Successful kills enhance your combat capabilities.",
    "prerequisite": "2 Combat Mutations",
    "effect": "After a melee kill, gain +10 ft movement and +1 to hit",
    "type": "Combat_mutation",
    "draft": false,
    "deprecated": false,
    "needsReview": false
  },
  "completeClassCounterpart": {
    "id": "warrior.supplement.kill-chain-adaptation",
    "name": "Kill-Chain Adaptation",
    "className": "Warrior",
    "band": "Arch",
    "path": null,
    "sourceKind": "mutationFeat",
    "minimumClassLevel": 4,
    "acquisition": "supplement",
    "activation": "Triggered",
    "cost": "Feat choice",
    "rangeAndTarget": "Self",
    "duration": "Until end of next regular turn",
    "frequency": "Once per round",
    "effect": "After you personally reduce a meaningful hostile creature to 0 HP with a melee attack, gain +10 feet Speed and +1 on your next melee attack roll before the end of your next regular turn.",
    "prerequisite": "Warrior 4; two Combat mutations equipped; eligible feat grant",
    "source": {
      "line": 5001,
      "reference": null,
      "originalText": "| Kill-Chain Adaptation | 2 Combat Mutations | After a melee kill, gain +10 ft movement and +1 to hit |",
      "status": "source-derived"
    },
    "designStatus": "provisional-playtest",
    "spellRank": null
  }
}
```

Reconcile melee kill with Warrior4 counterpart meaningful-hostile zeroHP,once per round,next-melee-attack+1 and Speed+10 until next regular-turn end. Define dying/dead distinction,ownership,refresh/stacking,actual mutation activation and movement already spent. Preserve anti-farming and no additional full Action.

</details>

### HM-16 — Living Fortress

Source identity: `livingFortress`. Original prerequisite: **3 Vital Mutations active**.

**Original effect, unchanged**

Gain immunity to flanking

**Actual class counterpart, unchanged:** warrior.supplement.living-fortress

**Counterpart prerequisite:** Warrior 8; three Vital mutations equipped; eligible feat grant

**Counterpart effect:** You cannot grant advantage to an enemy solely because it is flanking you. Other sources of advantage still apply.

**Proposed complete procedure**

NEW require Warrior8 and three actual Vital mutations equipped for acquisition; the benefit operates only while at least three distinct Vital mutations are actually active. No feat adds slots or active limits: the Warrior must have actual unlocked slots and an expressly acquired temporary active-count exception where needed. A Warrior8 normally cannot equip three mutations, so the printed level is a minimum rather than proof of present eligibility. Selected doctrine is the counterpart precise protection: opponents receive no advantage solely from a source explicitly granting advantage for flanking you. Reviewed ordinary combat has no global flanking advantage; this feat does not invent one. Independent unseen/Restrained/other advantage survives. It does not erase nearby bodies, ally assistance, legal target geometry, Tactical Flanker's separately proposed damage die, attacks or cover. When any required active state ends/suppresses, protection immediately stops; restoration within existing durations can restore protection without new actions or resources. No numericalAC/DR or immunity to all positioning effects.

**Explicit NEW choices:** Actual three-equipped/three-active feasibility and sole flanking-advantage protection; no fictitious slot unlock.

**Worked adjudications**

- Three Vital mutations active through a real temporary exception protect against an actual flanking-advantage feature.

- With only two active mutations, having the third equipped dormant grants no benefit; unrelated attack advantage is never removed.

**Dependencies:** Current reviewed Core, action, condition, healing, ancestry and equipment interfaces; Exact preserved Warrior/ancestry source evidence where applicable; Shared proposed feat conventions; actual expedition verdict still pending.

<details><summary>Complete original source, counterpart and question</summary>

```json
{
  "sourceObject": {
    "id": "livingFortress",
    "name": "Living Fortress",
    "description": "Multiple vital mutations make you nearly impregnable.",
    "prerequisite": "3 Vital Mutations active",
    "effect": "Gain immunity to flanking",
    "type": "Vital_mutation",
    "draft": false,
    "deprecated": false,
    "needsReview": false
  },
  "completeClassCounterpart": {
    "id": "warrior.supplement.living-fortress",
    "name": "Living Fortress",
    "className": "Warrior",
    "band": "Arch",
    "path": null,
    "sourceKind": "mutationFeat",
    "minimumClassLevel": 8,
    "acquisition": "supplement",
    "activation": "Passive",
    "cost": "Feat choice",
    "rangeAndTarget": "Self",
    "duration": "Permanent",
    "frequency": "While at least three Vital mutations are active",
    "effect": "You cannot grant advantage to an enemy solely because it is flanking you. Other sources of advantage still apply.",
    "prerequisite": "Warrior 8; three Vital mutations equipped; eligible feat grant",
    "source": {
      "line": 4962,
      "reference": null,
      "originalText": "| Living Fortress | 3 Vital Mutations active | Gain immunity to flanking |",
      "status": "source-derived"
    },
    "designStatus": "provisional-playtest",
    "spellRank": null
  }
}
```

Bind three actually active Vital mutations against real slot/active limits and temporary exceptions; resolve equipped-only prerequisite versus active benefit and Warrior8 gate. Identify actual flanking rule before denying its sole advantage. Do not erase other advantage sources,nearby allies or tactical positioning effects by an undefined blanket immunity.

</details>

### HM-17 — Nightfang Training

Source identity: `nightfang_training`. Original prerequisite: **Umbrin heritage**.

**Original effect, unchanged**

You gain +10% damage and +2 stealth in total darkness.

**Proposed complete procedure**

Require actual Umbrin heritage. While your actual occupied space is in total darkness, gain+2 to actualDEXStealth checks and add floor(native damage/10) to each eligible personal direct attack/spell damage event. NEW your whole occupied footprint must be dark, not dim or partly illuminated; determine this independently from darkvision, which changes perception rather than illumination. It grants no ability to see targets, Hide automatically or ignore your actual Sunlight Sensitivity. Damage bonus uses the already proposed common pre-percentage base after critical dice/flat additions and before defenses; allocate increment across native typed components by proportional largest remainder with stable ties. Count direct initial attacks/spell resolutions, not copies, companion attacks, transfers or later ongoing ticks; one area event uses each target's actual native packet after its save as usual. No new attack/damage event or added damage type. Check darkness at the attack/spell's actual damage resolution and at the Stealth check; a light-generating effect can remove eligibility before damage. Distinct percentage sources do not compound and the flatStealth bonus never grants a proficiency credential.

**Explicit NEW choices:** Full-footprint total darkness, exact10% native direct damage arithmetic and legalStealth+2.

**Worked adjudications**

- A qualifying native19damage packet adds1 before defenses; later darkness-independent poison ticks do not inherit the feat bonus.

- Darkvision lets the Umbrin perceive a dark square but does not turn it bright. A square actually lit dimly no longer qualifies.

**Dependencies:** Current reviewed Core, action, condition, healing, ancestry and equipment interfaces; Exact preserved Warrior/ancestry source evidence where applicable; Shared proposed feat conventions; actual expedition verdict still pending.

<details><summary>Complete original source, counterpart and question</summary>

```json
{
  "sourceObject": {
    "id": "nightfang_training",
    "name": "Nightfang Training",
    "description": "Racial feat tied to Umbrin heritage.",
    "prerequisite": "Umbrin heritage",
    "effect": "You gain +10% damage and +2 stealth in total darkness.",
    "type": "Racial",
    "draft": false,
    "deprecated": false,
    "needsReview": false
  },
  "completeClassCounterpart": null
}
```

Bind Umbrin heritage,total darkness and actual senses without granting sight. Define10percent damage sources,packets/critical/rounding/resistance and+2 Stealth ability checks; require legal hiding. Preserve bright/dim versus total-dark boundaries and do not change ancestry/origin.

</details>

### HM-18 — Orcish Warpath

Source identity: `orcish_warpath`. Original prerequisite: **Orc heritage**.

**Original effect, unchanged**

You gain +2 strength temporarily after defeating an enemy (stacks up to 3).

**Proposed complete procedure**

Require actual Orc heritage. NEW after your personal direct attack or personally resolved immediate spell/feature damage reduces a meaningful hostile from positiveHP to0, gain one temporary+2STR-score stack, maximum three. Death is not required; floors/replacements preventing the drop and staged/cooperative targets do not qualify. One actual target identity can yield at most one stack per encounter, and copied/periodic/companion damage yields none. Each stack lasts through the end of your next future regular turn; additional eligible distinct targets add independent stacks up to three, and at cap a new genuine trigger may refresh only the earliest-expiring stack. No rest/refill/initiative transition resets their deadlines. NEW apply up to+6STR without raising a score below20 past20; a separately legitimate underlying score above20 remains unchanged rather than reduced and gains no increase from this feat. Recompute the actual STR modifier for attacks, damage, saves, checks and carrying at each relevant moment; never add2 directly to the modifier. Derived maximumHP does not change from STR. Temporary increases cannot satisfy permanent acquisition/multiclass/feat prerequisites or create lasting learned choices. Expiry removes only its own layer and can cause ordinary encumbrance; it creates no damage or new movement.

**Explicit NEW choices:** Three independent bounded+2score stacks, distinct meaningful targets, cap20 and no permanent-prerequisite exploit.

**Worked adjudications**

- STR15 with two live stacks becomes19, changing modifier+2 to+4; a third reaches20, not21.

- Dropping the same revived/cycled foe again cannot grant another stack that encounter. Expiry restores the underlying score.

**Dependencies:** Current reviewed Core, action, condition, healing, ancestry and equipment interfaces; Exact preserved Warrior/ancestry source evidence where applicable; Shared proposed feat conventions; actual expedition verdict still pending.

<details><summary>Complete original source, counterpart and question</summary>

```json
{
  "sourceObject": {
    "id": "orcish_warpath",
    "name": "Orcish Warpath",
    "description": "Racial feat tied to Orc heritage.",
    "prerequisite": "Orc heritage",
    "effect": "You gain +2 strength temporarily after defeating an enemy (stacks up to 3).",
    "type": "Racial",
    "draft": false,
    "deprecated": false,
    "needsReview": false
  },
  "completeClassCounterpart": null
}
```

Bind Orc heritage and personally defeating a meaningful enemy,not arbitrary party kills. Define temporary+2 Strength score versus modifier,maximum3 stacks,duration/refresh/reset and ordinary or explicit score cap. Recompute actual attacks,checks,carrying/prerequisites consistently without permanently learning gated choices or creating repeated kill buffs.

</details>

### HM-19 — Primal Recovery

Source identity: `primal_recovery`. Original prerequisite: **Troll heritage**.

**Original effect, unchanged**

Once per combat, instantly recover from a debuff or status condition.

**Proposed complete procedure**

Require actual Troll heritage. NEW once per real encounter, when one eligible adverse condition record would apply to you, or at the start of your own original regular turn, voluntarily end that one selected record immediately without Action/BA/Reaction. On-application choice occurs before its consequences and may avert its resulting incapacity. At your start you must still be alive and conscious; this specific non-action choice may be made while Incapacitated, Stunned or Paralyzed, but supplies no other actions. Select one ordinary source-applied Blinded, Deafened, Charmed, Frightened, Poisoned, Staggered, Stunned, Paralyzed, Silenced, Slowed, Root, Shaken, Disoriented, Weakened, Dazed, Bleeding, ongoing-fire or magical-sleep record with an ordinary removal endpoint. Pending Disoriented can be ended before transition. Explicit protected/artifact/special-cure-only records remain protected. This is a NEW finite interpretation of any debuff/status, not silent proof of the broad source promise. No cure of death, zeroHP Unconscious/dying state, Wounds/Injuries, disease/curses, exhaustion, serum/expedition Strain, class-resource costs, physical restraints/Grappled/Restrained, actual blindness from absent eyes, or environmental cause. Root qualifies only if magical/control, not physical ties. It ends one effect record, not its parent area/poison/disease, and may be reapplied by a later legal exposure. Removing Poisoned does not cancel a separate damage schedule. A current engulfingfire may create a new burn; the cure creates no lasting immunity. NoHP or regeneration pulse; acid/fire inhibition of Troll regeneration remains.

**Explicit NEW choices:** One non-action voluntary condition cure, explicit incapacitation window, finite condition list and real-cause/protected-source exclusions.

**Worked adjudications**

- A conscious Troll may use the feat at its start to end oneStunned record, then acts only if no other restriction remains.

- It may remove ordinaryBleeding without healingHP, but cannot remove aWound or loosen the actual ropes causingRestrained.

**Dependencies:** Current reviewed Core, action, condition, healing, ancestry and equipment interfaces; Exact preserved Warrior/ancestry source evidence where applicable; Shared proposed feat conventions; actual expedition verdict still pending.

<details><summary>Complete original source, counterpart and question</summary>

```json
{
  "sourceObject": {
    "id": "primal_recovery",
    "name": "Primal Recovery",
    "description": "Racial feat tied to Troll heritage.",
    "prerequisite": "Troll heritage",
    "effect": "Once per combat, instantly recover from a debuff or status condition.",
    "type": "Racial",
    "draft": false,
    "deprecated": false,
    "needsReview": false
  },
  "completeClassCounterpart": null
}
```

Bind Troll heritage and once-per-real-combat use with declaration/action timing,zeroHP/incapacity restrictions and an explicit eligible condition/debuff scope. Distinguish cure,suppression,ongoing sources,physical restraints,Wounds/disease/curses/death and ability availability. Do not reduce any-status source promise silently; decide necessary exceptions with evidence.

</details>

### HM-20 — Synaptic Rot

Source identity: `synapticRot`. Original prerequisite: **Wailing Eye or Viral Core mutation**.

**Original effect, unchanged**

If an enemy fails a WIS or INT save near you, they cannot cast spells next round

**Actual class counterpart, unchanged:** warrior.supplement.synaptic-rot

**Counterpart prerequisite:** Warrior 8; Wailing Eye Cluster or Viral Core Sacs equipped; eligible feat grant

**Counterpart effect:** When the target fails the qualifying save, it is Silenced until the end of its next turn. This does not prevent non-spell abilities.

**Proposed complete procedure**

NEW select the Warrior8 counterpart over nearby-any-save/all-spell-shutdown wording. Require Wailing Eye Cluster or Viral Core Sacs equipped and at least one of those exact mutations active. When an actual hostile within15ft and line of effect fails anINT orWIS save against your own direct Warrior feature, apply actualSilenced until the end of its next future regular turn, once per target per numbered round. The generating Warrior feature need not be the equipped prerequisite itself, but must be actually acquired/active/legal; an ally spell or unrelated ordinary spell does not qualify. Source names Wailing Eye and Viral Core bind only to the named actual cards. ActualSilenced prevents verbal components, command words, Chants and audible coordination; nonverbal spells and nonspell abilities remain possible if otherwise legal. No new universal spell ban or action loss. Same-profile reapplication may preserve later expiry without stacking, but the round ledger and source immunity apply. Gaining a nonverbal casting permission is not retroactively denied. No automatic target identification, sound-detection channel or ongoing15ft tether after application; later range loss does not erase the legal record.

**Explicit NEW choices:** Exact active prerequisite,15ft actual ownWarriorINT/WISfailure and reviewed verbal-onlySilenced.

**Worked adjudications**

- A nearby hostile failsWIS against an acquired Warrior feature while Wailing Eye is active: its verbal spell is blocked through the deadline.

- A legally nonverbal spell remains usable; the original all-spells wording is preserved as the explicit alternative for review.

**Dependencies:** Current reviewed Core, action, condition, healing, ancestry and equipment interfaces; Exact preserved Warrior/ancestry source evidence where applicable; Shared proposed feat conventions; actual expedition verdict still pending.

<details><summary>Complete original source, counterpart and question</summary>

```json
{
  "sourceObject": {
    "id": "synapticRot",
    "name": "Synaptic Rot",
    "description": "Mental attacks disrupt enemy spellcasting.",
    "prerequisite": "Wailing Eye or Viral Core mutation",
    "effect": "If an enemy fails a WIS or INT save near you, they cannot cast spells next round",
    "type": "Aberrant_mutation",
    "draft": false,
    "deprecated": false,
    "needsReview": false
  },
  "completeClassCounterpart": {
    "id": "warrior.supplement.synaptic-rot",
    "name": "Synaptic Rot",
    "className": "Warrior",
    "band": "Arch",
    "path": null,
    "sourceKind": "mutationFeat",
    "minimumClassLevel": 8,
    "acquisition": "supplement",
    "activation": "Triggered",
    "cost": "Feat choice",
    "rangeAndTarget": "Enemy within 15 feet failing a Wisdom or Intelligence save against your Warrior feature",
    "duration": "Until end of target's next turn",
    "frequency": "Once per target per round",
    "effect": "When the target fails the qualifying save, it is Silenced until the end of its next turn. This does not prevent non-spell abilities.",
    "prerequisite": "Warrior 8; Wailing Eye Cluster or Viral Core Sacs equipped; eligible feat grant",
    "source": {
      "line": 5045,
      "reference": null,
      "originalText": "| Synaptic Rot | Wailing Eye or Viral Core | If an enemy fails a WIS or INT save near you, they cannot cast spells next round |",
      "status": "source-derived"
    },
    "designStatus": "provisional-playtest",
    "spellRank": null
  }
}
```

Reconcile nearby any enemy WIS/INT failure with Warrior8/15ft/your-feature/once-target-round counterpart and actual Silenced rules. Define verbal-only versus all-spell denial,save sources,active Wailing Eye Cluster/Viral Core Sacs binding and end-of-next-turn clock. Preserve nonspell abilities and source conflicts for explicit decision.

</details>

### HM-21 — Terror Engine

Source identity: `terrorEngine`. Original prerequisite: **Carrion Signal Gland mutation**.

**Original effect, unchanged**

If 2+ enemies are Shaken or Disoriented, gain +2 DR

**Actual class counterpart, unchanged:** warrior.supplement.terror-engine

**Counterpart prerequisite:** Warrior 8; Carrion Signal Gland equipped; eligible feat grant

**Counterpart effect:** While at least two hostile creatures within 30 feet are currently Shaken, Frightened or Disoriented by your Warrior features, reduce the first damage you take each round by 2.

**Proposed complete procedure**

NEW select Warrior8 and actual Carrion Signal Gland equipped/active. At each incoming direct damage event, count distinct meaningful hostiles within30ft and line of effect currently carrying an active unsuppressed Shaken, Frightened or activeDisoriented record caused by your own Warrior features. Two or more qualify; pendingDisoriented does not, and multiple records on one creature count as one creature. NEW the first positive resolved event in the numbered round while this predicate holds receives2whole-event damage reduction, minimum0, after passive typed defenses and before temporaryHP. Consume the feat's round entitlement when applied even if the reduction makes damage0; an event already at0 does not consume it. Stable component order allocates the2 once, not2 per type. No mitigation of HP sacrifice, direct death/state assignment or a transfer expressly forbidding recipient mitigation. The precise class wording addsFrightened and confines the original+2DR to one qualifying event; both differences remain explicit. Losing range, source eligibility or an active qualifying state removes readiness for later events but does not undo resolved damage. It grants no armor, universal resistance or new fear application.

**Explicit NEW choices:** ActiveCarrion, real own-source distinct hostiles, pending-state exclusion and one2point whole-event reduction per round.

**Worked adjudications**

- One Shaken hostile and one activeDisoriented hostile in range qualify; a6damage event becomes4 beforetempHP.

- TwoShaken records on the same creature count as one hostile. A future scheduledDisoriented state counts as none until active.

**Dependencies:** Current reviewed Core, action, condition, healing, ancestry and equipment interfaces; Exact preserved Warrior/ancestry source evidence where applicable; Shared proposed feat conventions; actual expedition verdict still pending.

<details><summary>Complete original source, counterpart and question</summary>

```json
{
  "sourceObject": {
    "id": "terrorEngine",
    "name": "Terror Engine",
    "description": "Fear effects provide defensive benefits.",
    "prerequisite": "Carrion Signal Gland mutation",
    "effect": "If 2+ enemies are Shaken or Disoriented, gain +2 DR",
    "type": "Aberrant_mutation",
    "draft": false,
    "deprecated": false,
    "needsReview": false
  },
  "completeClassCounterpart": {
    "id": "warrior.supplement.terror-engine",
    "name": "Terror Engine",
    "className": "Warrior",
    "band": "Arch",
    "path": null,
    "sourceKind": "mutationFeat",
    "minimumClassLevel": 8,
    "acquisition": "supplement",
    "activation": "Passive",
    "cost": "Feat choice",
    "rangeAndTarget": "Self",
    "duration": "While condition is met",
    "frequency": "Always",
    "effect": "While at least two hostile creatures within 30 feet are currently Shaken, Frightened or Disoriented by your Warrior features, reduce the first damage you take each round by 2.",
    "prerequisite": "Warrior 8; Carrion Signal Gland equipped; eligible feat grant",
    "source": {
      "line": 5043,
      "reference": null,
      "originalText": "| Terror Engine | Carrion Signal Gland | If 2+ enemies are Shaken or Disoriented, gain +2 DR |",
      "status": "source-derived"
    },
    "designStatus": "provisional-playtest",
    "spellRank": null
  }
}
```

Reconcile source two Shaken/Disoriented enemies+2DR with Warrior8 counterpart adding Frightened,30ft,your-feature attribution and first damage each round. Define actual active Carrion prerequisite,counting distinct hostiles,damage-reduction order/packet,expiry and changed counts. No universal armor,all-hit reduction or stacking inferred.

</details>

### HM-22 — Versatile Mastery

Source identity: `versatile_mastery`. Original prerequisite: **Human heritage**.

**Original effect, unchanged**

Once per rest, use a class skill or ability from another party member.

**Proposed complete procedure**

Require actual Human heritage. NEW once per completed beneficialSR orLR, borrow one permitted class skill for one check OR one class ability activation from a real willing current party member. Before use, spend one uninterrupted minute together within5ft communicating through an actual shared language/channel; choose the exact currently acquired donor skill/card and record donor consent. This preparation changes no resources and does not spend the use; one prepared choice at a time, ending at the next completedrest or replacement. Donor must have it through actual class training/acquisition, not a copied, borrowed or suppressed grant; you must meet actual body/equipment and the menu's total-level gate. You may then consume the feat use on your own legal check/activation while donor is conscious within30ft and can perceive/understand your signal; donor spends noAction, use or resource. A skill choice uses your own ability+normalPB for one real check, replacing lower proficiency, never donor ability, expertise or passive bonus; the task must actually use that donor's class-granted skill. An ability choice uses one of the twelve exact permitted cards/procedures below, your own stats/PB/materials and actual activation cost. These finite NEW borrowing limits deliberately narrow the source's otherwise unbounded class-ability promise for joint decision. No extra feat use after failure, no copied class levels/engines, passive/Arch/Hero/finale ability, transformation, companion, summon, item production, resource generation, permanent learning or further borrowing. The menu grants a one-use ability permission, never its independent class resource pool; actual1RP cost must be paid from your existing personal legalRPpool. Shared spell/Weave restrictions still apply where printed. An already-known same card shares its own recharge/use ledger, so borrowing cannot bypass a spent natural entitlement; an unknown menu card gets only this one borrowed activation and its future recharge history is retained. Existing ordinary resources and restrictions persist after the temporary permission ends. Lasting riders keep their original deadlines and source identity, with you as actor and donor provenance retained.

**Explicit NEW choices:** Consent/minute preparation, one check or exact twelve-card activation, own actual costs, bounded statistics and no permanent/copy/resource engine.

**Worked adjudications**

- A willing Soldier teaches Tactical Reposition; the Human spends its ownBA and feat use to move half its ownSpeed along a legal route.

- Borrowing Nature's Whisper still costs1realRP. A Human with noRPpool cannot pay and must choose a different legal option before committing.

**Dependencies:** Current reviewed Core, action, condition, healing, ancestry and equipment interfaces; Exact preserved Warrior/ancestry source evidence where applicable; Shared proposed feat conventions; actual expedition verdict still pending.

<details><summary>Complete original source, counterpart and question</summary>

```json
{
  "sourceObject": {
    "id": "versatile_mastery",
    "name": "Versatile Mastery",
    "description": "Racial feat tied to Human heritage.",
    "prerequisite": "Human heritage",
    "effect": "Once per rest, use a class skill or ability from another party member.",
    "type": "Racial",
    "draft": false,
    "deprecated": false,
    "needsReview": false
  },
  "completeClassCounterpart": null
}
```

Bind Human heritage and once-per-rest clock. Define an explicit finite borrowing procedure for an actual party member class skill/ability,consent/availability,character/class-level gates,activation/RP/other resources,DC/scaling,duration and restrictions. No copied permanent progression,free resources/companions,signature identity or automatic full class access.

</details>

## NEW Contraption Crafter table

Roll one ordinaryd4 after the paid construction completes; all four outcomes share the actual object and expiry contract in HM-05. These are NEW feat gadgets, not the four existing Tinker Gnome devices.

### 1 — Shaded lamp

Action light or extinguish the integral enclosed wick. While lit it gives bright light10ft and dim light another10ft for the remaining gadget lifetime. No fuel inventory, attack, ignition of other objects, magical darkness penetration or restored illumination item is created.

### 2 — Line bell

Action fix the gadget and its attached5ft non-load-bearing thread across one reachable ground passage. An actual body crossing and physically touching the taut thread rings an ordinary bell audible30ft, then the thread releases and the device becomes inert. It neither detects incorporeal/noncontact passage nor reveals identity/location beyond its physical site, restrains, trips or causes damage. A visible thread can be noticed by ordinary senses; it has no automatic hidden DC.

### 3 — Light clamp

Action attach/remove the clamp to a reachable mundane edge no more than2inches thick. It can hold one unattended or willingly presented object of at most5lb against that edge, falling normally on expiry/destruction. It cannot restrain a creature, secure a door against forced entry, support a climber, substitute for restraints or improve a check. No free hand is created.

### 4 — Hand fan

Action crank while held to move ordinary air through a5ft cone until the start of your next regular turn; sustained use needs anotherAction. It can cool a touched/hands-reach surface for comfort and stir loose paper/dust, without mechanical damage, creature movement, suffocation relief, weather/hazard immunity or removal of a rules-defined gas/cloud. It can visibly show ordinary airflow but identifies no substance.

## NEW Versatile Mastery finite borrowing menu

Each exact donor card must actually be acquired through the donor's own class and currently operative. Preparation, consent, real costs and one-use limits are governed by HM-22. The menu is an explicit proposed restriction of the broad source ability promise, not proof that the original source supplied these limits. Original full class cards/engines remain in the structured source comparison.

### Soldier — Covering Fire

Actual card: `soldier.base.covering-fire`. Minimum borrower total level: 1.

**Original effect, unchanged:** Make one ranged weapon attack. On hit normal damage and target has-2 on its next attack against an ally other than you. Further Covering Fire replaces rather than stacks this penalty.

**Borrowed one-use procedure:** Action; own actual ranged weapon/ammunition and normal attack/damage. On hit one−2 next attack against an ally other than you, until your next regular start. One attack only; no Soldier engine.

**Original activation/cost/cadence:** Action; One ammunition; Recharge 2.

### Soldier — Tactical Reposition

Actual card: `soldier.base.tactical-reposition`. Minimum borrower total level: 1.

**Original effect, unchanged:** Move up to half Speed without opportunity attacks. Requires an open route; no teleporting, escaping restraints or attacks.

**Borrowed one-use procedure:** BA; move half current usableSpeed as a separate movement-cost budget, normal terrain/route/endpoint restrictions, no opportunity attacks; no teleport or escape from actual restraints.

**Original activation/cost/cadence:** Bonus Action; 0; Recharge 2.

### Warrior — Brutal Strike

Actual card: `warrior.base.brutal-strike`. Minimum borrower total level: 1.

**Original effect, unchanged:** Brutal Strike. Make one melee weapon attack using its normal ability. On hit add S d6 damage of the weapon's type. The target makes a Constitution save; on failure it is Staggered, taking -1 on attack rolls and -5 feet Speed until the end of its next turn. This is not a full-turn denial.

**Borrowed one-use procedure:** Action; one own actual meleeweapon attack, hit adds1d6 native weapon type (NEW fixedS1 for borrowing, doubled on critical). TargetCONsaveDC8+yourPB+actualattackability; fail Staggered−1attacks and−5Speed through next future target regular end. No mutation/BT grant.

**Original activation/cost/cadence:** Action; 0; Recharge 1 round.

### Ranger — Quick Shot

Actual card: `ranger.base.quick-shot`. Minimum borrower total level: 1.

**Original effect, unchanged:** Make one ranged weapon attack, dealing weapon die only without ability damage modifier. Does not trigger Extra Attack or another Quick Shot; may gain one Hit Chain point at 11 within the turn cap.

**Borrowed one-use procedure:** BA; one own legal bowattack using normal attack ability/proficiency, weapon die only without any ability damage modifier. Spend one borrowed entitlement, never donor use. No ExtraAttack, QuickShot loop or HitChain generation from borrowing.

**Original activation/cost/cadence:** Bonus Action; 1 short-rest use; 1/short rest.

### Ranger — Twin Strike

Actual card: `ranger.base.twin-strike`. Minimum borrower total level: 1.

**Original effect, unchanged:** Make one attack with each weapon. Add ability modifier to first hit only. These are the full attacks for this Action; do not add ordinary Extra Attack. Hit Chain gains at 11 cap 2 per turn.

**Borrowed one-use procedure:** Action; two actually wieldedLightmeleeweapons, one attack with each against one/two legaltargets. Add actual ability damage only to first successful hit. Two are the wholeAction; no ordinaryExtraAttack or borrowedHitChain.

**Original activation/cost/cadence:** Action; 0; Recharge 2.

### Ranger — Nature's Whisper

Actual card: `ranger.base.nature-s-whisper`. Minimum borrower total level: 1.

**Original effect, unchanged:** Gain advantage on one Perception/Survival check to find tracks, hidden natural creatures or signs of passage. It reveals evidence on success, not automatically creatures through total cover, incorporeal beings or thoughts.

**Borrowed one-use procedure:** Action and1actualpersonalRP; for1minute gain advantage on one actualPerception/Survival check to find tracks/hidden natural creatures/signs of passage in natural terrain within15ft. Success reveals real evidence only. No free check, location through totalcover or borrowedclassengine; apply actual minorWeave/sharedcasting restrictions of the source.

**Original activation/cost/cadence:** Action; 1 RP; Recharge 3.

### Ranger — Skirmisher's Step

Actual card: `ranger.base.skirmisher-s-step`. Minimum borrower total level: 1.

**Original effect, unchanged:** Move up to half Speed without provoking opportunity attacks. Supplied movement does not increase remaining normal movement. Requires an unblocked route; no teleport or escape from restraints.

**Borrowed one-use procedure:** BA; half current usableSpeed as separate movement-cost budget, no opportunity attacks, ordinary terrain/legalroute/endpoint and actual restraint restrictions; ordinary movement is not refunded.

**Original activation/cost/cadence:** Bonus Action; 0; Recharge 2.

### Thief — Cunning Movement

Actual card: `thief.base.cunning-movement`. Minimum borrower total level: 1.

**Original effect, unchanged:** Move up to half Speed without opportunity attacks; may pass through hostile occupied squares but not end there. Cannot cross impassable terrain or escape restraints.

**Borrowed one-use procedure:** BA; half current usableSpeed separate movement-cost budget, no opportunity attacks, may cross hostile occupiedspace but never end there; ordinary terrain/cost, no impassable route or escape from restraints.

**Original activation/cost/cadence:** Bonus Action; 0; Recharge 2.

### Thief — Disable Device

Actual card: `thief.base.disable-device`. Minimum borrower total level: 1.

**Original effect, unchanged:** Make DEX+PB against its stated disarm DC; unknown DC defaults 15 for ordinary trap, 20 complex. Success disarms one accessible mechanism, failure by 5 triggers it. Does not automatically dispel magic.

**Borrowed one-use procedure:** Action with actual usablethieves tools; one accessible nonmagical mechanism in reach,DEX+ownPB vsactualdisarmDC, otherwise15ordinary/20complex. Apply taskdegrees/naturalshifts; success disarms one mechanism, numericfailuremargin5triggersit as source. No magicdispel or blanket toolproficiency.

**Original activation/cost/cadence:** Action; Thieves tools; At will; retries need changed approach.

### Thief — Feint

Actual card: `thief.base.feint`. Minimum borrower total level: 1.

**Original effect, unchanged:** CHA or DEX+PB deception check against target passive Insight. Success grants advantage on your next weapon attack against it. Failure gives no bonus; no mind-control or guaranteed critical.

**Borrowed one-use procedure:** BA; one perceivedenemy within10ft able to perceiveyou,chooseCHAorDEX+ownPB vsitsactualpassiveInsight. Ordinarytaskresolution; successadvantage on yournextweaponattackagainst it thisactualturn, no automaticcritical/mindcontrol.

**Original activation/cost/cadence:** Bonus Action; 0; Recharge 2.

### Thief — Shadow Step

Actual card: `thief.base.shadow-step`. Minimum borrower total level: 1.

**Original effect, unchanged:** Move half Speed and attempt Hide if the destination can conceal you. Movement produces no deliberate footfall noise but normal senses still apply. This Base feature is not teleportation.

**Borrowed one-use procedure:** BA; begin in actualcover/concealment,movehalfcurrentSpeed with ordinarycost/route, then one actualHidecheck only ifdestinationqualifies. No deliberatefootfallnoise fromthismove; ordinaryOA stillapply. No teleport, invisibility or removal of other tracking evidence.

**Original activation/cost/cadence:** Bonus Action; 0; Recharge 2.

### Monk — Flurry of Blows

Actual card: `monk.base.flurry-of-blows`. Minimum borrower total level: 1.

**Original effect, unchanged:** Flurry of Blows. Tags: base, active, attack, ki. Make exactly two separate unarmed strikes. The first successful Flurry strike on your turn grants 1 Ki. If both strikes hit different creatures, the second may grant 1 additional Ki, subject to the normal own-turn gain ceiling. Tiger critical generation and Flowing Form may occur, but the total Ki gained on your turn still cannot exceed 2.

**Borrowed one-use procedure:** Action; exactlytwo separate actualunarmedstrikes with your ownbody/normalunarmedprofile againstone/twolegalcreatures. No borrowedmartialdie,unarmedproficiency,Ki,Tiger/FlowingFormorMonkengine. Actuallyowned independentfeatures may operate within their owncaps; this permission itself generates no resource or recursiveattack.

**Original activation/cost/cadence:** Action; 0 Ki; At will.

## Specific joint decisions

Decide all22 preserved questions, including whether to adopt counterpart level/equipped/active gates and the single paid identity mapping. Explicitly resolve standalone unrestrictedhitBT, perturnrerolls,Actiondenial,allspellshutdown andDR versus the proposed narrower counterparts. Confirm numeric actual-damage and healing-reserve interaction, living0HP Bloodthick eligibility, real three-mutation slot feasibility, continuous Butcherform threshold and condition-record timing.

The heritage proposals need decisions on the4gadget economics/cadence, Goblin finite favored-task list and10%check-total interpretation, Ogre5ftapproach/push, Elf complete one-event evasion, Feykind100first-attack defense, Umbrin dark-footprint damage, Orc cappedtemporarySTR, Troll finite ordinarycondition recovery and Human12cardborrowing restrictions. These are gameplay proposals, not ancestry-origin or cosmology conclusions.

Reconcile the actual expedition decisions before sending the complete feat package. Ordinary class/condition/ancestry component review does not certify these whole feats or their balance. Final joint whole-game flow agreement precedes the authorized GitHub push; verified remote commit precedes careful cosmology review.
