# Defensive and foundation feats: complete operating proposal

**UNADOPTED — all31 full feat entries await the joint source conference and exact review.** The already reviewed maximum-HP components of Tenacity, Tough, Tough as Nails and Dark Fortitude remain controlling within their actual scope. This manuscript completes proposed acquisition and other-effect procedures; it does not reopen those settled coefficients, change the eight reviewed full feats or activate any of the327 pending entries.

[Complete structured proposal and source objects](../../data/director/general_defense_feat_operating_proposal_internal.json) · [Original defensive feat source audit](../../../../docs/audit/2026-10-08/full-game/GENERAL_DEFENSE_FEAT_SOURCE_AUDIT.md) · [Reviewed maximum-HP contract](../mechanics/MAXIMUM_HP_PLAYTEST.md) · [Local preservation/component checks](../../../../docs/audit/2026-10-08/full-game/GENERAL_DEFENSE_31_OPERATING_PROPOSAL_CHECK.json)

The62 worked examples are authored adjudications. The specifically recorded component/arithmetic checks below do not implement these full feats, prove campaign balance or represent actual play. All303 repository payloads of the live304-file expedition conference remain frozen. Dragon Blood and Elemental Body keep literal prerequisite receipts without new ancestry/plane interpretation.

## Shared proposed and retained rules

### Acquisition

NEW full-feat proposal: use an actual legal class ASI/feat opportunity and check the printed prerequisite at acquisition. Level means total character level. Ability increases from these feats have the ordinary ceiling of 20 and do not grant another feat or ASI. For a feat with other benefits, a score already at or above the applicable ceiling gains zero from its +1 clause but does not lose points or make the other grants ineligible. The pure ASI option below separately requires a full legal allocation. Except the expressly repeatable Ability Score Improvement, Armor Proficiency and Resilient proposals below, each identity is nonrepeatable. Different names remain different identities. Later prerequisite loss does not retroactively revoke ownership; actual ongoing equipment/body/effect requirements still apply.

### Capacity is not recovery

RETAIN the already reviewed MAXIMUM_HP_PLAYTEST component contract: Tenacity uses current total level; Tough keeps twice acquisition-level snapshot; Tough as Nails uses two per acquisition level plus two for each later level; Dark Fortitude uses twice current total level. Distinct feat identities add; duplicates do not. Recompute from separate records. Capacity increases grant no current HP. Capacity decreases clamp current HP without damage, Wounds, healing or new first-fall triggers. These decisions are already reviewed components and are not reopened by full-feat authoring.

### Ability changes

Apply a real permanent ability increase once and recompute its derived modifier. Recompute base maximum HP from stored attained-level values and current CON using the existing per-level floor, then the reviewed maximum-HP ledger. Do not refill current HP, Hit Dice, RP, RC, class pools or uses. Acquisition of a newly limited-use feat follows the NEW proposal of one initially available use unless its exact procedure says otherwise; this never refills another feature.

### Timing and rerolls

NEW common reroll completion: after an eligible failed saving throw but before its consequences commit, spend the feature's use and replace the complete original one- or two-d20 save procedure with the same applicable advantage/disadvantage and modifiers. Use the new result even if worse. The feature cannot reroll its own replacement. Other exact reroll features keep their own windows and costs; no committed consequence can be undone. A completed long rest refreshes short-rest uses under existing timing, while extra turns or calendar changes do not.

### Damage and healing

Retain actual attack/save, passive defense, prevention, temporary HP, Core damage and life-state ordering. Resistance never stacks with another resistance of the same scope. Immunity remains immunity. Proposed paid reactions below specify their separate timing and cannot be invoked after damage has already committed. Ordinary healing follows current modifiers, prohibitions, finite funding and Critical ceiling; direct state recovery is expressly identified and receives no ordinary healing bonuses. Neither operation restores an actually dead creature without a genuine resurrection source.

### Mental predicate

NEW proposed finite definition for Iron Will and Resilient Mind: a qualifying mental-effect save is the effect's own save to prevent or end Charmed, Frightened, possession, compelled actions/speech, or an explicitly described alteration of thoughts, memories, beliefs, emotions or perceived sensory reality; also include a save directly against psychic damage. Actual concentration maintenance is a separate save, not automatically a mental-effect save because psychic damage caused it. A generic INT/WIS/CHA save, mundane physical hazard or ordinary social check does not qualify solely by ability or theme. Tag the actual effect and outcome before the roll; this classification needs the full spell/class conference.

### Limits

All new action costs, quantities, types, timing bridges and eligibility interpretations below are proposals requiring GPT discussion. Exact previously reviewed components remain carried. Source descriptions and legacy variants stay preserved, including inactive immunity/regeneration language. No creation of a curse, ancestry, plane, soul, origin or missing body profile is authorized. Human balance and complete feat runtime remain open.

## Complete feat entries

### GD-01 — Ability Score Improvement

Source identity: `abilityScoreImprovement`. Original prerequisite: **None**.

**Source effect, unchanged**

Choose +2 to one ability score or +1 to two ability scores

**Proposed complete procedure**

Use one actual earned ASI/feat choice to increase one ability by 2 or two distinct abilities by 1 each. Retain the source description's ceiling of 20 for this feature. NEW: this entry is the registry representation of that ordinary ASI option and may be selected at each legitimate ASI opportunity; choosing it does not give both an ASI and another feat. The one-score option requires room for the full +2, and the two-score option requires room for both full +1 increases; do not waste or bank part of the award. Record the acquisition event and chosen scores, then recompute actual modifiers and other derived statistics under the shared rules. No current HP/resource refill, retroactive class selection, starting feat or extra ASI schedule is created. Use each class's real ASI levels, including Oracle's specific schedule, rather than total-level multiples.

**Explicit NEW choices:** Registry ASI identity and repeatability; full legal increase allocation and no banking. Source ability-20 cap preserved.

**Worked adjudications**

- At one earned opportunity, STR 18 can become 20, or STR 19 and WIS 13 can become 20 and 14. That same opportunity cannot also acquire Tough.

- A multiclass character reaching total level 4 without an actual class ASI milestone receives no new ASI merely from this registry entry.

**Dependencies:** Reviewed class advancement schedules; Permanent ability and maximum-HP recomputation.

<details><summary>Complete original record and original conference question</summary>

```json
{
  "id": "abilityScoreImprovement",
  "name": "Ability Score Improvement",
  "description": "Increase one ability score by 2, or increase two ability scores by 1 each. You can't increase an ability score above 20 using this feat.",
  "prerequisite": "None",
  "effect": "Choose +2 to one ability score or +1 to two ability scores",
  "type": "General",
  "draft": false,
  "deprecated": false,
  "needsReview": false
}
```

Retain the description-only ability20 ceiling alongside the effect. Define +2 to one or +1 to two distinct scores, legal acquisition/repeatability, total-character versus class-level ASI choice, lost eligibility and derived modifier/HP changes. Compare class ASI choices without granting both a feat and an extra ASI from one opportunity.

</details>

### GD-02 — Armor Proficiency

Source identity: `armorProficiency`. Original prerequisite: **None**.

**Source effect, unchanged**

You gain proficiency with light, medium, or heavy armor (choose one).

**Proposed complete procedure**

Choose one actual armor proficiency tier: light, medium or heavy. Preserve the source's lack of a prerequisite: NEW explicit selection permits direct heavy-armor proficiency without first learning lighter tiers. Only the chosen tier is granted; heavy does not automatically grant light, medium, shields, weapons or tools. NEW repeatability: this feat may be acquired again through another actual feat choice for a different armor tier not already proficient; record each chosen tier under one source family with distinct acquisition events. Choosing an already proficient tier gives no benefit and is not an eligible new selection. Training does not supply armor, alter fit/anatomy, remove its Strength requirement, waive donning time or invent an AC bonus. While legally using the selected tier, remove only the nonproficiency consequences that actual proficiency removes; other properties remain.

**Explicit NEW choices:** Direct tier choice retained; repeatability for distinct missing tiers only; no implied lower-tier/shield grants.

**Worked adjudications**

- An unarmored character can spend this proposed feat choice on heavy armor proficiency, but remains untrained in a separately used shield.

- A second acquisition can select medium if it is genuinely missing. It cannot select heavy again to stack AC or obtain an unrelated skill.

**Dependencies:** Armor catalog and nonproficiency rules; Heavily/Moderately/Lightly Armored identities.

<details><summary>Complete original record and original conference question</summary>

```json
{
  "id": "armorProficiency",
  "name": "Armor Proficiency",
  "description": "You are skilled with a type of armor.",
  "prerequisite": "None",
  "effect": "You gain proficiency with light, medium, or heavy armor (choose one).",
  "type": "General",
  "draft": false,
  "deprecated": false,
  "needsReview": false
}
```

Source permits choosing light, medium or heavy with no prerequisite. Decide whether that remains a direct tier choice and whether this feat is repeatable for other tiers. Distinguish armor from shields, actual training from item ownership, and chosen-tier access from automatic lower-tier or weapon grants.

</details>

### GD-03 — Athlete

Source identity: `athlete`. Original prerequisite: **None**.

**Source effect, unchanged**

Increase Strength or Dexterity by 1, climbing doesn't cost extra movement, running long jump distance increases by feet equal to Strength modifier

**Proposed complete procedure**

Choose Strength or Dexterity and increase it by 1, normally no higher than 20. Climbing does not cost extra movement solely because it is climbing; terrain, crawling, squeezing and other independent costs remain. This grants no climbing Speed, handholds, ceiling adhesion, automatic check success or immunity to falls. For a running long jump, add your current Strength modifier in feet to the otherwise legal horizontal distance. NEW: the increase has a minimum of zero when that modifier is negative, and a running approach requires at least 10 feet of actual immediately preceding movement on support. The approach and jump both spend movement; clearance, checks and legal landing remain. This does not increase a high jump or ordinary standing long jump. Improved Athlete's separate proposal supplies its own standing-distance change and retains this running increase once. The approach and negative-modifier completions require the full movement-source decision before adoption.

**Explicit NEW choices:** Score cap; no negative 'increase'; explicit 10-foot approach and movement-budget interpretation. No new climb mode.

**Worked adjudications**

- A legal running jump with baseline 16 feet and STR modifier +3 can span 19 feet, still paid from actual movement after its approach.

- A character with STR modifier -1 gains no extra jump distance and suffers no extra one-foot reduction from this feat. Difficult terrain on a climb still costs its terrain surcharge.

**Dependencies:** Improved Athlete proposal; Full jumping/climbing and spent-cost procedure.

<details><summary>Complete original record and original conference question</summary>

```json
{
  "id": "athlete",
  "name": "Athlete",
  "description": "You have undergone extensive physical training to gain the following benefits:",
  "prerequisite": "None",
  "effect": "Increase Strength or Dexterity by 1, climbing doesn't cost extra movement, running long jump distance increases by feet equal to Strength modifier",
  "type": "General",
  "draft": false,
  "deprecated": false,
  "needsReview": false
}
```

Retain +1STR orDEX, no extra climbing movement cost and running-long-jump addition equal to STR modifier. Define score cap, negative modifier, running start, movement-budget ceiling and ordinary checks; no automatic climb success, ceiling adhesion or unprinted swim/climb Speed. Reconcile Athlete Improved and Climber separately.

</details>

### GD-04 — Battle Ready

Source identity: `battleReady`. Original prerequisite: **Constitution 13 or higher**.

**Source effect, unchanged**

You can don or doff armor in half the normal time and have advantage on initiative rolls.

**Proposed complete procedure**

Don or doff an actual suit of armor in half its normal time, preserving its real steps, access, hands, closures and fit. NEW: apply this factor once to the selected suit's existing armor duration; do not automatically include shields, weapons, jewelry or other gear. Combine the separately authorized single helper's doff-time halving multiplicatively with this feat because they represent distinct sources, then round elapsed time upward once to a whole second. In initiative, spend enough complete Actions/turn intervals to cover that elapsed work without compressing an Action below its legal availability; partial progress is retained only to the extent the armor procedure actually permits. Extra helpers do not further halve the time. Interruption leaves the real partially completed state and does not make the armor usable sooner. Gain advantage on each actual initiative roll; this creates neither a new roll after order is established nor an extra turn. Multiple initiative-advantage sources do not stack.

**Explicit NEW choices:** Armor-only scope; actual helper composition and final-second rounding; initiative-event boundary.

**Worked adjudications**

- A normal 60-second armor doff becomes 30 seconds; one real helper can reduce it to 15 seconds under this proposed composition. Two helpers do not reduce it to 7.5 seconds.

- A shield whose separate rule takes one Action still takes that Action; the feat does not convert it to a free interaction.

**Dependencies:** Reviewed don/doff table and helper rule; Initiative and actual Action scheduling.

<details><summary>Complete original record and original conference question</summary>

```json
{
  "id": "battleReady",
  "name": "Battle Ready",
  "description": "You are always prepared for combat.",
  "prerequisite": "Constitution 13 or higher",
  "effect": "You can don or doff armor in half the normal time and have advantage on initiative rolls.",
  "type": "General",
  "draft": false,
  "deprecated": false,
  "needsReview": false
}
```

Define exact halving and rounding for each existing armor don/doff duration, actual helpers/hands/closures and interruption. Preserve advantage on initiative as initiative, not an ability check or extra turn. Do not apply armor timing automatically to shields, jewelry or general gear without explicit source scope.

</details>

### GD-05 — Berserker

Source identity: `berserker`. Original prerequisite: **Constitution 15+**.

**Source effect, unchanged**

Once per long rest, you can rage for 1 minute, gaining +2 damage on melee attacks and resistance to physical damage.

**Proposed complete procedure**

NEW: as a Bonus Action, spend the feat's one long-rest use to enter this feat rage for one elapsed minute. Gain resistance to bludgeoning, piercing and slashing damage, whether magical or nonmagical, and add 2 damage on each actual successful melee attack you own. The melee scope includes weapon, unarmed, natural and melee spell attacks; it is not limited to weapons. Add the flat 2 once to the attack's primary damage type before target defenses; it is not doubled by a critical hit and is not a separate hit, copied damage or spellcasting trigger. NEW: the rage ends early if you voluntarily end it as a Bonus Action or become Incapacitated. It does not require attacking or taking damage to continue, prohibit spellcasting/concentration, extend through repeated attacks, or grant unstated class rage features. Another real rage may coexist under its own rules, but same-scope resistance does not stack and bonuses obey their actual families; this feat's flat rider cannot be counted twice under aliases. A completed rest restores the use, not an encounter declaration.

**Explicit NEW choices:** Bonus Action activation/end, physical-type mapping, melee attack breadth, flat rider attribution and incapacity ending.

**Worked adjudications**

- A critical melee weapon hit doubles its actual damage dice but adds this feat's flat 2 only once. A separate ranged attack receives none of this rider.

- An already bludgeoning-resistant holder remains resistant, not quarter-damage, when the rage begins. Becoming Stunned ends this proposed rage through Incapacitated.

**Dependencies:** Berserker Rage/Frenzied Rage source identities; Class bonus families; Current damage and Incapacitated rules.

<details><summary>Complete original record and original conference question</summary>

```json
{
  "id": "berserker",
  "name": "Berserker",
  "description": "You can enter a battle rage.",
  "prerequisite": "Constitution 15+",
  "effect": "Once per long rest, you can rage for 1 minute, gaining +2 damage on melee attacks and resistance to physical damage.",
  "type": "General",
  "draft": false,
  "deprecated": false,
  "needsReview": false
}
```

Complete once-per-Long-Rest activation action, minute clock, voluntary ending, incapacitation and simultaneous class/feat rages. Bound physical resistance to explicit damage types and clarify +2 on melee weapon, natural, unarmed or melee spell attacks. Compare Berserker Rage and Frenzied Rage without importing unstated class features, spell bans or rage extension.

</details>

### GD-06 — Dragon Blood

Source identity: `dragon_blood`. Original prerequisite: **Dragonborn or sorcerer with draconic bloodline**.

**Source effect, unchanged**

You gain resistance to your draconic ancestry's damage type and can speak, read, and write Draconic.

**Proposed complete procedure**

Preserve the printed prerequisite exactly: Dragonborn, or a Sorcerer with an actual draconic bloodline. Neither name is silently replaced by Drakari or Mage. NEW mechanical eligibility record: identify an actual controlling character/lineage source that expressly establishes one of those prerequisites and its one draconic ancestry damage type. Without that evidence the feat is not selectable in the current candidate; the name alone is not a lineage grant. Once legitimately acquired, gain resistance to that recorded actual damage type and the source's ability to speak, read and write Draconic under the reviewed language procedure. The language grant does not supply writing tools, hands or current speech when an independent condition prevents it. Existing resistance does not stack, and an existing language grant does not produce a substitute language or feat. No bloodline, species origin, dragon allegiance or cosmology is authored here. Resolve any proposed legacy-name alias in the actual source conference before opening eligibility.

**Explicit NEW choices:** Evidence-backed prerequisite/type record and duplicate-language handling; unmatched identity stays unresolved without inventing an alias.

**Worked adjudications**

- A Drakari entry with no explicit Dragonborn alias does not automatically satisfy the printed prerequisite. A verified historical alias would need to be recorded by the source decision first.

- An actually eligible source specifying fire produces fire resistance and Draconic literacy/speech, not a free choice among every dragon damage type.

**Dependencies:** Exact legacy/current identity reconciliation; Reviewed language grants; Cosmology and origins deferred.

<details><summary>Complete original record and original conference question</summary>

```json
{
  "id": "dragon_blood",
  "name": "Dragon Blood",
  "description": "Draconic blood flows through your veins.",
  "prerequisite": "Dragonborn or sorcerer with draconic bloodline",
  "effect": "You gain resistance to your draconic ancestry's damage type and can speak, read, and write Draconic.",
  "type": "General",
  "draft": false,
  "deprecated": false,
  "needsReview": false
}
```

Preserve Dragonborn or sorcerer-with-draconic-bloodline prerequisite. Neither Dragonborn nor Sorcerer is an exact current base-ancestry/class identity in the supplied catalogs; Drakari is not an automatic alias. Identify lawful eligibility and a finite ancestry damage-type binding, plus Draconic language acquisition, without rewriting origins or undertaking cosmology.

</details>

### GD-07 — Durable

Source identity: `durable`. Original prerequisite: **None**.

**Source effect, unchanged**

Increase Constitution by 1, when you roll a Hit Die to regain hit points, minimum amount regained equals twice your Constitution modifier

**Proposed complete procedure**

Increase Constitution by 1, normally no higher than 20, and recompute the real derived modifier and maximum-HP records without healing. For each actual Hit Die legally spent and rolled to restore HP, NEW: set that die's pre-healing-modifier amount to the greatest of its ordinary die-plus-CON healing amount, twice the current signed CON modifier, and zero. Apply the minimum after the ordinary die-plus-CON calculation, separately per die, before ordinary healing bonuses, reductions, blockers and maximum/Critical caps. The resulting actual HP gain may be less than this raw minimum or zero. It creates no Hit Die, rest permission or automatic restoration of spent dice. Wounds reduce actual Hit Dice recovery under their existing rule, not this individual die's result. Do not floor the die face itself at twice CON or multiply a combined multi-die pool a second time.

**Explicit NEW choices:** Per-die floor after die-plus-CON, nonnegative bound and placement before ordinary healing pipeline.

**Worked adjudications**

- CON modifier +3 with a Hit Die face of 1 normally gives 4; Durable makes the raw healing 6 before actual healing modifiers and caps.

- CON modifier -1 with a die face of 1 gives zero under the proposed floor, not negative healing. A genuine no-HP-gain effect can still prevent a positive Durable result.

**Dependencies:** Actual Hit Die/rest procedure; Healing arithmetic; CON and maximum-HP recomputation.

<details><summary>Complete original record and original conference question</summary>

```json
{
  "id": "durable",
  "name": "Durable",
  "description": "Hardy and resilient, you gain the following benefits:",
  "prerequisite": "None",
  "effect": "Increase Constitution by 1, when you roll a Hit Die to regain hit points, minimum amount regained equals twice your Constitution modifier",
  "type": "General",
  "draft": false,
  "deprecated": false,
  "needsReview": false
}
```

Retain +1CON and the twice-CON-modifier minimum when spending a Hit Die for HP. Decide floor0/1 for nonpositive modifiers, whether the minimum applies after the die plus CON or to the die, per-die versus combined spending, score cap and maxHP recomputation. Respect actual Hit Dice, rest eligibility, Wounds and same-healing bonuses.

</details>

### GD-08 — Elemental Body

Source identity: `elemental_body`. Original prerequisite: **Constitution 15+, exposure to elemental plane**.

**Source effect, unchanged**

Choose an element. You gain resistance to that damage type and your unarmed strikes deal that damage type.

**Proposed complete procedure**

Require Constitution 15 and an actual recorded source event satisfying the printed exposure-to-an-elemental-plane prerequisite. This record is a literal eligibility receipt, not permission to invent a plane or reinterpret an origin. NEW finite mechanical choice at acquisition: select acid, cold, fire, lightning or thunder as the feat's one permanent damage type; this menu is proposed, not a recovered elemental taxonomy. Gain resistance to that type. Your actual unarmed strikes replace their ordinary base damage type with the selected type; they do not add a second packet, new dice or another ability modifier. Other separately sourced riders keep their own types. Use actual unarmed attack proficiency, ability, action economy and body legality. A natural weapon is not automatically an unarmed strike unless its source says so. No creature-type change, anatomy, emitted aura, elemental immunity or automatic environmental protection is granted. A new type choice requires an explicit later retraining source; none is created here.

**Explicit NEW choices:** Five-type operational menu and base unarmed-type replacement; exposure remains receipt-bound without new lore.

**Worked adjudications**

- Selecting lightning changes a legal unarmed strike's normal base damage to lightning. It does not add an extra lightning die on top of the old bludgeoning damage.

- Without an actual qualifying exposure receipt, Constitution 15 alone does not unlock the feat or establish that a planar trip occurred.

**Dependencies:** Literal exposure eligibility; Damage types and unarmed/body rules; Cosmology deferred.

<details><summary>Complete original record and original conference question</summary>

```json
{
  "id": "elemental_body",
  "name": "Elemental Body",
  "description": "Your body has been infused with elemental energy.",
  "prerequisite": "Constitution 15+, exposure to elemental plane",
  "effect": "Choose an element. You gain resistance to that damage type and your unarmed strikes deal that damage type.",
  "type": "General",
  "draft": false,
  "deprecated": false,
  "needsReview": false
}
```

Preserve CON15 and exposure-to-elemental-plane prerequisite as unresolved eligibility for the deferred cosmology branch. Define a finite mechanical damage-type choice, resistance and replacement versus extra unarmed damage; attacks still use actual proficiency/ability and damage dice. No creature-type change, new anatomy or planar-origin claim follows.

</details>

### GD-09 — Endurance

Source identity: `endurance`. Original prerequisite: **Constitution 13+**.

**Source effect, unchanged**

You can go twice as long without food, water, or sleep, and you have advantage on Constitution saves against exhaustion.

**Proposed complete procedure**

NEW precise deprivation bridge: while this feat is operative, accrue only half the ordinary food-, water- and sleep-deprivation time toward each respective unmet-need deadline. Use the same elapsed world clock, preserving fractional accrued time and prior exposure; do not halve the actual daily food/water quantity. A nominal 24-hour no-water threshold therefore requires 48 actual hours of otherwise identical deprivation under the feat. Partial intake and resets follow the actual deprivation procedure. Acquisition does not erase already accrued debt or penalties, and suppression changes future accrual rather than replaying old time. Gain advantage on actual Constitution saves whose source prevents or resists gaining the Exhaustion condition. NEW: include a Constitution save against ordinary environmental expedition Strain only if the source explicitly equates that save with exhaustion; do not apply it to Dissonance, serum Strain or every similarly named track. Sleep tolerance gives no short/long-rest benefits, extra active-work Watch, free recovery or exemption from an actual hard work cap. The live expedition verdict must supply the final baseline schedules and distinct track mapping.

**Explicit NEW choices:** Half-rate future deprivation accrual, no retroactive cure, exact save predicate and preserved rest/work limits.

**Worked adjudications**

- Twelve actual hours without water adds six hours to a deprivation clock that would ordinarily accrue one-for-one. It does not produce half a ration of missing water.

- Remaining awake longer does not itself restore RP or grant a beneficial long rest. An unrelated Warrior serum-Strain save does not gain this feat's advantage by name alone.

**Dependencies:** Live deprivation/rest/watch decision; Exhaustion versus Strain namespaces; Survivalist.

<details><summary>Complete original record and original conference question</summary>

```json
{
  "id": "endurance",
  "name": "Endurance",
  "description": "You can push your body beyond normal limits.",
  "prerequisite": "Constitution 13+",
  "effect": "You can go twice as long without food, water, or sleep, and you have advantage on Constitution saves against exhaustion.",
  "type": "General",
  "draft": false,
  "deprecated": false,
  "needsReview": false
}
```

Resolve twice-as-long food/water/sleep deprivation against actual schedules, quantities and cumulative penalties, not infinite sustenance. Identify exact CON saves against Exhausted and environmental Strain, and whether sleep tolerance changes any rest benefits. No unprinted healing, RP recovery or universal immunity.

</details>

### GD-10 — Fey Ancestry

Source identity: `fey_ancestry`. Original prerequisite: **Charisma 13+**.

**Source effect, unchanged**

You have advantage on saving throws against being charmed, and magic can't put you to sleep.

**Proposed complete procedure**

The printed prerequisite is Charisma 13; acquiring this feat does not require or grant an Elf/Feykin ancestry. Gain advantage on actual saving throws to prevent or end the Charmed condition. NEW: qualify by the actual effect's Charmed outcome, not merely an Enchantment school or a persuasive theme; no new save is created for a no-save effect. Prevent a new magical application whose actual source puts you to sleep. This does not block ordinary sleep, fatigue, zero-HP Unconsciousness or a magical effect that causes Unconsciousness without sleep. NEW prospective boundary: acquiring or unsuppressing the feat does not itself end an already applied sleep effect; that effect retains its own wake/removal rules unless it explicitly checks immunity continuously. A new sleep application while protection is operative fails. Other independent damage/conditions from the same source remain. This feat grants no creature type, lineage history, charm immunity or fear immunity.

**Explicit NEW choices:** Charmed/sleep predicates and prospective sleep protection; no implicit ancestry gate or origin claim.

**Worked adjudications**

- An eligible Charisma-13 character of a different ancestry can acquire the feat through a legal choice and gains its mechanical protections without becoming Feykin.

- A spell that newly puts the holder to sleep is prevented. Falling to zero HP from ordinary damage still follows Core Unconsciousness and death rules.

**Dependencies:** Charmed and sleep source cards; Actual condition immunity timing; Ancestry lore deferred.

<details><summary>Complete original record and original conference question</summary>

```json
{
  "id": "fey_ancestry",
  "name": "Fey Ancestry",
  "description": "You have fey blood in your lineage.",
  "prerequisite": "Charisma 13+",
  "effect": "You have advantage on saving throws against being charmed, and magic can't put you to sleep.",
  "type": "General",
  "draft": false,
  "deprecated": false,
  "needsReview": false
}
```

Source requires only CHA13, not a Feykin/Elf ancestry. Preserve that distinction while defining advantage against actual Charmed and magical-sleep prevention, including already asleep versus future application and ordinary exhaustion/sleep. Do not infer creature type, lineage truth or broad charm/fear immunity.

</details>

### GD-11 — Giant Strength

Source identity: `giant_strength`. Original prerequisite: **Strength 17+**.

**Source effect, unchanged**

Your carrying capacity doubles, and you can wield weapons one size larger than normal without penalty.

**Proposed complete procedure**

After computing the current body's ordinary physical carrying capacity and inventory Load capacity from actual Strength and size, double both capacities. NEW: the same factor also doubles the corresponding push/drag/lift limit so that the paired physical-handling limits remain coherent. It does not double an item's weight, remove carried cargo, alter casualty Load, enlarge a mount's capacity or multiply an already modified result twice. Distinct capacity effects use their actual stacking clauses; no generic repeated doubling is granted. You may wield a weapon made for a body one size category larger than your actual current body without a size-only handling penalty. Use that weapon's actual reviewed item profile, hands, reach, damage and properties; the feat itself adds no damage die, reach, proficiency, free hand or two-size permission. An oversized weapon without a complete source profile remains an item-authoring dependency rather than receiving improvised bigger statistics. Real anatomy and Strength requirements still apply.

**Explicit NEW choices:** Pounds/Load/push-drag-lift capacity binding and one-category weapon permission; no invented oversized profile.

**Worked adjudications**

- A Medium STR-18 body has ordinary 270-pound carry and 18 Load; this proposal gives 540 pounds and 36 Load, with the corresponding lift/push/drag limit doubled once.

- Wielding an actual Large weapon does not give a Medium holder Large reach or an extra damage die unless that weapon's complete profile expressly supplies it.

**Dependencies:** Reviewed body/carry table; Oversized weapon profiles; Other carrying-capacity effects.

<details><summary>Complete original record and original conference question</summary>

```json
{
  "id": "giant_strength",
  "name": "Giant Strength",
  "description": "You possess the strength of giants.",
  "prerequisite": "Strength 17+",
  "effect": "Your carrying capacity doubles, and you can wield weapons one size larger than normal without penalty.",
  "type": "General",
  "draft": false,
  "deprecated": false,
  "needsReview": false
}
```

Define doubling under the current pounds and Load reconciliation, whether it affects push/drag/lift, and stacking with actual size or other capacity effects. Complete one-size-larger weapon access using existing weapon sizes, hands and damage rules; no automatic reach, extra dice, anatomy or exemption from other restrictions.

</details>

### GD-12 — Hardy

Source identity: `hardy`. Original prerequisite: **Constitution 15+**.

**Source effect, unchanged**

You have resistance to cold and heat damage, and you have advantage on saves against disease and poison.

**Proposed complete procedure**

Gain resistance to cold damage. NEW explicit type mapping: treat the source's undefined 'heat damage' as fire damage for this feat, granting fire resistance rather than introducing another damage type. This mapping requires joint approval; a different typed effect does not qualify merely because its narration sounds hot. Gain advantage on actual saving throws directly against poison or disease, including a permitted save to prevent or end that actual ailment. These protections do not stack with other resistance or advantage sources. They do not cure an existing illness, prevent the Poisoned condition without a save, erase a dose's non-save consequences or automatically defeat environmental heat/cold exposure that uses a separate save or deprivation rule. An ordinary exposure Constitution save is not a poison/disease save unless its real source says so.

**Explicit NEW choices:** Heat-to-fire mapping and poison/disease save predicate; no generic environmental immunity.

**Worked adjudications**

- A 9-point fire component is reduced under ordinary fire-resistance rounding after its other applicable damage stages; a separately typed radiant component is unchanged.

- A disease-recovery save can gain advantage. The feat does not automatically cure that disease or prevent starvation in a hot region.

**Dependencies:** Damage type authority; Poison/disease and hazard profiles.

<details><summary>Complete original record and original conference question</summary>

```json
{
  "id": "hardy",
  "name": "Hardy",
  "description": "You are resistant to environmental hazards.",
  "prerequisite": "Constitution 15+",
  "effect": "You have resistance to cold and heat damage, and you have advantage on saves against disease and poison.",
  "type": "General",
  "draft": false,
  "deprecated": false,
  "needsReview": false
}
```

Resolve source cold and heat damage: heat is not automatically a new damage type or universally fire. Define the exact resistance mapping and separate save advantage for disease and poison, with no automatic environmental survival or disease cure. Retain overlaps under existing resistance/advantage rules.

</details>

### GD-13 — Healer

Source identity: `healer`. Original prerequisite: **Wisdom 13 or higher**.

**Source effect, unchanged**

You can use a healer's kit to restore hit points and stabilize dying creatures more effectively.

**Proposed complete procedure**

NEW full healing procedure: as an Action, spend one real healer's-kit charge to treat one adjacent legally reachable living creature. Choose ordinary stabilization only, or this feat's healing treatment. A full actual kit has ten charges, costs 5 gp and weighs 3 lb under the reviewed item rule; transfer or partial use never refills it. Healing treatment has one entitlement per recipient per that recipient's completed short or long rest, shared across all Healer practitioners. Commit that entitlement and the charge before resolution even if healing is later blocked. If the recipient is dying, first cause an actual dying-to-Stable transition using this paid kit use, then resolve ordinary healing of 2d4 plus the practitioner's signed Wisdom modifier, minimum zero before the normal healing pipeline. One charge funds both parts of this single treatment. If HP gain is blocked, the stabilization remains with its genuine recovery deadline; if positive HP returns, close that obsolete deadline normally. A recipient whose healing entitlement is spent may still receive ordinary kit stabilization for its real charge and Action, without more feat HP. Already Stable creatures can receive the once-per-rest healing but create no new stabilization trigger. This removes no Wounds, Injury, disease or death. Independently owned Field Medic/Field Surgeon triggers require their actual source/event and own limits, with no duplicated kit charge or invented second stabilization.

**Explicit NEW choices:** Action, one-charge cost, 2d4+WIS healing, recipient short-rest family cap, blocked-offer commitment and stabilization-before-healing sequence.

**Worked adjudications**

- One charge treats a dying target: record stabilization, then dice 3+2 and WIS +3 give 8 ordinary healing before actual modifiers/caps. A second Healer owner cannot repeat the HP treatment before that target rests.

- Under a broad HP-gain prohibition the target remains Stable at zero; the charge and healing entitlement are spent. The feat does not resurrect a dead body.

**Dependencies:** Reviewed kit, stabilization and healing pipeline; Field Medic and Field Surgeon; Healing balance.

<details><summary>Complete original record and original conference question</summary>

```json
{
  "id": "healer",
  "name": "Healer",
  "description": "You are skilled in medicine and healing.",
  "prerequisite": "Wisdom 13 or higher",
  "effect": "You can use a healer's kit to restore hit points and stabilize dying creatures more effectively.",
  "type": "General",
  "draft": false,
  "deprecated": false,
  "needsReview": false
}
```

The source has no HP amount, action, target cadence or kit-charge cost. Complete all of them, including stabilization versus actual healing, touch/access and zeroHP/Wound gates. Bind the actual ten-charge Healer kit and compare the already-reviewed Field Medic plus pending Field Surgeon, without double expenditure, invented charges or unbounded repeat healing.

</details>

### GD-14 — Heavily Armored

Source identity: `heavily_armored`. Original prerequisite: **Proficiency with medium armor**.

**Source effect, unchanged**

You gain proficiency with heavy armor and increase your Strength score by 1.

**Proposed complete procedure**

Require actual medium-armor proficiency at acquisition. Gain heavy-armor proficiency and increase Strength by 1, normally no higher than 20. NEW: record the actual Strength increase at acquisition, including zero if already at the ceiling; another existing heavy-proficiency grant produces no substitute skill, shield, feat or Expertise. Later loss of a prerequisite does not erase ownership, but actual suit/body legality continues to apply. Heavy proficiency removes only the relevant nonproficiency penalties while using that armor; it does not supply the suit, grant medium/light/shield proficiency a second time, change AC formula, waive Strength minimum, eliminate Stealth disadvantage, cancel weight/Load or shorten donning. A source suppressing training operates under its own actual duration without undoing the permanent score history.

**Explicit NEW choices:** Score cap, duplicate-grant handling and acquisition-time prerequisite; no armor-property waiver.

**Worked adjudications**

- A medium-trained character with STR 15 can become STR 16 and learn heavy armor through one legal feat choice; a real suit still has to be acquired and donned.

- Already knowing heavy armor yields no extra proficiency, though the actual permitted +1 Strength remains the feat's separate benefit.

**Dependencies:** Armor proficiency/fit/nonproficiency rules; Permanent ability ledger.

<details><summary>Complete original record and original conference question</summary>

```json
{
  "id": "heavily_armored",
  "name": "Heavily Armored",
  "description": "You have trained to master heavy armor.",
  "prerequisite": "Proficiency with medium armor",
  "effect": "You gain proficiency with heavy armor and increase your Strength score by 1.",
  "type": "General",
  "draft": false,
  "deprecated": false,
  "needsReview": false
}
```

Require actual medium armor proficiency and preserve heavy proficiency plus1STR. Define ability ceiling, no duplicate training, later loss of prerequisite and what the feat does not grant to shields or lower armor tiers. Keep armor properties/fit/strength minimum and item acquisition independent.

</details>

### GD-15 — Immortal Vigor

Source identity: `immortal_vigor`. Original prerequisite: **Constitution 17+, level 10+**.

**Source effect, unchanged**

You age at half the normal rate and have advantage on death saving throws.

**Proposed complete procedure**

Require Constitution 17 and total character level 10. From acquisition onward, accrue natural biological aging at half the body's otherwise applicable natural rate. NEW: keep elapsed world time and accumulated age separate; the feat does not reverse existing age or halve a discrete magical aging event unless that event expressly changes the natural aging rate. Suppression restores future ordinary accrual without retroactive catch-up or rejuvenation. This is a bounded mechanical clock, not immortality, resurrection or a new lifespan/cosmology claim. Gain advantage on actual death saving throws at the existing regular-turn start. Roll the two dice and select the higher before resolving death-save natural 1/20 and counters. Ordinary advantage cancellation applies. No extra death save occurs on an extra turn, and the feat does not replace Instant Death, a fatal Wound save, an effect without a death save or an already dead state.

**Explicit NEW choices:** Future natural-aging accrual versus discrete magical events; death-save advantage integration without new saves.

**Worked adjudications**

- Two elapsed years under an unchanged ordinary aging rate add one biological year, while the world calendar still advances two years.

- Death-save faces 1 and 12 select 12 under advantage, giving the ordinary success. The feat does not permit a roll after actual Instant Death.

**Dependencies:** Core death saves; Actual age records; no new lifespan lore.

<details><summary>Complete original record and original conference question</summary>

```json
{
  "id": "immortal_vigor",
  "name": "Immortal Vigor",
  "description": "You age more slowly than normal.",
  "prerequisite": "Constitution 17+, level 10+",
  "effect": "You age at half the normal rate and have advantage on death saving throws.",
  "type": "General",
  "draft": false,
  "deprecated": false,
  "needsReview": false
}
```

Define the half-rate aging effect as a mechanical clock only, distinguishing natural versus magical aging without granting immortality or cosmology. Define advantage specifically on death saving throws, applicable timing and no replacement of Wounds, instant death or already-dead state; CON17 and character-level10 gate remain.

</details>

### GD-16 — Iron Will

Source identity: `iron_will`. Original prerequisite: **Wisdom 13+**.

**Source effect, unchanged**

+2 bonus to saves vs mind effects

**Proposed complete procedure**

Add 2 once to the actual saving throw against a mental effect meeting the shared proposed finite predicate. This can apply to an INT, WIS, CHA, CON or other save if the actual effect qualifies; it is not a blanket ability-based bonus. The same source cannot add twice when one effect both causes fear and deals psychic damage. No bonus applies to an opposed skill check, death save, ordinary concentration maintenance or an effect granting no save. NEW stacking completion: this distinct feat bonus can combine with Resilient Mind's independently applicable +1 Wisdom-save rider, subject to any explicit overriding source restriction; class-technique bonuses first obey their own strongest-only family. Preserve actual natural-save rules and any printed failure margin. The feat supplies no immunity, automatic success, new save, changed belief or agency override.

**Explicit NEW choices:** Shared mental predicate and explicit distinct-feat combination with Resilient Mind; existing +2 retained.

**Worked adjudications**

- An actual Wisdom save against Charmed can receive Iron Will +2 and an owned Resilient Mind's qualifying +1, for a proposed total +3 from those distinct feats.

- A Constitution concentration save caused by psychic damage is not itself the attack's mental-effect save; Iron Will does not add +2 merely from that causal history.

**Dependencies:** Full mental-effect classification; Resilient Mind; Class and feat bonus families.

<details><summary>Complete original record and original conference question</summary>

```json
{
  "id": "iron_will",
  "name": "Iron Will",
  "description": "Your willpower is unbreakable.",
  "prerequisite": "Wisdom 13+",
  "effect": "+2 bonus to saves vs mind effects",
  "type": "General",
  "draft": false,
  "deprecated": false,
  "needsReview": false
}
```

Define an exhaustive mechanical predicate for mind effects and +2 on actual saving throws. Compare Psychic/mental magic, Charmed/Frightened and mundane pressure without giving all WIS/INT saves a universal bonus. Resolve stacking with Resilient Mind and other static save modifiers using explicit families.

</details>

### GD-17 — Lightly Armored

Source identity: `lightly_armored`. Original prerequisite: **None**.

**Source effect, unchanged**

You gain proficiency with light armor and shields, and increase your Strength or Dexterity score by 1.

**Proposed complete procedure**

Gain light-armor proficiency and shield proficiency, preserving both printed grants despite the feat's name. Choose Strength or Dexterity and increase that score by 1, normally no higher than 20. Existing proficiency in either category provides no unprinted substitute training or Expertise; the other actual grants still apply. NEW: treat this as one nonrepeatable feat identity with the chosen score recorded at acquisition. Training does not give armor or a shield, free a hand, grant two shields' AC, waive fit, auto-don equipment or add an AC modifier beyond the actual item's reviewed contribution. Shield proficiency removes its own relevant nonproficiency consequences; light-armor proficiency applies only to that armor tier. Recompute actual derived statistics without healing or refilling resources.

**Explicit NEW choices:** Score cap and fixed duplicate-grant handling; source light-plus-shields breadth retained.

**Worked adjudications**

- A character already proficient in shields can still gain light armor and the legal +1 chosen ability; duplicate shield training does not become another skill.

- A shield's real hand/forearm occupancy and donning Action remain. The feat's name is not grounds to omit its explicit shield proficiency.

**Dependencies:** Armor/shield equipment procedures; Permanent ability increases.

<details><summary>Complete original record and original conference question</summary>

```json
{
  "id": "lightly_armored",
  "name": "Lightly Armored",
  "description": "You have trained to master light armor.",
  "prerequisite": "None",
  "effect": "You gain proficiency with light armor and shields, and increase your Strength or Dexterity score by 1.",
  "type": "General",
  "draft": false,
  "deprecated": false,
  "needsReview": false
}
```

Preserve light armor AND shield proficiency plus1STR orDEX, although the name mentions only light armor. Define score cap and legal choice, existing proficiency/no duplicate alternatives, armor versus shield carrying/equipping, and no automatic item or AC bonus.

</details>

### GD-18 — Medium Armor Master

Source identity: `medium_armor_master`. Original prerequisite: **Proficiency with medium armor**.

**Source effect, unchanged**

Wearing medium armor doesn't impose disadvantage on Dexterity (Stealth) checks and you can add 3 to AC instead of 2 if you have a Dexterity of 16 or higher.

**Proposed complete procedure**

Require medium-armor proficiency at acquisition. While wearing an actual medium suit, remove only that suit's Stealth-disadvantage cause; other remaining causes still combine normally with advantage. When the selected operative AC formula is that medium suit's formula and your current Dexterity score is at least 16, raise its Dexterity contribution cap from 2 to 3. Use the actual Dexterity modifier, including any penalty, capped at 3; this is not a flat +3 added to AC. If Dexterity falls below 16, use the ordinary cap of 2. A shield's legal bonus remains separate, and another chosen unarmored/natural formula gains nothing from this medium-suit modification. NEW: a Broken or otherwise nonbeneficial suit supplies no positive AC formula benefit, although removing that suit's Stealth-disadvantage cause still applies while it is physically worn. Other properties, weight, Strength limits and actual fit remain.

**Explicit NEW choices:** Live DEX threshold, formula-specific cap and Broken-suit treatment; no broad Stealth advantage.

**Worked adjudications**

- A medium suit with base AC 14 and DEX 16 contributes 14+3=17 before a real shield. DEX 14 uses 14+2=16.

- Removing the suit's Stealth disadvantage does not remove an unrelated Exhaustion disadvantage or grant automatic Hidden.

**Dependencies:** Reviewed AC formula and Broken equipment rules; Current ability scores; Stealth disadvantage causes.

<details><summary>Complete original record and original conference question</summary>

```json
{
  "id": "medium_armor_master",
  "name": "Medium Armor Master",
  "description": "You have mastered medium armor.",
  "prerequisite": "Proficiency with medium armor",
  "effect": "Wearing medium armor doesn't impose disadvantage on Dexterity (Stealth) checks and you can add 3 to AC instead of 2 if you have a Dexterity of 16 or higher.",
  "type": "General",
  "draft": false,
  "deprecated": false,
  "needsReview": false
}
```

Require actual medium proficiency. Waive the armor-imposed Stealth disadvantage only, leaving other disadvantage. At DEX16+ define raised Dexterity AC contribution cap3 instead of2 under the selected medium-suit formula; handle score changes, nonselected formulas, suppression/condition and other enhancement families.

</details>

### GD-19 — Mental Fortress

Source identity: `mental_fortress`. Original prerequisite: **Level 6**.

**Source effect, unchanged**

Once per short rest, when you fail a saving throw against fear, reroll it and use the new result.

**Proposed complete procedure**

At total character level 6 or higher, once per completed short rest, after failing an actual saving throw to prevent or end Frightened or another source explicitly designated as a fear effect, you may spend this feat's use to reroll under the shared save-replacement procedure. Keep the new result. A no-save fear effect supplies no eligible roll, and success does not cure unrelated conditions. NEW operative-source choice: use the current reroll effect; preserve the description/legacy fear-immunity wording as an inactive alternative rather than granting both. Advantage/disadvantage applies to the replacement as it did to the original complete save procedure. A failed replacement still applies the original effect's actual failure outcome; it is not an automatic success. No additional Action or Reaction cost is proposed because this is a response within the original save's uncommitted result window.

**Explicit NEW choices:** Current effect controls over legacy immunity; fear predicate and complete-procedure reroll timing.

**Worked adjudications**

- After a failed advantaged fear save, spend the one use and roll the replacement two-d20 procedure. Its new failed result must stand if still below the actual DC.

- A fear aura with no saving throw cannot be canceled by inventing a Mental Fortress save. The feat grants no immunity under this proposed current-effect selection.

**Dependencies:** Fear/Charmed source separation; Other reroll contracts; Current versus legacy source decision.

<details><summary>Complete original record and original conference question</summary>

```json
{
  "id": "mental_fortress",
  "name": "Mental Fortress",
  "description": "At level 6, a disciplined mind receives the feat's listed once-per-rest immunity to fear effects.",
  "prerequisite": "Level 6",
  "effect": "Once per short rest, when you fail a saving throw against fear, reroll it and use the new result.",
  "type": "General",
  "legacyEffect": "Immune to fear effects once per rest",
  "status": "provisional-complete",
  "balanceReview": true,
  "source": "Completed from the existing feat draft corpus on 2026-08-05; playable wording supplied, final balance pass still required.",
  "draft": false,
  "deprecated": false,
  "needsReview": true
}
```

Preserve description/legacy immunity wording beside current failed-fear-save reroll once per Short Rest. Explicitly select the operative completion, define exact fear predicate, declaration after failure/new result and same-event advantage interactions. Do not silently grant immunity, automatic success or more than one use per recovery interval.

</details>

### GD-20 — Moderately Armored

Source identity: `moderately_armored`. Original prerequisite: **Proficiency with light armor**.

**Source effect, unchanged**

You gain proficiency with medium armor and shields, and increase your Strength or Dexterity score by 1.

**Proposed complete procedure**

Require actual light-armor proficiency at acquisition. Gain medium-armor and shield proficiency, and choose Strength or Dexterity to increase by 1, normally no higher than 20. Preserve all three printed benefits. NEW: one nonrepeatable identity records the actual chosen score and grants; already held medium/shield proficiency gives no substitute selection or Expertise. The feat does not waive suit properties, body fit, Strength minimum, weight, don/doff time or hand use. Apply the actual selected armor formula and shield contribution, with the ordinary cap unless a separately owned feature changes it. Later loss of the acquisition prerequisite does not erase ownership; ongoing item/body restrictions and actual suppression still govern use.

**Explicit NEW choices:** Score cap, nonrepeatability and duplicate-training handling; no hidden lower/upper-tier grants.

**Worked adjudications**

- A light-trained holder with DEX 15 can become DEX 16 and gain medium armor plus shields. The medium suit still uses its normal +2 DEX cap without Medium Armor Master.

- Existing shield proficiency does not create an extra skill when this feat is acquired; the medium training and legal ability increase remain.

**Dependencies:** Armor/shield rules; Medium Armor Master; Ability advancement.

<details><summary>Complete original record and original conference question</summary>

```json
{
  "id": "moderately_armored",
  "name": "Moderately Armored",
  "description": "You have trained to master medium armor.",
  "prerequisite": "Proficiency with light armor",
  "effect": "You gain proficiency with medium armor and shields, and increase your Strength or Dexterity score by 1.",
  "type": "General",
  "draft": false,
  "deprecated": false,
  "needsReview": false
}
```

Require actual light proficiency; preserve medium and shield proficiency plus1STR orDEX. Resolve score cap and existing shield training without an unprinted substitute proficiency. Keep actual armor formula, fit, donning, Strength and noise properties intact.

</details>

### GD-21 — Quick Recovery

Source identity: `quick_recovery`. Original prerequisite: **Constitution 12+**.

**Source effect, unchanged**

When you spend Hit Dice during a short rest, add your proficiency bonus to the total hit points restored.

**Proposed complete procedure**

Preserve the current effect: when you legally spend one or more Hit Dice during a completed short-rest recovery procedure, add your current PB once to the total ordinary HP-healing amount for that rest. NEW: commit this single Quick-Recovery-family addition with the first actual Hit Die healing event of that rest; further installments or extra dice in the same rest do not add it again. Zero spent Hit Dice yields no feat addition. Add PB before the ordinary healing reductions, prohibitions and capacity/Critical caps; it is not a promise of PB actual HP restored. The entitlement is spent even if that first event is blocked or entirely excess, and a separate owned converter still needs its own actual rules. Wounds affect recovered Hit Dice under their existing procedure, not a second fee on this bonus. The description/legacy +50-percent out-of-combat regeneration remains preserved but inactive. No free recurring regeneration, extra rest reward or new Hit Dice is created.

**Explicit NEW choices:** Once-per-real-rest total bonus, first-event commitment and inactive legacy regeneration choice.

**Worked adjudications**

- PB +3 with two Hit Die results totaling 11 gives 14 raw ordinary healing for that rest, before actual healing modifiers and caps; spending another die later in the same rest adds no second +3.

- A rest spent without any Hit Die gives no Quick Recovery healing. A blocked first Hit Die heal does not reserve the bonus for repeated retries.

**Dependencies:** Actual short-rest Hit Die procedure; Healing arithmetic and excess converters; Current versus legacy choice.

<details><summary>Complete original record and original conference question</summary>

```json
{
  "id": "quick_recovery",
  "name": "Quick Recovery",
  "description": "Constitution 12+ supports the listed +50% HP regeneration outside combat.",
  "prerequisite": "Constitution 12+",
  "effect": "When you spend Hit Dice during a short rest, add your proficiency bonus to the total hit points restored.",
  "type": "General",
  "legacyEffect": "+50% HP regen out of combat",
  "status": "provisional-complete",
  "balanceReview": true,
  "source": "Completed from the existing feat draft corpus on 2026-08-05; playable wording supplied, final balance pass still required.",
  "draft": false,
  "deprecated": false,
  "needsReview": true
}
```

Reconcile description/legacy +50percent out-of-combat regeneration with current PB added to HP restored when spending Hit Dice during Short Rest. Define once per rest versus per die, multiple installments, zero dice, actual healing caps and Wounds. Current wording must not become a new free recurring regeneration pulse.

</details>

### GD-22 — Resilient

Source identity: `resilient`. Original prerequisite: **None**.

**Source effect, unchanged**

Increase the chosen ability score by 1, gain proficiency in saving throws using the chosen ability

**Proposed complete procedure**

Choose one of STR, DEX, CON, INT, WIS or CHA. Increase that score by 1, normally no higher than 20, and gain proficiency in saving throws using that same ability. NEW repeatability: a later actual feat opportunity can select a different ability, but cannot select the same ability again through this feat. Record the chosen ability and acquisition event; there is no free switch or banked +1. An existing save proficiency adds no second PB or Expertise, though an otherwise legal +1 ability remains. Check the score ceiling for each selection. Apply the actual save ability only when that save is made, including other legitimate modifiers; proficiency is not a bonus to every save. Recompute derived statistics and the CON/maximum-HP records where relevant without ordinary healing or resource refills.

**Explicit NEW choices:** Different-ability repeatability, score cap and duplicate-save handling; same ability binds both benefits.

**Worked adjudications**

- Selecting WIS 15 makes WIS 16 and grants Wisdom-save proficiency. A later separate selection may choose CON, but not WIS again.

- If Wisdom saves were already proficient, selecting a legal WIS increase does not add PB twice or grant Expertise on those saves.

**Dependencies:** Save proficiency and ability ledger; Maximum HP for CON changes; Feat repeatability decision.

<details><summary>Complete original record and original conference question</summary>

```json
{
  "id": "resilient",
  "name": "Resilient",
  "description": "Choose one ability score. You gain the following benefits:",
  "prerequisite": "None",
  "effect": "Increase the chosen ability score by 1, gain proficiency in saving throws using the chosen ability",
  "type": "General",
  "draft": false,
  "deprecated": false,
  "needsReview": false
}
```

Choose one actual ability, add1 subject to explicit score cap and gain that save proficiency. Decide repeatability for different abilities, existing proficiency and no expertise/doublePB. Recompute legitimate derived statistics without automatic HP healing or replacing the class ASI/feat acquisition opportunity.

</details>

### GD-23 — Resilient Mind

Source identity: `resilient_mind`. Original prerequisite: **Wisdom 14+**.

**Source effect, unchanged**

Gain +2 to Constitution saving throws made to maintain concentration and +1 to Wisdom saves against mental effects.

**Proposed complete procedure**

Add 2 on actual Constitution saving throws whose purpose is maintaining concentration on a real active effect. This does not create concentration on an effect that lacks it, grant a new slot or add to every Constitution save. Separately add 1 on actual Wisdom saves against a mental effect under the shared proposed finite predicate. The two clauses have different roll requirements and do not both apply to one ordinary Constitution concentration save. Preserve the current source's save wording over its legacy 'concentration checks' shorthand; an effect using a different non-save procedure is not automatically converted. NEW: its distinct qualifying Wisdom +1 can coexist with Iron Will's +2 under the proposed feat-family rule. No effect without an actual save grants an invented roll, and no bonus automatically prevents concentration ending from Incapacitated, voluntary replacement or its source's dependency ending.

**Explicit NEW choices:** Separate exact predicates, current-save wording and explicit Iron Will combination.

**Worked adjudications**

- A CON concentration save with ordinary modifier +4 becomes +6. Its causal psychic damage does not also activate this feat's Wisdom-only +1.

- A qualifying WIS save against mental coercion can receive the +1, while an unrelated Wisdom-based navigation check receives nothing.

**Dependencies:** Concentration legality and ending; Iron Will and mental predicate; Legacy/current wording.

<details><summary>Complete original record and original conference question</summary>

```json
{
  "id": "resilient_mind",
  "name": "Resilient Mind",
  "description": "Wisdom 14+ supports the listed +2 to concentration checks.",
  "prerequisite": "Wisdom 14+",
  "effect": "Gain +2 to Constitution saving throws made to maintain concentration and +1 to Wisdom saves against mental effects.",
  "type": "General",
  "legacyEffect": "+2 to concentration checks",
  "status": "provisional-complete",
  "balanceReview": true,
  "source": "Completed from the existing feat draft corpus on 2026-08-05; playable wording supplied, final balance pass still required.",
  "draft": false,
  "deprecated": false,
  "needsReview": true
}
```

Preserve description/legacy concentration-check wording and current +2CON concentration saves plus1WIS saves against mental effects. Define the second predicate independently; no double application of the same source, no all-CON/all-WIS bonus and no use when no legitimate concentration save occurs.

</details>

### GD-24 — Stubborn Resolve

Source identity: `stubborn_resolve`. Original prerequisite: **Constitution 15+**.

**Source effect, unchanged**

Once per long rest, when you fail a saving throw against an effect that would kill you outright, reroll the save and use the new result.

**Proposed complete procedure**

Once per completed long rest, after you fail an actual saving throw whose currently applicable failure outcome directly makes you Dead, you may spend the feat's use to reroll under the shared replacement procedure before death commits. NEW eligible examples include an explicit save-or-die effect and a Wound save begun at three Wounds, where another failure is immediately fatal. An ordinary damage save does not qualify merely because the eventual damage could reduce HP to zero or meet Instant Death; that save's failure outcome is damage, not direct death. Ordinary death saving throws and their accumulated failure counters are a separate Core procedure and do not qualify here. No-save direct death, an already committed death, a maximum-HP clamp or a future delayed risk supplies no new save. Use the new result even if it still kills; there is no resurrection or automatic survival. Preserve legacy death-effect 'resistance' wording as inactive beside this explicit current reroll proposal. A separately eligible would-die replacement still keeps its own later legal window if the new result remains fatal.

**Explicit NEW choices:** Exact direct-death failure predicate; fatal Wound inclusion; damage/death-save exclusions; precommit reroll timing.

**Worked adjudications**

- At three Wounds, a failed actual Wound save would kill. This proposal permits one paid reroll before committing that death, with the new save's actual result controlling.

- A failed fire-damage save is not eligible merely because the incoming damage is lethal. A no-save Instant Death check supplies no Stubborn Resolve roll.

**Dependencies:** Core Wound/death pipeline; Save-or-die spell/card source; Would-die replacement ordering.

<details><summary>Complete original record and original conference question</summary>

```json
{
  "id": "stubborn_resolve",
  "name": "Stubborn Resolve",
  "description": "Constitution 15+ supports the listed resistance to one death effect per day.",
  "prerequisite": "Constitution 15+",
  "effect": "Once per long rest, when you fail a saving throw against an effect that would kill you outright, reroll the save and use the new result.",
  "type": "General",
  "legacyEffect": "Can resist 1 death effect per day",
  "status": "provisional-complete",
  "balanceReview": true,
  "source": "Completed from the existing feat draft corpus on 2026-08-05; playable wording supplied, final balance pass still required.",
  "draft": false,
  "deprecated": false,
  "needsReview": true
}
```

Current once-Long-Rest reroll applies after failing a save against an effect that would kill outright. Define qualifying kill versus HP0/Wound/death-save/damage events, choice and new result, trigger/recovery ledger and exceptions for no-save death. Reconcile legacy resistance wording without granting resurrection or automatic survival.

</details>

### GD-25 — Tenacity

Source identity: `tenacity`. Original prerequisite: **Level 4**.

**Source effect, unchanged**

Your hit point maximum increases by 1 for each character level, including levels already gained.

**Proposed complete procedure**

At total character level 4 or higher, acquire Tenacity through a legal feat opportunity. RETAIN its reviewed maximum-HP component: one bonus record equal to your current total character level, including already attained levels. It updates with genuine later level changes; do not snapshot it at acquisition. It is one identity and cannot be counted twice through aliases, engine descriptions or repeated registration. Distinct Tough, Tough as Nails and Dark Fortitude records add under the already reviewed maximum-HP contract. Apply systemic factors and reductions in that contract's order. Gaining or restoring this bonus increases capacity only; losing/suppressing it recomputes capacity and clamps current HP if necessary without damage, Wounds, healing, death-failure or first-fall triggers. NEW full-feat completion: nonrepeatable acquisition and retention under ordinary later prerequisite loss; no free retraining or HP refill.

**Explicit NEW choices:** Only full-feat acquisition/nonrepeatability completion; existing HP coefficient, stacking and no-healing rule are retained authority.

**Worked adjudications**

- At total level 7, Tenacity contributes +7 maximum HP. A later genuine level 8 makes that +8 without restoring a missing current HP point.

- With current HP 35 and maximum 40, removing a +7 Tenacity record can clamp HP to the recomputed maximum 33; the two-point clamp is not damage.

**Dependencies:** Reviewed maximum-HP ledger; Genuine advancement/removal procedures.

<details><summary>Complete original record and original conference question</summary>

```json
{
  "id": "tenacity",
  "name": "Tenacity",
  "description": "Level 4 supports the listed +1 HP per level.",
  "prerequisite": "Level 4",
  "effect": "Your hit point maximum increases by 1 for each character level, including levels already gained.",
  "type": "General",
  "legacyEffect": "+1 HP per level",
  "status": "provisional-complete",
  "balanceReview": true,
  "source": "Completed from the existing feat draft corpus on 2026-08-05; playable wording supplied, final balance pass still required.",
  "draft": false,
  "deprecated": false,
  "needsReview": true
}
```

Bind +1maximumHP per total character level, explicitly retroactive. Define future advancement, level loss and suppression/removal through the reviewed maxHP source identity and current-HP reconciliation. Compare Tough, Tough as Nails and Dark Fortitude without accidental duplicate family bonuses or healing.

</details>

### GD-26 — Tough

Source identity: `tough`. Original prerequisite: **None**.

**Source effect, unchanged**

Your hit point maximum increases by an amount equal to twice your level when you gain this feat.

**Proposed complete procedure**

Acquire Tough through one legal feat opportunity and record total character level at that moment. RETAIN the reviewed component decision: its maximum-HP bonus is twice that acquisition-level snapshot, with no automatic later increment from Tough itself. Keep that snapshot through current level changes, temporary suppression and save loading; do not rewrite it to current level or borrow Tough as Nails' later-level clause. Distinct maximum-HP feat identities add under the reviewed ledger, but duplicate Tough copies do not. Capacity increases give no current HP; removal/suppression can clamp current HP without damage or healing triggers. NEW full-feat completion: nonrepeatable, with no ordinary re-acquisition loop to replace the snapshot at a higher level. Only a separately authorized actual retraining/removal procedure could create a genuinely new acquisition event; this feat supplies none.

**Explicit NEW choices:** Nonrepeatable acquisition and no snapshot-reset loop; reviewed snapshot/stacking component stays unchanged.

**Worked adjudications**

- Tough acquired at level 4 contributes +8 even after the character reaches level 10. Tough as Nails' separately owned later-level rule does not rewrite this record.

- Suppressing and restoring Tough keeps the original +8 snapshot and restores no current HP.

**Dependencies:** Reviewed Tough acquisition snapshot; Actual retraining boundaries.

<details><summary>Complete original record and original conference question</summary>

```json
{
  "id": "tough",
  "name": "Tough",
  "description": "Your hit point maximum increases.",
  "prerequisite": "None",
  "effect": "Your hit point maximum increases by an amount equal to twice your level when you gain this feat.",
  "type": "General",
  "draft": false,
  "deprecated": false,
  "needsReview": false
}
```

Source effect says +2times level when gained but lacks the explicit later-level increment printed in Tough as Nails. Decide whether this is a snapshot or ongoing coefficient, preserve the distinction and reconcile identity/stacking with the other HP feats. Define removal/level changes without treating maximum-HP capacity as healing.

</details>

### GD-27 — Tough as Nails

Source identity: `tough_as_nails`. Original prerequisite: **Level 5**.

**Source effect, unchanged**

Your hit point maximum increases by 2 per character level when you take this feat, and by 2 whenever you gain a level thereafter.

**Proposed complete procedure**

Require total character level 5 at acquisition. RETAIN the reviewed maximum-HP component: +2 for each total character level already gained, and +2 for each genuine later gained level. Record acquisition level and each subsequent actual advancement so that the benefit tracks the actual attained-level history without replaying level events. NEW edge completion: if a separately authorized level-loss rule removes a level and its benefits, remove the corresponding later-level +2 contribution; restoration of that same level restores that contribution once, not an additional duplicate. The ordinary candidate currently grants no free level loss/retraining mechanism. Preserve source description/legacy +10-percent wording as an inactive alternative, not a second bonus. Distinct HP feat identities add under the already reviewed ledger. Capacity changes never heal and clamps are not damage. This feat is nonrepeatable.

**Explicit NEW choices:** Full-feat gate/nonrepeatability and explicit replay-safe level-loss edge; reviewed current coefficient and legacy distinction retained.

**Worked adjudications**

- Acquiring at level 5 gives +10 maximum HP; reaching level 6 adds exactly +2, for +12. It does not also apply the legacy +10 percent.

- Replaying the saved level-6 advancement event adds nothing after that same event is already recorded.

**Dependencies:** Reviewed maximum-HP component; Actual advancement event identity; Any future level-loss procedure.

<details><summary>Complete original record and original conference question</summary>

```json
{
  "id": "tough_as_nails",
  "name": "Tough as Nails",
  "description": "Level 5 supports the listed +10% maximum HP.",
  "prerequisite": "Level 5",
  "effect": "Your hit point maximum increases by 2 per character level when you take this feat, and by 2 whenever you gain a level thereafter.",
  "type": "General",
  "legacyEffect": "+10% max HP",
  "status": "provisional-complete",
  "balanceReview": true,
  "source": "Completed from the existing feat draft corpus on 2026-08-05; playable wording supplied, final balance pass still required.",
  "draft": false,
  "deprecated": false,
  "needsReview": true
}
```

Reconcile description/legacy +10percent maximumHP with current retroactive +2per-character-level and +2on later level gains. Define exact source identity and stacking with Tough/Dark Fortitude/Tenacity, level loss and no current-HP refill from toggling capacity. Keep level5 prerequisite and balance status.

</details>

### GD-28 — Void Touched

Source identity: `void_touched`. Original prerequisite: **Wisdom 15+**.

**Source effect, unchanged**

You have resistance to necrotic damage and can see normally in magical darkness.

**Proposed complete procedure**

Gain resistance to necrotic damage. You can see normally through magical darkness with your current functioning visual sense. NEW precise scope: within the range at which that body's normal vision can resolve a subject under adequate light, treat magical darkness's obscuring effect as absent for your sight; where the magic itself creates a dark region, treat that region as normally lit for this personal perception. This emits no light and grants no benefit to allies. Independent ordinary darkness beyond that region, non-darkness fog/smoke, total cover, invisible creatures, lack of eyes, Blinded and an actual vision-range limit still apply. It neither creates a new visual sense in a sightless form nor extends a specified sense range. Existing necrotic resistance does not stack. The name/descriptive void connection grants no planar origin, alignment change, creature type or other cosmological assertion.

**Explicit NEW choices:** Personal normally-lit interpretation for magical darkness, actual visual-range/body boundary and no light emission; no invented fixed range.

**Worked adjudications**

- A visible unobstructed target inside magical darkness can be seen by a holder with functioning ordinary sight. An invisible target remains invisible without another exact ability.

- A wall still blocks sight and a sightless form gains no eyes from this feat; necrotic resistance remains its separate benefit where otherwise operative.

**Dependencies:** Darkness/vision spell and condition sources; Actual body senses; Cosmology deferred.

<details><summary>Complete original record and original conference question</summary>

```json
{
  "id": "void_touched",
  "name": "Void Touched",
  "description": "You have been exposed to the void between planes.",
  "prerequisite": "Wisdom 15+",
  "effect": "You have resistance to necrotic damage and can see normally in magical darkness.",
  "type": "General",
  "draft": false,
  "deprecated": false,
  "needsReview": false
}
```

Define necrotic resistance and normal sight through magical darkness, including range, line of sight, non-darkness obscurity and actual form senses. It does not automatically grant darkvision beyond normal sight or see invisible/through walls. Preserve void/plane description without confirming origins or cosmology.

</details>

### GD-29 — Cursebound Flesh

Source identity: `cursebound_flesh`. Original prerequisite: **Constitution 13+, level 6+**.

**Source effect, unchanged**

While transformed or under a lycanthropic curse, you have resistance to nonmagical slashing damage and reduce damage from silver weapons by half. You have advantage on saves to resist involuntary transformation. Once per long rest, when you would drop to 0 hit points while transformed, you may instead drop to 1 hit point and remain transformed until the end of your next turn.

**Proposed complete procedure**

Require Constitution 13 and total character level 6 at acquisition. For the two damage defenses, the holder must currently have an actual operative transformation or an explicitly recorded lycanthropic curse. A cosmetic disguise, feat name or inferred origin is insufficient. Gain resistance to nonmagical slashing damage and halve an actual silver weapon's own damage components, including any intrinsic item-profile components. Separate poison doses, class/feat riders and spell damage are not silver-weapon damage merely because the weapon hit delivered their trigger, unless an exact source says they are part of that weapon's own damage. NEW: the two passive halves supplied by this same feat form one defensive family; a nonmagical silver slashing hit is halved once by this family, not automatically quartered. Resolve separate actually applicable defenses by the governing damage pipeline. Gain advantage on actual saves to resist an involuntary transformation, without creating a save for a no-save change. Once per completed long rest, when a real positive-to-zero HP transition would occur while actually transformed, you may spend the use to remain at 1 HP instead. NEW: this is a true drop-prevention floor after Instant Death checking and before later Wound consequences; it does not override Instant Death, fatal Wounds, an already-zero state, actual death or a mandatory unpreventable cost. Extend only the current transformation's ordinary time endpoint, if needed, to at least the end of your next original regular turn. It does not shorten a longer duration, create another form, waive upkeep, prevent voluntary ending or preserve a form through independently failed concentration, invalid anatomy, suppression or another mandatory source ending. Keep the source's origin/curse language as a literal eligibility receipt without inventing a curse.

**Explicit NEW choices:** Actual form/curse predicates; same-feat passive-halving family; true-floor order and limited time-endpoint extension. Silver-weapon native components are explicitly separated from independent riders.

**Worked adjudications**

- An eligible nonmagical silver slashing packet of 11 is halved once by this feat's own passive family, yielding 5 before any other distinct legally ordered stage, not 2 from counting both clauses twice.

- A transformed positive-HP holder can spend the floor use on an eligible drop, but a subsequent failed Wound save begun at three Wounds can still kill under Core. The feat is not resurrection.

**Dependencies:** Transformation/lifecycle/body-ending contracts; Core Instant Death/floors/Wounds; Silver weapon damage scope.

<details><summary>Complete original record and original conference question</summary>

```json
{
  "id": "cursebound_flesh",
  "name": "Cursebound Flesh",
  "description": "The moon's bite runs in your veins. Your body has learned to endure what would break mortal flesh. Prestige lineage: Mooncursed. completed from the existing development record.)",
  "prerequisite": "Constitution 13+, level 6+",
  "effect": "While transformed or under a lycanthropic curse, you have resistance to nonmagical slashing damage and reduce damage from silver weapons by half. You have advantage on saves to resist involuntary transformation. Once per long rest, when you would drop to 0 hit points while transformed, you may instead drop to 1 hit point and remain transformed until the end of your next turn.",
  "type": "General",
  "source": "Completed from the existing feat draft corpus on 2026-08-05; playable wording supplied, final balance pass still required.",
  "legacyEffect": "While transformed or under a lycanthropic curse, you have resistance to nonmagical slashing damage and reduce damage from silver weapons by half. You have advantage on saves to resist involuntary transformation. Once per long rest, when you would drop to 0 hit points while transformed, you may instead drop to 1 hit point and remain transformed until the end of your next turn.",
  "status": "provisional-complete",
  "balanceReview": true,
  "draft": false,
  "deprecated": false,
  "needsReview": true
}
```

Define the actual transformed/lycanthropic-curse eligibility without inventing a curse or origin. Resolve nonmagical slashing resistance and separate silver-weapon halving on one event, timing/rounding and no automatic quartering. Specify involuntary-transformation saves and once-Long-Rest HP0-to1 replacement, instant-death/Wound priority and next-turn form extension without bypassing a forced invalid anatomy ending.

</details>

### GD-30 — Dark Fortitude

Source identity: `dark_fortitude`. Original prerequisite: **Constitution 15+**.

**Source effect, unchanged**

You have advantage on saving throws against poison and disease. Your hit point maximum increases by 2 per character level. When you take necrotic damage, you can use your reaction to reduce that instance by half (once per short rest). While below half your hit point maximum, you have resistance to poison damage.

**Proposed complete procedure**

Gain advantage on actual saves against poison and disease. RETAIN the reviewed maximum-HP record of +2 per current total character level, additive with distinct HP feat identities and never a current-HP refill. RETAIN its continuous strict-below-half threshold: poison resistance applies exactly while 2 × current HP is less than effective maximum HP. Freeze eligibility for a damage component at its actual defense evaluation; later HP loss does not retroactively resist earlier damage in that packet. Once per completed short rest, when a positive necrotic damage component is about to reach you after passive defenses and before temporary HP/normal HP, NEW: spend your available Reaction and this feat use to halve that remaining necrotic component, rounding the remaining amount down. Other damage types in the same event are unchanged. This is a separate paid prevention step and can follow an actual passive necrotic resistance, but never double-apply either stage or replay a committed packet. You must legally be able to react at that window; zero-HP Incapacitated supplies no generic permission. Necrotic Affinity's separate reaction remains its own choice/cost and does not activate for free from this feat. No prevented amount becomes healing or temporary HP here.

**Explicit NEW choices:** Exact paid reaction window, necrotic-component halving/rounding and no generated resource; reviewed HP/threshold components retained.

**Worked adjudications**

- With effective maximum 21, HP 10 is strictly below half and grants poison resistance; HP 11 does not. A later maximum change recomputes the continuous predicate without a damage event.

- A remaining necrotic component of 5 can be reduced to 2 by the paid Reaction. A simultaneous 4 fire remains 4; no temporary HP is granted.

**Dependencies:** Reviewed maximum HP and strict thresholds; Damage/prevention order; Necrotic Affinity and Reaction legality.

<details><summary>Complete original record and original conference question</summary>

```json
{
  "id": "dark_fortitude",
  "name": "Dark Fortitude",
  "description": "Grave-cold and poison have tried to claim you. They learned your name and backed away. Prestige lineage: Gravetouched. completed from the existing development record.)",
  "prerequisite": "Constitution 15+",
  "effect": "You have advantage on saving throws against poison and disease. Your hit point maximum increases by 2 per character level. When you take necrotic damage, you can use your reaction to reduce that instance by half (once per short rest). While below half your hit point maximum, you have resistance to poison damage.",
  "type": "General",
  "source": "Completed from the existing feat draft corpus on 2026-08-05; playable wording supplied, final balance pass still required.",
  "legacyEffect": "You have advantage on saving throws against poison and disease. Your hit point maximum increases by 2 per character level. When you take necrotic damage, you can use your reaction to reduce that instance by half (once per short rest). While below half your hit point maximum, you have resistance to poison damage.",
  "status": "provisional-complete",
  "balanceReview": true,
  "draft": false,
  "deprecated": false,
  "needsReview": true
}
```

Preserve every clause: poison/disease save advantage, +2maxHP per character level, once-Short-Rest Reaction to halve one necrotic damage instance, and poison resistance below half maximum. Define snapshot thresholds, exact damage event and order/rounding, activation at zeroHP/incapacity and stacking with actual resistance. Reconcile HP-family identity without changing lineage lore.

</details>

### GD-31 — Undying Flesh

Source identity: `undying_flesh`. Original prerequisite: **Constitution 15+, Necrotic Affinity or Dark Fortitude**.

**Source effect, unchanged**

You have resistance to necrotic and poison damage. Once per long rest, when you are reduced to 0 hit points but not killed outright, you rise at 1 hit point at the start of your next turn with temporary necrotic bonuses (+2 damage for 1 minute).

**Proposed complete procedure**

Require Constitution 15 and actually owned Necrotic Affinity or Dark Fortitude, using their exact feat IDs. Gain resistance to necrotic and poison damage. NEW delayed-recovery procedure: once per completed long rest, after an actual positive-to-zero damage/loss event finishes its Core Instant Death, Wound and death processing and leaves you living at zero, you may commit the use to that real dying/Stable episode. Record a recovery deadline at the start of your next original regular turn, preserving its virtual marker if initiative changes. At that deadline, before the normal death save, if you are still living at zero in that same episode, attempt direct state recovery to 1 HP. Broad HP-gain prohibition blocks the point; it does not create stability or refund the use. Earlier positive healing closes the pending episode and cancels this later recovery without reducing HP; actual death cancels it and cannot be reversed. On actual successful recovery, NEW: gain a one-elapsed-minute rider adding 2 necrotic damage once to each genuine personally owned damaging attack/spell/feature event, before target defenses. Apply it once to a shared area roll/event, with each target resolving its own defenses; a mixed-type packet does not gain it per component. Fixed damage and actual ongoing source ticks can qualify, but copied/reflected damage, another creature's actions and newly invented split packets do not. The flat +2 is not doubled by critical hits. It is this feat's damage component, not ordinary spell damage for Lifeleech, and creates no new spell, hit, payment, resource event or damage root; it cannot recursively trigger itself. Direct recovery does not remove Wounds, Prone or an independent cause of Unconsciousness. It ends on its deadline or your actual death and does not stack with itself. Missing this delayed recovery or being killed before it never becomes a later corpse wake-up.

**Explicit NEW choices:** Episode-bound regular-start recovery, before-death-save placement, blocked/early-healed/dead branches and exact one-minute +2 necrotic rider scope. Distinguish direct recovery from resurrection.

**Worked adjudications**

- The holder drops to zero and survives the packet, commits the use, then receives ordinary healing before the next regular start. That real episode closes; the delayed effect neither lowers them to 1 HP nor grants its recovery rider.

- If still alive at zero at the deadline, legal direct recovery restores 1 HP before the death save and starts the minute-long rider. If already dead, neither recovery nor rider occurs.

**Dependencies:** Necrotic Affinity/Dark Fortitude exact ownership; Core and healing episode/deadline ordering; Damage ownership/copy and rider interactions.

<details><summary>Complete original record and original conference question</summary>

```json
{
  "id": "undying_flesh",
  "name": "Undying Flesh",
  "description": "Death tried to keep you. Your flesh negotiated a reprieve. Prestige lineage: Gravetouched. completed from the existing development record.)",
  "prerequisite": "Constitution 15+, Necrotic Affinity or Dark Fortitude",
  "effect": "You have resistance to necrotic and poison damage. Once per long rest, when you are reduced to 0 hit points but not killed outright, you rise at 1 hit point at the start of your next turn with temporary necrotic bonuses (+2 damage for 1 minute).",
  "type": "General",
  "source": "Completed from the existing feat draft corpus on 2026-08-05; playable wording supplied, final balance pass still required.",
  "legacyEffect": "You have resistance to necrotic and poison damage. Once per long rest, when you are reduced to 0 hit points but not killed outright, you rise at 1 hit point at the start of your next turn with temporary necrotic bonuses (+2 damage for 1 minute).",
  "status": "provisional-complete",
  "balanceReview": true,
  "draft": false,
  "deprecated": false,
  "needsReview": true
}
```

Bind CON15 plus Necrotic Affinity OR Dark Fortitude to actual feat IDs. Define necrotic/poison resistance and once-Long-Rest delayed rise at1HP on next own turn after HP0-but-not-outright-death, with Wound/death/resurrection distinctions and interruption if killed in between. Specify what +2damage for one minute applies to, damage type, attacks/packets/copies and consumption/recovery timing; no indefinite corpse wake-up.

</details>

## Joint decisions still required

Review all31 original questions against these complete procedures. Explicit new decisions include ASI/armor/save-feat repeatability; composite ability caps; Battle Ready helper timing; Berserker melee scope; literal Dragon Blood/Elemental Body eligibility; Durable and Quick Recovery healing arithmetic; Endurance deprivation clocks; Healer costs and recipient cadence; the mental-effect predicate; fear/death reroll boundaries; Cursebound silver components/floor timing; Dark Fortitude reaction ordering; and Undying Flesh’s actual living-episode deadline and damage rider. Preserve every current and legacy source alongside the selected result.

Do not call the whole feats reviewed because their maximum-HP components already passed. Do not treat a synthetic arithmetic result as a working actor/resource scheduler. Runtime integration, full spell/class/feat interactions, human teaching and numerical balance remain separate work. Final whole-game flow agreement precedes the authorized GitHub push; verified remote precedes careful cosmology review.
