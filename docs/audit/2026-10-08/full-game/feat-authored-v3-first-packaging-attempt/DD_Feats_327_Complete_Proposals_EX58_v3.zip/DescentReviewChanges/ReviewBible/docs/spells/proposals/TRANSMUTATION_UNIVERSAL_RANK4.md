# Rank-four Transmutation and Universal: operating proposals

**UNADOPTED AND UNSENT.** Twelve complete procedures and twenty-four authored examples; Veiled Chest remains one unchanged literal deferred receipt. Original source, class access and historical versions remain intact. These await GPT discussion and exact review; examples are not runtime tests.

[Complete structured evidence](../../../data/director/spell_proposals/transmutation_universal_rank4.json) · [Original questions](../../../../../docs/audit/2026-10-08/full-game/TRANSMUTATION_UNIVERSAL_RANK4_SOURCE_AUDIT.md) · [Preservation checks](../../../../../docs/audit/2026-10-08/full-game/TRANSMUTATION_UNIVERSAL_RANK4_OPERATING_PROPOSAL_CHECK.json)

## Shared proposed rules

### status

UNADOPTED AND UNSENT. Twelve complete mechanical proposals, twenty-four authored examples and one unchanged post-push receipt. Every unsupported completion is NEW and awaits joint discussion/exact review. No ordinary approval, runtime, class grant, balance or cosmology claim changes.

### casting

KEEP the actual selected classAccess row, rank 4/base 7 RP, repertoire and minimum class level. Fabricate keeps both Transmutation and Universal placements rather than merging their class access. Time Skip uses its printed Bonus Action; the other eleven use Action. V/S/F applies except Fabricate preserves V/S/M/F through the existing actual unpriced material-or-focus alternative; real fabrication substrates remain independently required. Check observable legality and real components/resources before commitment, then spend the actual Action/Bonus Action and source costs/cadence before countering. Hidden ineligibility grants neither free diagnosis nor a refund. Concentration begins under the ordinary rule and displaces incompatible previous concentration even if countered. Use actual casting modifier plus PB for spell attacks; DC 8 plus those values for saves. Saves remain binary; named task checks use Core degrees/natural shifts collapsed to success/failure unless the crafting table expressly replaces them. No generic upcast, new repertoire, free material, second resource pool or unprinted scaling.

### clocksAndSources

NEW default here: one active instance per original caster per spell identity; a successful replacement ends that caster’s former active instance. Failed/countered nonconcentration casts create no replacement. Actual concentration displacement still occurs at commitment. A NEW minute/hour is an absolute 60/3600 elapsed seconds from completed resolution, preserved through initiative changes, absence and suppression. Expiry precedes a use at exactly the deadline. Keep each original owner/class/cast ID, actual source rank, snapshotted DC, target/component, consumed opportunity and endpoint. Suppression suspends only its actual scope, never resets clocks, refills budgets, restores ended concentration or queues missed ticks. Specific termination/reappearance exceptions below are explicit. Nonconcentration voluntary dismissal here uses the original caster’s Action with perception and line of effect to the anchor within original range, except Time Skip’s expressly defined arming/return procedure. Completed instantaneous physical consequences cannot be recalled.

### realBodiesAndMatter

KEEP one physical identity for every creature, object, container and material lot. A creature is not a nonliving object merely because it is Undead, Construct, Petrified, unconscious or temporarily object-shaped. A genuinely dead body retains its actual corpse identity and old resource restrictions. Actual worn/held/carried noncreature belongings, including independently lawful melded possessions, keep their quantity, damage, age, ownership and paid history. Real anatomical capacity, pounds and Load apply separately. No other creature is ordinary gear. A closed container does not erase its contents’ weight or eligibility. A spell roll cannot authenticate unknown contents, a lawful owner, a source value, a safe destination or a formula. Source-ineligible summoned/copy material cannot become eligible stock through reshaping, custody transfer or a new item ID.

### movementAndGeometry

KEEP real support, occupied volume, source-qualified movement prevention and actual endpoint wards. A teleport is not traversed movement, costs no Speed by itself and gives no ordinary opportunity attack, fresh movement budget or companion turn. Speed 0 alone does not block relocation. Approaching a portal still spends movement and can provoke under actual ordinary rules. Explicit remote-destination exceptions below waive only the stated originating path/line-of-effect requirement. They grant no sight through walls or topology between planes. Movement groups resolve atomically with all their actual gear: no split arrivals, cargo deletion, post-failure alternate-square choice or second copy. At genuine lost support use existing Falling. An illegal observed declaration does not commit; a hidden/newly invalid destination can defeat a committed transit without refund or diagnostic.

### damageAndDefenses

KEEP typed defenses, actual prevention/sharing, temporary/form buffers, normal HP, Wounds and concentration. Half saves floor before actual defenses. Mixed typed components in one original hit remain one damage event, while genuinely distinct triggers keep their own roots. An area event snapshots admitted bodies/geometry once and shares the raw roll; each recipient applies its own save/defenses. Nonmagical versus magical damage follows actual source properties, not a weapon’s wielder or a form’s name. A source created by a spell does not automatically make every later mundane collision or supplied natural attack magical. Actual HP payment is not damage. A converted output below is one event in its final category, not both damage and healing.

### roundHistory

NEW only where these cards expressly use a family cap: keep the actual creature/spell/category history across all casts and owners for the numbered combat round. Outside initiative use the ongoing six-second scene cycle fixed before the first relevant event. Crossing timing modes carries the still-open cycle’s spent entries into the corresponding round, without a recast/reentry reset. Extra turns do not refresh these caps. Existing one-extra-full-Action, actual Bonus Action, Reaction, movement, companion-command and offensive-companion/device records retain their real scopes. Time Skip’s additional Bonus Action is a specific NEW exception, not a general change to those rules.

### informationAndCompletion

KEEP individually perceived source selection, actual sensory range/lighting, protected information and source-specific recognition limits. Detecting nearby magic is not identifying a specific buff, rank or hidden creature. Historical labels in the preparation are not current approvals: Haste, Arcane Portal, Spell Mirror and Unravel Spell now have reviewed low-rank procedures; Dimensional Anchor and Dimensional Door have separate unadopted proposals. The unresolved exact-name Fly example stays unresolved. Veiled Chest and its historical alias are literal receipts only; no mechanism, destination, interpretation or promotion is authored for them.

## Decisions for joint review

- Greater Stoneflesh retains broad nonmagical resistance, +4 AC and minute duration without importing the lesser Speed penalty. Confirm nonconcentration and actual source-provenance handling rather than restricting the source to weapons.

- Crystalline Growth preserves both entry and movement, with one shared family exposure per target/round and no creation pulse. Confirm ground contact, five-foot movement threshold and the finite destructible patch profile.

- Teleport Object proposes actual contested custody, whole-container mass and secured/restraint boundaries. Its two range bounds, real supported arrival and no creature payload must be reviewed without treating nonliving as an object type.

- Formlock prevents prospective genuine form changes without a rank ceiling but never blocks an existing source’s legal ending. Confirm ordinary cosmetic/condition distinctions and the high-rank prevention interaction.

- Control Water supplies real Raise/Lower/Redirect operations with finite quantities, Action movement and swimmer/helmsman resolution. Review the exact forced-motion resistance and buoyancy/anchor geometry; it creates no water or harvest.

- Fabricate actually replaces a qualifying mundane order’s active shaping/assembly hours with one Action. Review the 500-pound/ten-foot-cube batch limit, skill/quality/material conservation, real assistants and explicit exclusion of magical/biological/calendar processes.

- Fabricate’s no-trade-XP rule and recording of a successful recipe in the existing first-success history are NEW learning/economy choices. They are not attributed to the original source; normal pricing and physical quality still use the reviewed framework.

- Spell Theft proposes one whole qualifying rank≤4 buff bundle, retained original concentration owner and lifetime transfer flag. Haste imposes the donor’s real accepted ending cost and the thief’s eventual ending cost without refreshing Action history. The exact Fly source example remains unresolved.

- Time Skip proposes a delayed departure that skips exactly one future regular interval, ending current concentration on departure and preserving all real clocks/life consequences. Its actual additional return Bonus Action is a specific exception, not a rename of the ordinary one.

- Time Skip’s mandatory same-anchor return uses the existing nearest-adjacent placement/conflict procedure. Confirm that blocked placement does not extend absence or invulnerability, and that early suppression/removal gives no return bonus.

- Arcane Reversal uses five explicit inverse pairs and one lifetime inversion of a rank≤4 component, preserving source funding/schedules. Converted healing-reserve expenditure and final-category defenses need joint review, especially for ordinary-spell companion outputs and damage-funded healing.

- Mystic Gate remains two-way for the full minute with real movement/geometry throughput, including an independently legal fitting transport assembly. The local-only endpoint proposal interprets no new cosmology and borrows no faction credentials.

- Universal Dimension Door explicitly permits a precise measured-vector destination, unlike the separately proposed Conjuration known-location rule. Confirm that distinction while preserving both source identities and paid blocked-arrival behavior.

- Arcane Eye proposes hour-long concentration, a 500-foot tether and Action/30-foot movement through actual one-inch paths. Its invisibility/detection and Universal information-ward scope cannot be replaced by a creature-only sight rule or automatic Divination classification.

- Veiled Chest remains the complete literal post-push receipt, with its historical alias and all source access untouched. No mechanism is authored, and no other pending proposal or recipe gains approval from this package.

## TU4-01 — Greater Stoneflesh

**Original placements, unchanged**

- Transmutation rank 4: +4 AC, resistance to non-magical damage, lasts 1 minute.

**Proposed procedure**

Action; range 60 feet; V/S/F. KEEP +4 AC, resistance to nonmagical damage and the explicit one-minute source promise over contradictory Instantaneous metadata. NEW choose one willing perceived creature with line of effect, including yourself; duration sixty elapsed seconds without concentration. The +4 is one spell-derived flat AC bonus under the existing strongest applicable same-stat flat-bonus arbitration; it is not another armor formula, base-AC replacement or bonus to worn equipment’s structural AC. The creature’s actual compatible armor/form AC is calculated normally before the permitted bonus. KEEP resistance to all genuinely nonmagical damage, rather than silently restricting the wording to weapon attacks or bludgeoning/piercing/slashing. For every typed packet/component use its actual causal source’s magical-damage property. Ordinary environmental fire, falls or poison can qualify when truly nonmagical; an actual spell’s direct magical damage does not. A monster, animated body, magical weapon or carrier title alone cannot relabel an unrelated event. When provenance is not established, determine the real source from existing facts without inventing a bypass or treating unknown as nonmagical by default. Apply eligible resistance once with native rounding and immunity/vulnerability rules; duplicate resistance never becomes quarter damage or immunity. This greater identity grants no halved Speed, added body mass, stone anatomy, Petrified immunity, extra HP, structural repair or harvesting rights. An independent Stoneflesh may retain its own Speed penalty even when its smaller AC bonus does not add. Source suppression suspends this record’s AC/resistance while its deadline continues. Removal/expiry removes only this source; other independent defenses remain. A successful same-caster replacement ends the older instance without refund or healing, and no continuing range tether is added.

**Explicit NEW choices:** NEW willing target and nonconcentration minute, explicit strongest flat AC category and source-provenance test for all nonmagical damage. Printed +4 and broad nonmagical resistance are preserved, without importing lesser Stoneflesh’s Speed penalty.

**Authored examples**

- TU4-01-A: A creature has AC 15 before flat spell bonuses and both +2 Stoneflesh and +4 Greater Stoneflesh. The permitted strongest bonus gives AC 19, not 21. The older spell’s separate half-Speed rider can still operate until its own source ends.

- TU4-01-B: An established mundane fire deals 17 fire before resistance, so eligible resistance yields 8. A separately established magical fire-spell packet of 17 receives no reduction from this nonmagical-only resistance. The result depends on the actual event, not merely its fire type.

<details><summary>Original question and complete source/access record</summary>

Preserve+4AC, resistance to nonmagical damage and one-minute duration, Core Action/60ft/Instantaneous. Resolve recipient, concentration and explicit duration conflict, then the AC bonus family and exact meaning of nonmagical damage using actual damage source properties. Do not silently restrict it to weapon damage or import Stoneflesh's halved movement when this source omits that clause. Compare strongest AC/defense sources, compatible forms and actual armor; apply per-packet resistance and rounding. Recasting/ending/suppression cannot create a second armor formula, heal structural HP or refresh resources.

```json
{
  "id": "greater-stoneflesh",
  "name": "Greater Stoneflesh",
  "schools": [
    "Transmutation"
  ],
  "status": "blocked-pending-operational-review",
  "visibility": "public-source-review",
  "classAccess": {
    "Dragoon": {
      "rank": 4,
      "minimumClassLevel": 18,
      "school": "Transmutation",
      "baseRpCost": 7
    },
    "Druid": {
      "rank": 4,
      "minimumClassLevel": 7,
      "school": "Transmutation",
      "baseRpCost": 7
    },
    "Mage": {
      "rank": 4,
      "minimumClassLevel": 7,
      "school": "Transmutation",
      "baseRpCost": 7
    },
    "Monk": {
      "rank": 4,
      "minimumClassLevel": 18,
      "school": "Transmutation",
      "baseRpCost": 7
    },
    "Ranger": {
      "rank": 4,
      "minimumClassLevel": 13,
      "school": "Transmutation",
      "baseRpCost": 7
    },
    "Shaman": {
      "rank": 4,
      "minimumClassLevel": 10,
      "school": "Transmutation",
      "baseRpCost": 7
    },
    "Thief": {
      "rank": 4,
      "minimumClassLevel": 18,
      "school": "Transmutation",
      "baseRpCost": 7
    },
    "Tinker": {
      "rank": 4,
      "minimumClassLevel": 14,
      "school": "Transmutation",
      "baseRpCost": 7
    },
    "Wizard": {
      "rank": 4,
      "minimumClassLevel": 7,
      "school": "Transmutation",
      "baseRpCost": 7
    }
  },
  "operational": null,
  "additionalRpCost": 0,
  "source": {
    "catalogPath": "src/data/spells.js",
    "catalogSha256": "3358a2e1afcbc340dbafd92e45e39a7d2d0a24fed5c0719a3d233263ce530078",
    "catalogKey": "greater-stoneflesh",
    "original": {
      "name": "Greater Stoneflesh",
      "level": 4,
      "resonanceRank": 4,
      "school": "Transmutation",
      "schools": [
        "Transmutation"
      ],
      "placements": [
        {
          "name": "Greater Stoneflesh",
          "school": "Transmutation",
          "level": 4,
          "summary": "+4 AC, resistance to non-magical damage, lasts 1 minute."
        }
      ],
      "classLevels": {
        "Dragoon": 4,
        "Druid": 4,
        "Mage": 4,
        "Monk": 4,
        "Ranger": 4,
        "Shaman": 4,
        "Thief": 4,
        "Tinker": 4,
        "Wizard": 4
      },
      "classRanks": {
        "Dragoon": 4,
        "Druid": 4,
        "Mage": 4,
        "Monk": 4,
        "Ranger": 4,
        "Shaman": 4,
        "Thief": 4,
        "Tinker": 4,
        "Wizard": 4
      },
      "classLearnLevels": {
        "Dragoon": 18,
        "Druid": 7,
        "Mage": 7,
        "Monk": 18,
        "Ranger": 13,
        "Shaman": 10,
        "Thief": 18,
        "Tinker": 14,
        "Wizard": 7
      },
      "classSchools": {
        "Dragoon": "Transmutation",
        "Druid": "Transmutation",
        "Mage": "Transmutation",
        "Monk": "Transmutation",
        "Ranger": "Transmutation",
        "Shaman": "Transmutation",
        "Thief": "Transmutation",
        "Tinker": "Transmutation",
        "Wizard": "Transmutation"
      },
      "castingTime": "Not specified in current rulebook",
      "range": "Not specified in current rulebook",
      "components": "Not specified in current rulebook",
      "duration": "Not specified in current rulebook",
      "description": "+4 AC, resistance to non-magical damage, lasts 1 minute.",
      "alternateSummaries": [],
      "classes": [
        "Dragoon",
        "Druid",
        "Mage",
        "Monk",
        "Ranger",
        "Shaman",
        "Thief",
        "Tinker",
        "Wizard"
      ],
      "status": "canon",
      "source": "Player Rulebook — Spell Lists"
    },
    "corePath": "data/public/Decennium_Descent_Core_Systems_Data_v2_Known_Descent.json",
    "coreSha256": "50c3e9683349e93192191381ab6354ca7d675a24fcc9bb9b039c23e67fecca4f",
    "coreEntries": [
      {
        "index": 776,
        "original": {
          "school": "Transmutation",
          "level": 4,
          "name": "Greater Stoneflesh",
          "effect": "+4 AC, resistance to non-magical damage, lasts 1 minute.",
          "source_paragraph": 9942,
          "casting_time": "1 action",
          "range": "60 feet",
          "duration": "Instantaneous",
          "components": "V, S, F",
          "resolution": "Automatic or opposed as described",
          "tags": [
            "Ward"
          ],
          "rp_cost": 7
        }
      }
    ],
    "possibleHistoricalAliases": []
  },
  "reviewFlags": [
    "Core resolution requires an explicit operational interpretation",
    "Not selectable in this spell playtest packet until individual operational review"
  ]
}
```

</details>

## TU4-02 — Crystalline Growth

**Original placements, unchanged**

- Transmutation rank 4: Create hazardous crystal field: 3d6 piercing on entry or move.

**Proposed procedure**

Action; range 60 feet; V/S/F. KEEP a crystal field dealing 3d6 piercing on entry or move. NEW create a fixed twenty-foot-radius footprint of conjured spines extending one foot above genuinely exposed supported surfaces, centered on a perceived point with line of effect and clipped by real barriers. Replace Instantaneous with concentration up to sixty seconds. The field does not rise through a ceiling, create support, change movement cost, restrain, block sight or become useful gems. NEW two actual triggers share one cap: a creature physically enters/contact-arrives on an active patch from outside the active field, OR actually moves at least five feet while contacting its active patches after starting inside. Entry consumes the same opportunity as movement; it is not a second packet after the first five feet. The same continuous body trajectory can qualify only once per creature per numbered round across all Crystalline Growth casts/owners. Voluntary and forced ground motion qualify; teleport arrival onto an active patch qualifies as entry, but teleporting across without contact does not. Airborne passage wholly above the one-foot spines does not qualify. Creation under a stationary creature is neither entry nor movement; standing still supplies no periodic tick. In-place gestures, attacks and another creature’s turn supply no movement trigger. At a genuine eligible exposure make DEX: failure takes 3d6 magical piercing, success half. A simultaneous entry group shares one raw roll; distinct actual exposures roll separately. Ordinary defenses and exact hazard permissions apply; shoes alone supply no generic hazard immunity. Formation/suppression lifting creates no fictitious entry. NEW physical removal profile: partition the footprint into fixed scene-aligned five-foot patches, clipping edge patches to the true radius; each patch has AC 13 and HP 10, with no additional resistance/immunity beyond actual object rules. A legal reachable object attack can damage one actual patch, with no invented multi-patch attack or harm to creatures standing there. At zero HP that patch is permanently cleared for this instance; there is no regrowth, separate cheap spike target or second salvage claim. Effects including objects can affect patches only within their real geometry. Suppression makes affected spines inactive and nonobstructive while preserving damage/cleared-state history and deadline; resumption restores only uncleared patches with no free damage trigger. Ending the source removes all remaining spines and leaves actual unrelated damage/cargo unchanged. No harvestable crystal, field relocation or initial damage is added.

**Explicit NEW choices:** NEW supported radius-20 footprint, one-foot height, concentration minute, DEX half, entry-or-five-foot-move trigger sharing one family exposure per round, and AC13/HP10 clearable five-foot patches. Both printed triggers remain without a per-tile damage loop.

**Authored examples**

- TU4-02-A: The field forms under a stationary enemy, causing no initial packet. It then walks five feet through an active patch: DEX succeeds against a shared raw 3d6 roll of 11, for 5 before defenses. Leaving and reentering another caster’s field that numbered round gives no second Crystalline Growth packet.

- TU4-02-B: A legal object attack deals 10 actual damage to an AC13/HP10 patch, clearing it. Suppression later lifts without restoring that patch or repeating entry damage. A flier whose entire body passes two feet above the spines remains outside their contact volume.

<details><summary>Original question and complete source/access record</summary>

Preserve a hazardous crystal field dealing3d6 piercing on entry OR move, Action/60ft/Instantaneous. Define finite geometry/support, lifetime/concentration and eligible creatures/objects. Set the actual entry/movement event, distance thresholds or cadence, forced movement, teleportation, airborne passage and initial placement. Resolve the explicit two triggers without silently deleting one or permitting unlimited per-tile/reentry packets. Determine saves, shared rolls, cover, overlapping casts and suppression. Define whether crystals are physical, breakable or resource-ineligible; no free gem stock, automatic Restrained, extra difficult terrain or generic hazard immunity is implied.

```json
{
  "id": "crystalline-growth",
  "name": "Crystalline Growth",
  "schools": [
    "Transmutation"
  ],
  "status": "blocked-pending-operational-review",
  "visibility": "public-source-review",
  "classAccess": {
    "Dragoon": {
      "rank": 4,
      "minimumClassLevel": 18,
      "school": "Transmutation",
      "baseRpCost": 7
    },
    "Druid": {
      "rank": 4,
      "minimumClassLevel": 7,
      "school": "Transmutation",
      "baseRpCost": 7
    },
    "Mage": {
      "rank": 4,
      "minimumClassLevel": 7,
      "school": "Transmutation",
      "baseRpCost": 7
    },
    "Monk": {
      "rank": 4,
      "minimumClassLevel": 18,
      "school": "Transmutation",
      "baseRpCost": 7
    },
    "Ranger": {
      "rank": 4,
      "minimumClassLevel": 13,
      "school": "Transmutation",
      "baseRpCost": 7
    },
    "Shaman": {
      "rank": 4,
      "minimumClassLevel": 10,
      "school": "Transmutation",
      "baseRpCost": 7
    },
    "Thief": {
      "rank": 4,
      "minimumClassLevel": 18,
      "school": "Transmutation",
      "baseRpCost": 7
    },
    "Tinker": {
      "rank": 4,
      "minimumClassLevel": 14,
      "school": "Transmutation",
      "baseRpCost": 7
    },
    "Wizard": {
      "rank": 4,
      "minimumClassLevel": 7,
      "school": "Transmutation",
      "baseRpCost": 7
    }
  },
  "operational": null,
  "additionalRpCost": 0,
  "source": {
    "catalogPath": "src/data/spells.js",
    "catalogSha256": "3358a2e1afcbc340dbafd92e45e39a7d2d0a24fed5c0719a3d233263ce530078",
    "catalogKey": "crystalline-growth",
    "original": {
      "name": "Crystalline Growth",
      "level": 4,
      "resonanceRank": 4,
      "school": "Transmutation",
      "schools": [
        "Transmutation"
      ],
      "placements": [
        {
          "name": "Crystalline Growth",
          "school": "Transmutation",
          "level": 4,
          "summary": "Create hazardous crystal field: 3d6 piercing on entry or move."
        }
      ],
      "classLevels": {
        "Dragoon": 4,
        "Druid": 4,
        "Mage": 4,
        "Monk": 4,
        "Ranger": 4,
        "Shaman": 4,
        "Thief": 4,
        "Tinker": 4,
        "Wizard": 4
      },
      "classRanks": {
        "Dragoon": 4,
        "Druid": 4,
        "Mage": 4,
        "Monk": 4,
        "Ranger": 4,
        "Shaman": 4,
        "Thief": 4,
        "Tinker": 4,
        "Wizard": 4
      },
      "classLearnLevels": {
        "Dragoon": 18,
        "Druid": 7,
        "Mage": 7,
        "Monk": 18,
        "Ranger": 13,
        "Shaman": 10,
        "Thief": 18,
        "Tinker": 14,
        "Wizard": 7
      },
      "classSchools": {
        "Dragoon": "Transmutation",
        "Druid": "Transmutation",
        "Mage": "Transmutation",
        "Monk": "Transmutation",
        "Ranger": "Transmutation",
        "Shaman": "Transmutation",
        "Thief": "Transmutation",
        "Tinker": "Transmutation",
        "Wizard": "Transmutation"
      },
      "castingTime": "Not specified in current rulebook",
      "range": "Not specified in current rulebook",
      "components": "Not specified in current rulebook",
      "duration": "Not specified in current rulebook",
      "description": "Create hazardous crystal field: 3d6 piercing on entry or move.",
      "alternateSummaries": [],
      "classes": [
        "Dragoon",
        "Druid",
        "Mage",
        "Monk",
        "Ranger",
        "Shaman",
        "Thief",
        "Tinker",
        "Wizard"
      ],
      "status": "canon",
      "source": "Player Rulebook — Spell Lists"
    },
    "corePath": "data/public/Decennium_Descent_Core_Systems_Data_v2_Known_Descent.json",
    "coreSha256": "50c3e9683349e93192191381ab6354ca7d675a24fcc9bb9b039c23e67fecca4f",
    "coreEntries": [
      {
        "index": 777,
        "original": {
          "school": "Transmutation",
          "level": 4,
          "name": "Crystalline Growth",
          "effect": "Create hazardous crystal field: 3d6 piercing on entry or move.",
          "source_paragraph": 9943,
          "casting_time": "1 action",
          "range": "60 feet",
          "duration": "Instantaneous",
          "components": "V, S, F",
          "resolution": "Automatic or opposed as described",
          "tags": [
            "Damage"
          ],
          "rp_cost": 7
        }
      }
    ],
    "possibleHistoricalAliases": []
  },
  "reviewFlags": [
    "Core resolution requires an explicit operational interpretation",
    "Not selectable in this spell playtest packet until individual operational review"
  ]
}
```

</details>

## TU4-03 — Teleport Object

**Original placements, unchanged**

- Transmutation rank 4: Move any non-living item up to 500 lb within 100 ft.

**Proposed procedure**

Action; range 100 feet; V/S/F; Instantaneous. KEEP one nonliving item of at most 500 pounds moved within 100 feet. NEW the source item must be individually perceived within 100 feet and line of effect; choose one precise perceived destination within 100 feet of the caster AND no more than 100 feet from the source item’s anchor. The destination need not have an unobstructed intervening path, but actual transport wards still apply. It must contain the whole actual item/payload at the chosen orientation, with real support at rest; no deliberate unsupported drop, insertion into a body or momentum attack is granted. One connected standalone item or real container plus its complete enclosed noncreature contents is one payload. Count all contents and attached parts toward 500 pounds; selecting a lid, gem, hinge or wall section does not detach it or make a new object. Actual assemblies bolted/built into another structure, locked/secured to an external anchor, implanted in a body, or functioning as a locked restraint are ineligible until actually released. Ordinary loose worn gear or an item merely held can qualify if moving the whole item removes no body part, breaks no external secured connection and violates no exact item/ward restriction. NEW an unwilling actual bearer/custodian holding or wearing it makes WIS against the spell DC; success prevents movement. A willing custodian may expressly waive that save. Multiple real custodians must all be willing or fail their own saves; one success blocks the indivisible transaction. Unattended items need no save. Magical identity or attunement alone is not a general immunity, but source-specific anti-removal rules still govern. No creature or living payload travels inside a container; Undead, Constructs and magically object-shaped creatures remain creatures. A genuine corpse is a nonliving body-object only where the actual life rules establish that state; its old identity, weight, decay and resource restrictions persist. Hidden weight, contents, attachment or arrival ineligibility can defeat a paid cast without revealing which fact caused failure. At resolution recheck the complete payload, custodians, endpoints and support. A failure moves nothing and opens no container. Successful placement is at rest relative to the actual destination support; it does not carry stored impact momentum, activate a device, discharge a trap as an attack or rearrange contents. Actual lawful independent consequences of moving an object remain, but no spell-supplied attack or free Sunder is added. The object’s real ownership, locks, conditions, charges and contents remain unchanged.

**Explicit NEW choices:** NEW both caster-range and displacement limits, actual-perception/path exception, supported whole-item placement, complete container mass, WIS contested custody and explicit secured/restraint exclusions. No partial extraction or creature-as-object conversion.

**Authored examples**

- TU4-03-A: A 40-pound chest contains 430 pounds of actual noncreature cargo. The 470-pound whole payload qualifies by mass. Source and destination are each within caster range and 80 feet apart; a legal supported arrival moves the locked chest with the same contents and lock, without opening it.

- TU4-03-B: The same chest contains another 40 pounds, bringing it to 510, or secretly contains an actual creature. It cannot travel as this payload. A paid failure supplies no free contents/weight readout, and the caster cannot salvage the attempt by sending only a conveniently chosen portion.

<details><summary>Original question and complete source/access record</summary>

Preserve any nonliving item up to500lb moved within100ft, Action/100ft/Instantaneous. Define one item versus container/assembly, total payload mass, actual connected parts, attached/worn/held/secured items and contested custody; nonliving does not automatically mean a creature is an object. Specify source and destination knowledge, perception/line of effect, both distance limits, legal volume/support and occupancy. Container contents retain real identity and must satisfy any actual living-payload rule. No duplication, partial-body extraction, automatically bypassed locks/restraints, momentum weapon, mass laundering or interplanar reach is inferred. Paid failed placement and suppression follow explicit transaction rules.

```json
{
  "id": "teleport-object",
  "name": "Teleport Object",
  "schools": [
    "Transmutation"
  ],
  "status": "blocked-pending-operational-review",
  "visibility": "public-source-review",
  "classAccess": {
    "Dragoon": {
      "rank": 4,
      "minimumClassLevel": 18,
      "school": "Transmutation",
      "baseRpCost": 7
    },
    "Druid": {
      "rank": 4,
      "minimumClassLevel": 7,
      "school": "Transmutation",
      "baseRpCost": 7
    },
    "Mage": {
      "rank": 4,
      "minimumClassLevel": 7,
      "school": "Transmutation",
      "baseRpCost": 7
    },
    "Monk": {
      "rank": 4,
      "minimumClassLevel": 18,
      "school": "Transmutation",
      "baseRpCost": 7
    },
    "Ranger": {
      "rank": 4,
      "minimumClassLevel": 13,
      "school": "Transmutation",
      "baseRpCost": 7
    },
    "Shaman": {
      "rank": 4,
      "minimumClassLevel": 10,
      "school": "Transmutation",
      "baseRpCost": 7
    },
    "Thief": {
      "rank": 4,
      "minimumClassLevel": 18,
      "school": "Transmutation",
      "baseRpCost": 7
    },
    "Tinker": {
      "rank": 4,
      "minimumClassLevel": 14,
      "school": "Transmutation",
      "baseRpCost": 7
    },
    "Wizard": {
      "rank": 4,
      "minimumClassLevel": 7,
      "school": "Transmutation",
      "baseRpCost": 7
    }
  },
  "operational": null,
  "additionalRpCost": 0,
  "source": {
    "catalogPath": "src/data/spells.js",
    "catalogSha256": "3358a2e1afcbc340dbafd92e45e39a7d2d0a24fed5c0719a3d233263ce530078",
    "catalogKey": "teleport-object",
    "original": {
      "name": "Teleport Object",
      "level": 4,
      "resonanceRank": 4,
      "school": "Transmutation",
      "schools": [
        "Transmutation"
      ],
      "placements": [
        {
          "name": "Teleport Object",
          "school": "Transmutation",
          "level": 4,
          "summary": "Move any non-living item up to 500 lb within 100 ft."
        }
      ],
      "classLevels": {
        "Dragoon": 4,
        "Druid": 4,
        "Mage": 4,
        "Monk": 4,
        "Ranger": 4,
        "Shaman": 4,
        "Thief": 4,
        "Tinker": 4,
        "Wizard": 4
      },
      "classRanks": {
        "Dragoon": 4,
        "Druid": 4,
        "Mage": 4,
        "Monk": 4,
        "Ranger": 4,
        "Shaman": 4,
        "Thief": 4,
        "Tinker": 4,
        "Wizard": 4
      },
      "classLearnLevels": {
        "Dragoon": 18,
        "Druid": 7,
        "Mage": 7,
        "Monk": 18,
        "Ranger": 13,
        "Shaman": 10,
        "Thief": 18,
        "Tinker": 14,
        "Wizard": 7
      },
      "classSchools": {
        "Dragoon": "Transmutation",
        "Druid": "Transmutation",
        "Mage": "Transmutation",
        "Monk": "Transmutation",
        "Ranger": "Transmutation",
        "Shaman": "Transmutation",
        "Thief": "Transmutation",
        "Tinker": "Transmutation",
        "Wizard": "Transmutation"
      },
      "castingTime": "Not specified in current rulebook",
      "range": "Not specified in current rulebook",
      "components": "Not specified in current rulebook",
      "duration": "Not specified in current rulebook",
      "description": "Move any non-living item up to 500 lb within 100 ft.",
      "alternateSummaries": [],
      "classes": [
        "Dragoon",
        "Druid",
        "Mage",
        "Monk",
        "Ranger",
        "Shaman",
        "Thief",
        "Tinker",
        "Wizard"
      ],
      "status": "canon",
      "source": "Player Rulebook — Spell Lists"
    },
    "corePath": "data/public/Decennium_Descent_Core_Systems_Data_v2_Known_Descent.json",
    "coreSha256": "50c3e9683349e93192191381ab6354ca7d675a24fcc9bb9b039c23e67fecca4f",
    "coreEntries": [
      {
        "index": 778,
        "original": {
          "school": "Transmutation",
          "level": 4,
          "name": "Teleport Object",
          "effect": "Move any non-living item up to 500 lb within 100 ft.",
          "source_paragraph": 9944,
          "casting_time": "1 action",
          "range": "100 feet",
          "duration": "Instantaneous",
          "components": "V, S, F",
          "resolution": "Automatic or opposed as described",
          "tags": [
            "Movement"
          ],
          "rp_cost": 7
        }
      }
    ],
    "possibleHistoricalAliases": []
  },
  "reviewFlags": [
    "Core resolution requires an explicit operational interpretation",
    "Not selectable in this spell playtest packet until individual operational review"
  ]
}
```

</details>

## TU4-04 — Formlock

**Original placements, unchanged**

- Transmutation rank 4: Prevent creature from changing form or shape (WIS save negates).

**Proposed procedure**

Action; range 60 feet; V/S/F. One perceived creature with line of effect makes WIS; success establishes nothing. KEEP failure prevents changing form or shape. NEW concentration up to sixty elapsed seconds replaces Instantaneous. The target keeps its present actual body at application; this does not itself cancel, revert, transform or replace it. While active, prevent establishment of a NEW anatomy/form/size transformation of that same creature, whether voluntary, hostile or a genuine natural shapeshifter’s activated change. This covers a new Polymorph/Shapechange/Druid form or Enlarge/Reduce body-size alteration where actually applicable, without granting knowledge of those powers. No spell-rank ceiling is added to this prevention; an exact immunity/exception can defeat only the prevention it names. A new spell may still commit legal costs or resolve other independently eligible recipients/components; this target’s prohibited new body is not established. If the block is already observably known and the attempted action has no other legal outcome, ordinary preflight rejects it without payment. A hidden block or one established after commitment can defeat the already paid change without refund. KEEP mandatory source endings: expiry, concentration loss, zero-HP/incapacity/death reversion, dispel, destruction and an otherwise legal early termination/rejection end their existing form normally and reconcile root anatomy and real melded gear. Formlock never extends a body, traps it past its endpoint or recreates an already displaced anatomy. A voluntary change to a different selected form is blocked; voluntarily ending an existing form is allowed. Starting a new concentration effect can therefore end an old form even if the requested replacement then fails against Formlock. Cosmetic illusions/disguises, clothes, posture, ordinary locomotion, normal biological aging/healing and a condition such as Petrified follow their own categories; this spell does not convert every appearance or condition change into a form activation. It grants no immunity to harm, actual death, involuntary motion or a named condition. Suppression of Formlock permits otherwise legal new changes while suppressed; their establishment is not undone when the lock resumes. Original duration/resource/body history remains. NEW no repeat save is added; qualifying removal, concentration loss, expiry or actual recipient death ends this source. Preventing a transformation does not itself consume the whole-Action hard-denial allowance, because it denies this particular effect rather than all Actions.

**Explicit NEW choices:** NEW minute concentration, prevention of prospective genuine body/form changes without rank ceiling, explicit mandatory/voluntary-ending exceptions and precise cosmetic/condition distinctions. It never holds an expired form or gives refunded shift reserves.

**Authored examples**

- TU4-04-A: A Druid is in a legal Bear form when Formlock takes hold. The Bear remains until its own source ends. The Druid cannot select Hawk while locked, but can lawfully end Bear and return to root anatomy; the same real gear and spent shift history remain.

- TU4-04-B: A temporary spell form expires at t=40 while Formlock lasts until t=60. Mandatory reversion occurs at t=40. Later suppression permits a genuine new transformation at t=50; resuming the lock at t=55 does not erase that successfully established form or extend either source.

<details><summary>Original question and complete source/access record</summary>

Preserve preventing a creature from changing form/shape, WIS negates, Action/60ft/Instantaneous. Define finite duration/concentration, voluntary/hostile/natural transformations and what happens to an already active form, its ordinary endpoint, unconscious/death reversion, dispel and forced form loss. Never silently trap a creature in an expired body or restore an ended parent. Compare Shapechange, Polymorph and the actual Druid/body equipment rules; classify true body change separately from visual disguise and ordinary movement/posture. Preserve melded cargo custody, real HP/resources and paid failed shift/cast histories; no frozen duration or free form-reserve refill.

```json
{
  "id": "formlock",
  "name": "Formlock",
  "schools": [
    "Transmutation"
  ],
  "status": "blocked-pending-operational-review",
  "visibility": "public-source-review",
  "classAccess": {
    "Dragoon": {
      "rank": 4,
      "minimumClassLevel": 18,
      "school": "Transmutation",
      "baseRpCost": 7
    },
    "Druid": {
      "rank": 4,
      "minimumClassLevel": 7,
      "school": "Transmutation",
      "baseRpCost": 7
    },
    "Mage": {
      "rank": 4,
      "minimumClassLevel": 7,
      "school": "Transmutation",
      "baseRpCost": 7
    },
    "Monk": {
      "rank": 4,
      "minimumClassLevel": 18,
      "school": "Transmutation",
      "baseRpCost": 7
    },
    "Ranger": {
      "rank": 4,
      "minimumClassLevel": 13,
      "school": "Transmutation",
      "baseRpCost": 7
    },
    "Shaman": {
      "rank": 4,
      "minimumClassLevel": 10,
      "school": "Transmutation",
      "baseRpCost": 7
    },
    "Thief": {
      "rank": 4,
      "minimumClassLevel": 18,
      "school": "Transmutation",
      "baseRpCost": 7
    },
    "Tinker": {
      "rank": 4,
      "minimumClassLevel": 14,
      "school": "Transmutation",
      "baseRpCost": 7
    },
    "Wizard": {
      "rank": 4,
      "minimumClassLevel": 7,
      "school": "Transmutation",
      "baseRpCost": 7
    }
  },
  "operational": null,
  "additionalRpCost": 0,
  "source": {
    "catalogPath": "src/data/spells.js",
    "catalogSha256": "3358a2e1afcbc340dbafd92e45e39a7d2d0a24fed5c0719a3d233263ce530078",
    "catalogKey": "formlock",
    "original": {
      "name": "Formlock",
      "level": 4,
      "resonanceRank": 4,
      "school": "Transmutation",
      "schools": [
        "Transmutation"
      ],
      "placements": [
        {
          "name": "Formlock",
          "school": "Transmutation",
          "level": 4,
          "summary": "Prevent creature from changing form or shape (WIS save negates)."
        }
      ],
      "classLevels": {
        "Dragoon": 4,
        "Druid": 4,
        "Mage": 4,
        "Monk": 4,
        "Ranger": 4,
        "Shaman": 4,
        "Thief": 4,
        "Tinker": 4,
        "Wizard": 4
      },
      "classRanks": {
        "Dragoon": 4,
        "Druid": 4,
        "Mage": 4,
        "Monk": 4,
        "Ranger": 4,
        "Shaman": 4,
        "Thief": 4,
        "Tinker": 4,
        "Wizard": 4
      },
      "classLearnLevels": {
        "Dragoon": 18,
        "Druid": 7,
        "Mage": 7,
        "Monk": 18,
        "Ranger": 13,
        "Shaman": 10,
        "Thief": 18,
        "Tinker": 14,
        "Wizard": 7
      },
      "classSchools": {
        "Dragoon": "Transmutation",
        "Druid": "Transmutation",
        "Mage": "Transmutation",
        "Monk": "Transmutation",
        "Ranger": "Transmutation",
        "Shaman": "Transmutation",
        "Thief": "Transmutation",
        "Tinker": "Transmutation",
        "Wizard": "Transmutation"
      },
      "castingTime": "Not specified in current rulebook",
      "range": "Not specified in current rulebook",
      "components": "Not specified in current rulebook",
      "duration": "Not specified in current rulebook",
      "description": "Prevent creature from changing form or shape (WIS save negates).",
      "alternateSummaries": [],
      "classes": [
        "Dragoon",
        "Druid",
        "Mage",
        "Monk",
        "Ranger",
        "Shaman",
        "Thief",
        "Tinker",
        "Wizard"
      ],
      "status": "canon",
      "source": "Player Rulebook — Spell Lists"
    },
    "corePath": "data/public/Decennium_Descent_Core_Systems_Data_v2_Known_Descent.json",
    "coreSha256": "50c3e9683349e93192191381ab6354ca7d675a24fcc9bb9b039c23e67fecca4f",
    "coreEntries": [
      {
        "index": 779,
        "original": {
          "school": "Transmutation",
          "level": 4,
          "name": "Formlock",
          "effect": "Prevent creature from changing form or shape (WIS save negates).",
          "source_paragraph": 9945,
          "casting_time": "1 action",
          "range": "60 feet",
          "duration": "Instantaneous",
          "components": "V, S, F",
          "resolution": "Wisdom save",
          "tags": [
            "Utility"
          ],
          "rp_cost": 7
        }
      }
    ],
    "possibleHistoricalAliases": []
  },
  "reviewFlags": [
    "Not selectable in this spell playtest packet until individual operational review"
  ]
}
```

</details>

## TU4-05 — Control Water

**Original placements, unchanged**

- Transmutation rank 4: Raise, lower, or redirect water.

**Proposed procedure**

Action; range 60 feet; V/S/F; KEEP concentration up to one minute and raising, lowering or redirecting water. NEW select one actually perceived contiguous quantity of liquid water fitting at most a ten-foot cube, with initial line of effect, and record its real quantity/identity/contamination. Actual conjured water may qualify only while its own source permits this physical manipulation; preserve its original quantity, expiry, dispersal/consumption endings, recipient hydration limit and no-sale/no-ingredient restrictions. Manipulation never turns it into permanent natural stock. Fix a twenty-foot-cube working region with its center within sixty feet; all controlled water must remain in that region and within sixty feet of the caster when a new control operation is issued. Water inside a living body, a sealed vessel or a hostile worn/carried container is ineligible; another fluid, ice, steam or unselected incoming water is not silently converted into this inventory. At casting choose one initial operation; each later caster Action can issue one new operation. Each operation displaces the selected water at most ten feet along a declared actually open fluid path to available volume within the region. Choose Raise, Lower or Redirect: Raise lifts a supported connected body’s local surface by at most ten feet above its recorded starting level, maintaining that finite shape while concentration permits; Lower displaces its water sideways/down into actual available volume to lower the local surface at most ten feet below the starting level; Redirect changes its flow along the chosen open path, moving it at most ten feet for that operation. No cumulative height ratchet exceeds those bounds. Existing independent currents keep their actual behavior. There is no unlimited automatic conveyor after a single Action; without a new operation the magic only maintains the currently supported chosen shape. It can hold the selected finite water, not block an entire unselected river or create a vacuum that deletes incoming water. NEW a freely floating body/boat supported by the moved water follows its actual buoyancy and clearance; no weightless lift beyond its existing displacement/support or passage through a real anchor is created. When an operation would displace an unwilling swimming creature, it makes STR against spell DC: failure permits at most ten feet with that operation, success avoids that forced displacement if an actual reachable support/swimming position within its occupied water exists; absent any legal resisting position, the operation cannot force that creature through a barrier and stops at the last legal geometry. A free boat’s actual operating helmsman may instead make a DEX check with one genuinely applicable water-vehicle proficiency against spell DC, Core success/failure, for the whole boat; no fictional helmsman, control channel or repeated passenger saves. A moored/grounded/overloaded boat stays constrained by its real physical support; the spell supplies no breaking force. Each actual creature/boat can face at most one such forced-displacement attempt per Control Water family per round; additional Actions can move other water but cannot replay its forced-motion attempt. Willing following needs no roll. No hydraulic damage, whirlpool attack, automatic drowning, forced submerged airway, swimming speed or breathing benefit is supplied. Actual immersion, temperature, lost support, collisions and breath limits use their real rules and elapsed time. Controlled water keeps quantity and contamination; this is no creation, purification, fish harvest or free Supply. At loss of control, suppression or ending, the water obeys ordinary gravity/current from its actual present location; do not recreate it at its former source. Suppression lifts no fresh shape or missed motion when it ends: another legal Action is required to move/re-form the same remaining eligible water. Escaped water outside the region is no longer controlled; it is not replaced by new inflow. The current Fishing set has completed FI-E01–11 review. Its real stock, one deployment, fifty-five minutes to the check and five retrieval minutes remain; changing water access supplies no automatic catch or replacement roll. A worker spending this spell’s control Action cannot also credit that same six-second interval as active fishing work. Water movement never resets bait, opportunity, preservation or retrieval history.

**Explicit NEW choices:** NEW finite water quantity/working region, bounded height and Action displacement, actual buoyancy/anchor constraints, per-family forced-motion attempts with swimmer/helmsman checks and real release history. The printed three modes remain and no water/material is created.

**Authored examples**

- TU4-05-A: A recorded 200-cubic-foot quantity is redirected ten feet from an open basin into a real adjacent channel with sufficient volume. The basin loses that exact quantity and the channel receives it once. Releasing concentration leaves it in the channel under ordinary flow; neither the basin nor abstract Supply is refilled.

- TU4-05-B: An unwilling swimmer in the selected water fails STR and moves ten feet along a legal open path. A second paid control Action that numbered round cannot force another displacement attempt on that same creature. A moored boat in the water does not break its real tether merely because the caster declared Redirect.

<details><summary>Original question and complete source/access record</summary>

Preserve raising, lowering or redirecting water, Action/60ft/concentration up to one minute. Define finite volume/geometry, reachable source, height/flow limits, command timing and supported modes. Preserve real water quantity, contamination and connected containers/channels; compare Shape Water and Conjure Water without treating manipulation as creation or purification. Resolve bodies/boats/cargo, current, forced movement, drowning/submersion and existing barriers through finite checks, with no automatic hydraulic damage or harvest. State release/ending and restoration behavior without recreating spilled water. Fishing's current44-card candidate remains pending exact review: rebase any water-access interface after its verdict, and do not treat it as approved here.

```json
{
  "id": "control-water",
  "name": "Control Water",
  "schools": [
    "Transmutation"
  ],
  "status": "blocked-pending-operational-review",
  "visibility": "public-source-review",
  "classAccess": {
    "Dragoon": {
      "rank": 4,
      "minimumClassLevel": 18,
      "school": "Transmutation",
      "baseRpCost": 7
    },
    "Druid": {
      "rank": 4,
      "minimumClassLevel": 7,
      "school": "Transmutation",
      "baseRpCost": 7
    },
    "Mage": {
      "rank": 4,
      "minimumClassLevel": 7,
      "school": "Transmutation",
      "baseRpCost": 7
    },
    "Monk": {
      "rank": 4,
      "minimumClassLevel": 18,
      "school": "Transmutation",
      "baseRpCost": 7
    },
    "Ranger": {
      "rank": 4,
      "minimumClassLevel": 13,
      "school": "Transmutation",
      "baseRpCost": 7
    },
    "Shaman": {
      "rank": 4,
      "minimumClassLevel": 10,
      "school": "Transmutation",
      "baseRpCost": 7
    },
    "Thief": {
      "rank": 4,
      "minimumClassLevel": 18,
      "school": "Transmutation",
      "baseRpCost": 7
    },
    "Tinker": {
      "rank": 4,
      "minimumClassLevel": 14,
      "school": "Transmutation",
      "baseRpCost": 7
    },
    "Wizard": {
      "rank": 4,
      "minimumClassLevel": 7,
      "school": "Transmutation",
      "baseRpCost": 7
    }
  },
  "operational": null,
  "additionalRpCost": 0,
  "source": {
    "catalogPath": "src/data/spells.js",
    "catalogSha256": "3358a2e1afcbc340dbafd92e45e39a7d2d0a24fed5c0719a3d233263ce530078",
    "catalogKey": "control-water",
    "original": {
      "name": "Control Water",
      "level": 4,
      "resonanceRank": 4,
      "school": "Transmutation",
      "schools": [
        "Transmutation"
      ],
      "placements": [
        {
          "name": "Control Water",
          "school": "Transmutation",
          "level": 4,
          "summary": "Raise, lower, or redirect water."
        }
      ],
      "classLevels": {
        "Dragoon": 4,
        "Druid": 4,
        "Mage": 4,
        "Monk": 4,
        "Ranger": 4,
        "Shaman": 4,
        "Thief": 4,
        "Tinker": 4,
        "Wizard": 4
      },
      "classRanks": {
        "Dragoon": 4,
        "Druid": 4,
        "Mage": 4,
        "Monk": 4,
        "Ranger": 4,
        "Shaman": 4,
        "Thief": 4,
        "Tinker": 4,
        "Wizard": 4
      },
      "classLearnLevels": {
        "Dragoon": 18,
        "Druid": 7,
        "Mage": 7,
        "Monk": 18,
        "Ranger": 13,
        "Shaman": 10,
        "Thief": 18,
        "Tinker": 14,
        "Wizard": 7
      },
      "classSchools": {
        "Dragoon": "Transmutation",
        "Druid": "Transmutation",
        "Mage": "Transmutation",
        "Monk": "Transmutation",
        "Ranger": "Transmutation",
        "Shaman": "Transmutation",
        "Thief": "Transmutation",
        "Tinker": "Transmutation",
        "Wizard": "Transmutation"
      },
      "castingTime": "Not specified in current rulebook",
      "range": "Not specified in current rulebook",
      "components": "Not specified in current rulebook",
      "duration": "Not specified in current rulebook",
      "description": "Raise, lower, or redirect water.",
      "alternateSummaries": [],
      "classes": [
        "Dragoon",
        "Druid",
        "Mage",
        "Monk",
        "Ranger",
        "Shaman",
        "Thief",
        "Tinker",
        "Wizard"
      ],
      "status": "canon",
      "source": "Player Rulebook — Spell Lists"
    },
    "corePath": "data/public/Decennium_Descent_Core_Systems_Data_v2_Known_Descent.json",
    "coreSha256": "50c3e9683349e93192191381ab6354ca7d675a24fcc9bb9b039c23e67fecca4f",
    "coreEntries": [
      {
        "index": 782,
        "original": {
          "school": "Transmutation",
          "level": 4,
          "name": "Control Water",
          "effect": "Raise, lower, or redirect water.",
          "source_paragraph": 9948,
          "casting_time": "1 action",
          "range": "60 feet",
          "duration": "Concentration, up to 1 minute",
          "components": "V, S, F",
          "resolution": "Automatic or opposed as described",
          "tags": [
            "Control"
          ],
          "rp_cost": 7
        }
      }
    ],
    "possibleHistoricalAliases": []
  },
  "reviewFlags": [
    "Core resolution requires an explicit operational interpretation",
    "Not selectable in this spell playtest packet until individual operational review"
  ]
}
```

</details>

## TU4-06 — Fabricate

**Original placements, unchanged**

- Transmutation rank 4: Transform raw materials into finished items.

- Universal rank 4: Transform raw materials into finished items.

**Proposed procedure**

Action; range 60 feet; V/S/M/F; Instantaneous. KEEP both actual rank-four Transmutation and Universal placements and genuine raw-material-to-finished-item transformation. NEW one cast resolves one preregistered, otherwise legal MUNDANE manufacturing work order whose entire required production consists of physically shaping/assembling real nonliving raw materials. All reserved consumed/nonconsumed material, maximum possible physical output, packaging and necessary bodies together must fit inside a ten-foot cube and weigh at most 500 pounds. Each participating lot, actual working tool/facility and output position must be perceived within sixty feet and line of effect at resolution, with space/support to receive the actual product. This explicitly replaces all ordinary active shaping/assembly hours of that eligible order with this one casting Action: no hidden requirement to perform the unchanged full hours afterward. Keep exact recipe/formula access, trade-level gate, source-selected ability, actual primary-tool proficiency or permitted untrained disadvantage, real required tools/auxiliaries/station, substitutions, complete material quantities, packaging, component roles and output profile. Fabricate supplies neither an unknown design nor an unavailable tool/facility/material. Its unpriced F alternative never substitutes for the actual substrate. It cannot complete a process requiring magical imbuement/attunement/encoding, creature creation, living growth, fermentation, incubation, chemical preparation or another independently stated natural/calendar wait. A separately specified wholly mundane carrier/body recipe may qualify, but that creates only its ordinary finished body; it does not perform a later Enchanting, Rune Carving, Scribing or magical-device operation. No arbitrary unsourced fraction of a complex recipe’s time is removed. For an eligible order reserve the exact lots at legal cast start; payment/countering precedes its manufacturing resolution. NEW a countered cast releases only those still-existing reserved materials which no actual event consumed, with spell costs still spent and no product/roll/XP. At successful spell resolution, recheck the entire real order and consume/process its exact inputs once, then make one actual recipe creation check and resolve the existing six crafting outcome bands, natural-1 Mishap, yield/structural option, catalyst retention and bounded failure recovery. The spell does not guarantee a successful product or higher equipment grade. A genuine Forge Dwarf quality benefit can apply to its otherwise eligible artisan order; its time multiplier cannot shorten the spell’s one Action. Eligible assistants, if the exact recipe allows them, must actually co-perform this one manufacturing operation with their own Action and tools/position; in initiative they can use ordinary Ready with real Reaction/release, not an invented simultaneous free Action. They provide only the existing +1 each within the actual cap, with no assistant XP. NEW no numerical trade XP is awarded for work replaced by Fabricate, including failure research; record the actual recipe success/quality in the same first-success history, so a later ordinary attempt cannot pretend that recipe was never successfully made. There are no fictitious work hours to satisfy a failure-XP requirement. This explicit learning tradeoff is proposed rather than attributed to the original source. Structural quality, output mass, waste, consumed material, returned catalyst and unused stock must reconcile physically; extra yield cannot duplicate a unique body or exceed material/packaging. A failed batch is not a fresh salvage pool for another cast. This is creation from raw input, not repair, flaw removal, grade improvement, salvage, item recharge or a way to reclassify a used/Broken/enhanced body as never-altered reserve. Finished mundane products persist after the spell; dispel cannot unmanufacture them. Actual permissions, finite buyers, quoted facility reservations and source price-reference rules remain, with no automatic sale, labor-value multiplication or new market.

**Explicit NEW choices:** NEW genuine instant completion of one bounded wholly mundane shaping/assembly recipe, native skill/quality/material procedure, no magically substituted trade XP, and explicit complex/magical/biological exclusions. Both class-school placements remain; ordinary work time is actually replaced, not merely renamed.

**Authored examples**

- TU4-06-A: A synthetic admitted mundane recipe has Q4, DC12, forty pounds of real stock and four eight-pound Standard outputs, with adequate packaging and otherwise valid tools/formula. A total of 12 makes four finished units during the one casting Action; eight pounds remain recorded as the actual recipe waste. No ordinary eight-hour work period is fabricated and no trade XP is awarded by this proposal.

- TU4-06-B: A source Enchanting order needs an admitted ordinary sword body plus actual magical process inputs and imbuement work. Fabricate cannot finish that magical order. A separate eligible mundane sword recipe can supply a real ordinary sword from its own complete raw materials, after which the actual Enchanting order still needs all of its own inputs, work and source permissions.

<details><summary>Original question and complete source/access record</summary>

Preserve BOTH Transmutation and Universal rank4 placements, Action/60ft/Instantaneous/V,S,M/F and transforming raw materials into finished items. Decide a finite genuine instant-transformation procedure and exactly which ordinary crafting work it replaces; do not erase the source by merely requiring the unchanged full work time. Preserve real material identity, quantity, purity, consumed components, separate catalysts, unavailable or no-resource inputs and exact output custody. Define volume/mass/item limits, recipe/knowledge/proficiency/tool/facility requirements, complex or magical products, check/quality/mishap and trade-XP behavior as explicit rulings. Sourcebook material promises and reviewed trade costs/output counts must be reconciled, not silently bypassed or globally rewritten. Distinguish fabrication from repair, improvement and salvage; no free quality, magical charges, missing ingredients, duplicate batches or repeat XP. Keep both class-school access records.

```json
{
  "id": "fabricate",
  "name": "Fabricate",
  "schools": [
    "Transmutation",
    "Universal"
  ],
  "status": "blocked-pending-operational-review",
  "visibility": "public-source-review",
  "classAccess": {
    "Bard": {
      "rank": 4,
      "minimumClassLevel": 10,
      "school": "Universal",
      "baseRpCost": 7
    },
    "Cleric": {
      "rank": 4,
      "minimumClassLevel": 7,
      "school": "Universal",
      "baseRpCost": 7
    },
    "Dragoon": {
      "rank": 4,
      "minimumClassLevel": 18,
      "school": "Transmutation",
      "baseRpCost": 7
    },
    "Druid": {
      "rank": 4,
      "minimumClassLevel": 7,
      "school": "Transmutation",
      "baseRpCost": 7
    },
    "Mage": {
      "rank": 4,
      "minimumClassLevel": 7,
      "school": "Transmutation",
      "baseRpCost": 7
    },
    "Monk": {
      "rank": 4,
      "minimumClassLevel": 18,
      "school": "Transmutation",
      "baseRpCost": 7
    },
    "Mirrorsage": {
      "rank": 4,
      "minimumClassLevel": 10,
      "school": "Universal",
      "baseRpCost": 7
    },
    "Ranger": {
      "rank": 4,
      "minimumClassLevel": 13,
      "school": "Transmutation",
      "baseRpCost": 7
    },
    "Shaman": {
      "rank": 4,
      "minimumClassLevel": 10,
      "school": "Transmutation",
      "baseRpCost": 7
    },
    "Thief": {
      "rank": 4,
      "minimumClassLevel": 18,
      "school": "Transmutation",
      "baseRpCost": 7
    },
    "Tinker": {
      "rank": 4,
      "minimumClassLevel": 14,
      "school": "Transmutation",
      "baseRpCost": 7
    },
    "Wizard": {
      "rank": 4,
      "minimumClassLevel": 7,
      "school": "Transmutation",
      "baseRpCost": 7
    },
    "Paladin": {
      "rank": 4,
      "minimumClassLevel": 13,
      "school": "Universal",
      "baseRpCost": 7
    }
  },
  "operational": null,
  "additionalRpCost": 0,
  "source": {
    "catalogPath": "src/data/spells.js",
    "catalogSha256": "3358a2e1afcbc340dbafd92e45e39a7d2d0a24fed5c0719a3d233263ce530078",
    "catalogKey": "fabricate",
    "original": {
      "name": "Fabricate",
      "level": 4,
      "resonanceRank": 4,
      "school": "Transmutation",
      "schools": [
        "Transmutation",
        "Universal"
      ],
      "placements": [
        {
          "name": "Fabricate",
          "school": "Transmutation",
          "level": 4,
          "summary": "Transform raw materials into finished items."
        },
        {
          "name": "Fabricate",
          "school": "Universal",
          "level": 4,
          "summary": "Transform raw materials into finished items."
        }
      ],
      "classLevels": {
        "Bard": 4,
        "Cleric": 4,
        "Dragoon": 4,
        "Druid": 4,
        "Mage": 4,
        "Monk": 4,
        "Mirrorsage": 4,
        "Ranger": 4,
        "Shaman": 4,
        "Thief": 4,
        "Tinker": 4,
        "Wizard": 4,
        "Paladin": 4
      },
      "classRanks": {
        "Bard": 4,
        "Cleric": 4,
        "Dragoon": 4,
        "Druid": 4,
        "Mage": 4,
        "Monk": 4,
        "Mirrorsage": 4,
        "Ranger": 4,
        "Shaman": 4,
        "Thief": 4,
        "Tinker": 4,
        "Wizard": 4,
        "Paladin": 4
      },
      "classLearnLevels": {
        "Bard": 10,
        "Cleric": 7,
        "Dragoon": 18,
        "Druid": 7,
        "Mage": 7,
        "Monk": 18,
        "Mirrorsage": 10,
        "Ranger": 13,
        "Shaman": 10,
        "Thief": 18,
        "Tinker": 14,
        "Wizard": 7,
        "Paladin": 13
      },
      "classSchools": {
        "Bard": "Universal",
        "Cleric": "Universal",
        "Dragoon": "Transmutation",
        "Druid": "Transmutation",
        "Mage": "Transmutation",
        "Monk": "Transmutation",
        "Mirrorsage": "Universal",
        "Ranger": "Transmutation",
        "Shaman": "Transmutation",
        "Thief": "Transmutation",
        "Tinker": "Transmutation",
        "Wizard": "Transmutation",
        "Paladin": "Universal"
      },
      "castingTime": "Not specified in current rulebook",
      "range": "Not specified in current rulebook",
      "components": "Not specified in current rulebook",
      "duration": "Not specified in current rulebook",
      "description": "Transform raw materials into finished items.",
      "alternateSummaries": [],
      "classes": [
        "Bard",
        "Cleric",
        "Dragoon",
        "Druid",
        "Mage",
        "Monk",
        "Mirrorsage",
        "Ranger",
        "Shaman",
        "Thief",
        "Tinker",
        "Wizard",
        "Paladin"
      ],
      "status": "canon",
      "source": "Player Rulebook — Spell Lists"
    },
    "corePath": "data/public/Decennium_Descent_Core_Systems_Data_v2_Known_Descent.json",
    "coreSha256": "50c3e9683349e93192191381ab6354ca7d675a24fcc9bb9b039c23e67fecca4f",
    "coreEntries": [
      {
        "index": 783,
        "original": {
          "school": "Transmutation",
          "level": 4,
          "name": "Fabricate",
          "effect": "Transform raw materials into finished items.",
          "source_paragraph": 9949,
          "casting_time": "1 action",
          "range": "60 feet",
          "duration": "Instantaneous",
          "components": "V, S, M/F",
          "resolution": "Automatic or opposed as described",
          "tags": [
            "Utility"
          ],
          "rp_cost": 7
        }
      },
      {
        "index": 886,
        "original": {
          "school": "Universal",
          "level": 4,
          "name": "Fabricate",
          "effect": "Transform raw materials into finished items.",
          "source_paragraph": 10077,
          "casting_time": "1 action",
          "range": "60 feet",
          "duration": "Instantaneous",
          "components": "V, S, M/F",
          "resolution": "Automatic or opposed as described",
          "tags": [
            "Utility"
          ],
          "rp_cost": 7
        }
      }
    ],
    "possibleHistoricalAliases": []
  },
  "reviewFlags": [
    "Core resolution requires an explicit operational interpretation",
    "Not selectable in this spell playtest packet until individual operational review"
  ]
}
```

</details>

## TU4-07 — Spell Theft

**Original placements, unchanged**

- Universal rank 4: Steal a spell effect from a creature (e.g. Fly, Haste).

**Proposed procedure**

Action; range 60 feet; V/S/F; Instantaneous transfer attempt. KEEP stealing an existing spell effect from a creature. NEW choose one other perceived creature and one individually perceived live ordinary-spell benefit on it, with line of effect. Its actual generating rank must be at most four. The recipient of the stolen benefit is only you. The eligible family is a whole target-local buff bundle consisting solely of flat AC/attack/check/save bonuses, an actual locomotion Speed/mode, resistance, Invisible or the specifically reviewed Haste package including its extra-Action and ending-cost clauses. All components of that selected bundle transfer together; do not cherry-pick the favorable half of Stoneflesh/Haste. Summoned bodies, areas/aura ownership, ongoing healing/damage streams, stored HP/RP/reserves/charges, linked damage sharing, transformations, hostile control, item enchantments, innate traits and class techniques are explicitly outside this NEW theft family. Source-specific fixed-self eligibility or an untransferable recipient condition can make a purported buff ineligible; it is not bypassed merely because its numbers fit the table. The current catalog has no exact Fly identity: the printed example remains preserved and unresolved, without importing an external spell. A genuinely existing eligible flight-granting ordinary source can qualify under the same actual predicates. The donor makes WIS against your spell DC, with an explicit option to waive if actually willing; success leaves the benefit unchanged. Failure transfers only if you are a legal recipient under every source/body/consent prerequisite, including informed acceptance of Haste’s ending Stun, and the selected parent/bundle still exists. All checks happen before an atomic transfer; ineligibility after paid commitment leaves the original benefit intact without refund or a hidden-property report. NEW retain the original creating caster, class, statistics, parent cast, original concentration owner/slot, original remaining deadline, suppression history and all already spent source opportunities. Theft itself needs no concentration and cannot steal concentration ownership. The old recipient loses the whole selected bundle and receives its actual recipient-ending consequences exactly once; the new recipient gets only the remaining state, not a new casting/application pulse, reset mark or renewed resource allowance. For Haste explicitly treat departure from the donor as termination of that donor’s accepted benefit and apply its ordinary one-round ending Stun; transfer does not erase that cost. The thief accepts a separate eventual ending cost when its received Haste benefit really ends. Original source loss can terminate the transferred benefit immediately, and it cannot be forced to remain by the thief. A transferred Haste extra-Action permission checks the thief’s already spent character/round extra-Action slot and the source’s actual originating-extra-Action restriction; it grants no fresh slot to either participant. A stolen flight benefit can remove actual support from the donor, invoking normal Falling. NEW a particular originating target-local bundle can be successfully stolen only once for its lifetime across all thieves; save/failure spends no transfer flag, but successful transfer does, permanently. No return-copy or second theft chain is permitted. Ending any separate theft record never returns or recreates the old benefit; all final ending is governed by the retained parent and received bundle.

**Explicit NEW choices:** NEW rank≤4 whole-buff eligibility family, donor WIS, self recipient, retained original parent/concentration owner, real donor ending consequences and one lifetime transfer per bundle. Haste’s accepted costs and spent Action history remain; unresolved Fly is not imported.

**Authored examples**

- TU4-07-A: A willing donor has a reviewed Haste with twenty elapsed seconds left. The thief is informed of its ending Stun and otherwise eligible. A successful transfer removes the donor’s benefit and applies its accepted ending cost once; the thief receives only the remaining twenty seconds under the original caster’s concentration, with no new extra-Action slot if already spent.

- TU4-07-B: The original caster ends concentration five seconds after the transfer. The received Haste ends then and imposes its actual ending cost on the thief. A second thief cannot transfer that same already-stolen bundle, and a same-named class feature never became an eligible ordinary spell merely through its title.

<details><summary>Original question and complete source/access record</summary>

Preserve stealing a spell effect from a creature, with Fly/Haste examples, Action/60ft/Instantaneous. Define actual eligible live parent/component, target/save or contest, recipient and whether stealing transfers ownership, recipient or maintained benefit. Resolve caster statistics, remaining duration, concentration, charges/reserves, application identity and source-specific restrictions. Preserve existing spent use/hard-control histories and any ending riders, including pending Haste's end penalty; a transfer cannot both replay application and avoid removal consequences without an explicit ruling. Distinguish a real spell from same-named class features/items, paid parent effects from child riders, and partial versus whole transfer. No free cast/repertoire gain, capacity increase, reset or copying while leaving the original intact.

```json
{
  "id": "spell-theft",
  "name": "Spell Theft",
  "schools": [
    "Universal"
  ],
  "status": "blocked-pending-operational-review",
  "visibility": "public-source-review",
  "classAccess": {
    "Bard": {
      "rank": 4,
      "minimumClassLevel": 10,
      "school": "Universal",
      "baseRpCost": 7
    },
    "Cleric": {
      "rank": 4,
      "minimumClassLevel": 7,
      "school": "Universal",
      "baseRpCost": 7
    },
    "Mage": {
      "rank": 4,
      "minimumClassLevel": 7,
      "school": "Universal",
      "baseRpCost": 7
    },
    "Mirrorsage": {
      "rank": 4,
      "minimumClassLevel": 10,
      "school": "Universal",
      "baseRpCost": 7
    },
    "Tinker": {
      "rank": 4,
      "minimumClassLevel": 14,
      "school": "Universal",
      "baseRpCost": 7
    },
    "Wizard": {
      "rank": 4,
      "minimumClassLevel": 7,
      "school": "Universal",
      "baseRpCost": 7
    },
    "Paladin": {
      "rank": 4,
      "minimumClassLevel": 13,
      "school": "Universal",
      "baseRpCost": 7
    }
  },
  "operational": null,
  "additionalRpCost": 0,
  "source": {
    "catalogPath": "src/data/spells.js",
    "catalogSha256": "3358a2e1afcbc340dbafd92e45e39a7d2d0a24fed5c0719a3d233263ce530078",
    "catalogKey": "spell-theft",
    "original": {
      "name": "Spell Theft",
      "level": 4,
      "resonanceRank": 4,
      "school": "Universal",
      "schools": [
        "Universal"
      ],
      "placements": [
        {
          "name": "Spell Theft",
          "school": "Universal",
          "level": 4,
          "summary": "Steal a spell effect from a creature (e.g. Fly, Haste)."
        }
      ],
      "classLevels": {
        "Bard": 4,
        "Cleric": 4,
        "Mage": 4,
        "Mirrorsage": 4,
        "Tinker": 4,
        "Wizard": 4,
        "Paladin": 4
      },
      "classRanks": {
        "Bard": 4,
        "Cleric": 4,
        "Mage": 4,
        "Mirrorsage": 4,
        "Tinker": 4,
        "Wizard": 4,
        "Paladin": 4
      },
      "classLearnLevels": {
        "Bard": 10,
        "Cleric": 7,
        "Mage": 7,
        "Mirrorsage": 10,
        "Tinker": 14,
        "Wizard": 7,
        "Paladin": 13
      },
      "classSchools": {
        "Bard": "Universal",
        "Cleric": "Universal",
        "Mage": "Universal",
        "Mirrorsage": "Universal",
        "Tinker": "Universal",
        "Wizard": "Universal",
        "Paladin": "Universal"
      },
      "castingTime": "Not specified in current rulebook",
      "range": "Not specified in current rulebook",
      "components": "Not specified in current rulebook",
      "duration": "Not specified in current rulebook",
      "description": "Steal a spell effect from a creature (e.g. Fly, Haste).",
      "alternateSummaries": [],
      "classes": [
        "Bard",
        "Cleric",
        "Mage",
        "Mirrorsage",
        "Tinker",
        "Wizard",
        "Paladin"
      ],
      "status": "canon",
      "source": "Player Rulebook — Spell Lists"
    },
    "corePath": "data/public/Decennium_Descent_Core_Systems_Data_v2_Known_Descent.json",
    "coreSha256": "50c3e9683349e93192191381ab6354ca7d675a24fcc9bb9b039c23e67fecca4f",
    "coreEntries": [
      {
        "index": 880,
        "original": {
          "school": "Universal",
          "level": 4,
          "name": "Spell Theft",
          "effect": "Steal a spell effect from a creature (e.g. Fly, Haste).",
          "source_paragraph": 10071,
          "casting_time": "1 action",
          "range": "60 feet",
          "duration": "Instantaneous",
          "components": "V, S, F",
          "resolution": "Automatic or opposed as described",
          "tags": [
            "Movement"
          ],
          "rp_cost": 7
        }
      }
    ],
    "possibleHistoricalAliases": []
  },
  "reviewFlags": [
    "Core resolution requires an explicit operational interpretation",
    "Not selectable in this spell playtest packet until individual operational review"
  ]
}
```

</details>

## TU4-08 — Time Skip

**Original placements, unchanged**

- Universal rank 4: Skip next round; reappear with surprise bonus action.

**Proposed procedure**

KEEP Bonus Action, V/S/F and skipping the next round before reappearing with a surprise Bonus Action. NEW self only; the original sixty-foot target metadata remains preserved as an unassigned alternative, not permission to remove another creature. Cast on your actual regular turn to arm one departure at your next future original regular START; you remain normally present for the rest of the casting turn. Outside initiative arm for +6 elapsed seconds, followed by a six-second absence. At the departure checkpoint, after actual start-ending expirations and before refresh/voluntary opportunities, recheck your continuing identity and any exact source preventing this temporal absence. If prevented or the armed effect is suppressed, it ends without departure or bonus; costs remain spent. A dead/ended creature cannot newly depart. NEW departure ends your current concentration and removes only your body and actually lawful noncreature gear from ordinary local occupancy/targeting for one original regular-turn interval, returning at the following original regular START or six elapsed seconds after outside departure. Carried creatures, a mount and grapplers stay with their own actual support/relationships. Record the exact departure anchor, original body/cargo identities and return marker; invent no destination plane or rewind. While absent you take no Actions, Bonus Actions, Reactions, voluntary movement, item interactions, commands or speech and gain no new observations of the scene. No fresh external attack/area/target selection can select the absent body at its old position. Already attached effects and their actual elapsed deadlines continue: periodic damage, saves, death/life recovery and explicitly automatic source events follow their own genuine predicates, but no new caster/companion operation or resource-generating opportunity is created by a virtual skipped turn. Suppressed/ineligible due events are lost, never banked. At the skipped regular marker do not refresh Reaction or action/movement budgets; advance actual duration/recharge clocks and process required life-state bookkeeping, without treating absence as rest or a new Time Loop iteration. The regular turn being skipped supplies no optional activity. Any genuine already committed consequence remains committed; departure does not refund, copy or rewind it. At the return marker the absence ends before ordinary return-turn processing. Try the actual departure space, legal squeeze, then the existing nearest-adjacent placement procedure in the same unobstructed region, minimum displacement/greatest prior overlap/fixed neutral tie order. No farther safe-space search, barrier passage or crushing damage is added. If no legal adjacent placement exists, record the same body at its actual return anchor with a placement conflict under the current body rules; this is a returned body, not extended invulnerability or a continued absence. Actual anchor cover/targetability and ongoing life consequences apply, while movement/physical actions require resolution of their genuine geometry. The return does not change items or create another body. NEW after mandatory regular-start processing, a living eligible returning caster receives one additional Bonus Action opportunity, usable immediately for one genuinely available Bonus-Action feature/spell with all ordinary costs, then lost if declined/ineligible. Its scope excludes Time Skip itself and abilities whose effect is to grant another action/turn; it creates no Surprise condition, advantage or special attack. The ordinary return-turn Bonus Action remains separately available, but no other round cap or companion command/offense allowance refreshes from this extra opportunity. Only one Time Skip return-bonus per character/numbered round; it cannot be copied or banked. If return is outside initiative, offer that one immediate Bonus Action under actual downtime legality; a hostile action first enters normal initiative without ambush actions before that process. Actual death during absence does not delete the body: return its same remains at the marker, with no bonus or restored resources. Qualifying removal/full suppression during absence forces early return using the same placement procedure and grants no bonus; removing the armed effect cancels departure. Recast cannot replace an armed/absent instance, and neither departure nor return supplies a new turn beyond the already scheduled return turn.

**Explicit NEW choices:** NEW self-only delayed departure, exactly one skipped original regular interval, real elapsed/state processing, same-anchor mandatory return and a specific additional immediate Bonus Action on legal return. The extra opportunity is retained as a real exception but grants no global Surprise, temporal reset or action-generation loop.

**Authored examples**

- TU4-08-A: The caster arms Time Skip with its round-3 Bonus Action, remains present through that turn, disappears at its round-4 regular START and skips that turn. At round-5 START it returns, processes normal due events and may spend the one explicit immediate return Bonus Action plus its ordinary turn resources. No round-4 Action or Reaction was saved for later.

- TU4-08-B: A poison installment attached before departure becomes due during the six-second absence and resolves under its actual source/life rules. An enemy cannot make a new ordinary attack against the empty anchor. If the poison kills the caster, the same remains return at the scheduled anchor; the spell supplies neither resurrection nor a bonus to a replacement identity.

<details><summary>Original question and complete source/access record</summary>

Preserve skipping the next round then reappearing with a surprise Bonus Action, Core Bonus Action/60ft/Instantaneous. Decide recipient versus self, disappearance/return checkpoints, skipped opportunities, legal return placement and what surprise Bonus Action permits relative to the ordinary one-BA budget. Specify already-committed actions, targeting/collision while absent, gear/cargo, concentration, real elapsed-time effects, regular markers and outside-initiative timing. Reappearance is not automatically Surprise against every foe, a fresh turn, a resource/reaction refresh or permission to bank a missed action. Compare current temporal limits without borrowing full Time Loop restoration, which remains unavailable. No new plane/topology or rewind of real consequences is authorized.

```json
{
  "id": "time-skip",
  "name": "Time Skip",
  "schools": [
    "Universal"
  ],
  "status": "blocked-pending-operational-review",
  "visibility": "public-source-review",
  "classAccess": {
    "Bard": {
      "rank": 4,
      "minimumClassLevel": 10,
      "school": "Universal",
      "baseRpCost": 7
    },
    "Cleric": {
      "rank": 4,
      "minimumClassLevel": 7,
      "school": "Universal",
      "baseRpCost": 7
    },
    "Mage": {
      "rank": 4,
      "minimumClassLevel": 7,
      "school": "Universal",
      "baseRpCost": 7
    },
    "Mirrorsage": {
      "rank": 4,
      "minimumClassLevel": 10,
      "school": "Universal",
      "baseRpCost": 7
    },
    "Tinker": {
      "rank": 4,
      "minimumClassLevel": 14,
      "school": "Universal",
      "baseRpCost": 7
    },
    "Wizard": {
      "rank": 4,
      "minimumClassLevel": 7,
      "school": "Universal",
      "baseRpCost": 7
    },
    "Paladin": {
      "rank": 4,
      "minimumClassLevel": 13,
      "school": "Universal",
      "baseRpCost": 7
    }
  },
  "operational": null,
  "additionalRpCost": 0,
  "source": {
    "catalogPath": "src/data/spells.js",
    "catalogSha256": "3358a2e1afcbc340dbafd92e45e39a7d2d0a24fed5c0719a3d233263ce530078",
    "catalogKey": "time-skip",
    "original": {
      "name": "Time Skip",
      "level": 4,
      "resonanceRank": 4,
      "school": "Universal",
      "schools": [
        "Universal"
      ],
      "placements": [
        {
          "name": "Time Skip",
          "school": "Universal",
          "level": 4,
          "summary": "Skip next round; reappear with surprise bonus action."
        }
      ],
      "classLevels": {
        "Bard": 4,
        "Cleric": 4,
        "Mage": 4,
        "Mirrorsage": 4,
        "Tinker": 4,
        "Wizard": 4,
        "Paladin": 4
      },
      "classRanks": {
        "Bard": 4,
        "Cleric": 4,
        "Mage": 4,
        "Mirrorsage": 4,
        "Tinker": 4,
        "Wizard": 4,
        "Paladin": 4
      },
      "classLearnLevels": {
        "Bard": 10,
        "Cleric": 7,
        "Mage": 7,
        "Mirrorsage": 10,
        "Tinker": 14,
        "Wizard": 7,
        "Paladin": 13
      },
      "classSchools": {
        "Bard": "Universal",
        "Cleric": "Universal",
        "Mage": "Universal",
        "Mirrorsage": "Universal",
        "Tinker": "Universal",
        "Wizard": "Universal",
        "Paladin": "Universal"
      },
      "castingTime": "Not specified in current rulebook",
      "range": "Not specified in current rulebook",
      "components": "Not specified in current rulebook",
      "duration": "Not specified in current rulebook",
      "description": "Skip next round; reappear with surprise bonus action.",
      "alternateSummaries": [],
      "classes": [
        "Bard",
        "Cleric",
        "Mage",
        "Mirrorsage",
        "Tinker",
        "Wizard",
        "Paladin"
      ],
      "status": "canon",
      "source": "Player Rulebook — Spell Lists"
    },
    "corePath": "data/public/Decennium_Descent_Core_Systems_Data_v2_Known_Descent.json",
    "coreSha256": "50c3e9683349e93192191381ab6354ca7d675a24fcc9bb9b039c23e67fecca4f",
    "coreEntries": [
      {
        "index": 881,
        "original": {
          "school": "Universal",
          "level": 4,
          "name": "Time Skip",
          "effect": "Skip next round; reappear with surprise bonus action.",
          "source_paragraph": 10072,
          "casting_time": "1 bonus action",
          "range": "60 feet",
          "duration": "Instantaneous",
          "components": "V, S, F",
          "resolution": "Automatic or opposed as described",
          "tags": [
            "Utility"
          ],
          "rp_cost": 7
        }
      }
    ],
    "possibleHistoricalAliases": []
  },
  "reviewFlags": [
    "Core resolution requires an explicit operational interpretation",
    "Not selectable in this spell playtest packet until individual operational review"
  ]
}
```

</details>

## TU4-09 — Arcane Reversal

**Original placements, unchanged**

- Universal rank 4: Reverse ongoing magical effect; e.g., Heal to Harm.

**Proposed procedure**

Action; range 60 feet; V/S/F. KEEP reversal of an ongoing magical effect, including the source’s Heal-to-Harm example. NEW select one individually perceived live target-local numerical component of an actual ordinary spell of generating rank at most four, with line of effect to its real recipient/anchor. Name exactly one admissible inverse from this finite table: (1) a future normal-HP healing output becomes necrotic damage of the same computed amount; (2) a future direct damage output becomes normal-HP healing of the same computed amount; (3) a flat AC, attack-roll, ability-check or saving-throw modifier changes sign with the same magnitude; (4) one typed resistance becomes vulnerability to that same type, or vice versa; (5) a stated double-Speed multiplier becomes half-Speed, or a half-Speed multiplier becomes double-Speed, using the actual native Speed arbitration. One selected component, including its linked repeated future opportunities, is modified; other parent components remain themselves. No inverse is supplied for immunity, hard control, conditions, transformation, Invisible/sensory information, temporary/form HP, HP maxima, RP/charges/items, physical work, creature creation, damage transfer, a portal or a completed instantaneous result. An actual spell-created companion’s heal/attack is eligible only if it is an explicitly defined output component of the ongoing spell parent with all its original command/offense budgets, rather than an independent creature feature inferred from a name. Make one casting-ability plus PB task check against DC 10 + twice the actual generating rank, Core degrees/natural shifts collapsed to success/failure. Success installs the chosen inversion; failure changes nothing. Unknown rank/component ineligibility can defeat a paid attempt without disclosing hidden facts. NEW reversal requires no concentration of its own and lasts only until the parent/component ends or sixty seconds from reversal, whichever is earlier. Original owner, statistics, concentration, targets, costs, eligibility, schedule, reserves and already spent opportunities remain. It does not reset a tick, create a new recipient or revive ended concentration. A specific parent/component may be successfully inverted only once in its lifetime across all casters; the consumed inversion flag survives suppression/removal, and the inversion cannot itself be selected for recursive inversion. Qualifying removal of the reversal restores only the surviving parent’s original future behavior, never past results or consumed opportunities. For output conversion, retain the original legal trigger/attack/save and source-funded amount. Compute the numerical amount through its source’s ordinary formula, actual limit and relevant source funding, before the original recipient’s healing-specific or damage-specific mitigation. An HP-healing reserve that would be debited only for actual restoration instead commits no more than this converted amount from its remaining reserve once; it cannot emit free damage while keeping that budget. Apply the final category’s actual target rules and defenses once: converted damage uses necrotic immunity/resistance/prevention/buffers and can cause ordinary Wounds/concentration; converted healing uses living-recipient eligibility, actual healing restrictions and maximum-HP cap, with no resurrection or excess reserve. No healing-only bonus/prohibition is copied into necrotic defenses, and no damage resistance is applied a second time to converted healing. Any source-specific fraction/funding explicitly based on an earlier real damage event still needs that genuinely qualifying earlier event; conversion cannot fund itself, create reciprocal drain healing, or use reflected/copied output as a fresh source occurrence. An attack-origin converted heal does not become two events or a free second attack; original hit/secondary riders retain only their expressly independent scope, while damage-dependent riders see no damage from the converted component. A save that originally halves the eligible source output retains that half before final-category processing; a success preventing the original output supplies nothing to convert. Resolve signed numeric and resistance/Speed changes through their actual stat rules, preserving separate source records; multiple reversals cannot add duplicate magnitude. The Healing tag grants no new heal and the Heal-to-Harm example never undoes HP already restored.

**Explicit NEW choices:** NEW finite five-pair inverse table, rank≤4 task gate, component-local remaining-duration cap, retained source budgets and one lifetime inversion flag. Actual future output changes category; completed healing, resources and unsupported inverse concepts are excluded explicitly.

**Authored examples**

- TU4-09-A: A synthetic eligible ongoing spell has one future eight-HP healing installment and at least eight units of actual healing reserve. After successful reversal, that genuine due opportunity commits eight reserve and emits one eight-necrotic packet; necrotic resistance reduces it to four before later prevention. It does not also heal, retain the eight reserve or create another installment.

- TU4-09-B: A separately eligible +2 AC spell component is successfully inverted to -2 for the lesser of its original remaining duration and sixty seconds. Ending the reversal restores the still-live +2 for only its original remaining time. The same component’s consumed inversion flag prevents another reversal chain and no prior attack result is recalculated.

<details><summary>Original question and complete source/access record</summary>

Preserve reversing an ongoing magical effect, with Heal-to-Harm as an example, Action/60ft/Instantaneous. Define a finite admissible effect/operation table and actual live source components, target/save or contest, ownership, duration/concentration and exact reversed result. Distinguish ongoing future healing from an already completed instantaneous heal; the example does not itself license retroactive HP edits. Explain interaction with heal prevention, damage types/defenses, pulses, temporary HP, hard control and resource outputs. Preserve source identity, spent charges and old deadlines; reversal must not manufacture stronger effects, refunded costs, new periodic ticks or an endless mutual reversal loop. Missing inverse definitions remain explicit rather than arbitrary Director improvisation.

```json
{
  "id": "arcane-reversal",
  "name": "Arcane Reversal",
  "schools": [
    "Universal"
  ],
  "status": "blocked-pending-operational-review",
  "visibility": "public-source-review",
  "classAccess": {
    "Bard": {
      "rank": 4,
      "minimumClassLevel": 10,
      "school": "Universal",
      "baseRpCost": 7
    },
    "Cleric": {
      "rank": 4,
      "minimumClassLevel": 7,
      "school": "Universal",
      "baseRpCost": 7
    },
    "Mage": {
      "rank": 4,
      "minimumClassLevel": 7,
      "school": "Universal",
      "baseRpCost": 7
    },
    "Mirrorsage": {
      "rank": 4,
      "minimumClassLevel": 10,
      "school": "Universal",
      "baseRpCost": 7
    },
    "Tinker": {
      "rank": 4,
      "minimumClassLevel": 14,
      "school": "Universal",
      "baseRpCost": 7
    },
    "Wizard": {
      "rank": 4,
      "minimumClassLevel": 7,
      "school": "Universal",
      "baseRpCost": 7
    },
    "Paladin": {
      "rank": 4,
      "minimumClassLevel": 13,
      "school": "Universal",
      "baseRpCost": 7
    }
  },
  "operational": null,
  "additionalRpCost": 0,
  "source": {
    "catalogPath": "src/data/spells.js",
    "catalogSha256": "3358a2e1afcbc340dbafd92e45e39a7d2d0a24fed5c0719a3d233263ce530078",
    "catalogKey": "arcane-reversal",
    "original": {
      "name": "Arcane Reversal",
      "level": 4,
      "resonanceRank": 4,
      "school": "Universal",
      "schools": [
        "Universal"
      ],
      "placements": [
        {
          "name": "Arcane Reversal",
          "school": "Universal",
          "level": 4,
          "summary": "Reverse ongoing magical effect; e.g., Heal to Harm."
        }
      ],
      "classLevels": {
        "Bard": 4,
        "Cleric": 4,
        "Mage": 4,
        "Mirrorsage": 4,
        "Tinker": 4,
        "Wizard": 4,
        "Paladin": 4
      },
      "classRanks": {
        "Bard": 4,
        "Cleric": 4,
        "Mage": 4,
        "Mirrorsage": 4,
        "Tinker": 4,
        "Wizard": 4,
        "Paladin": 4
      },
      "classLearnLevels": {
        "Bard": 10,
        "Cleric": 7,
        "Mage": 7,
        "Mirrorsage": 10,
        "Tinker": 14,
        "Wizard": 7,
        "Paladin": 13
      },
      "classSchools": {
        "Bard": "Universal",
        "Cleric": "Universal",
        "Mage": "Universal",
        "Mirrorsage": "Universal",
        "Tinker": "Universal",
        "Wizard": "Universal",
        "Paladin": "Universal"
      },
      "castingTime": "Not specified in current rulebook",
      "range": "Not specified in current rulebook",
      "components": "Not specified in current rulebook",
      "duration": "Not specified in current rulebook",
      "description": "Reverse ongoing magical effect; e.g., Heal to Harm.",
      "alternateSummaries": [],
      "classes": [
        "Bard",
        "Cleric",
        "Mage",
        "Mirrorsage",
        "Tinker",
        "Wizard",
        "Paladin"
      ],
      "status": "canon",
      "source": "Player Rulebook — Spell Lists"
    },
    "corePath": "data/public/Decennium_Descent_Core_Systems_Data_v2_Known_Descent.json",
    "coreSha256": "50c3e9683349e93192191381ab6354ca7d675a24fcc9bb9b039c23e67fecca4f",
    "coreEntries": [
      {
        "index": 882,
        "original": {
          "school": "Universal",
          "level": 4,
          "name": "Arcane Reversal",
          "effect": "Reverse ongoing magical effect; e.g., Heal to Harm.",
          "source_paragraph": 10073,
          "casting_time": "1 action",
          "range": "60 feet",
          "duration": "Instantaneous",
          "components": "V, S, F",
          "resolution": "Automatic or opposed as described",
          "tags": [
            "Healing"
          ],
          "rp_cost": 7
        }
      }
    ],
    "possibleHistoricalAliases": []
  },
  "reviewFlags": [
    "Core resolution requires an explicit operational interpretation",
    "Not selectable in this spell playtest packet until individual operational review"
  ]
}
```

</details>

## TU4-10 — Mystic Gate

**Original placements, unchanged**

- Universal rank 4: Summon a two-way portal for 1 minute between two points.

**Proposed procedure**

Action; range 60 feet; V/S/F; KEEP a two-way portal for one minute between two points. NEW create two fixed vertical five-foot-wide, eight-foot-high apertures, each at a perceived open supported location within sixty feet of you, with originating line of effect and no more than sixty feet between them. This card is local to the same already established plane; the preserved Planar tag creates no new location or cosmological connection. Both apertures and enough real arrival space must exist at creation. Add concentration up to sixty seconds. Endpoints stay at their actual world positions, not on a moving vehicle or transferable item, and provide no physical wall, floor or support. A creature actually fitting under normal anatomy/squeezing may voluntarily cross either direction by spending five feet of its legal movement, with actual terrain adjustments. Use the whole physical body and actually carried legal belongings, including genuinely carried creatures only within the carrier’s real anatomy/pound/Load capacity and with room for the entire group. NEW an independently legal driven vehicle/puller/passenger assembly can cross only as one whole transport group if every part fits the aperture and complete arrival space; its real driver/puller Actions, movement budget, capacity and coupling remain required. No portal-created transport permission or extra drive is supplied. Loose objects cross only while actually carried or handled as part of such a moving creature/group; free projectiles, fluids, falling mass, unattended conveyor flow, areas and attacks cannot independently activate it. Resolve one crossing atomically at a time in actual initiative/committed-event order, with fixed neutral source order for genuine simultaneous ties. Both directions share the same physically occupied departure/arrival capacity; opposing groups cannot overlap or pass through each other. There is no numerical lifetime passenger limit beyond the real sixty-second deadline, movement budgets and geometry. At each crossing recheck the exact body/group, endpoint wards, actual support and unoccupied exit space immediately adjacent to the destination aperture. Use the nearest legal fitting adjacent arrival with fixed neutral tie order, never a tactical remote square or search through a barrier. A blocked transit leaves the entire group at its source, with its already committed approach/attempted movement spent; no splitting, crushing or disappearing cargo. Ordinary approach can provoke; the teleport crossing itself cannot. The portals are opaque to sight/sound and provide no attack, spell or remote-sense line through them, no free view of the far side and no momentum weapon. Successful groups retain their real physical velocity only insofar as normal local movement already permits it; the crossing adds no impact damage or extra distance. Closure/suppression is processed before any later crossing, while an already resolving legal crossing finishes atomically before that closure. No body stays half transported. Suppression disables transit without pausing the original deadline or replaying missed arrivals. Concentration loss, expiry or qualifying removal closes both apertures; actual travelers and cargo already across stay there. This identity grants none of Faction Portal’s reputation/HQ permissions, and the shorter single-transit Arcane Portal retains its separate source.

**Explicit NEW choices:** NEW paired 5×8-foot static local apertures, both sixty-foot range/separation limits, concentration minute, actual movement and whole transport-group crossing, opaque transport-only interface and real throughput rather than a single-use cap.

**Authored examples**

- TU4-10-A: Two legal endpoints are forty feet apart. A traveler spends five feet to cross east, then later another five feet to cross back while the same gate remains active and both destinations fit. Each crossing moves the one real traveler and their actual cargo once, with no additional Action or renewed movement budget.

- TU4-10-B: A coupled wagon/puller group cannot fit the actual five-foot aperture or complete exit footprint. The portal does not shrink, detach or divide it. A fitting pedestrian can still use a later genuine open crossing, but a thrown parcel and flowing water do not independently pass.

<details><summary>Original question and complete source/access record</summary>

Preserve a two-way portal for one minute between two points, Action/60ft. Define both endpoints, finite size/orientation, destination knowledge, range between and from caster, support, occupancy, entry/exit and throughput. Resolve creatures/objects/cargo, projectiles, sight/sound/line of effect, momentum and closure while crossing; opening a portal does not duplicate an actor or cargo. Decide concentration and static versus movable endpoints explicitly. Compare Faction Portal and pending Arcane Portal without inheriting faction access or unlimited endpoints. Existing known locations only: the Core Planar tag does not authorize inventing planes or their topology, and cosmology remains post-push.

```json
{
  "id": "mystic-gate",
  "name": "Mystic Gate",
  "schools": [
    "Universal"
  ],
  "status": "blocked-pending-operational-review",
  "visibility": "public-source-review",
  "classAccess": {
    "Bard": {
      "rank": 4,
      "minimumClassLevel": 10,
      "school": "Universal",
      "baseRpCost": 7
    },
    "Cleric": {
      "rank": 4,
      "minimumClassLevel": 7,
      "school": "Universal",
      "baseRpCost": 7
    },
    "Mage": {
      "rank": 4,
      "minimumClassLevel": 7,
      "school": "Universal",
      "baseRpCost": 7
    },
    "Mirrorsage": {
      "rank": 4,
      "minimumClassLevel": 10,
      "school": "Universal",
      "baseRpCost": 7
    },
    "Tinker": {
      "rank": 4,
      "minimumClassLevel": 14,
      "school": "Universal",
      "baseRpCost": 7
    },
    "Wizard": {
      "rank": 4,
      "minimumClassLevel": 7,
      "school": "Universal",
      "baseRpCost": 7
    },
    "Paladin": {
      "rank": 4,
      "minimumClassLevel": 13,
      "school": "Universal",
      "baseRpCost": 7
    }
  },
  "operational": null,
  "additionalRpCost": 0,
  "source": {
    "catalogPath": "src/data/spells.js",
    "catalogSha256": "3358a2e1afcbc340dbafd92e45e39a7d2d0a24fed5c0719a3d233263ce530078",
    "catalogKey": "mystic-gate",
    "original": {
      "name": "Mystic Gate",
      "level": 4,
      "resonanceRank": 4,
      "school": "Universal",
      "schools": [
        "Universal"
      ],
      "placements": [
        {
          "name": "Mystic Gate",
          "school": "Universal",
          "level": 4,
          "summary": "Summon a two-way portal for 1 minute between two points."
        }
      ],
      "classLevels": {
        "Bard": 4,
        "Cleric": 4,
        "Mage": 4,
        "Mirrorsage": 4,
        "Tinker": 4,
        "Wizard": 4,
        "Paladin": 4
      },
      "classRanks": {
        "Bard": 4,
        "Cleric": 4,
        "Mage": 4,
        "Mirrorsage": 4,
        "Tinker": 4,
        "Wizard": 4,
        "Paladin": 4
      },
      "classLearnLevels": {
        "Bard": 10,
        "Cleric": 7,
        "Mage": 7,
        "Mirrorsage": 10,
        "Tinker": 14,
        "Wizard": 7,
        "Paladin": 13
      },
      "classSchools": {
        "Bard": "Universal",
        "Cleric": "Universal",
        "Mage": "Universal",
        "Mirrorsage": "Universal",
        "Tinker": "Universal",
        "Wizard": "Universal",
        "Paladin": "Universal"
      },
      "castingTime": "Not specified in current rulebook",
      "range": "Not specified in current rulebook",
      "components": "Not specified in current rulebook",
      "duration": "Not specified in current rulebook",
      "description": "Summon a two-way portal for 1 minute between two points.",
      "alternateSummaries": [],
      "classes": [
        "Bard",
        "Cleric",
        "Mage",
        "Mirrorsage",
        "Tinker",
        "Wizard",
        "Paladin"
      ],
      "status": "canon",
      "source": "Player Rulebook — Spell Lists"
    },
    "corePath": "data/public/Decennium_Descent_Core_Systems_Data_v2_Known_Descent.json",
    "coreSha256": "50c3e9683349e93192191381ab6354ca7d675a24fcc9bb9b039c23e67fecca4f",
    "coreEntries": [
      {
        "index": 883,
        "original": {
          "school": "Universal",
          "level": 4,
          "name": "Mystic Gate",
          "effect": "Summon a two-way portal for 1 minute between two points.",
          "source_paragraph": 10074,
          "casting_time": "1 action",
          "range": "60 feet",
          "duration": "1 minute",
          "components": "V, S, F",
          "resolution": "Automatic or opposed as described",
          "tags": [
            "Summoning",
            "Planar"
          ],
          "rp_cost": 7
        }
      }
    ],
    "possibleHistoricalAliases": []
  },
  "reviewFlags": [
    "Core resolution requires an explicit operational interpretation",
    "Not selectable in this spell playtest packet until individual operational review"
  ]
}
```

</details>

## TU4-11 — Dimension Door

**Original placements, unchanged**

- Universal rank 4: Teleport up to 500 feet.

**Proposed procedure**

Action; range 500 feet; V/S/F; Instantaneous. KEEP the Universal identity’s up-to-five-hundred-foot teleport. NEW self and actually lawful worn/held/carried noncreature belongings only. Declare one exact destination footprint/orientation on the same established plane, no more than five hundred feet from the caster. You may designate it by current perception, accurate personal knowledge, or a precise measured direction-and-distance displacement from your current known anchor; this last option expressly differs from the Conjuration Dimensional Door proposal’s known-location gate. No originating sight, line of effect or traversable path to the destination is required by this specific teleport. Designation supplies no new sensory information or guarantee that the chosen space is free. A vague request for a safe room, hidden treasure, an unknown person’s location or the other side of an unmeasured wall is insufficient. At resolution the whole actual body and gear must fit unoccupied space with all actual transport prohibitions satisfied. Unsupported open space is allowed, but starts ordinary Falling immediately if no independent support/flight exists. No passenger, carried creature, mount or unwilling grappled victim travels as gear; retained and released relationships use their actual rules at the old/new positions. A corpse-object or container can accompany only as an actual legal noncreature belonging within both real carrying limits, with the same full contents/weight and history. If hidden/new occupancy, solid matter, a ward or custody failure makes the destination illegal after commitment, nothing moves; paid costs remain spent, with no damage, remote diagnostic, split body or automatic substitute square. Teleportation spends no Speed and provokes no ordinary opportunity attack, but grants no invisibility, sound suppression, attack, return journey, rest, concentration reset or renewed class resources. Current conditions persist unless their actual source relation ends. The separate Dimension Door and Dimensional Door source records, spell names, schools and class access remain distinct; this proposal does not approve or rewrite the other.

**Explicit NEW choices:** NEW self-only atomic payload, exact measured-vector or known/perceived destination without originating path, unsupported arrival/Falling and paid-failure handling. The distinct Conjuration name/source remains preserved rather than silently merged.

**Authored examples**

- TU4-11-A: From a genuinely known anchor the caster declares exactly three hundred feet east at the same elevation. The destination happens to be a legal empty supported space. The spell moves the same caster and actual carried gear once, despite the lack of a traversed path, without granting a view of intermediate rooms.

- TU4-11-B: The precisely declared destination is actually solid rock or occupied at resolution. The paid spell moves nothing and supplies no damage or automatic nearby safe arrival. A separately legal unsupported open-air destination would instead succeed and use ordinary Falling, not this blocked-destination outcome.

<details><summary>Original question and complete source/access record</summary>

Preserve Universal teleportation up to500ft, Action/500ft/Instantaneous. Define who travels, destination knowledge/perception, actual legal space/support, carried objects and willingness/contested cases. Keep this identity distinct from Conjuration Dimensional Door, whose wording specifies a known location; decide any harmonization explicitly while retaining both originals and class access. Account for existing transport blocks, failed destination, falling, current clocks and real custody. No familiar-game companion passenger, bonus spell damage, unseen map knowledge, interplanar connection or recreated inventory is assumed.

```json
{
  "id": "dimension-door",
  "name": "Dimension Door",
  "schools": [
    "Universal"
  ],
  "status": "blocked-pending-operational-review",
  "visibility": "public-source-review",
  "classAccess": {
    "Bard": {
      "rank": 4,
      "minimumClassLevel": 10,
      "school": "Universal",
      "baseRpCost": 7
    },
    "Cleric": {
      "rank": 4,
      "minimumClassLevel": 7,
      "school": "Universal",
      "baseRpCost": 7
    },
    "Mage": {
      "rank": 4,
      "minimumClassLevel": 7,
      "school": "Universal",
      "baseRpCost": 7
    },
    "Mirrorsage": {
      "rank": 4,
      "minimumClassLevel": 10,
      "school": "Universal",
      "baseRpCost": 7
    },
    "Tinker": {
      "rank": 4,
      "minimumClassLevel": 14,
      "school": "Universal",
      "baseRpCost": 7
    },
    "Wizard": {
      "rank": 4,
      "minimumClassLevel": 7,
      "school": "Universal",
      "baseRpCost": 7
    },
    "Paladin": {
      "rank": 4,
      "minimumClassLevel": 13,
      "school": "Universal",
      "baseRpCost": 7
    }
  },
  "operational": null,
  "additionalRpCost": 0,
  "source": {
    "catalogPath": "src/data/spells.js",
    "catalogSha256": "3358a2e1afcbc340dbafd92e45e39a7d2d0a24fed5c0719a3d233263ce530078",
    "catalogKey": "dimension-door",
    "original": {
      "name": "Dimension Door",
      "level": 4,
      "resonanceRank": 4,
      "school": "Universal",
      "schools": [
        "Universal"
      ],
      "placements": [
        {
          "name": "Dimension Door",
          "school": "Universal",
          "level": 4,
          "summary": "Teleport up to 500 feet."
        }
      ],
      "classLevels": {
        "Bard": 4,
        "Cleric": 4,
        "Mage": 4,
        "Mirrorsage": 4,
        "Tinker": 4,
        "Wizard": 4,
        "Paladin": 4
      },
      "classRanks": {
        "Bard": 4,
        "Cleric": 4,
        "Mage": 4,
        "Mirrorsage": 4,
        "Tinker": 4,
        "Wizard": 4,
        "Paladin": 4
      },
      "classLearnLevels": {
        "Bard": 10,
        "Cleric": 7,
        "Mage": 7,
        "Mirrorsage": 10,
        "Tinker": 14,
        "Wizard": 7,
        "Paladin": 13
      },
      "classSchools": {
        "Bard": "Universal",
        "Cleric": "Universal",
        "Mage": "Universal",
        "Mirrorsage": "Universal",
        "Tinker": "Universal",
        "Wizard": "Universal",
        "Paladin": "Universal"
      },
      "castingTime": "Not specified in current rulebook",
      "range": "Not specified in current rulebook",
      "components": "Not specified in current rulebook",
      "duration": "Not specified in current rulebook",
      "description": "Teleport up to 500 feet.",
      "alternateSummaries": [],
      "classes": [
        "Bard",
        "Cleric",
        "Mage",
        "Mirrorsage",
        "Tinker",
        "Wizard",
        "Paladin"
      ],
      "status": "canon",
      "source": "Player Rulebook — Spell Lists"
    },
    "corePath": "data/public/Decennium_Descent_Core_Systems_Data_v2_Known_Descent.json",
    "coreSha256": "50c3e9683349e93192191381ab6354ca7d675a24fcc9bb9b039c23e67fecca4f",
    "coreEntries": [
      {
        "index": 884,
        "original": {
          "school": "Universal",
          "level": 4,
          "name": "Dimension Door",
          "effect": "Teleport up to 500 feet.",
          "source_paragraph": 10075,
          "casting_time": "1 action",
          "range": "500 feet",
          "duration": "Instantaneous",
          "components": "V, S, F",
          "resolution": "Automatic or opposed as described",
          "tags": [
            "Movement"
          ],
          "rp_cost": 7
        }
      }
    ],
    "possibleHistoricalAliases": []
  },
  "reviewFlags": [
    "Core resolution requires an explicit operational interpretation",
    "Not selectable in this spell playtest packet until individual operational review"
  ]
}
```

</details>

## TU4-12 — Arcane Eye

**Original placements, unchanged**

- Universal rank 4: Create invisible eye that moves and sees for you.

**Proposed procedure**

Action; range 60 feet; V/S/F. KEEP one invisible eye that moves and sees for you. NEW create a nonphysical one-inch-diameter magical sensor in a perceived unoccupied point with originating line of effect; replace Instantaneous with concentration up to one hour. It has no creature identity, HP, weight, inventory, attack, hands, collision, physical support or autonomous intelligence. Its movement is magically sustained in three dimensions and can remain at a fixed open point without physical hover anatomy. Creation supplies no extra move. On a later caster Action move it up to thirty feet along one continuously open path; solid matter blocks its path despite being nonphysical, and a real aperture must be at least one inch across throughout the route. It cannot open doors, carry/touch objects or pass through a keyhole smaller than that. No independent turn, Bonus Action command or companion offensive allowance is created. At all times the sensor must remain on the caster’s same established plane and within five hundred feet. If the caster moves beyond that tether, its feed and commanded movement are suppressed while the clock runs; returning into range restores only present information. A control Action can move it only while the whole path stays within that tether. No continuing originating line-of-effect tether is required, so it can round a real open corner; actual information/remote-sensing wards apply only according to their own source scope, not automatically to every Universal effect as if it were Divination. Sight is ordinary all-direction vision from its current point using real local illumination, distances, cover and visual obscurity. It grants no darkvision, true sight, wall sight, hearing, scent, language translation, automatic secret search or authentication. Your normal local senses continue; your actual Blindness suppresses this remote Sight channel under the existing sensory interface. You may spend a genuine Search Action observing the current feed with an actually applicable perception procedure, but that Action does not also move the eye. The invisible sensor can be perceived only through an actual effect/sense that can reveal that kind of invisible magical sensor; a creature-only sight power does not reveal a noncreature by default. Detecting some magic is not automatic identification or permission to target it. There is no illusion-disbelief check that destroys the real sensor. No physical attack damages it; an actual effect permitted to end/suppress this rank-four ongoing spell can do so when its own targeting prerequisites are met. If its current point becomes solid or a closing barrier intersects it, the sensor ends, rather than shunting through an unseen wall. Suppression supplies no backlog or off-screen autonomous travel; expiry/removal/concentration loss ends the eye. Received visual information can inform decisions but never supplies a new spell origin, another power’s originating line of effect, remote touch or enlarged casting range. No recording object or replay is created.

**Explicit NEW choices:** NEW one-inch nonphysical sensor, hour concentration, later Action/30-foot path movement, 500-foot same-plane tether and actual visual/sensor detection rules. It can round open corners but cannot pass solid matter or supply a remote spell origin.

**Authored examples**

- TU4-12-A: After creation, the caster spends an Action to move the eye thirty feet along an open corridor and around a corner through a two-inch gap. It sees only what ordinary local lighting reveals from the new point. The caster receives no sound and cannot cast from the eye’s position.

- TU4-12-B: A later door closes across the sensor’s actual point, ending it rather than moving it through the door. A sensor merely behind the closed door can remain if its point is open and tether valid, but moving through that solid door is illegal; detection of a nearby magical aura alone does not identify it.

<details><summary>Original question and complete source/access record</summary>

Preserve a created invisible eye that moves and sees for the caster, Action/60ft/Instantaneous. Define size/physical status, speed/control/activation, finite lifetime/concentration, sensor range/separation and caster sensory interface. Resolve normal vision/darkness, doors/apertures, line of effect, detection/disbelief, actual information wards and inability to occupy solid matter. Compare Clairvoyance and sight spells without granting omniscience, an attacking creature, a spell origin, touch/cargo delivery, new action budget or arbitrary wall passage. Preserve independent source identity, damage/dispel if physically applicable, suppression and finite ending.

```json
{
  "id": "arcane-eye",
  "name": "Arcane Eye",
  "schools": [
    "Universal"
  ],
  "status": "blocked-pending-operational-review",
  "visibility": "public-source-review",
  "classAccess": {
    "Bard": {
      "rank": 4,
      "minimumClassLevel": 10,
      "school": "Universal",
      "baseRpCost": 7
    },
    "Cleric": {
      "rank": 4,
      "minimumClassLevel": 7,
      "school": "Universal",
      "baseRpCost": 7
    },
    "Mage": {
      "rank": 4,
      "minimumClassLevel": 7,
      "school": "Universal",
      "baseRpCost": 7
    },
    "Mirrorsage": {
      "rank": 4,
      "minimumClassLevel": 10,
      "school": "Universal",
      "baseRpCost": 7
    },
    "Tinker": {
      "rank": 4,
      "minimumClassLevel": 14,
      "school": "Universal",
      "baseRpCost": 7
    },
    "Wizard": {
      "rank": 4,
      "minimumClassLevel": 7,
      "school": "Universal",
      "baseRpCost": 7
    },
    "Paladin": {
      "rank": 4,
      "minimumClassLevel": 13,
      "school": "Universal",
      "baseRpCost": 7
    }
  },
  "operational": null,
  "additionalRpCost": 0,
  "source": {
    "catalogPath": "src/data/spells.js",
    "catalogSha256": "3358a2e1afcbc340dbafd92e45e39a7d2d0a24fed5c0719a3d233263ce530078",
    "catalogKey": "arcane-eye",
    "original": {
      "name": "Arcane Eye",
      "level": 4,
      "resonanceRank": 4,
      "school": "Universal",
      "schools": [
        "Universal"
      ],
      "placements": [
        {
          "name": "Arcane Eye",
          "school": "Universal",
          "level": 4,
          "summary": "Create invisible eye that moves and sees for you."
        }
      ],
      "classLevels": {
        "Bard": 4,
        "Cleric": 4,
        "Mage": 4,
        "Mirrorsage": 4,
        "Tinker": 4,
        "Wizard": 4,
        "Paladin": 4
      },
      "classRanks": {
        "Bard": 4,
        "Cleric": 4,
        "Mage": 4,
        "Mirrorsage": 4,
        "Tinker": 4,
        "Wizard": 4,
        "Paladin": 4
      },
      "classLearnLevels": {
        "Bard": 10,
        "Cleric": 7,
        "Mage": 7,
        "Mirrorsage": 10,
        "Tinker": 14,
        "Wizard": 7,
        "Paladin": 13
      },
      "classSchools": {
        "Bard": "Universal",
        "Cleric": "Universal",
        "Mage": "Universal",
        "Mirrorsage": "Universal",
        "Tinker": "Universal",
        "Wizard": "Universal",
        "Paladin": "Universal"
      },
      "castingTime": "Not specified in current rulebook",
      "range": "Not specified in current rulebook",
      "components": "Not specified in current rulebook",
      "duration": "Not specified in current rulebook",
      "description": "Create invisible eye that moves and sees for you.",
      "alternateSummaries": [],
      "classes": [
        "Bard",
        "Cleric",
        "Mage",
        "Mirrorsage",
        "Tinker",
        "Wizard",
        "Paladin"
      ],
      "status": "canon",
      "source": "Player Rulebook — Spell Lists"
    },
    "corePath": "data/public/Decennium_Descent_Core_Systems_Data_v2_Known_Descent.json",
    "coreSha256": "50c3e9683349e93192191381ab6354ca7d675a24fcc9bb9b039c23e67fecca4f",
    "coreEntries": [
      {
        "index": 885,
        "original": {
          "school": "Universal",
          "level": 4,
          "name": "Arcane Eye",
          "effect": "Create invisible eye that moves and sees for you.",
          "source_paragraph": 10076,
          "casting_time": "1 action",
          "range": "60 feet",
          "duration": "Instantaneous",
          "components": "V, S, F",
          "resolution": "Automatic or opposed as described",
          "tags": [
            "Utility"
          ],
          "rp_cost": 7
        }
      }
    ],
    "possibleHistoricalAliases": []
  },
  "reviewFlags": [
    "Core resolution requires an explicit operational interpretation",
    "Not selectable in this spell playtest packet until individual operational review"
  ]
}
```

</details>
