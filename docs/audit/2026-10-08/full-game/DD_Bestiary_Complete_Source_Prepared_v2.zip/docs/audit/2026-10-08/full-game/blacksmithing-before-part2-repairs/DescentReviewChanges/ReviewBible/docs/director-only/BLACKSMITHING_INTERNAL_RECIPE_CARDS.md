# Blacksmithing internal recipe cards

**Draft awaiting exact GPT review.** 43 source formulas.

Every card uses the complete shared Blacksmithing guide: real predeclared base bodies, exact ingredients, grade/quality separation, damage preservation, lawful wearing, source access and finite repair. Source originals are preserved in the paired JSON. These are provisional authored mechanics, not runtime or human balance approval.

## recipe-42 — Refined Gale Sword

**Source:** public; Blacksmithing level 3; tier 2; Common; crafting DC 12; 4 hours / 4 active hours; Standard quantity 1. Source Standard batch reference 92 gp.

**Preserved effect:** Creates a durable sword with +1 to attack and damage rolls.

**Operational effect:** One actual sword base becomes an intact magical nonartifact output. With this weapon's actual attacks, use recipe +1 in the item-accuracy family and add +1 once to ordinary weapon-hit damage. Legal thrown/off-hand attacks retain these benefits; carrying it does not. Unsuppressed ordinary B/P/S counts magical. No elemental damage rider is granted by its title, ingredient or tag. Broken stops positive functions; suppression stops recipe magic only. The complete base, quality, repair and value rules apply.

**Legal base models:** Shortsword, Longsword, Greatsword, Rapier, Scimitar. Choose one model, size and actual legal equipment grade for the whole batch before work.

**Physical reserve:** 1 complete legal mundane bases, ordered before work. Transform the first resolved N; keep original inventory identity, actual grade/material/damage and source access. All source ingredients below are additional inputs; none supplies a free body.

| Base model | Ordinary Standard price | Weight | Ordinary max HP | Actual base combat profile | Finished unit reference with this ordinary base |
|---|---:|---:|---:|---|---:|
| Shortsword | 10 gp | 2 lb | 5 | 1d6 piercing; Finesse, light | 102 gp |
| Longsword | 15 gp | 3 lb | 5 | 1d8 slashing; Versatile (1d10) | 107 gp |
| Greatsword | 50 gp | 6 lb | 5 | 2d6 slashing; Heavy, two-handed | 142 gp |
| Rapier | 25 gp | 2 lb | 5 | 1d8 piercing; Finesse | 117 gp |
| Scimitar | 25 gp | 3 lb | 5 | 1d6 slashing; Finesse, light | 117 gp |

These are Small/Medium/Tiny ordinary Standard examples, not automatic item grants or material-AC assignments. Actual bases retain the complete equipment profile, requirements and legitimate size/grade valuation. Large doubles base price/weight/ordinary HP, not the source magic/process share. Record actual dominant material before work; the shared structural and damage-preservation rules apply.

**Exact source components:**

| Occurrence | Component | Quantity | Tier | Role / consumed | Unit mass | Unit source value | Required properties |
|---|---|---:|---:|---|---:|---:|---|
| 0 | Forge water | 1 | 2 | tool / false | 25 lb | 24 gp | tool |
| 1 | Leather strips | 2 | 2 | substrate / true | 0.25 lb | 8 gp | substrate |
| 2 | Vulture claw | 1 | 2 | material / true | 0.35 lb | 48 gp | rigid, structural |

**Work:** STR or INT under the shared crafting check; Forge and Anvil; tools: Smith's tools, Forge, Anvil, Tongs. Maximum assistants 0; fieldCraftable=false, preserved timeMode=expedition. The false field flag controls: an actual Forge-and-Anvil worksite is still required. Ordinary first stable phase 4 active hour(s), included in total. An eligible Forge Dwarf uses 180 actual active minutes, first phase 180 minutes; no extra time reduction from assistants.

**Results:** Standard 1; Exceptional yield 1; Masterwork yield 1; structural option 1 with strongest noncompounding 25%/50% durability layer. Flawed: one unit establishing the single persistent half-maximum flaw after ordinary size/grade and strongest durability improvement; preserve damage deficit, possibly emerging Broken. Failed/Mishap transforms no base; source ingredient recovery/loss still applies. Masterwork returns at most one eligible consumed catalyst unit total, never one per occurrence or finished item.

**Repair:** functioning HP≥1 uses trained Smith's tools, actual Forge/Anvil/Tongs, STR/INT DC10, max(1 hour, actual max HP/10 hours), materials 25% mundane size/grade base value. HP0 with recoverable main body uses original recipe DC 12, max(8 hours, actual max HP/10 hours), materials 25% undamaged finished unit reference. Both are binary repair tasks; no formula/trade-level entitlement required or granted, no creation-only time reduction, crafting XP, quality roll or catalyst. Existing grade, durability state and flaw persist.

**Reference accounting:** source magic/process share 92 gp per unit, plus the actual transformed base's undamaged mundane size/grade reference. Real owned bases need no repurchase; purchased reserves are separate expenses. No automatic artifact multiplier, quality markup or guaranteed mundane-table magic buyback.

**Source access:** {"sources":["trainer","starter manual","common experimentation"],"minimumResearchHours":0,"requiresFormula":false,"formulaConsumed":false}. Visibility and actual ingredient availability remain source-controlled.

**Preserved tags:** Air. **Operative tag:** Air. Secondary tags grant no additional mechanics.

**Preserved legacy (inactive):** {"legacyName": "Basic Iron Sword", "legacyEffect": "AC 14 + Dex modifier (light armor)"}.

## recipe-43 — Field Verdant Hammer

**Source:** public; Blacksmithing level 1; tier 1; Common; crafting DC 10; 1 hour / 1 active hours; Standard quantity 2. Source Standard batch reference 64 gp.

**Preserved effect:** Creates a durable hammer with +1 to attack and damage rolls.

**Operational effect:** One actual hammer base becomes an intact magical nonartifact output. With this weapon's actual attacks, use recipe +1 in the item-accuracy family and add +1 once to ordinary weapon-hit damage. Legal thrown/off-hand attacks retain these benefits; carrying it does not. Unsuppressed ordinary B/P/S counts magical. No elemental damage rider is granted by its title, ingredient or tag. Broken stops positive functions; suppression stops recipe magic only. The complete base, quality, repair and value rules apply.

**Legal base models:** Light hammer, Warhammer, Maul. Choose one model, size and actual legal equipment grade for the whole batch before work.

**Physical reserve:** 3 complete legal mundane bases, ordered before work. Transform the first resolved N; keep original inventory identity, actual grade/material/damage and source access. All source ingredients below are additional inputs; none supplies a free body.

| Base model | Ordinary Standard price | Weight | Ordinary max HP | Actual base combat profile | Finished unit reference with this ordinary base |
|---|---:|---:|---:|---|---:|
| Light hammer | 2 gp | 2 lb | 5 | 1d4 bludgeoning; Light, thrown (range 20/60) | 34 gp |
| Warhammer | 15 gp | 2 lb | 5 | 1d8 bludgeoning; Versatile (1d10) | 47 gp |
| Maul | 10 gp | 10 lb | 5 | 2d6 bludgeoning; Heavy, two-handed | 42 gp |

These are Small/Medium/Tiny ordinary Standard examples, not automatic item grants or material-AC assignments. Actual bases retain the complete equipment profile, requirements and legitimate size/grade valuation. Large doubles base price/weight/ordinary HP, not the source magic/process share. Record actual dominant material before work; the shared structural and damage-preservation rules apply.

**Exact source components:**

| Occurrence | Component | Quantity | Tier | Role / consumed | Unit mass | Unit source value | Required properties |
|---|---|---:|---:|---|---:|---:|---|
| 0 | Forge water | 1 | 1 | tool / false | 25 lb | 6 gp | tool |
| 1 | Brightsteel Ingot | 1 | 1 | substrate / true | 1 lb | 2 gp | substrate |
| 2 | Heartsteel Ingot | 2 | 1 | substrate / true | 1 lb | 2 gp | substrate |
| 3 | animated vine | 1 | 2 | material / true | 0.68 lb | 23 gp | specialized |

**Work:** STR or INT under the shared crafting check; Forge and Anvil; tools: Smith's tools, Forge, Anvil, Tongs. Maximum assistants 0; fieldCraftable=false, preserved timeMode=field. The false field flag controls: an actual Forge-and-Anvil worksite is still required. Ordinary first stable phase 1 active hour(s), included in total. An eligible Forge Dwarf uses 45 actual active minutes, first phase 45 minutes; no extra time reduction from assistants.

**Results:** Standard 2; Exceptional yield 2; Masterwork yield 3; structural option 2 with strongest noncompounding 25%/50% durability layer. Flawed: 1 ordinary-effect units with existing durability state preserved. Failed/Mishap transforms no base; source ingredient recovery/loss still applies. Masterwork returns at most one eligible consumed catalyst unit total, never one per occurrence or finished item.

**Repair:** functioning HP≥1 uses trained Smith's tools, actual Forge/Anvil/Tongs, STR/INT DC10, max(1 hour, actual max HP/10 hours), materials 25% mundane size/grade base value. HP0 with recoverable main body uses original recipe DC 10, max(8 hours, actual max HP/10 hours), materials 25% undamaged finished unit reference. Both are binary repair tasks; no formula/trade-level entitlement required or granted, no creation-only time reduction, crafting XP, quality roll or catalyst. Existing grade, durability state and flaw persist.

**Reference accounting:** source magic/process share 32 gp per unit, plus the actual transformed base's undamaged mundane size/grade reference. Real owned bases need no repurchase; purchased reserves are separate expenses. No automatic artifact multiplier, quality markup or guaranteed mundane-table magic buyback.

**Source access:** {"sources":["trainer","starter manual","common experimentation"],"minimumResearchHours":0,"requiresFormula":false,"formulaConsumed":false}. Visibility and actual ingredient availability remain source-controlled.

**Preserved tags:** Flora. **Operative tag:** Flora. Secondary tags grant no additional mechanics.

**Preserved legacy (inactive):** {"legacyName": "Dwarven Hammer", "legacyEffect": "Deals an extra 1d4 damage of a specific type"}.

## recipe-44 — Superior Ember Gauntlets of Red Dragonscale

**Source:** public; Blacksmithing level 5; tier 3; Common; crafting DC 9; 8 hours / 8 active hours; Standard quantity 3. Source Standard batch reference 100 gp.

**Preserved effect:** Creates reinforced gauntlets granting +1 AC.

**Operational effect:** One actual matched Gauntlets pair becomes one intact magical nonartifact output. While legally equipped, offer +1 to equipment.defense-enhancement, using the strongest eligible recipe/suit-grade modifier; retain the base suit formula or shield contribution where applicable. No resistance is granted by its title, ingredient or tag. Broken stops positive functions; suppression stops recipe magic only. The complete base, quality, repair and value rules apply.

**Legal base models:** Gauntlets blank. Choose one model, size and actual legal equipment grade for the whole batch before work.

**Physical reserve:** 4 complete legal mundane bases, ordered before work. Transform the first resolved N; keep original inventory identity, actual grade/material/damage and source access. All source ingredients below are additional inputs; none supplies a free body.

| Base model | Ordinary Standard price | Weight | Ordinary max HP | Actual base combat profile | Finished unit reference with this ordinary base |
|---|---:|---:|---:|---|---:|
| Gauntlets blank | 10 gp | 4 lb | 5 | No mundane AC bonus; recipe supplies actual enhancement/resistance. | 130/3 gp |

These are Small/Medium/Tiny ordinary Standard examples, not automatic item grants or material-AC assignments. Actual bases retain the complete equipment profile, requirements and legitimate size/grade valuation. Large doubles base price/weight/ordinary HP, not the source magic/process share. Record actual dominant material before work; the shared structural and damage-preservation rules apply.

**Exact source components:**

| Occurrence | Component | Quantity | Tier | Role / consumed | Unit mass | Unit source value | Required properties |
|---|---|---:|---:|---|---:|---:|---|
| 0 | Wood handle | 2 | 3 | substrate / true | 0.1 lb | 25 gp | substrate |
| 1 | red dragon scale | 1 | 1 | material / true | 0.38 lb | 9 gp | draconic, fire, protective, rigid |

**Work:** STR or INT under the shared crafting check; Forge and Anvil; tools: Smith's tools, Forge, Anvil, Tongs. Maximum assistants 0; fieldCraftable=false, preserved timeMode=expedition. The false field flag controls: an actual Forge-and-Anvil worksite is still required. Ordinary first stable phase 8 active hour(s), included in total. An eligible Forge Dwarf uses 360 actual active minutes, first phase 360 minutes; no extra time reduction from assistants.

**Results:** Standard 3; Exceptional yield 3; Masterwork yield 4; structural option 3 with strongest noncompounding 25%/50% durability layer. Flawed: 1 ordinary-effect units with existing durability state preserved. Failed/Mishap transforms no base; source ingredient recovery/loss still applies. Masterwork returns at most one eligible consumed catalyst unit total, never one per occurrence or finished item.

**Repair:** functioning HP≥1 uses trained Smith's tools, actual Forge/Anvil/Tongs, STR/INT DC10, max(1 hour, actual max HP/10 hours), materials 25% mundane size/grade base value. HP0 with recoverable main body uses original recipe DC 9, max(8 hours, actual max HP/10 hours), materials 25% undamaged finished unit reference. Both are binary repair tasks; no formula/trade-level entitlement required or granted, no creation-only time reduction, crafting XP, quality roll or catalyst. Existing grade, durability state and flaw persist.

**Reference accounting:** source magic/process share 100/3 gp per unit, plus the actual transformed base's undamaged mundane size/grade reference. Real owned bases need no repurchase; purchased reserves are separate expenses. No automatic artifact multiplier, quality markup or guaranteed mundane-table magic buyback.

**Source access:** {"sources":["guild trainer","faction vendor","uncommon dungeon book","reverse engineering"],"minimumResearchHours":0,"requiresFormula":true,"formulaConsumed":false}. Visibility and actual ingredient availability remain source-controlled.

**Preserved tags:** Fire. **Operative tag:** Fire. Secondary tags grant no additional mechanics.

**Preserved legacy (inactive):** {"legacyName": "Gauntlets of Tempered Serviceableness", "legacyEffect": "AC 14 + Dex modifier (light armor)"}.

## recipe-45 — Superior Vital Axe of Putrid Marrow

**Source:** public; Blacksmithing level 5; tier 3; Common; crafting DC 10; 4 hours / 4 active hours; Standard quantity 5. Source Standard batch reference 171 gp.

**Preserved effect:** Creates a durable axe with +1 to attack and damage rolls.

**Operational effect:** One actual axe base becomes an intact magical nonartifact output. With this weapon's actual attacks, use recipe +1 in the item-accuracy family and add +1 once to ordinary weapon-hit damage. Legal thrown/off-hand attacks retain these benefits; carrying it does not. Unsuppressed ordinary B/P/S counts magical. No elemental damage rider is granted by its title, ingredient or tag. Broken stops positive functions; suppression stops recipe magic only. The complete base, quality, repair and value rules apply.

**Legal base models:** Handaxe, Battleaxe, Greataxe. Choose one model, size and actual legal equipment grade for the whole batch before work.

**Physical reserve:** 7 complete legal mundane bases, ordered before work. Transform the first resolved N; keep original inventory identity, actual grade/material/damage and source access. All source ingredients below are additional inputs; none supplies a free body.

| Base model | Ordinary Standard price | Weight | Ordinary max HP | Actual base combat profile | Finished unit reference with this ordinary base |
|---|---:|---:|---:|---|---:|
| Handaxe | 5 gp | 2 lb | 5 | 1d6 slashing; Light, thrown (range 20/60) | 39.2 gp |
| Battleaxe | 10 gp | 4 lb | 5 | 1d8 slashing; Versatile (1d10) | 44.2 gp |
| Greataxe | 30 gp | 7 lb | 5 | 1d12 slashing; Heavy, two-handed | 64.2 gp |

These are Small/Medium/Tiny ordinary Standard examples, not automatic item grants or material-AC assignments. Actual bases retain the complete equipment profile, requirements and legitimate size/grade valuation. Large doubles base price/weight/ordinary HP, not the source magic/process share. Record actual dominant material before work; the shared structural and damage-preservation rules apply.

**Exact source components:**

| Occurrence | Component | Quantity | Tier | Role / consumed | Unit mass | Unit source value | Required properties |
|---|---|---:|---:|---|---:|---:|---|
| 0 | Brightsteel Ingot | 4 | 3 | substrate / true | 1 lb | 25 gp | substrate |
| 1 | putrid marrow | 1 | 2 | material / true | 0.18 lb | 19 gp | specialized, vital |

**Work:** STR or INT under the shared crafting check; Forge and Anvil; tools: Smith's tools, Forge, Anvil, Tongs. Maximum assistants 0; fieldCraftable=false, preserved timeMode=expedition. The false field flag controls: an actual Forge-and-Anvil worksite is still required. Ordinary first stable phase 4 active hour(s), included in total. An eligible Forge Dwarf uses 180 actual active minutes, first phase 180 minutes; no extra time reduction from assistants.

**Results:** Standard 5; Exceptional yield 6; Masterwork yield 7; structural option 5 with strongest noncompounding 25%/50% durability layer. Flawed: 2 ordinary-effect units with existing durability state preserved. Failed/Mishap transforms no base; source ingredient recovery/loss still applies. Masterwork returns at most one eligible consumed catalyst unit total, never one per occurrence or finished item.

**Repair:** functioning HP≥1 uses trained Smith's tools, actual Forge/Anvil/Tongs, STR/INT DC10, max(1 hour, actual max HP/10 hours), materials 25% mundane size/grade base value. HP0 with recoverable main body uses original recipe DC 10, max(8 hours, actual max HP/10 hours), materials 25% undamaged finished unit reference. Both are binary repair tasks; no formula/trade-level entitlement required or granted, no creation-only time reduction, crafting XP, quality roll or catalyst. Existing grade, durability state and flaw persist.

**Reference accounting:** source magic/process share 34.2 gp per unit, plus the actual transformed base's undamaged mundane size/grade reference. Real owned bases need no repurchase; purchased reserves are separate expenses. No automatic artifact multiplier, quality markup or guaranteed mundane-table magic buyback.

**Source access:** {"sources":["guild trainer","faction vendor","uncommon dungeon book","reverse engineering"],"minimumResearchHours":0,"requiresFormula":true,"formulaConsumed":false}. Visibility and actual ingredient availability remain source-controlled.

**Preserved tags:** Vitality. **Operative tag:** Vitality. Secondary tags grant no additional mechanics.

**Preserved legacy (inactive):** {"legacyName": "Dwarven Axe", "legacyEffect": "+1 to attack and damage rolls"}.

## recipe-46 — Refined Ember Gauntlets

**Source:** public; Blacksmithing level 4; tier 2; Common; crafting DC 9; 8 hours / 8 active hours; Standard quantity 2. Source Standard batch reference 104 gp.

**Preserved effect:** Creates reinforced gauntlets granting +1 AC.

**Operational effect:** One actual matched Gauntlets pair becomes one intact magical nonartifact output. While legally equipped, offer +1 to equipment.defense-enhancement, using the strongest eligible recipe/suit-grade modifier; retain the base suit formula or shield contribution where applicable. No resistance is granted by its title, ingredient or tag. Broken stops positive functions; suppression stops recipe magic only. The complete base, quality, repair and value rules apply.

**Legal base models:** Gauntlets blank. Choose one model, size and actual legal equipment grade for the whole batch before work.

**Physical reserve:** 3 complete legal mundane bases, ordered before work. Transform the first resolved N; keep original inventory identity, actual grade/material/damage and source access. All source ingredients below are additional inputs; none supplies a free body.

| Base model | Ordinary Standard price | Weight | Ordinary max HP | Actual base combat profile | Finished unit reference with this ordinary base |
|---|---:|---:|---:|---|---:|
| Gauntlets blank | 10 gp | 4 lb | 5 | No mundane AC bonus; recipe supplies actual enhancement/resistance. | 62 gp |

These are Small/Medium/Tiny ordinary Standard examples, not automatic item grants or material-AC assignments. Actual bases retain the complete equipment profile, requirements and legitimate size/grade valuation. Large doubles base price/weight/ordinary HP, not the source magic/process share. Record actual dominant material before work; the shared structural and damage-preservation rules apply.

**Exact source components:**

| Occurrence | Component | Quantity | Tier | Role / consumed | Unit mass | Unit source value | Required properties |
|---|---|---:|---:|---|---:|---:|---|
| 0 | Metal rivets | 5 | 2 | binder / true | 0.1 lb | 8 gp | binder |
| 1 | Brightsteel Ingot | 2 | 2 | substrate / true | 1 lb | 8 gp | substrate |
| 2 | red dragon scale | 1 | 1 | material / true | 0.38 lb | 9 gp | draconic, fire, protective, rigid |

**Work:** STR or INT under the shared crafting check; Forge and Anvil; tools: Smith's tools, Forge, Anvil, Tongs. Maximum assistants 0; fieldCraftable=false, preserved timeMode=expedition. The false field flag controls: an actual Forge-and-Anvil worksite is still required. Ordinary first stable phase 8 active hour(s), included in total. An eligible Forge Dwarf uses 360 actual active minutes, first phase 360 minutes; no extra time reduction from assistants.

**Results:** Standard 2; Exceptional yield 2; Masterwork yield 3; structural option 2 with strongest noncompounding 25%/50% durability layer. Flawed: 1 ordinary-effect units with existing durability state preserved. Failed/Mishap transforms no base; source ingredient recovery/loss still applies. Masterwork returns at most one eligible consumed catalyst unit total, never one per occurrence or finished item.

**Repair:** functioning HP≥1 uses trained Smith's tools, actual Forge/Anvil/Tongs, STR/INT DC10, max(1 hour, actual max HP/10 hours), materials 25% mundane size/grade base value. HP0 with recoverable main body uses original recipe DC 9, max(8 hours, actual max HP/10 hours), materials 25% undamaged finished unit reference. Both are binary repair tasks; no formula/trade-level entitlement required or granted, no creation-only time reduction, crafting XP, quality roll or catalyst. Existing grade, durability state and flaw persist.

**Reference accounting:** source magic/process share 52 gp per unit, plus the actual transformed base's undamaged mundane size/grade reference. Real owned bases need no repurchase; purchased reserves are separate expenses. No automatic artifact multiplier, quality markup or guaranteed mundane-table magic buyback.

**Source access:** {"sources":["trainer","starter manual","common experimentation"],"minimumResearchHours":0,"requiresFormula":false,"formulaConsumed":false}. Visibility and actual ingredient availability remain source-controlled.

**Preserved tags:** Fire. **Operative tag:** Fire. Secondary tags grant no additional mechanics.

**Preserved legacy (inactive):** {"legacyName": "Gauntlets of Iron Basicness", "legacyEffect": "+1 to attack and damage rolls"}.

## recipe-47 — Field Vital Axe

**Source:** public; Blacksmithing level 2; tier 1; Common; crafting DC 10; 2 hours / 2 active hours; Standard quantity 1. Source Standard batch reference 72 gp.

**Preserved effect:** Creates a durable axe with +1 to attack and damage rolls.

**Operational effect:** One actual axe base becomes an intact magical nonartifact output. With this weapon's actual attacks, use recipe +1 in the item-accuracy family and add +1 once to ordinary weapon-hit damage. Legal thrown/off-hand attacks retain these benefits; carrying it does not. Unsuppressed ordinary B/P/S counts magical. No elemental damage rider is granted by its title, ingredient or tag. Broken stops positive functions; suppression stops recipe magic only. The complete base, quality, repair and value rules apply.

**Legal base models:** Handaxe, Battleaxe, Greataxe. Choose one model, size and actual legal equipment grade for the whole batch before work.

**Physical reserve:** 1 complete legal mundane bases, ordered before work. Transform the first resolved N; keep original inventory identity, actual grade/material/damage and source access. All source ingredients below are additional inputs; none supplies a free body.

| Base model | Ordinary Standard price | Weight | Ordinary max HP | Actual base combat profile | Finished unit reference with this ordinary base |
|---|---:|---:|---:|---|---:|
| Handaxe | 5 gp | 2 lb | 5 | 1d6 slashing; Light, thrown (range 20/60) | 77 gp |
| Battleaxe | 10 gp | 4 lb | 5 | 1d8 slashing; Versatile (1d10) | 82 gp |
| Greataxe | 30 gp | 7 lb | 5 | 1d12 slashing; Heavy, two-handed | 102 gp |

These are Small/Medium/Tiny ordinary Standard examples, not automatic item grants or material-AC assignments. Actual bases retain the complete equipment profile, requirements and legitimate size/grade valuation. Large doubles base price/weight/ordinary HP, not the source magic/process share. Record actual dominant material before work; the shared structural and damage-preservation rules apply.

**Exact source components:**

| Occurrence | Component | Quantity | Tier | Role / consumed | Unit mass | Unit source value | Required properties |
|---|---|---:|---:|---|---:|---:|---|
| 0 | Forge water | 1 | 1 | tool / false | 25 lb | 6 gp | tool |
| 1 | Brightsteel Ingot | 3 | 1 | substrate / true | 1 lb | 2 gp | substrate |
| 2 | Coal | 4 | 1 | fuel / true | 1 lb | 2 gp | fuel |
| 3 | putrid marrow | 1 | 2 | material / true | 0.18 lb | 19 gp | specialized, vital |

**Work:** STR or INT under the shared crafting check; Forge and Anvil; tools: Smith's tools, Forge, Anvil, Tongs. Maximum assistants 0; fieldCraftable=false, preserved timeMode=field. The false field flag controls: an actual Forge-and-Anvil worksite is still required. Ordinary first stable phase 2 active hour(s), included in total. An eligible Forge Dwarf uses 90 actual active minutes, first phase 90 minutes; no extra time reduction from assistants.

**Results:** Standard 1; Exceptional yield 1; Masterwork yield 1; structural option 1 with strongest noncompounding 25%/50% durability layer. Flawed: one unit establishing the single persistent half-maximum flaw after ordinary size/grade and strongest durability improvement; preserve damage deficit, possibly emerging Broken. Failed/Mishap transforms no base; source ingredient recovery/loss still applies. Masterwork returns at most one eligible consumed catalyst unit total, never one per occurrence or finished item.

**Repair:** functioning HP≥1 uses trained Smith's tools, actual Forge/Anvil/Tongs, STR/INT DC10, max(1 hour, actual max HP/10 hours), materials 25% mundane size/grade base value. HP0 with recoverable main body uses original recipe DC 10, max(8 hours, actual max HP/10 hours), materials 25% undamaged finished unit reference. Both are binary repair tasks; no formula/trade-level entitlement required or granted, no creation-only time reduction, crafting XP, quality roll or catalyst. Existing grade, durability state and flaw persist.

**Reference accounting:** source magic/process share 72 gp per unit, plus the actual transformed base's undamaged mundane size/grade reference. Real owned bases need no repurchase; purchased reserves are separate expenses. No automatic artifact multiplier, quality markup or guaranteed mundane-table magic buyback.

**Source access:** {"sources":["trainer","starter manual","common experimentation"],"minimumResearchHours":0,"requiresFormula":false,"formulaConsumed":false}. Visibility and actual ingredient availability remain source-controlled.

**Preserved tags:** Vitality. **Operative tag:** Vitality. Secondary tags grant no additional mechanics.

**Preserved legacy (inactive):** {"legacyName": "Serviceable Forged Axe", "legacyEffect": "AC 14 + Dex modifier (light armor)"}.

## recipe-48 — Field Storm Axe

**Source:** public; Blacksmithing level 2; tier 1; Common; crafting DC 8; 8 hours / 8 active hours; Standard quantity 5. Source Standard batch reference 88 gp.

**Preserved effect:** Creates a durable axe with +1 to attack and damage rolls.

**Operational effect:** One actual axe base becomes an intact magical nonartifact output. With this weapon's actual attacks, use recipe +1 in the item-accuracy family and add +1 once to ordinary weapon-hit damage. Legal thrown/off-hand attacks retain these benefits; carrying it does not. Unsuppressed ordinary B/P/S counts magical. No elemental damage rider is granted by its title, ingredient or tag. Broken stops positive functions; suppression stops recipe magic only. The complete base, quality, repair and value rules apply.

**Legal base models:** Handaxe, Battleaxe, Greataxe. Choose one model, size and actual legal equipment grade for the whole batch before work.

**Physical reserve:** 7 complete legal mundane bases, ordered before work. Transform the first resolved N; keep original inventory identity, actual grade/material/damage and source access. All source ingredients below are additional inputs; none supplies a free body.

| Base model | Ordinary Standard price | Weight | Ordinary max HP | Actual base combat profile | Finished unit reference with this ordinary base |
|---|---:|---:|---:|---|---:|
| Handaxe | 5 gp | 2 lb | 5 | 1d6 slashing; Light, thrown (range 20/60) | 22.6 gp |
| Battleaxe | 10 gp | 4 lb | 5 | 1d8 slashing; Versatile (1d10) | 27.6 gp |
| Greataxe | 30 gp | 7 lb | 5 | 1d12 slashing; Heavy, two-handed | 47.6 gp |

These are Small/Medium/Tiny ordinary Standard examples, not automatic item grants or material-AC assignments. Actual bases retain the complete equipment profile, requirements and legitimate size/grade valuation. Large doubles base price/weight/ordinary HP, not the source magic/process share. Record actual dominant material before work; the shared structural and damage-preservation rules apply.

**Exact source components:**

| Occurrence | Component | Quantity | Tier | Role / consumed | Unit mass | Unit source value | Required properties |
|---|---|---:|---:|---|---:|---:|---|
| 0 | Brightsteel Ingot | 4 | 1 | substrate / true | 1 lb | 2 gp | substrate |
| 1 | blue dragon scale | 1 | 1 | material / true | 0.52 lb | 12 gp | draconic, lightning, protective, rigid |

**Work:** STR or INT under the shared crafting check; Forge and Anvil; tools: Smith's tools, Forge, Anvil, Tongs. Maximum assistants 0; fieldCraftable=false, preserved timeMode=expedition. The false field flag controls: an actual Forge-and-Anvil worksite is still required. Ordinary first stable phase 8 active hour(s), included in total. An eligible Forge Dwarf uses 360 actual active minutes, first phase 360 minutes; no extra time reduction from assistants.

**Results:** Standard 5; Exceptional yield 6; Masterwork yield 7; structural option 5 with strongest noncompounding 25%/50% durability layer. Flawed: 2 ordinary-effect units with existing durability state preserved. Failed/Mishap transforms no base; source ingredient recovery/loss still applies. Masterwork returns at most one eligible consumed catalyst unit total, never one per occurrence or finished item.

**Repair:** functioning HP≥1 uses trained Smith's tools, actual Forge/Anvil/Tongs, STR/INT DC10, max(1 hour, actual max HP/10 hours), materials 25% mundane size/grade base value. HP0 with recoverable main body uses original recipe DC 8, max(8 hours, actual max HP/10 hours), materials 25% undamaged finished unit reference. Both are binary repair tasks; no formula/trade-level entitlement required or granted, no creation-only time reduction, crafting XP, quality roll or catalyst. Existing grade, durability state and flaw persist.

**Reference accounting:** source magic/process share 17.6 gp per unit, plus the actual transformed base's undamaged mundane size/grade reference. Real owned bases need no repurchase; purchased reserves are separate expenses. No automatic artifact multiplier, quality markup or guaranteed mundane-table magic buyback.

**Source access:** {"sources":["trainer","starter manual","common experimentation"],"minimumResearchHours":0,"requiresFormula":false,"formulaConsumed":false}. Visibility and actual ingredient availability remain source-controlled.

**Preserved tags:** Lightning. **Operative tag:** Lightning. Secondary tags grant no additional mechanics.

**Preserved legacy (inactive):** {"legacyName": "Basic Dwarven Axe", "legacyEffect": "Deals an extra 1d4 damage of a specific type"}.

## recipe-49 — Refined Tide Helm

**Source:** public; Blacksmithing level 3; tier 2; Common; crafting DC 8; 4 hours / 4 active hours; Standard quantity 3. Source Standard batch reference 98 gp.

**Preserved effect:** Creates reinforced helm granting +1 AC.

**Operational effect:** One actual helm base becomes an intact magical nonartifact output. While legally equipped, offer +1 to equipment.defense-enhancement, using the strongest eligible recipe/suit-grade modifier; retain the base suit formula or shield contribution where applicable. No resistance is granted by its title, ingredient or tag. Broken stops positive functions; suppression stops recipe magic only. The complete base, quality, repair and value rules apply.

**Legal base models:** Helm blank. Choose one model, size and actual legal equipment grade for the whole batch before work.

**Physical reserve:** 4 complete legal mundane bases, ordered before work. Transform the first resolved N; keep original inventory identity, actual grade/material/damage and source access. All source ingredients below are additional inputs; none supplies a free body.

| Base model | Ordinary Standard price | Weight | Ordinary max HP | Actual base combat profile | Finished unit reference with this ordinary base |
|---|---:|---:|---:|---|---:|
| Helm blank | 10 gp | 5 lb | 5 | No mundane AC bonus; recipe supplies actual enhancement/resistance. | 128/3 gp |

These are Small/Medium/Tiny ordinary Standard examples, not automatic item grants or material-AC assignments. Actual bases retain the complete equipment profile, requirements and legitimate size/grade valuation. Large doubles base price/weight/ordinary HP, not the source magic/process share. Record actual dominant material before work; the shared structural and damage-preservation rules apply.

**Exact source components:**

| Occurrence | Component | Quantity | Tier | Role / consumed | Unit mass | Unit source value | Required properties |
|---|---|---:|---:|---|---:|---:|---|
| 0 | Tempering oil | 2 | 2 | solvent / true | 0.5 lb | 8 gp | solvent |
| 1 | Brightsteel Ingot | 5 | 2 | substrate / true | 1 lb | 8 gp | substrate |
| 2 | bronze dragon scale | 1 | 1 | material / true | 0.91 lb | 12 gp | draconic, protective, rigid, water |

**Work:** STR or INT under the shared crafting check; Forge and Anvil; tools: Smith's tools, Forge, Anvil, Tongs. Maximum assistants 0; fieldCraftable=false, preserved timeMode=expedition. The false field flag controls: an actual Forge-and-Anvil worksite is still required. Ordinary first stable phase 4 active hour(s), included in total. An eligible Forge Dwarf uses 180 actual active minutes, first phase 180 minutes; no extra time reduction from assistants.

**Results:** Standard 3; Exceptional yield 3; Masterwork yield 4; structural option 3 with strongest noncompounding 25%/50% durability layer. Flawed: 1 ordinary-effect units with existing durability state preserved. Failed/Mishap transforms no base; source ingredient recovery/loss still applies. Masterwork returns at most one eligible consumed catalyst unit total, never one per occurrence or finished item.

**Repair:** functioning HP≥1 uses trained Smith's tools, actual Forge/Anvil/Tongs, STR/INT DC10, max(1 hour, actual max HP/10 hours), materials 25% mundane size/grade base value. HP0 with recoverable main body uses original recipe DC 8, max(8 hours, actual max HP/10 hours), materials 25% undamaged finished unit reference. Both are binary repair tasks; no formula/trade-level entitlement required or granted, no creation-only time reduction, crafting XP, quality roll or catalyst. Existing grade, durability state and flaw persist.

**Reference accounting:** source magic/process share 98/3 gp per unit, plus the actual transformed base's undamaged mundane size/grade reference. Real owned bases need no repurchase; purchased reserves are separate expenses. No automatic artifact multiplier, quality markup or guaranteed mundane-table magic buyback.

**Source access:** {"sources":["trainer","starter manual","common experimentation"],"minimumResearchHours":0,"requiresFormula":false,"formulaConsumed":false}. Visibility and actual ingredient availability remain source-controlled.

**Preserved tags:** Water. **Operative tag:** Water. Secondary tags grant no additional mechanics.

**Preserved legacy (inactive):** {"legacyName": "Simple Helmet", "legacyEffect": "+1 to attack and damage rolls"}.

## recipe-50 — Superior Gale Mace of Hawk Bone

**Source:** public; Blacksmithing level 5; tier 3; Common; crafting DC 11; 4 hours / 4 active hours; Standard quantity 5. Source Standard batch reference 71 gp.

**Preserved effect:** Creates a durable mace with +1 to attack and damage rolls.

**Operational effect:** One actual mace base becomes an intact magical nonartifact output. With this weapon's actual attacks, use recipe +1 in the item-accuracy family and add +1 once to ordinary weapon-hit damage. Legal thrown/off-hand attacks retain these benefits; carrying it does not. Unsuppressed ordinary B/P/S counts magical. No elemental damage rider is granted by its title, ingredient or tag. Broken stops positive functions; suppression stops recipe magic only. The complete base, quality, repair and value rules apply.

**Legal base models:** Mace, Flail, Morningstar. Choose one model, size and actual legal equipment grade for the whole batch before work.

**Physical reserve:** 7 complete legal mundane bases, ordered before work. Transform the first resolved N; keep original inventory identity, actual grade/material/damage and source access. All source ingredients below are additional inputs; none supplies a free body.

| Base model | Ordinary Standard price | Weight | Ordinary max HP | Actual base combat profile | Finished unit reference with this ordinary base |
|---|---:|---:|---:|---|---:|
| Mace | 5 gp | 4 lb | 5 | 1d6 bludgeoning; , | 19.2 gp |
| Flail | 10 gp | 2 lb | 5 | 1d8 bludgeoning; , | 24.2 gp |
| Morningstar | 15 gp | 4 lb | 5 | 1d8 piercing; , | 29.2 gp |

These are Small/Medium/Tiny ordinary Standard examples, not automatic item grants or material-AC assignments. Actual bases retain the complete equipment profile, requirements and legitimate size/grade valuation. Large doubles base price/weight/ordinary HP, not the source magic/process share. Record actual dominant material before work; the shared structural and damage-preservation rules apply.

**Exact source components:**

| Occurrence | Component | Quantity | Tier | Role / consumed | Unit mass | Unit source value | Required properties |
|---|---|---:|---:|---|---:|---:|---|
| 0 | Iron ingot | 1 | 3 | substrate / true | 1 lb | 25 gp | substrate |
| 1 | Hawk bone shard | 1 | 2 | material / true | 0.75 lb | 17 gp | rigid, structural |

**Work:** STR or INT under the shared crafting check; Forge and Anvil; tools: Smith's tools, Forge, Anvil, Tongs. Maximum assistants 0; fieldCraftable=false, preserved timeMode=expedition. The false field flag controls: an actual Forge-and-Anvil worksite is still required. Ordinary first stable phase 4 active hour(s), included in total. An eligible Forge Dwarf uses 180 actual active minutes, first phase 180 minutes; no extra time reduction from assistants.

**Results:** Standard 5; Exceptional yield 6; Masterwork yield 7; structural option 5 with strongest noncompounding 25%/50% durability layer. Flawed: 2 ordinary-effect units with existing durability state preserved. Failed/Mishap transforms no base; source ingredient recovery/loss still applies. Masterwork returns at most one eligible consumed catalyst unit total, never one per occurrence or finished item.

**Repair:** functioning HP≥1 uses trained Smith's tools, actual Forge/Anvil/Tongs, STR/INT DC10, max(1 hour, actual max HP/10 hours), materials 25% mundane size/grade base value. HP0 with recoverable main body uses original recipe DC 11, max(8 hours, actual max HP/10 hours), materials 25% undamaged finished unit reference. Both are binary repair tasks; no formula/trade-level entitlement required or granted, no creation-only time reduction, crafting XP, quality roll or catalyst. Existing grade, durability state and flaw persist.

**Reference accounting:** source magic/process share 14.2 gp per unit, plus the actual transformed base's undamaged mundane size/grade reference. Real owned bases need no repurchase; purchased reserves are separate expenses. No automatic artifact multiplier, quality markup or guaranteed mundane-table magic buyback.

**Source access:** {"sources":["guild trainer","faction vendor","uncommon dungeon book","reverse engineering"],"minimumResearchHours":0,"requiresFormula":true,"formulaConsumed":false}. Visibility and actual ingredient availability remain source-controlled.

**Preserved tags:** Air. **Operative tag:** Air. Secondary tags grant no additional mechanics.

**Preserved legacy (inactive):** {"legacyName": "Dwarven Mace", "legacyEffect": "+1 to attack and damage rolls"}.

## recipe-51 — Refined Veiled Sword

**Source:** public; Blacksmithing level 4; tier 2; Common; crafting DC 11; 2 hours / 2 active hours; Standard quantity 3. Source Standard batch reference 112 gp.

**Preserved effect:** Creates a durable sword with +1 to attack and damage rolls.

**Operational effect:** One actual sword base becomes an intact magical nonartifact output. With this weapon's actual attacks, use recipe +1 in the item-accuracy family and add +1 once to ordinary weapon-hit damage. Legal thrown/off-hand attacks retain these benefits; carrying it does not. Unsuppressed ordinary B/P/S counts magical. No elemental damage rider is granted by its title, ingredient or tag. Broken stops positive functions; suppression stops recipe magic only. The complete base, quality, repair and value rules apply.

**Legal base models:** Shortsword, Longsword, Greatsword, Rapier, Scimitar. Choose one model, size and actual legal equipment grade for the whole batch before work.

**Physical reserve:** 4 complete legal mundane bases, ordered before work. Transform the first resolved N; keep original inventory identity, actual grade/material/damage and source access. All source ingredients below are additional inputs; none supplies a free body.

| Base model | Ordinary Standard price | Weight | Ordinary max HP | Actual base combat profile | Finished unit reference with this ordinary base |
|---|---:|---:|---:|---|---:|
| Shortsword | 10 gp | 2 lb | 5 | 1d6 piercing; Finesse, light | 142/3 gp |
| Longsword | 15 gp | 3 lb | 5 | 1d8 slashing; Versatile (1d10) | 157/3 gp |
| Greatsword | 50 gp | 6 lb | 5 | 2d6 slashing; Heavy, two-handed | 262/3 gp |
| Rapier | 25 gp | 2 lb | 5 | 1d8 piercing; Finesse | 187/3 gp |
| Scimitar | 25 gp | 3 lb | 5 | 1d6 slashing; Finesse, light | 187/3 gp |

These are Small/Medium/Tiny ordinary Standard examples, not automatic item grants or material-AC assignments. Actual bases retain the complete equipment profile, requirements and legitimate size/grade valuation. Large doubles base price/weight/ordinary HP, not the source magic/process share. Record actual dominant material before work; the shared structural and damage-preservation rules apply.

**Exact source components:**

| Occurrence | Component | Quantity | Tier | Role / consumed | Unit mass | Unit source value | Required properties |
|---|---|---:|---:|---|---:|---:|---|
| 0 | Steel ingot | 4 | 2 | substrate / true | 1 lb | 8 gp | substrate |
| 1 | Leather strips | 1 | 2 | substrate / true | 0.25 lb | 8 gp | substrate |
| 2 | Heartsteel Ingot | 4 | 2 | substrate / true | 1 lb | 8 gp | substrate |
| 3 | black dragon scale | 1 | 1 | material / true | 0.43 lb | 8 gp | acid, draconic, protective, rigid |

**Work:** STR or INT under the shared crafting check; Forge and Anvil; tools: Smith's tools, Forge, Anvil, Tongs. Maximum assistants 0; fieldCraftable=false, preserved timeMode=field. The false field flag controls: an actual Forge-and-Anvil worksite is still required. Ordinary first stable phase 2 active hour(s), included in total. An eligible Forge Dwarf uses 90 actual active minutes, first phase 90 minutes; no extra time reduction from assistants.

**Results:** Standard 3; Exceptional yield 3; Masterwork yield 4; structural option 3 with strongest noncompounding 25%/50% durability layer. Flawed: 1 ordinary-effect units with existing durability state preserved. Failed/Mishap transforms no base; source ingredient recovery/loss still applies. Masterwork returns at most one eligible consumed catalyst unit total, never one per occurrence or finished item.

**Repair:** functioning HP≥1 uses trained Smith's tools, actual Forge/Anvil/Tongs, STR/INT DC10, max(1 hour, actual max HP/10 hours), materials 25% mundane size/grade base value. HP0 with recoverable main body uses original recipe DC 11, max(8 hours, actual max HP/10 hours), materials 25% undamaged finished unit reference. Both are binary repair tasks; no formula/trade-level entitlement required or granted, no creation-only time reduction, crafting XP, quality roll or catalyst. Existing grade, durability state and flaw persist.

**Reference accounting:** source magic/process share 112/3 gp per unit, plus the actual transformed base's undamaged mundane size/grade reference. Real owned bases need no repurchase; purchased reserves are separate expenses. No automatic artifact multiplier, quality markup or guaranteed mundane-table magic buyback.

**Source access:** {"sources":["trainer","starter manual","common experimentation"],"minimumResearchHours":0,"requiresFormula":false,"formulaConsumed":false}. Visibility and actual ingredient availability remain source-controlled.

**Preserved tags:** Stealth. **Operative tag:** Stealth. Secondary tags grant no additional mechanics.

**Preserved legacy (inactive):** {"legacyName": "Serviceable Iron Sword", "legacyEffect": "AC 14 + Dex modifier (light armor)"}.

## recipe-52 — Superior Storm Weapon of Blue Dragonscale

**Source:** public; Blacksmithing level 5; tier 3; Common; crafting DC 8; 4 hours / 4 active hours; Standard quantity 3. Source Standard batch reference 127 gp.

**Preserved effect:** Creates a durable weapon with +1 to attack and damage rolls.

**Operational effect:** One actual weapon base becomes an intact magical nonartifact output. With this weapon's actual attacks, use recipe +1 in the item-accuracy family and add +1 once to ordinary weapon-hit damage. Legal thrown/off-hand attacks retain these benefits; carrying it does not. Unsuppressed ordinary B/P/S counts magical. No elemental damage rider is granted by its title, ingredient or tag. Broken stops positive functions; suppression stops recipe magic only. The complete base, quality, repair and value rules apply.

**Legal base models:** Dagger, Dart, Handaxe, Javelin, Light hammer, Mace, Sickle, Spear, Battleaxe, Flail, Glaive, Greataxe, Greatsword, Halberd, Lance, Longsword, Maul, Morningstar, Pike, Rapier, Scimitar, Shortsword, Trident, War pick, Warhammer, Kama. Choose one model, size and actual legal equipment grade for the whole batch before work.

**Physical reserve:** 4 complete legal mundane bases, ordered before work. Transform the first resolved N; keep original inventory identity, actual grade/material/damage and source access. All source ingredients below are additional inputs; none supplies a free body.

| Base model | Ordinary Standard price | Weight | Ordinary max HP | Actual base combat profile | Finished unit reference with this ordinary base |
|---|---:|---:|---:|---|---:|
| Dagger | 2 gp | 1 lb | 5 | 1d4 piercing; Finesse, light, thrown (range 20/60) | 133/3 gp |
| Dart | 0.05 gp | 0.25 lb | 5 | 1d4 piercing; Finesse, thrown (range 20/60) | 2543/60 gp |
| Handaxe | 5 gp | 2 lb | 5 | 1d6 slashing; Light, thrown (range 20/60) | 142/3 gp |
| Javelin | 0.5 gp | 2 lb | 5 | 1d6 piercing; Thrown (range 30/120) | 257/6 gp |
| Light hammer | 2 gp | 2 lb | 5 | 1d4 bludgeoning; Light, thrown (range 20/60) | 133/3 gp |
| Mace | 5 gp | 4 lb | 5 | 1d6 bludgeoning; , | 142/3 gp |
| Sickle | 1 gp | 2 lb | 5 | 1d4 slashing; Light | 130/3 gp |
| Spear | 1 gp | 3 lb | 5 | 1d6 piercing; Thrown (range 20/60), versatile (1d8) | 130/3 gp |
| Battleaxe | 10 gp | 4 lb | 5 | 1d8 slashing; Versatile (1d10) | 157/3 gp |
| Flail | 10 gp | 2 lb | 5 | 1d8 bludgeoning; , | 157/3 gp |
| Glaive | 20 gp | 6 lb | 5 | 1d10 slashing; Heavy, reach, two-handed | 187/3 gp |
| Greataxe | 30 gp | 7 lb | 5 | 1d12 slashing; Heavy, two-handed | 217/3 gp |
| Greatsword | 50 gp | 6 lb | 5 | 2d6 slashing; Heavy, two-handed | 277/3 gp |
| Halberd | 20 gp | 6 lb | 5 | 1d10 slashing; Heavy, reach, two-handed | 187/3 gp |
| Lance | 10 gp | 6 lb | 5 | 1d12 piercing; Reach, special | 157/3 gp |
| Longsword | 15 gp | 3 lb | 5 | 1d8 slashing; Versatile (1d10) | 172/3 gp |
| Maul | 10 gp | 10 lb | 5 | 2d6 bludgeoning; Heavy, two-handed | 157/3 gp |
| Morningstar | 15 gp | 4 lb | 5 | 1d8 piercing; , | 172/3 gp |
| Pike | 5 gp | 18 lb | 5 | 1d10 piercing; Heavy, reach, two-handed | 142/3 gp |
| Rapier | 25 gp | 2 lb | 5 | 1d8 piercing; Finesse | 202/3 gp |
| Scimitar | 25 gp | 3 lb | 5 | 1d6 slashing; Finesse, light | 202/3 gp |
| Shortsword | 10 gp | 2 lb | 5 | 1d6 piercing; Finesse, light | 157/3 gp |
| Trident | 5 gp | 4 lb | 5 | 1d6 piercing; Thrown (range 20/60), versatile (1d8) | 142/3 gp |
| War pick | 5 gp | 2 lb | 5 | 1d8 piercing; , | 142/3 gp |
| Warhammer | 15 gp | 2 lb | 5 | 1d8 bludgeoning; Versatile (1d10) | 172/3 gp |
| Kama | 2 gp | 2 lb | 5 | 1d4 slashing; Light | 133/3 gp |

These are Small/Medium/Tiny ordinary Standard examples, not automatic item grants or material-AC assignments. Actual bases retain the complete equipment profile, requirements and legitimate size/grade valuation. Large doubles base price/weight/ordinary HP, not the source magic/process share. Record actual dominant material before work; the shared structural and damage-preservation rules apply.

**Exact source components:**

| Occurrence | Component | Quantity | Tier | Role / consumed | Unit mass | Unit source value | Required properties |
|---|---|---:|---:|---|---:|---:|---|
| 0 | Iron ingot | 3 | 3 | substrate / true | 1 lb | 25 gp | substrate |
| 1 | blue dragon scale | 1 | 1 | material / true | 0.52 lb | 12 gp | draconic, lightning, protective, rigid |

**Work:** STR or INT under the shared crafting check; Forge and Anvil; tools: Smith's tools, Forge, Anvil, Tongs. Maximum assistants 0; fieldCraftable=false, preserved timeMode=expedition. The false field flag controls: an actual Forge-and-Anvil worksite is still required. Ordinary first stable phase 4 active hour(s), included in total. An eligible Forge Dwarf uses 180 actual active minutes, first phase 180 minutes; no extra time reduction from assistants.

**Results:** Standard 3; Exceptional yield 3; Masterwork yield 4; structural option 3 with strongest noncompounding 25%/50% durability layer. Flawed: 1 ordinary-effect units with existing durability state preserved. Failed/Mishap transforms no base; source ingredient recovery/loss still applies. Masterwork returns at most one eligible consumed catalyst unit total, never one per occurrence or finished item.

**Repair:** functioning HP≥1 uses trained Smith's tools, actual Forge/Anvil/Tongs, STR/INT DC10, max(1 hour, actual max HP/10 hours), materials 25% mundane size/grade base value. HP0 with recoverable main body uses original recipe DC 8, max(8 hours, actual max HP/10 hours), materials 25% undamaged finished unit reference. Both are binary repair tasks; no formula/trade-level entitlement required or granted, no creation-only time reduction, crafting XP, quality roll or catalyst. Existing grade, durability state and flaw persist.

**Reference accounting:** source magic/process share 127/3 gp per unit, plus the actual transformed base's undamaged mundane size/grade reference. Real owned bases need no repurchase; purchased reserves are separate expenses. No automatic artifact multiplier, quality markup or guaranteed mundane-table magic buyback.

**Source access:** {"sources":["guild trainer","faction vendor","uncommon dungeon book","reverse engineering"],"minimumResearchHours":0,"requiresFormula":true,"formulaConsumed":false}. Visibility and actual ingredient availability remain source-controlled.

**Preserved tags:** Lightning. **Operative tag:** Lightning. Secondary tags grant no additional mechanics.

**Preserved legacy (inactive):** {"legacyName": "Iron Chain", "legacyEffect": "Deals an extra 1d4 damage of a specific type"}.

## recipe-53 — Refined Veiled Shield

**Source:** public; Blacksmithing level 4; tier 2; Common; crafting DC 9; 4 hours / 4 active hours; Standard quantity 5. Source Standard batch reference 94 gp.

**Preserved effect:** Creates reinforced shield granting +1 AC.

**Operational effect:** One actual shield base becomes an intact magical nonartifact output. While legally equipped, offer +1 to equipment.defense-enhancement, using the strongest eligible recipe/suit-grade modifier; retain the base suit formula or shield contribution where applicable. No resistance is granted by its title, ingredient or tag. Broken stops positive functions; suppression stops recipe magic only. The complete base, quality, repair and value rules apply.

**Legal base models:** Buckler, Shield, Tower shield. Choose one model, size and actual legal equipment grade for the whole batch before work.

**Physical reserve:** 7 complete legal mundane bases, ordered before work. Transform the first resolved N; keep original inventory identity, actual grade/material/damage and source access. All source ingredients below are additional inputs; none supplies a free body.

| Base model | Ordinary Standard price | Weight | Ordinary max HP | Actual base combat profile | Finished unit reference with this ordinary base |
|---|---:|---:|---:|---|---:|
| Buckler | 5 gp | 3 lb | 10 | +1 | 23.8 gp |
| Shield | 10 gp | 6 lb | 10 | +2 | 28.8 gp |
| Tower shield | 50 gp | 15 lb | 15 | +3 | 68.8 gp |

These are Small/Medium/Tiny ordinary Standard examples, not automatic item grants or material-AC assignments. Actual bases retain the complete equipment profile, requirements and legitimate size/grade valuation. Large doubles base price/weight/ordinary HP, not the source magic/process share. Record actual dominant material before work; the shared structural and damage-preservation rules apply.

**Exact source components:**

| Occurrence | Component | Quantity | Tier | Role / consumed | Unit mass | Unit source value | Required properties |
|---|---|---:|---:|---|---:|---:|---|
| 0 | Tempering oil | 4 | 2 | solvent / true | 0.5 lb | 8 gp | solvent |
| 1 | Iron ingot | 1 | 2 | substrate / true | 1 lb | 8 gp | substrate |
| 2 | Heartsteel Ingot | 2 | 2 | substrate / true | 1 lb | 8 gp | substrate |
| 3 | black dragon scale | 1 | 1 | material / true | 0.43 lb | 8 gp | acid, draconic, protective, rigid |

**Work:** STR or INT under the shared crafting check; Forge and Anvil; tools: Smith's tools, Forge, Anvil, Tongs. Maximum assistants 0; fieldCraftable=false, preserved timeMode=expedition. The false field flag controls: an actual Forge-and-Anvil worksite is still required. Ordinary first stable phase 4 active hour(s), included in total. An eligible Forge Dwarf uses 180 actual active minutes, first phase 180 minutes; no extra time reduction from assistants.

**Results:** Standard 5; Exceptional yield 6; Masterwork yield 7; structural option 5 with strongest noncompounding 25%/50% durability layer. Flawed: 2 ordinary-effect units with existing durability state preserved. Failed/Mishap transforms no base; source ingredient recovery/loss still applies. Masterwork returns at most one eligible consumed catalyst unit total, never one per occurrence or finished item.

**Repair:** functioning HP≥1 uses trained Smith's tools, actual Forge/Anvil/Tongs, STR/INT DC10, max(1 hour, actual max HP/10 hours), materials 25% mundane size/grade base value. HP0 with recoverable main body uses original recipe DC 9, max(8 hours, actual max HP/10 hours), materials 25% undamaged finished unit reference. Both are binary repair tasks; no formula/trade-level entitlement required or granted, no creation-only time reduction, crafting XP, quality roll or catalyst. Existing grade, durability state and flaw persist.

**Reference accounting:** source magic/process share 18.8 gp per unit, plus the actual transformed base's undamaged mundane size/grade reference. Real owned bases need no repurchase; purchased reserves are separate expenses. No automatic artifact multiplier, quality markup or guaranteed mundane-table magic buyback.

**Source access:** {"sources":["trainer","starter manual","common experimentation"],"minimumResearchHours":0,"requiresFormula":false,"formulaConsumed":false}. Visibility and actual ingredient availability remain source-controlled.

**Preserved tags:** Stealth. **Operative tag:** Stealth. Secondary tags grant no additional mechanics.

**Preserved legacy (inactive):** {"legacyName": "Practical Shield", "legacyEffect": "Deals an extra 1d4 damage of a specific type"}.

## recipe-54 — Superior Stone Spear of Metal

**Source:** public; Blacksmithing level 5; tier 3; Common; crafting DC 11; 4 hours / 4 active hours; Standard quantity 2. Source Standard batch reference 265 gp.

**Preserved effect:** Creates a durable spear with +1 to attack and damage rolls.

**Operational effect:** One actual spear base becomes an intact magical nonartifact output. With this weapon's actual attacks, use recipe +1 in the item-accuracy family and add +1 once to ordinary weapon-hit damage. Legal thrown/off-hand attacks retain these benefits; carrying it does not. Unsuppressed ordinary B/P/S counts magical. No elemental damage rider is granted by its title, ingredient or tag. Broken stops positive functions; suppression stops recipe magic only. The complete base, quality, repair and value rules apply.

**Legal base models:** Spear, Javelin, Trident, Pike, Lance. Choose one model, size and actual legal equipment grade for the whole batch before work.

**Physical reserve:** 3 complete legal mundane bases, ordered before work. Transform the first resolved N; keep original inventory identity, actual grade/material/damage and source access. All source ingredients below are additional inputs; none supplies a free body.

| Base model | Ordinary Standard price | Weight | Ordinary max HP | Actual base combat profile | Finished unit reference with this ordinary base |
|---|---:|---:|---:|---|---:|
| Spear | 1 gp | 3 lb | 5 | 1d6 piercing; Thrown (range 20/60), versatile (1d8) | 133.5 gp |
| Javelin | 0.5 gp | 2 lb | 5 | 1d6 piercing; Thrown (range 30/120) | 133 gp |
| Trident | 5 gp | 4 lb | 5 | 1d6 piercing; Thrown (range 20/60), versatile (1d8) | 137.5 gp |
| Pike | 5 gp | 18 lb | 5 | 1d10 piercing; Heavy, reach, two-handed | 137.5 gp |
| Lance | 10 gp | 6 lb | 5 | 1d12 piercing; Reach, special | 142.5 gp |

These are Small/Medium/Tiny ordinary Standard examples, not automatic item grants or material-AC assignments. Actual bases retain the complete equipment profile, requirements and legitimate size/grade valuation. Large doubles base price/weight/ordinary HP, not the source magic/process share. Record actual dominant material before work; the shared structural and damage-preservation rules apply.

**Exact source components:**

| Occurrence | Component | Quantity | Tier | Role / consumed | Unit mass | Unit source value | Required properties |
|---|---|---:|---:|---|---:|---:|---|
| 0 | Wood handle | 4 | 3 | substrate / true | 0.1 lb | 25 gp | substrate |
| 1 | Coal | 3 | 3 | fuel / true | 1 lb | 25 gp | fuel |
| 2 | metal fragment | 1 | 1 | material / true | 0.27 lb | 14 gp | resonant, rigid |

**Work:** STR or INT under the shared crafting check; Forge and Anvil; tools: Smith's tools, Forge, Anvil, Tongs. Maximum assistants 0; fieldCraftable=false, preserved timeMode=expedition. The false field flag controls: an actual Forge-and-Anvil worksite is still required. Ordinary first stable phase 4 active hour(s), included in total. An eligible Forge Dwarf uses 180 actual active minutes, first phase 180 minutes; no extra time reduction from assistants.

**Results:** Standard 2; Exceptional yield 2; Masterwork yield 3; structural option 2 with strongest noncompounding 25%/50% durability layer. Flawed: 1 ordinary-effect units with existing durability state preserved. Failed/Mishap transforms no base; source ingredient recovery/loss still applies. Masterwork returns at most one eligible consumed catalyst unit total, never one per occurrence or finished item.

**Repair:** functioning HP≥1 uses trained Smith's tools, actual Forge/Anvil/Tongs, STR/INT DC10, max(1 hour, actual max HP/10 hours), materials 25% mundane size/grade base value. HP0 with recoverable main body uses original recipe DC 11, max(8 hours, actual max HP/10 hours), materials 25% undamaged finished unit reference. Both are binary repair tasks; no formula/trade-level entitlement required or granted, no creation-only time reduction, crafting XP, quality roll or catalyst. Existing grade, durability state and flaw persist.

**Reference accounting:** source magic/process share 132.5 gp per unit, plus the actual transformed base's undamaged mundane size/grade reference. Real owned bases need no repurchase; purchased reserves are separate expenses. No automatic artifact multiplier, quality markup or guaranteed mundane-table magic buyback.

**Source access:** {"sources":["guild trainer","faction vendor","uncommon dungeon book","reverse engineering"],"minimumResearchHours":0,"requiresFormula":true,"formulaConsumed":false}. Visibility and actual ingredient availability remain source-controlled.

**Preserved tags:** Earth. **Operative tag:** Earth. Secondary tags grant no additional mechanics.

**Preserved legacy (inactive):** {"legacyName": "Standard Dwarven Spear", "legacyEffect": "AC 14 + Dex modifier (light armor)"}.

## recipe-55 — Field Veiled Mace

**Source:** public; Blacksmithing level 1; tier 1; Common; crafting DC 8; 2 hours / 2 active hours; Standard quantity 2. Source Standard batch reference 73 gp.

**Preserved effect:** Creates a durable mace with +1 to attack and damage rolls.

**Operational effect:** One actual mace base becomes an intact magical nonartifact output. With this weapon's actual attacks, use recipe +1 in the item-accuracy family and add +1 once to ordinary weapon-hit damage. Legal thrown/off-hand attacks retain these benefits; carrying it does not. Unsuppressed ordinary B/P/S counts magical. No elemental damage rider is granted by its title, ingredient or tag. Broken stops positive functions; suppression stops recipe magic only. The complete base, quality, repair and value rules apply.

**Legal base models:** Mace, Flail, Morningstar. Choose one model, size and actual legal equipment grade for the whole batch before work.

**Physical reserve:** 3 complete legal mundane bases, ordered before work. Transform the first resolved N; keep original inventory identity, actual grade/material/damage and source access. All source ingredients below are additional inputs; none supplies a free body.

| Base model | Ordinary Standard price | Weight | Ordinary max HP | Actual base combat profile | Finished unit reference with this ordinary base |
|---|---:|---:|---:|---|---:|
| Mace | 5 gp | 4 lb | 5 | 1d6 bludgeoning; , | 41.5 gp |
| Flail | 10 gp | 2 lb | 5 | 1d8 bludgeoning; , | 46.5 gp |
| Morningstar | 15 gp | 4 lb | 5 | 1d8 piercing; , | 51.5 gp |

These are Small/Medium/Tiny ordinary Standard examples, not automatic item grants or material-AC assignments. Actual bases retain the complete equipment profile, requirements and legitimate size/grade valuation. Large doubles base price/weight/ordinary HP, not the source magic/process share. Record actual dominant material before work; the shared structural and damage-preservation rules apply.

**Exact source components:**

| Occurrence | Component | Quantity | Tier | Role / consumed | Unit mass | Unit source value | Required properties |
|---|---|---:|---:|---|---:|---:|---|
| 0 | Heartsteel Ingot | 1 | 1 | substrate / true | 1 lb | 2 gp | substrate |
| 1 | Forge water | 1 | 1 | tool / false | 25 lb | 6 gp | tool |
| 2 | Brightsteel Ingot | 3 | 1 | substrate / true | 1 lb | 2 gp | substrate |
| 3 | black dragon scale | 1 | 1 | material / true | 0.43 lb | 8 gp | acid, draconic, protective, rigid |

**Work:** STR or INT under the shared crafting check; Forge and Anvil; tools: Smith's tools, Forge, Anvil, Tongs. Maximum assistants 0; fieldCraftable=false, preserved timeMode=field. The false field flag controls: an actual Forge-and-Anvil worksite is still required. Ordinary first stable phase 2 active hour(s), included in total. An eligible Forge Dwarf uses 90 actual active minutes, first phase 90 minutes; no extra time reduction from assistants.

**Results:** Standard 2; Exceptional yield 2; Masterwork yield 3; structural option 2 with strongest noncompounding 25%/50% durability layer. Flawed: 1 ordinary-effect units with existing durability state preserved. Failed/Mishap transforms no base; source ingredient recovery/loss still applies. Masterwork returns at most one eligible consumed catalyst unit total, never one per occurrence or finished item.

**Repair:** functioning HP≥1 uses trained Smith's tools, actual Forge/Anvil/Tongs, STR/INT DC10, max(1 hour, actual max HP/10 hours), materials 25% mundane size/grade base value. HP0 with recoverable main body uses original recipe DC 8, max(8 hours, actual max HP/10 hours), materials 25% undamaged finished unit reference. Both are binary repair tasks; no formula/trade-level entitlement required or granted, no creation-only time reduction, crafting XP, quality roll or catalyst. Existing grade, durability state and flaw persist.

**Reference accounting:** source magic/process share 36.5 gp per unit, plus the actual transformed base's undamaged mundane size/grade reference. Real owned bases need no repurchase; purchased reserves are separate expenses. No automatic artifact multiplier, quality markup or guaranteed mundane-table magic buyback.

**Source access:** {"sources":["trainer","starter manual","common experimentation"],"minimumResearchHours":0,"requiresFormula":false,"formulaConsumed":false}. Visibility and actual ingredient availability remain source-controlled.

**Preserved tags:** Stealth. **Operative tag:** Stealth. Secondary tags grant no additional mechanics.

**Preserved legacy (inactive):** {"legacyName": "Standard Mace", "legacyEffect": "Deals an extra 1d4 damage of a specific type"}.

## recipe-56 — Superior Grave Axe of Infernal Marrow

**Source:** public; Blacksmithing level 5; tier 3; Uncommon; crafting DC 17; 1 day / 8 active hours; Standard quantity 1. Source Standard batch reference 471 gp.

**Preserved effect:** Creates a durable axe with +1 to attack and damage rolls.

**Operational effect:** One actual axe base becomes an intact magical nonartifact output. With this weapon's actual attacks, use recipe +1 in the item-accuracy family and add +1 once to ordinary weapon-hit damage. Legal thrown/off-hand attacks retain these benefits; carrying it does not. Unsuppressed ordinary B/P/S counts magical. No elemental damage rider is granted by its title, ingredient or tag. Broken stops positive functions; suppression stops recipe magic only. The complete base, quality, repair and value rules apply.

**Legal base models:** Handaxe, Battleaxe, Greataxe. Choose one model, size and actual legal equipment grade for the whole batch before work.

**Physical reserve:** 1 complete legal mundane bases, ordered before work. Transform the first resolved N; keep original inventory identity, actual grade/material/damage and source access. All source ingredients below are additional inputs; none supplies a free body.

| Base model | Ordinary Standard price | Weight | Ordinary max HP | Actual base combat profile | Finished unit reference with this ordinary base |
|---|---:|---:|---:|---|---:|
| Handaxe | 5 gp | 2 lb | 5 | 1d6 slashing; Light, thrown (range 20/60) | 476 gp |
| Battleaxe | 10 gp | 4 lb | 5 | 1d8 slashing; Versatile (1d10) | 481 gp |
| Greataxe | 30 gp | 7 lb | 5 | 1d12 slashing; Heavy, two-handed | 501 gp |

These are Small/Medium/Tiny ordinary Standard examples, not automatic item grants or material-AC assignments. Actual bases retain the complete equipment profile, requirements and legitimate size/grade valuation. Large doubles base price/weight/ordinary HP, not the source magic/process share. Record actual dominant material before work; the shared structural and damage-preservation rules apply.

**Exact source components:**

| Occurrence | Component | Quantity | Tier | Role / consumed | Unit mass | Unit source value | Required properties |
|---|---|---:|---:|---|---:|---:|---|
| 0 | Forge water | 1 | 3 | tool / false | 25 lb | 75 gp | tool |
| 1 | Brightsteel Ingot | 4 | 3 | substrate / true | 1 lb | 25 gp | substrate |
| 2 | Iron ingot | 5 | 3 | substrate / true | 1 lb | 25 gp | substrate |
| 3 | infernal marrow | 1 | 3 | material / true | 0.18 lb | 109 gp | specialized, unholy, vital |

**Work:** STR or INT under the shared crafting check; Forge and Anvil; tools: Smith's tools, Forge, Anvil, Tongs. Maximum assistants 0; fieldCraftable=false, preserved timeMode=expedition. The false field flag controls: an actual Forge-and-Anvil worksite is still required. Ordinary first stable phase 8 active hour(s), included in total. An eligible Forge Dwarf uses 360 actual active minutes, first phase 360 minutes; no extra time reduction from assistants.

**Results:** Standard 1; Exceptional yield 1; Masterwork yield 1; structural option 1 with strongest noncompounding 25%/50% durability layer. Flawed: one unit establishing the single persistent half-maximum flaw after ordinary size/grade and strongest durability improvement; preserve damage deficit, possibly emerging Broken. Failed/Mishap transforms no base; source ingredient recovery/loss still applies. Masterwork returns at most one eligible consumed catalyst unit total, never one per occurrence or finished item.

**Repair:** functioning HP≥1 uses trained Smith's tools, actual Forge/Anvil/Tongs, STR/INT DC10, max(1 hour, actual max HP/10 hours), materials 25% mundane size/grade base value. HP0 with recoverable main body uses original recipe DC 17, max(8 hours, actual max HP/10 hours), materials 25% undamaged finished unit reference. Both are binary repair tasks; no formula/trade-level entitlement required or granted, no creation-only time reduction, crafting XP, quality roll or catalyst. Existing grade, durability state and flaw persist.

**Reference accounting:** source magic/process share 471 gp per unit, plus the actual transformed base's undamaged mundane size/grade reference. Real owned bases need no repurchase; purchased reserves are separate expenses. No automatic artifact multiplier, quality markup or guaranteed mundane-table magic buyback.

**Source access:** {"sources":["guild trainer","faction vendor","uncommon dungeon book","reverse engineering"],"minimumResearchHours":0,"requiresFormula":true,"formulaConsumed":false}. Visibility and actual ingredient availability remain source-controlled.

**Preserved tags:** Unholy. **Operative tag:** Unholy. Secondary tags grant no additional mechanics.

**Preserved legacy (inactive):** {"legacyName": "Refined Axe", "legacyEffect": "+2 to attack and damage rolls"}.

## recipe-57 — Masterwork Vital Shield of Putrid Marrow

**Source:** public; Blacksmithing level 7; tier 4; Uncommon; crafting DC 17; 2 days / 16 active hours; Standard quantity 1. Source Standard batch reference 1297 gp.

**Preserved effect:** Creates reinforced shield granting +1 AC.

**Operational effect:** One actual shield base becomes an intact magical nonartifact output. While legally equipped, offer +1 to equipment.defense-enhancement, using the strongest eligible recipe/suit-grade modifier; retain the base suit formula or shield contribution where applicable. No resistance is granted by its title, ingredient or tag. Broken stops positive functions; suppression stops recipe magic only. The complete base, quality, repair and value rules apply.

**Legal base models:** Buckler, Shield, Tower shield. Choose one model, size and actual legal equipment grade for the whole batch before work.

**Physical reserve:** 1 complete legal mundane bases, ordered before work. Transform the first resolved N; keep original inventory identity, actual grade/material/damage and source access. All source ingredients below are additional inputs; none supplies a free body.

| Base model | Ordinary Standard price | Weight | Ordinary max HP | Actual base combat profile | Finished unit reference with this ordinary base |
|---|---:|---:|---:|---|---:|
| Buckler | 5 gp | 3 lb | 10 | +1 | 1302 gp |
| Shield | 10 gp | 6 lb | 10 | +2 | 1307 gp |
| Tower shield | 50 gp | 15 lb | 15 | +3 | 1347 gp |

These are Small/Medium/Tiny ordinary Standard examples, not automatic item grants or material-AC assignments. Actual bases retain the complete equipment profile, requirements and legitimate size/grade valuation. Large doubles base price/weight/ordinary HP, not the source magic/process share. Record actual dominant material before work; the shared structural and damage-preservation rules apply.

**Exact source components:**

| Occurrence | Component | Quantity | Tier | Role / consumed | Unit mass | Unit source value | Required properties |
|---|---|---:|---:|---|---:|---:|---|
| 0 | Wood handle | 2 | 4 | substrate / true | 0.1 lb | 75 gp | substrate |
| 1 | Metal rivets | 5 | 4 | binder / true | 0.1 lb | 75 gp | binder |
| 2 | Coal | 5 | 4 | fuel / true | 1 lb | 75 gp | fuel |
| 3 | putrid marrow | 1 | 2 | material / true | 0.18 lb | 19 gp | specialized, vital |

**Work:** STR or INT under the shared crafting check; Forge and Anvil; tools: Smith's tools, Forge, Anvil, Tongs. Maximum assistants 0; fieldCraftable=false, preserved timeMode=workshop. The false field flag controls: an actual Forge-and-Anvil worksite is still required. Ordinary first stable phase 8 active hour(s), included in total. An eligible Forge Dwarf uses 720 actual active minutes, first phase 480 minutes; no extra time reduction from assistants.

**Results:** Standard 1; Exceptional yield 1; Masterwork yield 1; structural option 1 with strongest noncompounding 25%/50% durability layer. Flawed: one unit establishing the single persistent half-maximum flaw after ordinary size/grade and strongest durability improvement; preserve damage deficit, possibly emerging Broken. Failed/Mishap transforms no base; source ingredient recovery/loss still applies. Masterwork returns at most one eligible consumed catalyst unit total, never one per occurrence or finished item.

**Repair:** functioning HP≥1 uses trained Smith's tools, actual Forge/Anvil/Tongs, STR/INT DC10, max(1 hour, actual max HP/10 hours), materials 25% mundane size/grade base value. HP0 with recoverable main body uses original recipe DC 17, max(8 hours, actual max HP/10 hours), materials 25% undamaged finished unit reference. Both are binary repair tasks; no formula/trade-level entitlement required or granted, no creation-only time reduction, crafting XP, quality roll or catalyst. Existing grade, durability state and flaw persist.

**Reference accounting:** source magic/process share 1297 gp per unit, plus the actual transformed base's undamaged mundane size/grade reference. Real owned bases need no repurchase; purchased reserves are separate expenses. No automatic artifact multiplier, quality markup or guaranteed mundane-table magic buyback.

**Source access:** {"sources":["guild trainer","faction vendor","uncommon dungeon book","reverse engineering"],"minimumResearchHours":0,"requiresFormula":true,"formulaConsumed":false}. Visibility and actual ingredient availability remain source-controlled.

**Preserved tags:** Vitality. **Operative tag:** Vitality. Secondary tags grant no additional mechanics.

**Preserved legacy (inactive):** {"legacyName": "Steel Shield", "legacyEffect": "Deals an extra 1d6 damage of a specific type"}.

## recipe-58 — Superior Ember Weapon of Red Dragon Talon

**Source:** public; Blacksmithing level 6; tier 3; Uncommon; crafting DC 14; 3 days / 24 active hours; Standard quantity 1. Source Standard batch reference 607 gp.

**Preserved effect:** Creates a durable weapon with +1 to attack and damage rolls.

**Operational effect:** One actual weapon base becomes an intact magical nonartifact output. With this weapon's actual attacks, use recipe +1 in the item-accuracy family and add +1 once to ordinary weapon-hit damage. Legal thrown/off-hand attacks retain these benefits; carrying it does not. Unsuppressed ordinary B/P/S counts magical. No elemental damage rider is granted by its title, ingredient or tag. Broken stops positive functions; suppression stops recipe magic only. The complete base, quality, repair and value rules apply.

**Legal base models:** Dagger, Dart, Handaxe, Javelin, Light hammer, Mace, Sickle, Spear, Battleaxe, Flail, Glaive, Greataxe, Greatsword, Halberd, Lance, Longsword, Maul, Morningstar, Pike, Rapier, Scimitar, Shortsword, Trident, War pick, Warhammer, Kama. Choose one model, size and actual legal equipment grade for the whole batch before work.

**Physical reserve:** 1 complete legal mundane bases, ordered before work. Transform the first resolved N; keep original inventory identity, actual grade/material/damage and source access. All source ingredients below are additional inputs; none supplies a free body.

| Base model | Ordinary Standard price | Weight | Ordinary max HP | Actual base combat profile | Finished unit reference with this ordinary base |
|---|---:|---:|---:|---|---:|
| Dagger | 2 gp | 1 lb | 5 | 1d4 piercing; Finesse, light, thrown (range 20/60) | 609 gp |
| Dart | 0.05 gp | 0.25 lb | 5 | 1d4 piercing; Finesse, thrown (range 20/60) | 607.05 gp |
| Handaxe | 5 gp | 2 lb | 5 | 1d6 slashing; Light, thrown (range 20/60) | 612 gp |
| Javelin | 0.5 gp | 2 lb | 5 | 1d6 piercing; Thrown (range 30/120) | 607.5 gp |
| Light hammer | 2 gp | 2 lb | 5 | 1d4 bludgeoning; Light, thrown (range 20/60) | 609 gp |
| Mace | 5 gp | 4 lb | 5 | 1d6 bludgeoning; , | 612 gp |
| Sickle | 1 gp | 2 lb | 5 | 1d4 slashing; Light | 608 gp |
| Spear | 1 gp | 3 lb | 5 | 1d6 piercing; Thrown (range 20/60), versatile (1d8) | 608 gp |
| Battleaxe | 10 gp | 4 lb | 5 | 1d8 slashing; Versatile (1d10) | 617 gp |
| Flail | 10 gp | 2 lb | 5 | 1d8 bludgeoning; , | 617 gp |
| Glaive | 20 gp | 6 lb | 5 | 1d10 slashing; Heavy, reach, two-handed | 627 gp |
| Greataxe | 30 gp | 7 lb | 5 | 1d12 slashing; Heavy, two-handed | 637 gp |
| Greatsword | 50 gp | 6 lb | 5 | 2d6 slashing; Heavy, two-handed | 657 gp |
| Halberd | 20 gp | 6 lb | 5 | 1d10 slashing; Heavy, reach, two-handed | 627 gp |
| Lance | 10 gp | 6 lb | 5 | 1d12 piercing; Reach, special | 617 gp |
| Longsword | 15 gp | 3 lb | 5 | 1d8 slashing; Versatile (1d10) | 622 gp |
| Maul | 10 gp | 10 lb | 5 | 2d6 bludgeoning; Heavy, two-handed | 617 gp |
| Morningstar | 15 gp | 4 lb | 5 | 1d8 piercing; , | 622 gp |
| Pike | 5 gp | 18 lb | 5 | 1d10 piercing; Heavy, reach, two-handed | 612 gp |
| Rapier | 25 gp | 2 lb | 5 | 1d8 piercing; Finesse | 632 gp |
| Scimitar | 25 gp | 3 lb | 5 | 1d6 slashing; Finesse, light | 632 gp |
| Shortsword | 10 gp | 2 lb | 5 | 1d6 piercing; Finesse, light | 617 gp |
| Trident | 5 gp | 4 lb | 5 | 1d6 piercing; Thrown (range 20/60), versatile (1d8) | 612 gp |
| War pick | 5 gp | 2 lb | 5 | 1d8 piercing; , | 612 gp |
| Warhammer | 15 gp | 2 lb | 5 | 1d8 bludgeoning; Versatile (1d10) | 622 gp |
| Kama | 2 gp | 2 lb | 5 | 1d4 slashing; Light | 609 gp |

These are Small/Medium/Tiny ordinary Standard examples, not automatic item grants or material-AC assignments. Actual bases retain the complete equipment profile, requirements and legitimate size/grade valuation. Large doubles base price/weight/ordinary HP, not the source magic/process share. Record actual dominant material before work; the shared structural and damage-preservation rules apply.

**Exact source components:**

| Occurrence | Component | Quantity | Tier | Role / consumed | Unit mass | Unit source value | Required properties |
|---|---|---:|---:|---|---:|---:|---|
| 0 | Iron ingot | 4 | 3 | substrate / true | 1 lb | 25 gp | substrate |
| 1 | Steel ingot | 5 | 3 | substrate / true | 1 lb | 25 gp | substrate |
| 2 | Tempering oil | 2 | 3 | solvent / true | 0.5 lb | 25 gp | solvent |
| 3 | Leather strips | 4 | 3 | substrate / true | 0.25 lb | 25 gp | substrate |
| 4 | red dragon talon | 1 | 2 | material / true | 0.16 lb | 21 gp | draconic, fire, rigid, structural |

**Work:** STR or INT under the shared crafting check; Forge and Anvil; tools: Smith's tools, Forge, Anvil, Tongs. Maximum assistants 0; fieldCraftable=false, preserved timeMode=workshop. The false field flag controls: an actual Forge-and-Anvil worksite is still required. Ordinary first stable phase 8 active hour(s), included in total. An eligible Forge Dwarf uses 1080 actual active minutes, first phase 480 minutes; no extra time reduction from assistants.

**Results:** Standard 1; Exceptional yield 1; Masterwork yield 1; structural option 1 with strongest noncompounding 25%/50% durability layer. Flawed: one unit establishing the single persistent half-maximum flaw after ordinary size/grade and strongest durability improvement; preserve damage deficit, possibly emerging Broken. Failed/Mishap transforms no base; source ingredient recovery/loss still applies. Masterwork returns at most one eligible consumed catalyst unit total, never one per occurrence or finished item.

**Repair:** functioning HP≥1 uses trained Smith's tools, actual Forge/Anvil/Tongs, STR/INT DC10, max(1 hour, actual max HP/10 hours), materials 25% mundane size/grade base value. HP0 with recoverable main body uses original recipe DC 14, max(8 hours, actual max HP/10 hours), materials 25% undamaged finished unit reference. Both are binary repair tasks; no formula/trade-level entitlement required or granted, no creation-only time reduction, crafting XP, quality roll or catalyst. Existing grade, durability state and flaw persist.

**Reference accounting:** source magic/process share 607 gp per unit, plus the actual transformed base's undamaged mundane size/grade reference. Real owned bases need no repurchase; purchased reserves are separate expenses. No automatic artifact multiplier, quality markup or guaranteed mundane-table magic buyback.

**Source access:** {"sources":["guild trainer","faction vendor","uncommon dungeon book","reverse engineering"],"minimumResearchHours":0,"requiresFormula":true,"formulaConsumed":false}. Visibility and actual ingredient availability remain source-controlled.

**Preserved tags:** Fire. **Operative tag:** Fire. Secondary tags grant no additional mechanics.

**Preserved legacy (inactive):** {"legacyName": "Chain of Tempered Superiorness", "legacyEffect": "AC 16 + Dex modifier (medium armor)"}.

## recipe-59 — Superior Ember Mace of Fire Bone

**Source:** public; Blacksmithing level 6; tier 3; Uncommon; crafting DC 15; 2 days / 16 active hours; Standard quantity 1. Source Standard batch reference 412 gp.

**Preserved effect:** Creates a durable mace with +1 to attack and damage rolls.

**Operational effect:** One actual mace base becomes an intact magical nonartifact output. With this weapon's actual attacks, use recipe +1 in the item-accuracy family and add +1 once to ordinary weapon-hit damage. Legal thrown/off-hand attacks retain these benefits; carrying it does not. Unsuppressed ordinary B/P/S counts magical. No elemental damage rider is granted by its title, ingredient or tag. Broken stops positive functions; suppression stops recipe magic only. The complete base, quality, repair and value rules apply.

**Legal base models:** Mace, Flail, Morningstar. Choose one model, size and actual legal equipment grade for the whole batch before work.

**Physical reserve:** 1 complete legal mundane bases, ordered before work. Transform the first resolved N; keep original inventory identity, actual grade/material/damage and source access. All source ingredients below are additional inputs; none supplies a free body.

| Base model | Ordinary Standard price | Weight | Ordinary max HP | Actual base combat profile | Finished unit reference with this ordinary base |
|---|---:|---:|---:|---|---:|
| Mace | 5 gp | 4 lb | 5 | 1d6 bludgeoning; , | 417 gp |
| Flail | 10 gp | 2 lb | 5 | 1d8 bludgeoning; , | 422 gp |
| Morningstar | 15 gp | 4 lb | 5 | 1d8 piercing; , | 427 gp |

These are Small/Medium/Tiny ordinary Standard examples, not automatic item grants or material-AC assignments. Actual bases retain the complete equipment profile, requirements and legitimate size/grade valuation. Large doubles base price/weight/ordinary HP, not the source magic/process share. Record actual dominant material before work; the shared structural and damage-preservation rules apply.

**Exact source components:**

| Occurrence | Component | Quantity | Tier | Role / consumed | Unit mass | Unit source value | Required properties |
|---|---|---:|---:|---|---:|---:|---|
| 0 | Heartsteel Ingot | 5 | 3 | substrate / true | 1 lb | 25 gp | substrate |
| 1 | Tempering oil | 4 | 3 | solvent / true | 0.5 lb | 25 gp | solvent |
| 2 | Fire bone shard | 1 | 2 | material / true | 0.33 lb | 45 gp | fire, rigid, structural |

**Work:** STR or INT under the shared crafting check; Forge and Anvil; tools: Smith's tools, Forge, Anvil, Tongs. Maximum assistants 0; fieldCraftable=false, preserved timeMode=workshop. The false field flag controls: an actual Forge-and-Anvil worksite is still required. Ordinary first stable phase 8 active hour(s), included in total. An eligible Forge Dwarf uses 720 actual active minutes, first phase 480 minutes; no extra time reduction from assistants.

**Results:** Standard 1; Exceptional yield 1; Masterwork yield 1; structural option 1 with strongest noncompounding 25%/50% durability layer. Flawed: one unit establishing the single persistent half-maximum flaw after ordinary size/grade and strongest durability improvement; preserve damage deficit, possibly emerging Broken. Failed/Mishap transforms no base; source ingredient recovery/loss still applies. Masterwork returns at most one eligible consumed catalyst unit total, never one per occurrence or finished item.

**Repair:** functioning HP≥1 uses trained Smith's tools, actual Forge/Anvil/Tongs, STR/INT DC10, max(1 hour, actual max HP/10 hours), materials 25% mundane size/grade base value. HP0 with recoverable main body uses original recipe DC 15, max(8 hours, actual max HP/10 hours), materials 25% undamaged finished unit reference. Both are binary repair tasks; no formula/trade-level entitlement required or granted, no creation-only time reduction, crafting XP, quality roll or catalyst. Existing grade, durability state and flaw persist.

**Reference accounting:** source magic/process share 412 gp per unit, plus the actual transformed base's undamaged mundane size/grade reference. Real owned bases need no repurchase; purchased reserves are separate expenses. No automatic artifact multiplier, quality markup or guaranteed mundane-table magic buyback.

**Source access:** {"sources":["guild trainer","faction vendor","uncommon dungeon book","reverse engineering"],"minimumResearchHours":0,"requiresFormula":true,"formulaConsumed":false}. Visibility and actual ingredient availability remain source-controlled.

**Preserved tags:** Fire. **Operative tag:** Fire. Secondary tags grant no additional mechanics.

**Preserved legacy (inactive):** {"legacyName": "Mace of Steel Enhancedness", "legacyEffect": "+2 to attack and damage rolls"}.

## recipe-60 — Masterwork Vital Gauntlets of Putrid Marrow

**Source:** public; Blacksmithing level 8; tier 4; Uncommon; crafting DC 17; 1 day / 8 active hours; Standard quantity 1. Source Standard batch reference 868 gp.

**Preserved effect:** Creates reinforced gauntlets granting +1 AC.

**Operational effect:** One actual matched Gauntlets pair becomes one intact magical nonartifact output. While legally equipped, offer +1 to equipment.defense-enhancement, using the strongest eligible recipe/suit-grade modifier; retain the base suit formula or shield contribution where applicable. No resistance is granted by its title, ingredient or tag. Broken stops positive functions; suppression stops recipe magic only. The complete base, quality, repair and value rules apply.

**Legal base models:** Gauntlets blank. Choose one model, size and actual legal equipment grade for the whole batch before work.

**Physical reserve:** 1 complete legal mundane bases, ordered before work. Transform the first resolved N; keep original inventory identity, actual grade/material/damage and source access. All source ingredients below are additional inputs; none supplies a free body.

| Base model | Ordinary Standard price | Weight | Ordinary max HP | Actual base combat profile | Finished unit reference with this ordinary base |
|---|---:|---:|---:|---|---:|
| Gauntlets blank | 10 gp | 4 lb | 5 | No mundane AC bonus; recipe supplies actual enhancement/resistance. | 878 gp |

These are Small/Medium/Tiny ordinary Standard examples, not automatic item grants or material-AC assignments. Actual bases retain the complete equipment profile, requirements and legitimate size/grade valuation. Large doubles base price/weight/ordinary HP, not the source magic/process share. Record actual dominant material before work; the shared structural and damage-preservation rules apply.

**Exact source components:**

| Occurrence | Component | Quantity | Tier | Role / consumed | Unit mass | Unit source value | Required properties |
|---|---|---:|---:|---|---:|---:|---|
| 0 | Brightsteel Ingot | 1 | 4 | substrate / true | 1 lb | 75 gp | substrate |
| 1 | Forge water | 1 | 4 | tool / false | 25 lb | 225 gp | tool |
| 2 | Leather strips | 3 | 4 | substrate / true | 0.25 lb | 75 gp | substrate |
| 3 | Iron ingot | 4 | 4 | substrate / true | 1 lb | 75 gp | substrate |
| 4 | putrid marrow | 1 | 2 | material / true | 0.18 lb | 19 gp | specialized, vital |

**Work:** STR or INT under the shared crafting check; Forge and Anvil; tools: Smith's tools, Forge, Anvil, Tongs. Maximum assistants 0; fieldCraftable=false, preserved timeMode=expedition. The false field flag controls: an actual Forge-and-Anvil worksite is still required. Ordinary first stable phase 8 active hour(s), included in total. An eligible Forge Dwarf uses 360 actual active minutes, first phase 360 minutes; no extra time reduction from assistants.

**Results:** Standard 1; Exceptional yield 1; Masterwork yield 1; structural option 1 with strongest noncompounding 25%/50% durability layer. Flawed: one unit establishing the single persistent half-maximum flaw after ordinary size/grade and strongest durability improvement; preserve damage deficit, possibly emerging Broken. Failed/Mishap transforms no base; source ingredient recovery/loss still applies. Masterwork returns at most one eligible consumed catalyst unit total, never one per occurrence or finished item.

**Repair:** functioning HP≥1 uses trained Smith's tools, actual Forge/Anvil/Tongs, STR/INT DC10, max(1 hour, actual max HP/10 hours), materials 25% mundane size/grade base value. HP0 with recoverable main body uses original recipe DC 17, max(8 hours, actual max HP/10 hours), materials 25% undamaged finished unit reference. Both are binary repair tasks; no formula/trade-level entitlement required or granted, no creation-only time reduction, crafting XP, quality roll or catalyst. Existing grade, durability state and flaw persist.

**Reference accounting:** source magic/process share 868 gp per unit, plus the actual transformed base's undamaged mundane size/grade reference. Real owned bases need no repurchase; purchased reserves are separate expenses. No automatic artifact multiplier, quality markup or guaranteed mundane-table magic buyback.

**Source access:** {"sources":["guild trainer","faction vendor","uncommon dungeon book","reverse engineering"],"minimumResearchHours":0,"requiresFormula":true,"formulaConsumed":false}. Visibility and actual ingredient availability remain source-controlled.

**Preserved tags:** Vitality. **Operative tag:** Vitality. Secondary tags grant no additional mechanics.

**Preserved legacy (inactive):** {"legacyName": "Gauntlets of Forged Improvedness", "legacyEffect": "+2 to attack and damage rolls"}.

## recipe-61 — Masterwork Resonant Helm of Elemental Core

**Source:** public; Blacksmithing level 7; tier 4; Uncommon; crafting DC 13; 1 day / 8 active hours; Standard quantity 1. Source Standard batch reference 1155 gp.

**Preserved effect:** Creates reinforced helm granting +1 AC.

**Operational effect:** One actual helm base becomes an intact magical nonartifact output. While legally equipped, offer +1 to equipment.defense-enhancement, using the strongest eligible recipe/suit-grade modifier; retain the base suit formula or shield contribution where applicable. No resistance is granted by its title, ingredient or tag. Broken stops positive functions; suppression stops recipe magic only. The complete base, quality, repair and value rules apply.

**Legal base models:** Helm blank. Choose one model, size and actual legal equipment grade for the whole batch before work.

**Physical reserve:** 1 complete legal mundane bases, ordered before work. Transform the first resolved N; keep original inventory identity, actual grade/material/damage and source access. All source ingredients below are additional inputs; none supplies a free body.

| Base model | Ordinary Standard price | Weight | Ordinary max HP | Actual base combat profile | Finished unit reference with this ordinary base |
|---|---:|---:|---:|---|---:|
| Helm blank | 10 gp | 5 lb | 5 | No mundane AC bonus; recipe supplies actual enhancement/resistance. | 1165 gp |

These are Small/Medium/Tiny ordinary Standard examples, not automatic item grants or material-AC assignments. Actual bases retain the complete equipment profile, requirements and legitimate size/grade valuation. Large doubles base price/weight/ordinary HP, not the source magic/process share. Record actual dominant material before work; the shared structural and damage-preservation rules apply.

**Exact source components:**

| Occurrence | Component | Quantity | Tier | Role / consumed | Unit mass | Unit source value | Required properties |
|---|---|---:|---:|---|---:|---:|---|
| 0 | Coal | 4 | 4 | fuel / true | 1 lb | 75 gp | fuel |
| 1 | Tempering oil | 2 | 4 | solvent / true | 0.5 lb | 75 gp | solvent |
| 2 | Leather strips | 3 | 4 | substrate / true | 0.25 lb | 75 gp | substrate |
| 3 | Metal rivets | 1 | 4 | binder / true | 0.1 lb | 75 gp | binder |
| 4 | elemental core fragment | 1 | 3 | material / true | 0.53 lb | 85 gp | arcane, resonant, rigid |

**Work:** STR or INT under the shared crafting check; Forge and Anvil; tools: Smith's tools, Forge, Anvil, Tongs. Maximum assistants 0; fieldCraftable=false, preserved timeMode=expedition. The false field flag controls: an actual Forge-and-Anvil worksite is still required. Ordinary first stable phase 8 active hour(s), included in total. An eligible Forge Dwarf uses 360 actual active minutes, first phase 360 minutes; no extra time reduction from assistants.

**Results:** Standard 1; Exceptional yield 1; Masterwork yield 1; structural option 1 with strongest noncompounding 25%/50% durability layer. Flawed: one unit establishing the single persistent half-maximum flaw after ordinary size/grade and strongest durability improvement; preserve damage deficit, possibly emerging Broken. Failed/Mishap transforms no base; source ingredient recovery/loss still applies. Masterwork returns at most one eligible consumed catalyst unit total, never one per occurrence or finished item.

**Repair:** functioning HP≥1 uses trained Smith's tools, actual Forge/Anvil/Tongs, STR/INT DC10, max(1 hour, actual max HP/10 hours), materials 25% mundane size/grade base value. HP0 with recoverable main body uses original recipe DC 13, max(8 hours, actual max HP/10 hours), materials 25% undamaged finished unit reference. Both are binary repair tasks; no formula/trade-level entitlement required or granted, no creation-only time reduction, crafting XP, quality roll or catalyst. Existing grade, durability state and flaw persist.

**Reference accounting:** source magic/process share 1155 gp per unit, plus the actual transformed base's undamaged mundane size/grade reference. Real owned bases need no repurchase; purchased reserves are separate expenses. No automatic artifact multiplier, quality markup or guaranteed mundane-table magic buyback.

**Source access:** {"sources":["guild trainer","faction vendor","uncommon dungeon book","reverse engineering"],"minimumResearchHours":0,"requiresFormula":true,"formulaConsumed":false}. Visibility and actual ingredient availability remain source-controlled.

**Preserved tags:** Arcane. **Operative tag:** Arcane. Secondary tags grant no additional mechanics.

**Preserved legacy (inactive):** {"legacyName": "Refined Helmet", "legacyEffect": "AC 16 + Dex modifier (medium armor)"}.

## recipe-62 — Superior Grave Gauntlets of Demonic Talon

**Source:** public; Blacksmithing level 6; tier 3; Uncommon; crafting DC 15; 1 day / 8 active hours; Standard quantity 1. Source Standard batch reference 656 gp.

**Preserved effect:** Creates reinforced gauntlets granting +1 AC.

**Operational effect:** One actual matched Gauntlets pair becomes one intact magical nonartifact output. While legally equipped, offer +1 to equipment.defense-enhancement, using the strongest eligible recipe/suit-grade modifier; retain the base suit formula or shield contribution where applicable. No resistance is granted by its title, ingredient or tag. Broken stops positive functions; suppression stops recipe magic only. The complete base, quality, repair and value rules apply.

**Legal base models:** Gauntlets blank. Choose one model, size and actual legal equipment grade for the whole batch before work.

**Physical reserve:** 1 complete legal mundane bases, ordered before work. Transform the first resolved N; keep original inventory identity, actual grade/material/damage and source access. All source ingredients below are additional inputs; none supplies a free body.

| Base model | Ordinary Standard price | Weight | Ordinary max HP | Actual base combat profile | Finished unit reference with this ordinary base |
|---|---:|---:|---:|---|---:|
| Gauntlets blank | 10 gp | 4 lb | 5 | No mundane AC bonus; recipe supplies actual enhancement/resistance. | 666 gp |

These are Small/Medium/Tiny ordinary Standard examples, not automatic item grants or material-AC assignments. Actual bases retain the complete equipment profile, requirements and legitimate size/grade valuation. Large doubles base price/weight/ordinary HP, not the source magic/process share. Record actual dominant material before work; the shared structural and damage-preservation rules apply.

**Exact source components:**

| Occurrence | Component | Quantity | Tier | Role / consumed | Unit mass | Unit source value | Required properties |
|---|---|---:|---:|---|---:|---:|---|
| 0 | Wood handle | 5 | 3 | substrate / true | 0.1 lb | 25 gp | substrate |
| 1 | Brightsteel Ingot | 2 | 3 | substrate / true | 1 lb | 25 gp | substrate |
| 2 | demonic talon | 1 | 4 | material / true | 0.11 lb | 293 gp | rigid, structural, unholy |

**Work:** STR or INT under the shared crafting check; Forge and Anvil; tools: Smith's tools, Forge, Anvil, Tongs. Maximum assistants 0; fieldCraftable=false, preserved timeMode=expedition. The false field flag controls: an actual Forge-and-Anvil worksite is still required. Ordinary first stable phase 8 active hour(s), included in total. An eligible Forge Dwarf uses 360 actual active minutes, first phase 360 minutes; no extra time reduction from assistants.

**Results:** Standard 1; Exceptional yield 1; Masterwork yield 1; structural option 1 with strongest noncompounding 25%/50% durability layer. Flawed: one unit establishing the single persistent half-maximum flaw after ordinary size/grade and strongest durability improvement; preserve damage deficit, possibly emerging Broken. Failed/Mishap transforms no base; source ingredient recovery/loss still applies. Masterwork returns at most one eligible consumed catalyst unit total, never one per occurrence or finished item.

**Repair:** functioning HP≥1 uses trained Smith's tools, actual Forge/Anvil/Tongs, STR/INT DC10, max(1 hour, actual max HP/10 hours), materials 25% mundane size/grade base value. HP0 with recoverable main body uses original recipe DC 15, max(8 hours, actual max HP/10 hours), materials 25% undamaged finished unit reference. Both are binary repair tasks; no formula/trade-level entitlement required or granted, no creation-only time reduction, crafting XP, quality roll or catalyst. Existing grade, durability state and flaw persist.

**Reference accounting:** source magic/process share 656 gp per unit, plus the actual transformed base's undamaged mundane size/grade reference. Real owned bases need no repurchase; purchased reserves are separate expenses. No automatic artifact multiplier, quality markup or guaranteed mundane-table magic buyback.

**Source access:** {"sources":["guild trainer","faction vendor","uncommon dungeon book","reverse engineering"],"minimumResearchHours":0,"requiresFormula":true,"formulaConsumed":false}. Visibility and actual ingredient availability remain source-controlled.

**Preserved tags:** Unholy. **Operative tag:** Unholy. Secondary tags grant no additional mechanics.

**Preserved legacy (inactive):** {"legacyName": "Dwarven Gauntlets", "legacyEffect": "Deals an extra 1d6 damage of a specific type"}.

## recipe-63 — Exalted Stone Spear of Brimstone Bone

**Source:** public; Blacksmithing level 9; tier 5; Uncommon; crafting DC 17; 3 days / 24 active hours; Standard quantity 1. Source Standard batch reference 4825 gp.

**Preserved effect:** Creates a durable spear with +1 to attack and damage rolls.

**Operational effect:** One actual spear base becomes an intact magical nonartifact output. With this weapon's actual attacks, use recipe +1 in the item-accuracy family and add +1 once to ordinary weapon-hit damage. Legal thrown/off-hand attacks retain these benefits; carrying it does not. Unsuppressed ordinary B/P/S counts magical. No elemental damage rider is granted by its title, ingredient or tag. Broken stops positive functions; suppression stops recipe magic only. The complete base, quality, repair and value rules apply.

**Legal base models:** Spear, Javelin, Trident, Pike, Lance. Choose one model, size and actual legal equipment grade for the whole batch before work.

**Physical reserve:** 1 complete legal mundane bases, ordered before work. Transform the first resolved N; keep original inventory identity, actual grade/material/damage and source access. All source ingredients below are additional inputs; none supplies a free body.

| Base model | Ordinary Standard price | Weight | Ordinary max HP | Actual base combat profile | Finished unit reference with this ordinary base |
|---|---:|---:|---:|---|---:|
| Spear | 1 gp | 3 lb | 5 | 1d6 piercing; Thrown (range 20/60), versatile (1d8) | 4826 gp |
| Javelin | 0.5 gp | 2 lb | 5 | 1d6 piercing; Thrown (range 30/120) | 4825.5 gp |
| Trident | 5 gp | 4 lb | 5 | 1d6 piercing; Thrown (range 20/60), versatile (1d8) | 4830 gp |
| Pike | 5 gp | 18 lb | 5 | 1d10 piercing; Heavy, reach, two-handed | 4830 gp |
| Lance | 10 gp | 6 lb | 5 | 1d12 piercing; Reach, special | 4835 gp |

These are Small/Medium/Tiny ordinary Standard examples, not automatic item grants or material-AC assignments. Actual bases retain the complete equipment profile, requirements and legitimate size/grade valuation. Large doubles base price/weight/ordinary HP, not the source magic/process share. Record actual dominant material before work; the shared structural and damage-preservation rules apply.

**Exact source components:**

| Occurrence | Component | Quantity | Tier | Role / consumed | Unit mass | Unit source value | Required properties |
|---|---|---:|---:|---|---:|---:|---|
| 0 | Heartsteel Ingot | 3 | 5 | substrate / true | 1 lb | 200 gp | substrate |
| 1 | Steel ingot | 4 | 5 | substrate / true | 1 lb | 200 gp | substrate |
| 2 | Wood handle | 5 | 5 | substrate / true | 0.1 lb | 200 gp | substrate |
| 3 | Iron ingot | 5 | 5 | substrate / true | 1 lb | 200 gp | substrate |
| 4 | brimstone bone | 1 | 3 | material / true | 0.44 lb | 94 gp | earth, fire, rigid, structural |

**Work:** STR or INT under the shared crafting check; Forge and Anvil; tools: Smith's tools, Forge, Anvil, Tongs. Maximum assistants 0; fieldCraftable=false, preserved timeMode=workshop. The false field flag controls: an actual Forge-and-Anvil worksite is still required. Ordinary first stable phase 8 active hour(s), included in total. An eligible Forge Dwarf uses 1080 actual active minutes, first phase 480 minutes; no extra time reduction from assistants.

**Results:** Standard 1; Exceptional yield 1; Masterwork yield 1; structural option 1 with strongest noncompounding 25%/50% durability layer. Flawed: one unit establishing the single persistent half-maximum flaw after ordinary size/grade and strongest durability improvement; preserve damage deficit, possibly emerging Broken. Failed/Mishap transforms no base; source ingredient recovery/loss still applies. Masterwork returns at most one eligible consumed catalyst unit total, never one per occurrence or finished item.

**Repair:** functioning HP≥1 uses trained Smith's tools, actual Forge/Anvil/Tongs, STR/INT DC10, max(1 hour, actual max HP/10 hours), materials 25% mundane size/grade base value. HP0 with recoverable main body uses original recipe DC 17, max(8 hours, actual max HP/10 hours), materials 25% undamaged finished unit reference. Both are binary repair tasks; no formula/trade-level entitlement required or granted, no creation-only time reduction, crafting XP, quality roll or catalyst. Existing grade, durability state and flaw persist.

**Reference accounting:** source magic/process share 4825 gp per unit, plus the actual transformed base's undamaged mundane size/grade reference. Real owned bases need no repurchase; purchased reserves are separate expenses. No automatic artifact multiplier, quality markup or guaranteed mundane-table magic buyback.

**Source access:** {"sources":["rare recipe drop","specialist commission","dungeon library","successful experimentation"],"minimumResearchHours":4,"requiresFormula":true,"formulaConsumed":false}. Visibility and actual ingredient availability remain source-controlled.

**Preserved tags:** Earth. **Operative tag:** Earth. Secondary tags grant no additional mechanics.

**Preserved legacy (inactive):** {"legacyName": "Tempered Spear", "legacyEffect": "+2 to attack and damage rolls"}.

## recipe-64 — Superior Tide Weapon of Sea Bone

**Source:** public; Blacksmithing level 6; tier 3; Uncommon; crafting DC 15; 1 day / 8 active hours; Standard quantity 1. Source Standard batch reference 314 gp.

**Preserved effect:** Creates a durable weapon with +1 to attack and damage rolls.

**Operational effect:** One actual weapon base becomes an intact magical nonartifact output. With this weapon's actual attacks, use recipe +1 in the item-accuracy family and add +1 once to ordinary weapon-hit damage. Legal thrown/off-hand attacks retain these benefits; carrying it does not. Unsuppressed ordinary B/P/S counts magical. No elemental damage rider is granted by its title, ingredient or tag. Broken stops positive functions; suppression stops recipe magic only. The complete base, quality, repair and value rules apply.

**Legal base models:** Dagger, Dart, Handaxe, Javelin, Light hammer, Mace, Sickle, Spear, Battleaxe, Flail, Glaive, Greataxe, Greatsword, Halberd, Lance, Longsword, Maul, Morningstar, Pike, Rapier, Scimitar, Shortsword, Trident, War pick, Warhammer, Kama. Choose one model, size and actual legal equipment grade for the whole batch before work.

**Physical reserve:** 1 complete legal mundane bases, ordered before work. Transform the first resolved N; keep original inventory identity, actual grade/material/damage and source access. All source ingredients below are additional inputs; none supplies a free body.

| Base model | Ordinary Standard price | Weight | Ordinary max HP | Actual base combat profile | Finished unit reference with this ordinary base |
|---|---:|---:|---:|---|---:|
| Dagger | 2 gp | 1 lb | 5 | 1d4 piercing; Finesse, light, thrown (range 20/60) | 316 gp |
| Dart | 0.05 gp | 0.25 lb | 5 | 1d4 piercing; Finesse, thrown (range 20/60) | 314.05 gp |
| Handaxe | 5 gp | 2 lb | 5 | 1d6 slashing; Light, thrown (range 20/60) | 319 gp |
| Javelin | 0.5 gp | 2 lb | 5 | 1d6 piercing; Thrown (range 30/120) | 314.5 gp |
| Light hammer | 2 gp | 2 lb | 5 | 1d4 bludgeoning; Light, thrown (range 20/60) | 316 gp |
| Mace | 5 gp | 4 lb | 5 | 1d6 bludgeoning; , | 319 gp |
| Sickle | 1 gp | 2 lb | 5 | 1d4 slashing; Light | 315 gp |
| Spear | 1 gp | 3 lb | 5 | 1d6 piercing; Thrown (range 20/60), versatile (1d8) | 315 gp |
| Battleaxe | 10 gp | 4 lb | 5 | 1d8 slashing; Versatile (1d10) | 324 gp |
| Flail | 10 gp | 2 lb | 5 | 1d8 bludgeoning; , | 324 gp |
| Glaive | 20 gp | 6 lb | 5 | 1d10 slashing; Heavy, reach, two-handed | 334 gp |
| Greataxe | 30 gp | 7 lb | 5 | 1d12 slashing; Heavy, two-handed | 344 gp |
| Greatsword | 50 gp | 6 lb | 5 | 2d6 slashing; Heavy, two-handed | 364 gp |
| Halberd | 20 gp | 6 lb | 5 | 1d10 slashing; Heavy, reach, two-handed | 334 gp |
| Lance | 10 gp | 6 lb | 5 | 1d12 piercing; Reach, special | 324 gp |
| Longsword | 15 gp | 3 lb | 5 | 1d8 slashing; Versatile (1d10) | 329 gp |
| Maul | 10 gp | 10 lb | 5 | 2d6 bludgeoning; Heavy, two-handed | 324 gp |
| Morningstar | 15 gp | 4 lb | 5 | 1d8 piercing; , | 329 gp |
| Pike | 5 gp | 18 lb | 5 | 1d10 piercing; Heavy, reach, two-handed | 319 gp |
| Rapier | 25 gp | 2 lb | 5 | 1d8 piercing; Finesse | 339 gp |
| Scimitar | 25 gp | 3 lb | 5 | 1d6 slashing; Finesse, light | 339 gp |
| Shortsword | 10 gp | 2 lb | 5 | 1d6 piercing; Finesse, light | 324 gp |
| Trident | 5 gp | 4 lb | 5 | 1d6 piercing; Thrown (range 20/60), versatile (1d8) | 319 gp |
| War pick | 5 gp | 2 lb | 5 | 1d8 piercing; , | 319 gp |
| Warhammer | 15 gp | 2 lb | 5 | 1d8 bludgeoning; Versatile (1d10) | 329 gp |
| Kama | 2 gp | 2 lb | 5 | 1d4 slashing; Light | 316 gp |

These are Small/Medium/Tiny ordinary Standard examples, not automatic item grants or material-AC assignments. Actual bases retain the complete equipment profile, requirements and legitimate size/grade valuation. Large doubles base price/weight/ordinary HP, not the source magic/process share. Record actual dominant material before work; the shared structural and damage-preservation rules apply.

**Exact source components:**

| Occurrence | Component | Quantity | Tier | Role / consumed | Unit mass | Unit source value | Required properties |
|---|---|---:|---:|---|---:|---:|---|
| 0 | Brightsteel Ingot | 3 | 3 | substrate / true | 1 lb | 25 gp | substrate |
| 1 | Wood handle | 2 | 3 | substrate / true | 0.1 lb | 25 gp | substrate |
| 2 | Sea bone shard | 1 | 2 | material / true | 0.39 lb | 29 gp | rigid, structural, water |

**Work:** STR or INT under the shared crafting check; Forge and Anvil; tools: Smith's tools, Forge, Anvil, Tongs. Maximum assistants 0; fieldCraftable=false, preserved timeMode=expedition. The false field flag controls: an actual Forge-and-Anvil worksite is still required. Ordinary first stable phase 8 active hour(s), included in total. An eligible Forge Dwarf uses 360 actual active minutes, first phase 360 minutes; no extra time reduction from assistants.

**Results:** Standard 1; Exceptional yield 1; Masterwork yield 1; structural option 1 with strongest noncompounding 25%/50% durability layer. Flawed: one unit establishing the single persistent half-maximum flaw after ordinary size/grade and strongest durability improvement; preserve damage deficit, possibly emerging Broken. Failed/Mishap transforms no base; source ingredient recovery/loss still applies. Masterwork returns at most one eligible consumed catalyst unit total, never one per occurrence or finished item.

**Repair:** functioning HP≥1 uses trained Smith's tools, actual Forge/Anvil/Tongs, STR/INT DC10, max(1 hour, actual max HP/10 hours), materials 25% mundane size/grade base value. HP0 with recoverable main body uses original recipe DC 15, max(8 hours, actual max HP/10 hours), materials 25% undamaged finished unit reference. Both are binary repair tasks; no formula/trade-level entitlement required or granted, no creation-only time reduction, crafting XP, quality roll or catalyst. Existing grade, durability state and flaw persist.

**Reference accounting:** source magic/process share 314 gp per unit, plus the actual transformed base's undamaged mundane size/grade reference. Real owned bases need no repurchase; purchased reserves are separate expenses. No automatic artifact multiplier, quality markup or guaranteed mundane-table magic buyback.

**Source access:** {"sources":["guild trainer","faction vendor","uncommon dungeon book","reverse engineering"],"minimumResearchHours":0,"requiresFormula":true,"formulaConsumed":false}. Visibility and actual ingredient availability remain source-controlled.

**Preserved tags:** Water. **Operative tag:** Water. Secondary tags grant no additional mechanics.

**Preserved legacy (inactive):** {"legacyName": "Steel Chain", "legacyEffect": "AC 16 + Dex modifier (medium armor)"}.

## recipe-65 — Exalted Ember Sword of Red Dragon Talon

**Source:** public; Blacksmithing level 10; tier 5; Uncommon; crafting DC 16; 3 days / 24 active hours; Standard quantity 1. Source Standard batch reference 2038 gp.

**Preserved effect:** Creates a durable sword with +1 to attack and damage rolls.

**Operational effect:** One actual sword base becomes an intact magical nonartifact output. With this weapon's actual attacks, use recipe +1 in the item-accuracy family and add +1 once to ordinary weapon-hit damage. Legal thrown/off-hand attacks retain these benefits; carrying it does not. Unsuppressed ordinary B/P/S counts magical. No elemental damage rider is granted by its title, ingredient or tag. Broken stops positive functions; suppression stops recipe magic only. The complete base, quality, repair and value rules apply.

**Legal base models:** Shortsword, Longsword, Greatsword, Rapier, Scimitar. Choose one model, size and actual legal equipment grade for the whole batch before work.

**Physical reserve:** 1 complete legal mundane bases, ordered before work. Transform the first resolved N; keep original inventory identity, actual grade/material/damage and source access. All source ingredients below are additional inputs; none supplies a free body.

| Base model | Ordinary Standard price | Weight | Ordinary max HP | Actual base combat profile | Finished unit reference with this ordinary base |
|---|---:|---:|---:|---|---:|
| Shortsword | 10 gp | 2 lb | 5 | 1d6 piercing; Finesse, light | 2048 gp |
| Longsword | 15 gp | 3 lb | 5 | 1d8 slashing; Versatile (1d10) | 2053 gp |
| Greatsword | 50 gp | 6 lb | 5 | 2d6 slashing; Heavy, two-handed | 2088 gp |
| Rapier | 25 gp | 2 lb | 5 | 1d8 piercing; Finesse | 2063 gp |
| Scimitar | 25 gp | 3 lb | 5 | 1d6 slashing; Finesse, light | 2063 gp |

These are Small/Medium/Tiny ordinary Standard examples, not automatic item grants or material-AC assignments. Actual bases retain the complete equipment profile, requirements and legitimate size/grade valuation. Large doubles base price/weight/ordinary HP, not the source magic/process share. Record actual dominant material before work; the shared structural and damage-preservation rules apply.

**Exact source components:**

| Occurrence | Component | Quantity | Tier | Role / consumed | Unit mass | Unit source value | Required properties |
|---|---|---:|---:|---|---:|---:|---|
| 0 | Wood handle | 2 | 5 | substrate / true | 0.1 lb | 200 gp | substrate |
| 1 | Forge water | 1 | 5 | tool / false | 25 lb | 600 gp | tool |
| 2 | Leather strips | 5 | 5 | substrate / true | 0.25 lb | 200 gp | substrate |
| 3 | red dragon talon | 1 | 2 | material / true | 0.16 lb | 21 gp | draconic, fire, rigid, structural |

**Work:** STR or INT under the shared crafting check; Forge and Anvil; tools: Smith's tools, Forge, Anvil, Tongs. Maximum assistants 0; fieldCraftable=false, preserved timeMode=workshop. The false field flag controls: an actual Forge-and-Anvil worksite is still required. Ordinary first stable phase 8 active hour(s), included in total. An eligible Forge Dwarf uses 1080 actual active minutes, first phase 480 minutes; no extra time reduction from assistants.

**Results:** Standard 1; Exceptional yield 1; Masterwork yield 1; structural option 1 with strongest noncompounding 25%/50% durability layer. Flawed: one unit establishing the single persistent half-maximum flaw after ordinary size/grade and strongest durability improvement; preserve damage deficit, possibly emerging Broken. Failed/Mishap transforms no base; source ingredient recovery/loss still applies. Masterwork returns at most one eligible consumed catalyst unit total, never one per occurrence or finished item.

**Repair:** functioning HP≥1 uses trained Smith's tools, actual Forge/Anvil/Tongs, STR/INT DC10, max(1 hour, actual max HP/10 hours), materials 25% mundane size/grade base value. HP0 with recoverable main body uses original recipe DC 16, max(8 hours, actual max HP/10 hours), materials 25% undamaged finished unit reference. Both are binary repair tasks; no formula/trade-level entitlement required or granted, no creation-only time reduction, crafting XP, quality roll or catalyst. Existing grade, durability state and flaw persist.

**Reference accounting:** source magic/process share 2038 gp per unit, plus the actual transformed base's undamaged mundane size/grade reference. Real owned bases need no repurchase; purchased reserves are separate expenses. No automatic artifact multiplier, quality markup or guaranteed mundane-table magic buyback.

**Source access:** {"sources":["rare recipe drop","specialist commission","dungeon library","successful experimentation"],"minimumResearchHours":8,"requiresFormula":true,"formulaConsumed":false}. Visibility and actual ingredient availability remain source-controlled.

**Preserved tags:** Fire. **Operative tag:** Fire. Secondary tags grant no additional mechanics.

**Preserved legacy (inactive):** {"legacyName": "Sword of Iron Superiorness", "legacyEffect": "+2 to attack and damage rolls"}.

## recipe-66 — Legendary Mighty Armor of Brontosaurus Tooth

**Source:** restricted; Blacksmithing level 12; tier 6; Rare; crafting DC 18; 2 weeks / 80 active hours; Standard quantity 1. Source Standard batch reference 6681 gp.

**Preserved effect:** Creates reinforced armor granting +2 AC and resistance to force damage while worn.

**Operational effect:** One actual armor base becomes an intact magical nonartifact output. While legally equipped, offer +2 to equipment.defense-enhancement, using the strongest eligible recipe/suit-grade modifier; retain the base suit formula or shield contribution where applicable. Its actual wearing rule separately supplies force resistance even if a stronger AC enhancement wins. Broken stops positive functions; suppression stops recipe magic only. The complete base, quality, repair and value rules apply.

**Legal base models:** Chain shirt, Scale mail, Breastplate, Half plate, Ring mail, Chain mail, Splint, Plate, Dwarven plate. Choose one model, size and actual legal equipment grade for the whole batch before work.

**Physical reserve:** 1 complete legal mundane bases, ordered before work. Transform the first resolved N; keep original inventory identity, actual grade/material/damage and source access. All source ingredients below are additional inputs; none supplies a free body.

| Base model | Ordinary Standard price | Weight | Ordinary max HP | Actual base combat profile | Finished unit reference with this ordinary base |
|---|---:|---:|---:|---|---:|
| Chain shirt | 50 gp | 20 lb | 15 | 13 + Dex modifier (max 2) | 6731 gp |
| Scale mail | 50 gp | 45 lb | 15 | 14 + Dex modifier (max 2) | 6731 gp |
| Breastplate | 400 gp | 20 lb | 15 | 14 + Dex modifier (max 2) | 7081 gp |
| Half plate | 750 gp | 40 lb | 15 | 15 + Dex modifier (max 2) | 7431 gp |
| Ring mail | 30 gp | 40 lb | 20 | 14 | 6711 gp |
| Chain mail | 75 gp | 55 lb | 20 | 16 | 6756 gp |
| Splint | 200 gp | 60 lb | 20 | 17 | 6881 gp |
| Plate | 1500 gp | 65 lb | 20 | 18 | 8181 gp |
| Dwarven plate | 3000 gp | 55 lb | 20 | 18 | 9681 gp |

These are Small/Medium/Tiny ordinary Standard examples, not automatic item grants or material-AC assignments. Actual bases retain the complete equipment profile, requirements and legitimate size/grade valuation. Large doubles base price/weight/ordinary HP, not the source magic/process share. Record actual dominant material before work; the shared structural and damage-preservation rules apply.

**Exact source components:**

| Occurrence | Component | Quantity | Tier | Role / consumed | Unit mass | Unit source value | Required properties |
|---|---|---:|---:|---|---:|---:|---|
| 0 | Steel ingot | 4 | 6 | substrate / true | 1 lb | 500 gp | substrate |
| 1 | Wood handle | 4 | 6 | substrate / true | 0.1 lb | 500 gp | substrate |
| 2 | Brightsteel Ingot | 1 | 6 | substrate / true | 1 lb | 500 gp | substrate |
| 3 | Brontosaurus tooth | 1 | 3 | material / true | 0.5 lb | 93 gp | rigid, structural |

**Work:** STR or INT under the shared crafting check; Forge and Anvil; tools: Smith's tools, Forge, Anvil, Tongs. Maximum assistants 1; fieldCraftable=false, preserved timeMode=haven. The false field flag controls: an actual Forge-and-Anvil worksite is still required. Ordinary first stable phase 8 active hour(s), included in total. An eligible Forge Dwarf uses 3600 actual active minutes, first phase 480 minutes; no extra time reduction from assistants.

**Results:** Standard 1; Exceptional yield 1; Masterwork yield 1; structural option 1 with strongest noncompounding 25%/50% durability layer. Flawed: one unit establishing the single persistent half-maximum flaw after ordinary size/grade and strongest durability improvement; preserve damage deficit, possibly emerging Broken. Failed/Mishap transforms no base; source ingredient recovery/loss still applies. Masterwork returns at most one eligible consumed catalyst unit total, never one per occurrence or finished item.

**Repair:** functioning HP≥1 uses trained Smith's tools, actual Forge/Anvil/Tongs, STR/INT DC10, max(1 hour, actual max HP/10 hours), materials 25% mundane size/grade base value. HP0 with recoverable main body uses original recipe DC 18, max(8 hours, actual max HP/10 hours), materials 25% undamaged finished unit reference. Both are binary repair tasks; no formula/trade-level entitlement required or granted, no creation-only time reduction, crafting XP, quality roll or catalyst. Existing grade, durability state and flaw persist.

**Reference accounting:** source magic/process share 6681 gp per unit, plus the actual transformed base's undamaged mundane size/grade reference. Real owned bases need no repurchase; purchased reserves are separate expenses. No automatic artifact multiplier, quality markup or guaranteed mundane-table magic buyback.

**Source access:** {"sources":["rare recipe drop","specialist commission","dungeon library","successful experimentation"],"minimumResearchHours":16,"requiresFormula":true,"formulaConsumed":false}. Visibility and actual ingredient availability remain source-controlled.

**Preserved tags:** Strength. **Operative tag:** Strength. Secondary tags grant no additional mechanics.

**Preserved legacy (inactive):** {"legacyName": "Mystical Forged Armor", "legacyEffect": "AC 18 (heavy armor)"}.

**Optional preserved Director guidance:** "Deep-tier provisional (skill 11+ → restricted or undiscovered depth). Components are real costs — do not treat as free craft. Director: (1) require components as listed or 1:1 Instruments salvage swap; (2) gate availability behind Floor/tier access or a named haven workshop; (3) if the result feels too strong for current floor, add downtime hours (skillLevel × 2 hours suggested) or a rare catalyst from the current Gate zone;". This is not an automatic extra gate.

## recipe-67 — Exalted Storm Shield of Blue Dragon Rib

**Source:** public; Blacksmithing level 10; tier 5; Rare; crafting DC 18; 1 week / 40 active hours; Standard quantity 1. Source Standard batch reference 2480 gp.

**Preserved effect:** Creates reinforced shield granting +2 AC and resistance to lightning damage while worn.

**Operational effect:** One actual shield base becomes an intact magical nonartifact output. While legally equipped, offer +2 to equipment.defense-enhancement, using the strongest eligible recipe/suit-grade modifier; retain the base suit formula or shield contribution where applicable. Its actual wearing rule separately supplies lightning resistance even if a stronger AC enhancement wins. Broken stops positive functions; suppression stops recipe magic only. The complete base, quality, repair and value rules apply.

**Legal base models:** Buckler, Shield, Tower shield. Choose one model, size and actual legal equipment grade for the whole batch before work.

**Physical reserve:** 1 complete legal mundane bases, ordered before work. Transform the first resolved N; keep original inventory identity, actual grade/material/damage and source access. All source ingredients below are additional inputs; none supplies a free body.

| Base model | Ordinary Standard price | Weight | Ordinary max HP | Actual base combat profile | Finished unit reference with this ordinary base |
|---|---:|---:|---:|---|---:|
| Buckler | 5 gp | 3 lb | 10 | +1 | 2485 gp |
| Shield | 10 gp | 6 lb | 10 | +2 | 2490 gp |
| Tower shield | 50 gp | 15 lb | 15 | +3 | 2530 gp |

These are Small/Medium/Tiny ordinary Standard examples, not automatic item grants or material-AC assignments. Actual bases retain the complete equipment profile, requirements and legitimate size/grade valuation. Large doubles base price/weight/ordinary HP, not the source magic/process share. Record actual dominant material before work; the shared structural and damage-preservation rules apply.

**Exact source components:**

| Occurrence | Component | Quantity | Tier | Role / consumed | Unit mass | Unit source value | Required properties |
|---|---|---:|---:|---|---:|---:|---|
| 0 | Iron ingot | 1 | 5 | substrate / true | 1 lb | 200 gp | substrate |
| 1 | Tempering oil | 2 | 5 | solvent / true | 0.5 lb | 200 gp | solvent |
| 2 | Heartsteel Ingot | 4 | 5 | substrate / true | 1 lb | 200 gp | substrate |
| 3 | Forge water | 1 | 5 | tool / false | 25 lb | 600 gp | tool |
| 4 | Wood handle | 1 | 5 | substrate / true | 0.1 lb | 200 gp | substrate |
| 5 | blue dragon rib | 1 | 3 | material / true | 0.34 lb | 89 gp | draconic, lightning, specialized |

**Work:** STR or INT under the shared crafting check; Forge and Anvil; tools: Smith's tools, Forge, Anvil, Tongs. Maximum assistants 0; fieldCraftable=false, preserved timeMode=workshop. The false field flag controls: an actual Forge-and-Anvil worksite is still required. Ordinary first stable phase 8 active hour(s), included in total. An eligible Forge Dwarf uses 1800 actual active minutes, first phase 480 minutes; no extra time reduction from assistants.

**Results:** Standard 1; Exceptional yield 1; Masterwork yield 1; structural option 1 with strongest noncompounding 25%/50% durability layer. Flawed: one unit establishing the single persistent half-maximum flaw after ordinary size/grade and strongest durability improvement; preserve damage deficit, possibly emerging Broken. Failed/Mishap transforms no base; source ingredient recovery/loss still applies. Masterwork returns at most one eligible consumed catalyst unit total, never one per occurrence or finished item.

**Repair:** functioning HP≥1 uses trained Smith's tools, actual Forge/Anvil/Tongs, STR/INT DC10, max(1 hour, actual max HP/10 hours), materials 25% mundane size/grade base value. HP0 with recoverable main body uses original recipe DC 18, max(8 hours, actual max HP/10 hours), materials 25% undamaged finished unit reference. Both are binary repair tasks; no formula/trade-level entitlement required or granted, no creation-only time reduction, crafting XP, quality roll or catalyst. Existing grade, durability state and flaw persist.

**Reference accounting:** source magic/process share 2480 gp per unit, plus the actual transformed base's undamaged mundane size/grade reference. Real owned bases need no repurchase; purchased reserves are separate expenses. No automatic artifact multiplier, quality markup or guaranteed mundane-table magic buyback.

**Source access:** {"sources":["rare recipe drop","specialist commission","dungeon library","successful experimentation"],"minimumResearchHours":8,"requiresFormula":true,"formulaConsumed":false}. Visibility and actual ingredient availability remain source-controlled.

**Preserved tags:** Lightning. **Operative tag:** Lightning. Secondary tags grant no additional mechanics.

**Preserved legacy (inactive):** {"legacyName": "Mystical Forged Shield", "legacyEffect": "Deals an extra 1d8 damage of a specific type"}.

## recipe-68 — Mythic Storm Mace of Blue Dragon Bone

**Source:** director-only; Blacksmithing level 15; tier 8; Rare; crafting DC 20; 2 weeks / 80 active hours; Standard quantity 1. Source Standard batch reference 41130 gp.

**Preserved effect:** Creates a durable mace with +2 to attack and damage rolls and 2d4 additional lightning damage once per turn.

**Operational effect:** One actual mace base becomes an intact magical nonartifact output. With this weapon's actual attacks, use recipe +2 in the item-accuracy family and add +2 once to ordinary weapon-hit damage. Legal thrown/off-hand attacks retain these benefits; carrying it does not. Unsuppressed ordinary B/P/S counts magical. On a legal hit, optionally add 2d4 lightning as part of that same attack damage event, once per physical item per actual turn; choose before damage. Criticals double these dice, never the flat bonus. Use the shared off-turn, copy, companion and six-second transition rules. Broken stops positive functions; suppression stops recipe magic only. The complete base, quality, repair and value rules apply.

**Legal base models:** Mace, Flail, Morningstar. Choose one model, size and actual legal equipment grade for the whole batch before work.

**Physical reserve:** 1 complete legal mundane bases, ordered before work. Transform the first resolved N; keep original inventory identity, actual grade/material/damage and source access. All source ingredients below are additional inputs; none supplies a free body.

| Base model | Ordinary Standard price | Weight | Ordinary max HP | Actual base combat profile | Finished unit reference with this ordinary base |
|---|---:|---:|---:|---|---:|
| Mace | 5 gp | 4 lb | 5 | 1d6 bludgeoning; , | 41135 gp |
| Flail | 10 gp | 2 lb | 5 | 1d8 bludgeoning; , | 41140 gp |
| Morningstar | 15 gp | 4 lb | 5 | 1d8 piercing; , | 41145 gp |

These are Small/Medium/Tiny ordinary Standard examples, not automatic item grants or material-AC assignments. Actual bases retain the complete equipment profile, requirements and legitimate size/grade valuation. Large doubles base price/weight/ordinary HP, not the source magic/process share. Record actual dominant material before work; the shared structural and damage-preservation rules apply.

**Exact source components:**

| Occurrence | Component | Quantity | Tier | Role / consumed | Unit mass | Unit source value | Required properties |
|---|---|---:|---:|---|---:|---:|---|
| 0 | Leather strips | 4 | 8 | substrate / true | 0.25 lb | 3000 gp | substrate |
| 1 | Wood handle | 4 | 8 | substrate / true | 0.1 lb | 3000 gp | substrate |
| 2 | Steel ingot | 2 | 8 | substrate / true | 1 lb | 3000 gp | substrate |
| 3 | blue dragon bone | 1 | 2 | material / true | 0.43 lb | 22 gp | draconic, lightning, rigid, structural |

**Work:** STR or INT under the shared crafting check; Forge and Anvil; tools: Smith's tools, Forge, Anvil, Tongs. Maximum assistants 1; fieldCraftable=false, preserved timeMode=haven. The false field flag controls: an actual Forge-and-Anvil worksite is still required. Ordinary first stable phase 8 active hour(s), included in total. An eligible Forge Dwarf uses 3600 actual active minutes, first phase 480 minutes; no extra time reduction from assistants.

**Results:** Standard 1; Exceptional yield 1; Masterwork yield 1; structural option 1 with strongest noncompounding 25%/50% durability layer. Flawed: one unit establishing the single persistent half-maximum flaw after ordinary size/grade and strongest durability improvement; preserve damage deficit, possibly emerging Broken. Failed/Mishap transforms no base; source ingredient recovery/loss still applies. Masterwork returns at most one eligible consumed catalyst unit total, never one per occurrence or finished item.

**Repair:** functioning HP≥1 uses trained Smith's tools, actual Forge/Anvil/Tongs, STR/INT DC10, max(1 hour, actual max HP/10 hours), materials 25% mundane size/grade base value. HP0 with recoverable main body uses original recipe DC 20, max(8 hours, actual max HP/10 hours), materials 25% undamaged finished unit reference. Both are binary repair tasks; no formula/trade-level entitlement required or granted, no creation-only time reduction, crafting XP, quality roll or catalyst. Existing grade, durability state and flaw persist.

**Reference accounting:** source magic/process share 41130 gp per unit, plus the actual transformed base's undamaged mundane size/grade reference. Real owned bases need no repurchase; purchased reserves are separate expenses. No automatic artifact multiplier, quality markup or guaranteed mundane-table magic buyback.

**Source access:** {"sources":["forbidden archive","named master crafter","Gate-zone research","complex reverse engineering"],"minimumResearchHours":28,"requiresFormula":true,"formulaConsumed":false}. Visibility and actual ingredient availability remain source-controlled.

**Preserved tags:** Lightning. **Operative tag:** Lightning. Secondary tags grant no additional mechanics.

**Preserved legacy (inactive):** {"legacyName": "Forged Mace", "legacyEffect": "AC 18 (heavy armor)"}.

**Optional preserved Director guidance:** "Deep-tier provisional (skill 11+ → restricted or undiscovered depth). Components are real costs — do not treat as free craft. Director: (1) require components as listed or 1:1 Instruments salvage swap; (2) gate availability behind Floor/tier access or a named haven workshop; (3) if the result feels too strong for current floor, add downtime hours (skillLevel × 2 hours suggested) or a rare catalyst from the current Gate zone;". This is not an automatic extra gate.

## recipe-69 — Legendary Tide Mace of Refined Water Core

**Source:** restricted; Blacksmithing level 11; tier 6; Rare; crafting DC 20; 2 weeks / 80 active hours; Standard quantity 1. Source Standard batch reference 5643 gp.

**Preserved effect:** Creates a durable mace with +2 to attack and damage rolls and 2d4 additional cold damage once per turn.

**Operational effect:** One actual mace base becomes an intact magical nonartifact output. With this weapon's actual attacks, use recipe +2 in the item-accuracy family and add +2 once to ordinary weapon-hit damage. Legal thrown/off-hand attacks retain these benefits; carrying it does not. Unsuppressed ordinary B/P/S counts magical. On a legal hit, optionally add 2d4 cold as part of that same attack damage event, once per physical item per actual turn; choose before damage. Criticals double these dice, never the flat bonus. Use the shared off-turn, copy, companion and six-second transition rules. Broken stops positive functions; suppression stops recipe magic only. The complete base, quality, repair and value rules apply.

**Legal base models:** Mace, Flail, Morningstar. Choose one model, size and actual legal equipment grade for the whole batch before work.

**Physical reserve:** 1 complete legal mundane bases, ordered before work. Transform the first resolved N; keep original inventory identity, actual grade/material/damage and source access. All source ingredients below are additional inputs; none supplies a free body.

| Base model | Ordinary Standard price | Weight | Ordinary max HP | Actual base combat profile | Finished unit reference with this ordinary base |
|---|---:|---:|---:|---|---:|
| Mace | 5 gp | 4 lb | 5 | 1d6 bludgeoning; , | 5648 gp |
| Flail | 10 gp | 2 lb | 5 | 1d8 bludgeoning; , | 5653 gp |
| Morningstar | 15 gp | 4 lb | 5 | 1d8 piercing; , | 5658 gp |

These are Small/Medium/Tiny ordinary Standard examples, not automatic item grants or material-AC assignments. Actual bases retain the complete equipment profile, requirements and legitimate size/grade valuation. Large doubles base price/weight/ordinary HP, not the source magic/process share. Record actual dominant material before work; the shared structural and damage-preservation rules apply.

**Exact source components:**

| Occurrence | Component | Quantity | Tier | Role / consumed | Unit mass | Unit source value | Required properties |
|---|---|---:|---:|---|---:|---:|---|
| 0 | Leather strips | 2 | 6 | substrate / true | 0.25 lb | 500 gp | substrate |
| 1 | Tempering oil | 5 | 6 | solvent / true | 0.5 lb | 500 gp | solvent |
| 2 | Forge water | 1 | 6 | tool / false | 25 lb | 1500 gp | tool |
| 3 | refined water core | 1 | 4 | material / true | 0.05 lb | 354 gp | resonant, rigid, water |

**Work:** STR or INT under the shared crafting check; Forge and Anvil; tools: Smith's tools, Forge, Anvil, Tongs. Maximum assistants 0; fieldCraftable=false, preserved timeMode=haven. The false field flag controls: an actual Forge-and-Anvil worksite is still required. Ordinary first stable phase 8 active hour(s), included in total. An eligible Forge Dwarf uses 3600 actual active minutes, first phase 480 minutes; no extra time reduction from assistants.

**Results:** Standard 1; Exceptional yield 1; Masterwork yield 1; structural option 1 with strongest noncompounding 25%/50% durability layer. Flawed: one unit establishing the single persistent half-maximum flaw after ordinary size/grade and strongest durability improvement; preserve damage deficit, possibly emerging Broken. Failed/Mishap transforms no base; source ingredient recovery/loss still applies. Masterwork returns at most one eligible consumed catalyst unit total, never one per occurrence or finished item.

**Repair:** functioning HP≥1 uses trained Smith's tools, actual Forge/Anvil/Tongs, STR/INT DC10, max(1 hour, actual max HP/10 hours), materials 25% mundane size/grade base value. HP0 with recoverable main body uses original recipe DC 20, max(8 hours, actual max HP/10 hours), materials 25% undamaged finished unit reference. Both are binary repair tasks; no formula/trade-level entitlement required or granted, no creation-only time reduction, crafting XP, quality roll or catalyst. Existing grade, durability state and flaw persist.

**Reference accounting:** source magic/process share 5643 gp per unit, plus the actual transformed base's undamaged mundane size/grade reference. Real owned bases need no repurchase; purchased reserves are separate expenses. No automatic artifact multiplier, quality markup or guaranteed mundane-table magic buyback.

**Source access:** {"sources":["rare recipe drop","specialist commission","dungeon library","successful experimentation"],"minimumResearchHours":12,"requiresFormula":true,"formulaConsumed":false}. Visibility and actual ingredient availability remain source-controlled.

**Preserved tags:** Water. **Operative tag:** Water. Secondary tags grant no additional mechanics.

**Preserved legacy (inactive):** {"legacyName": "Masterwork Forged Mace", "legacyEffect": "Deals an extra 1d8 damage of a specific type"}.

**Optional preserved Director guidance:** "Deep-tier provisional (skill 11+ → restricted or undiscovered depth). Components are real costs — do not treat as free craft. Director: (1) require components as listed or 1:1 Instruments salvage swap; (2) gate availability behind Floor/tier access or a named haven workshop; (3) if the result feels too strong for current floor, add downtime hours (skillLevel × 2 hours suggested) or a rare catalyst from the current Gate zone;". This is not an automatic extra gate.

## recipe-70 — Legendary Tide Sword of Refined Water Core

**Source:** restricted; Blacksmithing level 12; tier 6; Rare; crafting DC 18; 1 week / 40 active hours; Standard quantity 1. Source Standard batch reference 8143 gp.

**Preserved effect:** Creates a durable sword with +2 to attack and damage rolls and 2d4 additional cold damage once per turn.

**Operational effect:** One actual sword base becomes an intact magical nonartifact output. With this weapon's actual attacks, use recipe +2 in the item-accuracy family and add +2 once to ordinary weapon-hit damage. Legal thrown/off-hand attacks retain these benefits; carrying it does not. Unsuppressed ordinary B/P/S counts magical. On a legal hit, optionally add 2d4 cold as part of that same attack damage event, once per physical item per actual turn; choose before damage. Criticals double these dice, never the flat bonus. Use the shared off-turn, copy, companion and six-second transition rules. Broken stops positive functions; suppression stops recipe magic only. The complete base, quality, repair and value rules apply.

**Legal base models:** Shortsword, Longsword, Greatsword, Rapier, Scimitar. Choose one model, size and actual legal equipment grade for the whole batch before work.

**Physical reserve:** 1 complete legal mundane bases, ordered before work. Transform the first resolved N; keep original inventory identity, actual grade/material/damage and source access. All source ingredients below are additional inputs; none supplies a free body.

| Base model | Ordinary Standard price | Weight | Ordinary max HP | Actual base combat profile | Finished unit reference with this ordinary base |
|---|---:|---:|---:|---|---:|
| Shortsword | 10 gp | 2 lb | 5 | 1d6 piercing; Finesse, light | 8153 gp |
| Longsword | 15 gp | 3 lb | 5 | 1d8 slashing; Versatile (1d10) | 8158 gp |
| Greatsword | 50 gp | 6 lb | 5 | 2d6 slashing; Heavy, two-handed | 8193 gp |
| Rapier | 25 gp | 2 lb | 5 | 1d8 piercing; Finesse | 8168 gp |
| Scimitar | 25 gp | 3 lb | 5 | 1d6 slashing; Finesse, light | 8168 gp |

These are Small/Medium/Tiny ordinary Standard examples, not automatic item grants or material-AC assignments. Actual bases retain the complete equipment profile, requirements and legitimate size/grade valuation. Large doubles base price/weight/ordinary HP, not the source magic/process share. Record actual dominant material before work; the shared structural and damage-preservation rules apply.

**Exact source components:**

| Occurrence | Component | Quantity | Tier | Role / consumed | Unit mass | Unit source value | Required properties |
|---|---|---:|---:|---|---:|---:|---|
| 0 | Coal | 2 | 6 | fuel / true | 1 lb | 500 gp | fuel |
| 1 | Iron ingot | 3 | 6 | substrate / true | 1 lb | 500 gp | substrate |
| 2 | Heartsteel Ingot | 1 | 6 | substrate / true | 1 lb | 500 gp | substrate |
| 3 | Wood handle | 5 | 6 | substrate / true | 0.1 lb | 500 gp | substrate |
| 4 | refined water core | 1 | 4 | material / true | 0.05 lb | 354 gp | resonant, rigid, water |

**Work:** STR or INT under the shared crafting check; Forge and Anvil; tools: Smith's tools, Forge, Anvil, Tongs. Maximum assistants 1; fieldCraftable=false, preserved timeMode=workshop. The false field flag controls: an actual Forge-and-Anvil worksite is still required. Ordinary first stable phase 8 active hour(s), included in total. An eligible Forge Dwarf uses 1800 actual active minutes, first phase 480 minutes; no extra time reduction from assistants.

**Results:** Standard 1; Exceptional yield 1; Masterwork yield 1; structural option 1 with strongest noncompounding 25%/50% durability layer. Flawed: one unit establishing the single persistent half-maximum flaw after ordinary size/grade and strongest durability improvement; preserve damage deficit, possibly emerging Broken. Failed/Mishap transforms no base; source ingredient recovery/loss still applies. Masterwork returns at most one eligible consumed catalyst unit total, never one per occurrence or finished item.

**Repair:** functioning HP≥1 uses trained Smith's tools, actual Forge/Anvil/Tongs, STR/INT DC10, max(1 hour, actual max HP/10 hours), materials 25% mundane size/grade base value. HP0 with recoverable main body uses original recipe DC 18, max(8 hours, actual max HP/10 hours), materials 25% undamaged finished unit reference. Both are binary repair tasks; no formula/trade-level entitlement required or granted, no creation-only time reduction, crafting XP, quality roll or catalyst. Existing grade, durability state and flaw persist.

**Reference accounting:** source magic/process share 8143 gp per unit, plus the actual transformed base's undamaged mundane size/grade reference. Real owned bases need no repurchase; purchased reserves are separate expenses. No automatic artifact multiplier, quality markup or guaranteed mundane-table magic buyback.

**Source access:** {"sources":["rare recipe drop","specialist commission","dungeon library","successful experimentation"],"minimumResearchHours":16,"requiresFormula":true,"formulaConsumed":false}. Visibility and actual ingredient availability remain source-controlled.

**Preserved tags:** Water. **Operative tag:** Water. Secondary tags grant no additional mechanics.

**Preserved legacy (inactive):** {"legacyName": "Sword of Forged Exceptionalness", "legacyEffect": "Deals an extra 1d8 damage of a specific type"}.

**Optional preserved Director guidance:** "Deep-tier provisional (skill 11+ → restricted or undiscovered depth). Components are real costs — do not treat as free craft. Director: (1) require components as listed or 1:1 Instruments salvage swap; (2) gate availability behind Floor/tier access or a named haven workshop; (3) if the result feels too strong for current floor, add downtime hours (skillLevel × 2 hours suggested) or a rare catalyst from the current Gate zone;". This is not an automatic extra gate.

## recipe-71 — Legendary Grave Hammer of Infernal Marrow

**Source:** restricted; Blacksmithing level 12; tier 6; Rare; crafting DC 20; 2 weeks / 80 active hours; Standard quantity 1. Source Standard batch reference 4002 gp.

**Preserved effect:** Creates a durable hammer with +2 to attack and damage rolls and 2d4 additional necrotic damage once per turn.

**Operational effect:** One actual hammer base becomes an intact magical nonartifact output. With this weapon's actual attacks, use recipe +2 in the item-accuracy family and add +2 once to ordinary weapon-hit damage. Legal thrown/off-hand attacks retain these benefits; carrying it does not. Unsuppressed ordinary B/P/S counts magical. On a legal hit, optionally add 2d4 necrotic as part of that same attack damage event, once per physical item per actual turn; choose before damage. Criticals double these dice, never the flat bonus. Use the shared off-turn, copy, companion and six-second transition rules. Broken stops positive functions; suppression stops recipe magic only. The complete base, quality, repair and value rules apply.

**Legal base models:** Light hammer, Warhammer, Maul. Choose one model, size and actual legal equipment grade for the whole batch before work.

**Physical reserve:** 1 complete legal mundane bases, ordered before work. Transform the first resolved N; keep original inventory identity, actual grade/material/damage and source access. All source ingredients below are additional inputs; none supplies a free body.

| Base model | Ordinary Standard price | Weight | Ordinary max HP | Actual base combat profile | Finished unit reference with this ordinary base |
|---|---:|---:|---:|---|---:|
| Light hammer | 2 gp | 2 lb | 5 | 1d4 bludgeoning; Light, thrown (range 20/60) | 4004 gp |
| Warhammer | 15 gp | 2 lb | 5 | 1d8 bludgeoning; Versatile (1d10) | 4017 gp |
| Maul | 10 gp | 10 lb | 5 | 2d6 bludgeoning; Heavy, two-handed | 4012 gp |

These are Small/Medium/Tiny ordinary Standard examples, not automatic item grants or material-AC assignments. Actual bases retain the complete equipment profile, requirements and legitimate size/grade valuation. Large doubles base price/weight/ordinary HP, not the source magic/process share. Record actual dominant material before work; the shared structural and damage-preservation rules apply.

**Exact source components:**

| Occurrence | Component | Quantity | Tier | Role / consumed | Unit mass | Unit source value | Required properties |
|---|---|---:|---:|---|---:|---:|---|
| 0 | Forge water | 1 | 6 | tool / false | 25 lb | 1500 gp | tool |
| 1 | Brightsteel Ingot | 4 | 6 | substrate / true | 1 lb | 500 gp | substrate |
| 2 | Leather strips | 1 | 6 | substrate / true | 0.25 lb | 500 gp | substrate |
| 3 | infernal marrow | 1 | 3 | material / true | 0.18 lb | 109 gp | specialized, unholy, vital |

**Work:** STR or INT under the shared crafting check; Forge and Anvil; tools: Smith's tools, Forge, Anvil, Tongs. Maximum assistants 1; fieldCraftable=false, preserved timeMode=haven. The false field flag controls: an actual Forge-and-Anvil worksite is still required. Ordinary first stable phase 8 active hour(s), included in total. An eligible Forge Dwarf uses 3600 actual active minutes, first phase 480 minutes; no extra time reduction from assistants.

**Results:** Standard 1; Exceptional yield 1; Masterwork yield 1; structural option 1 with strongest noncompounding 25%/50% durability layer. Flawed: one unit establishing the single persistent half-maximum flaw after ordinary size/grade and strongest durability improvement; preserve damage deficit, possibly emerging Broken. Failed/Mishap transforms no base; source ingredient recovery/loss still applies. Masterwork returns at most one eligible consumed catalyst unit total, never one per occurrence or finished item.

**Repair:** functioning HP≥1 uses trained Smith's tools, actual Forge/Anvil/Tongs, STR/INT DC10, max(1 hour, actual max HP/10 hours), materials 25% mundane size/grade base value. HP0 with recoverable main body uses original recipe DC 20, max(8 hours, actual max HP/10 hours), materials 25% undamaged finished unit reference. Both are binary repair tasks; no formula/trade-level entitlement required or granted, no creation-only time reduction, crafting XP, quality roll or catalyst. Existing grade, durability state and flaw persist.

**Reference accounting:** source magic/process share 4002 gp per unit, plus the actual transformed base's undamaged mundane size/grade reference. Real owned bases need no repurchase; purchased reserves are separate expenses. No automatic artifact multiplier, quality markup or guaranteed mundane-table magic buyback.

**Source access:** {"sources":["rare recipe drop","specialist commission","dungeon library","successful experimentation"],"minimumResearchHours":16,"requiresFormula":true,"formulaConsumed":false}. Visibility and actual ingredient availability remain source-controlled.

**Preserved tags:** Unholy. **Operative tag:** Unholy. Secondary tags grant no additional mechanics.

**Preserved legacy (inactive):** {"legacyName": "Iron Hammer", "legacyEffect": "+3 to attack and damage rolls"}.

**Optional preserved Director guidance:** "Deep-tier provisional (skill 11+ → restricted or undiscovered depth). Components are real costs — do not treat as free craft. Director: (1) require components as listed or 1:1 Instruments salvage swap; (2) gate availability behind Floor/tier access or a named haven workshop; (3) if the result feels too strong for current floor, add downtime hours (skillLevel × 2 hours suggested) or a rare catalyst from the current Gate zone;". This is not an automatic extra gate.

## recipe-72 — Relic Frost Weapon of Silver Dragon Rib

**Source:** director-only; Blacksmithing level 13; tier 7; Rare; crafting DC 20; 2 weeks / 80 active hours; Standard quantity 1. Source Standard batch reference 26620 gp.

**Preserved effect:** Creates a durable weapon with +2 to attack and damage rolls and 2d4 additional cold damage once per turn.

**Operational effect:** One actual weapon base becomes an intact magical nonartifact output. With this weapon's actual attacks, use recipe +2 in the item-accuracy family and add +2 once to ordinary weapon-hit damage. Legal thrown/off-hand attacks retain these benefits; carrying it does not. Unsuppressed ordinary B/P/S counts magical. On a legal hit, optionally add 2d4 cold as part of that same attack damage event, once per physical item per actual turn; choose before damage. Criticals double these dice, never the flat bonus. Use the shared off-turn, copy, companion and six-second transition rules. Broken stops positive functions; suppression stops recipe magic only. The complete base, quality, repair and value rules apply.

**Legal base models:** Dagger, Dart, Handaxe, Javelin, Light hammer, Mace, Sickle, Spear, Battleaxe, Flail, Glaive, Greataxe, Greatsword, Halberd, Lance, Longsword, Maul, Morningstar, Pike, Rapier, Scimitar, Shortsword, Trident, War pick, Warhammer, Kama. Choose one model, size and actual legal equipment grade for the whole batch before work.

**Physical reserve:** 1 complete legal mundane bases, ordered before work. Transform the first resolved N; keep original inventory identity, actual grade/material/damage and source access. All source ingredients below are additional inputs; none supplies a free body.

| Base model | Ordinary Standard price | Weight | Ordinary max HP | Actual base combat profile | Finished unit reference with this ordinary base |
|---|---:|---:|---:|---|---:|
| Dagger | 2 gp | 1 lb | 5 | 1d4 piercing; Finesse, light, thrown (range 20/60) | 26622 gp |
| Dart | 0.05 gp | 0.25 lb | 5 | 1d4 piercing; Finesse, thrown (range 20/60) | 26620.05 gp |
| Handaxe | 5 gp | 2 lb | 5 | 1d6 slashing; Light, thrown (range 20/60) | 26625 gp |
| Javelin | 0.5 gp | 2 lb | 5 | 1d6 piercing; Thrown (range 30/120) | 26620.5 gp |
| Light hammer | 2 gp | 2 lb | 5 | 1d4 bludgeoning; Light, thrown (range 20/60) | 26622 gp |
| Mace | 5 gp | 4 lb | 5 | 1d6 bludgeoning; , | 26625 gp |
| Sickle | 1 gp | 2 lb | 5 | 1d4 slashing; Light | 26621 gp |
| Spear | 1 gp | 3 lb | 5 | 1d6 piercing; Thrown (range 20/60), versatile (1d8) | 26621 gp |
| Battleaxe | 10 gp | 4 lb | 5 | 1d8 slashing; Versatile (1d10) | 26630 gp |
| Flail | 10 gp | 2 lb | 5 | 1d8 bludgeoning; , | 26630 gp |
| Glaive | 20 gp | 6 lb | 5 | 1d10 slashing; Heavy, reach, two-handed | 26640 gp |
| Greataxe | 30 gp | 7 lb | 5 | 1d12 slashing; Heavy, two-handed | 26650 gp |
| Greatsword | 50 gp | 6 lb | 5 | 2d6 slashing; Heavy, two-handed | 26670 gp |
| Halberd | 20 gp | 6 lb | 5 | 1d10 slashing; Heavy, reach, two-handed | 26640 gp |
| Lance | 10 gp | 6 lb | 5 | 1d12 piercing; Reach, special | 26630 gp |
| Longsword | 15 gp | 3 lb | 5 | 1d8 slashing; Versatile (1d10) | 26635 gp |
| Maul | 10 gp | 10 lb | 5 | 2d6 bludgeoning; Heavy, two-handed | 26630 gp |
| Morningstar | 15 gp | 4 lb | 5 | 1d8 piercing; , | 26635 gp |
| Pike | 5 gp | 18 lb | 5 | 1d10 piercing; Heavy, reach, two-handed | 26625 gp |
| Rapier | 25 gp | 2 lb | 5 | 1d8 piercing; Finesse | 26645 gp |
| Scimitar | 25 gp | 3 lb | 5 | 1d6 slashing; Finesse, light | 26645 gp |
| Shortsword | 10 gp | 2 lb | 5 | 1d6 piercing; Finesse, light | 26630 gp |
| Trident | 5 gp | 4 lb | 5 | 1d6 piercing; Thrown (range 20/60), versatile (1d8) | 26625 gp |
| War pick | 5 gp | 2 lb | 5 | 1d8 piercing; , | 26625 gp |
| Warhammer | 15 gp | 2 lb | 5 | 1d8 bludgeoning; Versatile (1d10) | 26635 gp |
| Kama | 2 gp | 2 lb | 5 | 1d4 slashing; Light | 26622 gp |

These are Small/Medium/Tiny ordinary Standard examples, not automatic item grants or material-AC assignments. Actual bases retain the complete equipment profile, requirements and legitimate size/grade valuation. Large doubles base price/weight/ordinary HP, not the source magic/process share. Record actual dominant material before work; the shared structural and damage-preservation rules apply.

**Exact source components:**

| Occurrence | Component | Quantity | Tier | Role / consumed | Unit mass | Unit source value | Required properties |
|---|---|---:|---:|---|---:|---:|---|
| 0 | Forge water | 1 | 7 | tool / false | 25 lb | 3600 gp | tool |
| 1 | Iron ingot | 5 | 7 | substrate / true | 1 lb | 1200 gp | substrate |
| 2 | Tempering oil | 5 | 7 | solvent / true | 0.5 lb | 1200 gp | solvent |
| 3 | Coal | 2 | 7 | fuel / true | 1 lb | 1200 gp | fuel |
| 4 | Heartsteel Ingot | 4 | 7 | substrate / true | 1 lb | 1200 gp | substrate |
| 5 | silver dragon rib | 1 | 3 | material / true | 0.49 lb | 133 gp | cold, draconic, specialized |

**Work:** STR or INT under the shared crafting check; Forge and Anvil; tools: Smith's tools, Forge, Anvil, Tongs. Maximum assistants 1; fieldCraftable=false, preserved timeMode=haven. The false field flag controls: an actual Forge-and-Anvil worksite is still required. Ordinary first stable phase 8 active hour(s), included in total. An eligible Forge Dwarf uses 3600 actual active minutes, first phase 480 minutes; no extra time reduction from assistants.

**Results:** Standard 1; Exceptional yield 1; Masterwork yield 1; structural option 1 with strongest noncompounding 25%/50% durability layer. Flawed: one unit establishing the single persistent half-maximum flaw after ordinary size/grade and strongest durability improvement; preserve damage deficit, possibly emerging Broken. Failed/Mishap transforms no base; source ingredient recovery/loss still applies. Masterwork returns at most one eligible consumed catalyst unit total, never one per occurrence or finished item.

**Repair:** functioning HP≥1 uses trained Smith's tools, actual Forge/Anvil/Tongs, STR/INT DC10, max(1 hour, actual max HP/10 hours), materials 25% mundane size/grade base value. HP0 with recoverable main body uses original recipe DC 20, max(8 hours, actual max HP/10 hours), materials 25% undamaged finished unit reference. Both are binary repair tasks; no formula/trade-level entitlement required or granted, no creation-only time reduction, crafting XP, quality roll or catalyst. Existing grade, durability state and flaw persist.

**Reference accounting:** source magic/process share 26620 gp per unit, plus the actual transformed base's undamaged mundane size/grade reference. Real owned bases need no repurchase; purchased reserves are separate expenses. No automatic artifact multiplier, quality markup or guaranteed mundane-table magic buyback.

**Source access:** {"sources":["forbidden archive","named master crafter","Gate-zone research","complex reverse engineering"],"minimumResearchHours":20,"requiresFormula":true,"formulaConsumed":false}. Visibility and actual ingredient availability remain source-controlled.

**Preserved tags:** Cold. **Operative tag:** Cold. Secondary tags grant no additional mechanics.

**Preserved legacy (inactive):** {"legacyName": "Masterwork Iron Chain", "legacyEffect": "AC 18 (heavy armor)"}.

**Optional preserved Director guidance:** "Deep-tier provisional (skill 11+ → restricted or undiscovered depth). Components are real costs — do not treat as free craft. Director: (1) require components as listed or 1:1 Instruments salvage swap; (2) gate availability behind Floor/tier access or a named haven workshop; (3) if the result feels too strong for current floor, add downtime hours (skillLevel × 2 hours suggested) or a rare catalyst from the current Gate zone;". This is not an automatic extra gate.

## recipe-73 — Mythic Tide Shield of Bronze Dragonheart

**Source:** director-only; Blacksmithing level 15; tier 8; Very Rare; crafting DC 21; 1 month / 160 active hours; Standard quantity 1. Source Standard batch reference 76427 gp.

**Preserved effect:** Creates reinforced shield granting +2 AC and resistance to cold damage while worn.

**Operational effect:** One actual shield base becomes an intact magical nonartifact output. While legally equipped, offer +2 to equipment.defense-enhancement, using the strongest eligible recipe/suit-grade modifier; retain the base suit formula or shield contribution where applicable. Its actual wearing rule separately supplies cold resistance even if a stronger AC enhancement wins. Broken stops positive functions; suppression stops recipe magic only. The complete base, quality, repair and value rules apply.

**Legal base models:** Buckler, Shield, Tower shield. Choose one model, size and actual legal equipment grade for the whole batch before work.

**Physical reserve:** 1 complete legal mundane bases, ordered before work. Transform the first resolved N; keep original inventory identity, actual grade/material/damage and source access. All source ingredients below are additional inputs; none supplies a free body.

| Base model | Ordinary Standard price | Weight | Ordinary max HP | Actual base combat profile | Finished unit reference with this ordinary base |
|---|---:|---:|---:|---|---:|
| Buckler | 5 gp | 3 lb | 10 | +1 | 76432 gp |
| Shield | 10 gp | 6 lb | 10 | +2 | 76437 gp |
| Tower shield | 50 gp | 15 lb | 15 | +3 | 76477 gp |

These are Small/Medium/Tiny ordinary Standard examples, not automatic item grants or material-AC assignments. Actual bases retain the complete equipment profile, requirements and legitimate size/grade valuation. Large doubles base price/weight/ordinary HP, not the source magic/process share. Record actual dominant material before work; the shared structural and damage-preservation rules apply.

**Exact source components:**

| Occurrence | Component | Quantity | Tier | Role / consumed | Unit mass | Unit source value | Required properties |
|---|---|---:|---:|---|---:|---:|---|
| 0 | Leather strips | 3 | 8 | substrate / true | 0.25 lb | 3000 gp | substrate |
| 1 | Heartsteel Ingot | 5 | 8 | substrate / true | 1 lb | 3000 gp | substrate |
| 2 | Wood handle | 4 | 8 | substrate / true | 0.1 lb | 3000 gp | substrate |
| 3 | Iron ingot | 4 | 8 | substrate / true | 1 lb | 3000 gp | substrate |
| 4 | Brightsteel Ingot | 2 | 8 | substrate / true | 1 lb | 3000 gp | substrate |
| 5 | bronze dragon heartstone | 1 | 5 | catalyst / true | 0.26 lb | 1370 gp | draconic, earth, epic, power-bearing, vital, water |
| 6 | refined water core | 1 | 4 | material / true | 0.05 lb | 354 gp | resonant, rigid, water |

**Work:** STR or INT under the shared crafting check; Forge and Anvil; tools: Smith's tools, Forge, Anvil, Tongs. Maximum assistants 1; fieldCraftable=false, preserved timeMode=haven. The false field flag controls: an actual Forge-and-Anvil worksite is still required. Ordinary first stable phase 8 active hour(s), included in total. An eligible Forge Dwarf uses 7200 actual active minutes, first phase 480 minutes; no extra time reduction from assistants.

**Results:** Standard 1; Exceptional yield 1; Masterwork yield 1; structural option 1 with strongest noncompounding 25%/50% durability layer. Flawed: one unit establishing the single persistent half-maximum flaw after ordinary size/grade and strongest durability improvement; preserve damage deficit, possibly emerging Broken. Failed/Mishap transforms no base; source ingredient recovery/loss still applies. Masterwork returns at most one eligible consumed catalyst unit total, never one per occurrence or finished item.

**Repair:** functioning HP≥1 uses trained Smith's tools, actual Forge/Anvil/Tongs, STR/INT DC10, max(1 hour, actual max HP/10 hours), materials 25% mundane size/grade base value. HP0 with recoverable main body uses original recipe DC 21, max(8 hours, actual max HP/10 hours), materials 25% undamaged finished unit reference. Both are binary repair tasks; no formula/trade-level entitlement required or granted, no creation-only time reduction, crafting XP, quality roll or catalyst. Existing grade, durability state and flaw persist.

**Reference accounting:** source magic/process share 76427 gp per unit, plus the actual transformed base's undamaged mundane size/grade reference. Real owned bases need no repurchase; purchased reserves are separate expenses. No automatic artifact multiplier, quality markup or guaranteed mundane-table magic buyback.

**Source access:** {"sources":["forbidden archive","named master crafter","Gate-zone research","complex reverse engineering"],"minimumResearchHours":28,"requiresFormula":true,"formulaConsumed":false}. Visibility and actual ingredient availability remain source-controlled.

**Preserved tags:** Water, Vitality. **Operative tag:** Water. Secondary tags grant no additional mechanics.

**Preserved legacy (inactive):** {"legacyName": "Magnificent Shield", "legacyEffect": "Vorpal weapon property"}.

**Optional preserved Director guidance:** "Deep-tier provisional (skill 11+ → restricted or undiscovered depth). Components are real costs — do not treat as free craft. Director: (1) require components as listed or 1:1 Instruments salvage swap; (2) gate availability behind Floor/tier access or a named haven workshop; (3) if the result feels too strong for current floor, add downtime hours (skillLevel × 2 hours suggested) or a rare catalyst from the current Gate zone;". This is not an automatic extra gate.

## recipe-74 — Mythic Ember Axe of Refined Fire Core

**Source:** director-only; Blacksmithing level 16; tier 8; Very Rare; crafting DC 21; 1 month / 160 active hours; Standard quantity 1. Source Standard batch reference 34489 gp.

**Preserved effect:** Creates a durable axe with +2 to attack and damage rolls and 3d4 additional fire damage once per turn.

**Operational effect:** One actual axe base becomes an intact magical nonartifact output. With this weapon's actual attacks, use recipe +2 in the item-accuracy family and add +2 once to ordinary weapon-hit damage. Legal thrown/off-hand attacks retain these benefits; carrying it does not. Unsuppressed ordinary B/P/S counts magical. On a legal hit, optionally add 3d4 fire as part of that same attack damage event, once per physical item per actual turn; choose before damage. Criticals double these dice, never the flat bonus. Use the shared off-turn, copy, companion and six-second transition rules. Broken stops positive functions; suppression stops recipe magic only. The complete base, quality, repair and value rules apply.

**Legal base models:** Handaxe, Battleaxe, Greataxe. Choose one model, size and actual legal equipment grade for the whole batch before work.

**Physical reserve:** 1 complete legal mundane bases, ordered before work. Transform the first resolved N; keep original inventory identity, actual grade/material/damage and source access. All source ingredients below are additional inputs; none supplies a free body.

| Base model | Ordinary Standard price | Weight | Ordinary max HP | Actual base combat profile | Finished unit reference with this ordinary base |
|---|---:|---:|---:|---|---:|
| Handaxe | 5 gp | 2 lb | 5 | 1d6 slashing; Light, thrown (range 20/60) | 34494 gp |
| Battleaxe | 10 gp | 4 lb | 5 | 1d8 slashing; Versatile (1d10) | 34499 gp |
| Greataxe | 30 gp | 7 lb | 5 | 1d12 slashing; Heavy, two-handed | 34519 gp |

These are Small/Medium/Tiny ordinary Standard examples, not automatic item grants or material-AC assignments. Actual bases retain the complete equipment profile, requirements and legitimate size/grade valuation. Large doubles base price/weight/ordinary HP, not the source magic/process share. Record actual dominant material before work; the shared structural and damage-preservation rules apply.

**Exact source components:**

| Occurrence | Component | Quantity | Tier | Role / consumed | Unit mass | Unit source value | Required properties |
|---|---|---:|---:|---|---:|---:|---|
| 0 | Forge water | 1 | 8 | tool / false | 25 lb | 9000 gp | tool |
| 1 | Tempering oil | 2 | 8 | solvent / true | 0.5 lb | 3000 gp | solvent |
| 2 | Coal | 5 | 8 | fuel / true | 1 lb | 3000 gp | fuel |
| 3 | Leather strips | 1 | 8 | substrate / true | 0.25 lb | 3000 gp | substrate |
| 4 | refined fire core | 1 | 4 | material / true | 0.19 lb | 242 gp | fire, resonant, rigid |
| 5 | silver dragon claw | 1 | 4 | material / true | 0.21 lb | 357 gp | cold, draconic, rigid, structural |

**Work:** STR or INT under the shared crafting check; Forge and Anvil; tools: Smith's tools, Forge, Anvil, Tongs. Maximum assistants 2; fieldCraftable=false, preserved timeMode=haven. The false field flag controls: an actual Forge-and-Anvil worksite is still required. Ordinary first stable phase 8 active hour(s), included in total. An eligible Forge Dwarf uses 7200 actual active minutes, first phase 480 minutes; no extra time reduction from assistants.

**Results:** Standard 1; Exceptional yield 1; Masterwork yield 1; structural option 1 with strongest noncompounding 25%/50% durability layer. Flawed: one unit establishing the single persistent half-maximum flaw after ordinary size/grade and strongest durability improvement; preserve damage deficit, possibly emerging Broken. Failed/Mishap transforms no base; source ingredient recovery/loss still applies. Masterwork returns at most one eligible consumed catalyst unit total, never one per occurrence or finished item.

**Repair:** functioning HP≥1 uses trained Smith's tools, actual Forge/Anvil/Tongs, STR/INT DC10, max(1 hour, actual max HP/10 hours), materials 25% mundane size/grade base value. HP0 with recoverable main body uses original recipe DC 21, max(8 hours, actual max HP/10 hours), materials 25% undamaged finished unit reference. Both are binary repair tasks; no formula/trade-level entitlement required or granted, no creation-only time reduction, crafting XP, quality roll or catalyst. Existing grade, durability state and flaw persist.

**Reference accounting:** source magic/process share 34489 gp per unit, plus the actual transformed base's undamaged mundane size/grade reference. Real owned bases need no repurchase; purchased reserves are separate expenses. No automatic artifact multiplier, quality markup or guaranteed mundane-table magic buyback.

**Source access:** {"sources":["forbidden archive","named master crafter","Gate-zone research","complex reverse engineering"],"minimumResearchHours":32,"requiresFormula":true,"formulaConsumed":false}. Visibility and actual ingredient availability remain source-controlled.

**Preserved tags:** Fire, Cold. **Operative tag:** Fire. Secondary tags grant no additional mechanics.

**Preserved legacy (inactive):** {"legacyName": "Axe of Forged Extraordinaryness", "legacyEffect": "AC 20 + magic protection"}.

**Optional preserved Director guidance:** "Deep-tier provisional (skill 11+ → restricted or undiscovered depth). Components are real costs — do not treat as free craft. Director: (1) require components as listed or 1:1 Instruments salvage swap; (2) gate availability behind Floor/tier access or a named haven workshop; (3) if the result feels too strong for current floor, add downtime hours (skillLevel × 2 hours suggested) or a rare catalyst from the current Gate zone;". This is not an automatic extra gate.

## recipe-75 — Mythic Veiled Axe of Green Dragon Claw

**Source:** director-only; Blacksmithing level 15; tier 8; Very Rare; crafting DC 20; 1 month / 160 active hours; Standard quantity 1. Source Standard batch reference 58813 gp.

**Preserved effect:** Creates a durable axe with +2 to attack and damage rolls and 3d4 additional psychic damage once per turn.

**Operational effect:** One actual axe base becomes an intact magical nonartifact output. With this weapon's actual attacks, use recipe +2 in the item-accuracy family and add +2 once to ordinary weapon-hit damage. Legal thrown/off-hand attacks retain these benefits; carrying it does not. Unsuppressed ordinary B/P/S counts magical. On a legal hit, optionally add 3d4 psychic as part of that same attack damage event, once per physical item per actual turn; choose before damage. Criticals double these dice, never the flat bonus. Use the shared off-turn, copy, companion and six-second transition rules. Broken stops positive functions; suppression stops recipe magic only. The complete base, quality, repair and value rules apply.

**Legal base models:** Handaxe, Battleaxe, Greataxe. Choose one model, size and actual legal equipment grade for the whole batch before work.

**Physical reserve:** 1 complete legal mundane bases, ordered before work. Transform the first resolved N; keep original inventory identity, actual grade/material/damage and source access. All source ingredients below are additional inputs; none supplies a free body.

| Base model | Ordinary Standard price | Weight | Ordinary max HP | Actual base combat profile | Finished unit reference with this ordinary base |
|---|---:|---:|---:|---|---:|
| Handaxe | 5 gp | 2 lb | 5 | 1d6 slashing; Light, thrown (range 20/60) | 58818 gp |
| Battleaxe | 10 gp | 4 lb | 5 | 1d8 slashing; Versatile (1d10) | 58823 gp |
| Greataxe | 30 gp | 7 lb | 5 | 1d12 slashing; Heavy, two-handed | 58843 gp |

These are Small/Medium/Tiny ordinary Standard examples, not automatic item grants or material-AC assignments. Actual bases retain the complete equipment profile, requirements and legitimate size/grade valuation. Large doubles base price/weight/ordinary HP, not the source magic/process share. Record actual dominant material before work; the shared structural and damage-preservation rules apply.

**Exact source components:**

| Occurrence | Component | Quantity | Tier | Role / consumed | Unit mass | Unit source value | Required properties |
|---|---|---:|---:|---|---:|---:|---|
| 0 | Leather strips | 2 | 8 | substrate / true | 0.25 lb | 3000 gp | substrate |
| 1 | Coal | 2 | 8 | fuel / true | 1 lb | 3000 gp | fuel |
| 2 | Brightsteel Ingot | 2 | 8 | substrate / true | 1 lb | 3000 gp | substrate |
| 3 | Tempering oil | 3 | 8 | solvent / true | 0.5 lb | 3000 gp | solvent |
| 4 | Wood handle | 5 | 8 | substrate / true | 0.1 lb | 3000 gp | substrate |
| 5 | Forge water | 1 | 8 | tool / false | 25 lb | 9000 gp | tool |
| 6 | green dragon claw | 1 | 4 | material / true | 0.35 lb | 199 gp | draconic, poison, rigid, structural |
| 7 | green dragon horn | 1 | 4 | material / true | 0.25 lb | 477 gp | draconic, piercing, poison, rigid |

**Work:** STR or INT under the shared crafting check; Forge and Anvil; tools: Smith's tools, Forge, Anvil, Tongs. Maximum assistants 1; fieldCraftable=false, preserved timeMode=haven. The false field flag controls: an actual Forge-and-Anvil worksite is still required. Ordinary first stable phase 8 active hour(s), included in total. An eligible Forge Dwarf uses 7200 actual active minutes, first phase 480 minutes; no extra time reduction from assistants.

**Results:** Standard 1; Exceptional yield 1; Masterwork yield 1; structural option 1 with strongest noncompounding 25%/50% durability layer. Flawed: one unit establishing the single persistent half-maximum flaw after ordinary size/grade and strongest durability improvement; preserve damage deficit, possibly emerging Broken. Failed/Mishap transforms no base; source ingredient recovery/loss still applies. Masterwork returns at most one eligible consumed catalyst unit total, never one per occurrence or finished item.

**Repair:** functioning HP≥1 uses trained Smith's tools, actual Forge/Anvil/Tongs, STR/INT DC10, max(1 hour, actual max HP/10 hours), materials 25% mundane size/grade base value. HP0 with recoverable main body uses original recipe DC 20, max(8 hours, actual max HP/10 hours), materials 25% undamaged finished unit reference. Both are binary repair tasks; no formula/trade-level entitlement required or granted, no creation-only time reduction, crafting XP, quality roll or catalyst. Existing grade, durability state and flaw persist.

**Reference accounting:** source magic/process share 58813 gp per unit, plus the actual transformed base's undamaged mundane size/grade reference. Real owned bases need no repurchase; purchased reserves are separate expenses. No automatic artifact multiplier, quality markup or guaranteed mundane-table magic buyback.

**Source access:** {"sources":["forbidden archive","named master crafter","Gate-zone research","complex reverse engineering"],"minimumResearchHours":28,"requiresFormula":true,"formulaConsumed":false}. Visibility and actual ingredient availability remain source-controlled.

**Preserved tags:** Stealth, Poison. **Operative tag:** Stealth. Secondary tags grant no additional mechanics.

**Preserved legacy (inactive):** {"legacyName": "Tempered Axe", "legacyEffect": "AC 20 + magic protection"}.

**Optional preserved Director guidance:** "Deep-tier provisional (skill 11+ → restricted or undiscovered depth). Components are real costs — do not treat as free craft. Director: (1) require components as listed or 1:1 Instruments salvage swap; (2) gate availability behind Floor/tier access or a named haven workshop; (3) if the result feels too strong for current floor, add downtime hours (skillLevel × 2 hours suggested) or a rare catalyst from the current Gate zone;". This is not an automatic extra gate.

## recipe-76 — Ascendant Gale Shield of Refined Air Core

**Source:** director-only; Blacksmithing level 18; tier 9; Very Rare; crafting DC 22; 1 month / 160 active hours; Standard quantity 1. Source Standard batch reference 175593 gp.

**Preserved effect:** Creates reinforced shield granting +2 AC and resistance to thunder damage while worn.

**Operational effect:** One actual shield base becomes an intact magical nonartifact output. While legally equipped, offer +2 to equipment.defense-enhancement, using the strongest eligible recipe/suit-grade modifier; retain the base suit formula or shield contribution where applicable. Its actual wearing rule separately supplies thunder resistance even if a stronger AC enhancement wins. Broken stops positive functions; suppression stops recipe magic only. The complete base, quality, repair and value rules apply.

**Legal base models:** Buckler, Shield, Tower shield. Choose one model, size and actual legal equipment grade for the whole batch before work.

**Physical reserve:** 1 complete legal mundane bases, ordered before work. Transform the first resolved N; keep original inventory identity, actual grade/material/damage and source access. All source ingredients below are additional inputs; none supplies a free body.

| Base model | Ordinary Standard price | Weight | Ordinary max HP | Actual base combat profile | Finished unit reference with this ordinary base |
|---|---:|---:|---:|---|---:|
| Buckler | 5 gp | 3 lb | 10 | +1 | 175598 gp |
| Shield | 10 gp | 6 lb | 10 | +2 | 175603 gp |
| Tower shield | 50 gp | 15 lb | 15 | +3 | 175643 gp |

These are Small/Medium/Tiny ordinary Standard examples, not automatic item grants or material-AC assignments. Actual bases retain the complete equipment profile, requirements and legitimate size/grade valuation. Large doubles base price/weight/ordinary HP, not the source magic/process share. Record actual dominant material before work; the shared structural and damage-preservation rules apply.

**Exact source components:**

| Occurrence | Component | Quantity | Tier | Role / consumed | Unit mass | Unit source value | Required properties |
|---|---|---:|---:|---|---:|---:|---|
| 0 | Wood handle | 3 | 9 | substrate / true | 0.1 lb | 7500 gp | substrate |
| 1 | Coal | 2 | 9 | fuel / true | 1 lb | 7500 gp | fuel |
| 2 | Tempering oil | 4 | 9 | solvent / true | 0.5 lb | 7500 gp | solvent |
| 3 | Heartsteel Ingot | 5 | 9 | substrate / true | 1 lb | 7500 gp | substrate |
| 4 | Brightsteel Ingot | 2 | 9 | substrate / true | 1 lb | 7500 gp | substrate |
| 5 | Iron ingot | 1 | 9 | substrate / true | 1 lb | 7500 gp | substrate |
| 6 | refined air core | 1 | 4 | material / true | 0.27 lb | 262 gp | air, resonant, rigid |
| 7 | pulsing air crystal | 1 | 5 | material / true | 0.28 lb | 1240 gp | air, epic, resonant, rigid |

**Work:** STR or INT under the shared crafting check; Forge and Anvil; tools: Smith's tools, Forge, Anvil, Tongs. Maximum assistants 2; fieldCraftable=false, preserved timeMode=haven. The false field flag controls: an actual Forge-and-Anvil worksite is still required. Ordinary first stable phase 8 active hour(s), included in total. An eligible Forge Dwarf uses 7200 actual active minutes, first phase 480 minutes; no extra time reduction from assistants.

**Results:** Standard 1; Exceptional yield 1; Masterwork yield 1; structural option 1 with strongest noncompounding 25%/50% durability layer. Flawed: one unit establishing the single persistent half-maximum flaw after ordinary size/grade and strongest durability improvement; preserve damage deficit, possibly emerging Broken. Failed/Mishap transforms no base; source ingredient recovery/loss still applies. Masterwork returns at most one eligible consumed catalyst unit total, never one per occurrence or finished item.

**Repair:** functioning HP≥1 uses trained Smith's tools, actual Forge/Anvil/Tongs, STR/INT DC10, max(1 hour, actual max HP/10 hours), materials 25% mundane size/grade base value. HP0 with recoverable main body uses original recipe DC 22, max(8 hours, actual max HP/10 hours), materials 25% undamaged finished unit reference. Both are binary repair tasks; no formula/trade-level entitlement required or granted, no creation-only time reduction, crafting XP, quality roll or catalyst. Existing grade, durability state and flaw persist.

**Reference accounting:** source magic/process share 175593 gp per unit, plus the actual transformed base's undamaged mundane size/grade reference. Real owned bases need no repurchase; purchased reserves are separate expenses. No automatic artifact multiplier, quality markup or guaranteed mundane-table magic buyback.

**Source access:** {"sources":["sealed library","world event","Gate Guardian cache","multiseason research"],"minimumResearchHours":40,"requiresFormula":true,"formulaConsumed":false}. Visibility and actual ingredient availability remain source-controlled.

**Preserved tags:** Air, Earth. **Operative tag:** Air. Secondary tags grant no additional mechanics.

**Preserved legacy (inactive):** {"legacyName": "Mythical Shield", "legacyEffect": "Deals an extra 2d6 damage of a specific type"}.

**Optional preserved Director guidance:** "Deep-tier provisional (skill 11+ → restricted or undiscovered depth). Components are real costs — do not treat as free craft. Director: (1) require components as listed or 1:1 Instruments salvage swap; (2) gate availability behind Floor/tier access or a named haven workshop; (3) if the result feels too strong for current floor, add downtime hours (skillLevel × 2 hours suggested) or a rare catalyst from the current Gate zone;". This is not an automatic extra gate.

## recipe-77 — Ascendant Gale Weapon of Pulsing Water Crystal

**Source:** director-only; Blacksmithing level 18; tier 9; Legendary; crafting DC 24; 2 months / 320 active hours; Standard quantity 1. Source Standard batch reference 137584 gp.

**Preserved effect:** Creates a durable weapon with +3 to attack and damage rolls and 4d4 additional thunder damage once per turn.

**Operational effect:** One actual weapon base becomes an intact magical nonartifact output. With this weapon's actual attacks, use recipe +3 in the item-accuracy family and add +3 once to ordinary weapon-hit damage. Legal thrown/off-hand attacks retain these benefits; carrying it does not. Unsuppressed ordinary B/P/S counts magical. On a legal hit, optionally add 4d4 thunder as part of that same attack damage event, once per physical item per actual turn; choose before damage. Criticals double these dice, never the flat bonus. Use the shared off-turn, copy, companion and six-second transition rules. Broken stops positive functions; suppression stops recipe magic only. The complete base, quality, repair and value rules apply.

**Legal base models:** Dagger, Dart, Handaxe, Javelin, Light hammer, Mace, Sickle, Spear, Battleaxe, Flail, Glaive, Greataxe, Greatsword, Halberd, Lance, Longsword, Maul, Morningstar, Pike, Rapier, Scimitar, Shortsword, Trident, War pick, Warhammer, Kama. Choose one model, size and actual legal equipment grade for the whole batch before work.

**Physical reserve:** 1 complete legal mundane bases, ordered before work. Transform the first resolved N; keep original inventory identity, actual grade/material/damage and source access. All source ingredients below are additional inputs; none supplies a free body.

| Base model | Ordinary Standard price | Weight | Ordinary max HP | Actual base combat profile | Finished unit reference with this ordinary base |
|---|---:|---:|---:|---|---:|
| Dagger | 2 gp | 1 lb | 5 | 1d4 piercing; Finesse, light, thrown (range 20/60) | 137586 gp |
| Dart | 0.05 gp | 0.25 lb | 5 | 1d4 piercing; Finesse, thrown (range 20/60) | 137584.05 gp |
| Handaxe | 5 gp | 2 lb | 5 | 1d6 slashing; Light, thrown (range 20/60) | 137589 gp |
| Javelin | 0.5 gp | 2 lb | 5 | 1d6 piercing; Thrown (range 30/120) | 137584.5 gp |
| Light hammer | 2 gp | 2 lb | 5 | 1d4 bludgeoning; Light, thrown (range 20/60) | 137586 gp |
| Mace | 5 gp | 4 lb | 5 | 1d6 bludgeoning; , | 137589 gp |
| Sickle | 1 gp | 2 lb | 5 | 1d4 slashing; Light | 137585 gp |
| Spear | 1 gp | 3 lb | 5 | 1d6 piercing; Thrown (range 20/60), versatile (1d8) | 137585 gp |
| Battleaxe | 10 gp | 4 lb | 5 | 1d8 slashing; Versatile (1d10) | 137594 gp |
| Flail | 10 gp | 2 lb | 5 | 1d8 bludgeoning; , | 137594 gp |
| Glaive | 20 gp | 6 lb | 5 | 1d10 slashing; Heavy, reach, two-handed | 137604 gp |
| Greataxe | 30 gp | 7 lb | 5 | 1d12 slashing; Heavy, two-handed | 137614 gp |
| Greatsword | 50 gp | 6 lb | 5 | 2d6 slashing; Heavy, two-handed | 137634 gp |
| Halberd | 20 gp | 6 lb | 5 | 1d10 slashing; Heavy, reach, two-handed | 137604 gp |
| Lance | 10 gp | 6 lb | 5 | 1d12 piercing; Reach, special | 137594 gp |
| Longsword | 15 gp | 3 lb | 5 | 1d8 slashing; Versatile (1d10) | 137599 gp |
| Maul | 10 gp | 10 lb | 5 | 2d6 bludgeoning; Heavy, two-handed | 137594 gp |
| Morningstar | 15 gp | 4 lb | 5 | 1d8 piercing; , | 137599 gp |
| Pike | 5 gp | 18 lb | 5 | 1d10 piercing; Heavy, reach, two-handed | 137589 gp |
| Rapier | 25 gp | 2 lb | 5 | 1d8 piercing; Finesse | 137609 gp |
| Scimitar | 25 gp | 3 lb | 5 | 1d6 slashing; Finesse, light | 137609 gp |
| Shortsword | 10 gp | 2 lb | 5 | 1d6 piercing; Finesse, light | 137594 gp |
| Trident | 5 gp | 4 lb | 5 | 1d6 piercing; Thrown (range 20/60), versatile (1d8) | 137589 gp |
| War pick | 5 gp | 2 lb | 5 | 1d8 piercing; , | 137589 gp |
| Warhammer | 15 gp | 2 lb | 5 | 1d8 bludgeoning; Versatile (1d10) | 137599 gp |
| Kama | 2 gp | 2 lb | 5 | 1d4 slashing; Light | 137586 gp |

These are Small/Medium/Tiny ordinary Standard examples, not automatic item grants or material-AC assignments. Actual bases retain the complete equipment profile, requirements and legitimate size/grade valuation. Large doubles base price/weight/ordinary HP, not the source magic/process share. Record actual dominant material before work; the shared structural and damage-preservation rules apply.

**Exact source components:**

| Occurrence | Component | Quantity | Tier | Role / consumed | Unit mass | Unit source value | Required properties |
|---|---|---:|---:|---|---:|---:|---|
| 0 | Leather strips | 5 | 9 | substrate / true | 0.25 lb | 7500 gp | substrate |
| 1 | Brightsteel Ingot | 3 | 9 | substrate / true | 1 lb | 7500 gp | substrate |
| 2 | Tempering oil | 1 | 9 | solvent / true | 0.5 lb | 7500 gp | solvent |
| 3 | Coal | 2 | 9 | fuel / true | 1 lb | 7500 gp | fuel |
| 4 | Forge water | 1 | 9 | tool / false | 25 lb | 22500 gp | tool |
| 5 | Iron ingot | 2 | 9 | substrate / true | 1 lb | 7500 gp | substrate |
| 6 | pulsing water crystal | 1 | 5 | material / true | 0.09 lb | 1041 gp | epic, resonant, rigid, water |
| 7 | pulsing air crystal | 1 | 5 | material / true | 0.28 lb | 1240 gp | air, epic, resonant, rigid |

**Work:** STR or INT under the shared crafting check; Forge and Anvil; tools: Smith's tools, Forge, Anvil, Tongs. Maximum assistants 2; fieldCraftable=false, preserved timeMode=legacy. The false field flag controls: an actual Forge-and-Anvil worksite is still required. Ordinary first stable phase 8 active hour(s), included in total. An eligible Forge Dwarf uses 14400 actual active minutes, first phase 480 minutes; no extra time reduction from assistants.

**Results:** Standard 1; Exceptional yield 1; Masterwork yield 1; structural option 1 with strongest noncompounding 25%/50% durability layer. Flawed: one unit establishing the single persistent half-maximum flaw after ordinary size/grade and strongest durability improvement; preserve damage deficit, possibly emerging Broken. Failed/Mishap transforms no base; source ingredient recovery/loss still applies. Masterwork returns at most one eligible consumed catalyst unit total, never one per occurrence or finished item.

**Repair:** functioning HP≥1 uses trained Smith's tools, actual Forge/Anvil/Tongs, STR/INT DC10, max(1 hour, actual max HP/10 hours), materials 25% mundane size/grade base value. HP0 with recoverable main body uses original recipe DC 24, max(8 hours, actual max HP/10 hours), materials 25% undamaged finished unit reference. Both are binary repair tasks; no formula/trade-level entitlement required or granted, no creation-only time reduction, crafting XP, quality roll or catalyst. Existing grade, durability state and flaw persist.

**Reference accounting:** source magic/process share 137584 gp per unit, plus the actual transformed base's undamaged mundane size/grade reference. Real owned bases need no repurchase; purchased reserves are separate expenses. No automatic artifact multiplier, quality markup or guaranteed mundane-table magic buyback.

**Source access:** {"sources":["sealed library","world event","Gate Guardian cache","multiseason research"],"minimumResearchHours":40,"requiresFormula":true,"formulaConsumed":false}. Visibility and actual ingredient availability remain source-controlled.

**Preserved tags:** Air, Water. **Operative tag:** Air. Secondary tags grant no additional mechanics.

**Preserved legacy (inactive):** {"legacyName": "Legendary Chain", "legacyEffect": "AC 22 + damage resistance"}.

**Optional preserved Director guidance:** "Legendary/Mythic quality — provisional balance. Components are real costs — do not empty or waive casually. Director: (1) treat as campaign-defining rewards (Gate seal, research breakthrough, or named NPC commission); (2) require full listed components or Instruments tier salvage of equal or higher tier; (3) optional: add a Resonance ritual (1 long rest + Weave check DC 15 + skillLevel) before completion; (4) keep Heartcell/Silent Ones names out of the public craft ledger.". This is not an automatic extra gate.

## recipe-78 — Transcendent Storm Sword of Blue Dragon Claw

**Source:** director-only; Blacksmithing level 19; tier 10; Legendary; crafting DC 25; 2 months / 320 active hours; Standard quantity 1. Source Standard batch reference 465786 gp.

**Preserved effect:** Creates a durable sword with +3 to attack and damage rolls and 4d4 additional lightning damage once per turn.

**Operational effect:** One actual sword base becomes an intact magical nonartifact output. With this weapon's actual attacks, use recipe +3 in the item-accuracy family and add +3 once to ordinary weapon-hit damage. Legal thrown/off-hand attacks retain these benefits; carrying it does not. Unsuppressed ordinary B/P/S counts magical. On a legal hit, optionally add 4d4 lightning as part of that same attack damage event, once per physical item per actual turn; choose before damage. Criticals double these dice, never the flat bonus. Use the shared off-turn, copy, companion and six-second transition rules. Broken stops positive functions; suppression stops recipe magic only. The complete base, quality, repair and value rules apply.

**Legal base models:** Shortsword, Longsword, Greatsword, Rapier, Scimitar. Choose one model, size and actual legal equipment grade for the whole batch before work.

**Physical reserve:** 1 complete legal mundane bases, ordered before work. Transform the first resolved N; keep original inventory identity, actual grade/material/damage and source access. All source ingredients below are additional inputs; none supplies a free body.

| Base model | Ordinary Standard price | Weight | Ordinary max HP | Actual base combat profile | Finished unit reference with this ordinary base |
|---|---:|---:|---:|---|---:|
| Shortsword | 10 gp | 2 lb | 5 | 1d6 piercing; Finesse, light | 465796 gp |
| Longsword | 15 gp | 3 lb | 5 | 1d8 slashing; Versatile (1d10) | 465801 gp |
| Greatsword | 50 gp | 6 lb | 5 | 2d6 slashing; Heavy, two-handed | 465836 gp |
| Rapier | 25 gp | 2 lb | 5 | 1d8 piercing; Finesse | 465811 gp |
| Scimitar | 25 gp | 3 lb | 5 | 1d6 slashing; Finesse, light | 465811 gp |

These are Small/Medium/Tiny ordinary Standard examples, not automatic item grants or material-AC assignments. Actual bases retain the complete equipment profile, requirements and legitimate size/grade valuation. Large doubles base price/weight/ordinary HP, not the source magic/process share. Record actual dominant material before work; the shared structural and damage-preservation rules apply.

**Exact source components:**

| Occurrence | Component | Quantity | Tier | Role / consumed | Unit mass | Unit source value | Required properties |
|---|---|---:|---:|---|---:|---:|---|
| 0 | Brightsteel Ingot | 4 | 10 | substrate / true | 1 lb | 18000 gp | substrate |
| 1 | Forge water | 1 | 10 | tool / false | 25 lb | 54000 gp | tool |
| 2 | Metal rivets | 3 | 10 | binder / true | 0.1 lb | 18000 gp | binder |
| 3 | Steel ingot | 5 | 10 | substrate / true | 1 lb | 18000 gp | substrate |
| 4 | Iron ingot | 3 | 10 | substrate / true | 1 lb | 18000 gp | substrate |
| 5 | Tempering oil | 4 | 10 | solvent / true | 0.5 lb | 18000 gp | solvent |
| 6 | blue dragon claw | 1 | 4 | material / true | 0.08 lb | 308 gp | draconic, lightning, rigid, structural |
| 7 | blue dragon horn | 1 | 4 | material / true | 0.24 lb | 467 gp | draconic, lightning, piercing, rigid |

**Work:** STR or INT under the shared crafting check; Forge and Anvil; tools: Smith's tools, Forge, Anvil, Tongs. Maximum assistants 2; fieldCraftable=false, preserved timeMode=legacy. The false field flag controls: an actual Forge-and-Anvil worksite is still required. Ordinary first stable phase 8 active hour(s), included in total. An eligible Forge Dwarf uses 14400 actual active minutes, first phase 480 minutes; no extra time reduction from assistants.

**Results:** Standard 1; Exceptional yield 1; Masterwork yield 1; structural option 1 with strongest noncompounding 25%/50% durability layer. Flawed: one unit establishing the single persistent half-maximum flaw after ordinary size/grade and strongest durability improvement; preserve damage deficit, possibly emerging Broken. Failed/Mishap transforms no base; source ingredient recovery/loss still applies. Masterwork returns at most one eligible consumed catalyst unit total, never one per occurrence or finished item.

**Repair:** functioning HP≥1 uses trained Smith's tools, actual Forge/Anvil/Tongs, STR/INT DC10, max(1 hour, actual max HP/10 hours), materials 25% mundane size/grade base value. HP0 with recoverable main body uses original recipe DC 25, max(8 hours, actual max HP/10 hours), materials 25% undamaged finished unit reference. Both are binary repair tasks; no formula/trade-level entitlement required or granted, no creation-only time reduction, crafting XP, quality roll or catalyst. Existing grade, durability state and flaw persist.

**Reference accounting:** source magic/process share 465786 gp per unit, plus the actual transformed base's undamaged mundane size/grade reference. Real owned bases need no repurchase; purchased reserves are separate expenses. No automatic artifact multiplier, quality markup or guaranteed mundane-table magic buyback.

**Source access:** {"sources":["sealed library","world event","Gate Guardian cache","multiseason research"],"minimumResearchHours":44,"requiresFormula":true,"formulaConsumed":false}. Visibility and actual ingredient availability remain source-controlled.

**Preserved tags:** Lightning, Strength. **Operative tag:** Lightning. Secondary tags grant no additional mechanics.

**Preserved legacy (inactive):** {"legacyName": "Celestial Iron Sword", "legacyEffect": "Deals an extra 3d6 damage of a specific type"}.

**Optional preserved Director guidance:** "Legendary/Mythic quality — provisional balance. Components are real costs — do not empty or waive casually. Director: (1) treat as campaign-defining rewards (Gate seal, research breakthrough, or named NPC commission); (2) require full listed components or Instruments tier salvage of equal or higher tier; (3) optional: add a Resonance ritual (1 long rest + Weave check DC 15 + skillLevel) before completion; (4) keep Heartcell/Silent Ones names out of the public craft ledger.". This is not an automatic extra gate.

## recipe-79 — Ascendant Vital Mace of Pulsing Elemental Crystal

**Source:** director-only; Blacksmithing level 18; tier 9; Legendary; crafting DC 25; 2 months / 320 active hours; Standard quantity 1. Source Standard batch reference 137132 gp.

**Preserved effect:** Creates a durable mace with +3 to attack and damage rolls and 4d4 additional radiant damage once per turn.

**Operational effect:** One actual mace base becomes an intact magical nonartifact output. With this weapon's actual attacks, use recipe +3 in the item-accuracy family and add +3 once to ordinary weapon-hit damage. Legal thrown/off-hand attacks retain these benefits; carrying it does not. Unsuppressed ordinary B/P/S counts magical. On a legal hit, optionally add 4d4 radiant as part of that same attack damage event, once per physical item per actual turn; choose before damage. Criticals double these dice, never the flat bonus. Use the shared off-turn, copy, companion and six-second transition rules. Broken stops positive functions; suppression stops recipe magic only. The complete base, quality, repair and value rules apply.

**Legal base models:** Mace, Flail, Morningstar. Choose one model, size and actual legal equipment grade for the whole batch before work.

**Physical reserve:** 1 complete legal mundane bases, ordered before work. Transform the first resolved N; keep original inventory identity, actual grade/material/damage and source access. All source ingredients below are additional inputs; none supplies a free body.

| Base model | Ordinary Standard price | Weight | Ordinary max HP | Actual base combat profile | Finished unit reference with this ordinary base |
|---|---:|---:|---:|---|---:|
| Mace | 5 gp | 4 lb | 5 | 1d6 bludgeoning; , | 137137 gp |
| Flail | 10 gp | 2 lb | 5 | 1d8 bludgeoning; , | 137142 gp |
| Morningstar | 15 gp | 4 lb | 5 | 1d8 piercing; , | 137147 gp |

These are Small/Medium/Tiny ordinary Standard examples, not automatic item grants or material-AC assignments. Actual bases retain the complete equipment profile, requirements and legitimate size/grade valuation. Large doubles base price/weight/ordinary HP, not the source magic/process share. Record actual dominant material before work; the shared structural and damage-preservation rules apply.

**Exact source components:**

| Occurrence | Component | Quantity | Tier | Role / consumed | Unit mass | Unit source value | Required properties |
|---|---|---:|---:|---|---:|---:|---|
| 0 | Steel ingot | 1 | 9 | substrate / true | 1 lb | 7500 gp | substrate |
| 1 | Tempering oil | 4 | 9 | solvent / true | 0.5 lb | 7500 gp | solvent |
| 2 | Coal | 2 | 9 | fuel / true | 1 lb | 7500 gp | fuel |
| 3 | Leather strips | 4 | 9 | substrate / true | 0.25 lb | 7500 gp | substrate |
| 4 | Heartsteel Ingot | 2 | 9 | substrate / true | 1 lb | 7500 gp | substrate |
| 5 | pulsing elemental crystal | 1 | 5 | material / true | 0.11 lb | 1375 gp | arcane, epic, resonant, rigid |
| 6 | green dragon heartstone | 1 | 5 | catalyst / true | 0.23 lb | 571 gp | draconic, earth, epic, poison, power-bearing, vital |

**Work:** STR or INT under the shared crafting check; Forge and Anvil; tools: Smith's tools, Forge, Anvil, Tongs. Maximum assistants 2; fieldCraftable=false, preserved timeMode=legacy. The false field flag controls: an actual Forge-and-Anvil worksite is still required. Ordinary first stable phase 8 active hour(s), included in total. An eligible Forge Dwarf uses 14400 actual active minutes, first phase 480 minutes; no extra time reduction from assistants.

**Results:** Standard 1; Exceptional yield 1; Masterwork yield 1; structural option 1 with strongest noncompounding 25%/50% durability layer. Flawed: one unit establishing the single persistent half-maximum flaw after ordinary size/grade and strongest durability improvement; preserve damage deficit, possibly emerging Broken. Failed/Mishap transforms no base; source ingredient recovery/loss still applies. Masterwork returns at most one eligible consumed catalyst unit total, never one per occurrence or finished item.

**Repair:** functioning HP≥1 uses trained Smith's tools, actual Forge/Anvil/Tongs, STR/INT DC10, max(1 hour, actual max HP/10 hours), materials 25% mundane size/grade base value. HP0 with recoverable main body uses original recipe DC 25, max(8 hours, actual max HP/10 hours), materials 25% undamaged finished unit reference. Both are binary repair tasks; no formula/trade-level entitlement required or granted, no creation-only time reduction, crafting XP, quality roll or catalyst. Existing grade, durability state and flaw persist.

**Reference accounting:** source magic/process share 137132 gp per unit, plus the actual transformed base's undamaged mundane size/grade reference. Real owned bases need no repurchase; purchased reserves are separate expenses. No automatic artifact multiplier, quality markup or guaranteed mundane-table magic buyback.

**Source access:** {"sources":["sealed library","world event","Gate Guardian cache","multiseason research"],"minimumResearchHours":40,"requiresFormula":true,"formulaConsumed":false}. Visibility and actual ingredient availability remain source-controlled.

**Preserved tags:** Vitality, Arcane. **Operative tag:** Vitality. Secondary tags grant no additional mechanics.

**Preserved legacy (inactive):** {"legacyName": "Celestial Mace", "legacyEffect": "Deals an extra 3d6 damage of a specific type"}.

**Optional preserved Director guidance:** "Legendary/Mythic quality — provisional balance. Components are real costs — do not empty or waive casually. Director: (1) treat as campaign-defining rewards (Gate seal, research breakthrough, or named NPC commission); (2) require full listed components or Instruments tier salvage of equal or higher tier; (3) optional: add a Resonance ritual (1 long rest + Weave check DC 15 + skillLevel) before completion; (4) keep Heartcell/Silent Ones names out of the public craft ledger.". This is not an automatic extra gate.

## recipe-80 — Transcendent Resonant Gauntlets of Green Dragonheart

**Source:** director-only; Blacksmithing level 20; tier 10; Mythic; crafting DC 27; 6 months / 960 active hours; Standard quantity 1. Source Standard batch reference 449313 gp.

**Preserved effect:** Creates reinforced gauntlets granting +3 AC and resistance to force damage while worn.

**Operational effect:** One actual matched Gauntlets pair becomes one intact magical nonartifact output. While legally equipped, offer +3 to equipment.defense-enhancement, using the strongest eligible recipe/suit-grade modifier; retain the base suit formula or shield contribution where applicable. Its actual wearing rule separately supplies force resistance even if a stronger AC enhancement wins. Broken stops positive functions; suppression stops recipe magic only. The complete base, quality, repair and value rules apply.

**Legal base models:** Gauntlets blank. Choose one model, size and actual legal equipment grade for the whole batch before work.

**Physical reserve:** 1 complete legal mundane bases, ordered before work. Transform the first resolved N; keep original inventory identity, actual grade/material/damage and source access. All source ingredients below are additional inputs; none supplies a free body.

| Base model | Ordinary Standard price | Weight | Ordinary max HP | Actual base combat profile | Finished unit reference with this ordinary base |
|---|---:|---:|---:|---|---:|
| Gauntlets blank | 10 gp | 4 lb | 5 | No mundane AC bonus; recipe supplies actual enhancement/resistance. | 449323 gp |

These are Small/Medium/Tiny ordinary Standard examples, not automatic item grants or material-AC assignments. Actual bases retain the complete equipment profile, requirements and legitimate size/grade valuation. Large doubles base price/weight/ordinary HP, not the source magic/process share. Record actual dominant material before work; the shared structural and damage-preservation rules apply.

**Exact source components:**

| Occurrence | Component | Quantity | Tier | Role / consumed | Unit mass | Unit source value | Required properties |
|---|---|---:|---:|---|---:|---:|---|
| 0 | Iron ingot | 4 | 10 | substrate / true | 1 lb | 18000 gp | substrate |
| 1 | Brightsteel Ingot | 5 | 10 | substrate / true | 1 lb | 18000 gp | substrate |
| 2 | Metal rivets | 5 | 10 | binder / true | 0.1 lb | 18000 gp | binder |
| 3 | Forge water | 1 | 10 | tool / false | 25 lb | 54000 gp | tool |
| 4 | Coal | 2 | 10 | fuel / true | 1 lb | 18000 gp | fuel |
| 5 | Heartsteel Ingot | 2 | 10 | substrate / true | 1 lb | 18000 gp | substrate |
| 6 | green dragon heartstone | 1 | 5 | catalyst / true | 0.23 lb | 571 gp | draconic, earth, epic, poison, power-bearing, vital |
| 7 | green dragon heartstone | 1 | 5 | catalyst / true | 0.23 lb | 571 gp | draconic, earth, epic, poison, power-bearing, vital |
| 8 | green dragon heartstone | 1 | 5 | catalyst / true | 0.23 lb | 571 gp | draconic, earth, epic, poison, power-bearing, vital |

**Work:** STR or INT under the shared crafting check; Forge and Anvil; tools: Smith's tools, Forge, Anvil, Tongs. Maximum assistants 3; fieldCraftable=false, preserved timeMode=legacy. The false field flag controls: an actual Forge-and-Anvil worksite is still required. Ordinary first stable phase 8 active hour(s), included in total. An eligible Forge Dwarf uses 43200 actual active minutes, first phase 480 minutes; no extra time reduction from assistants.

**Results:** Standard 1; Exceptional yield 1; Masterwork yield 1; structural option 1 with strongest noncompounding 25%/50% durability layer. Flawed: one unit establishing the single persistent half-maximum flaw after ordinary size/grade and strongest durability improvement; preserve damage deficit, possibly emerging Broken. Failed/Mishap transforms no base; source ingredient recovery/loss still applies. Masterwork returns at most one eligible consumed catalyst unit total, never one per occurrence or finished item.

**Repair:** functioning HP≥1 uses trained Smith's tools, actual Forge/Anvil/Tongs, STR/INT DC10, max(1 hour, actual max HP/10 hours), materials 25% mundane size/grade base value. HP0 with recoverable main body uses original recipe DC 27, max(8 hours, actual max HP/10 hours), materials 25% undamaged finished unit reference. Both are binary repair tasks; no formula/trade-level entitlement required or granted, no creation-only time reduction, crafting XP, quality roll or catalyst. Existing grade, durability state and flaw persist.

**Reference accounting:** source magic/process share 449313 gp per unit, plus the actual transformed base's undamaged mundane size/grade reference. Real owned bases need no repurchase; purchased reserves are separate expenses. No automatic artifact multiplier, quality markup or guaranteed mundane-table magic buyback.

**Source access:** {"sources":["sealed library","world event","Gate Guardian cache","multiseason research"],"minimumResearchHours":48,"requiresFormula":true,"formulaConsumed":false}. Visibility and actual ingredient availability remain source-controlled.

**Preserved tags:** Arcane, Poison, Vitality. **Operative tag:** Arcane. Secondary tags grant no additional mechanics.

**Separate catalysts:** every listed occurrence requires its actual quantity, even when names/IDs repeat. The Masterwork return remains one eligible unit total.

**Preserved legacy (inactive):** {"legacyName": "Godly Dwarven Gauntlets", "legacyEffect": "AC 25 + damage immunity"}.

**Optional preserved Director guidance:** "Legendary/Mythic quality — provisional balance. Components are real costs — do not empty or waive casually. Director: (1) treat as campaign-defining rewards (Gate seal, research breakthrough, or named NPC commission); (2) require full listed components or Instruments tier salvage of equal or higher tier; (3) optional: add a Resonance ritual (1 long rest + Weave check DC 15 + skillLevel) before completion; (4) keep Heartcell/Silent Ones names out of the public craft ledger.". This is not an automatic extra gate.

## recipe-628 — Alien-Chitin Lamellar

**Source:** public; Blacksmithing level 5; tier 3; Uncommon; crafting DC 13; 8 hours / 8 active hours; Standard quantity 1. Source Standard batch reference 208 gp.

**Preserved effect:** Creates reinforced armor granting +1 AC.

**Operational effect:** One actual armor base becomes an intact magical nonartifact output. While legally equipped, offer +1 to equipment.defense-enhancement, using the strongest eligible recipe/suit-grade modifier; retain the base suit formula or shield contribution where applicable. No resistance is granted by its title, ingredient or tag. Broken stops positive functions; suppression stops recipe magic only. The complete base, quality, repair and value rules apply.

**Legal base models:** Scale mail. This card fixes its base model.

**Physical reserve:** 1 complete legal mundane bases, ordered before work. Transform the first resolved N; keep original inventory identity, actual grade/material/damage and source access. All source ingredients below are additional inputs; none supplies a free body.

| Base model | Ordinary Standard price | Weight | Ordinary max HP | Actual base combat profile | Finished unit reference with this ordinary base |
|---|---:|---:|---:|---|---:|
| Scale mail | 50 gp | 45 lb | 15 | 14 + Dex modifier (max 2) | 258 gp |

These are Small/Medium/Tiny ordinary Standard examples, not automatic item grants or material-AC assignments. Actual bases retain the complete equipment profile, requirements and legitimate size/grade valuation. Large doubles base price/weight/ordinary HP, not the source magic/process share. Record actual dominant material before work; the shared structural and damage-preservation rules apply.

**Exact source components:**

| Occurrence | Component | Quantity | Tier | Role / consumed | Unit mass | Unit source value | Required properties |
|---|---|---:|---:|---|---:|---:|---|
| 0 | alien chitin | 1 | 2 | material / true | 0.18 lb | 50 gp | protective, rigid |
| 1 | Iron ingot | 1 | 3 | substrate / true | 1 lb | 25 gp | substrate |
| 2 | Leather strips | 1 | 3 | substrate / true | 0.25 lb | 25 gp | substrate |
| 3 | Metal rivets | 1 | 3 | binder / true | 0.1 lb | 25 gp | binder |

**Work:** STR or INT under the shared crafting check; Forge and Anvil; tools: Smith's tools, Forge, Anvil, Tongs. Maximum assistants 0; fieldCraftable=false, preserved timeMode=expedition. The false field flag controls: an actual Forge-and-Anvil worksite is still required. Ordinary first stable phase 8 active hour(s), included in total. An eligible Forge Dwarf uses 360 actual active minutes, first phase 360 minutes; no extra time reduction from assistants.

**Results:** Standard 1; Exceptional yield 1; Masterwork yield 1; structural option 1 with strongest noncompounding 25%/50% durability layer. Flawed: one unit establishing the single persistent half-maximum flaw after ordinary size/grade and strongest durability improvement; preserve damage deficit, possibly emerging Broken. Failed/Mishap transforms no base; source ingredient recovery/loss still applies. Masterwork returns at most one eligible consumed catalyst unit total, never one per occurrence or finished item.

**Repair:** functioning HP≥1 uses trained Smith's tools, actual Forge/Anvil/Tongs, STR/INT DC10, max(1 hour, actual max HP/10 hours), materials 25% mundane size/grade base value. HP0 with recoverable main body uses original recipe DC 13, max(8 hours, actual max HP/10 hours), materials 25% undamaged finished unit reference. Both are binary repair tasks; no formula/trade-level entitlement required or granted, no creation-only time reduction, crafting XP, quality roll or catalyst. Existing grade, durability state and flaw persist.

**Reference accounting:** source magic/process share 208 gp per unit, plus the actual transformed base's undamaged mundane size/grade reference. Real owned bases need no repurchase; purchased reserves are separate expenses. No automatic artifact multiplier, quality markup or guaranteed mundane-table magic buyback.

**Source access:** {"sources":["guild trainer","faction vendor","uncommon dungeon book","reverse engineering"],"minimumResearchHours":0,"requiresFormula":true,"formulaConsumed":false}. Visibility and actual ingredient availability remain source-controlled.

**Preserved tags:** Acid. **Operative tag:** Acid. Secondary tags grant no additional mechanics.

## recipe-629 — Black-Dragon Bone Spear

**Source:** public; Blacksmithing level 5; tier 3; Uncommon; crafting DC 13; 8 hours / 8 active hours; Standard quantity 1. Source Standard batch reference 216 gp.

**Preserved effect:** Creates a durable spear with +1 to attack and damage rolls.

**Operational effect:** One actual spear base becomes an intact magical nonartifact output. With this weapon's actual attacks, use recipe +1 in the item-accuracy family and add +1 once to ordinary weapon-hit damage. Legal thrown/off-hand attacks retain these benefits; carrying it does not. Unsuppressed ordinary B/P/S counts magical. No elemental damage rider is granted by its title, ingredient or tag. Broken stops positive functions; suppression stops recipe magic only. The complete base, quality, repair and value rules apply.

**Legal base models:** Spear, Javelin, Trident, Pike, Lance. Choose one model, size and actual legal equipment grade for the whole batch before work.

**Physical reserve:** 1 complete legal mundane bases, ordered before work. Transform the first resolved N; keep original inventory identity, actual grade/material/damage and source access. All source ingredients below are additional inputs; none supplies a free body.

| Base model | Ordinary Standard price | Weight | Ordinary max HP | Actual base combat profile | Finished unit reference with this ordinary base |
|---|---:|---:|---:|---|---:|
| Spear | 1 gp | 3 lb | 5 | 1d6 piercing; Thrown (range 20/60), versatile (1d8) | 217 gp |
| Javelin | 0.5 gp | 2 lb | 5 | 1d6 piercing; Thrown (range 30/120) | 216.5 gp |
| Trident | 5 gp | 4 lb | 5 | 1d6 piercing; Thrown (range 20/60), versatile (1d8) | 221 gp |
| Pike | 5 gp | 18 lb | 5 | 1d10 piercing; Heavy, reach, two-handed | 221 gp |
| Lance | 10 gp | 6 lb | 5 | 1d12 piercing; Reach, special | 226 gp |

These are Small/Medium/Tiny ordinary Standard examples, not automatic item grants or material-AC assignments. Actual bases retain the complete equipment profile, requirements and legitimate size/grade valuation. Large doubles base price/weight/ordinary HP, not the source magic/process share. Record actual dominant material before work; the shared structural and damage-preservation rules apply.

**Exact source components:**

| Occurrence | Component | Quantity | Tier | Role / consumed | Unit mass | Unit source value | Required properties |
|---|---|---:|---:|---|---:|---:|---|
| 0 | black dragon bone | 1 | 2 | material / true | 0.48 lb | 29 gp | acid, draconic, rigid, structural |
| 1 | black dragon talon | 1 | 2 | material / true | 0.31 lb | 27 gp | acid, draconic, rigid, structural |
| 2 | Steel ingot | 1 | 3 | substrate / true | 1 lb | 25 gp | substrate |
| 3 | Wood handle | 1 | 3 | substrate / true | 0.1 lb | 25 gp | substrate |
| 4 | Tempering oil | 1 | 3 | solvent / true | 0.5 lb | 25 gp | solvent |

**Work:** STR or INT under the shared crafting check; Forge and Anvil; tools: Smith's tools, Forge, Anvil, Tongs. Maximum assistants 0; fieldCraftable=false, preserved timeMode=expedition. The false field flag controls: an actual Forge-and-Anvil worksite is still required. Ordinary first stable phase 8 active hour(s), included in total. An eligible Forge Dwarf uses 360 actual active minutes, first phase 360 minutes; no extra time reduction from assistants.

**Results:** Standard 1; Exceptional yield 1; Masterwork yield 1; structural option 1 with strongest noncompounding 25%/50% durability layer. Flawed: one unit establishing the single persistent half-maximum flaw after ordinary size/grade and strongest durability improvement; preserve damage deficit, possibly emerging Broken. Failed/Mishap transforms no base; source ingredient recovery/loss still applies. Masterwork returns at most one eligible consumed catalyst unit total, never one per occurrence or finished item.

**Repair:** functioning HP≥1 uses trained Smith's tools, actual Forge/Anvil/Tongs, STR/INT DC10, max(1 hour, actual max HP/10 hours), materials 25% mundane size/grade base value. HP0 with recoverable main body uses original recipe DC 13, max(8 hours, actual max HP/10 hours), materials 25% undamaged finished unit reference. Both are binary repair tasks; no formula/trade-level entitlement required or granted, no creation-only time reduction, crafting XP, quality roll or catalyst. Existing grade, durability state and flaw persist.

**Reference accounting:** source magic/process share 216 gp per unit, plus the actual transformed base's undamaged mundane size/grade reference. Real owned bases need no repurchase; purchased reserves are separate expenses. No automatic artifact multiplier, quality markup or guaranteed mundane-table magic buyback.

**Source access:** {"sources":["guild trainer","faction vendor","uncommon dungeon book","reverse engineering"],"minimumResearchHours":0,"requiresFormula":true,"formulaConsumed":false}. Visibility and actual ingredient availability remain source-controlled.

**Preserved tags:** Acid. **Operative tag:** Acid. Secondary tags grant no additional mechanics.

**Whole-creature metadata:** retained source label, with no borrowed trait, anatomy ability or extra donor effect.

## recipe-630 — Arcsteel Gate Shield

**Source:** director-only; Blacksmithing level 16; tier 9; Legendary; crafting DC 24; 1 month / 160 active hours; Standard quantity 1. Source Standard batch reference 37577 gp.

**Preserved effect:** Creates reinforced shield granting +3 AC and resistance to force damage while worn.

**Operational effect:** One actual shield base becomes an intact magical nonartifact output. While legally equipped, offer +3 to equipment.defense-enhancement, using the strongest eligible recipe/suit-grade modifier; retain the base suit formula or shield contribution where applicable. Its actual wearing rule separately supplies force resistance even if a stronger AC enhancement wins. Broken stops positive functions; suppression stops recipe magic only. The complete base, quality, repair and value rules apply.

**Legal base models:** Buckler, Shield, Tower shield. Choose one model, size and actual legal equipment grade for the whole batch before work.

**Physical reserve:** 1 complete legal mundane bases, ordered before work. Transform the first resolved N; keep original inventory identity, actual grade/material/damage and source access. All source ingredients below are additional inputs; none supplies a free body.

| Base model | Ordinary Standard price | Weight | Ordinary max HP | Actual base combat profile | Finished unit reference with this ordinary base |
|---|---:|---:|---:|---|---:|
| Buckler | 5 gp | 3 lb | 10 | +1 | 37582 gp |
| Shield | 10 gp | 6 lb | 10 | +2 | 37587 gp |
| Tower shield | 50 gp | 15 lb | 15 | +3 | 37627 gp |

These are Small/Medium/Tiny ordinary Standard examples, not automatic item grants or material-AC assignments. Actual bases retain the complete equipment profile, requirements and legitimate size/grade valuation. Large doubles base price/weight/ordinary HP, not the source magic/process share. Record actual dominant material before work; the shared structural and damage-preservation rules apply.

**Exact source components:**

| Occurrence | Component | Quantity | Tier | Role / consumed | Unit mass | Unit source value | Required properties |
|---|---|---:|---:|---|---:|---:|---|
| 0 | arcsteel plating | 1 | 4 | material / true | 0.23 lb | 277 gp | construct, specialized |
| 1 | core crystal | 1 | 5 | material / true | 0.11 lb | 1421 gp | epic, resonant, rigid |
| 2 | Brightsteel Ingot | 1 | 9 | substrate / true | 1 lb | 7500 gp | substrate |
| 3 | Metal rivets | 1 | 9 | binder / true | 0.1 lb | 7500 gp | binder |
| 4 | Tempering oil | 1 | 9 | solvent / true | 0.5 lb | 7500 gp | solvent |

**Work:** STR or INT under the shared crafting check; Forge and Anvil; tools: Smith's tools, Forge, Anvil, Tongs. Maximum assistants 2; fieldCraftable=false, preserved timeMode=haven. The false field flag controls: an actual Forge-and-Anvil worksite is still required. Ordinary first stable phase 8 active hour(s), included in total. An eligible Forge Dwarf uses 7200 actual active minutes, first phase 480 minutes; no extra time reduction from assistants.

**Results:** Standard 1; Exceptional yield 1; Masterwork yield 1; structural option 1 with strongest noncompounding 25%/50% durability layer. Flawed: one unit establishing the single persistent half-maximum flaw after ordinary size/grade and strongest durability improvement; preserve damage deficit, possibly emerging Broken. Failed/Mishap transforms no base; source ingredient recovery/loss still applies. Masterwork returns at most one eligible consumed catalyst unit total, never one per occurrence or finished item.

**Repair:** functioning HP≥1 uses trained Smith's tools, actual Forge/Anvil/Tongs, STR/INT DC10, max(1 hour, actual max HP/10 hours), materials 25% mundane size/grade base value. HP0 with recoverable main body uses original recipe DC 24, max(8 hours, actual max HP/10 hours), materials 25% undamaged finished unit reference. Both are binary repair tasks; no formula/trade-level entitlement required or granted, no creation-only time reduction, crafting XP, quality roll or catalyst. Existing grade, durability state and flaw persist.

**Reference accounting:** source magic/process share 37577 gp per unit, plus the actual transformed base's undamaged mundane size/grade reference. Real owned bases need no repurchase; purchased reserves are separate expenses. No automatic artifact multiplier, quality markup or guaranteed mundane-table magic buyback.

**Source access:** {"sources":["forbidden archive","named master crafter","Gate-zone research","complex reverse engineering"],"minimumResearchHours":32,"requiresFormula":true,"formulaConsumed":false}. Visibility and actual ingredient availability remain source-controlled.

**Preserved tags:** Arcane. **Operative tag:** Arcane. Secondary tags grant no additional mechanics.

**Whole-creature metadata:** retained source label, with no borrowed trait, anatomy ability or extra donor effect.

## recipe-631 — Ancient Red-Scale Cuirass

**Source:** director-only; Blacksmithing level 16; tier 9; Legendary; crafting DC 24; 1 month / 160 active hours; Standard quantity 1. Source Standard batch reference 39212 gp.

**Preserved effect:** Creates reinforced armor granting +3 AC and resistance to fire damage while worn.

**Operational effect:** One actual armor base becomes an intact magical nonartifact output. While legally equipped, offer +3 to equipment.defense-enhancement, using the strongest eligible recipe/suit-grade modifier; retain the base suit formula or shield contribution where applicable. Its actual wearing rule separately supplies fire resistance even if a stronger AC enhancement wins. Broken stops positive functions; suppression stops recipe magic only. The complete base, quality, repair and value rules apply.

**Legal base models:** Breastplate. This card fixes its base model.

**Physical reserve:** 1 complete legal mundane bases, ordered before work. Transform the first resolved N; keep original inventory identity, actual grade/material/damage and source access. All source ingredients below are additional inputs; none supplies a free body.

| Base model | Ordinary Standard price | Weight | Ordinary max HP | Actual base combat profile | Finished unit reference with this ordinary base |
|---|---:|---:|---:|---|---:|
| Breastplate | 400 gp | 20 lb | 15 | 14 + Dex modifier (max 2) | 39612 gp |

These are Small/Medium/Tiny ordinary Standard examples, not automatic item grants or material-AC assignments. Actual bases retain the complete equipment profile, requirements and legitimate size/grade valuation. Large doubles base price/weight/ordinary HP, not the source magic/process share. Record actual dominant material before work; the shared structural and damage-preservation rules apply.

**Exact source components:**

| Occurrence | Component | Quantity | Tier | Role / consumed | Unit mass | Unit source value | Required properties |
|---|---|---:|---:|---|---:|---:|---|
| 0 | ancient red dragon scale | 1 | 5 | material / true | 0.15 lb | 1465 gp | draconic, epic, fire, protective, rigid |
| 1 | red dragon heartstone | 1 | 5 | material / true | 0.16 lb | 1323 gp | draconic, earth, epic, fire, power-bearing, vital |
| 2 | Heartsteel Ingot | 1 | 9 | substrate / true | 1 lb | 7500 gp | substrate |
| 3 | Metal rivets | 1 | 9 | binder / true | 0.1 lb | 7500 gp | binder |
| 4 | Tempering oil | 1 | 9 | solvent / true | 0.5 lb | 7500 gp | solvent |

**Work:** STR or INT under the shared crafting check; Forge and Anvil; tools: Smith's tools, Forge, Anvil, Tongs. Maximum assistants 2; fieldCraftable=false, preserved timeMode=haven. The false field flag controls: an actual Forge-and-Anvil worksite is still required. Ordinary first stable phase 8 active hour(s), included in total. An eligible Forge Dwarf uses 7200 actual active minutes, first phase 480 minutes; no extra time reduction from assistants.

**Results:** Standard 1; Exceptional yield 1; Masterwork yield 1; structural option 1 with strongest noncompounding 25%/50% durability layer. Flawed: one unit establishing the single persistent half-maximum flaw after ordinary size/grade and strongest durability improvement; preserve damage deficit, possibly emerging Broken. Failed/Mishap transforms no base; source ingredient recovery/loss still applies. Masterwork returns at most one eligible consumed catalyst unit total, never one per occurrence or finished item.

**Repair:** functioning HP≥1 uses trained Smith's tools, actual Forge/Anvil/Tongs, STR/INT DC10, max(1 hour, actual max HP/10 hours), materials 25% mundane size/grade base value. HP0 with recoverable main body uses original recipe DC 24, max(8 hours, actual max HP/10 hours), materials 25% undamaged finished unit reference. Both are binary repair tasks; no formula/trade-level entitlement required or granted, no creation-only time reduction, crafting XP, quality roll or catalyst. Existing grade, durability state and flaw persist.

**Reference accounting:** source magic/process share 39212 gp per unit, plus the actual transformed base's undamaged mundane size/grade reference. Real owned bases need no repurchase; purchased reserves are separate expenses. No automatic artifact multiplier, quality markup or guaranteed mundane-table magic buyback.

**Source access:** {"sources":["forbidden archive","named master crafter","Gate-zone research","complex reverse engineering"],"minimumResearchHours":32,"requiresFormula":true,"formulaConsumed":false}. Visibility and actual ingredient availability remain source-controlled.

**Preserved tags:** Fire. **Operative tag:** Fire. Secondary tags grant no additional mechanics.

**Whole-creature metadata:** retained source label, with no borrowed trait, anatomy ability or extra donor effect.
