# Leatherworking public recipe cards

**REVIEWED — authored operational PLAYTEST.** Public projection: 30 public formulas; hidden formula/body records remain separately gated.

All cards require the complete [shared guide](LEATHERWORKING_RECIPE_PLAYTEST.md). Full preserved source records accompany the JSON; operational overlays never replace the historical text.

## recipe-280 — Refined Stone Backpack

**REVIEWED — authored operational PLAYTEST.** public; Leatherworking level 4; tier 2; Common; DC 9. Standard quantity 4; source Standard batch reference 178 gp.

**Preserved effect:** Creates a reinforced backpack carrying 10 pounds without counting against normal encumbrance; grants +1 to checks to secure or retrieve its contents.

**Operational effect:** One output transforms one complete mundane body, retaining its physical identity and latest lawful completion damage state. Functional means at least 1 current structural HP; the singleton Flawed result can emerge Broken with a dormant imprint. While functional, unsuppressed, unmelded, properly fitted and worn or directly held in its recorded back-cargo relief position, cover up to 10 lb of eligible contents in stable loading order. Physical capacity remains 30 lb and 1 ft³, subject to its actual opening, shape and compartment limits. Its own body is not relieved. For each covered record, subtract covered pounds from the direct bearer's pound-carrying comparison and at most min(canonical Load, covered pounds/10) from Inventory Load; preserve actual mass and canonical Load. Enclosed enchanted containers are inactive; ordinary inner bodies and descendants count once. External lashings do not become contents. The actual operator receives +1 on a qualifying handling check: Actual difficult cargo handling to secure its ordinary closure/retainers or retrieve through an unlocked closure, jam, tangle or other physical difficulty: DEX for dexterous work or STR (Athletics) for forceful handling of noncreature cargo. This handling benefit needs accessible functional unsuppressed fittings, not a relief slot, and can apply on a table or for an ally. Only the strongest qualifying Leatherworking task bonus applies once per actual check. No routine check is invented; ordinary actions, hands, access, proficiency and competing slot requirements still apply. Broken stops positive functions; suppression stops recipe magic, not physical capacity or workmanship. Use the complete shared guide for custody, melding, quality, repair and value.

**Legal mundane bases:** Backpack. One model, actual fit and legal grade for the whole batch. Buy, own or legitimately commission complete bodies; no stock-construction recipe is implied.

**Physical reserve:** 6 complete, nonmagical, non-Broken bases in a stable physical-ID order before work; containers empty. No existing imprint. Missing/Broken/committed bases pause before the roll; repair or replace at the same position. Transform the first resolved N, using latest lawful completion HP. Keep unused bodies in their actual state outside ingredient recovery.

| Mundane body | Price gp | Empty lb | Ordinary HP / structural AC | Benefit slot | Ordinary use |
|---|---:|---:|---|---|---|
| Backpack | 2 | 5 | 10 / 15 | back-cargo | 30 lb / 1 ft³ contents |

| Container | Compartments | Interior per compartment, inches | Opening, inches | Exterior, inches | Each compartment limit |
|---|---:|---|---|---|---|
| Backpack | 1 | 18 × 12 × 8 | 12 × 8 | 20 × 14 × 10 | 30 lb / 1 ft³ |

**Exact source component occurrences:**

| # | Component | Quantity | Tier | Role / consumed | Unit lb | Unit gp | Required properties |
|---|---|---:|---:|---|---:|---:|---|
| 0 | Lining | 2 | 2 | reinforcement / true | 0.25 | 8 | reinforcement |
| 1 | Leather strips | 2 | 2 | substrate / true | 0.25 | 8 | substrate |
| 2 | brimstone bone | 1 | 3 | material / true | 0.44 | 94 | earth, fire, rigid, structural |

All listed inputs are additional consumed process/reinforcement materials. Finished empty mass is the actual body mass; process waste supplies no second body or automatically valuable salvage. No source component is a catalyst; even Masterwork returns zero catalyst units. Independently required tools remain tools.

**Work and access:** DEX with actual Leatherworker's-tools proficiency as the shared framework permits; Tannery Bench; Leatherworker's tools, Awl, Cutting knife. Maximum assistants 0. Source fieldCraftable=false; preserved timeMode=expedition; the false field flag controls. Source time: 4 hours; source activeWorkHours=4. Operational required active time 4 hours. First stable phase 4 hours, included in total. Eligible Forge Dwarf: 180 minutes, first phase 180 minutes. Stabilize only components actually incorporated in the completed first phase; other lots keep their clocks.

**Progression:** exact source trivialAtSkillLevel=9; use this threshold rather than regenerating level+5. Actual formula access: {"sources":["trainer","starter manual","common experimentation"],"minimumResearchHours":0,"requiresFormula":false,"formulaConsumed":false}. The framework controls trade eligibility, proficiency once, assistant qualifications, Watches, rest, interruptions, XP and mishaps.

**Output:** Standard 4; Exceptional yield 5; Masterwork yield 6; or 4 units with strongest noncompounding structural improvement 25%/50%. Flawed: 2 ordinary-effect units, preserving existing physical durability state. Failed/Mishap transforms none; source input recovery/loss remains separate. Quality changes no capacity, relief, check bonus, AC, resistance or grade.

**Repair:** trained Leatherworker's tools, Tannery Bench, Awl and Cutting knife. Functional HP≥1: DEX + applicable proficiency DC10; max(1 hour, recorded max HP/10); materials 25% mundane base reference. Broken HP0: DEX + applicable proficiency DC9; max(8 hours, recorded max HP/10); materials 25% finished per-item reference; recoverable original main body required. Binary success restores recorded maximum, including the persistent flaw; failure consumes materials and time. No formula or original trade-level eligibility required or granted, quality roll, XP, catalyst return or Forge Dwarf creation reduction. No lost contents return.

**Finished ordinary Standard reference examples:** Backpack = 46.5 gp. Source process share 44.5 gp/unit plus actual undamaged mundane size/grade body reference. Retain exact precision until the actual transaction; no automatic buyer, quality premium, artifact multiplier or mundane-table magic buyback.

**Preserved tags:** Earth. Tags, current/legacy names, donors and whole-creature metadata add no powers or availability.

**Public source binding:** V5 ¶1625, ¶1626, ¶1627, ¶1628, ¶1629, ¶1630. The original effect remains verbatim; any AC overlay above is separate.

**Preserved inactive legacy/metadata:** {"legacyName": "Backpack of Hardened Simpleness", "legacyEffect": "Small bonus to one skill"}.

## recipe-281 — Refined Tide Pouch

**REVIEWED — authored operational PLAYTEST.** public; Leatherworking level 4; tier 2; Common; DC 12. Standard quantity 4; source Standard batch reference 108 gp.

**Preserved effect:** Creates a reinforced pouch carrying 10 pounds without counting against normal encumbrance; grants +1 to checks to secure or retrieve its contents.

**Operational effect:** One output transforms one complete mundane body, retaining its physical identity and latest lawful completion damage state. Functional means at least 1 current structural HP; the singleton Flawed result can emerge Broken with a dormant imprint. While functional, unsuppressed, unmelded, properly fitted and worn or directly held in its recorded pouch-position relief position, cover up to 10 lb of eligible contents in stable loading order. Physical capacity remains 10 lb and 1/3 ft³, subject to its actual opening, shape and compartment limits. Its own body is not relieved. For each covered record, subtract covered pounds from the direct bearer's pound-carrying comparison and at most min(canonical Load, covered pounds/10) from Inventory Load; preserve actual mass and canonical Load. Enclosed enchanted containers are inactive; ordinary inner bodies and descendants count once. External lashings do not become contents. The actual operator receives +1 on a qualifying handling check: Actual difficult cargo handling to secure its ordinary closure/retainers or retrieve through an unlocked closure, jam, tangle or other physical difficulty: DEX for dexterous work or STR (Athletics) for forceful handling of noncreature cargo. This handling benefit needs accessible functional unsuppressed fittings, not a relief slot, and can apply on a table or for an ally. Only the strongest qualifying Leatherworking task bonus applies once per actual check. No routine check is invented; ordinary actions, hands, access, proficiency and competing slot requirements still apply. Broken stops positive functions; suppression stops recipe magic, not physical capacity or workmanship. Use the complete shared guide for custody, melding, quality, repair and value.

**Legal mundane bases:** Cargo pouch 10 lb. One model, actual fit and legal grade for the whole batch. Buy, own or legitimately commission complete bodies; no stock-construction recipe is implied.

**Physical reserve:** 6 complete, nonmagical, non-Broken bases in a stable physical-ID order before work; containers empty. No existing imprint. Missing/Broken/committed bases pause before the roll; repair or replace at the same position. Transform the first resolved N, using latest lawful completion HP. Keep unused bodies in their actual state outside ingredient recovery.

| Mundane body | Price gp | Empty lb | Ordinary HP / structural AC | Benefit slot | Ordinary use |
|---|---:|---:|---|---|---|
| Cargo pouch 10 lb | 1 | 2 | 5 / 15 | pouch-position | 10 lb / 1/3 ft³ contents |

| Container | Compartments | Interior per compartment, inches | Opening, inches | Exterior, inches | Each compartment limit |
|---|---:|---|---|---|---|
| Cargo pouch 10 lb | 1 | 12 × 8 × 6 | 12 × 6 | 13 × 9 × 7 | 10 lb / 1/3 ft³ |

**Exact source component occurrences:**

| # | Component | Quantity | Tier | Role / consumed | Unit lb | Unit gp | Required properties |
|---|---|---:|---:|---|---:|---:|---|
| 0 | Leather strips | 1 | 2 | substrate / true | 0.25 | 8 | substrate |
| 1 | Cured leather | 5 | 2 | substrate / true | 0.25 | 8 | substrate |
| 2 | Rivets | 1 | 2 | binder / true | 0.1 | 8 | binder |
| 3 | bronze dragon scale | 1 | 1 | material / true | 0.91 | 12 | draconic, protective, rigid, water |

All listed inputs are additional consumed process/reinforcement materials. Finished empty mass is the actual body mass; process waste supplies no second body or automatically valuable salvage. No source component is a catalyst; even Masterwork returns zero catalyst units. Independently required tools remain tools.

**Work and access:** DEX with actual Leatherworker's-tools proficiency as the shared framework permits; Tannery Bench; Leatherworker's tools, Awl, Cutting knife. Maximum assistants 0. Source fieldCraftable=false; preserved timeMode=expedition; the false field flag controls. Source time: 8 hours; source activeWorkHours=8. Operational required active time 8 hours. First stable phase 8 hours, included in total. Eligible Forge Dwarf: 360 minutes, first phase 360 minutes. Stabilize only components actually incorporated in the completed first phase; other lots keep their clocks.

**Progression:** exact source trivialAtSkillLevel=9; use this threshold rather than regenerating level+5. Actual formula access: {"sources":["trainer","starter manual","common experimentation"],"minimumResearchHours":0,"requiresFormula":false,"formulaConsumed":false}. The framework controls trade eligibility, proficiency once, assistant qualifications, Watches, rest, interruptions, XP and mishaps.

**Output:** Standard 4; Exceptional yield 5; Masterwork yield 6; or 4 units with strongest noncompounding structural improvement 25%/50%. Flawed: 2 ordinary-effect units, preserving existing physical durability state. Failed/Mishap transforms none; source input recovery/loss remains separate. Quality changes no capacity, relief, check bonus, AC, resistance or grade.

**Repair:** trained Leatherworker's tools, Tannery Bench, Awl and Cutting knife. Functional HP≥1: DEX + applicable proficiency DC10; max(1 hour, recorded max HP/10); materials 25% mundane base reference. Broken HP0: DEX + applicable proficiency DC12; max(8 hours, recorded max HP/10); materials 25% finished per-item reference; recoverable original main body required. Binary success restores recorded maximum, including the persistent flaw; failure consumes materials and time. No formula or original trade-level eligibility required or granted, quality roll, XP, catalyst return or Forge Dwarf creation reduction. No lost contents return.

**Finished ordinary Standard reference examples:** Cargo pouch 10 lb = 28 gp. Source process share 27 gp/unit plus actual undamaged mundane size/grade body reference. Retain exact precision until the actual transaction; no automatic buyer, quality premium, artifact multiplier or mundane-table magic buyback.

**Preserved tags:** Water. Tags, current/legacy names, donors and whole-creature metadata add no powers or availability.

**Public source binding:** V5 ¶1632, ¶1633, ¶1634, ¶1635, ¶1636, ¶1637. The original effect remains verbatim; any AC overlay above is separate.

**Preserved inactive legacy/metadata:** {"legacyName": "Basic Hardened Pouch", "legacyEffect": "Small bonus to one skill"}.

## recipe-282 — Superior Grave Boots of Demonic Talon

**REVIEWED — authored operational PLAYTEST.** public; Leatherworking level 5; tier 3; Common; DC 12. Standard quantity 3; source Standard batch reference 676 gp.

**Preserved effect:** Creates fitted boots granting +1 to a related mobility or handling check.

**Operational effect:** One output transforms one complete matched pair, retaining its physical identity and latest lawful completion damage state. Functional means at least 1 current structural HP; the singleton Flawed result can emerge Broken with a dormant imprint. While complete, functional, unsuppressed, unmelded and actually worn in its footwear-pair benefit slot, receive +1 only on these actual checks: STR (Athletics) for actual foothold climbing or a jump that requires a check; DEX (Acrobatics) to balance on narrow, unstable or slippery support using the feet. The source armorBonus of 0 creates no recipe AC candidate and does not cancel a Crude suit penalty. No damage resistance or environmental immunity is granted. Only the strongest qualifying Leatherworking task bonus applies once per actual check. No routine check is invented; ordinary actions, hands, access, proficiency and competing slot requirements still apply. Broken stops positive functions; suppression stops recipe magic, not physical capacity or workmanship. Use the complete shared guide for custody, melding, quality, repair and value.

**Legal mundane bases:** Boots pair. One model, actual fit and legal grade for the whole batch. Buy, own or legitimately commission complete bodies; no stock-construction recipe is implied.

**Physical reserve:** 4 complete, nonmagical, non-Broken bases in a stable physical-ID order before work; containers empty. No existing imprint. Missing/Broken/committed bases pause before the roll; repair or replace at the same position. Transform the first resolved N, using latest lawful completion HP. Keep unused bodies in their actual state outside ingredient recovery.

| Mundane body | Price gp | Empty lb | Ordinary HP / structural AC | Benefit slot | Ordinary use |
|---|---:|---:|---|---|---|
| Boots pair | 2 | 2 | 5 / 15 | footwear-pair | one matched pair |

| Container | Compartments | Interior per compartment, inches | Opening, inches | Exterior, inches | Each compartment limit |
|---|---:|---|---|---|---|

**Exact source component occurrences:**

| # | Component | Quantity | Tier | Role / consumed | Unit lb | Unit gp | Required properties |
|---|---|---:|---:|---|---:|---:|---|
| 0 | Buckles | 2 | 3 | ingredient / true | 0.1 | 25 |  |
| 1 | Reinforced stitching | 1 | 3 | binder / true | 0.1 | 25 | binder |
| 2 | Waterproofing oil | 5 | 3 | solvent / true | 0.5 | 25 | solvent |
| 3 | demonic talon | 1 | 4 | material / true | 0.11 | 293 | rigid, structural, unholy |

All listed inputs are additional consumed process/reinforcement materials. Finished empty mass is the actual body mass; process waste supplies no second body or automatically valuable salvage. No source component is a catalyst; even Masterwork returns zero catalyst units. Independently required tools remain tools.

**Work and access:** DEX with actual Leatherworker's-tools proficiency as the shared framework permits; Tannery Bench; Leatherworker's tools, Awl, Cutting knife. Maximum assistants 0. Source fieldCraftable=false; preserved timeMode=expedition; the false field flag controls. Source time: 4 hours; source activeWorkHours=4. Operational required active time 4 hours. First stable phase 4 hours, included in total. Eligible Forge Dwarf: 180 minutes, first phase 180 minutes. Stabilize only components actually incorporated in the completed first phase; other lots keep their clocks.

**Progression:** exact source trivialAtSkillLevel=10; use this threshold rather than regenerating level+5. Actual formula access: {"sources":["guild trainer","faction vendor","uncommon dungeon book","reverse engineering"],"minimumResearchHours":0,"requiresFormula":true,"formulaConsumed":false}. The framework controls trade eligibility, proficiency once, assistant qualifications, Watches, rest, interruptions, XP and mishaps.

**Output:** Standard 3; Exceptional yield 3; Masterwork yield 4; or 3 units with strongest noncompounding structural improvement 25%/50%. Flawed: 1 ordinary-effect units, preserving existing physical durability state. Failed/Mishap transforms none; source input recovery/loss remains separate. Quality changes no capacity, relief, check bonus, AC, resistance or grade.

**Repair:** trained Leatherworker's tools, Tannery Bench, Awl and Cutting knife. Functional HP≥1: DEX + applicable proficiency DC10; max(1 hour, recorded max HP/10); materials 25% mundane base reference. Broken HP0: DEX + applicable proficiency DC12; max(8 hours, recorded max HP/10); materials 25% finished per-item reference; recoverable original main body required with both original pair members. Binary success restores recorded maximum, including the persistent flaw; failure consumes materials and time. No formula or original trade-level eligibility required or granted, quality roll, XP, catalyst return or Forge Dwarf creation reduction. No lost contents return.

**Finished ordinary Standard reference examples:** Boots pair = 682/3 gp. Source process share 676/3 gp/unit plus actual undamaged mundane size/grade body reference. Retain exact precision until the actual transaction; no automatic buyer, quality premium, artifact multiplier or mundane-table magic buyback.

**Preserved tags:** Unholy. Tags, current/legacy names, donors and whole-creature metadata add no powers or availability.

**Public source binding:** V5 ¶1639, ¶1640, ¶1641, ¶1642, ¶1643, ¶1644. The original effect remains verbatim; any AC overlay above is separate.

**Preserved inactive legacy/metadata:** {"legacyName": "Reinforced Boots", "legacyEffect": "Temporary resistance"}.

## recipe-283 — Refined Frost Quiver

**REVIEWED — authored operational PLAYTEST.** public; Leatherworking level 4; tier 2; Common; DC 9. Standard quantity 2; source Standard batch reference 140 gp.

**Preserved effect:** Creates a reinforced quiver carrying 10 pounds without counting against normal encumbrance; grants +1 to checks to secure or retrieve its contents.

**Operational effect:** One output transforms one complete mundane body, retaining its physical identity and latest lawful completion damage state. Functional means at least 1 current structural HP; the singleton Flawed result can emerge Broken with a dormant imprint. While functional, unsuppressed, unmelded, properly fitted and worn or directly held in its recorded quiver relief position, cover up to 10 lb of eligible contents in stable loading order. Physical capacity remains 10 lb and 1/3 ft³, subject to its actual opening, shape and compartment limits. Its own body is not relieved. For each covered record, subtract covered pounds from the direct bearer's pound-carrying comparison and at most min(canonical Load, covered pounds/10) from Inventory Load; preserve actual mass and canonical Load. Enclosed enchanted containers are inactive; ordinary inner bodies and descendants count once. External lashings do not become contents. The actual operator receives +1 on a qualifying handling check: Actual difficult cargo handling to secure its ordinary closure/retainers or retrieve through an unlocked closure, jam, tangle or other physical difficulty: DEX for dexterous work or STR (Athletics) for forceful handling of noncreature cargo. This handling benefit needs accessible functional unsuppressed fittings, not a relief slot, and can apply on a table or for an ally. Only the strongest qualifying Leatherworking task bonus applies once per actual check. No routine check is invented; ordinary actions, hands, access, proficiency and competing slot requirements still apply. Broken stops positive functions; suppression stops recipe magic, not physical capacity or workmanship. Use the complete shared guide for custody, melding, quality, repair and value.

**Legal mundane bases:** Cargo quiver 10 lb. One model, actual fit and legal grade for the whole batch. Buy, own or legitimately commission complete bodies; no stock-construction recipe is implied.

**Physical reserve:** 3 complete, nonmagical, non-Broken bases in a stable physical-ID order before work; containers empty. No existing imprint. Missing/Broken/committed bases pause before the roll; repair or replace at the same position. Transform the first resolved N, using latest lawful completion HP. Keep unused bodies in their actual state outside ingredient recovery.

| Mundane body | Price gp | Empty lb | Ordinary HP / structural AC | Benefit slot | Ordinary use |
|---|---:|---:|---|---|---|
| Cargo quiver 10 lb | 2 | 2 | 5 / 15 | quiver | 10 lb / 1/3 ft³ contents |

| Container | Compartments | Interior per compartment, inches | Opening, inches | Exterior, inches | Each compartment limit |
|---|---:|---|---|---|---|
| Cargo quiver 10 lb | 1 | 36 × 4 × 4 | 4 × 4 | 38 × 6 × 6 | 10 lb / 1/3 ft³ |

**Exact source component occurrences:**

| # | Component | Quantity | Tier | Role / consumed | Unit lb | Unit gp | Required properties |
|---|---|---:|---:|---|---:|---:|---|
| 0 | Rivets | 4 | 2 | binder / true | 0.1 | 8 | binder |
| 1 | Reinforced stitching | 5 | 2 | binder / true | 0.1 | 8 | binder |
| 2 | Lining | 2 | 2 | reinforcement / true | 0.25 | 8 | reinforcement |
| 3 | Triceratops pelt | 1 | 1 | material / true | 0.75 | 14 | cold, flexible, protective |

All listed inputs are additional consumed process/reinforcement materials. Finished empty mass is the actual body mass; process waste supplies no second body or automatically valuable salvage. No source component is a catalyst; even Masterwork returns zero catalyst units. Independently required tools remain tools.

**Work and access:** DEX with actual Leatherworker's-tools proficiency as the shared framework permits; Tannery Bench; Leatherworker's tools, Awl, Cutting knife. Maximum assistants 0. Source fieldCraftable=false; preserved timeMode=field; the false field flag controls. Source time: 1 hour; source activeWorkHours=1. Operational required active time 1 hours. First stable phase 1 hours, included in total. Eligible Forge Dwarf: 45 minutes, first phase 45 minutes. Stabilize only components actually incorporated in the completed first phase; other lots keep their clocks.

**Progression:** exact source trivialAtSkillLevel=9; use this threshold rather than regenerating level+5. Actual formula access: {"sources":["trainer","starter manual","common experimentation"],"minimumResearchHours":0,"requiresFormula":false,"formulaConsumed":false}. The framework controls trade eligibility, proficiency once, assistant qualifications, Watches, rest, interruptions, XP and mishaps.

**Output:** Standard 2; Exceptional yield 2; Masterwork yield 3; or 2 units with strongest noncompounding structural improvement 25%/50%. Flawed: 1 ordinary-effect units, preserving existing physical durability state. Failed/Mishap transforms none; source input recovery/loss remains separate. Quality changes no capacity, relief, check bonus, AC, resistance or grade.

**Repair:** trained Leatherworker's tools, Tannery Bench, Awl and Cutting knife. Functional HP≥1: DEX + applicable proficiency DC10; max(1 hour, recorded max HP/10); materials 25% mundane base reference. Broken HP0: DEX + applicable proficiency DC9; max(8 hours, recorded max HP/10); materials 25% finished per-item reference; recoverable original main body required. Binary success restores recorded maximum, including the persistent flaw; failure consumes materials and time. No formula or original trade-level eligibility required or granted, quality roll, XP, catalyst return or Forge Dwarf creation reduction. No lost contents return.

**Finished ordinary Standard reference examples:** Cargo quiver 10 lb = 72 gp. Source process share 70 gp/unit plus actual undamaged mundane size/grade body reference. Retain exact precision until the actual transaction; no automatic buyer, quality premium, artifact multiplier or mundane-table magic buyback.

**Preserved tags:** Cold. Tags, current/legacy names, donors and whole-creature metadata add no powers or availability.

**Public source binding:** V5 ¶1618, ¶1619, ¶1620, ¶1621, ¶1622, ¶1623. The original effect remains verbatim; any AC overlay above is separate.

**Preserved inactive legacy/metadata:** {"legacyName": "Basic Flexible Quiver", "legacyEffect": "Temporary resistance"}.

## recipe-284 — Refined Veiled Gloves

**REVIEWED — authored operational PLAYTEST.** public; Leatherworking level 3; tier 2; Common; DC 10. Standard quantity 1; source Standard batch reference 77 gp.

**Preserved effect:** Creates fitted gloves granting +1 to a related mobility or handling check.

**Operational effect:** One output transforms one complete matched pair, retaining its physical identity and latest lawful completion damage state. Functional means at least 1 current structural HP; the singleton Flawed result can emerge Broken with a dormant imprint. While complete, functional, unsuppressed, unmelded and actually worn in its handwear-pair benefit slot, receive +1 only on these actual checks: STR (Athletics) for climbing with actual handholds or rope grip; STR (Athletics) or DEX to retain, lower or position noncreature cargo by hand; DEX for ordinary nonlocking ties, straps, clasps or a jammed small object. The source armorBonus of 0 creates no recipe AC candidate and does not cancel a Crude suit penalty. No damage resistance or environmental immunity is granted. Only the strongest qualifying Leatherworking task bonus applies once per actual check. No routine check is invented; ordinary actions, hands, access, proficiency and competing slot requirements still apply. Broken stops positive functions; suppression stops recipe magic, not physical capacity or workmanship. Use the complete shared guide for custody, melding, quality, repair and value.

**Legal mundane bases:** Gloves pair. One model, actual fit and legal grade for the whole batch. Buy, own or legitimately commission complete bodies; no stock-construction recipe is implied.

**Physical reserve:** 1 complete, nonmagical, non-Broken bases in a stable physical-ID order before work; containers empty. No existing imprint. Missing/Broken/committed bases pause before the roll; repair or replace at the same position. Transform the first resolved N, using latest lawful completion HP. Keep unused bodies in their actual state outside ingredient recovery.

| Mundane body | Price gp | Empty lb | Ordinary HP / structural AC | Benefit slot | Ordinary use |
|---|---:|---:|---|---|---|
| Gloves pair | 1 | 0.5 | 5 / 15 | handwear-pair | one matched pair |

| Container | Compartments | Interior per compartment, inches | Opening, inches | Exterior, inches | Each compartment limit |
|---|---:|---|---|---|---|

**Exact source component occurrences:**

| # | Component | Quantity | Tier | Role / consumed | Unit lb | Unit gp | Required properties |
|---|---|---:|---:|---|---:|---:|---|
| 0 | Leather strips | 3 | 2 | substrate / true | 0.25 | 8 | substrate |
| 1 | Waterproofing oil | 1 | 2 | solvent / true | 0.5 | 8 | solvent |
| 2 | Lining | 1 | 2 | reinforcement / true | 0.25 | 8 | reinforcement |
| 3 | black dragon scale | 1 | 1 | material / true | 0.43 | 8 | acid, draconic, protective, rigid |

All listed inputs are additional consumed process/reinforcement materials. Finished empty mass is the actual body mass; process waste supplies no second body or automatically valuable salvage. No source component is a catalyst; even Masterwork returns zero catalyst units. Independently required tools remain tools.

**Work and access:** DEX with actual Leatherworker's-tools proficiency as the shared framework permits; Tannery Bench; Leatherworker's tools, Awl, Cutting knife. Maximum assistants 0. Source fieldCraftable=false; preserved timeMode=expedition; the false field flag controls. Source time: 8 hours; source activeWorkHours=8. Operational required active time 8 hours. First stable phase 8 hours, included in total. Eligible Forge Dwarf: 360 minutes, first phase 360 minutes. Stabilize only components actually incorporated in the completed first phase; other lots keep their clocks.

**Progression:** exact source trivialAtSkillLevel=8; use this threshold rather than regenerating level+5. Actual formula access: {"sources":["trainer","starter manual","common experimentation"],"minimumResearchHours":0,"requiresFormula":false,"formulaConsumed":false}. The framework controls trade eligibility, proficiency once, assistant qualifications, Watches, rest, interruptions, XP and mishaps.

**Output:** Standard 1; Exceptional yield 1; Masterwork yield 1; or 1 units with strongest noncompounding structural improvement 25%/50%. Flawed: one persistent half-maximum flaw applied after size/grade and strongest improvement, minimum1; preserve damage deficit and possible Broken output. Failed/Mishap transforms none; source input recovery/loss remains separate. Quality changes no capacity, relief, check bonus, AC, resistance or grade.

**Repair:** trained Leatherworker's tools, Tannery Bench, Awl and Cutting knife. Functional HP≥1: DEX + applicable proficiency DC10; max(1 hour, recorded max HP/10); materials 25% mundane base reference. Broken HP0: DEX + applicable proficiency DC10; max(8 hours, recorded max HP/10); materials 25% finished per-item reference; recoverable original main body required with both original pair members. Binary success restores recorded maximum, including the persistent flaw; failure consumes materials and time. No formula or original trade-level eligibility required or granted, quality roll, XP, catalyst return or Forge Dwarf creation reduction. No lost contents return.

**Finished ordinary Standard reference examples:** Gloves pair = 78 gp. Source process share 77 gp/unit plus actual undamaged mundane size/grade body reference. Retain exact precision until the actual transaction; no automatic buyer, quality premium, artifact multiplier or mundane-table magic buyback.

**Preserved tags:** Stealth. Tags, current/legacy names, donors and whole-creature metadata add no powers or availability.

**Public source binding:** V5 ¶1597, ¶1598, ¶1599, ¶1600, ¶1601, ¶1602. The original effect remains verbatim; any AC overlay above is separate.

**Preserved inactive legacy/metadata:** {"legacyName": "Flexible Gloves", "legacyEffect": "Small bonus to one skill"}.

## recipe-285 — Refined Verdant Pouch

**REVIEWED — authored operational PLAYTEST.** public; Leatherworking level 3; tier 2; Common; DC 12. Standard quantity 2; source Standard batch reference 58 gp.

**Preserved effect:** Creates a reinforced pouch carrying 10 pounds without counting against normal encumbrance; grants +1 to checks to secure or retrieve its contents.

**Operational effect:** One output transforms one complete mundane body, retaining its physical identity and latest lawful completion damage state. Functional means at least 1 current structural HP; the singleton Flawed result can emerge Broken with a dormant imprint. While functional, unsuppressed, unmelded, properly fitted and worn or directly held in its recorded pouch-position relief position, cover up to 10 lb of eligible contents in stable loading order. Physical capacity remains 10 lb and 1/3 ft³, subject to its actual opening, shape and compartment limits. Its own body is not relieved. For each covered record, subtract covered pounds from the direct bearer's pound-carrying comparison and at most min(canonical Load, covered pounds/10) from Inventory Load; preserve actual mass and canonical Load. Enclosed enchanted containers are inactive; ordinary inner bodies and descendants count once. External lashings do not become contents. The actual operator receives +1 on a qualifying handling check: Actual difficult cargo handling to secure its ordinary closure/retainers or retrieve through an unlocked closure, jam, tangle or other physical difficulty: DEX for dexterous work or STR (Athletics) for forceful handling of noncreature cargo. This handling benefit needs accessible functional unsuppressed fittings, not a relief slot, and can apply on a table or for an ally. Only the strongest qualifying Leatherworking task bonus applies once per actual check. No routine check is invented; ordinary actions, hands, access, proficiency and competing slot requirements still apply. Broken stops positive functions; suppression stops recipe magic, not physical capacity or workmanship. Use the complete shared guide for custody, melding, quality, repair and value.

**Legal mundane bases:** Cargo pouch 10 lb. One model, actual fit and legal grade for the whole batch. Buy, own or legitimately commission complete bodies; no stock-construction recipe is implied.

**Physical reserve:** 3 complete, nonmagical, non-Broken bases in a stable physical-ID order before work; containers empty. No existing imprint. Missing/Broken/committed bases pause before the roll; repair or replace at the same position. Transform the first resolved N, using latest lawful completion HP. Keep unused bodies in their actual state outside ingredient recovery.

| Mundane body | Price gp | Empty lb | Ordinary HP / structural AC | Benefit slot | Ordinary use |
|---|---:|---:|---|---|---|
| Cargo pouch 10 lb | 1 | 2 | 5 / 15 | pouch-position | 10 lb / 1/3 ft³ contents |

| Container | Compartments | Interior per compartment, inches | Opening, inches | Exterior, inches | Each compartment limit |
|---|---:|---|---|---|---|
| Cargo pouch 10 lb | 1 | 12 × 8 × 6 | 12 × 6 | 13 × 9 × 7 | 10 lb / 1/3 ft³ |

**Exact source component occurrences:**

| # | Component | Quantity | Tier | Role / consumed | Unit lb | Unit gp | Required properties |
|---|---|---:|---:|---|---:|---:|---|
| 0 | Reinforced stitching | 4 | 2 | binder / true | 0.1 | 8 | binder |
| 1 | fey pollen | 1 | 1 | material / true | 0.83 | 9 | fey, specialized |

All listed inputs are additional consumed process/reinforcement materials. Finished empty mass is the actual body mass; process waste supplies no second body or automatically valuable salvage. No source component is a catalyst; even Masterwork returns zero catalyst units. Independently required tools remain tools.

**Work and access:** DEX with actual Leatherworker's-tools proficiency as the shared framework permits; Tannery Bench; Leatherworker's tools, Awl, Cutting knife. Maximum assistants 0. Source fieldCraftable=false; preserved timeMode=field; the false field flag controls. Source time: 2 hours; source activeWorkHours=2. Operational required active time 2 hours. First stable phase 2 hours, included in total. Eligible Forge Dwarf: 90 minutes, first phase 90 minutes. Stabilize only components actually incorporated in the completed first phase; other lots keep their clocks.

**Progression:** exact source trivialAtSkillLevel=8; use this threshold rather than regenerating level+5. Actual formula access: {"sources":["trainer","starter manual","common experimentation"],"minimumResearchHours":0,"requiresFormula":false,"formulaConsumed":false}. The framework controls trade eligibility, proficiency once, assistant qualifications, Watches, rest, interruptions, XP and mishaps.

**Output:** Standard 2; Exceptional yield 2; Masterwork yield 3; or 2 units with strongest noncompounding structural improvement 25%/50%. Flawed: 1 ordinary-effect units, preserving existing physical durability state. Failed/Mishap transforms none; source input recovery/loss remains separate. Quality changes no capacity, relief, check bonus, AC, resistance or grade.

**Repair:** trained Leatherworker's tools, Tannery Bench, Awl and Cutting knife. Functional HP≥1: DEX + applicable proficiency DC10; max(1 hour, recorded max HP/10); materials 25% mundane base reference. Broken HP0: DEX + applicable proficiency DC12; max(8 hours, recorded max HP/10); materials 25% finished per-item reference; recoverable original main body required. Binary success restores recorded maximum, including the persistent flaw; failure consumes materials and time. No formula or original trade-level eligibility required or granted, quality roll, XP, catalyst return or Forge Dwarf creation reduction. No lost contents return.

**Finished ordinary Standard reference examples:** Cargo pouch 10 lb = 30 gp. Source process share 29 gp/unit plus actual undamaged mundane size/grade body reference. Retain exact precision until the actual transaction; no automatic buyer, quality premium, artifact multiplier or mundane-table magic buyback.

**Preserved tags:** Flora. Tags, current/legacy names, donors and whole-creature metadata add no powers or availability.

**Public source binding:** V5 ¶1611, ¶1612, ¶1613, ¶1614, ¶1615, ¶1616. The original effect remains verbatim; any AC overlay above is separate.

**Preserved inactive legacy/metadata:** {"legacyName": "Standard Pouch", "legacyEffect": "Minor magical effect"}.

## recipe-286 — Field Resonant Backpack

**REVIEWED — authored operational PLAYTEST.** public; Leatherworking level 2; tier 1; Common; DC 8. Standard quantity 1; source Standard batch reference 63 gp.

**Preserved effect:** Creates a reinforced backpack carrying 10 pounds without counting against normal encumbrance; grants +1 to checks to secure or retrieve its contents.

**Operational effect:** One output transforms one complete mundane body, retaining its physical identity and latest lawful completion damage state. Functional means at least 1 current structural HP; the singleton Flawed result can emerge Broken with a dormant imprint. While functional, unsuppressed, unmelded, properly fitted and worn or directly held in its recorded back-cargo relief position, cover up to 10 lb of eligible contents in stable loading order. Physical capacity remains 30 lb and 1 ft³, subject to its actual opening, shape and compartment limits. Its own body is not relieved. For each covered record, subtract covered pounds from the direct bearer's pound-carrying comparison and at most min(canonical Load, covered pounds/10) from Inventory Load; preserve actual mass and canonical Load. Enclosed enchanted containers are inactive; ordinary inner bodies and descendants count once. External lashings do not become contents. The actual operator receives +1 on a qualifying handling check: Actual difficult cargo handling to secure its ordinary closure/retainers or retrieve through an unlocked closure, jam, tangle or other physical difficulty: DEX for dexterous work or STR (Athletics) for forceful handling of noncreature cargo. This handling benefit needs accessible functional unsuppressed fittings, not a relief slot, and can apply on a table or for an ally. Only the strongest qualifying Leatherworking task bonus applies once per actual check. No routine check is invented; ordinary actions, hands, access, proficiency and competing slot requirements still apply. Broken stops positive functions; suppression stops recipe magic, not physical capacity or workmanship. Use the complete shared guide for custody, melding, quality, repair and value.

**Legal mundane bases:** Backpack. One model, actual fit and legal grade for the whole batch. Buy, own or legitimately commission complete bodies; no stock-construction recipe is implied.

**Physical reserve:** 1 complete, nonmagical, non-Broken bases in a stable physical-ID order before work; containers empty. No existing imprint. Missing/Broken/committed bases pause before the roll; repair or replace at the same position. Transform the first resolved N, using latest lawful completion HP. Keep unused bodies in their actual state outside ingredient recovery.

| Mundane body | Price gp | Empty lb | Ordinary HP / structural AC | Benefit slot | Ordinary use |
|---|---:|---:|---|---|---|
| Backpack | 2 | 5 | 10 / 15 | back-cargo | 30 lb / 1 ft³ contents |

| Container | Compartments | Interior per compartment, inches | Opening, inches | Exterior, inches | Each compartment limit |
|---|---:|---|---|---|---|
| Backpack | 1 | 18 × 12 × 8 | 12 × 8 | 20 × 14 × 10 | 30 lb / 1 ft³ |

**Exact source component occurrences:**

| # | Component | Quantity | Tier | Role / consumed | Unit lb | Unit gp | Required properties |
|---|---|---:|---:|---|---:|---:|---|
| 0 | Cured leather | 3 | 1 | substrate / true | 0.25 | 2 | substrate |
| 1 | Rivets | 2 | 1 | binder / true | 0.1 | 2 | binder |
| 2 | Lining | 2 | 1 | reinforcement / true | 0.25 | 2 | reinforcement |
| 3 | arcane wire | 1 | 1 | material / true | 0.81 | 15 | arcane, construct, specialized |

All listed inputs are additional consumed process/reinforcement materials. Finished empty mass is the actual body mass; process waste supplies no second body or automatically valuable salvage. No source component is a catalyst; even Masterwork returns zero catalyst units. Independently required tools remain tools.

**Work and access:** DEX with actual Leatherworker's-tools proficiency as the shared framework permits; Tannery Bench; Leatherworker's tools, Awl, Cutting knife. Maximum assistants 0. Source fieldCraftable=false; preserved timeMode=expedition; the false field flag controls. Source time: 8 hours; source activeWorkHours=8. Operational required active time 8 hours. First stable phase 8 hours, included in total. Eligible Forge Dwarf: 360 minutes, first phase 360 minutes. Stabilize only components actually incorporated in the completed first phase; other lots keep their clocks.

**Progression:** exact source trivialAtSkillLevel=7; use this threshold rather than regenerating level+5. Actual formula access: {"sources":["trainer","starter manual","common experimentation"],"minimumResearchHours":0,"requiresFormula":false,"formulaConsumed":false}. The framework controls trade eligibility, proficiency once, assistant qualifications, Watches, rest, interruptions, XP and mishaps.

**Output:** Standard 1; Exceptional yield 1; Masterwork yield 1; or 1 units with strongest noncompounding structural improvement 25%/50%. Flawed: one persistent half-maximum flaw applied after size/grade and strongest improvement, minimum1; preserve damage deficit and possible Broken output. Failed/Mishap transforms none; source input recovery/loss remains separate. Quality changes no capacity, relief, check bonus, AC, resistance or grade.

**Repair:** trained Leatherworker's tools, Tannery Bench, Awl and Cutting knife. Functional HP≥1: DEX + applicable proficiency DC10; max(1 hour, recorded max HP/10); materials 25% mundane base reference. Broken HP0: DEX + applicable proficiency DC8; max(8 hours, recorded max HP/10); materials 25% finished per-item reference; recoverable original main body required. Binary success restores recorded maximum, including the persistent flaw; failure consumes materials and time. No formula or original trade-level eligibility required or granted, quality roll, XP, catalyst return or Forge Dwarf creation reduction. No lost contents return.

**Finished ordinary Standard reference examples:** Backpack = 65 gp. Source process share 63 gp/unit plus actual undamaged mundane size/grade body reference. Retain exact precision until the actual transaction; no automatic buyer, quality premium, artifact multiplier or mundane-table magic buyback.

**Preserved tags:** Arcane. Tags, current/legacy names, donors and whole-creature metadata add no powers or availability.

**Public source binding:** V5 ¶1569, ¶1570, ¶1571, ¶1572, ¶1573, ¶1574. The original effect remains verbatim; any AC overlay above is separate.

**Preserved inactive legacy/metadata:** {"legacyName": "Tanned Backpack", "legacyEffect": "Temporary resistance"}.

## recipe-287 — Superior Veiled Backpack of Black Dragonscale

**REVIEWED — authored operational PLAYTEST.** public; Leatherworking level 5; tier 3; Common; DC 10. Standard quantity 2; source Standard batch reference 166 gp.

**Preserved effect:** Creates a reinforced backpack carrying 10 pounds without counting against normal encumbrance; grants +1 to checks to secure or retrieve its contents.

**Operational effect:** One output transforms one complete mundane body, retaining its physical identity and latest lawful completion damage state. Functional means at least 1 current structural HP; the singleton Flawed result can emerge Broken with a dormant imprint. While functional, unsuppressed, unmelded, properly fitted and worn or directly held in its recorded back-cargo relief position, cover up to 10 lb of eligible contents in stable loading order. Physical capacity remains 30 lb and 1 ft³, subject to its actual opening, shape and compartment limits. Its own body is not relieved. For each covered record, subtract covered pounds from the direct bearer's pound-carrying comparison and at most min(canonical Load, covered pounds/10) from Inventory Load; preserve actual mass and canonical Load. Enclosed enchanted containers are inactive; ordinary inner bodies and descendants count once. External lashings do not become contents. The actual operator receives +1 on a qualifying handling check: Actual difficult cargo handling to secure its ordinary closure/retainers or retrieve through an unlocked closure, jam, tangle or other physical difficulty: DEX for dexterous work or STR (Athletics) for forceful handling of noncreature cargo. This handling benefit needs accessible functional unsuppressed fittings, not a relief slot, and can apply on a table or for an ally. Only the strongest qualifying Leatherworking task bonus applies once per actual check. No routine check is invented; ordinary actions, hands, access, proficiency and competing slot requirements still apply. Broken stops positive functions; suppression stops recipe magic, not physical capacity or workmanship. Use the complete shared guide for custody, melding, quality, repair and value.

**Legal mundane bases:** Backpack. One model, actual fit and legal grade for the whole batch. Buy, own or legitimately commission complete bodies; no stock-construction recipe is implied.

**Physical reserve:** 3 complete, nonmagical, non-Broken bases in a stable physical-ID order before work; containers empty. No existing imprint. Missing/Broken/committed bases pause before the roll; repair or replace at the same position. Transform the first resolved N, using latest lawful completion HP. Keep unused bodies in their actual state outside ingredient recovery.

| Mundane body | Price gp | Empty lb | Ordinary HP / structural AC | Benefit slot | Ordinary use |
|---|---:|---:|---|---|---|
| Backpack | 2 | 5 | 10 / 15 | back-cargo | 30 lb / 1 ft³ contents |

| Container | Compartments | Interior per compartment, inches | Opening, inches | Exterior, inches | Each compartment limit |
|---|---:|---|---|---|---|
| Backpack | 1 | 18 × 12 × 8 | 12 × 8 | 20 × 14 × 10 | 30 lb / 1 ft³ |

**Exact source component occurrences:**

| # | Component | Quantity | Tier | Role / consumed | Unit lb | Unit gp | Required properties |
|---|---|---:|---:|---|---:|---:|---|
| 0 | Buckles | 2 | 3 | ingredient / true | 0.1 | 25 |  |
| 1 | Reinforced stitching | 2 | 3 | binder / true | 0.1 | 25 | binder |
| 2 | black dragon scale | 1 | 1 | material / true | 0.43 | 8 | acid, draconic, protective, rigid |

All listed inputs are additional consumed process/reinforcement materials. Finished empty mass is the actual body mass; process waste supplies no second body or automatically valuable salvage. No source component is a catalyst; even Masterwork returns zero catalyst units. Independently required tools remain tools.

**Work and access:** DEX with actual Leatherworker's-tools proficiency as the shared framework permits; Tannery Bench; Leatherworker's tools, Awl, Cutting knife. Maximum assistants 0. Source fieldCraftable=false; preserved timeMode=expedition; the false field flag controls. Source time: 8 hours; source activeWorkHours=8. Operational required active time 8 hours. First stable phase 8 hours, included in total. Eligible Forge Dwarf: 360 minutes, first phase 360 minutes. Stabilize only components actually incorporated in the completed first phase; other lots keep their clocks.

**Progression:** exact source trivialAtSkillLevel=10; use this threshold rather than regenerating level+5. Actual formula access: {"sources":["guild trainer","faction vendor","uncommon dungeon book","reverse engineering"],"minimumResearchHours":0,"requiresFormula":true,"formulaConsumed":false}. The framework controls trade eligibility, proficiency once, assistant qualifications, Watches, rest, interruptions, XP and mishaps.

**Output:** Standard 2; Exceptional yield 2; Masterwork yield 3; or 2 units with strongest noncompounding structural improvement 25%/50%. Flawed: 1 ordinary-effect units, preserving existing physical durability state. Failed/Mishap transforms none; source input recovery/loss remains separate. Quality changes no capacity, relief, check bonus, AC, resistance or grade.

**Repair:** trained Leatherworker's tools, Tannery Bench, Awl and Cutting knife. Functional HP≥1: DEX + applicable proficiency DC10; max(1 hour, recorded max HP/10); materials 25% mundane base reference. Broken HP0: DEX + applicable proficiency DC10; max(8 hours, recorded max HP/10); materials 25% finished per-item reference; recoverable original main body required. Binary success restores recorded maximum, including the persistent flaw; failure consumes materials and time. No formula or original trade-level eligibility required or granted, quality roll, XP, catalyst return or Forge Dwarf creation reduction. No lost contents return.

**Finished ordinary Standard reference examples:** Backpack = 85 gp. Source process share 83 gp/unit plus actual undamaged mundane size/grade body reference. Retain exact precision until the actual transaction; no automatic buyer, quality premium, artifact multiplier or mundane-table magic buyback.

**Preserved tags:** Stealth. Tags, current/legacy names, donors and whole-creature metadata add no powers or availability.

**Public source binding:** V5 ¶1653, ¶1654, ¶1655, ¶1656, ¶1657, ¶1658. The original effect remains verbatim; any AC overlay above is separate.

**Preserved inactive legacy/metadata:** {"legacyName": "Practical Supple Backpack", "legacyEffect": "Temporary resistance"}.

## recipe-288 — Refined Tide Leather Gear

**REVIEWED — authored operational PLAYTEST.** public; Leatherworking level 3; tier 2; Common; DC 12. Standard quantity 3; source Standard batch reference 61 gp.

**Preserved effect:** Creates fitted leather gear granting +1 to a related mobility or handling check.

**Operational effect:** One output transforms one complete mundane body, retaining its physical identity and latest lawful completion damage state. Functional means at least 1 current structural HP; the singleton Flawed result can emerge Broken with a dormant imprint. While complete, functional, unsuppressed, unmelded and actually worn in its torso-accessory benefit slot, receive +1 only on these actual checks: STR (Athletics) for actual climbing; DEX (Acrobatics) for controlled movement through a cramped or obstructed passage when a check is actually required. The source armorBonus of 0 creates no recipe AC candidate and does not cancel a Crude suit penalty. No damage resistance or environmental immunity is granted. Only the strongest qualifying Leatherworking task bonus applies once per actual check. No routine check is invented; ordinary actions, hands, access, proficiency and competing slot requirements still apply. Broken stops positive functions; suppression stops recipe magic, not physical capacity or workmanship. Use the complete shared guide for custody, melding, quality, repair and value.

**Legal mundane bases:** Leather mobility vest. One model, actual fit and legal grade for the whole batch. Buy, own or legitimately commission complete bodies; no stock-construction recipe is implied.

**Physical reserve:** 4 complete, nonmagical, non-Broken bases in a stable physical-ID order before work; containers empty. No existing imprint. Missing/Broken/committed bases pause before the roll; repair or replace at the same position. Transform the first resolved N, using latest lawful completion HP. Keep unused bodies in their actual state outside ingredient recovery.

| Mundane body | Price gp | Empty lb | Ordinary HP / structural AC | Benefit slot | Ordinary use |
|---|---:|---:|---|---|---|
| Leather mobility vest | 5 | 4 | 5 / 15 | torso-accessory | one item |

| Container | Compartments | Interior per compartment, inches | Opening, inches | Exterior, inches | Each compartment limit |
|---|---:|---|---|---|---|

**Exact source component occurrences:**

| # | Component | Quantity | Tier | Role / consumed | Unit lb | Unit gp | Required properties |
|---|---|---:|---:|---|---:|---:|---|
| 0 | Buckles | 3 | 2 | ingredient / true | 0.1 | 8 |  |
| 1 | bronze dragon scale | 1 | 1 | material / true | 0.91 | 12 | draconic, protective, rigid, water |

All listed inputs are additional consumed process/reinforcement materials. Finished empty mass is the actual body mass; process waste supplies no second body or automatically valuable salvage. No source component is a catalyst; even Masterwork returns zero catalyst units. Independently required tools remain tools.

**Work and access:** DEX with actual Leatherworker's-tools proficiency as the shared framework permits; Tannery Bench; Leatherworker's tools, Awl, Cutting knife. Maximum assistants 0. Source fieldCraftable=false; preserved timeMode=expedition; the false field flag controls. Source time: 8 hours; source activeWorkHours=8. Operational required active time 8 hours. First stable phase 8 hours, included in total. Eligible Forge Dwarf: 360 minutes, first phase 360 minutes. Stabilize only components actually incorporated in the completed first phase; other lots keep their clocks.

**Progression:** exact source trivialAtSkillLevel=8; use this threshold rather than regenerating level+5. Actual formula access: {"sources":["trainer","starter manual","common experimentation"],"minimumResearchHours":0,"requiresFormula":false,"formulaConsumed":false}. The framework controls trade eligibility, proficiency once, assistant qualifications, Watches, rest, interruptions, XP and mishaps.

**Output:** Standard 3; Exceptional yield 3; Masterwork yield 4; or 3 units with strongest noncompounding structural improvement 25%/50%. Flawed: 1 ordinary-effect units, preserving existing physical durability state. Failed/Mishap transforms none; source input recovery/loss remains separate. Quality changes no capacity, relief, check bonus, AC, resistance or grade.

**Repair:** trained Leatherworker's tools, Tannery Bench, Awl and Cutting knife. Functional HP≥1: DEX + applicable proficiency DC10; max(1 hour, recorded max HP/10); materials 25% mundane base reference. Broken HP0: DEX + applicable proficiency DC12; max(8 hours, recorded max HP/10); materials 25% finished per-item reference; recoverable original main body required. Binary success restores recorded maximum, including the persistent flaw; failure consumes materials and time. No formula or original trade-level eligibility required or granted, quality roll, XP, catalyst return or Forge Dwarf creation reduction. No lost contents return.

**Finished ordinary Standard reference examples:** Leather mobility vest = 76/3 gp. Source process share 61/3 gp/unit plus actual undamaged mundane size/grade body reference. Retain exact precision until the actual transaction; no automatic buyer, quality premium, artifact multiplier or mundane-table magic buyback.

**Preserved tags:** Water. Tags, current/legacy names, donors and whole-creature metadata add no powers or availability.

**Public source binding:** V5 ¶1590, ¶1591, ¶1592, ¶1593, ¶1594, ¶1595. The original effect remains verbatim; any AC overlay above is separate.

**Preserved inactive legacy/metadata:** {"legacyName": "Basic Saddle", "legacyEffect": "Minor magical effect"}.

## recipe-289 — Field Venom Armor

**REVIEWED — authored operational PLAYTEST.** public; Leatherworking level 1; tier 1; Common; DC 11. Standard quantity 1; source Standard batch reference 52 gp.

**Preserved effect:** Creates fitted armor granting +1 to a related mobility or handling check.

**Operational effect:** One output transforms one complete mundane body, retaining its physical identity and latest lawful completion damage state. Functional means at least 1 current structural HP; the singleton Flawed result can emerge Broken with a dormant imprint. While complete, functional, unsuppressed, unmelded and actually worn in its armor-suit benefit slot, receive +1 only on these actual checks: STR (Athletics) for actual climbing; DEX (Acrobatics) for controlled movement through a cramped or obstructed passage when a check is actually required. The source armorBonus of 0 creates no recipe AC candidate and does not cancel a Crude suit penalty. No damage resistance or environmental immunity is granted. Only the strongest qualifying Leatherworking task bonus applies once per actual check. No routine check is invented; ordinary actions, hands, access, proficiency and competing slot requirements still apply. Broken stops positive functions; suppression stops recipe magic, not physical capacity or workmanship. Use the complete shared guide for custody, melding, quality, repair and value.

**Legal mundane bases:** Leather, Studded leather, Hide. One model, actual fit and legal grade for the whole batch. Buy, own or legitimately commission complete bodies; no stock-construction recipe is implied.

**Physical reserve:** 1 complete, nonmagical, non-Broken bases in a stable physical-ID order before work; containers empty. No existing imprint. Missing/Broken/committed bases pause before the roll; repair or replace at the same position. Transform the first resolved N, using latest lawful completion HP. Keep unused bodies in their actual state outside ingredient recovery.

| Mundane body | Price gp | Empty lb | Ordinary HP / structural AC | Benefit slot | Ordinary use |
|---|---:|---:|---|---|---|
| Leather | 10 | 10 | 10 / 15 | armor-suit | 11 + Dex modifier |
| Studded leather | 45 | 13 | 10 / 15 | armor-suit | 12 + Dex modifier |
| Hide | 10 | 12 | 15 / 15 | armor-suit | 12 + Dex modifier (max 2) |

| Container | Compartments | Interior per compartment, inches | Opening, inches | Exterior, inches | Each compartment limit |
|---|---:|---|---|---|---|

**Exact source component occurrences:**

| # | Component | Quantity | Tier | Role / consumed | Unit lb | Unit gp | Required properties |
|---|---|---:|---:|---|---:|---:|---|
| 0 | Reinforced stitching | 3 | 1 | binder / true | 0.1 | 2 | binder |
| 1 | Cured leather | 5 | 1 | substrate / true | 0.25 | 2 | substrate |
| 2 | green dragon scale | 1 | 1 | material / true | 0.75 | 13 | draconic, poison, protective, rigid |

All listed inputs are additional consumed process/reinforcement materials. Finished empty mass is the actual body mass; process waste supplies no second body or automatically valuable salvage. No source component is a catalyst; even Masterwork returns zero catalyst units. Independently required tools remain tools.

**Work and access:** DEX with actual Leatherworker's-tools proficiency as the shared framework permits; Tannery Bench; Leatherworker's tools, Awl, Cutting knife. Maximum assistants 0. Source fieldCraftable=false; preserved timeMode=expedition; the false field flag controls. Source time: 8 hours; source activeWorkHours=8. Operational required active time 8 hours. First stable phase 8 hours, included in total. Eligible Forge Dwarf: 360 minutes, first phase 360 minutes. Stabilize only components actually incorporated in the completed first phase; other lots keep their clocks.

**Progression:** exact source trivialAtSkillLevel=6; use this threshold rather than regenerating level+5. Actual formula access: {"sources":["trainer","starter manual","common experimentation"],"minimumResearchHours":0,"requiresFormula":false,"formulaConsumed":false}. The framework controls trade eligibility, proficiency once, assistant qualifications, Watches, rest, interruptions, XP and mishaps.

**Output:** Standard 1; Exceptional yield 1; Masterwork yield 1; or 1 units with strongest noncompounding structural improvement 25%/50%. Flawed: one persistent half-maximum flaw applied after size/grade and strongest improvement, minimum1; preserve damage deficit and possible Broken output. Failed/Mishap transforms none; source input recovery/loss remains separate. Quality changes no capacity, relief, check bonus, AC, resistance or grade.

**Repair:** trained Leatherworker's tools, Tannery Bench, Awl and Cutting knife. Functional HP≥1: DEX + applicable proficiency DC10; max(1 hour, recorded max HP/10); materials 25% mundane base reference. Broken HP0: DEX + applicable proficiency DC11; max(8 hours, recorded max HP/10); materials 25% finished per-item reference; recoverable original main body required. Binary success restores recorded maximum, including the persistent flaw; failure consumes materials and time. No formula or original trade-level eligibility required or granted, quality roll, XP, catalyst return or Forge Dwarf creation reduction. No lost contents return.

**Finished ordinary Standard reference examples:** Leather = 62 gp; Studded leather = 97 gp; Hide = 62 gp. Source process share 52 gp/unit plus actual undamaged mundane size/grade body reference. Retain exact precision until the actual transaction; no automatic buyer, quality premium, artifact multiplier or mundane-table magic buyback.

**Preserved tags:** Poison. Tags, current/legacy names, donors and whole-creature metadata add no powers or availability.

**Public source binding:** V5 ¶1555, ¶1556, ¶1557, ¶1558, ¶1559, ¶1560. The original effect remains verbatim; any AC overlay above is separate.

**Preserved inactive legacy/metadata:** {"legacyName": "Hardened Leather Armor", "legacyEffect": "Temporary resistance"}.

## recipe-290 — Refined Veiled Pouch

**REVIEWED — authored operational PLAYTEST.** public; Leatherworking level 3; tier 2; Common; DC 9. Standard quantity 5; source Standard batch reference 120 gp.

**Preserved effect:** Creates a reinforced pouch carrying 10 pounds without counting against normal encumbrance; grants +1 to checks to secure or retrieve its contents.

**Operational effect:** One output transforms one complete mundane body, retaining its physical identity and latest lawful completion damage state. Functional means at least 1 current structural HP; the singleton Flawed result can emerge Broken with a dormant imprint. While functional, unsuppressed, unmelded, properly fitted and worn or directly held in its recorded pouch-position relief position, cover up to 10 lb of eligible contents in stable loading order. Physical capacity remains 10 lb and 1/3 ft³, subject to its actual opening, shape and compartment limits. Its own body is not relieved. For each covered record, subtract covered pounds from the direct bearer's pound-carrying comparison and at most min(canonical Load, covered pounds/10) from Inventory Load; preserve actual mass and canonical Load. Enclosed enchanted containers are inactive; ordinary inner bodies and descendants count once. External lashings do not become contents. The actual operator receives +1 on a qualifying handling check: Actual difficult cargo handling to secure its ordinary closure/retainers or retrieve through an unlocked closure, jam, tangle or other physical difficulty: DEX for dexterous work or STR (Athletics) for forceful handling of noncreature cargo. This handling benefit needs accessible functional unsuppressed fittings, not a relief slot, and can apply on a table or for an ally. Only the strongest qualifying Leatherworking task bonus applies once per actual check. No routine check is invented; ordinary actions, hands, access, proficiency and competing slot requirements still apply. Broken stops positive functions; suppression stops recipe magic, not physical capacity or workmanship. Use the complete shared guide for custody, melding, quality, repair and value.

**Legal mundane bases:** Cargo pouch 10 lb. One model, actual fit and legal grade for the whole batch. Buy, own or legitimately commission complete bodies; no stock-construction recipe is implied.

**Physical reserve:** 7 complete, nonmagical, non-Broken bases in a stable physical-ID order before work; containers empty. No existing imprint. Missing/Broken/committed bases pause before the roll; repair or replace at the same position. Transform the first resolved N, using latest lawful completion HP. Keep unused bodies in their actual state outside ingredient recovery.

| Mundane body | Price gp | Empty lb | Ordinary HP / structural AC | Benefit slot | Ordinary use |
|---|---:|---:|---|---|---|
| Cargo pouch 10 lb | 1 | 2 | 5 / 15 | pouch-position | 10 lb / 1/3 ft³ contents |

| Container | Compartments | Interior per compartment, inches | Opening, inches | Exterior, inches | Each compartment limit |
|---|---:|---|---|---|---|
| Cargo pouch 10 lb | 1 | 12 × 8 × 6 | 12 × 6 | 13 × 9 × 7 | 10 lb / 1/3 ft³ |

**Exact source component occurrences:**

| # | Component | Quantity | Tier | Role / consumed | Unit lb | Unit gp | Required properties |
|---|---|---:|---:|---|---:|---:|---|
| 0 | Cured leather | 3 | 2 | substrate / true | 0.25 | 8 | substrate |
| 1 | Waterproofing oil | 1 | 2 | solvent / true | 0.5 | 8 | solvent |
| 2 | Padding | 5 | 2 | reinforcement / true | 0.25 | 8 | reinforcement |
| 3 | black dragon scale | 1 | 1 | material / true | 0.43 | 8 | acid, draconic, protective, rigid |

All listed inputs are additional consumed process/reinforcement materials. Finished empty mass is the actual body mass; process waste supplies no second body or automatically valuable salvage. No source component is a catalyst; even Masterwork returns zero catalyst units. Independently required tools remain tools.

**Work and access:** DEX with actual Leatherworker's-tools proficiency as the shared framework permits; Tannery Bench; Leatherworker's tools, Awl, Cutting knife. Maximum assistants 0. Source fieldCraftable=false; preserved timeMode=expedition; the false field flag controls. Source time: 8 hours; source activeWorkHours=8. Operational required active time 8 hours. First stable phase 8 hours, included in total. Eligible Forge Dwarf: 360 minutes, first phase 360 minutes. Stabilize only components actually incorporated in the completed first phase; other lots keep their clocks.

**Progression:** exact source trivialAtSkillLevel=8; use this threshold rather than regenerating level+5. Actual formula access: {"sources":["trainer","starter manual","common experimentation"],"minimumResearchHours":0,"requiresFormula":false,"formulaConsumed":false}. The framework controls trade eligibility, proficiency once, assistant qualifications, Watches, rest, interruptions, XP and mishaps.

**Output:** Standard 5; Exceptional yield 6; Masterwork yield 7; or 5 units with strongest noncompounding structural improvement 25%/50%. Flawed: 2 ordinary-effect units, preserving existing physical durability state. Failed/Mishap transforms none; source input recovery/loss remains separate. Quality changes no capacity, relief, check bonus, AC, resistance or grade.

**Repair:** trained Leatherworker's tools, Tannery Bench, Awl and Cutting knife. Functional HP≥1: DEX + applicable proficiency DC10; max(1 hour, recorded max HP/10); materials 25% mundane base reference. Broken HP0: DEX + applicable proficiency DC9; max(8 hours, recorded max HP/10); materials 25% finished per-item reference; recoverable original main body required. Binary success restores recorded maximum, including the persistent flaw; failure consumes materials and time. No formula or original trade-level eligibility required or granted, quality roll, XP, catalyst return or Forge Dwarf creation reduction. No lost contents return.

**Finished ordinary Standard reference examples:** Cargo pouch 10 lb = 25 gp. Source process share 24 gp/unit plus actual undamaged mundane size/grade body reference. Retain exact precision until the actual transaction; no automatic buyer, quality premium, artifact multiplier or mundane-table magic buyback.

**Preserved tags:** Stealth. Tags, current/legacy names, donors and whole-creature metadata add no powers or availability.

**Public source binding:** V5 ¶1604, ¶1605, ¶1606, ¶1607, ¶1608, ¶1609. The original effect remains verbatim; any AC overlay above is separate.

**Preserved inactive legacy/metadata:** {"legacyName": "Standard Flexible Pouch", "legacyEffect": "Temporary resistance"}.

## recipe-291 — Refined Frost Belt

**REVIEWED — authored operational PLAYTEST.** public; Leatherworking level 3; tier 2; Common; DC 10. Standard quantity 2; source Standard batch reference 154 gp.

**Preserved effect:** Creates a reinforced belt carrying 10 pounds without counting against normal encumbrance; grants +1 to checks to secure or retrieve its contents.

**Operational effect:** One output transforms one complete mundane body, retaining its physical identity and latest lawful completion damage state. Functional means at least 1 current structural HP; the singleton Flawed result can emerge Broken with a dormant imprint. While functional, unsuppressed, unmelded, properly fitted and worn or directly held in its recorded waist-cargo relief position, cover up to 10 lb of eligible contents in stable loading order. Physical capacity remains 10 lb and 1/3 ft³, subject to its actual opening, shape and compartment limits. Its own body is not relieved. For each covered record, subtract covered pounds from the direct bearer's pound-carrying comparison and at most min(canonical Load, covered pounds/10) from Inventory Load; preserve actual mass and canonical Load. Enclosed enchanted containers are inactive; ordinary inner bodies and descendants count once. External lashings do not become contents. The actual operator receives +1 on a qualifying handling check: Actual difficult cargo handling to secure its ordinary closure/retainers or retrieve through an unlocked closure, jam, tangle or other physical difficulty: DEX for dexterous work or STR (Athletics) for forceful handling of noncreature cargo. This handling benefit needs accessible functional unsuppressed fittings, not a relief slot, and can apply on a table or for an ally. Only the strongest qualifying Leatherworking task bonus applies once per actual check. No routine check is invented; ordinary actions, hands, access, proficiency and competing slot requirements still apply. Broken stops positive functions; suppression stops recipe magic, not physical capacity or workmanship. Use the complete shared guide for custody, melding, quality, repair and value.

**Legal mundane bases:** Cargo belt 10 lb. One model, actual fit and legal grade for the whole batch. Buy, own or legitimately commission complete bodies; no stock-construction recipe is implied.

**Physical reserve:** 3 complete, nonmagical, non-Broken bases in a stable physical-ID order before work; containers empty. No existing imprint. Missing/Broken/committed bases pause before the roll; repair or replace at the same position. Transform the first resolved N, using latest lawful completion HP. Keep unused bodies in their actual state outside ingredient recovery.

| Mundane body | Price gp | Empty lb | Ordinary HP / structural AC | Benefit slot | Ordinary use |
|---|---:|---:|---|---|---|
| Cargo belt 10 lb | 2 | 2 | 5 / 15 | waist-cargo | 10 lb / 1/3 ft³ contents |

| Container | Compartments | Interior per compartment, inches | Opening, inches | Exterior, inches | Each compartment limit |
|---|---:|---|---|---|---|
| Cargo belt 10 lb | 1 | 12 × 8 × 6 | 12 × 6 | 13 × 9 × 7 per pocket | 10 lb / 1/3 ft³ |

**Exact source component occurrences:**

| # | Component | Quantity | Tier | Role / consumed | Unit lb | Unit gp | Required properties |
|---|---|---:|---:|---|---:|---:|---|
| 0 | Waterproofing oil | 4 | 2 | solvent / true | 0.5 | 8 | solvent |
| 1 | Lining | 5 | 2 | reinforcement / true | 0.25 | 8 | reinforcement |
| 2 | Reinforced stitching | 3 | 2 | binder / true | 0.1 | 8 | binder |
| 3 | Triceratops pelt | 1 | 1 | material / true | 0.75 | 14 | cold, flexible, protective |

All listed inputs are additional consumed process/reinforcement materials. Finished empty mass is the actual body mass; process waste supplies no second body or automatically valuable salvage. No source component is a catalyst; even Masterwork returns zero catalyst units. Independently required tools remain tools.

**Work and access:** DEX with actual Leatherworker's-tools proficiency as the shared framework permits; Tannery Bench; Leatherworker's tools, Awl, Cutting knife. Maximum assistants 0. Source fieldCraftable=false; preserved timeMode=expedition; the false field flag controls. Source time: 4 hours; source activeWorkHours=4. Operational required active time 4 hours. First stable phase 4 hours, included in total. Eligible Forge Dwarf: 180 minutes, first phase 180 minutes. Stabilize only components actually incorporated in the completed first phase; other lots keep their clocks.

**Progression:** exact source trivialAtSkillLevel=8; use this threshold rather than regenerating level+5. Actual formula access: {"sources":["trainer","starter manual","common experimentation"],"minimumResearchHours":0,"requiresFormula":false,"formulaConsumed":false}. The framework controls trade eligibility, proficiency once, assistant qualifications, Watches, rest, interruptions, XP and mishaps.

**Output:** Standard 2; Exceptional yield 2; Masterwork yield 3; or 2 units with strongest noncompounding structural improvement 25%/50%. Flawed: 1 ordinary-effect units, preserving existing physical durability state. Failed/Mishap transforms none; source input recovery/loss remains separate. Quality changes no capacity, relief, check bonus, AC, resistance or grade.

**Repair:** trained Leatherworker's tools, Tannery Bench, Awl and Cutting knife. Functional HP≥1: DEX + applicable proficiency DC10; max(1 hour, recorded max HP/10); materials 25% mundane base reference. Broken HP0: DEX + applicable proficiency DC10; max(8 hours, recorded max HP/10); materials 25% finished per-item reference; recoverable original main body required. Binary success restores recorded maximum, including the persistent flaw; failure consumes materials and time. No formula or original trade-level eligibility required or granted, quality roll, XP, catalyst return or Forge Dwarf creation reduction. No lost contents return.

**Finished ordinary Standard reference examples:** Cargo belt 10 lb = 79 gp. Source process share 77 gp/unit plus actual undamaged mundane size/grade body reference. Retain exact precision until the actual transaction; no automatic buyer, quality premium, artifact multiplier or mundane-table magic buyback.

**Preserved tags:** Cold. Tags, current/legacy names, donors and whole-creature metadata add no powers or availability.

**Public source binding:** V5 ¶1583, ¶1584, ¶1585, ¶1586, ¶1587, ¶1588. The original effect remains verbatim; any AC overlay above is separate.

**Preserved inactive legacy/metadata:** {"legacyName": "Serviceable Belt", "legacyEffect": "Temporary resistance"}.

## recipe-292 — Refined Caustic Quiver

**REVIEWED — authored operational PLAYTEST.** public; Leatherworking level 3; tier 2; Common; DC 10. Standard quantity 2; source Standard batch reference 110 gp.

**Preserved effect:** Creates a reinforced quiver carrying 10 pounds without counting against normal encumbrance; grants +1 to checks to secure or retrieve its contents.

**Operational effect:** One output transforms one complete mundane body, retaining its physical identity and latest lawful completion damage state. Functional means at least 1 current structural HP; the singleton Flawed result can emerge Broken with a dormant imprint. While functional, unsuppressed, unmelded, properly fitted and worn or directly held in its recorded quiver relief position, cover up to 10 lb of eligible contents in stable loading order. Physical capacity remains 10 lb and 1/3 ft³, subject to its actual opening, shape and compartment limits. Its own body is not relieved. For each covered record, subtract covered pounds from the direct bearer's pound-carrying comparison and at most min(canonical Load, covered pounds/10) from Inventory Load; preserve actual mass and canonical Load. Enclosed enchanted containers are inactive; ordinary inner bodies and descendants count once. External lashings do not become contents. The actual operator receives +1 on a qualifying handling check: Actual difficult cargo handling to secure its ordinary closure/retainers or retrieve through an unlocked closure, jam, tangle or other physical difficulty: DEX for dexterous work or STR (Athletics) for forceful handling of noncreature cargo. This handling benefit needs accessible functional unsuppressed fittings, not a relief slot, and can apply on a table or for an ally. Only the strongest qualifying Leatherworking task bonus applies once per actual check. No routine check is invented; ordinary actions, hands, access, proficiency and competing slot requirements still apply. Broken stops positive functions; suppression stops recipe magic, not physical capacity or workmanship. Use the complete shared guide for custody, melding, quality, repair and value.

**Legal mundane bases:** Cargo quiver 10 lb. One model, actual fit and legal grade for the whole batch. Buy, own or legitimately commission complete bodies; no stock-construction recipe is implied.

**Physical reserve:** 3 complete, nonmagical, non-Broken bases in a stable physical-ID order before work; containers empty. No existing imprint. Missing/Broken/committed bases pause before the roll; repair or replace at the same position. Transform the first resolved N, using latest lawful completion HP. Keep unused bodies in their actual state outside ingredient recovery.

| Mundane body | Price gp | Empty lb | Ordinary HP / structural AC | Benefit slot | Ordinary use |
|---|---:|---:|---|---|---|
| Cargo quiver 10 lb | 2 | 2 | 5 / 15 | quiver | 10 lb / 1/3 ft³ contents |

| Container | Compartments | Interior per compartment, inches | Opening, inches | Exterior, inches | Each compartment limit |
|---|---:|---|---|---|---|
| Cargo quiver 10 lb | 1 | 36 × 4 × 4 | 4 × 4 | 38 × 6 × 6 | 10 lb / 1/3 ft³ |

**Exact source component occurrences:**

| # | Component | Quantity | Tier | Role / consumed | Unit lb | Unit gp | Required properties |
|---|---|---:|---:|---|---:|---:|---|
| 0 | Buckles | 5 | 2 | ingredient / true | 0.1 | 8 |  |
| 1 | Tanned hide | 4 | 2 | ingredient / true | 0.25 | 8 |  |
| 2 | black dragon scale | 1 | 1 | material / true | 0.43 | 8 | acid, draconic, protective, rigid |

All listed inputs are additional consumed process/reinforcement materials. Finished empty mass is the actual body mass; process waste supplies no second body or automatically valuable salvage. No source component is a catalyst; even Masterwork returns zero catalyst units. Independently required tools remain tools.

**Work and access:** DEX with actual Leatherworker's-tools proficiency as the shared framework permits; Tannery Bench; Leatherworker's tools, Awl, Cutting knife. Maximum assistants 0. Source fieldCraftable=false; preserved timeMode=field; the false field flag controls. Source time: 1 hour; source activeWorkHours=1. Operational required active time 1 hours. First stable phase 1 hours, included in total. Eligible Forge Dwarf: 45 minutes, first phase 45 minutes. Stabilize only components actually incorporated in the completed first phase; other lots keep their clocks.

**Progression:** exact source trivialAtSkillLevel=8; use this threshold rather than regenerating level+5. Actual formula access: {"sources":["trainer","starter manual","common experimentation"],"minimumResearchHours":0,"requiresFormula":false,"formulaConsumed":false}. The framework controls trade eligibility, proficiency once, assistant qualifications, Watches, rest, interruptions, XP and mishaps.

**Output:** Standard 2; Exceptional yield 2; Masterwork yield 3; or 2 units with strongest noncompounding structural improvement 25%/50%. Flawed: 1 ordinary-effect units, preserving existing physical durability state. Failed/Mishap transforms none; source input recovery/loss remains separate. Quality changes no capacity, relief, check bonus, AC, resistance or grade.

**Repair:** trained Leatherworker's tools, Tannery Bench, Awl and Cutting knife. Functional HP≥1: DEX + applicable proficiency DC10; max(1 hour, recorded max HP/10); materials 25% mundane base reference. Broken HP0: DEX + applicable proficiency DC10; max(8 hours, recorded max HP/10); materials 25% finished per-item reference; recoverable original main body required. Binary success restores recorded maximum, including the persistent flaw; failure consumes materials and time. No formula or original trade-level eligibility required or granted, quality roll, XP, catalyst return or Forge Dwarf creation reduction. No lost contents return.

**Finished ordinary Standard reference examples:** Cargo quiver 10 lb = 57 gp. Source process share 55 gp/unit plus actual undamaged mundane size/grade body reference. Retain exact precision until the actual transaction; no automatic buyer, quality premium, artifact multiplier or mundane-table magic buyback.

**Preserved tags:** Acid. Tags, current/legacy names, donors and whole-creature metadata add no powers or availability.

**Public source binding:** V5 ¶1576, ¶1577, ¶1578, ¶1579, ¶1580, ¶1581. The original effect remains verbatim; any AC overlay above is separate.

**Preserved inactive legacy/metadata:** {"legacyName": "Quiver of Tanned Standardness", "legacyEffect": "Small bonus to one skill"}.

## recipe-293 — Field Grave Backpack

**REVIEWED — authored operational PLAYTEST.** public; Leatherworking level 2; tier 1; Common; DC 12. Standard quantity 1; source Standard batch reference 407 gp.

**Preserved effect:** Creates a reinforced backpack carrying 10 pounds without counting against normal encumbrance; grants +1 to checks to secure or retrieve its contents.

**Operational effect:** One output transforms one complete mundane body, retaining its physical identity and latest lawful completion damage state. Functional means at least 1 current structural HP; the singleton Flawed result can emerge Broken with a dormant imprint. While functional, unsuppressed, unmelded, properly fitted and worn or directly held in its recorded back-cargo relief position, cover up to 10 lb of eligible contents in stable loading order. Physical capacity remains 30 lb and 1 ft³, subject to its actual opening, shape and compartment limits. Its own body is not relieved. For each covered record, subtract covered pounds from the direct bearer's pound-carrying comparison and at most min(canonical Load, covered pounds/10) from Inventory Load; preserve actual mass and canonical Load. Enclosed enchanted containers are inactive; ordinary inner bodies and descendants count once. External lashings do not become contents. The actual operator receives +1 on a qualifying handling check: Actual difficult cargo handling to secure its ordinary closure/retainers or retrieve through an unlocked closure, jam, tangle or other physical difficulty: DEX for dexterous work or STR (Athletics) for forceful handling of noncreature cargo. This handling benefit needs accessible functional unsuppressed fittings, not a relief slot, and can apply on a table or for an ally. Only the strongest qualifying Leatherworking task bonus applies once per actual check. No routine check is invented; ordinary actions, hands, access, proficiency and competing slot requirements still apply. Broken stops positive functions; suppression stops recipe magic, not physical capacity or workmanship. Use the complete shared guide for custody, melding, quality, repair and value.

**Legal mundane bases:** Backpack. One model, actual fit and legal grade for the whole batch. Buy, own or legitimately commission complete bodies; no stock-construction recipe is implied.

**Physical reserve:** 1 complete, nonmagical, non-Broken bases in a stable physical-ID order before work; containers empty. No existing imprint. Missing/Broken/committed bases pause before the roll; repair or replace at the same position. Transform the first resolved N, using latest lawful completion HP. Keep unused bodies in their actual state outside ingredient recovery.

| Mundane body | Price gp | Empty lb | Ordinary HP / structural AC | Benefit slot | Ordinary use |
|---|---:|---:|---|---|---|
| Backpack | 2 | 5 | 10 / 15 | back-cargo | 30 lb / 1 ft³ contents |

| Container | Compartments | Interior per compartment, inches | Opening, inches | Exterior, inches | Each compartment limit |
|---|---:|---|---|---|---|
| Backpack | 1 | 18 × 12 × 8 | 12 × 8 | 20 × 14 × 10 | 30 lb / 1 ft³ |

**Exact source component occurrences:**

| # | Component | Quantity | Tier | Role / consumed | Unit lb | Unit gp | Required properties |
|---|---|---:|---:|---|---:|---:|---|
| 0 | Leather strips | 4 | 1 | substrate / true | 0.25 | 2 | substrate |
| 1 | demonic talon | 1 | 4 | material / true | 0.11 | 293 | rigid, structural, unholy |

All listed inputs are additional consumed process/reinforcement materials. Finished empty mass is the actual body mass; process waste supplies no second body or automatically valuable salvage. No source component is a catalyst; even Masterwork returns zero catalyst units. Independently required tools remain tools.

**Work and access:** DEX with actual Leatherworker's-tools proficiency as the shared framework permits; Tannery Bench; Leatherworker's tools, Awl, Cutting knife. Maximum assistants 0. Source fieldCraftable=false; preserved timeMode=field; the false field flag controls. Source time: 1 hour; source activeWorkHours=1. Operational required active time 1 hours. First stable phase 1 hours, included in total. Eligible Forge Dwarf: 45 minutes, first phase 45 minutes. Stabilize only components actually incorporated in the completed first phase; other lots keep their clocks.

**Progression:** exact source trivialAtSkillLevel=7; use this threshold rather than regenerating level+5. Actual formula access: {"sources":["trainer","starter manual","common experimentation"],"minimumResearchHours":0,"requiresFormula":false,"formulaConsumed":false}. The framework controls trade eligibility, proficiency once, assistant qualifications, Watches, rest, interruptions, XP and mishaps.

**Output:** Standard 1; Exceptional yield 1; Masterwork yield 1; or 1 units with strongest noncompounding structural improvement 25%/50%. Flawed: one persistent half-maximum flaw applied after size/grade and strongest improvement, minimum1; preserve damage deficit and possible Broken output. Failed/Mishap transforms none; source input recovery/loss remains separate. Quality changes no capacity, relief, check bonus, AC, resistance or grade.

**Repair:** trained Leatherworker's tools, Tannery Bench, Awl and Cutting knife. Functional HP≥1: DEX + applicable proficiency DC10; max(1 hour, recorded max HP/10); materials 25% mundane base reference. Broken HP0: DEX + applicable proficiency DC12; max(8 hours, recorded max HP/10); materials 25% finished per-item reference; recoverable original main body required. Binary success restores recorded maximum, including the persistent flaw; failure consumes materials and time. No formula or original trade-level eligibility required or granted, quality roll, XP, catalyst return or Forge Dwarf creation reduction. No lost contents return.

**Finished ordinary Standard reference examples:** Backpack = 409 gp. Source process share 407 gp/unit plus actual undamaged mundane size/grade body reference. Retain exact precision until the actual transaction; no automatic buyer, quality premium, artifact multiplier or mundane-table magic buyback.

**Preserved tags:** Unholy. Tags, current/legacy names, donors and whole-creature metadata add no powers or availability.

**Public source binding:** V5 ¶1562, ¶1563, ¶1564, ¶1565, ¶1566, ¶1567. The original effect remains verbatim; any AC overlay above is separate.

**Preserved inactive legacy/metadata:** {"legacyName": "Backpack of Flexible Serviceableness", "legacyEffect": "Small bonus to one skill"}.

## recipe-294 — Field Veiled Gloves

**REVIEWED — authored operational PLAYTEST.** public; Leatherworking level 1; tier 1; Common; DC 10. Standard quantity 3; source Standard batch reference 56 gp.

**Preserved effect:** Creates fitted gloves granting +1 to a related mobility or handling check.

**Operational effect:** One output transforms one complete matched pair, retaining its physical identity and latest lawful completion damage state. Functional means at least 1 current structural HP; the singleton Flawed result can emerge Broken with a dormant imprint. While complete, functional, unsuppressed, unmelded and actually worn in its handwear-pair benefit slot, receive +1 only on these actual checks: STR (Athletics) for climbing with actual handholds or rope grip; STR (Athletics) or DEX to retain, lower or position noncreature cargo by hand; DEX for ordinary nonlocking ties, straps, clasps or a jammed small object. The source armorBonus of 0 creates no recipe AC candidate and does not cancel a Crude suit penalty. No damage resistance or environmental immunity is granted. Only the strongest qualifying Leatherworking task bonus applies once per actual check. No routine check is invented; ordinary actions, hands, access, proficiency and competing slot requirements still apply. Broken stops positive functions; suppression stops recipe magic, not physical capacity or workmanship. Use the complete shared guide for custody, melding, quality, repair and value.

**Legal mundane bases:** Gloves pair. One model, actual fit and legal grade for the whole batch. Buy, own or legitimately commission complete bodies; no stock-construction recipe is implied.

**Physical reserve:** 4 complete, nonmagical, non-Broken bases in a stable physical-ID order before work; containers empty. No existing imprint. Missing/Broken/committed bases pause before the roll; repair or replace at the same position. Transform the first resolved N, using latest lawful completion HP. Keep unused bodies in their actual state outside ingredient recovery.

| Mundane body | Price gp | Empty lb | Ordinary HP / structural AC | Benefit slot | Ordinary use |
|---|---:|---:|---|---|---|
| Gloves pair | 1 | 0.5 | 5 / 15 | handwear-pair | one matched pair |

| Container | Compartments | Interior per compartment, inches | Opening, inches | Exterior, inches | Each compartment limit |
|---|---:|---|---|---|---|

**Exact source component occurrences:**

| # | Component | Quantity | Tier | Role / consumed | Unit lb | Unit gp | Required properties |
|---|---|---:|---:|---|---:|---:|---|
| 0 | Padding | 3 | 1 | reinforcement / true | 0.25 | 2 | reinforcement |
| 1 | black dragon scale | 1 | 1 | material / true | 0.43 | 8 | acid, draconic, protective, rigid |

All listed inputs are additional consumed process/reinforcement materials. Finished empty mass is the actual body mass; process waste supplies no second body or automatically valuable salvage. No source component is a catalyst; even Masterwork returns zero catalyst units. Independently required tools remain tools.

**Work and access:** DEX with actual Leatherworker's-tools proficiency as the shared framework permits; Tannery Bench; Leatherworker's tools, Awl, Cutting knife. Maximum assistants 0. Source fieldCraftable=false; preserved timeMode=expedition; the false field flag controls. Source time: 8 hours; source activeWorkHours=8. Operational required active time 8 hours. First stable phase 8 hours, included in total. Eligible Forge Dwarf: 360 minutes, first phase 360 minutes. Stabilize only components actually incorporated in the completed first phase; other lots keep their clocks.

**Progression:** exact source trivialAtSkillLevel=6; use this threshold rather than regenerating level+5. Actual formula access: {"sources":["trainer","starter manual","common experimentation"],"minimumResearchHours":0,"requiresFormula":false,"formulaConsumed":false}. The framework controls trade eligibility, proficiency once, assistant qualifications, Watches, rest, interruptions, XP and mishaps.

**Output:** Standard 3; Exceptional yield 3; Masterwork yield 4; or 3 units with strongest noncompounding structural improvement 25%/50%. Flawed: 1 ordinary-effect units, preserving existing physical durability state. Failed/Mishap transforms none; source input recovery/loss remains separate. Quality changes no capacity, relief, check bonus, AC, resistance or grade.

**Repair:** trained Leatherworker's tools, Tannery Bench, Awl and Cutting knife. Functional HP≥1: DEX + applicable proficiency DC10; max(1 hour, recorded max HP/10); materials 25% mundane base reference. Broken HP0: DEX + applicable proficiency DC10; max(8 hours, recorded max HP/10); materials 25% finished per-item reference; recoverable original main body required with both original pair members. Binary success restores recorded maximum, including the persistent flaw; failure consumes materials and time. No formula or original trade-level eligibility required or granted, quality roll, XP, catalyst return or Forge Dwarf creation reduction. No lost contents return.

**Finished ordinary Standard reference examples:** Gloves pair = 59/3 gp. Source process share 56/3 gp/unit plus actual undamaged mundane size/grade body reference. Retain exact precision until the actual transaction; no automatic buyer, quality premium, artifact multiplier or mundane-table magic buyback.

**Preserved tags:** Stealth. Tags, current/legacy names, donors and whole-creature metadata add no powers or availability.

**Public source binding:** V5 ¶1548, ¶1549, ¶1550, ¶1551, ¶1552, ¶1553. The original effect remains verbatim; any AC overlay above is separate.

**Preserved inactive legacy/metadata:** {"legacyName": "Standard Flexible Gloves", "legacyEffect": "Minor magical effect"}.

## recipe-295 — Superior Grave Pouch of Demonic Talon

**REVIEWED — authored operational PLAYTEST.** public; Leatherworking level 6; tier 3; Uncommon; DC 14. Standard quantity 1; source Standard batch reference 839 gp.

**Preserved effect:** Creates a reinforced pouch carrying 20 pounds without counting against normal encumbrance; grants +1 to checks to secure or retrieve its contents.

**Operational effect:** One output transforms one complete mundane body, retaining its physical identity and latest lawful completion damage state. Functional means at least 1 current structural HP; the singleton Flawed result can emerge Broken with a dormant imprint. While functional, unsuppressed, unmelded, properly fitted and worn or directly held in its recorded pouch-position relief position, cover up to 20 lb of eligible contents in stable loading order. Physical capacity remains 20 lb and 2/3 ft³, subject to its actual opening, shape and compartment limits. Its own body is not relieved. For each covered record, subtract covered pounds from the direct bearer's pound-carrying comparison and at most min(canonical Load, covered pounds/10) from Inventory Load; preserve actual mass and canonical Load. Enclosed enchanted containers are inactive; ordinary inner bodies and descendants count once. External lashings do not become contents. The actual operator receives +1 on a qualifying handling check: Actual difficult cargo handling to secure its ordinary closure/retainers or retrieve through an unlocked closure, jam, tangle or other physical difficulty: DEX for dexterous work or STR (Athletics) for forceful handling of noncreature cargo. This handling benefit needs accessible functional unsuppressed fittings, not a relief slot, and can apply on a table or for an ally. Only the strongest qualifying Leatherworking task bonus applies once per actual check. No routine check is invented; ordinary actions, hands, access, proficiency and competing slot requirements still apply. Broken stops positive functions; suppression stops recipe magic, not physical capacity or workmanship. Use the complete shared guide for custody, melding, quality, repair and value.

**Legal mundane bases:** Cargo pouch 20 lb. One model, actual fit and legal grade for the whole batch. Buy, own or legitimately commission complete bodies; no stock-construction recipe is implied.

**Physical reserve:** 1 complete, nonmagical, non-Broken bases in a stable physical-ID order before work; containers empty. No existing imprint. Missing/Broken/committed bases pause before the roll; repair or replace at the same position. Transform the first resolved N, using latest lawful completion HP. Keep unused bodies in their actual state outside ingredient recovery.

| Mundane body | Price gp | Empty lb | Ordinary HP / structural AC | Benefit slot | Ordinary use |
|---|---:|---:|---|---|---|
| Cargo pouch 20 lb | 2 | 3 | 5 / 15 | pouch-position | 20 lb / 2/3 ft³ contents |

| Container | Compartments | Interior per compartment, inches | Opening, inches | Exterior, inches | Each compartment limit |
|---|---:|---|---|---|---|
| Cargo pouch 20 lb | 1 | 12 × 8 × 12 | 12 × 12 | 13 × 9 × 13 | 20 lb / 2/3 ft³ |

**Exact source component occurrences:**

| # | Component | Quantity | Tier | Role / consumed | Unit lb | Unit gp | Required properties |
|---|---|---:|---:|---|---:|---:|---|
| 0 | Buckles | 1 | 3 | ingredient / true | 0.1 | 25 |  |
| 1 | Padding | 5 | 3 | reinforcement / true | 0.25 | 25 | reinforcement |
| 2 | Cured leather | 5 | 3 | substrate / true | 0.25 | 25 | substrate |
| 3 | demonic talon | 1 | 4 | material / true | 0.11 | 293 | rigid, structural, unholy |

All listed inputs are additional consumed process/reinforcement materials. Finished empty mass is the actual body mass; process waste supplies no second body or automatically valuable salvage. No source component is a catalyst; even Masterwork returns zero catalyst units. Independently required tools remain tools.

**Work and access:** DEX with actual Leatherworker's-tools proficiency as the shared framework permits; Tannery Bench; Leatherworker's tools, Awl, Cutting knife. Maximum assistants 0. Source fieldCraftable=false; preserved timeMode=workshop; the false field flag controls. Source time: 3 days; source activeWorkHours=24. Operational required active time 24 hours. First stable phase 8 hours, included in total. Eligible Forge Dwarf: 1080 minutes, first phase 480 minutes. Stabilize only components actually incorporated in the completed first phase; other lots keep their clocks.

**Progression:** exact source trivialAtSkillLevel=11; use this threshold rather than regenerating level+5. Actual formula access: {"sources":["guild trainer","faction vendor","uncommon dungeon book","reverse engineering"],"minimumResearchHours":0,"requiresFormula":true,"formulaConsumed":false}. The framework controls trade eligibility, proficiency once, assistant qualifications, Watches, rest, interruptions, XP and mishaps.

**Output:** Standard 1; Exceptional yield 1; Masterwork yield 1; or 1 units with strongest noncompounding structural improvement 25%/50%. Flawed: one persistent half-maximum flaw applied after size/grade and strongest improvement, minimum1; preserve damage deficit and possible Broken output. Failed/Mishap transforms none; source input recovery/loss remains separate. Quality changes no capacity, relief, check bonus, AC, resistance or grade.

**Repair:** trained Leatherworker's tools, Tannery Bench, Awl and Cutting knife. Functional HP≥1: DEX + applicable proficiency DC10; max(1 hour, recorded max HP/10); materials 25% mundane base reference. Broken HP0: DEX + applicable proficiency DC14; max(8 hours, recorded max HP/10); materials 25% finished per-item reference; recoverable original main body required. Binary success restores recorded maximum, including the persistent flaw; failure consumes materials and time. No formula or original trade-level eligibility required or granted, quality roll, XP, catalyst return or Forge Dwarf creation reduction. No lost contents return.

**Finished ordinary Standard reference examples:** Cargo pouch 20 lb = 841 gp. Source process share 839 gp/unit plus actual undamaged mundane size/grade body reference. Retain exact precision until the actual transaction; no automatic buyer, quality premium, artifact multiplier or mundane-table magic buyback.

**Preserved tags:** Unholy. Tags, current/legacy names, donors and whole-creature metadata add no powers or availability.

**Public source binding:** V5 ¶1674, ¶1675, ¶1676, ¶1677, ¶1678, ¶1679. The original effect remains verbatim; any AC overlay above is separate.

**Preserved inactive legacy/metadata:** {"legacyName": "Hardened Pouch", "legacyEffect": "Daily spell-like ability"}.

## recipe-296 — Masterwork Veiled Leather Gear of Black Dragon Talon

**REVIEWED — authored operational PLAYTEST.** public; Leatherworking level 7; tier 4; Uncommon; DC 13. Standard quantity 1; source Standard batch reference 525 gp.

**Preserved effect:** Creates fitted leather gear granting +1 to a related mobility or handling check.

**Operational effect:** One output transforms one complete mundane body, retaining its physical identity and latest lawful completion damage state. Functional means at least 1 current structural HP; the singleton Flawed result can emerge Broken with a dormant imprint. While complete, functional, unsuppressed, unmelded and actually worn in its torso-accessory benefit slot, receive +1 only on these actual checks: STR (Athletics) for actual climbing; DEX (Acrobatics) for controlled movement through a cramped or obstructed passage when a check is actually required. The source armorBonus of 0 creates no recipe AC candidate and does not cancel a Crude suit penalty. No damage resistance or environmental immunity is granted. Only the strongest qualifying Leatherworking task bonus applies once per actual check. No routine check is invented; ordinary actions, hands, access, proficiency and competing slot requirements still apply. Broken stops positive functions; suppression stops recipe magic, not physical capacity or workmanship. Use the complete shared guide for custody, melding, quality, repair and value.

**Legal mundane bases:** Leather mobility vest. One model, actual fit and legal grade for the whole batch. Buy, own or legitimately commission complete bodies; no stock-construction recipe is implied.

**Physical reserve:** 1 complete, nonmagical, non-Broken bases in a stable physical-ID order before work; containers empty. No existing imprint. Missing/Broken/committed bases pause before the roll; repair or replace at the same position. Transform the first resolved N, using latest lawful completion HP. Keep unused bodies in their actual state outside ingredient recovery.

| Mundane body | Price gp | Empty lb | Ordinary HP / structural AC | Benefit slot | Ordinary use |
|---|---:|---:|---|---|---|
| Leather mobility vest | 5 | 4 | 5 / 15 | torso-accessory | one item |

| Container | Compartments | Interior per compartment, inches | Opening, inches | Exterior, inches | Each compartment limit |
|---|---:|---|---|---|---|

**Exact source component occurrences:**

| # | Component | Quantity | Tier | Role / consumed | Unit lb | Unit gp | Required properties |
|---|---|---:|---:|---|---:|---:|---|
| 0 | Cured leather | 3 | 4 | substrate / true | 0.25 | 75 | substrate |
| 1 | Reinforced stitching | 1 | 4 | binder / true | 0.1 | 75 | binder |
| 2 | black dragon talon | 1 | 2 | material / true | 0.31 | 27 | acid, draconic, rigid, structural |

All listed inputs are additional consumed process/reinforcement materials. Finished empty mass is the actual body mass; process waste supplies no second body or automatically valuable salvage. No source component is a catalyst; even Masterwork returns zero catalyst units. Independently required tools remain tools.

**Work and access:** DEX with actual Leatherworker's-tools proficiency as the shared framework permits; Tannery Bench; Leatherworker's tools, Awl, Cutting knife. Maximum assistants 0. Source fieldCraftable=false; preserved timeMode=workshop; the false field flag controls. Source time: 3 days; source activeWorkHours=24. Operational required active time 24 hours. First stable phase 8 hours, included in total. Eligible Forge Dwarf: 1080 minutes, first phase 480 minutes. Stabilize only components actually incorporated in the completed first phase; other lots keep their clocks.

**Progression:** exact source trivialAtSkillLevel=12; use this threshold rather than regenerating level+5. Actual formula access: {"sources":["guild trainer","faction vendor","uncommon dungeon book","reverse engineering"],"minimumResearchHours":0,"requiresFormula":true,"formulaConsumed":false}. The framework controls trade eligibility, proficiency once, assistant qualifications, Watches, rest, interruptions, XP and mishaps.

**Output:** Standard 1; Exceptional yield 1; Masterwork yield 1; or 1 units with strongest noncompounding structural improvement 25%/50%. Flawed: one persistent half-maximum flaw applied after size/grade and strongest improvement, minimum1; preserve damage deficit and possible Broken output. Failed/Mishap transforms none; source input recovery/loss remains separate. Quality changes no capacity, relief, check bonus, AC, resistance or grade.

**Repair:** trained Leatherworker's tools, Tannery Bench, Awl and Cutting knife. Functional HP≥1: DEX + applicable proficiency DC10; max(1 hour, recorded max HP/10); materials 25% mundane base reference. Broken HP0: DEX + applicable proficiency DC13; max(8 hours, recorded max HP/10); materials 25% finished per-item reference; recoverable original main body required. Binary success restores recorded maximum, including the persistent flaw; failure consumes materials and time. No formula or original trade-level eligibility required or granted, quality roll, XP, catalyst return or Forge Dwarf creation reduction. No lost contents return.

**Finished ordinary Standard reference examples:** Leather mobility vest = 530 gp. Source process share 525 gp/unit plus actual undamaged mundane size/grade body reference. Retain exact precision until the actual transaction; no automatic buyer, quality premium, artifact multiplier or mundane-table magic buyback.

**Preserved tags:** Stealth. Tags, current/legacy names, donors and whole-creature metadata add no powers or availability.

**Public source binding:** V5 ¶1695, ¶1696, ¶1697, ¶1698, ¶1699, ¶1700. The original effect remains verbatim; any AC overlay above is separate.

**Preserved inactive legacy/metadata:** {"legacyName": "Saddle of Hardened Enhancedness", "legacyEffect": "Bonus to multiple skills"}.

## recipe-297 — Superior Verdant Backpack of Animated Vine

**REVIEWED — authored operational PLAYTEST.** public; Leatherworking level 5; tier 3; Uncommon; DC 16. Standard quantity 1; source Standard batch reference 496 gp.

**Preserved effect:** Creates a reinforced backpack carrying 20 pounds without counting against normal encumbrance; grants +1 to checks to secure or retrieve its contents.

**Operational effect:** One output transforms one complete mundane body, retaining its physical identity and latest lawful completion damage state. Functional means at least 1 current structural HP; the singleton Flawed result can emerge Broken with a dormant imprint. While functional, unsuppressed, unmelded, properly fitted and worn or directly held in its recorded back-cargo relief position, cover up to 20 lb of eligible contents in stable loading order. Physical capacity remains 30 lb and 1 ft³, subject to its actual opening, shape and compartment limits. Its own body is not relieved. For each covered record, subtract covered pounds from the direct bearer's pound-carrying comparison and at most min(canonical Load, covered pounds/10) from Inventory Load; preserve actual mass and canonical Load. Enclosed enchanted containers are inactive; ordinary inner bodies and descendants count once. External lashings do not become contents. The actual operator receives +1 on a qualifying handling check: Actual difficult cargo handling to secure its ordinary closure/retainers or retrieve through an unlocked closure, jam, tangle or other physical difficulty: DEX for dexterous work or STR (Athletics) for forceful handling of noncreature cargo. This handling benefit needs accessible functional unsuppressed fittings, not a relief slot, and can apply on a table or for an ally. Only the strongest qualifying Leatherworking task bonus applies once per actual check. No routine check is invented; ordinary actions, hands, access, proficiency and competing slot requirements still apply. Broken stops positive functions; suppression stops recipe magic, not physical capacity or workmanship. Use the complete shared guide for custody, melding, quality, repair and value.

**Legal mundane bases:** Backpack. One model, actual fit and legal grade for the whole batch. Buy, own or legitimately commission complete bodies; no stock-construction recipe is implied.

**Physical reserve:** 1 complete, nonmagical, non-Broken bases in a stable physical-ID order before work; containers empty. No existing imprint. Missing/Broken/committed bases pause before the roll; repair or replace at the same position. Transform the first resolved N, using latest lawful completion HP. Keep unused bodies in their actual state outside ingredient recovery.

| Mundane body | Price gp | Empty lb | Ordinary HP / structural AC | Benefit slot | Ordinary use |
|---|---:|---:|---|---|---|
| Backpack | 2 | 5 | 10 / 15 | back-cargo | 30 lb / 1 ft³ contents |

| Container | Compartments | Interior per compartment, inches | Opening, inches | Exterior, inches | Each compartment limit |
|---|---:|---|---|---|---|
| Backpack | 1 | 18 × 12 × 8 | 12 × 8 | 20 × 14 × 10 | 30 lb / 1 ft³ |

**Exact source component occurrences:**

| # | Component | Quantity | Tier | Role / consumed | Unit lb | Unit gp | Required properties |
|---|---|---:|---:|---|---:|---:|---|
| 0 | Leather strips | 4 | 3 | substrate / true | 0.25 | 25 | substrate |
| 1 | Rivets | 4 | 3 | binder / true | 0.1 | 25 | binder |
| 2 | Buckles | 2 | 3 | ingredient / true | 0.1 | 25 |  |
| 3 | Cured leather | 2 | 3 | substrate / true | 0.25 | 25 | substrate |
| 4 | animated vine | 1 | 2 | material / true | 0.68 | 23 | specialized |

All listed inputs are additional consumed process/reinforcement materials. Finished empty mass is the actual body mass; process waste supplies no second body or automatically valuable salvage. No source component is a catalyst; even Masterwork returns zero catalyst units. Independently required tools remain tools.

**Work and access:** DEX with actual Leatherworker's-tools proficiency as the shared framework permits; Tannery Bench; Leatherworker's tools, Awl, Cutting knife. Maximum assistants 0. Source fieldCraftable=false; preserved timeMode=workshop; the false field flag controls. Source time: 3 days; source activeWorkHours=24. Operational required active time 24 hours. First stable phase 8 hours, included in total. Eligible Forge Dwarf: 1080 minutes, first phase 480 minutes. Stabilize only components actually incorporated in the completed first phase; other lots keep their clocks.

**Progression:** exact source trivialAtSkillLevel=10; use this threshold rather than regenerating level+5. Actual formula access: {"sources":["guild trainer","faction vendor","uncommon dungeon book","reverse engineering"],"minimumResearchHours":0,"requiresFormula":true,"formulaConsumed":false}. The framework controls trade eligibility, proficiency once, assistant qualifications, Watches, rest, interruptions, XP and mishaps.

**Output:** Standard 1; Exceptional yield 1; Masterwork yield 1; or 1 units with strongest noncompounding structural improvement 25%/50%. Flawed: one persistent half-maximum flaw applied after size/grade and strongest improvement, minimum1; preserve damage deficit and possible Broken output. Failed/Mishap transforms none; source input recovery/loss remains separate. Quality changes no capacity, relief, check bonus, AC, resistance or grade.

**Repair:** trained Leatherworker's tools, Tannery Bench, Awl and Cutting knife. Functional HP≥1: DEX + applicable proficiency DC10; max(1 hour, recorded max HP/10); materials 25% mundane base reference. Broken HP0: DEX + applicable proficiency DC16; max(8 hours, recorded max HP/10); materials 25% finished per-item reference; recoverable original main body required. Binary success restores recorded maximum, including the persistent flaw; failure consumes materials and time. No formula or original trade-level eligibility required or granted, quality roll, XP, catalyst return or Forge Dwarf creation reduction. No lost contents return.

**Finished ordinary Standard reference examples:** Backpack = 498 gp. Source process share 496 gp/unit plus actual undamaged mundane size/grade body reference. Retain exact precision until the actual transaction; no automatic buyer, quality premium, artifact multiplier or mundane-table magic buyback.

**Preserved tags:** Flora. Tags, current/legacy names, donors and whole-creature metadata add no powers or availability.

**Public source binding:** V5 ¶1660, ¶1661, ¶1662, ¶1663, ¶1664, ¶1665. The original effect remains verbatim; any AC overlay above is separate.

**Preserved inactive legacy/metadata:** {"legacyName": "Hardened Backpack", "legacyEffect": "Bonus to multiple skills"}.

## recipe-298 — Masterwork Verdant Gloves of Animated Vine

**REVIEWED — authored operational PLAYTEST.** public; Leatherworking level 7; tier 4; Uncommon; DC 16. Standard quantity 1; source Standard batch reference 1375 gp.

**Preserved effect:** Creates fitted gloves granting +1 to a related mobility or handling check.

**Operational effect:** One output transforms one complete matched pair, retaining its physical identity and latest lawful completion damage state. Functional means at least 1 current structural HP; the singleton Flawed result can emerge Broken with a dormant imprint. While complete, functional, unsuppressed, unmelded and actually worn in its handwear-pair benefit slot, receive +1 only on these actual checks: STR (Athletics) for climbing with actual handholds or rope grip; STR (Athletics) or DEX to retain, lower or position noncreature cargo by hand; DEX for ordinary nonlocking ties, straps, clasps or a jammed small object. The source armorBonus of 0 creates no recipe AC candidate and does not cancel a Crude suit penalty. No damage resistance or environmental immunity is granted. Only the strongest qualifying Leatherworking task bonus applies once per actual check. No routine check is invented; ordinary actions, hands, access, proficiency and competing slot requirements still apply. Broken stops positive functions; suppression stops recipe magic, not physical capacity or workmanship. Use the complete shared guide for custody, melding, quality, repair and value.

**Legal mundane bases:** Gloves pair. One model, actual fit and legal grade for the whole batch. Buy, own or legitimately commission complete bodies; no stock-construction recipe is implied.

**Physical reserve:** 1 complete, nonmagical, non-Broken bases in a stable physical-ID order before work; containers empty. No existing imprint. Missing/Broken/committed bases pause before the roll; repair or replace at the same position. Transform the first resolved N, using latest lawful completion HP. Keep unused bodies in their actual state outside ingredient recovery.

| Mundane body | Price gp | Empty lb | Ordinary HP / structural AC | Benefit slot | Ordinary use |
|---|---:|---:|---|---|---|
| Gloves pair | 1 | 0.5 | 5 / 15 | handwear-pair | one matched pair |

| Container | Compartments | Interior per compartment, inches | Opening, inches | Exterior, inches | Each compartment limit |
|---|---:|---|---|---|---|

**Exact source component occurrences:**

| # | Component | Quantity | Tier | Role / consumed | Unit lb | Unit gp | Required properties |
|---|---|---:|---:|---|---:|---:|---|
| 0 | Lining | 5 | 4 | reinforcement / true | 0.25 | 75 | reinforcement |
| 1 | Leather strips | 3 | 4 | substrate / true | 0.25 | 75 | substrate |
| 2 | Padding | 2 | 4 | reinforcement / true | 0.25 | 75 | reinforcement |
| 3 | Cured leather | 3 | 4 | substrate / true | 0.25 | 75 | substrate |
| 4 | animated vine | 1 | 2 | material / true | 0.68 | 23 | specialized |

All listed inputs are additional consumed process/reinforcement materials. Finished empty mass is the actual body mass; process waste supplies no second body or automatically valuable salvage. No source component is a catalyst; even Masterwork returns zero catalyst units. Independently required tools remain tools.

**Work and access:** DEX with actual Leatherworker's-tools proficiency as the shared framework permits; Tannery Bench; Leatherworker's tools, Awl, Cutting knife. Maximum assistants 0. Source fieldCraftable=false; preserved timeMode=expedition; the false field flag controls. Source time: 1 day; source activeWorkHours=8. Operational required active time 8 hours. First stable phase 8 hours, included in total. Eligible Forge Dwarf: 360 minutes, first phase 360 minutes. Stabilize only components actually incorporated in the completed first phase; other lots keep their clocks.

**Progression:** exact source trivialAtSkillLevel=12; use this threshold rather than regenerating level+5. Actual formula access: {"sources":["guild trainer","faction vendor","uncommon dungeon book","reverse engineering"],"minimumResearchHours":0,"requiresFormula":true,"formulaConsumed":false}. The framework controls trade eligibility, proficiency once, assistant qualifications, Watches, rest, interruptions, XP and mishaps.

**Output:** Standard 1; Exceptional yield 1; Masterwork yield 1; or 1 units with strongest noncompounding structural improvement 25%/50%. Flawed: one persistent half-maximum flaw applied after size/grade and strongest improvement, minimum1; preserve damage deficit and possible Broken output. Failed/Mishap transforms none; source input recovery/loss remains separate. Quality changes no capacity, relief, check bonus, AC, resistance or grade.

**Repair:** trained Leatherworker's tools, Tannery Bench, Awl and Cutting knife. Functional HP≥1: DEX + applicable proficiency DC10; max(1 hour, recorded max HP/10); materials 25% mundane base reference. Broken HP0: DEX + applicable proficiency DC16; max(8 hours, recorded max HP/10); materials 25% finished per-item reference; recoverable original main body required with both original pair members. Binary success restores recorded maximum, including the persistent flaw; failure consumes materials and time. No formula or original trade-level eligibility required or granted, quality roll, XP, catalyst return or Forge Dwarf creation reduction. No lost contents return.

**Finished ordinary Standard reference examples:** Gloves pair = 1376 gp. Source process share 1375 gp/unit plus actual undamaged mundane size/grade body reference. Retain exact precision until the actual transaction; no automatic buyer, quality premium, artifact multiplier or mundane-table magic buyback.

**Preserved tags:** Flora. Tags, current/legacy names, donors and whole-creature metadata add no powers or availability.

**Public source binding:** V5 ¶1702, ¶1703, ¶1704, ¶1705, ¶1706, ¶1707. The original effect remains verbatim; any AC overlay above is separate.

**Preserved inactive legacy/metadata:** {"legacyName": "Gloves of Hardened Superiorness", "legacyEffect": "Daily spell-like ability"}.

## recipe-299 — Superior Gale Gloves of Quetzalcoatlus Bone

**REVIEWED — authored operational PLAYTEST.** public; Leatherworking level 6; tier 3; Uncommon; DC 14. Standard quantity 1; source Standard batch reference 327 gp.

**Preserved effect:** Creates fitted gloves granting +1 to a related mobility or handling check.

**Operational effect:** One output transforms one complete matched pair, retaining its physical identity and latest lawful completion damage state. Functional means at least 1 current structural HP; the singleton Flawed result can emerge Broken with a dormant imprint. While complete, functional, unsuppressed, unmelded and actually worn in its handwear-pair benefit slot, receive +1 only on these actual checks: STR (Athletics) for climbing with actual handholds or rope grip; STR (Athletics) or DEX to retain, lower or position noncreature cargo by hand; DEX for ordinary nonlocking ties, straps, clasps or a jammed small object. The source armorBonus of 0 creates no recipe AC candidate and does not cancel a Crude suit penalty. No damage resistance or environmental immunity is granted. Only the strongest qualifying Leatherworking task bonus applies once per actual check. No routine check is invented; ordinary actions, hands, access, proficiency and competing slot requirements still apply. Broken stops positive functions; suppression stops recipe magic, not physical capacity or workmanship. Use the complete shared guide for custody, melding, quality, repair and value.

**Legal mundane bases:** Gloves pair. One model, actual fit and legal grade for the whole batch. Buy, own or legitimately commission complete bodies; no stock-construction recipe is implied.

**Physical reserve:** 1 complete, nonmagical, non-Broken bases in a stable physical-ID order before work; containers empty. No existing imprint. Missing/Broken/committed bases pause before the roll; repair or replace at the same position. Transform the first resolved N, using latest lawful completion HP. Keep unused bodies in their actual state outside ingredient recovery.

| Mundane body | Price gp | Empty lb | Ordinary HP / structural AC | Benefit slot | Ordinary use |
|---|---:|---:|---|---|---|
| Gloves pair | 1 | 0.5 | 5 / 15 | handwear-pair | one matched pair |

| Container | Compartments | Interior per compartment, inches | Opening, inches | Exterior, inches | Each compartment limit |
|---|---:|---|---|---|---|

**Exact source component occurrences:**

| # | Component | Quantity | Tier | Role / consumed | Unit lb | Unit gp | Required properties |
|---|---|---:|---:|---|---:|---:|---|
| 0 | Reinforced stitching | 1 | 3 | binder / true | 0.1 | 25 | binder |
| 1 | Lining | 3 | 3 | reinforcement / true | 0.25 | 25 | reinforcement |
| 2 | Quetzalcoatlus bone shard | 1 | 2 | material / true | 0.59 | 16 | rigid, structural |

All listed inputs are additional consumed process/reinforcement materials. Finished empty mass is the actual body mass; process waste supplies no second body or automatically valuable salvage. No source component is a catalyst; even Masterwork returns zero catalyst units. Independently required tools remain tools.

**Work and access:** DEX with actual Leatherworker's-tools proficiency as the shared framework permits; Tannery Bench; Leatherworker's tools, Awl, Cutting knife. Maximum assistants 0. Source fieldCraftable=false; preserved timeMode=expedition; the false field flag controls. Source time: 1 day; source activeWorkHours=8. Operational required active time 8 hours. First stable phase 8 hours, included in total. Eligible Forge Dwarf: 360 minutes, first phase 360 minutes. Stabilize only components actually incorporated in the completed first phase; other lots keep their clocks.

**Progression:** exact source trivialAtSkillLevel=11; use this threshold rather than regenerating level+5. Actual formula access: {"sources":["guild trainer","faction vendor","uncommon dungeon book","reverse engineering"],"minimumResearchHours":0,"requiresFormula":true,"formulaConsumed":false}. The framework controls trade eligibility, proficiency once, assistant qualifications, Watches, rest, interruptions, XP and mishaps.

**Output:** Standard 1; Exceptional yield 1; Masterwork yield 1; or 1 units with strongest noncompounding structural improvement 25%/50%. Flawed: one persistent half-maximum flaw applied after size/grade and strongest improvement, minimum1; preserve damage deficit and possible Broken output. Failed/Mishap transforms none; source input recovery/loss remains separate. Quality changes no capacity, relief, check bonus, AC, resistance or grade.

**Repair:** trained Leatherworker's tools, Tannery Bench, Awl and Cutting knife. Functional HP≥1: DEX + applicable proficiency DC10; max(1 hour, recorded max HP/10); materials 25% mundane base reference. Broken HP0: DEX + applicable proficiency DC14; max(8 hours, recorded max HP/10); materials 25% finished per-item reference; recoverable original main body required with both original pair members. Binary success restores recorded maximum, including the persistent flaw; failure consumes materials and time. No formula or original trade-level eligibility required or granted, quality roll, XP, catalyst return or Forge Dwarf creation reduction. No lost contents return.

**Finished ordinary Standard reference examples:** Gloves pair = 328 gp. Source process share 327 gp/unit plus actual undamaged mundane size/grade body reference. Retain exact precision until the actual transaction; no automatic buyer, quality premium, artifact multiplier or mundane-table magic buyback.

**Preserved tags:** Air. Tags, current/legacy names, donors and whole-creature metadata add no powers or availability.

**Public source binding:** V5 ¶1667, ¶1668, ¶1669, ¶1670, ¶1671, ¶1672. The original effect remains verbatim; any AC overlay above is separate.

**Preserved inactive legacy/metadata:** {"legacyName": "Reinforced Gloves", "legacyEffect": "Bonus to multiple skills"}.

## recipe-300 — Masterwork Tide Belt of Bronze Dragon Bone

**REVIEWED — authored operational PLAYTEST.** public; Leatherworking level 7; tier 4; Uncommon; DC 13. Standard quantity 1; source Standard batch reference 1397 gp.

**Preserved effect:** Creates a reinforced belt carrying 20 pounds without counting against normal encumbrance; grants +1 to checks to secure or retrieve its contents.

**Operational effect:** One output transforms one complete mundane body, retaining its physical identity and latest lawful completion damage state. Functional means at least 1 current structural HP; the singleton Flawed result can emerge Broken with a dormant imprint. While functional, unsuppressed, unmelded, properly fitted and worn or directly held in its recorded waist-cargo relief position, cover up to 20 lb of eligible contents in stable loading order. Physical capacity remains 20 lb and 2/3 ft³, subject to its actual opening, shape and compartment limits. Its own body is not relieved. For each covered record, subtract covered pounds from the direct bearer's pound-carrying comparison and at most min(canonical Load, covered pounds/10) from Inventory Load; preserve actual mass and canonical Load. Enclosed enchanted containers are inactive; ordinary inner bodies and descendants count once. External lashings do not become contents. The actual operator receives +1 on a qualifying handling check: Actual difficult cargo handling to secure its ordinary closure/retainers or retrieve through an unlocked closure, jam, tangle or other physical difficulty: DEX for dexterous work or STR (Athletics) for forceful handling of noncreature cargo. This handling benefit needs accessible functional unsuppressed fittings, not a relief slot, and can apply on a table or for an ally. Only the strongest qualifying Leatherworking task bonus applies once per actual check. No routine check is invented; ordinary actions, hands, access, proficiency and competing slot requirements still apply. Broken stops positive functions; suppression stops recipe magic, not physical capacity or workmanship. Use the complete shared guide for custody, melding, quality, repair and value.

**Legal mundane bases:** Cargo belt 20 lb. One model, actual fit and legal grade for the whole batch. Buy, own or legitimately commission complete bodies; no stock-construction recipe is implied.

**Physical reserve:** 1 complete, nonmagical, non-Broken bases in a stable physical-ID order before work; containers empty. No existing imprint. Missing/Broken/committed bases pause before the roll; repair or replace at the same position. Transform the first resolved N, using latest lawful completion HP. Keep unused bodies in their actual state outside ingredient recovery.

| Mundane body | Price gp | Empty lb | Ordinary HP / structural AC | Benefit slot | Ordinary use |
|---|---:|---:|---|---|---|
| Cargo belt 20 lb | 4 | 4 | 5 / 15 | waist-cargo | 20 lb / 2/3 ft³ contents |

| Container | Compartments | Interior per compartment, inches | Opening, inches | Exterior, inches | Each compartment limit |
|---|---:|---|---|---|---|
| Cargo belt 20 lb | 2 | 12 × 8 × 6 | 12 × 6 | 13 × 9 × 7 per pocket | 10 lb / 1/3 ft³ |

**Exact source component occurrences:**

| # | Component | Quantity | Tier | Role / consumed | Unit lb | Unit gp | Required properties |
|---|---|---:|---:|---|---:|---:|---|
| 0 | Lining | 3 | 4 | reinforcement / true | 0.25 | 75 | reinforcement |
| 1 | Waterproofing oil | 2 | 4 | solvent / true | 0.5 | 75 | solvent |
| 2 | Leather strips | 4 | 4 | substrate / true | 0.25 | 75 | substrate |
| 3 | Tanned hide | 4 | 4 | ingredient / true | 0.25 | 75 |  |
| 4 | bronze dragon bone | 1 | 2 | material / true | 0.16 | 18 | draconic, rigid, structural, water |

All listed inputs are additional consumed process/reinforcement materials. Finished empty mass is the actual body mass; process waste supplies no second body or automatically valuable salvage. No source component is a catalyst; even Masterwork returns zero catalyst units. Independently required tools remain tools.

**Work and access:** DEX with actual Leatherworker's-tools proficiency as the shared framework permits; Tannery Bench; Leatherworker's tools, Awl, Cutting knife. Maximum assistants 0. Source fieldCraftable=false; preserved timeMode=workshop; the false field flag controls. Source time: 2 days; source activeWorkHours=16. Operational required active time 16 hours. First stable phase 8 hours, included in total. Eligible Forge Dwarf: 720 minutes, first phase 480 minutes. Stabilize only components actually incorporated in the completed first phase; other lots keep their clocks.

**Progression:** exact source trivialAtSkillLevel=12; use this threshold rather than regenerating level+5. Actual formula access: {"sources":["guild trainer","faction vendor","uncommon dungeon book","reverse engineering"],"minimumResearchHours":0,"requiresFormula":true,"formulaConsumed":false}. The framework controls trade eligibility, proficiency once, assistant qualifications, Watches, rest, interruptions, XP and mishaps.

**Output:** Standard 1; Exceptional yield 1; Masterwork yield 1; or 1 units with strongest noncompounding structural improvement 25%/50%. Flawed: one persistent half-maximum flaw applied after size/grade and strongest improvement, minimum1; preserve damage deficit and possible Broken output. Failed/Mishap transforms none; source input recovery/loss remains separate. Quality changes no capacity, relief, check bonus, AC, resistance or grade.

**Repair:** trained Leatherworker's tools, Tannery Bench, Awl and Cutting knife. Functional HP≥1: DEX + applicable proficiency DC10; max(1 hour, recorded max HP/10); materials 25% mundane base reference. Broken HP0: DEX + applicable proficiency DC13; max(8 hours, recorded max HP/10); materials 25% finished per-item reference; recoverable original main body required. Binary success restores recorded maximum, including the persistent flaw; failure consumes materials and time. No formula or original trade-level eligibility required or granted, quality roll, XP, catalyst return or Forge Dwarf creation reduction. No lost contents return.

**Finished ordinary Standard reference examples:** Cargo belt 20 lb = 1401 gp. Source process share 1397 gp/unit plus actual undamaged mundane size/grade body reference. Retain exact precision until the actual transaction; no automatic buyer, quality premium, artifact multiplier or mundane-table magic buyback.

**Preserved tags:** Water. Tags, current/legacy names, donors and whole-creature metadata add no powers or availability.

**Public source binding:** V5 ¶1688, ¶1689, ¶1690, ¶1691, ¶1692, ¶1693. The original effect remains verbatim; any AC overlay above is separate.

**Preserved inactive legacy/metadata:** {"legacyName": "Improved Tanned Belt", "legacyEffect": "Moderate magical effect"}.

## recipe-301 — Masterwork Caustic Armor of Black Dragon Bone

**REVIEWED — authored operational PLAYTEST.** public; Leatherworking level 7; tier 4; Uncommon; DC 13. Standard quantity 1; source Standard batch reference 601 gp.

**Preserved effect:** Creates fitted armor granting +1 to a related mobility or handling check.

**Operational effect:** One output transforms one complete mundane body, retaining its physical identity and latest lawful completion damage state. Functional means at least 1 current structural HP; the singleton Flawed result can emerge Broken with a dormant imprint. While complete, functional, unsuppressed, unmelded and actually worn in its armor-suit benefit slot, receive +1 only on these actual checks: STR (Athletics) for actual climbing; DEX (Acrobatics) for controlled movement through a cramped or obstructed passage when a check is actually required. The source armorBonus of 0 creates no recipe AC candidate and does not cancel a Crude suit penalty. No damage resistance or environmental immunity is granted. Only the strongest qualifying Leatherworking task bonus applies once per actual check. No routine check is invented; ordinary actions, hands, access, proficiency and competing slot requirements still apply. Broken stops positive functions; suppression stops recipe magic, not physical capacity or workmanship. Use the complete shared guide for custody, melding, quality, repair and value.

**Legal mundane bases:** Leather, Studded leather, Hide. One model, actual fit and legal grade for the whole batch. Buy, own or legitimately commission complete bodies; no stock-construction recipe is implied.

**Physical reserve:** 1 complete, nonmagical, non-Broken bases in a stable physical-ID order before work; containers empty. No existing imprint. Missing/Broken/committed bases pause before the roll; repair or replace at the same position. Transform the first resolved N, using latest lawful completion HP. Keep unused bodies in their actual state outside ingredient recovery.

| Mundane body | Price gp | Empty lb | Ordinary HP / structural AC | Benefit slot | Ordinary use |
|---|---:|---:|---|---|---|
| Leather | 10 | 10 | 10 / 15 | armor-suit | 11 + Dex modifier |
| Studded leather | 45 | 13 | 10 / 15 | armor-suit | 12 + Dex modifier |
| Hide | 10 | 12 | 15 / 15 | armor-suit | 12 + Dex modifier (max 2) |

| Container | Compartments | Interior per compartment, inches | Opening, inches | Exterior, inches | Each compartment limit |
|---|---:|---|---|---|---|

**Exact source component occurrences:**

| # | Component | Quantity | Tier | Role / consumed | Unit lb | Unit gp | Required properties |
|---|---|---:|---:|---|---:|---:|---|
| 0 | Cured leather | 3 | 4 | substrate / true | 0.25 | 75 | substrate |
| 1 | Leather strips | 2 | 4 | substrate / true | 0.25 | 75 | substrate |
| 2 | black dragon bone | 1 | 2 | material / true | 0.48 | 29 | acid, draconic, rigid, structural |

All listed inputs are additional consumed process/reinforcement materials. Finished empty mass is the actual body mass; process waste supplies no second body or automatically valuable salvage. No source component is a catalyst; even Masterwork returns zero catalyst units. Independently required tools remain tools.

**Work and access:** DEX with actual Leatherworker's-tools proficiency as the shared framework permits; Tannery Bench; Leatherworker's tools, Awl, Cutting knife. Maximum assistants 0. Source fieldCraftable=false; preserved timeMode=workshop; the false field flag controls. Source time: 2 days; source activeWorkHours=16. Operational required active time 16 hours. First stable phase 8 hours, included in total. Eligible Forge Dwarf: 720 minutes, first phase 480 minutes. Stabilize only components actually incorporated in the completed first phase; other lots keep their clocks.

**Progression:** exact source trivialAtSkillLevel=12; use this threshold rather than regenerating level+5. Actual formula access: {"sources":["guild trainer","faction vendor","uncommon dungeon book","reverse engineering"],"minimumResearchHours":0,"requiresFormula":true,"formulaConsumed":false}. The framework controls trade eligibility, proficiency once, assistant qualifications, Watches, rest, interruptions, XP and mishaps.

**Output:** Standard 1; Exceptional yield 1; Masterwork yield 1; or 1 units with strongest noncompounding structural improvement 25%/50%. Flawed: one persistent half-maximum flaw applied after size/grade and strongest improvement, minimum1; preserve damage deficit and possible Broken output. Failed/Mishap transforms none; source input recovery/loss remains separate. Quality changes no capacity, relief, check bonus, AC, resistance or grade.

**Repair:** trained Leatherworker's tools, Tannery Bench, Awl and Cutting knife. Functional HP≥1: DEX + applicable proficiency DC10; max(1 hour, recorded max HP/10); materials 25% mundane base reference. Broken HP0: DEX + applicable proficiency DC13; max(8 hours, recorded max HP/10); materials 25% finished per-item reference; recoverable original main body required. Binary success restores recorded maximum, including the persistent flaw; failure consumes materials and time. No formula or original trade-level eligibility required or granted, quality roll, XP, catalyst return or Forge Dwarf creation reduction. No lost contents return.

**Finished ordinary Standard reference examples:** Leather = 611 gp; Studded leather = 646 gp; Hide = 611 gp. Source process share 601 gp/unit plus actual undamaged mundane size/grade body reference. Retain exact precision until the actual transaction; no automatic buyer, quality premium, artifact multiplier or mundane-table magic buyback.

**Preserved tags:** Acid. Tags, current/legacy names, donors and whole-creature metadata add no powers or availability.

**Public source binding:** V5 ¶1681, ¶1682, ¶1683, ¶1684, ¶1685, ¶1686. The original effect remains verbatim; any AC overlay above is separate.

**Preserved inactive legacy/metadata:** {"legacyName": "Superior Tanned Leather Armor", "legacyEffect": "Bonus to multiple skills"}.

## recipe-302 — Superior Tide Pouch of Sea Bone

**REVIEWED — authored operational PLAYTEST.** public; Leatherworking level 5; tier 3; Uncommon; DC 15. Standard quantity 1; source Standard batch reference 397 gp.

**Preserved effect:** Creates a reinforced pouch carrying 20 pounds without counting against normal encumbrance; grants +1 to checks to secure or retrieve its contents.

**Operational effect:** One output transforms one complete mundane body, retaining its physical identity and latest lawful completion damage state. Functional means at least 1 current structural HP; the singleton Flawed result can emerge Broken with a dormant imprint. While functional, unsuppressed, unmelded, properly fitted and worn or directly held in its recorded pouch-position relief position, cover up to 20 lb of eligible contents in stable loading order. Physical capacity remains 20 lb and 2/3 ft³, subject to its actual opening, shape and compartment limits. Its own body is not relieved. For each covered record, subtract covered pounds from the direct bearer's pound-carrying comparison and at most min(canonical Load, covered pounds/10) from Inventory Load; preserve actual mass and canonical Load. Enclosed enchanted containers are inactive; ordinary inner bodies and descendants count once. External lashings do not become contents. The actual operator receives +1 on a qualifying handling check: Actual difficult cargo handling to secure its ordinary closure/retainers or retrieve through an unlocked closure, jam, tangle or other physical difficulty: DEX for dexterous work or STR (Athletics) for forceful handling of noncreature cargo. This handling benefit needs accessible functional unsuppressed fittings, not a relief slot, and can apply on a table or for an ally. Only the strongest qualifying Leatherworking task bonus applies once per actual check. No routine check is invented; ordinary actions, hands, access, proficiency and competing slot requirements still apply. Broken stops positive functions; suppression stops recipe magic, not physical capacity or workmanship. Use the complete shared guide for custody, melding, quality, repair and value.

**Legal mundane bases:** Cargo pouch 20 lb. One model, actual fit and legal grade for the whole batch. Buy, own or legitimately commission complete bodies; no stock-construction recipe is implied.

**Physical reserve:** 1 complete, nonmagical, non-Broken bases in a stable physical-ID order before work; containers empty. No existing imprint. Missing/Broken/committed bases pause before the roll; repair or replace at the same position. Transform the first resolved N, using latest lawful completion HP. Keep unused bodies in their actual state outside ingredient recovery.

| Mundane body | Price gp | Empty lb | Ordinary HP / structural AC | Benefit slot | Ordinary use |
|---|---:|---:|---|---|---|
| Cargo pouch 20 lb | 2 | 3 | 5 / 15 | pouch-position | 20 lb / 2/3 ft³ contents |

| Container | Compartments | Interior per compartment, inches | Opening, inches | Exterior, inches | Each compartment limit |
|---|---:|---|---|---|---|
| Cargo pouch 20 lb | 1 | 12 × 8 × 12 | 12 × 12 | 13 × 9 × 13 | 20 lb / 2/3 ft³ |

**Exact source component occurrences:**

| # | Component | Quantity | Tier | Role / consumed | Unit lb | Unit gp | Required properties |
|---|---|---:|---:|---|---:|---:|---|
| 0 | Padding | 5 | 3 | reinforcement / true | 0.25 | 25 | reinforcement |
| 1 | Buckles | 5 | 3 | ingredient / true | 0.1 | 25 |  |
| 2 | Sea bone shard | 1 | 2 | material / true | 0.39 | 29 | rigid, structural, water |

All listed inputs are additional consumed process/reinforcement materials. Finished empty mass is the actual body mass; process waste supplies no second body or automatically valuable salvage. No source component is a catalyst; even Masterwork returns zero catalyst units. Independently required tools remain tools.

**Work and access:** DEX with actual Leatherworker's-tools proficiency as the shared framework permits; Tannery Bench; Leatherworker's tools, Awl, Cutting knife. Maximum assistants 0. Source fieldCraftable=false; preserved timeMode=expedition; the false field flag controls. Source time: 1 day; source activeWorkHours=8. Operational required active time 8 hours. First stable phase 8 hours, included in total. Eligible Forge Dwarf: 360 minutes, first phase 360 minutes. Stabilize only components actually incorporated in the completed first phase; other lots keep their clocks.

**Progression:** exact source trivialAtSkillLevel=10; use this threshold rather than regenerating level+5. Actual formula access: {"sources":["guild trainer","faction vendor","uncommon dungeon book","reverse engineering"],"minimumResearchHours":0,"requiresFormula":true,"formulaConsumed":false}. The framework controls trade eligibility, proficiency once, assistant qualifications, Watches, rest, interruptions, XP and mishaps.

**Output:** Standard 1; Exceptional yield 1; Masterwork yield 1; or 1 units with strongest noncompounding structural improvement 25%/50%. Flawed: one persistent half-maximum flaw applied after size/grade and strongest improvement, minimum1; preserve damage deficit and possible Broken output. Failed/Mishap transforms none; source input recovery/loss remains separate. Quality changes no capacity, relief, check bonus, AC, resistance or grade.

**Repair:** trained Leatherworker's tools, Tannery Bench, Awl and Cutting knife. Functional HP≥1: DEX + applicable proficiency DC10; max(1 hour, recorded max HP/10); materials 25% mundane base reference. Broken HP0: DEX + applicable proficiency DC15; max(8 hours, recorded max HP/10); materials 25% finished per-item reference; recoverable original main body required. Binary success restores recorded maximum, including the persistent flaw; failure consumes materials and time. No formula or original trade-level eligibility required or granted, quality roll, XP, catalyst return or Forge Dwarf creation reduction. No lost contents return.

**Finished ordinary Standard reference examples:** Cargo pouch 20 lb = 399 gp. Source process share 397 gp/unit plus actual undamaged mundane size/grade body reference. Retain exact precision until the actual transaction; no automatic buyer, quality premium, artifact multiplier or mundane-table magic buyback.

**Preserved tags:** Water. Tags, current/legacy names, donors and whole-creature metadata add no powers or availability.

**Public source binding:** V5 ¶1646, ¶1647, ¶1648, ¶1649, ¶1650, ¶1651. The original effect remains verbatim; any AC overlay above is separate.

**Preserved inactive legacy/metadata:** {"legacyName": "Pouch of Tanned Enhancedness", "legacyEffect": "Bonus to multiple skills"}.

## recipe-303 — Masterwork Vital Backpack of Alien Chitin

**REVIEWED — authored operational PLAYTEST.** public; Leatherworking level 8; tier 4; Uncommon; DC 17. Standard quantity 1; source Standard batch reference 808 gp.

**Preserved effect:** Creates a reinforced backpack carrying 20 pounds without counting against normal encumbrance; grants +1 to checks to secure or retrieve its contents.

**Operational effect:** One output transforms one complete mundane body, retaining its physical identity and latest lawful completion damage state. Functional means at least 1 current structural HP; the singleton Flawed result can emerge Broken with a dormant imprint. While functional, unsuppressed, unmelded, properly fitted and worn or directly held in its recorded back-cargo relief position, cover up to 20 lb of eligible contents in stable loading order. Physical capacity remains 30 lb and 1 ft³, subject to its actual opening, shape and compartment limits. Its own body is not relieved. For each covered record, subtract covered pounds from the direct bearer's pound-carrying comparison and at most min(canonical Load, covered pounds/10) from Inventory Load; preserve actual mass and canonical Load. Enclosed enchanted containers are inactive; ordinary inner bodies and descendants count once. External lashings do not become contents. The actual operator receives +1 on a qualifying handling check: Actual difficult cargo handling to secure its ordinary closure/retainers or retrieve through an unlocked closure, jam, tangle or other physical difficulty: DEX for dexterous work or STR (Athletics) for forceful handling of noncreature cargo. This handling benefit needs accessible functional unsuppressed fittings, not a relief slot, and can apply on a table or for an ally. Only the strongest qualifying Leatherworking task bonus applies once per actual check. No routine check is invented; ordinary actions, hands, access, proficiency and competing slot requirements still apply. Broken stops positive functions; suppression stops recipe magic, not physical capacity or workmanship. Use the complete shared guide for custody, melding, quality, repair and value.

**Legal mundane bases:** Backpack. One model, actual fit and legal grade for the whole batch. Buy, own or legitimately commission complete bodies; no stock-construction recipe is implied.

**Physical reserve:** 1 complete, nonmagical, non-Broken bases in a stable physical-ID order before work; containers empty. No existing imprint. Missing/Broken/committed bases pause before the roll; repair or replace at the same position. Transform the first resolved N, using latest lawful completion HP. Keep unused bodies in their actual state outside ingredient recovery.

| Mundane body | Price gp | Empty lb | Ordinary HP / structural AC | Benefit slot | Ordinary use |
|---|---:|---:|---|---|---|
| Backpack | 2 | 5 | 10 / 15 | back-cargo | 30 lb / 1 ft³ contents |

| Container | Compartments | Interior per compartment, inches | Opening, inches | Exterior, inches | Each compartment limit |
|---|---:|---|---|---|---|
| Backpack | 1 | 18 × 12 × 8 | 12 × 8 | 20 × 14 × 10 | 30 lb / 1 ft³ |

**Exact source component occurrences:**

| # | Component | Quantity | Tier | Role / consumed | Unit lb | Unit gp | Required properties |
|---|---|---:|---:|---|---:|---:|---|
| 0 | Leather strips | 3 | 4 | substrate / true | 0.25 | 75 | substrate |
| 1 | Cured leather | 2 | 4 | substrate / true | 0.25 | 75 | substrate |
| 2 | Reinforced stitching | 2 | 4 | binder / true | 0.1 | 75 | binder |
| 3 | alien chitin | 1 | 2 | material / true | 0.18 | 50 | protective, rigid |

All listed inputs are additional consumed process/reinforcement materials. Finished empty mass is the actual body mass; process waste supplies no second body or automatically valuable salvage. No source component is a catalyst; even Masterwork returns zero catalyst units. Independently required tools remain tools.

**Work and access:** DEX with actual Leatherworker's-tools proficiency as the shared framework permits; Tannery Bench; Leatherworker's tools, Awl, Cutting knife. Maximum assistants 0. Source fieldCraftable=false; preserved timeMode=expedition; the false field flag controls. Source time: 1 day; source activeWorkHours=8. Operational required active time 8 hours. First stable phase 8 hours, included in total. Eligible Forge Dwarf: 360 minutes, first phase 360 minutes. Stabilize only components actually incorporated in the completed first phase; other lots keep their clocks.

**Progression:** exact source trivialAtSkillLevel=13; use this threshold rather than regenerating level+5. Actual formula access: {"sources":["guild trainer","faction vendor","uncommon dungeon book","reverse engineering"],"minimumResearchHours":0,"requiresFormula":true,"formulaConsumed":false}. The framework controls trade eligibility, proficiency once, assistant qualifications, Watches, rest, interruptions, XP and mishaps.

**Output:** Standard 1; Exceptional yield 1; Masterwork yield 1; or 1 units with strongest noncompounding structural improvement 25%/50%. Flawed: one persistent half-maximum flaw applied after size/grade and strongest improvement, minimum1; preserve damage deficit and possible Broken output. Failed/Mishap transforms none; source input recovery/loss remains separate. Quality changes no capacity, relief, check bonus, AC, resistance or grade.

**Repair:** trained Leatherworker's tools, Tannery Bench, Awl and Cutting knife. Functional HP≥1: DEX + applicable proficiency DC10; max(1 hour, recorded max HP/10); materials 25% mundane base reference. Broken HP0: DEX + applicable proficiency DC17; max(8 hours, recorded max HP/10); materials 25% finished per-item reference; recoverable original main body required. Binary success restores recorded maximum, including the persistent flaw; failure consumes materials and time. No formula or original trade-level eligibility required or granted, quality roll, XP, catalyst return or Forge Dwarf creation reduction. No lost contents return.

**Finished ordinary Standard reference examples:** Backpack = 810 gp. Source process share 808 gp/unit plus actual undamaged mundane size/grade body reference. Retain exact precision until the actual transaction; no automatic buyer, quality premium, artifact multiplier or mundane-table magic buyback.

**Preserved tags:** Vitality. Tags, current/legacy names, donors and whole-creature metadata add no powers or availability.

**Public source binding:** V5 ¶1723, ¶1724, ¶1725, ¶1726, ¶1727, ¶1728. The original effect remains verbatim; any AC overlay above is separate.

**Preserved inactive legacy/metadata:** {"legacyName": "Supple Backpack", "legacyEffect": "Moderate magical effect"}.

## recipe-304 — Exalted Mindward Belt of Eldritch Fang

**REVIEWED — authored operational PLAYTEST.** public; Leatherworking level 10; tier 5; Uncommon; DC 17. Standard quantity 1; source Standard batch reference 2023 gp.

**Preserved effect:** Creates a reinforced belt carrying 20 pounds without counting against normal encumbrance; grants +1 to checks to secure or retrieve its contents.

**Operational effect:** One output transforms one complete mundane body, retaining its physical identity and latest lawful completion damage state. Functional means at least 1 current structural HP; the singleton Flawed result can emerge Broken with a dormant imprint. While functional, unsuppressed, unmelded, properly fitted and worn or directly held in its recorded waist-cargo relief position, cover up to 20 lb of eligible contents in stable loading order. Physical capacity remains 20 lb and 2/3 ft³, subject to its actual opening, shape and compartment limits. Its own body is not relieved. For each covered record, subtract covered pounds from the direct bearer's pound-carrying comparison and at most min(canonical Load, covered pounds/10) from Inventory Load; preserve actual mass and canonical Load. Enclosed enchanted containers are inactive; ordinary inner bodies and descendants count once. External lashings do not become contents. The actual operator receives +1 on a qualifying handling check: Actual difficult cargo handling to secure its ordinary closure/retainers or retrieve through an unlocked closure, jam, tangle or other physical difficulty: DEX for dexterous work or STR (Athletics) for forceful handling of noncreature cargo. This handling benefit needs accessible functional unsuppressed fittings, not a relief slot, and can apply on a table or for an ally. Only the strongest qualifying Leatherworking task bonus applies once per actual check. No routine check is invented; ordinary actions, hands, access, proficiency and competing slot requirements still apply. Broken stops positive functions; suppression stops recipe magic, not physical capacity or workmanship. Use the complete shared guide for custody, melding, quality, repair and value.

**Legal mundane bases:** Cargo belt 20 lb. One model, actual fit and legal grade for the whole batch. Buy, own or legitimately commission complete bodies; no stock-construction recipe is implied.

**Physical reserve:** 1 complete, nonmagical, non-Broken bases in a stable physical-ID order before work; containers empty. No existing imprint. Missing/Broken/committed bases pause before the roll; repair or replace at the same position. Transform the first resolved N, using latest lawful completion HP. Keep unused bodies in their actual state outside ingredient recovery.

| Mundane body | Price gp | Empty lb | Ordinary HP / structural AC | Benefit slot | Ordinary use |
|---|---:|---:|---|---|---|
| Cargo belt 20 lb | 4 | 4 | 5 / 15 | waist-cargo | 20 lb / 2/3 ft³ contents |

| Container | Compartments | Interior per compartment, inches | Opening, inches | Exterior, inches | Each compartment limit |
|---|---:|---|---|---|---|
| Cargo belt 20 lb | 2 | 12 × 8 × 6 | 12 × 6 | 13 × 9 × 7 per pocket | 10 lb / 1/3 ft³ |

**Exact source component occurrences:**

| # | Component | Quantity | Tier | Role / consumed | Unit lb | Unit gp | Required properties |
|---|---|---:|---:|---|---:|---:|---|
| 0 | Rivets | 2 | 5 | binder / true | 0.1 | 200 | binder |
| 1 | Lining | 2 | 5 | reinforcement / true | 0.25 | 200 | reinforcement |
| 2 | Reinforced stitching | 1 | 5 | binder / true | 0.1 | 200 | binder |
| 3 | eldritch fang | 1 | 4 | material / true | 0.32 | 469 | rigid, structural |

All listed inputs are additional consumed process/reinforcement materials. Finished empty mass is the actual body mass; process waste supplies no second body or automatically valuable salvage. No source component is a catalyst; even Masterwork returns zero catalyst units. Independently required tools remain tools.

**Work and access:** DEX with actual Leatherworker's-tools proficiency as the shared framework permits; Tannery Bench; Leatherworker's tools, Awl, Cutting knife. Maximum assistants 0. Source fieldCraftable=false; preserved timeMode=expedition; the false field flag controls. Source time: 1 day; source activeWorkHours=8. Operational required active time 8 hours. First stable phase 8 hours, included in total. Eligible Forge Dwarf: 360 minutes, first phase 360 minutes. Stabilize only components actually incorporated in the completed first phase; other lots keep their clocks.

**Progression:** exact source trivialAtSkillLevel=15; use this threshold rather than regenerating level+5. Actual formula access: {"sources":["rare recipe drop","specialist commission","dungeon library","successful experimentation"],"minimumResearchHours":8,"requiresFormula":true,"formulaConsumed":false}. The framework controls trade eligibility, proficiency once, assistant qualifications, Watches, rest, interruptions, XP and mishaps.

**Output:** Standard 1; Exceptional yield 1; Masterwork yield 1; or 1 units with strongest noncompounding structural improvement 25%/50%. Flawed: one persistent half-maximum flaw applied after size/grade and strongest improvement, minimum1; preserve damage deficit and possible Broken output. Failed/Mishap transforms none; source input recovery/loss remains separate. Quality changes no capacity, relief, check bonus, AC, resistance or grade.

**Repair:** trained Leatherworker's tools, Tannery Bench, Awl and Cutting knife. Functional HP≥1: DEX + applicable proficiency DC10; max(1 hour, recorded max HP/10); materials 25% mundane base reference. Broken HP0: DEX + applicable proficiency DC17; max(8 hours, recorded max HP/10); materials 25% finished per-item reference; recoverable original main body required. Binary success restores recorded maximum, including the persistent flaw; failure consumes materials and time. No formula or original trade-level eligibility required or granted, quality roll, XP, catalyst return or Forge Dwarf creation reduction. No lost contents return.

**Finished ordinary Standard reference examples:** Cargo belt 20 lb = 2027 gp. Source process share 2023 gp/unit plus actual undamaged mundane size/grade body reference. Retain exact precision until the actual transaction; no automatic buyer, quality premium, artifact multiplier or mundane-table magic buyback.

**Preserved tags:** Psychic. Tags, current/legacy names, donors and whole-creature metadata add no powers or availability.

**Public source binding:** V5 ¶1737, ¶1738, ¶1739, ¶1740, ¶1741, ¶1742. The original effect remains verbatim; any AC overlay above is separate.

**Preserved inactive legacy/metadata:** {"legacyName": "Tanned Belt", "legacyEffect": "Daily spell-like ability"}.

## recipe-305 — Exalted Venom Quiver of Green Dragonhide

**REVIEWED — authored operational PLAYTEST.** public; Leatherworking level 10; tier 5; Rare; DC 19. Standard quantity 1; source Standard batch reference 3254 gp.

**Preserved effect:** Creates a reinforced quiver carrying 30 pounds without counting against normal encumbrance; grants +2 to checks to secure or retrieve its contents.

**Operational effect:** One output transforms one complete mundane body, retaining its physical identity and latest lawful completion damage state. Functional means at least 1 current structural HP; the singleton Flawed result can emerge Broken with a dormant imprint. While functional, unsuppressed, unmelded, properly fitted and worn or directly held in its recorded quiver relief position, cover up to 30 lb of eligible contents in stable loading order. Physical capacity remains 30 lb and 1 ft³, subject to its actual opening, shape and compartment limits. Its own body is not relieved. For each covered record, subtract covered pounds from the direct bearer's pound-carrying comparison and at most min(canonical Load, covered pounds/10) from Inventory Load; preserve actual mass and canonical Load. Enclosed enchanted containers are inactive; ordinary inner bodies and descendants count once. External lashings do not become contents. The actual operator receives +2 on a qualifying handling check: Actual difficult cargo handling to secure its ordinary closure/retainers or retrieve through an unlocked closure, jam, tangle or other physical difficulty: DEX for dexterous work or STR (Athletics) for forceful handling of noncreature cargo. This handling benefit needs accessible functional unsuppressed fittings, not a relief slot, and can apply on a table or for an ally. Only the strongest qualifying Leatherworking task bonus applies once per actual check. No routine check is invented; ordinary actions, hands, access, proficiency and competing slot requirements still apply. Broken stops positive functions; suppression stops recipe magic, not physical capacity or workmanship. Use the complete shared guide for custody, melding, quality, repair and value.

**Legal mundane bases:** Cargo quiver 30 lb. One model, actual fit and legal grade for the whole batch. Buy, own or legitimately commission complete bodies; no stock-construction recipe is implied.

**Physical reserve:** 1 complete, nonmagical, non-Broken bases in a stable physical-ID order before work; containers empty. No existing imprint. Missing/Broken/committed bases pause before the roll; repair or replace at the same position. Transform the first resolved N, using latest lawful completion HP. Keep unused bodies in their actual state outside ingredient recovery.

| Mundane body | Price gp | Empty lb | Ordinary HP / structural AC | Benefit slot | Ordinary use |
|---|---:|---:|---|---|---|
| Cargo quiver 30 lb | 6 | 6 | 5 / 15 | quiver | 30 lb / 1 ft³ contents |

| Container | Compartments | Interior per compartment, inches | Opening, inches | Exterior, inches | Each compartment limit |
|---|---:|---|---|---|---|
| Cargo quiver 30 lb | 3 | 36 × 4 × 4 | 4 × 4 | 38 × 18 × 6 | 10 lb / 1/3 ft³ |

**Exact source component occurrences:**

| # | Component | Quantity | Tier | Role / consumed | Unit lb | Unit gp | Required properties |
|---|---|---:|---:|---|---:|---:|---|
| 0 | Buckles | 3 | 5 | ingredient / true | 0.1 | 200 |  |
| 1 | Padding | 5 | 5 | reinforcement / true | 0.25 | 200 | reinforcement |
| 2 | Lining | 2 | 5 | reinforcement / true | 0.25 | 200 | reinforcement |
| 3 | green dragon hide | 1 | 3 | material / true | 0.44 | 114 | draconic, flexible, poison, protective |

All listed inputs are additional consumed process/reinforcement materials. Finished empty mass is the actual body mass; process waste supplies no second body or automatically valuable salvage. No source component is a catalyst; even Masterwork returns zero catalyst units. Independently required tools remain tools.

**Work and access:** DEX with actual Leatherworker's-tools proficiency as the shared framework permits; Tannery Bench; Leatherworker's tools, Awl, Cutting knife. Maximum assistants 0. Source fieldCraftable=false; preserved timeMode=haven; the false field flag controls. Source time: 2 weeks; source activeWorkHours=80. Operational required active time 80 hours. First stable phase 8 hours, included in total. Eligible Forge Dwarf: 3600 minutes, first phase 480 minutes. Stabilize only components actually incorporated in the completed first phase; other lots keep their clocks.

**Progression:** exact source trivialAtSkillLevel=15; use this threshold rather than regenerating level+5. Actual formula access: {"sources":["rare recipe drop","specialist commission","dungeon library","successful experimentation"],"minimumResearchHours":8,"requiresFormula":true,"formulaConsumed":false}. The framework controls trade eligibility, proficiency once, assistant qualifications, Watches, rest, interruptions, XP and mishaps.

**Output:** Standard 1; Exceptional yield 1; Masterwork yield 1; or 1 units with strongest noncompounding structural improvement 25%/50%. Flawed: one persistent half-maximum flaw applied after size/grade and strongest improvement, minimum1; preserve damage deficit and possible Broken output. Failed/Mishap transforms none; source input recovery/loss remains separate. Quality changes no capacity, relief, check bonus, AC, resistance or grade.

**Repair:** trained Leatherworker's tools, Tannery Bench, Awl and Cutting knife. Functional HP≥1: DEX + applicable proficiency DC10; max(1 hour, recorded max HP/10); materials 25% mundane base reference. Broken HP0: DEX + applicable proficiency DC19; max(8 hours, recorded max HP/10); materials 25% finished per-item reference; recoverable original main body required. Binary success restores recorded maximum, including the persistent flaw; failure consumes materials and time. No formula or original trade-level eligibility required or granted, quality roll, XP, catalyst return or Forge Dwarf creation reduction. No lost contents return.

**Finished ordinary Standard reference examples:** Cargo quiver 30 lb = 3260 gp. Source process share 3254 gp/unit plus actual undamaged mundane size/grade body reference. Retain exact precision until the actual transaction; no automatic buyer, quality premium, artifact multiplier or mundane-table magic buyback.

**Preserved tags:** Poison. Tags, current/legacy names, donors and whole-creature metadata add no powers or availability.

**Public source binding:** V5 ¶1751, ¶1752, ¶1753, ¶1754, ¶1755, ¶1756. The original effect remains verbatim; any AC overlay above is separate.

**Preserved inactive legacy/metadata:** {"legacyName": "Mystical Quiver", "legacyEffect": "Major magical effect"}.

## recipe-308 — Exalted Caustic Boots of Black Dragonhide

**REVIEWED — authored operational PLAYTEST.** public; Leatherworking level 10; tier 5; Rare; DC 19. Standard quantity 1; source Standard batch reference 2633 gp.

**Preserved effect:** Creates fitted boots granting +2 to a related mobility or handling check.

**Operational effect:** One output transforms one complete matched pair, retaining its physical identity and latest lawful completion damage state. Functional means at least 1 current structural HP; the singleton Flawed result can emerge Broken with a dormant imprint. While complete, functional, unsuppressed, unmelded and actually worn in its footwear-pair benefit slot, receive +2 only on these actual checks: STR (Athletics) for actual foothold climbing or a jump that requires a check; DEX (Acrobatics) to balance on narrow, unstable or slippery support using the feet. NEW LW-D01 overlay from mechanics.armorBonus: offer +1 to equipment.defense-enhancement; this AC benefit is omitted by the preserved prose. The complete accessory must occupy its one legal benefit slot. Use the strongest actual eligible Leatherworking, Blacksmithing or suit-grade modifier; ordinary selected shield AC remains separate. No damage resistance or environmental immunity is granted. Only the strongest qualifying Leatherworking task bonus applies once per actual check. No routine check is invented; ordinary actions, hands, access, proficiency and competing slot requirements still apply. Broken stops positive functions; suppression stops recipe magic, not physical capacity or workmanship. Use the complete shared guide for custody, melding, quality, repair and value.

**Legal mundane bases:** Boots pair. One model, actual fit and legal grade for the whole batch. Buy, own or legitimately commission complete bodies; no stock-construction recipe is implied.

**Physical reserve:** 1 complete, nonmagical, non-Broken bases in a stable physical-ID order before work; containers empty. No existing imprint. Missing/Broken/committed bases pause before the roll; repair or replace at the same position. Transform the first resolved N, using latest lawful completion HP. Keep unused bodies in their actual state outside ingredient recovery.

| Mundane body | Price gp | Empty lb | Ordinary HP / structural AC | Benefit slot | Ordinary use |
|---|---:|---:|---|---|---|
| Boots pair | 2 | 2 | 5 / 15 | footwear-pair | one matched pair |

| Container | Compartments | Interior per compartment, inches | Opening, inches | Exterior, inches | Each compartment limit |
|---|---:|---|---|---|---|

**Exact source component occurrences:**

| # | Component | Quantity | Tier | Role / consumed | Unit lb | Unit gp | Required properties |
|---|---|---:|---:|---|---:|---:|---|
| 0 | Waterproofing oil | 3 | 5 | solvent / true | 0.5 | 200 | solvent |
| 1 | Padding | 3 | 5 | reinforcement / true | 0.25 | 200 | reinforcement |
| 2 | Lining | 2 | 5 | reinforcement / true | 0.25 | 200 | reinforcement |
| 3 | black dragon hide | 1 | 3 | material / true | 0.58 | 54 | acid, draconic, flexible, protective |

All listed inputs are additional consumed process/reinforcement materials. Finished empty mass is the actual body mass; process waste supplies no second body or automatically valuable salvage. No source component is a catalyst; even Masterwork returns zero catalyst units. Independently required tools remain tools.

**Work and access:** DEX with actual Leatherworker's-tools proficiency as the shared framework permits; Tannery Bench; Leatherworker's tools, Awl, Cutting knife. Maximum assistants 0. Source fieldCraftable=false; preserved timeMode=haven; the false field flag controls. Source time: 2 weeks; source activeWorkHours=80. Operational required active time 80 hours. First stable phase 8 hours, included in total. Eligible Forge Dwarf: 3600 minutes, first phase 480 minutes. Stabilize only components actually incorporated in the completed first phase; other lots keep their clocks.

**Progression:** exact source trivialAtSkillLevel=15; use this threshold rather than regenerating level+5. Actual formula access: {"sources":["rare recipe drop","specialist commission","dungeon library","successful experimentation"],"minimumResearchHours":8,"requiresFormula":true,"formulaConsumed":false}. The framework controls trade eligibility, proficiency once, assistant qualifications, Watches, rest, interruptions, XP and mishaps.

**Output:** Standard 1; Exceptional yield 1; Masterwork yield 1; or 1 units with strongest noncompounding structural improvement 25%/50%. Flawed: one persistent half-maximum flaw applied after size/grade and strongest improvement, minimum1; preserve damage deficit and possible Broken output. Failed/Mishap transforms none; source input recovery/loss remains separate. Quality changes no capacity, relief, check bonus, AC, resistance or grade.

**Repair:** trained Leatherworker's tools, Tannery Bench, Awl and Cutting knife. Functional HP≥1: DEX + applicable proficiency DC10; max(1 hour, recorded max HP/10); materials 25% mundane base reference. Broken HP0: DEX + applicable proficiency DC19; max(8 hours, recorded max HP/10); materials 25% finished per-item reference; recoverable original main body required with both original pair members. Binary success restores recorded maximum, including the persistent flaw; failure consumes materials and time. No formula or original trade-level eligibility required or granted, quality roll, XP, catalyst return or Forge Dwarf creation reduction. No lost contents return.

**Finished ordinary Standard reference examples:** Boots pair = 2635 gp. Source process share 2633 gp/unit plus actual undamaged mundane size/grade body reference. Retain exact precision until the actual transaction; no automatic buyer, quality premium, artifact multiplier or mundane-table magic buyback.

**Preserved tags:** Acid. Tags, current/legacy names, donors and whole-creature metadata add no powers or availability.

**Public source binding:** V5 ¶1730, ¶1731, ¶1732, ¶1733, ¶1734, ¶1735. The original effect remains verbatim; any AC overlay above is separate.

**Preserved inactive legacy/metadata:** {"legacyName": "Boots of Reinforced Masterworkness", "legacyEffect": "Significant combat advantage"}.

## recipe-310 — Exalted Veiled Belt of Black Dragonhide

**REVIEWED — authored operational PLAYTEST.** public; Leatherworking level 10; tier 5; Rare; DC 18. Standard quantity 1; source Standard batch reference 3983 gp.

**Preserved effect:** Creates a reinforced belt carrying 30 pounds without counting against normal encumbrance; grants +2 to checks to secure or retrieve its contents.

**Operational effect:** One output transforms one complete mundane body, retaining its physical identity and latest lawful completion damage state. Functional means at least 1 current structural HP; the singleton Flawed result can emerge Broken with a dormant imprint. While functional, unsuppressed, unmelded, properly fitted and worn or directly held in its recorded waist-cargo relief position, cover up to 30 lb of eligible contents in stable loading order. Physical capacity remains 30 lb and 1 ft³, subject to its actual opening, shape and compartment limits. Its own body is not relieved. For each covered record, subtract covered pounds from the direct bearer's pound-carrying comparison and at most min(canonical Load, covered pounds/10) from Inventory Load; preserve actual mass and canonical Load. Enclosed enchanted containers are inactive; ordinary inner bodies and descendants count once. External lashings do not become contents. The actual operator receives +2 on a qualifying handling check: Actual difficult cargo handling to secure its ordinary closure/retainers or retrieve through an unlocked closure, jam, tangle or other physical difficulty: DEX for dexterous work or STR (Athletics) for forceful handling of noncreature cargo. This handling benefit needs accessible functional unsuppressed fittings, not a relief slot, and can apply on a table or for an ally. Only the strongest qualifying Leatherworking task bonus applies once per actual check. No routine check is invented; ordinary actions, hands, access, proficiency and competing slot requirements still apply. Broken stops positive functions; suppression stops recipe magic, not physical capacity or workmanship. Use the complete shared guide for custody, melding, quality, repair and value.

**Legal mundane bases:** Cargo belt 30 lb. One model, actual fit and legal grade for the whole batch. Buy, own or legitimately commission complete bodies; no stock-construction recipe is implied.

**Physical reserve:** 1 complete, nonmagical, non-Broken bases in a stable physical-ID order before work; containers empty. No existing imprint. Missing/Broken/committed bases pause before the roll; repair or replace at the same position. Transform the first resolved N, using latest lawful completion HP. Keep unused bodies in their actual state outside ingredient recovery.

| Mundane body | Price gp | Empty lb | Ordinary HP / structural AC | Benefit slot | Ordinary use |
|---|---:|---:|---|---|---|
| Cargo belt 30 lb | 6 | 6 | 5 / 15 | waist-cargo | 30 lb / 1 ft³ contents |

| Container | Compartments | Interior per compartment, inches | Opening, inches | Exterior, inches | Each compartment limit |
|---|---:|---|---|---|---|
| Cargo belt 30 lb | 3 | 12 × 8 × 6 | 12 × 6 | 13 × 9 × 7 per pocket | 10 lb / 1/3 ft³ |

**Exact source component occurrences:**

| # | Component | Quantity | Tier | Role / consumed | Unit lb | Unit gp | Required properties |
|---|---|---:|---:|---|---:|---:|---|
| 0 | Padding | 4 | 5 | reinforcement / true | 0.25 | 200 | reinforcement |
| 1 | Cured leather | 2 | 5 | substrate / true | 0.25 | 200 | substrate |
| 2 | Leather strips | 4 | 5 | substrate / true | 0.25 | 200 | substrate |
| 3 | Waterproofing oil | 3 | 5 | solvent / true | 0.5 | 200 | solvent |
| 4 | black dragon hide | 1 | 3 | material / true | 0.58 | 54 | acid, draconic, flexible, protective |

All listed inputs are additional consumed process/reinforcement materials. Finished empty mass is the actual body mass; process waste supplies no second body or automatically valuable salvage. No source component is a catalyst; even Masterwork returns zero catalyst units. Independently required tools remain tools.

**Work and access:** DEX with actual Leatherworker's-tools proficiency as the shared framework permits; Tannery Bench; Leatherworker's tools, Awl, Cutting knife. Maximum assistants 0. Source fieldCraftable=false; preserved timeMode=haven; the false field flag controls. Source time: 10 days; source activeWorkHours=80. Operational required active time 80 hours. First stable phase 8 hours, included in total. Eligible Forge Dwarf: 3600 minutes, first phase 480 minutes. Stabilize only components actually incorporated in the completed first phase; other lots keep their clocks.

**Progression:** exact source trivialAtSkillLevel=15; use this threshold rather than regenerating level+5. Actual formula access: {"sources":["rare recipe drop","specialist commission","dungeon library","successful experimentation"],"minimumResearchHours":8,"requiresFormula":true,"formulaConsumed":false}. The framework controls trade eligibility, proficiency once, assistant qualifications, Watches, rest, interruptions, XP and mishaps.

**Output:** Standard 1; Exceptional yield 1; Masterwork yield 1; or 1 units with strongest noncompounding structural improvement 25%/50%. Flawed: one persistent half-maximum flaw applied after size/grade and strongest improvement, minimum1; preserve damage deficit and possible Broken output. Failed/Mishap transforms none; source input recovery/loss remains separate. Quality changes no capacity, relief, check bonus, AC, resistance or grade.

**Repair:** trained Leatherworker's tools, Tannery Bench, Awl and Cutting knife. Functional HP≥1: DEX + applicable proficiency DC10; max(1 hour, recorded max HP/10); materials 25% mundane base reference. Broken HP0: DEX + applicable proficiency DC18; max(8 hours, recorded max HP/10); materials 25% finished per-item reference; recoverable original main body required. Binary success restores recorded maximum, including the persistent flaw; failure consumes materials and time. No formula or original trade-level eligibility required or granted, quality roll, XP, catalyst return or Forge Dwarf creation reduction. No lost contents return.

**Finished ordinary Standard reference examples:** Cargo belt 30 lb = 3989 gp. Source process share 3983 gp/unit plus actual undamaged mundane size/grade body reference. Retain exact precision until the actual transaction; no automatic buyer, quality premium, artifact multiplier or mundane-table magic buyback.

**Preserved tags:** Stealth. Tags, current/legacy names, donors and whole-creature metadata add no powers or availability.

**Public source binding:** V5 ¶1744, ¶1745, ¶1746, ¶1747, ¶1748, ¶1749. The original effect remains verbatim; any AC overlay above is separate.

**Preserved inactive legacy/metadata:** {"legacyName": "Exceptional Supple Belt", "legacyEffect": "Multiple spell-like abilities"}.

## recipe-652 — Allosaurus Expedition Pack

**REVIEWED — authored operational PLAYTEST.** public; Leatherworking level 8; tier 5; Rare; DC 16. Standard quantity 1; source Standard batch reference 1196 gp.

**Preserved effect:** Creates a reinforced backpack carrying 30 pounds without counting against normal encumbrance; grants +2 to checks to secure or retrieve its contents.

**Operational effect:** One output transforms one complete mundane body, retaining its physical identity and latest lawful completion damage state. Functional means at least 1 current structural HP; the singleton Flawed result can emerge Broken with a dormant imprint. While functional, unsuppressed, unmelded, properly fitted and worn or directly held in its recorded back-cargo relief position, cover up to 30 lb of eligible contents in stable loading order. Physical capacity remains 30 lb and 1 ft³, subject to its actual opening, shape and compartment limits. Its own body is not relieved. For each covered record, subtract covered pounds from the direct bearer's pound-carrying comparison and at most min(canonical Load, covered pounds/10) from Inventory Load; preserve actual mass and canonical Load. Enclosed enchanted containers are inactive; ordinary inner bodies and descendants count once. External lashings do not become contents. The actual operator receives +2 on a qualifying handling check: Actual difficult cargo handling to secure its ordinary closure/retainers or retrieve through an unlocked closure, jam, tangle or other physical difficulty: DEX for dexterous work or STR (Athletics) for forceful handling of noncreature cargo. This handling benefit needs accessible functional unsuppressed fittings, not a relief slot, and can apply on a table or for an ally. Only the strongest qualifying Leatherworking task bonus applies once per actual check. No routine check is invented; ordinary actions, hands, access, proficiency and competing slot requirements still apply. Broken stops positive functions; suppression stops recipe magic, not physical capacity or workmanship. Use the complete shared guide for custody, melding, quality, repair and value.

**Legal mundane bases:** Backpack. One model, actual fit and legal grade for the whole batch. Buy, own or legitimately commission complete bodies; no stock-construction recipe is implied.

**Physical reserve:** 1 complete, nonmagical, non-Broken bases in a stable physical-ID order before work; containers empty. No existing imprint. Missing/Broken/committed bases pause before the roll; repair or replace at the same position. Transform the first resolved N, using latest lawful completion HP. Keep unused bodies in their actual state outside ingredient recovery.

| Mundane body | Price gp | Empty lb | Ordinary HP / structural AC | Benefit slot | Ordinary use |
|---|---:|---:|---|---|---|
| Backpack | 2 | 5 | 10 / 15 | back-cargo | 30 lb / 1 ft³ contents |

| Container | Compartments | Interior per compartment, inches | Opening, inches | Exterior, inches | Each compartment limit |
|---|---:|---|---|---|---|
| Backpack | 1 | 18 × 12 × 8 | 12 × 8 | 20 × 14 × 10 | 30 lb / 1 ft³ |

**Exact source component occurrences:**

| # | Component | Quantity | Tier | Role / consumed | Unit lb | Unit gp | Required properties |
|---|---|---:|---:|---|---:|---:|---|
| 0 | Allosaurus pelt | 1 | 1 | material / true | 0.12 | 11 | flexible, protective |
| 1 | Allosaurus sinew | 1 | 3 | material / true | 0.34 | 144 | specialized |
| 2 | Cured leather | 1 | 5 | substrate / true | 0.25 | 200 | substrate |
| 3 | Buckles | 1 | 5 | ingredient / true | 0.1 | 200 |  |
| 4 | Reinforced stitching | 1 | 5 | binder / true | 0.1 | 200 | binder |

All listed inputs are additional consumed process/reinforcement materials. Finished empty mass is the actual body mass; process waste supplies no second body or automatically valuable salvage. No source component is a catalyst; even Masterwork returns zero catalyst units. Independently required tools remain tools.

**Work and access:** DEX with actual Leatherworker's-tools proficiency as the shared framework permits; Tannery Bench; Leatherworker's tools, Awl, Cutting knife. Maximum assistants 0. Source fieldCraftable=false; preserved timeMode=workshop; the false field flag controls. Source time: 2 days; source activeWorkHours=16. Operational required active time 16 hours. First stable phase 8 hours, included in total. Eligible Forge Dwarf: 720 minutes, first phase 480 minutes. Stabilize only components actually incorporated in the completed first phase; other lots keep their clocks.

**Progression:** exact source trivialAtSkillLevel=13; use this threshold rather than regenerating level+5. Actual formula access: {"sources":["guild trainer","faction vendor","uncommon dungeon book","reverse engineering"],"minimumResearchHours":0,"requiresFormula":true,"formulaConsumed":false}. The framework controls trade eligibility, proficiency once, assistant qualifications, Watches, rest, interruptions, XP and mishaps.

**Output:** Standard 1; Exceptional yield 1; Masterwork yield 1; or 1 units with strongest noncompounding structural improvement 25%/50%. Flawed: one persistent half-maximum flaw applied after size/grade and strongest improvement, minimum1; preserve damage deficit and possible Broken output. Failed/Mishap transforms none; source input recovery/loss remains separate. Quality changes no capacity, relief, check bonus, AC, resistance or grade.

**Repair:** trained Leatherworker's tools, Tannery Bench, Awl and Cutting knife. Functional HP≥1: DEX + applicable proficiency DC10; max(1 hour, recorded max HP/10); materials 25% mundane base reference. Broken HP0: DEX + applicable proficiency DC16; max(8 hours, recorded max HP/10); materials 25% finished per-item reference; recoverable original main body required. Binary success restores recorded maximum, including the persistent flaw; failure consumes materials and time. No formula or original trade-level eligibility required or granted, quality roll, XP, catalyst return or Forge Dwarf creation reduction. No lost contents return.

**Finished ordinary Standard reference examples:** Backpack = 1198 gp. Source process share 1196 gp/unit plus actual undamaged mundane size/grade body reference. Retain exact precision until the actual transaction; no automatic buyer, quality premium, artifact multiplier or mundane-table magic buyback.

**Preserved tags:** Strength. Tags, current/legacy names, donors and whole-creature metadata add no powers or availability.

**Public source binding:** V5 ¶1709, ¶1710, ¶1711, ¶1712, ¶1713, ¶1714. The original effect remains verbatim; any AC overlay above is separate.

**Preserved inactive legacy/metadata:** {"wholeCreatureUse": true}.

## recipe-653 — Black-Dragon Acidproof Boots

**REVIEWED — authored operational PLAYTEST.** public; Leatherworking level 8; tier 5; Rare; DC 16. Standard quantity 1; source Standard batch reference 1057 gp.

**Preserved effect:** Creates fitted boots granting +2 to a related mobility or handling check.

**Operational effect:** One output transforms one complete matched pair, retaining its physical identity and latest lawful completion damage state. Functional means at least 1 current structural HP; the singleton Flawed result can emerge Broken with a dormant imprint. While complete, functional, unsuppressed, unmelded and actually worn in its footwear-pair benefit slot, receive +2 only on these actual checks: STR (Athletics) for actual foothold climbing or a jump that requires a check; DEX (Acrobatics) to balance on narrow, unstable or slippery support using the feet. NEW LW-D01 overlay from mechanics.armorBonus: offer +1 to equipment.defense-enhancement; this AC benefit is omitted by the preserved prose. The complete accessory must occupy its one legal benefit slot. Use the strongest actual eligible Leatherworking, Blacksmithing or suit-grade modifier; ordinary selected shield AC remains separate. No damage resistance or environmental immunity is granted. Only the strongest qualifying Leatherworking task bonus applies once per actual check. No routine check is invented; ordinary actions, hands, access, proficiency and competing slot requirements still apply. Broken stops positive functions; suppression stops recipe magic, not physical capacity or workmanship. Use the complete shared guide for custody, melding, quality, repair and value.

**Legal mundane bases:** Boots pair. One model, actual fit and legal grade for the whole batch. Buy, own or legitimately commission complete bodies; no stock-construction recipe is implied.

**Physical reserve:** 1 complete, nonmagical, non-Broken bases in a stable physical-ID order before work; containers empty. No existing imprint. Missing/Broken/committed bases pause before the roll; repair or replace at the same position. Transform the first resolved N, using latest lawful completion HP. Keep unused bodies in their actual state outside ingredient recovery.

| Mundane body | Price gp | Empty lb | Ordinary HP / structural AC | Benefit slot | Ordinary use |
|---|---:|---:|---|---|---|
| Boots pair | 2 | 2 | 5 / 15 | footwear-pair | one matched pair |

| Container | Compartments | Interior per compartment, inches | Opening, inches | Exterior, inches | Each compartment limit |
|---|---:|---|---|---|---|

**Exact source component occurrences:**

| # | Component | Quantity | Tier | Role / consumed | Unit lb | Unit gp | Required properties |
|---|---|---:|---:|---|---:|---:|---|
| 0 | black dragon hide | 1 | 3 | material / true | 0.58 | 54 | acid, draconic, flexible, protective |
| 1 | black dragon scale | 1 | 1 | material / true | 0.43 | 8 | acid, draconic, protective, rigid |
| 2 | Cured leather | 1 | 5 | substrate / true | 0.25 | 200 | substrate |
| 3 | Waterproofing oil | 1 | 5 | solvent / true | 0.5 | 200 | solvent |
| 4 | Reinforced stitching | 1 | 5 | binder / true | 0.1 | 200 | binder |

All listed inputs are additional consumed process/reinforcement materials. Finished empty mass is the actual body mass; process waste supplies no second body or automatically valuable salvage. No source component is a catalyst; even Masterwork returns zero catalyst units. Independently required tools remain tools.

**Work and access:** DEX with actual Leatherworker's-tools proficiency as the shared framework permits; Tannery Bench; Leatherworker's tools, Awl, Cutting knife. Maximum assistants 0. Source fieldCraftable=false; preserved timeMode=workshop; the false field flag controls. Source time: 2 days; source activeWorkHours=16. Operational required active time 16 hours. First stable phase 8 hours, included in total. Eligible Forge Dwarf: 720 minutes, first phase 480 minutes. Stabilize only components actually incorporated in the completed first phase; other lots keep their clocks.

**Progression:** exact source trivialAtSkillLevel=13; use this threshold rather than regenerating level+5. Actual formula access: {"sources":["guild trainer","faction vendor","uncommon dungeon book","reverse engineering"],"minimumResearchHours":0,"requiresFormula":true,"formulaConsumed":false}. The framework controls trade eligibility, proficiency once, assistant qualifications, Watches, rest, interruptions, XP and mishaps.

**Output:** Standard 1; Exceptional yield 1; Masterwork yield 1; or 1 units with strongest noncompounding structural improvement 25%/50%. Flawed: one persistent half-maximum flaw applied after size/grade and strongest improvement, minimum1; preserve damage deficit and possible Broken output. Failed/Mishap transforms none; source input recovery/loss remains separate. Quality changes no capacity, relief, check bonus, AC, resistance or grade.

**Repair:** trained Leatherworker's tools, Tannery Bench, Awl and Cutting knife. Functional HP≥1: DEX + applicable proficiency DC10; max(1 hour, recorded max HP/10); materials 25% mundane base reference. Broken HP0: DEX + applicable proficiency DC16; max(8 hours, recorded max HP/10); materials 25% finished per-item reference; recoverable original main body required with both original pair members. Binary success restores recorded maximum, including the persistent flaw; failure consumes materials and time. No formula or original trade-level eligibility required or granted, quality roll, XP, catalyst return or Forge Dwarf creation reduction. No lost contents return.

**Finished ordinary Standard reference examples:** Boots pair = 1059 gp. Source process share 1057 gp/unit plus actual undamaged mundane size/grade body reference. Retain exact precision until the actual transaction; no automatic buyer, quality premium, artifact multiplier or mundane-table magic buyback.

**Preserved tags:** Acid. Tags, current/legacy names, donors and whole-creature metadata add no powers or availability.

**Public source binding:** V5 ¶1716, ¶1717, ¶1718, ¶1719, ¶1720, ¶1721. The original effect remains verbatim; any AC overlay above is separate.

**Preserved inactive legacy/metadata:** {"wholeCreatureUse": true}.
