"""Reviewer arithmetic audit of the submitted source/card control fields.
Compact rows are transcribed from the supplied source records and manuscript.
This is not an independent comparison with Codex's saved candidate JSON files.
"""
from pathlib import Path
from fractions import Fraction as F
from collections import Counter
import json
# ID, family, tag, bonus, charges, quantity, DC, hours, assistants, trivial, batch_gp
source_rows=[
(241,'Bracelet','Stealth',1,1,3,11,4,0,7,163),
(242,'Earring','Flora',1,1,1,12,4,0,6,132),
(243,'Earring','Flora',1,1,3,9,4,0,7,159),
(244,'Crown','Poison',1,1,1,8,2,0,6,173),
(245,'Bracelet','Unholy',1,1,5,8,8,0,6,390),
(246,'Earring','Earth',1,1,1,10,1,0,10,460),
(247,'Amulet','Strength',1,1,4,12,4,0,7,120),
(248,'Crown','Flora',1,1,5,11,1,0,9,133),
(249,'Ring','Psychic',1,1,3,11,1,0,7,2505),
(250,'Tiara','Arcane',1,1,3,12,2,0,6,137),
(251,'Necklace','Cold',1,1,1,11,2,0,10,175),
(252,'Amulet','Psychic',1,1,1,11,1,0,9,2536),
(253,'Brooch','Stealth',1,1,3,9,1,0,6,159),
(254,'Brooch','Psychic',1,1,3,8,2,0,9,2560),
(255,'Tiara','Vitality',1,1,4,12,2,0,9,312),
(256,'Tiara','Lightning',1,2,1,15,24,0,13,838),
(257,'Tiara','Vitality',1,2,1,14,24,0,12,835),
(258,'Earring','Fire',1,2,1,13,8,0,14,2527),
(259,'Crown','Stealth',1,2,1,14,24,0,13,1854),
(260,'Tiara','Strength',1,2,1,13,8,0,14,1710),
(261,'Ring','Poison',1,2,1,17,8,0,14,3601),
(262,'Amulet','Arcane',1,2,1,14,24,0,13,1932),
(263,'Necklace','Unholy',1,2,1,13,16,0,11,644),
(264,'Crown','Arcane',1,2,1,17,24,0,10,844),
(265,'Tiara','Poison',2,3,1,20,80,0,15,3695),
(266,'Crown','Water',2,3,1,20,40,1,18,25038),
(267,'Crown','Poison',2,3,1,19,80,1,18,13535),
(268,'Gem','Fire',2,3,1,19,80,0,15,4507),
(269,'Brooch','Psychic',2,3,1,20,80,1,18,15971),
(270,'Crown','Arcane',2,3,1,19,80,0,16,5955),
(271,'Crown','Unholy',2,3,1,20,80,1,19,31691),
(272,'Bracelet','Acid',2,4,1,22,160,2,20,194886),
(273,'Crown','Arcane',2,4,1,20,160,2,20,53923),
(274,'Bracelet','Psychic',2,4,1,22,120,2,20,53348),
(275,'Gem','Acid',2,4,1,23,120,2,20,245091),
(276,'Ring','Water',2,4,1,21,120,2,20,169904),
(277,'Brooch','Water',3,5,1,25,320,2,20,395095),
(278,'Necklace','Psychic',3,5,1,24,480,3,20,498638),
(279,'Brooch','Water',3,6,1,27,960,3,20,776887),
(648,'Ring','Arcane',3,5,1,24,160,2,20,37162),
(649,'Amulet','Earth',3,5,1,24,160,2,20,36880),
(650,'Brooch','Fire',3,5,1,24,160,2,20,37014),
(651,'Pendant','Unholy',3,5,1,24,160,2,20,36293)]
# Normal/Large card references and Forge Dwarf active minutes, from Part B.
observed={
241:('166/3','169/3',180),242:('132.5','133',180),243:('53.5','54',180),
244:('178','183',90),245:('79','80',360),246:('460.5','461',45),
247:('31','32',180),248:('31.6','36.6',45),249:('840','845',45),
250:('146/3','155/3',90),251:('177','179',90),252:('2537','2538',45),
253:('54','55',45),254:('2563/3','2566/3',90),255:('81','84',90),
256:('841','844',1080),257:('838','841',1080),258:('2527.5','2528',360),
259:('1859','1864',1080),260:('1713','1716',360),261:('3606','3611',360),
262:('1933','1934',1080),263:('646','648',720),264:('849','854',1080),
265:('3698','3701',3600),266:('25043','25048',1800),267:('13540','13545',3600),
268:('4509','4511',3600),269:('15972','15973',3600),270:('5960','5965',3600),
271:('31696','31701',3600),272:('194887','194888',7200),273:('53928','53933',7200),
274:('53349','53350',5400),275:('245093','245095',5400),276:('169909','169914',5400),
277:('395096','395097',14400),278:('498640','498642',21600),279:('776888','776889',43200),
648:('37167','37172',7200),649:('36881','36882',7200),650:('37015','37016',7200),
651:('36294','36295',7200)}
body_price={k:F(v) for k,v in {'Bracelet':'1','Earring':'0.5','Crown':'5','Amulet':'1',
'Ring':'5','Tiara':'3','Necklace':'2','Brooch':'1','Gem':'2','Pendant':'1'}.items()}
assert len(source_rows)==43
public=[r for r in source_rows if 241<=r[0]<=265 or r[0]==268]
for n,f,tag,b,c,q,dc,h,a,tr,v in source_rows:
    assert F(observed[n][0])==F(v,q)+body_price[f],n
    assert F(observed[n][1])==F(v,q)+2*body_price[f],n
    assert observed[n][2]==45*h,n
assert len(public)==26
assert len({r[1] for r in public})==9
assert len({r[2] for r in public})==12

# Exact supplied structural functions copied from Part B.
def structural_maximum(ordinary,percent=0,flawed=False):
    if ordinary not in (5,10) or percent not in (0,25,50):raise ValueError('unadmitted structural premise')
    improved=ordinary+(max(1,ordinary*percent//100) if percent else 0)
    return max(1,improved//2) if flawed else improved

def quality_structure(ordinary,old_percent,old_flawed,old_current,new_percent=0,add_flaw=False):
    oldmax=structural_maximum(ordinary,old_percent,old_flawed)
    if not 1<=old_current<=oldmax:raise ValueError('reserve must be functional at completion')
    percent=max(old_percent,new_percent);flaw=old_flawed or add_flaw;maximum=structural_maximum(ordinary,percent,flaw)
    return {'maximum':maximum,'current':max(0,min(maximum,maximum-(oldmax-old_current))),'durabilityPercent':percent,'flawed':flaw}

cases=0
for b in (5,10):
 for p in (0,25,50):
  for flaw in (False,True):
   oldmax=structural_maximum(b,p,flaw)
   for hp in range(1,oldmax+1):
    for newp in (0,25,50):
     for newflaw in (False,True):
      result=quality_structure(b,p,flaw,hp,newp,newflaw)
      unflawed=b+(max(1,b*max(p,newp)//100) if max(p,newp) else 0)
      expected=max(1,unflawed//2) if flaw or newflaw else unflawed
      assert result['maximum']==expected
      assert result['current']==max(0,expected-(oldmax-hp))
      cases+=1
report={'scope':__doc__,'recipes':43,'value_cases_passed':86,'creation_time_cases_passed':43,
'public_recipes':26,'public_body_families':9,'public_tags':12,
'bonus_distribution':dict(Counter(r[3] for r in source_rows)),
'charge_distribution':dict(Counter(r[4] for r in source_rows)),
'structural_cases_passed':cases,'gem_268_correct_broken_repair':{
'DC':19,'hours':8,'materials_gp':'1127.25','materials_cp':112725},
'gem_268_submitted_negative_test_dc':23}
assert cases==486
print(json.dumps(report,indent=2))
with open(Path(__file__).with_name('numeric_results.json'),'w',encoding='utf-8') as f:
 json.dump(report,f,indent=2);f.write('\n')
