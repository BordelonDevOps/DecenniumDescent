"""Reconstruct literal submitted card text from its supplied repeated templates
and independently transcribed per-card fields, then check the supplied SHA-256.
No Codex-local path is opened. A digest mismatch is not treated as verification.
"""
from pathlib import Path
import json, hashlib, re
from numeric_audit import source_rows,observed,body_price
ROOT=Path(__file__).resolve().parent
authority=(ROOT/'jewelcrafting_source_disposition.md').read_text(encoding='utf-8')
allowed={r[2] for r in source_rows}
registry={}
for line in authority.splitlines():
 m=re.match(r'^\| \*\*([^*]+)\*\* \|',line)
 if m and m[1] in allowed:registry[m[1]]=line.replace('**'+m[1]+'**',m[1],1)
assert len(registry)==14
models={
'Bracelet':('Fitted steel wrist chain/band with clasp','1','0.1','19','wrist-adornment'),
'Earring':('Single steel ear ornament with fitted clip or fastening','0.5','0.02','19','ear-adornment'),
'Crown':('Complete fitted steel circlet-style Crown','5','0.5','19','head'),
'Amulet':('Steel medallion Amulet with integral neck chain and closure','1','0.1','19','neck-adornment'),
'Ring':('Fitted steel signet-pattern Ring','5','0.02','19','ring-1, ring-2'),
'Tiara':('Complete fitted open steel headband Tiara','3','0.25','19','head'),
'Necklace':('Complete decorative steel Necklace with closure','2','0.2','19','neck-adornment'),
'Brooch':('Steel ornament with complete pin and keeper','1','0.05','19','chest-adornment'),
'Gem':('Ordinary ornamental crystal in fitted steel cup with pin and keeper','2','0.05','13','chest-adornment'),
'Pendant':('Steel drop ornament with integral neck chain and closure','1','0.1','19','neck-adornment')}
# ID: name | level | tier | rarity | source time | mode | research hours | legacy name | legacy effect
raw='''241|Field Veiled Bracelet|2|1|Common|4 hours|expedition|0|Serviceable Bracelet|Minor magical effect
242|Field Verdant Earring|1|1|Common|4 hours|expedition|0|Simple Earring|Temporary resistance
243|Field Verdant Earring — Metal|2|1|Common|4 hours|expedition|0|Jeweler's Earring|Minor magical effect
244|Field Venom Crown|1|1|Common|2 hours|field|0|Sparkling Crown|Temporary resistance
245|Field Grave Bracelet|1|1|Common|8 hours|expedition|0|Bracelet of Gem-Encrusted Serviceableness|Minor magical effect
246|Superior Stone Earring of Metal|5|3|Common|1 hour|field|0|Earring of Sparkling Serviceableness|Temporary resistance
247|Field Mighty Amulet|2|1|Common|4 hours|expedition|0|Sparkling Amulet|Small bonus to one skill
248|Refined Verdant Crown|4|2|Common|1 hour|field|0|Crown of Sparkling Simpleness|Temporary resistance
249|Field Mindward Ring|2|1|Common|1 hour|field|0|Standard Gem-Encrusted Ring|Temporary resistance
250|Field Resonant Tiara|1|1|Common|2 hours|field|0|Simple Tiara|Temporary resistance
251|Superior Frost Necklace of White Dragon Fang|5|3|Common|2 hours|field|0|Jeweler's Necklace|Small bonus to one skill
252|Refined Mindward Amulet|4|2|Common|1 hour|field|0|Gem-Encrusted Amulet|Minor magical effect
253|Field Veiled Brooch|1|1|Common|1 hour|field|0|Sparkling Brooch|Small bonus to one skill
254|Refined Mindward Brooch|4|2|Common|2 hours|field|0|Basic Brooch|Minor magical effect
255|Refined Vital Tiara|4|2|Common|2 hours|field|0|Standard Precious Tiara|Minor magical effect
256|Masterwork Storm Tiara of Blue Dragon Bone|8|4|Uncommon|3 days|workshop|0|Improved Tiara|Moderate magical effect
257|Masterwork Vital Tiara of Warrior's Heart|7|4|Uncommon|3 days|workshop|0|Jeweler's Tiara|Moderate magical effect
258|Exalted Ember Earring of Fire Bone|9|5|Uncommon|1 day|expedition|4|Earring of Gem-Encrusted Enhancedness|Daily spell-like ability
259|Masterwork Veiled Crown of Black Dragon Talon|8|4|Uncommon|3 days|workshop|0|Enhanced Sparkling Crown|Daily spell-like ability
260|Exalted Mighty Tiara of Horse Claw|9|5|Uncommon|1 day|expedition|4|Precious Tiara|Moderate magical effect
261|Exalted Venom Ring of Spore Pod|9|5|Uncommon|1 day|expedition|4|Ring of Brilliant Enhancedness|Daily spell-like ability
262|Masterwork Resonant Amulet of Elemental Core|8|4|Uncommon|3 days|workshop|0|Enhanced Sparkling Amulet|Bonus to multiple skills
263|Superior Grave Necklace of Soul|6|3|Uncommon|2 days|workshop|0|Refined Necklace|Bonus to multiple skills
264|Superior Resonant Crown of Elemental Core|5|3|Uncommon|3 days|workshop|0|Superior Precious Crown|Bonus to multiple skills
265|Exalted Venom Tiara of Spore Pod|10|5|Rare|2 weeks|haven|8|Exceptional Sparkling Tiara|Multiple spell-like abilities
266|Relic Tide Crown of Refined Water Core|13|7|Rare|1 week|workshop|20|Crown of Gem-Encrusted Exceptionalness|Multiple spell-like abilities
267|Relic Venom Crown of Spore Pod|13|7|Rare|10 days|haven|20|Empowered Brilliant Crown|Significant combat advantage
268|Exalted Ember Gem of Refined Fire Core|10|5|Rare|10 days|haven|8|Empowered Gem|Major magical effect
269|Relic Mindward Brooch of Aberrant Core|13|7|Rare|2 weeks|haven|20|Brooch of Brilliant Empoweredness|Multiple spell-like abilities
270|Legendary Resonant Crown of Elemental Core|11|6|Rare|2 weeks|haven|12|Masterwork Crown|Significant combat advantage
271|Relic Grave Crown of Soul|14|7|Rare|2 weeks|haven|24|Mystical Sparkling Crown|Major magical effect
272|Ascendant Caustic Bracelet of Black Dragon Claw|18|9|Very Rare|1 month|haven|40|Mythical Bracelet|Powerful magical effect
273|Mythic Resonant Crown of Primordial Ooze Core|16|8|Very Rare|1 month|haven|32|Legendary Crown|Unique special ability
274|Mythic Mindward Bracelet of Sentience|16|8|Very Rare|3 weeks|haven|32|Mythical Jeweler's Bracelet|Major combat advantage
275|Ascendant Caustic Gem of Black Dragon Claw|17|9|Very Rare|3 weeks|haven|36|Jeweler's Gem|Unique special ability
276|Ascendant Tide Ring of Refined Water Core|18|9|Very Rare|3 weeks|haven|40|Sparkling Ring|Major combat advantage
277|Transcendent Tide Brooch of Bronze Dragonheart|19|10|Legendary|2 months|legacy|44|Legendary Brooch|Extremely powerful effect
278|Transcendent Mindward Necklace of Aberrant Core|20|10|Legendary|3 months|legacy|48|Celestial Sparkling Necklace|Game-changing ability
279|Transcendent Tide Brooch of Pure Water|20|10|Mythic|6 months|legacy|48|Transcendent Brooch|Artifact-level unique ability
648|Core-Crystal Signet|16|9|Legendary|1 month|haven|32||
649|Obsidian-Heart Amulet|16|9|Legendary|1 month|haven|32||
650|Red-Dragon Heartstone Brooch|16|9|Legendary|1 month|haven|32||
651|Wailing-Spirit Pendant|16|9|Legendary|1 month|haven|32||'''
meta={int(p[0]):p[1:] for p in (line.split('|') for line in raw.splitlines())}
# Shared supply fields are exact for these submitted occurrences.
prices={1:2,2:8,3:25,4:75,5:200,6:500,7:1200,8:3000,9:7500,10:18000}
def supply(name,q,tier):
 role='binder' if name in ('Setting','Clasp') else 'reinforcement' if name=='Chain' else 'ingredient' if name=='Polishing compound' else 'substrate'
 w='0.02' if name in ('Emerald','Sapphire','Ruby','Opal','Diamond') else '1.0' if name=='Gemstone' else '0.1'
 return (name,q,tier,role,w,prices[tier],'' if role=='ingredient' else role)
# Complete per-occurrence special component rows. Only supplied metadata is used.
special={
'black dragon fang':(1,'material','0.67',5,'acid, draconic, rigid, structural'),
'metal fragment':(1,'material','0.27',14,'resonant, rigid'),
'spore pod':(2,'material','0.19',41,'poison, resonant, rigid'),
'soul fragment':(4,'catalyst','0.35',260,'arcane, resonant, unholy, volatile'),
'silver dragon fang':(1,'material','0.38',15,'cold, draconic, rigid, structural'),
'ancient aberrant core':(6,'material','0.15',1845,'epic, legendary, psychic, resonant, rigid'),
'elemental core fragment':(3,'material','0.53',85,'arcane, resonant, rigid'),
'white dragon fang':(1,'material','0.91',11,'cold, draconic, rigid, structural'),
"warrior's heart":(3,'catalyst','0.44',148,'power-bearing, vital'),
'blue dragon bone':(2,'material','0.43',22,'draconic, lightning, rigid, structural'),
'Fire bone shard':(2,'material','0.33',45,'fire, rigid, structural'),
'black dragon talon':(2,'material','0.31',27,'acid, draconic, rigid, structural'),
'Horse claw':(2,'material','0.38',40,'rigid, structural'),
'refined water core':(4,'material','0.05',354,'resonant, rigid, water'),
'refined fire core':(4,'material','0.19',242,'fire, resonant, rigid'),
'black dragon claw':(4,'material','0.31',485,'acid, draconic, rigid, structural'),
'blue dragon claw':(4,'material','0.08',308,'draconic, lightning, rigid, structural'),
'primordial ooze core':(6,'material','0.08',2541,'acid, epic, legendary, resonant, rigid'),
'refined elemental core':(4,'material','0.14',454,'arcane, resonant, rigid'),
'essence of sentience':(6,'catalyst','0.03',3961,'arcane, epic, legendary, psychic, resonant, sentient, volatile'),
'pure essence of water':(6,'catalyst','0.09',4701,'arcane, epic, legendary, resonant, volatile, water'),
'bronze dragon heartstone':(5,'catalyst','0.26',1370,'draconic, earth, epic, power-bearing, vital, water'),
'pulsing water crystal':(5,'material','0.09',1041,'epic, resonant, rigid, water'),
'mythic Sea core':(6,'material','0.01',1512,'epic, legendary, resonant, rigid, water'),
'ancient growth essence':(6,'catalyst','0.15',4148,'arcane, epic, legendary, regenerative, resonant, vital, volatile'),
'core crystal':(5,'material','0.11',1421,'epic, resonant, rigid'),
'obsidian heart':(5,'material','0.22',1233,'earth, epic, power-bearing, vital'),
'red dragon heartstone':(5,'material','0.16',1323,'draconic, earth, epic, fire, power-bearing, vital'),
'wailing spirit crystal':(5,'material','0.28',842,'arcane, epic, resonant, volatile')}
# Entries beginning with a quantity are supplies; unnumbered entries are full special rows.
bills='''241|2 Setting;2 Emerald;3 Opal;black dragon fang
242|4 Sapphire;metal fragment
243|2 Clasp;1 Ruby;metal fragment
244|1 Setting;5 Sapphire;spore pod
245|5 Gold;4 Gemstone;4 Sapphire;soul fragment
246|5 Emerald;4 Ruby;4 Polishing compound;metal fragment
247|4 Polishing compound;3 Diamond;silver dragon fang
248|2 Silver;5 Gold;metal fragment
249|2 Setting;3 Opal;ancient aberrant core
250|3 Ruby;2 Diamond;3 Sapphire;elemental core fragment
251|2 Diamond;1 Platinum;white dragon fang
252|2 Sapphire;2 Emerald;ancient aberrant core
253|2 Ruby;1 Gemstone;black dragon fang
254|5 Emerald;1 Opal;ancient aberrant core
255|5 Gold;2 Sapphire;3 Clasp;warrior's heart
256|4 Sapphire;2 Chain;blue dragon bone
257|1 Polishing compound;4 Opal;warrior's heart
258|1 Clasp;3 Silver;5 Ruby;Fire bone shard
259|3 Gemstone;4 Opal;5 Chain;5 Ruby;black dragon talon
260|5 Setting;1 Silver;Horse claw
261|5 Ruby;3 Sapphire;5 Gemstone;spore pod
262|3 Clasp;5 Platinum;5 Opal;4 Gemstone;elemental core fragment
263|3 Opal;3 Polishing compound;1 Gold;soul fragment
264|3 Setting;5 Clasp;5 Ruby;2 Polishing compound;elemental core fragment
265|2 Clasp;4 Chain;1 Sapphire;5 Silver;spore pod
266|4 Polishing compound;4 Chain;4 Clasp;3 Sapphire;refined water core
267|1 Ruby;1 Chain;2 Gold;4 Setting;spore pod
268|4 Opal;4 Platinum;2 Sapphire;4 Silver;refined fire core
269|1 Silver;4 Clasp;1 Opal;1 Emerald;1 Polishing compound;ancient aberrant core
270|2 Gemstone;5 Setting;1 Diamond;elemental core fragment
271|5 Opal;4 Setting;5 Silver;4 Gemstone;1 Emerald;soul fragment
272|5 Setting;4 Chain;3 Ruby;2 Sapphire;2 Gemstone;3 Gold;black dragon claw;blue dragon claw
273|5 Polishing compound;3 Diamond;3 Setting;1 Chain;primordial ooze core;refined elemental core
274|2 Platinum;1 Chain;3 Polishing compound;4 Sapphire;1 Diamond;essence of sentience;ancient aberrant core
275|3 Sapphire;5 Emerald;2 Gold;4 Opal;5 Ruby;5 Gemstone;black dragon claw;blue dragon claw
276|3 Ruby;4 Gemstone;5 Gold;4 Silver;refined water core;pure essence of water
277|1 Diamond;1 Polishing compound;5 Clasp;1 Silver;4 Ruby;4 Emerald;bronze dragon heartstone;pulsing water crystal
278|4 Opal;4 Gold;4 Diamond;1 Ruby;1 Gemstone;3 Chain;3 Clasp;ancient aberrant core;essence of sentience
279|3 Platinum;5 Opal;5 Diamond;1 Clasp;5 Emerald;5 Gold;4 Sapphire;3 Polishing compound;pure essence of water;mythic Sea core;ancient growth essence
648|core crystal;1 Gold;1 Setting;1 Polishing compound
649|obsidian heart;1 Platinum;1 Chain;1 Setting
650|red dragon heartstone;1 Gold;1 Ruby;1 Setting
651|wailing spirit crystal;1 Silver;1 Opal;1 Chain'''
components={}
for line in bills.splitlines():
 n,bill=line.split('|');n=int(n);tier=int(meta[n][2]);rows=[]
 for term in bill.split(';'):
  match=re.match(r'^(\d+) (.+)$',term)
  if match:rows.append(supply(match[2],int(match[1]),tier))
  else:rows.append((term,1,*special[term]))
 components[n]=rows
assert sum(map(len,components.values()))==200
assert sum(row[3]=='catalyst' for rows in components.values() for row in rows)==11
starts={241:1402,242:1381,243:1409,244:1374,245:1353,246:1458,247:1388,248:1430,249:1395,250:1360,251:1444,252:1416,253:1367,254:1423,255:1437,256:1486,257:1472,258:1500,259:1493,260:1507,261:1514,262:1479,263:1465,264:1451,265:1528,268:1521}
secondaries={272:'Acid, Lightning',273:'Arcane, Acid',274:'Psychic, Arcane',275:'Acid, Lightning',276:'Water, Arcane',277:'Water, Earth',278:'Psychic, Flora',279:'Water, Flora, Arcane'}
guidance='Deep-tier provisional (skill 11+ → restricted or undiscovered depth). Components are real costs — do not treat as free craft. Director: (1) require components as listed or 1:1 Instruments salvage swap; (2) gate availability behind Floor/tier access or a named haven workshop; (3) if the result feels too strong for current floor, add downtime hours (skillLevel × 2 hours suggested) or a rare catalyst from the current Gate zone;'
legendary='Legendary/Mythic quality — provisional balance. Components are real costs — do not empty or waive casually. Director: (1) treat as campaign-defining rewards (Gate seal, research breakthrough, or named NPC commission); (2) require full listed components or Instruments tier salvage of equal or higher tier; (3) optional: add a Resonance ritual (1 long rest + Weave check DC 15 + skillLevel) before completion; (4) keep Heartcell/Silent Ones names out of the public craft ledger.'
blocks={}
for n,f,tag,bonus,charges,q,dc,h,assist,trivial,batch in source_rows:
 name,level,tier,rarity,time,mode,research,legacyname,legacyeffect=meta[n]
 level=int(level);research=int(research)
 visibility='public' if n in starts else 'restricted' if n==270 else 'director-only'
 body,bgp,blb,ac,slot=models[f]
 p=[f'## recipe-{n} — {name}',
 f'**DRAFT; exact review pending.** {visibility}; Jewelcrafting level {level}; tier {tier}; {rarity}; crafting DC {dc}; Standard quantity {q}.',
 f'**Preserved source effect:** While worn, grants +{bonus} to one {tag.lower()}-related check or save. It has {charges} charge'+('' if charges==1 else 's')+'; expend one to gain advantage on such a roll. Charges return at dawn.']
 effect=f'**Operational effect:** While complete, at positive structural HP, unsuppressed, unmelded, fitted and actually worn in one designated legal {slot} position, the actual wearer gains +{bonus} once on each independently qualifying {tag}-related ability check or saving throw under the exact predicates below. This passive benefit is not spent and remains with zero charges. This physical item has maximum {charges} charges. A conscious, non-Incapacitated wearer may voluntarily spend one before an eligible roll commits to gain advantage on that event, with no separate Action, Bonus Action, Reaction, RP, speech or hand use. Declare before any die or replacement result; no retrospective reroll. At most one Jewelcrafting charge is spent per event, and ordinary advantage/disadvantage cancellation applies. The spending item must independently qualify but need not supply the strongest flat modifier. Ability-check modifiers share equipment.leather-task-enhancement with independently qualified Leatherworking/Tailoring; save modifiers share equipment.jewel-save-enhancement with other jewels. Use the strongest within the applicable family once. Charges initialize once at lawful creation and refill only at legitimate Jewelcrafting dawn events under the shared guide. Transfer, equipping, repair, suppression ending, new scenes and copied records never refill or reinitialize them. This grants no AC candidate, even zero; no resistance, attack modifier, proficiency, extra hand, focus permission or carrying relief.'
 if f=='Earring':effect+=' This is one fitted Earring; a second earring is a separate item and cannot share its active position.'
 if f=='Gem':effect+=' The original crystal and primary mounting form one body and ledger; loose, carried and weapon-mounted gems are not this worn assembly.'
 p.append(effect)
 p.append('| Operative tag | Actual ability checks | Actual saving throws |\n|---|---|---|\n'+registry[tag])
 p.append('Common exclusions: attack, damage, initiative, death-save, concentration, crafting-completion, formula-research, harvesting-extraction, repair, combat-maneuver. These predicates supply no missing roll, access, tool or permission. A later unrelated check is not qualified by an earlier poison, magical or other eligible event.')
 p.append('| Complete mundane body | gp | lb | Ordinary HP / structural AC | Legal designation |\n|---|---:|---:|---|---|\n'+f'| {body} | {bgp} | {blb} | 5 / {ac} | {slot} |')
 p.append(f'**Body and reserve:** Reserve {3*q//2} actual complete mundane functional bodies in stable physical-ID order. One model, fitted size and Standard grade; no prior magical alteration. Latest lawful completion HP/condition controls. Missing, Broken, incomplete or unavailable reserves pause before the roll; replacement retains the same position. Transform the first resolved N with no post-roll selection. Unused bodies remain mundane objects, not recovered ingredients. Large doubles only body gp/lb/ordinary HP. One Action each to don/doff or lawfully redesignate; actual clearance, supporting host and cross-trade position conflicts still govern.')
 p.append('**Source component occurrences:**')
 table='| # | Component | Quantity | Tier | Role | Consumed | Unit lb | Unit gp | Properties |\n|---|---|---:|---:|---|---|---:|---:|---|'
 for i,(c,cq,ct,role,w,v,props) in enumerate(components[n]):table+=f'\n| {i} | {c} | {cq} | {ct} | {role} | True | {w} | {v} | {props} |'
 p.append(table)
 cats=[str(i) for i,r in enumerate(components[n]) if r[3]=='catalyst']
 ctext='All listed occurrences are mandatory process inputs paid once per batch, separately from reserved bodies. Finished body mass is the actual selected body mass; no extra body or saleable waste is created. '
 ctext+=(f'Masterwork may retain at most one eligible actual catalyst unit total from component indices {", ".join(cats)}; retain identity, age, condition and remaining shelf life. Choose after the roll; participation is not premature destructive consumption. All other eligible units are consumed.' if cats else 'No component in this formula is an eligible catalyst; no catalyst return occurs.')
 ctext+=' Failed recovery excludes catalysts; Mishap/abandonment return none. Names and categories cannot change roles.'
 p.append(ctext)
 p.append(f"**Work and tools:** Choose DEX or INT before work; actual Jeweler's-tools credential, Jeweler's toolkit, Jeweler's Bench, Fine files and Magnifying lens. Source requiredTools: Jeweler's tools, Fine files, Magnifying lens. Actual documented compatible implements may overlap; ownership grants no proficiency or bonus. Source fieldCraftable=false controls despite timeMode={mode}. Source time {time}; {h} active hours, first included stable phase {min(8,h)} hours. Eligible Forge Dwarf creation {45*h} whole active minutes, first phase {min(480,45*h)} minutes. Maximum assistants {assist}. Actual station access, Watches, rest and lawful incorporation/preservation remain required.")
 sources=(['trainer','starter manual','common experimentation'] if level<=4 else ['guild trainer','faction vendor','uncommon dungeon book','reverse engineering'] if level<=8 else ['rare recipe drop','specialist commission','dungeon library','successful experimentation'] if level<=12 else ['forbidden archive','named master crafter','Gate-zone research','complex reverse engineering'] if level<=16 else ['sealed library','world event','Gate Guardian cache','multiseason research'])
 access={'sources':sources,'minimumResearchHours':research,'requiresFormula':level>4,'formulaConsumed':False}
 p.append(f'**Access and progression:** {json.dumps(access)}. Exact trivialAtSkillLevel={trivial}; do not regenerate level+5. Apply framework training/formula gates; trade level is never added to the roll. Untouched, replacement and recoverable catalyst lots retain their own clocks, and replacement grants no input or phase refund.')
 flawed=('1 with one persistent singleton structural flaw' if q==1 else f'{q//2} with ordinary effects and all existing flaws')
 p.append(f'**Quality:** Standard {q}; Exceptional yield {5*q//4}; Masterwork yield {3*q//2}; or {q} bodies with the strongest legal 25%/50% durability improvement. Flawed {flawed}. Failed/Mishap transform none. Select yield or durability once per batch. Apply the strongest noncompounding percentage to ordinary size-adjusted HP, then one flaw last, preserving latest damage deficit. A functional damaged body can emerge Broken. Tag, flat bonus, charges, dawn, grade and permission never improve through quality.')
 p.append(f'**Charges:** Maximum {charges}; initialize current to {charges} once at first lawful imprint creation, including Broken output. Mark each before-dice roll transaction once. Refill at the shared fixed 06:00 campaign dawn only when complete, positive-HP and unsuppressed, including stowed/melded states. Mark ineligible dawns processed; no catch-up. Transfers, repair, fitting, suppression ending and new scenes preserve the ledger. Melded items cannot grant bonuses or spend. On return, existing external equipment and the recorded position govern, otherwise lawful carried/drop/pending placement; preserve actual elevation.')
 required='original crystal and original primary mounting' if f=='Gem' else 'original primary body and all prerecorded required original stones/primary settings'
 p.append(f"**Repair:** Actual Jeweler's-tools proficiency, toolkit, bench, Fine files and Magnifying lens; choose DEX or INT. Functional HP≥1: DC10, max(1 hour, recorded maximum HP/10), materials25% undamaged mundane body reference. Broken HP0: DC{dc}, max(8 hours, recorded maximum HP/10), materials25% undamaged finished unit reference. Require {required}. Subordinate links/pins/closures may be replaced; missing primary bodies/settings/required stones cannot. Core binary success restores recorded maximum HP; failure consumes work/materials. No formula/original trade-level requirement, XP, quality roll, catalyst return, flaw removal or Forge Dwarf repair reduction. Preserve identity, fit, grade, durability, flaw, current/max charges and dawn history. Actual state at any intervening dawn governs; no repair refill.")
 p.append(f'**Ordinary finished unit reference:** {observed[n][0]} gp; Large fitted body {observed[n][1]} gp. Source Standard batch/Q plus actual undamaged body reference, not final yield. Do not add process materials or toolkit purchases again. Exact fractions persist until a real transaction; buy up/sell down to copper. Owned reserves need no repurchase. Depletion/damage/flaws grant no automatic sale or repair discount, guaranteed buyer, melt value, artifact multiplier or standard mundane buyback.')
 p.append(f'**Preserved tags:** {secondaries.get(n,tag)}. Names and donor metadata supply no unprinted power or available ingredient.')
 if n in starts:p.append('**Public V5 source paragraphs:** '+', '.join(str(i) for i in range(starts[n],starts[n]+6))+'.')
 p.append('**Preserved inactive metadata:** '+json.dumps({'legacyName':legacyname,'legacyEffect':legacyeffect} if n<648 else {'wholeCreatureUse':False}))
 if n not in starts and n<648:p.append('**Preserved optional Director guidance:** '+json.dumps(legendary if n>=277 else guidance,ensure_ascii=False))
 blocks[n]=p
header=['# Jewelcrafting internal recipe cards','**DRAFT — exact review pending.** Internal: all 43 formulas, including one restricted and sixteen Director-only records.','Every card uses the complete [shared guide](JEWELCRAFTING_INTERNAL_GUIDE.md). Full preserved source objects accompany the JSON.']
internal='\n\n'.join(header+[p for n,*_ in source_rows for p in blocks[n]])+'\n'
publicheader=['# Jewelcrafting public recipe cards','**DRAFT — exact review pending.** Public: 26 formulas with their nine body models and twelve operative tags.','Every card uses the complete [shared guide](JEWELCRAFTING_RECIPE_PLAYTEST.md). Full preserved source objects accompany the JSON.']
public='\n\n'.join(publicheader+[p for n,*_ in source_rows if n in starts for p in blocks[n]])+'\n'
expected={'internal':'097b406eccfd76548971351592b60f928d39a115570fda4823b933e061bdcf2a','public':'e1b771a57bdf71a8e8827706d111292c580ae0094675b7a164bd5edfa2f98ee3'}
report={}
for k,s in [('internal',internal),('public',public)]:
 p=ROOT/f'submitted_{k}_cards_reconstructed.md';p.write_text(s,encoding='utf-8')
 h=hashlib.sha256(p.read_bytes()).hexdigest()
 report[k]={'characters':len(s),'bytes':p.stat().st_size,'sha256':h,'supplied_sha256':expected[k],'matches_supplied_hash':h==expected[k]}
(ROOT/'manuscript_reconstruction_results.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps(report,indent=2))
