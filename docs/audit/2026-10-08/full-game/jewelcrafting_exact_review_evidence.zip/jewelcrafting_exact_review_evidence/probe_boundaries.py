"""Reviewer probes using the supplied excerpts, not Codex's full validator.
Only the NEW test events and their stated world premises are synthetic.
Item numerical profiles are taken from the submitted records.
"""
from pathlib import Path
from copy import deepcopy
import json
import ledger_excerpts as l
import qualification_excerpts as q
import tailoring_current_excerpts as t
l.validate_designations=q.validate_designations
l.qualifies=q.qualifies
q.tailor=t

def jewel(recipe, family, tag, bonus, charges, slot):
    return {'id':f'actual-{recipe}','recipeId':f'recipe-{recipe}',
        'trade':'Jewelcrafting','family':family,'tag':tag,'bonus':bonus,
        'maximumCharges':charges,'state':'worn','wearer':'A','slot':slot,
        'slotValid':True,'fit':True,'complete':True,'hp':5,'maximumHP':5,
        'suppressed':False,'physicalCompatibilityEstablished':True,
        'actualHostSupport':True}

def event(item, event_id, kind, ability, skill, predicate, at):
    return {'id':event_id,'kind':kind,'actualRoll':True,'actor':'A',
        'ability':ability,'proficiency':skill,'categories':[],
        'conscious':True,'incapacitated':False,'voluntaryActivationAllowed':True,
        'phase':'before-commit','resultRevealed':False,'campaignTime':at,
        'itemPremises':{item['id']:{'actualCausalPredicateEstablished':True,
        'predicateIds':[predicate]}}}

fire=jewel(258,'Earring','Fire',1,2,'ear-adornment')
e=event(fire,'save-after-dawn','saving-throw','DEX',None,'fire-damage',11)
history={'id':fire['id'],'recordedAt':10,'complete':True,'hp':5,
    'suppressed':False,'primaryDestroyed':False,'state':'worn'}
initial=l.initialize(l.new_ledger('review-probe',10),fire,'creation',0,
    processed_dawn_through=None)
# Both snapshots are truthful. The defect is acceptance of the wrong processing order.
late=l.commit_charge(initial,[fire],fire['id'],e)
late=l.dawn(late,fire['id'],0,10,history)
ordered=l.dawn(initial,fire['id'],0,10,history)
ordered=l.commit_charge(ordered,[fire],fire['id'],e)
result={'late_dawn_after_spend':{
    'chronological_order_current':ordered['items'][fire['id']]['current'],
    'accepted_out_of_order_current':late['items'][fire['id']]['current'],
    'defect_confirmed':late['items'][fire['id']]['current']!=ordered['items'][fire['id']]['current']}}

stealth=jewel(241,'Bracelet','Stealth',1,1,'wrist-adornment')
clothes={'id':'actual-recipe-584','recipeId':'recipe-584',
    'model':'tailoring.garment-common','trade':'Tailoring','family':'Garment',
    'bonus':3,'state':'worn','wearer':'A','slot':'body-clothing','slotValid':True,
    'fit':True,'complete':True,'hp':5,'suppressed':False}
current=event(stealth,'current-hide','ability-check','DEX','Stealth',
    'legal-hide-or-unnoticed-motion',20)
# This record truthfully describes an earlier, different check, with the same
# actor/ability/proficiency, where the garment did contribute.
earlier={'id':'earlier-hide','kind':'ability-check','actualCheck':True,'actor':'A',
    'ability':'DEX','proficiency':'Stealth','domain':'visual-concealment',
    'itemPremises':{clothes['id']:{'domainCriteriaMet':True,'actualContribution':True,
    'coverageSufficient':True,'legalHiding':True}}}
wrong=q.combined_check_bonus([stealth,clothes],current,earlier)
proper=deepcopy(earlier);proper['id']='current-hide'
proper['itemPremises'][clothes['id']]['actualContribution']=False
right=q.combined_check_bonus([stealth,clothes],current,proper)
result['mismatched_event_identity']={'current_jewel_only_bonus':right,
    'accepted_earlier_garment_bonus':wrong,'defect_confirmed':wrong!=right}
no_roll=deepcopy(current);no_roll['actualRoll']=False
result['mismatched_roll_existence']={'returned_bonus':
    q.combined_check_bonus([stealth,clothes],no_roll,earlier),
    'expected':'reject inconsistent descriptors or return no bonus'}
automatic=deepcopy(current);automatic['automaticResult']=True
result['mismatched_automatic_result']={'returned_bonus':
    q.combined_check_bonus([stealth,clothes],automatic,earlier),
    'expected':'reject inconsistent descriptors or return no bonus'}
# A positive serial/dedup baseline ensures the probe is not reporting all calls as failures.
try:l.commit_charge(ordered,[fire],fire['id'],e)
except ValueError: result['same_roll_duplicate_charge_rejected']=True
else: result['same_roll_duplicate_charge_rejected']=False
print(json.dumps(result,indent=2))
with open(Path(__file__).with_name('probe_results.json'),'w',encoding='utf-8') as f:
    json.dump(result,f,indent=2);f.write('\n')
