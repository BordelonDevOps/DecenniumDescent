"""Verbatim ledger functions from the user-supplied Jewelcrafting reference.
Only new_ledger, initialize, commit_charge and dawn are copied below.
The caller installs the separately supplied designation/qualification predicates.
"""
from copy import deepcopy
from fractions import Fraction as F
from math import ceil

def new_ledger(campaign,epoch):
    return {'campaignId':campaign,'epoch':epoch,'items':{},'rollSpenders':{},'rollEffects':{}}

def initialize(ledger,item,creation_id,created_at,*,processed_dawn_through):
    if item['id'] in ledger['items']:raise ValueError('physical imprint already initialized')
    maximum=item['maximumCharges']
    if not isinstance(maximum,int) or not 1<=maximum<=6:raise ValueError('invalid source charge maximum')
    # The authoritative campaign scheduler supplies its already-processed
    # checkpoint, especially when creation coincides with a dawn timestamp.
    n=(created_at-ledger['epoch'])//86400
    allowed={None} if n<0 else {n}
    if created_at==ledger['epoch']+n*86400 and n>=0:allowed.add(n-1 if n else None)
    if processed_dawn_through not in allowed:raise ValueError('creation lacks correct campaign dawn checkpoint')
    d=deepcopy(ledger);d['items'][item['id']]={'recipeId':item['recipeId'],'maximum':maximum,'current':maximum,'creationId':creation_id,'createdAt':created_at,'createdAfterProcessedDawn':processed_dawn_through,'lastDawn':processed_dawn_through,'dawnEvents':[],'spends':[]};return d

def commit_charge(ledger,items,item_id,event):
    validate_designations(items)
    chosen=next((r for r in items if r['id']==item_id),None)
    if not chosen or not qualifies(chosen,event):raise ValueError('ineligible item or event')
    if not event.get('conscious') or event.get('incapacitated') or not event.get('voluntaryActivationAllowed'):raise ValueError('voluntary activation unavailable')
    if event.get('phase')!='before-commit' or event.get('resultRevealed'):raise ValueError('too late')
    if not event.get('id'):raise ValueError('missing actual roll identity')
    if event['id'] in ledger['rollSpenders']:raise ValueError('event already has a Jewelcrafting expenditure')
    state=ledger['items'].get(item_id)
    if not state or state['recipeId']!=chosen['recipeId'] or state['maximum']!=chosen['maximumCharges'] or state['current']<1:raise ValueError('charge unavailable or imprint mismatch')
    if event.get('canceledBeforeCommit'):return deepcopy(ledger)
    d=deepcopy(ledger);d['items'][item_id]['current']-=1;d['items'][item_id]['spends'].append(event['id']);d['rollSpenders'][event['id']]=item_id
    d['rollEffects'][event['id']]={'advantageGranted':True,'sourcePhysicalItem':item_id,'sameEventSecondExpenditureAllowed':False,'scope':'ordinary cancellation and replacement procedure govern dice'}
    return d

def dawn(ledger,item_id,index,at_time,actual_state_at_event):
    if not isinstance(index,int) or index<0 or at_time!=ledger['epoch']+index*86400:raise ValueError('not an authoritative dawn event')
    s=ledger['items'][item_id]
    if at_time<s['createdAt']:raise ValueError('dawn predates imprint')
    if s['lastDawn'] is not None and index<=s['lastDawn']:raise ValueError('replayed or out-of-order dawn')
    if actual_state_at_event.get('id')!=item_id or actual_state_at_event.get('recordedAt')!=at_time:raise ValueError('missing actual event-state history')
    if any(k not in actual_state_at_event for k in ('complete','hp','suppressed','primaryDestroyed')):raise ValueError('incomplete historical state')
    if s['lastDawn'] is not None and index!=s['lastDawn']+1:raise ValueError('resolve intervening dawn states first')
    first=max(0,ceil(F(s['createdAt']-ledger['epoch'],86400)))
    if s['lastDawn'] is None and index!=first:raise ValueError('resolve first elapsed dawn before later events')
    state=actual_state_at_event
    eligible=(state.get('complete') and state.get('hp',0)>0 and not state.get('suppressed') and not state.get('primaryDestroyed'))
    d=deepcopy(ledger);z=d['items'][item_id];z['lastDawn']=index;z['dawnEvents'].append({'index':index,'time':at_time,'refilled':bool(eligible),'state':deepcopy(state)})
    if eligible:z['current']=z['maximum']
    return d
