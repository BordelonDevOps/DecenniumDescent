"""Verbatim supplied helper functions; constants transcribed from Part A.
CHECKS and SAVES here are the exact Stealth and Fire subsets used by the probes,
not a reproduction or validation of the entire fourteen-tag registry.
"""
SLOTS={'Bracelet':['wrist-adornment'],'Earring':['ear-adornment'],'Crown':['head'],
'Amulet':['neck-adornment'],'Ring':['ring-1','ring-2'],'Tiara':['head'],
'Necklace':['neck-adornment'],'Brooch':['chest-adornment'],'Gem':['chest-adornment'],
'Pendant':['neck-adornment']}
EXCLUSIONS=['attack','damage','initiative','death-save','concentration','crafting-completion','formula-research','harvesting-extraction','repair','combat-maneuver']
CHECKS={
'Stealth':[('DEX','Stealth','legal-hide-or-unnoticed-motion'),('DEX','Sleight of Hand','conceal-compatible-small-object')],
'Fire':[('INT','Nature','assess-flame-heat'),('INT','Arcana','assess-magical-flame-heat'),('WIS','Survival','present-fire-heat-hazard'),('STR','*','actual-fire-containment-extinguishing'),('DEX','*','actual-fire-containment-extinguishing'),('CON','*','heat-endurance')]}
SAVES={'Stealth':['explicit-detection-revelation-concealment-resistance'],
'Fire':['fire-damage','direct-burning-heat']}

def validate_designations(items):
    occupied={};hands=set();seen=set();counts={}
    for r in items:
        if r['id'] in seen:raise ValueError('duplicate physical identity')
        seen.add(r['id'])
        if r.get('state')!='worn' or not r.get('slotValid'):continue
        slot=r.get('slot');wearer=r.get('wearer');key=(wearer,slot)
        if key in occupied:raise ValueError('competing designated benefits')
        occupied[key]=r['id']
        if r.get('trade')!='Jewelcrafting':continue
        if slot not in SLOTS[r['family']]:raise ValueError('wrong jewel position')
        if not r.get('physicalCompatibilityEstablished'):raise ValueError('physical fit/anatomy/clearance not established')
        counts[wearer]=counts.get(wearer,0)+1
        if counts[wearer]>7:raise ValueError('too many active jewels')
        if r['family']=='Ring':
            hand=r.get('actualCompatibleHand')
            if not hand or (wearer,hand) in hands:raise ValueError('rings require different compatible hands')
            hands.add((wearer,hand))
    return occupied

def predicate_eligible(item,event):
    if not event.get('actualRoll') or event.get('automaticResult'):return False
    if set(event.get('categories',())).intersection(EXCLUSIONS):return False
    own=event.get('itemPremises',{}).get(item['id'],{})
    if not own.get('actualCausalPredicateEstablished'):return False
    predicates=set(own.get('predicateIds',()))
    tag=item['tag'];kind=event.get('kind');ability=event.get('ability');skill=event.get('proficiency')
    if kind=='ability-check':
        for a,s,p in CHECKS[tag]:
            amatch=ability==a if a!='CASTING' else event.get('actualSpellcastingAbilityCheck') is True
            if amatch and (s=='*' or skill==s) and p in predicates:return True
        return False
    if kind=='saving-throw':
        if tag=='Strength' and ability!='STR':return False
        if tag=='Vitality' and ability!='CON':return False
        return bool(predicates.intersection(SAVES[tag]))
    return False

def qualifies(item,event):
    return (item.get('trade')=='Jewelcrafting' and item.get('state')=='worn'
      and item.get('complete') and item.get('hp',0)>0 and not item.get('suppressed')
      and item.get('fit') and item.get('slotValid') and item.get('wearer')==event.get('actor')
      and item.get('physicalCompatibilityEstablished')
      and (item['family'] not in ('Brooch','Gem') or item.get('actualHostSupport'))
      and predicate_eligible(item,event))

def jewel_flat_bonus(items,event):
    validate_designations(items)
    return max((r['bonus'] for r in items if qualifies(r,event)),default=0)

def combined_check_bonus(items,event,older_trade_task,leather_task_ids=()):
    validate_designations(items)
    if event.get('kind')!='ability-check':raise ValueError('older trades have no save route')
    if older_trade_task.get('actor')!=event.get('actor') or older_trade_task.get('ability')!=event.get('ability') or older_trade_task.get('proficiency')!=event.get('proficiency'):raise ValueError('not the same actual check')
    others=[r for r in items if r.get('trade')!='Jewelcrafting']
    return max(jewel_flat_bonus(items,event),tailor.cross_trade_task_bonus(others,older_trade_task,leather_task_ids))
