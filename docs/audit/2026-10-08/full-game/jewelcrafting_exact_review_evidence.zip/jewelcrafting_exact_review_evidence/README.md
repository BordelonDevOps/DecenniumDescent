# Jewelcrafting exact-review evidence — INTERNAL

This archive includes Director-only card content. It is reviewer evidence, not a
public rule supplement or a companion-runtime implementation.

## Scope

The reviewed authority and candidate were supplied in the conversation. The
source-disposition Markdown was already present in this conversation's runtime;
its 49,702 characters and supplied SHA-256 were independently confirmed.

The full 43-card internal manuscript and 26-card public manuscript were separately
reconstructed from the supplied literal templates and per-card controls. Their
complete UTF-8 SHA-256 digests match the packet's reported manuscript digests.
The reconstruction does not modify those manuscripts to repair the findings.

The numeric audit recomputes 86 ordinary/Large values, 43 Forge Dwarf creation
times and 486 structural-state cases. Compact source rows are transcribed from
the provided source records. Full saved candidate JSON, full saved guide byte
comparisons and Codex's protected-file checks were NOT independently rerun.

The boundary probes copy the supplied ledger and qualification function bodies.
The qualification probe has only the exact Stealth and Fire registry subsets
needed by its cases; it does not claim to rerun all 69 submitted predicate cases.
The Tailoring excerpts are from the corrected dependency supplied in Part B, not
from the earlier, pre-repair reviewer archive. The Garment-only constants are
explicit test adapters. No Leatherworking items enter that reduced probe.

All world, causal, anatomical, scheduler-state and support facts in the probes
are declared premises. The probes do not establish those facts. The synthetic
clock labels are arithmetic fixtures, not new campaign rules or access grants.

`probe_results.json` records two confirmed interface defects and their boundary
variants. The scripts reproduce the submitted behavior; they do not implement
JC-ER01 or JC-ER02. The corrected DC19 Gem negative tests in `repair_results.json`
are reviewer probes, not a claim that Codex's test file has already been repaired.

## Reproduce

Use Python 3 and run these commands from this extracted folder:

```text
python probe_boundaries.py
python repair_probe.py
python numeric_audit.py
python reconstruct_manuscript.py
```

`reconstruct_manuscript.py` also imports/runs the numeric audit. A successful
probe execution can confirm a defect; read the expected/observed values rather
than treating process exit status as operational approval.

The exact review verdict is included unchanged. Conditions remain pending until
the author implements JC-ER01–JC-ER03 and completes the specified checks. No
repository push, source deletion, promotion, runtime installation, balance
approval or cosmology review was performed by this evidence preparation.
