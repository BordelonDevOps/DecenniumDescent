"""Source-bound repair comparison for recipe-268.
The submitted negative fixtures pass DC23 despite recipe-268's actual DC19.
The quotation helper itself accepts its caller-supplied numerical terms.
"""
from pathlib import Path
from fractions import Fraction as F
from types import SimpleNamespace
from copy import deepcopy
import json

def number(n): return F(str(n))

def repair_terms(current,maximum,base_value,finished_value,dc,pair=False,recoverable=True,both_members=True):
    if not recoverable or pair and not both_members:raise ValueError('generic reconstruction unavailable')
    if not 0<=current<=maximum:raise ValueError('invalid HP')
    return {'DC':10 if current>=1 else dc,'hours':max(F(1 if current>=1 else 8),F(maximum,10)),
            'materialsGp':number(base_value if current>=1 else finished_value)/4,'restoredMaximum':maximum}
leather=SimpleNamespace(repair_terms=repair_terms)

def repair_quote(item,base_value,finished_value,recipe_dc,premises):
    """Return a quotation only after supplied original-assembly/tool gates.
    No clock, material inventory, actual work or charge ledger is mutated.
    """
    required=['trained','actualToolkit','actualBench','actualFineFiles','actualLens','recoverableOriginalPrimary','requiredOriginalStonesSettingsPresent']
    if any(premises.get(k) is not True for k in required):raise ValueError('missing actual repair premise')
    if premises.get('ability') not in ('DEX','INT'):raise ValueError('choose DEX or INT')
    if item['family']=='Gem' and not (premises.get('originalCrystal') and premises.get('originalPrimaryMount')):raise ValueError('original Gem assembly missing')
    return leather.repair_terms(item['hp'],item['maximumHP'],base_value,finished_value,recipe_dc,recoverable=True)

item={'id':'actual-268','recipeId':'recipe-268','family':'Gem','hp':0,'maximumHP':5}
premises={k:True for k in ('trained','actualToolkit','actualBench','actualFineFiles','actualLens','recoverableOriginalPrimary','requiredOriginalStonesSettingsPresent','originalCrystal','originalPrimaryMount')}
premises['ability']='INT'
correct=repair_quote(item,F(2),F(4509),19,premises)
wrong=repair_quote(item,F(2),F(4509),23,premises)
checks={}
for missing in ('originalCrystal','originalPrimaryMount'):
 p=deepcopy(premises);p[missing]=False
 try:repair_quote(item,F(2),F(4509),19,p)
 except ValueError:checks[missing+'_rejected_using_correct_DC']=True
 else:checks[missing+'_rejected_using_correct_DC']=False
report={'correct_positive_quote':correct,'wrong_caller_DC_accepted_in_quote':wrong,'corrected_negative_gates':checks}
print(json.dumps(report,default=str,indent=2))
with open(Path(__file__).with_name('repair_results.json'),'w',encoding='utf-8') as f:json.dump(report,f,default=str,indent=2);f.write('\n')
