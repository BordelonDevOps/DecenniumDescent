# Complete language and communication candidate: exact review v1

Audience: INTERNAL joint review. This archive deliberately includes private source evidence. It is not a public distribution package.

Read these complete authored files first:
- DescentReviewChanges/ReviewBible/docs/mechanics/LANGUAGE_COMMUNICATION_PLAYTEST.md — full player chapter, 14 ancestry and20 background rows, new procedures labeled.
- DescentReviewChanges/ReviewBible/docs/mechanics/LANGUAGE_COMMUNICATION_WORKED_SEQUENCES.md — 32 concrete authored chronological adjudications.
- DescentReviewChanges/ReviewBible/docs/director-only/LANGUAGE_COMMUNICATION_INTERNAL_CANDIDATE.md — complete16-case application wording plus every selected class interface.
- DescentReviewChanges/ReviewBible/data/playtest/language_communication_candidate_public.json — full independent public envelope, 14/45/20 mappings, identity/mode/choice data, eight record contracts,49 class interfaces,23 spell comparisons,8 pending feat references and28 exact completed public Scribing cards.
- DescentReviewChanges/ReviewBible/data/director/language_communication_candidate_internal.json — complete source objects/engine contexts,15 spell routes,8 pending feat originals,40 Scribing cards and19 completed advanced sections, and the deferred LA16 receipt.

The original152 payloads are included at their original paths with identical bytes. ORIGINAL_SOURCE_V2_FILE_MANIFEST.json is their original manifest; the original source ZIP is also included so the reviewer read-only460-check script can run without reconstructing ZIP bytes. The full downloaded source verdict and all14 manifested reviewer files are under docs/audit/2026-10-08/full-game/language-source-reviewer-files. No live reasoning drafts were used as authority; only the final reply08f18635-6dea-4d41-8f11-19fafb1baf2c and its final package.

LANGUAGE_CANDIDATE_VALIDATION.json reports496 local checks, zero failures. These comprise static source/candidate/public parity plus20 finite reference arithmetic and18 finite reference boundary checks. The32 worked cases are authored semantic adjudications, NOT executed gameplay/runtime tests or human trials. The separate460 reviewer source checks reproduced with no failures. Record contracts are authored interfaces, not a deployed companion runtime or save migration.

The public envelope takes completed public recipe objects from the existing public artifact, never projects raw private recipe objects. Private or restricted Scribing membership/names are absent from that envelope. Published literal language names and restrictions remain, without new setting interpretation. Pending spells retain operational:null; feats and class review statuses are not promoted.

Please exact-review the actual complete candidate against all16 final source directions and all32 original expectations. Return bounded corrections with exact replacement wording and affected file/record paths where needed, or scoped authored-language approval. Do not reopen fulfilled NWX or687/433 recipe gates. No generic source conference is required. Whole-game flow, remaining catalogs, software runtime, human teaching/balance, push and post-push cosmology remain separate.

Builders in tools are one-time historical construction scripts and refuse an existing candidate. Do not run them over this frozen copy. validate_language_candidate.py is read-only on inputs and writes only its named validation report in a separately extracted workspace; the reviewer source validator reads the immutable source ZIP. Inspect any script before executing it.
