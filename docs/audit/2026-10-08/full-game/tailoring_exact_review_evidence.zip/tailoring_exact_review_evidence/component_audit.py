"""Arithmetic audit of all 190 printed Part B component rows.
Each compact row is quantity/tier/role/unitWeight/unitValue in original order.
This checks occurrence counts, roles, reusable profiles, and consumed totals;
it does not replace full-original JSON equality or verify undisplayed fields.
"""
from fractions import Fraction as F
from collections import Counter
from pathlib import Path
import json
# R reinforcement, B binder, M material, I ingredient, T reusable tool, S substrate.
DATA='''
546 5/1/R/.25/2 1/1/B/.1/2 1/1/B/.1/2 1/1/M/.43/8
547 3/2/B/.1/8 4/2/I/.1/8 1/1/M/.12/11
548 5/1/R/.25/2 1/1/T/1/6 1/1/M/.43/8
549 1/3/T/1/75 1/1/M/.29/12
550 5/1/I/.1/2 1/1/M/.38/9
551 5/2/R/.25/8 1/2/T/1/24 1/1/M/.29/12
552 4/2/R/.1/8 1/2/T/1/24 1/1/M/.81/15
553 1/1/T/1/6 1/1/T/1/6 1/1/M/.43/8
554 1/1/I/.1/2 1/1/T/1/6 4/1/S/.25/2 1/1/M/.75/14
555 2/3/I/.1/25 2/3/B/.1/25 5/3/R/.25/25 1/1/M/.5/10
556 5/2/R/.25/8 1/1/M/.57/10
557 2/3/R/.25/25 2/3/I/.1/25 1/1/M/.36/10
558 5/2/I/.1/8 1/1/M/.53/14
559 4/1/I/.1/2 1/1/M/.19/5
560 3/1/B/.1/2 3/1/I/.1/2 1/1/M/.75/14
561 4/4/R/.1/75 1/4/I/.1/75 1/3/M/.54/91
562 5/3/S/.25/25 1/3/T/1/75 1/3/T/1/75 1/3/I/.1/25 1/3/M/.58/54
563 2/4/R/.25/75 3/4/B/.1/75 3/4/B/.1/75 1/3/M/.54/123
564 1/4/T/1/225 1/4/R/.25/75 1/4/T/1/225 1/1/M/.75/14
565 4/5/I/.1/200 3/5/R/.25/200 1/5/B/.1/200 4/5/R/.1/200 1/2/M/.63/34
566 2/5/R/.25/200 4/5/R/.25/200 1/1/M/.29/12
567 3/5/R/.1/200 1/5/T/1/600 1/5/I/.1/200 2/5/B/.1/200 1/3/M/.58/54
568 1/3/T/1/75 2/3/I/.1/25 5/3/I/.1/25 4/3/R/.1/25 1/2/M/.45/31
569 2/4/R/.25/75 4/4/R/.1/75 5/4/B/.1/75 1/4/T/1/225 1/3/M/.54/91
570 1/6/I/.1/500 2/6/S/.25/500 1/6/T/1/1500 5/6/R/.25/500 1/3/M/.59/117
571 1/8/I/.1/3000 4/8/B/.1/3000 5/8/S/.25/3000 1/8/T/1/9000 1/3/M/.44/114
572 3/6/R/.25/500 1/6/T/1/1500 5/6/B/.1/500 1/4/M/.39/396
573 5/6/I/.1/500 2/6/B/.1/500 2/6/B/.1/500 3/6/I/.1/500 2/6/R/.25/500 1/3/M/.58/54
574 2/6/B/.1/500 4/6/I/.1/500 1/6/T/1/1500 1/2/M/.62/26
575 2/5/R/.25/200 1/5/I/.1/200 1/5/T/1/600 5/5/B/.1/200 1/3/M/.4/92
576 2/5/I/.1/200 1/5/T/1/600 2/5/B/.1/200 1/3/M/.59/117
577 1/9/S/.25/7500 3/9/I/.1/7500 5/9/R/.1/7500 3/9/I/.1/7500 1/4/M/.2/231 1/3/M/.58/54
578 4/8/R/.1/3000 5/8/R/.25/3000 2/8/I/.1/3000 5/8/B/.1/3000 4/8/I/.1/3000 2/8/B/.1/3000 1/3/M/.59/117 1/3/M/.34/89
579 4/8/I/.1/3000 5/8/I/.1/3000 2/8/R/.1/3000 1/8/S/.25/3000 1/4/M/.39/396 1/5/M/.26/656
580 5/9/I/.1/7500 2/9/R/.25/7500 5/9/B/.1/7500 1/9/T/1/22500 1/4/M/.2/231 1/3/M/.58/54
581 1/10/T/1/54000 2/10/I/.1/18000 4/10/B/.1/18000 5/10/I/.1/18000 4/10/R/.1/18000 1/5/M/.18/1434 1/6/M/.02/3758
582 1/10/R/.1/18000 1/10/T/1/54000 2/10/I/.1/18000 2/10/B/.1/18000 1/10/I/.1/18000 2/10/R/.25/18000 1/4/M/.09/419 1/3/M/.22/75
583 4/10/I/.1/18000 1/10/T/1/54000 5/10/R/.25/18000 2/10/R/.1/18000 3/10/R/.25/18000 1/5/M/.26/1361 1/6/M/.02/3758
584 1/10/S/.25/18000 4/10/R/.25/18000 1/10/T/1/54000 5/10/I/.1/18000 2/10/R/.1/18000 4/10/B/.1/18000 4/10/I/.1/18000 1/6/M/.13/4536 1/6/M/.16/4032 1/5/M/.1/737
680 1/3/M/.4/92 1/5/B/.1/200 1/5/R/.1/200 1/5/B/.1/200
681 1/1/M/.83/9 1/1/S/.25/2 1/1/I/.1/2 1/1/B/.1/2
682 1/3/M/.58/54 1/5/S/.25/200 1/5/R/.25/200 1/5/B/.1/200
683 1/6/M/.13/4536 1/1/M/.29/12 1/10/S/.25/18000 1/10/B/.1/18000 1/10/R/.1/18000
'''
# Independently supplied original economy consumed totals (gp, lb), Part A.
EXPECTED='''
546 22 1.88
547 67 .82
548 18 1.68
549 12 .29
550 19 .88
551 52 1.54
552 47 1.21
553 8 .43
554 24 1.85
555 235 2.15
556 50 1.82
557 110 1.06
558 54 1.03
559 13 .59
560 26 1.35
561 466 1.04
562 204 1.93
563 723 1.64
564 89 1
565 2434 2.28
566 1212 1.79
567 1254 1.18
568 306 1.55
569 916 1.94
570 4117 2.44
571 30114 2.19
572 4396 1.64
573 7054 2.28
574 3026 1.22
575 1692 1.5
576 917 .99
577 90285 2.13
578 66206 3.88
579 37052 2
580 90285 2.28
581 275192 1.7
582 144494 1.41
583 257119 2.88
584 369305 3.14
680 692 .7
681 15 1.28
682 654 1.18
683 58548 .87
'''
expected={int(l.split()[0]):tuple(map(F,l.split()[1:])) for l in EXPECTED.splitlines() if l}
roles=Counter();tools=[];totals=[];failures=[];n=0
for line in DATA.splitlines():
 if not line:continue
 rid,*entries=line.split();rid=int(rid);weight=value=F(0)
 for ordinal,entry in enumerate(entries):
  q,tier,role,w,v=entry.split('/');q=int(q);tier=int(tier);w=F(w);v=F(v)
  roles[role]+=1;n+=1
  if role=='T':tools.append({'recipeId':rid,'ordinal':ordinal,'quantity':q,'tier':tier,'unitLb':str(w),'unitGp':str(v)})
  else:weight+=q*w;value+=q*v
 if (value,weight)!=expected[rid]:failures.append({'recipeId':rid,'computed':[str(value),str(weight)],'expected':list(map(str,expected[rid]))})
 totals.append({'recipeId':rid,'consumedValueGp':str(value),'consumedWeightLb':str(weight)})
assert len(totals)==43 and n==190 and len(tools)==25
assert roles=={'R':38,'B':28,'M':53,'I':36,'T':25,'S':10}
assert all(t['quantity']==1 and t['unitLb']=='1' for t in tools)
price_by_tier={1:6,2:24,3:75,4:225,5:600,6:1500,8:9000,9:22500,10:54000}
assert all(F(t['unitGp'])==price_by_tier[t['tier']] for t in tools)
assert not failures,failures
out={'scope':__doc__,'recipes':43,'componentOccurrences':n,'consumedOccurrences':n-len(tools),'reusableToolOccurrences':len(tools),
     'roleCounts':dict(roles),'toolPriceDistribution':dict(Counter(t['unitGp'] for t in tools)),
     'tools':tools,'consumedTotals':totals,'failures':failures}
Path(__file__).with_name('component_results.json').write_text(json.dumps(out,indent=2))
print(json.dumps({k:v for k,v in out.items() if k not in ('tools','consumedTotals')},indent=2))
