"""Independent paragraph-routing audit of the supplied factored manuscript.
Uses per-paragraph field/content signatures transcribed from Part B; it does NOT
assert saved-file byte equality or reproduce original hashes. Each P dictionary
entry contains no double-newline paragraph split. The internal template has
three initial paragraphs; cards have 19, except the last (683), which has 18.
"""
import json
from pathlib import Path
from control_audit import rows,by,ordinary,models

# Supplied public internal-paragraph index map, copied as input.
MAP={"I4":3,"I5":4,"I6":5,"I7":6,"I8":7,"I9":8,"I10":9,"I11":10,"I12":11,"I13":12,"I14":13,"I15":14,"I16":15,"I17":16,"I18":17,"I19":18,"I20":19,"I21":20,"I22":21,"I23":22,"I24":23,"I25":24,"I26":25,"I27":26,"I28":27,"I29":28,"I30":29,"I31":31,"I32":33,"I33":34,"I34":35,"I35":36,"I36":37,"I37":38,"I38":39,"I39":40,"I40":41,"I41":42,"I42":43,"I43":44,"I44":45,"I45":46,"I46":48,"I47":50,"I48":54,"I49":55,"I50":56,"I51":58,"I52":59,"I53":60,"I54":61,"I55":62,"I56":63,"I57":64,"I58":65,"I59":67,"I60":69,"I61":72,"I62":73,"I63":75,"I64":76,"I65":77,"I66":78,"I67":79,"I68":80,"I69":88,"I70":93,"I71":94,"I72":95,"I73":96,"I74":97,"I75":98,"I76":99,"I77":100,"I78":101,"I79":103,"I80":105,"I81":107,"I82":109,"I83":110,"I84":111,"I85":113,"I86":115,"I87":116,"I88":117,"I89":118,"I90":126,"I91":128,"I92":132,"I93":133,"I94":134,"I95":135,"I96":136,"I97":137,"I98":145,"I99":148,"I100":150,"I101":151,"I102":152,"I103":153,"I104":154,"I105":155,"I106":156,"I107":164,"I108":170,"I109":171,"I110":172,"I111":173,"I112":174,"I113":175,"I114":183,"I115":189,"I116":190,"I117":191,"I118":192,"I119":193,"I120":194,"I121":202,"I122":208,"I123":209,"I124":210,"I125":211,"I126":212,"I127":213,"I128":221,"I129":227,"I130":228,"I131":229,"I132":230,"I133":231,"I134":232,"I135":240,"I136":246,"I137":248,"I138":249,"I139":250,"I140":259,"I141":265,"I142":267,"I143":268,"I144":269,"I145":270,"I146":278,"I147":284,"I148":286,"I149":287,"I150":288,"I151":289,"I152":297,"I153":299,"I154":300,"I155":302,"I156":303,"I157":305,"I158":306,"I159":307,"I160":308,"I161":309,"I162":310,"I163":312,"I164":316,"I165":318,"I166":322,"I167":324,"I168":325,"I169":326,"I170":327,"I171":335,"I172":337,"I173":338,"I174":340,"I175":341,"I176":342,"I177":343,"I178":344,"I179":345,"I180":346,"I181":354,"I182":360,"I183":362,"I184":363,"I185":364,"I186":365,"I187":373,"I188":376,"I189":379,"I190":381,"I191":382,"I192":383,"I193":384,"I194":392,"I195":395,"I196":397,"I197":398,"I198":400,"I199":401,"I200":402,"I201":403,"I202":411,"I203":417,"I204":419,"I205":420,"I206":421,"I207":422,"I208":430,"I209":433,"I210":435,"I211":436,"I212":438,"I213":439,"I214":440,"I215":441,"I216":449,"I217":455,"I218":457,"I219":458,"I225":470,"I233":480,"I234":481,"I246":511,"I265":549,"I268":554,"I269":555,"I270":563,"I271":569,"I272":571,"I273":572,"I274":573,"I275":574,"I276":582,"I277":584,"I278":588,"I279":590,"I280":591,"I359":744,"I360":745,"I361":746,"I362":747,"I363":748,"I364":749,"I365":753,"I366":759,"I367":761,"I368":762,"I369":763,"I370":764,"I371":765,"I372":766,"I373":767,"I374":768,"I375":772,"I376":778,"I377":780,"I378":782,"I379":784,"I380":785,"I381":791,"I382":797,"I383":799}
# Supplied public template references, grouped by its actual 19-paragraph cards.
REFS='''
546 I4 I5 I6 I7 I8 I9 I10 I11 I12 I13 I14 I15 I16 I17 I18 I19 I20 I21 I22
547 I23 I24 I25 I26 I27 I28 I29 I30 I12 I31 I14 I32 I33 I34 I35 I36 I37 I38 I39
548 I40 I41 I42 I43 I44 I45 I29 I46 I12 I47 I14 I32 I16 I48 I49 I50 I20 I51 I52
549 I53 I54 I55 I56 I57 I58 I29 I59 I12 I60 I14 I32 I61 I62 I18 I63 I64 I65 I66
550 I67 I68 I25 I26 I27 I28 I29 I11 I12 I69 I14 I32 I16 I17 I70 I71 I72 I73 I74
551 I75 I76 I77 I78 I27 I79 I29 I80 I12 I81 I14 I82 I83 I84 I18 I85 I64 I86 I87
552 I88 I89 I6 I7 I8 I9 I10 I80 I12 I90 I14 I91 I83 I84 I35 I92 I93 I94 I95
553 I96 I97 I25 I26 I27 I28 I29 I30 I12 I98 I14 I32 I99 I34 I100 I101 I102 I103 I104
554 I105 I106 I55 I56 I57 I58 I29 I59 I12 I107 I14 I91 I99 I62 I100 I108 I109 I110 I111
555 I112 I113 I77 I78 I27 I79 I29 I11 I12 I114 I14 I91 I61 I17 I70 I115 I116 I117 I118
556 I119 I120 I77 I78 I27 I79 I29 I59 I12 I121 I14 I32 I33 I62 I70 I122 I123 I124 I125
557 I126 I127 I42 I43 I44 I45 I29 I30 I12 I128 I14 I82 I61 I34 I18 I129 I130 I131 I132
558 I133 I134 I42 I43 I44 I45 I29 I11 I12 I135 I14 I15 I83 I17 I35 I136 I116 I137 I138
559 I139 I68 I42 I43 I44 I45 I29 I11 I12 I140 I14 I91 I16 I17 I70 I141 I123 I142 I143
560 I144 I145 I77 I78 I27 I79 I29 I59 I12 I146 I14 I15 I99 I62 I70 I147 I109 I148 I149
561 I150 I151 I42 I43 I44 I45 I29 I59 I12 I152 I14 I153 I154 I62 I155 I156 I72 I157 I158
562 I159 I160 I161 I162 I27 I163 I29 I59 I12 I164 I14 I165 I61 I62 I155 I166 I20 I167 I168
563 I169 I170 I77 I78 I27 I79 I29 I59 I12 I171 I14 I172 I173 I62 I174 I175 I176 I177 I178
564 I179 I180 I161 I162 I27 I163 I29 I59 I12 I181 I14 I172 I173 I62 I155 I182 I109 I183 I184
565 I185 I186 I161 I162 I27 I163 I29 I59 I12 I187 I14 I153 I188 I62 I155 I189 I102 I190 I191
566 I192 I193 I55 I56 I57 I58 I29 I59 I12 I194 I14 I153 I195 I62 I196 I197 I64 I198 I199
567 I200 I201 I25 I26 I27 I28 I29 I59 I12 I202 I14 I153 I188 I62 I196 I203 I20 I204 I205
568 I206 I207 I77 I78 I27 I79 I29 I59 I12 I208 I14 I165 I209 I62 I210 I211 I123 I212 I213
569 I214 I215 I77 I78 I27 I79 I29 I59 I12 I216 I14 I153 I173 I62 I196 I217 I72 I218 I219
575 I268 I269 I233 I234 I27 I79 I29 I59 I12 I270 I14 I225 I195 I62 I265 I271 I123 I272 I273
576 I274 I275 I233 I234 I27 I79 I29 I59 I12 I276 I14 I277 I195 I62 I246 I278 I130 I279 I280
680 I359 I360 I361 I362 I363 I364 I29 I59 I12 I365 I14 I153 I154 I62 I196 I366 I176 I367 I368
681 I369 I370 I371 I372 I373 I374 I29 I59 I12 I375 I14 I32 I16 I62 I100 I376 I20 I377 I368
682 I378 I360 I379 I380 I27 I28 I29 I59 I12 I381 I14 I153 I154 I62 I196 I382 I20 I383 FALSE_META
'''
TAGS='''546 Stealth
547 Unholy
548 Stealth
549 Vitality
550 Fire
551 Vitality
552 Arcane
553 Acid
554 Cold
555 Air
556 Earth
557 Lightning
558 Air
559 Earth
560 Cold
561 Fire
562 Stealth
563 Strength
564 Cold
565 Acid
566 Vitality
567 Stealth
568 Earth
569 Fire
570 Lightning
571 Poison
572 Flora
573 Acid
574 Arcane
575 Earth
576 Lightning
577 Acid Arcane
578 Vitality Lightning
579 Flora Air
580 Acid Psychic
581 Air Lightning
582 Earth Strength
583 Air Arcane
584 Vitality Water Acid
680 Strength
681 Stealth
682 Stealth
683 Flora'''
tags={int(l.split()[0]):tuple(l.split()[1:]) for l in TAGS.splitlines()}
V5={546:2983,547:2997,548:2990,549:3053,550:2969,551:3025,552:3018,553:2941,554:2955,555:3032,556:3004,557:3039,558:3011,559:2976,560:2948,561:3102,562:3046,563:3081,564:3074,565:3109,566:3137,567:3116,568:3060,569:3067,575:3123,576:3130,680:3095,681:2962,682:3088}
from tailoring_constants import FAMILY_TASKS

def rarity(r):
 if r['id'] in (680,682):return 'Rare'
 if r['id']==681:return 'Common'
 if r['id']==683:return 'Mythic'
 if r['id']<=560:return 'Common'
 if r['id']<=569:return 'Uncommon'
 if r['id']<=576:return 'Rare'
 if r['id']<=580:return 'Very Rare'
 if r['id']<=583:return 'Legendary'
 return 'Mythic'

def time_text(r):
 h=r['hours']
 if r['id'] in (563,564):return '1 day'
 if r['id']==573:return '2 weeks'
 if h is None:return '1 year'
 return {16:'2 days',24:'3 days',40:'1 week',80:'10 days',160:'1 month',320:'2 months',480:'3 months'}.get(h,str(h)+' '+('hour' if h==1 else 'hours'))

def access(r):
 if r['level']<=4:return ('basic',0,False,r['trivial'])
 if r['id'] in (571,578,579):return ('forbidden',28 if r['id'] in (571,578) else 32,True,r['trivial'])
 if r['id'] in (577,580,581,582,583,584,683):
  return ('sealed',{577:36,580:36,581:44,582:48,583:44,584:48,683:48}[r['id']],True,r['trivial'])
 if r['id'] in (565,566,567,570,572,573,574,575,576):
  return ('rare',{565:4,566:8,567:4,570:12,572:16,573:12,574:16,575:8,576:8}[r['id']],True,r['trivial'])
 return ('guild',0,True,r['trivial'])

def card_signatures(r):
 rid=r['id'];q=r['Q'];m=tuple(models(r));family=r['family']
 op_extra={ 'Gloves':'both members','Hat':'head exposure','Garment':'outfit constituents'}.get(family,'')
 if rid==582:op_extra+=';magical bludgeoning'
 if rid in (680,681,682,683):op_extra+=';special-'+str(rid)
 result=[('heading',rid),('status',r['visibility'],r['level'],r['tier'],rarity(r),r['DC'],q),
         ('source-effect',family,r['task'],r['resistance'],r['relief']),
         ('operational',family,r['task'],r['resistance'],r['relief'],op_extra),
         ('domains',tuple(FAMILY_TASKS[family])),('body',m),('bag-geometry',r['relief'] if family=='Bag' else None),
         ('reserve',3*q//2),('component-heading',),('component-table',rid),('process-tools',),
         ('work',r['mode'],time_text(r),r['hours'],r['assistants']),('access',*access(r)),
         ('quality',q),('repair',r['DC']),('value',m,tuple(map(str,ordinary[rid]))),('tags',tags[rid])]
 if r['visibility']=='public':result.append(('V5-paragraphs',tuple(range(V5[rid],V5[rid]+6))))
 result.append(('metadata-whole-creature',rid==683) if rid>=680 else ('legacy-metadata',rid))
 if r['visibility']!='public' and rid!=683:result.append(('optional-guidance','legendary' if rid>=581 else 'deep'))
 return result
internal=[('internal-title',),('internal-status',),('internal-intro',)]
start={};owner={}
for r in rows:
 start[r['id']]=len(internal)
 sig=card_signatures(r)
 for n in range(len(sig)):owner[len(internal)+n]=r['id']
 internal.extend(sig)
assert len(internal)==819
failures=[];routes=[];reference_count=0
for l in REFS.splitlines():
 if not l:continue
 rid,*refs=l.split();rid=int(rid)
 expected=card_signatures(by[rid]);assert len(refs)==len(expected)==19
 for offset,(ref,e) in enumerate(zip(refs,expected)):
  if ref=='FALSE_META':actual=('metadata-whole-creature',False);index=None
  else:
   reference_count+=1;index=MAP[ref];actual=internal[index]
  ok=actual==e
  if not ok:failures.append({'recipe':rid,'offset':offset,'ref':ref,'index':index,'actual':actual,'expected':e})
  routes.append({'recipe':rid,'cardParagraphOffset':offset,'ref':ref,'internalIndex':index,'sourceCard':owner.get(index),'category':actual[0],'match':ok})
used={x['ref'] for x in routes if x['ref']!='FALSE_META'}
assert used==set(MAP)
assert reference_count==550
private_reuse=[r for r in routes if r['sourceCard'] and by[r['sourceCard']]['visibility']!='public']
out={'scope':__doc__,'internalParagraphs':len(internal),'publicParagraphs':3+len(routes),
     'publicCards':len([l for l in REFS.splitlines() if l]),'paragraphReferences':reference_count,
     'literalFinalMetadataParagraphs':1,'uniqueReferenceKeys':len(MAP),'mismatches':failures,
     'privateCardGenericParagraphReuse':private_reuse,'routes':routes}
Path(__file__).with_name('projection_results.json').write_text(json.dumps(out,indent=2))
print(json.dumps({k:v for k,v in out.items() if k!='routes'},indent=2))
assert not failures,failures
