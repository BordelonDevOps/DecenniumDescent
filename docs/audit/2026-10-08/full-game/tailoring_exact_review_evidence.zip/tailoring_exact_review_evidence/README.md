# Tailoring exact-review evidence

INTERNAL REVIEW MATERIAL. This archive includes restricted/Director-only recipe control fields and must not be placed in the player-facing projection.

## Scope

This review examined the supplied Parts A and B, including their authoring verdict, shared guides, factored source records, operational fields, exact manuscript paragraphs and public reference routing. These files are reviewer transcriptions and isolated calculations, not the user's saved candidate files or a companion runtime.

No original working-copy hash, source-file byte equality, 53-protected-file comparison, or execution of the complete reported 120-check local validator is claimed. The unavailable builder imports were replaced only with constants transcribed from the supplied envelope for bounded helper tests. Paragraph routing uses field/content signatures rather than a byte-for-byte saved-manuscript reconstruction.

## Results

- 43 source/control rows: quantity, work/phase, assistant and threshold calculations agree with submitted operational controls.
- 91 ordinary and 91 Large-profile finished-value examples agree with source batch/Q plus the applicable body reference. Bags do not grow with fitting.
- 190 displayed component rows reconcile to 165 consumed occurrences and 25 reusable tool occurrences; all 43 consumed-value/weight totals agree.
- 15 internal and 11 public body models; source visibility is 29 public / 4 restricted / 10 Director-only.
- 819 internal paragraph positions; 554 public paragraph positions. All 550 public references, plus the final literal metadata paragraph, route consistently. Seven references reuse generic, matching paragraphs first occurring on private cards; they do not import those private cards.
- The 558-state durability sweep passed against a separately tabulated maximum-HP oracle.
- Forty complete-order quantity/option combinations passed ordered identity, unused-body and singleton-flaw checks.
- 396 predicate/fixture assertions passed. This count includes the summary assertions for the durability sweep and order enumeration; do not add them as disjoint sets of assertions.
- Two separate helper defects were reproduced: task-wide contribution/visibility admits a noncontributing higher-bonus garment; the cross-trade wrapper selects a container's wearer ahead of its actual operator.
- The supplied bag-10-inside-bag-10 fixture has no admitted fit under the stated envelopes. An explicit reviewed Backpack/inner Bag replacement was tested successfully.

Passing invariant tests do not erase the reproduced defects. The final response supplies the finite repair conditions and promotion boundary.

## Files

`control_audit.py` and `control_results.json`: independent source/manuscript/control transcriptions and exact rational arithmetic.

`component_audit.py` and `component_results.json`: all displayed component numerical/role occurrences and independently supplied original consumed totals.

`projection_audit.py` and `projection_results.json`: public reference indices and per-card paragraph routing, not byte equality.

`leatherworking_reference.py`, `tailoring_reference.py`: supplied bounded function bodies copied for review, with explanatory scope headers. `tailoring_constants.py` is an explicit import adapter, not the original builder.

`behavior_audit.py` and `behavior_results.json`: valid source-bound fixtures, independent expectations, sweep, and reproduced counterexamples. Item contribution and physical fit remain explicit governing-system premises.

`leatherworking_fixture_provenance.json`: relevant controls from the already available prior reviewer archive, used to identify legal cross-trade fixtures. It is not the original Leatherworking catalog.

## Running

Run the four audit scripts with Python 3 from this directory. They require only the standard library. Counterexamples are deliberately recorded as reproduced findings rather than hidden in the invariant-test pass count.
