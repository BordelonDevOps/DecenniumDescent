"""Reviewer transcriptions of supplied Tailoring Parts A/B control fields.
Not the original recipe JSON, not a working-copy hash or byte-equality check.
Source controls and manuscript examples were transcribed separately.
"""
from pathlib import Path
from fractions import Fraction as F
from collections import Counter
import json
# id family Q level tier DC hours mode assistants trivial task resistance relief batch_value visibility
SOURCE = '''
546 Bag 2 2 1 12 8 expedition 0 7 1 - 10 64 public
547 Cloak 3 3 2 9 2 field 0 8 1 - 0 93 public
548 Gloves 5 2 1 11 2 field 0 7 1 - 0 52 public
549 Hat 1 5 3 12 2 field 0 10 1 - 0 60 public
550 Cloak 2 2 1 8 2 field 0 7 1 - 0 54 public
551 Garment 4 4 2 12 4 expedition 0 9 1 - 0 78 public
552 Bag 4 4 2 9 1 field 0 9 1 - 10 65 public
553 Cloak 3 1 1 10 2 field 0 6 1 - 0 48 public
554 Hat 1 1 1 10 1 field 0 6 1 - 0 58 public
555 Garment 2 5 3 8 1 field 0 10 1 - 0 320 public
556 Garment 1 3 2 8 2 field 0 8 1 - 0 70 public
557 Gloves 3 5 3 12 4 expedition 0 10 1 - 0 158 public
558 Gloves 2 4 2 9 8 expedition 0 9 1 - 0 89 public
559 Gloves 2 2 1 8 1 field 0 7 1 - 0 47 public
560 Garment 1 1 1 8 8 expedition 0 6 1 - 0 50 public
561 Gloves 1 8 4 15 16 workshop 0 13 1 - 0 693 public
562 Robe 1 5 3 15 24 workshop 0 10 1 - 0 335 public
563 Garment 1 7 4 17 8 expedition 0 12 1 - 0 1004 public
564 Robe 1 7 4 15 8 expedition 0 12 1 - 0 260 public
565 Robe 1 9 5 15 16 workshop 0 14 1 - 0 3358 public
566 Hat 1 10 5 16 16 workshop 0 15 1 - 0 1716 public
567 Cloak 1 9 5 16 16 workshop 0 14 1 - 0 1765 public
568 Garment 1 6 3 14 24 workshop 0 11 1 - 0 485 public
569 Garment 1 7 4 16 16 workshop 0 12 1 - 0 1293 public
570 Robe 1 11 6 19 40 workshop 0 16 2 - 0 5778 restricted
571 Garment 1 15 8 19 80 haven 1 20 2 - 0 41254 director-only
572 Garment 1 12 6 20 40 workshop 1 17 2 - 0 6175 restricted
573 Bag 1 11 6 20 80 haven 0 16 2 - 30 9963 restricted
574 Hat 1 12 6 18 40 workshop 1 17 2 - 0 4325 restricted
575 Garment 1 10 5 18 40 workshop 0 15 2 - 0 2484 public
576 Garment 1 10 5 20 80 haven 0 15 2 - 0 1638 public
577 Garment 1 17 9 23 160 haven 2 20 2 acid 0 123245 director-only
578 Bag 1 15 8 22 160 haven 1 20 2 - 40 90578 director-only
579 Garment 1 16 8 21 160 haven 2 20 2 poison 0 51300 director-only
580 Garment 1 17 9 21 160 haven 2 20 2 acid 0 123245 director-only
581 Robe 1 19 10 23 320 legacy 2 20 3 thunder 0 374549 director-only
582 Garment 1 20 10 23 320 legacy 3 20 3 bludgeoning 0 198267 director-only
583 Bag 1 19 10 23 320 legacy 2 20 3 - 50 350151 director-only
584 Garment 1 20 10 28 null special 3 20 3 radiant 0 498562 director-only
680 Cord 1 8 5 16 16 workshop 0 13 2 - 0 1102 public
681 Veil 1 2 1 10 2 field 0 7 1 - 0 24 public
682 Cloak 1 8 5 16 16 workshop 0 13 2 - 0 1045 public
683 Mantle 1 20 10 28 480 legacy 3 20 3 poison 0 92622 director-only
'''
KEYS='id family Q level tier DC hours mode assistants trivial task resistance relief batch_value visibility'.split()
INTEGER=set('id Q level tier DC assistants trivial task relief batch_value'.split())
rows=[]
for line in SOURCE.splitlines():
 if not line: continue
 r=dict(zip(KEYS,line.split()))
 for k in INTEGER:r[k]=int(r[k])
 r['hours']=None if r['hours']=='null' else int(r['hours'])
 r['resistance']=None if r['resistance']=='-' else r['resistance']
 rows.append(r)
by={r['id']:r for r in rows}
BODY = {
 'bag-10':('1','1'), 'bag-30':('3','3'), 'bag-40':('4','4'), 'bag-50':('5','5'),
 'cloak':('1','2'),'gloves':('1','0.5'),'hat':('0.5','0.5'),
 'garment-common':('0.5','3'),'garment-costume':('5','4'),'garment-fine':('15','6'), 'garment-traveler':('2','4'),
 'robe':('2','4'),'cord':('0.1','0.2'),'veil':('0.5','0.1'),'mantle':('1','2')}
def models(r):
 if r['family']=='Bag':return ['bag-'+str(r['relief'])]
 if r['family']=='Garment':return ['garment-common','garment-costume','garment-fine','garment-traveler']
 return [r['family'].lower()]
# Actual ordinary finished values printed in the Part B manuscript, not computed.
DISPLAY='''
546 33
547 32
548 11.4
549 60.5
550 28
551 20 24.5 34.5 21.5
552 17.25
553 17
554 58.5
555 160.5 165 175 162
556 70.5 75 85 72
557 161/3
558 45.5
559 24.5
560 50.5 55 65 52
561 694
562 337
563 1004.5 1009 1019 1006
564 262
565 3360
566 1716.5
567 1766
568 485.5 490 500 487
569 1293.5 1298 1308 1295
570 5780
571 41254.5 41259 41269 41256
572 6175.5 6180 6190 6177
573 9966
574 4325.5
575 2484.5 2489 2499 2486
576 1638.5 1643 1653 1640
577 123245.5 123250 123260 123247
578 90582
579 51300.5 51305 51315 51302
580 123245.5 123250 123260 123247
581 374551
582 198267.5 198272 198282 198269
583 350156
584 498562.5 498567 498577 498564
680 1102.1
681 24.5
682 1046
683 92623
'''
# Actual Large-example values from the Part B operational projection.
LARGE='''
546 33
547 33
548 62/5
549 61
550 29
551 41/2 59/2 99/2 47/2
552 69/4
553 18
554 59
555 161 170 190 164
556 71 80 100 74
557 164/3
558 93/2
559 51/2
560 51 60 80 54
561 695
562 339
563 1005 1014 1034 1008
564 264
565 3362
566 1717
567 1767
568 486 495 515 489
569 1294 1303 1323 1297
570 5782
571 41255 41264 41284 41258
572 6176 6185 6205 6179
573 9966
574 4326
575 2485 2494 2514 2488
576 1639 1648 1668 1642
577 123246 123255 123275 123249
578 90582
579 51301 51310 51330 51304
580 123246 123255 123275 123249
581 374553
582 198268 198277 198297 198271
583 350156
584 498563 498572 498592 498566
680 5511/5
681 25
682 1047
683 92624
'''
def examples(s):return {int(x.split()[0]):list(map(F,x.split()[1:])) for x in s.splitlines() if x}
ordinary,large=examples(DISPLAY),examples(LARGE)
# id reserve standard exceptional masterwork flawed sourceH opH phaseH dwarfMin dwarfPhase assist trivial
OPS='''
546 3 2 2 3 1 8 8 8 360 360 0 7
547 4 3 3 4 1 2 2 2 90 90 0 8
548 7 5 6 7 2 2 2 2 90 90 0 7
549 1 1 1 1 1 2 2 2 90 90 0 10
550 3 2 2 3 1 2 2 2 90 90 0 7
551 6 4 5 6 2 4 4 4 180 180 0 9
552 6 4 5 6 2 1 1 1 45 45 0 9
553 4 3 3 4 1 2 2 2 90 90 0 6
554 1 1 1 1 1 1 1 1 45 45 0 6
555 3 2 2 3 1 1 1 1 45 45 0 10
556 1 1 1 1 1 2 2 2 90 90 0 8
557 4 3 3 4 1 4 4 4 180 180 0 10
558 3 2 2 3 1 8 8 8 360 360 0 9
559 3 2 2 3 1 1 1 1 45 45 0 7
560 1 1 1 1 1 8 8 8 360 360 0 6
561 1 1 1 1 1 16 16 8 720 480 0 13
562 1 1 1 1 1 24 24 8 1080 480 0 10
563 1 1 1 1 1 8 8 8 360 360 0 12
564 1 1 1 1 1 8 8 8 360 360 0 12
565 1 1 1 1 1 16 16 8 720 480 0 14
566 1 1 1 1 1 16 16 8 720 480 0 15
567 1 1 1 1 1 16 16 8 720 480 0 14
568 1 1 1 1 1 24 24 8 1080 480 0 11
569 1 1 1 1 1 16 16 8 720 480 0 12
570 1 1 1 1 1 40 40 8 1800 480 0 16
571 1 1 1 1 1 80 80 8 3600 480 1 20
572 1 1 1 1 1 40 40 8 1800 480 1 17
573 1 1 1 1 1 80 80 8 3600 480 0 16
574 1 1 1 1 1 40 40 8 1800 480 1 17
575 1 1 1 1 1 40 40 8 1800 480 0 15
576 1 1 1 1 1 80 80 8 3600 480 0 15
577 1 1 1 1 1 160 160 8 7200 480 2 20
578 1 1 1 1 1 160 160 8 7200 480 1 20
579 1 1 1 1 1 160 160 8 7200 480 2 20
580 1 1 1 1 1 160 160 8 7200 480 2 20
581 1 1 1 1 1 320 320 8 14400 480 2 20
582 1 1 1 1 1 320 320 8 14400 480 3 20
583 1 1 1 1 1 320 320 8 14400 480 2 20
584 1 1 1 1 1 null 1920 8 86400 480 3 20
680 1 1 1 1 1 16 16 8 720 480 0 13
681 1 1 1 1 1 2 2 2 90 90 0 7
682 1 1 1 1 1 16 16 8 720 480 0 13
683 1 1 1 1 1 480 480 8 21600 480 3 20
'''
ops={int(l.split()[0]):[None if v=='null' else int(v) for v in l.split()[1:]] for l in OPS.splitlines() if l}
def run():
 failures=[]
 for r in rows:
  q,h=r['Q'],r['hours'];a=1920 if h is None else h
  expected=[3*q//2,q,5*q//4,3*q//2,q//2 if q>=2 else 1,h,a,min(8,a),45*a,min(480,45*a),r['assistants'],r['trivial']]
  if ops[r['id']]!=expected:failures.append({'id':r['id'],'type':'work/quantity','expected':expected,'actual':ops[r['id']]})
  for size,actual in [('ordinary',ordinary),('large',large)]:
   refs=[F(r['batch_value'],q)+F(BODY[m][0])*(2 if size=='large' and r['family']!='Bag' else 1) for m in models(r)]
   if actual[r['id']]!=refs:failures.append({'id':r['id'],'type':size+' value','expected':list(map(str,refs)),'actual':list(map(str,actual[r['id']]))})
 out={'scope':__doc__,'cards':len(rows),'families':dict(Counter(r['family'] for r in rows)),
      'visibility':dict(Counter(r['visibility'] for r in rows)),
      'bodyModels':len({m for r in rows for m in models(r)}),
      'publicBodyModels':len({m for r in rows if r['visibility']=='public' for m in models(r)}),
      'ordinaryReferences':sum(map(len,ordinary.values())), 'largeReferences':sum(map(len,large.values())),
      'garmentBonusCounts':dict(Counter(r['task'] for r in rows if r['family']!='Bag')),
      'resistances':{str(r['id']):r['resistance'] for r in rows if r['resistance']},
      'fieldLabels':[r['id'] for r in rows if r['mode']=='field'],
      'nullHours':[r['id'] for r in rows if r['hours'] is None], 'failures':failures}
 assert len(rows)==43 and out['ordinaryReferences']==91 and out['largeReferences']==91
 assert not failures,failures
 Path(__file__).with_name('control_results.json').write_text(json.dumps(out,indent=2))
 print(json.dumps(out,indent=2))
 return out
if __name__=='__main__':run()
