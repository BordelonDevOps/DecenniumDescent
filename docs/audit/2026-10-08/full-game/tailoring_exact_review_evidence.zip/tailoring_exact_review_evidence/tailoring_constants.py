"""Adapter: constants transcribed from the supplied candidate envelope/body models.
This is NOT the unavailable build_tailoring_recipe_candidate module.
"""
FAMILY_TASKS={
'Cloak':['presentation','visual-concealment','quiet-clothing-motion','weather-arrangement','exposure'],
'Garment':['presentation','visual-concealment','quiet-clothing-motion','weather-arrangement','exposure'],
'Robe':['presentation','visual-concealment','quiet-clothing-motion','weather-arrangement','exposure'],
'Mantle':['presentation','visual-concealment','quiet-clothing-motion','weather-arrangement','exposure'],
'Gloves':['presentation','discreet-handwork','weather-arrangement'],
'Hat':['presentation','visual-concealment','weather-arrangement','exposure'],
'Cord':['presentation','quiet-clothing-motion','weather-arrangement'],
'Veil':['presentation','visual-concealment','weather-arrangement'],
'Bag':['conceal-contents','organize-contents']}
SLOTS={'Bag':'pouch-position','Cloak':'outerwear-benefit','Gloves':'handwear-pair','Hat':'head','Garment':'body-clothing','Robe':'body-clothing','Cord':'waist-adornment','Veil':'face-accessory','Mantle':'outerwear-benefit'}
# Bag relief resolves through concrete pouch-1/pouch-2 or back-cargo, not this
# family-only garment test adapter. Tests do not use SLOTS['Bag'] for inventory.
