"""Independent expected checks and counterexamples against supplied bounded helpers.
Source-specific fixtures are identified; geometry/context remain declared premises.
No companion or full working-copy validator was run.
"""
from pathlib import Path
from copy import deepcopy
from fractions import Fraction as F
import json
import tailoring_reference as tr
import leatherworking_reference as lw
from tailoring_constants import SLOTS
from control_audit import by, rows

def serial(x):
 if isinstance(x,F):return str(x)
 if isinstance(x,dict):return {k:serial(v) for k,v in x.items()}
 if isinstance(x,set):return [serial(v) for v in sorted(x)]
 if isinstance(x,(list,tuple)):return [serial(v) for v in x]
 return x

checks=[]; findings=[]
def check(name,actual,expected=True):
 checks.append({'name':name,'actual':serial(actual),'expected':serial(expected),'pass':actual==expected})
def raises(fn):
 try:fn()
 except ValueError:return True
 return False

def garment(rid,physical_id=None,**patch):
 r=by[rid]
 assert r['family']!='Bag'
 result=dict(id=physical_id or 'item-'+str(rid),recipeId='recipe-'+str(rid),trade='Tailoring',family=r['family'],bonus=r['task'],resistance=r['resistance'],
             state='worn',hp=5,complete=True,fit=True,slotValid=True,slot=SLOTS[r['family']],wearer='A')
 result.update(patch);return result

def bag(rid,physical_id=None,**patch):
 r=by[rid];cap=r['relief']; assert r['family']=='Bag'
 result=dict(id=physical_id or 'item-'+str(rid),recipeId='recipe-'+str(rid),trade='Tailoring',family='Bag',bonus=r['task'],resistance=None,
             bodyCapacityLb=cap,weight=cap//10,load=F(cap,100),relief=cap,state='worn',hp=5,complete=True,fit=True,
             slot='pouch-1' if cap==10 else 'back-cargo',bearer='A',contents=[])
 result.update(patch);return result

base_task=dict(actualCheck=True,kind='ability-check',domain='presentation',domainCriteriaMet=True,actualContribution=True,
               ability='CHA',proficiency='Persuasion',visibleAttire=True,actor='A',coverageSufficient=True)
# Every source garment, independently, may present its actual visible suitable attire.
for r in rows:
 if r['family']=='Bag':continue
 item=garment(r['id'])
 check(f'{r["id"]}: source-scoped presentation',tr.tailoring_task_bonus([item],base_task),r['task'])
 for label,patch in [('suppressed',{'suppressed':True}),('melded',{'state':'melded'}),('Broken',{'hp':0}),('incomplete',{'complete':False}),('bad fit',{'fit':False}),('not designated',{'slotValid':False})]:
  check(f'{r["id"]}: inactive {label}',tr.tailoring_task_bonus([{**item,**patch}],base_task),0)
 if r['resistance']:
  check(f'{r["id"]}: independent printed resistance',tr.defense(-1,[item]),{'enhancement':-1,'resistances':[r['resistance']]})
  for label,patch in [('suppressed',{'suppressed':True}),('melded',{'state':'melded'}),('Broken',{'hp':0}),('incomplete',{'complete':False}),('bad fit',{'fit':False}),('not designated',{'slotValid':False})]:
   check(f'{r["id"]}: no resistance when {label}',tr.defense(-1,[{**item,**patch}]),{'enhancement':-1,'resistances':[]})
for label,patch in [('ordinary bargain',{'domainCriteriaMet':False}),('save',{'kind':'save'}),('other maker',{'actor':'B'}),('observer',{'ability':'WIS','proficiency':'Perception'}),('hidden attire',{'visibleAttire':False}),('no check',{'actualCheck':False})]:
 check('single item rejection: '+label,tr.tailoring_task_bonus([garment(682)],{**base_task,**patch}),0)
check('Crude receives no phantom Tailoring zero',tr.defense(-1,[garment(682)])['enhancement'],-1)
check('No eligible suit remains no AC candidate',tr.defense(None,[garment(682)])['enhancement'],None)
check('Robe/outfit competing designations rejected',raises(lambda:tr.validate_designated_slots([garment(581),garment(584)])))
check('Cloak/Mantle competing designations rejected',raises(lambda:tr.validate_designated_slots([garment(682),garment(683)])))
check('Poison plus bludgeoning in distinct legal slots',tr.defense(None,[garment(582),garment(683)])['resistances'],['bludgeoning','poison'])
check('Duplicate poison stays one type',tr.defense(None,[garment(579),garment(683)])['resistances'],['poison'])

# Counterexample: all clothing is genuinely worn/fitted in distinct slots, but
# only the cloak contributes visible presentation. Context is item-specific.
cloak=garment(682)
outfit=garment(584)
item_contexts={cloak['id']:{'actualContribution':True,'visibleAttire':True},
               outfit['id']:{'actualContribution':False,'visibleAttire':False}}
actual=tr.tailoring_task_bonus([cloak,outfit],base_task)
expected=max(tr.tailoring_task_bonus([i],{**base_task,**item_contexts[i['id']]}) for i in [cloak,outfit])
findings.append({'name':'global contribution admits a hidden stronger garment','sourceItems':[682,584],
                 'premises':item_contexts,'actual':actual,'expected':expected,'reproduced':actual!=expected})
# Scope does not suppress the otherwise active hidden garment's resistance.
check('hidden item may still resist independently',tr.defense(None,[cloak,outfit])['resistances'],['radiant'])

# New cross-trade wrapper must distinguish a worn container's operator from bearer.
# A reviewed +2 Leatherworking Backpack is a legal source profile (e.g. recipe-652).
lwbag=dict(id='lw-pack',recipeId='recipe-652',trade='Leatherworking',family='Backpack',bonus=2,state='worn',
           wearer='A',bearer='A',operator='B',accessible=True,complete=True,hp=10,fit=True,slot='back-cargo',slotValid=True)
org={**base_task,'domain':'organize-contents','ability':'DEX','proficiency':None,'actor':'B','noncreatureCargo':True,'leatherCriteriaMet':True}
actual=tr.cross_trade_task_bonus([lwbag],org,['cargo-handling'])
expected=lw.task_bonus([lwbag],True,{'cargo-handling'},True)
findings.append({'name':'worn Leatherworking container denies actual other operator',
                 'wearer':'A','actualOperator':'B','actual':actual,'expected':expected,'reproduced':actual!=expected})

# The supplied nested fixture has two unmodified bag-10 envelopes.
small_outer_fit=lw.orthogonal_box_fit([13,9,7],[12,8,6],[12,6],(0,2))
findings.append({'name':'supplied bag-10 inside bag-10 has no stated admissible fit',
                 'outerInterior':[12,8,6],'innerExterior':[13,9,7],
                 'innerEnvelopeVolumeFt3':str(F(13*9*7,1728)),
                 'outerContentsVolumeFt3':str(F(1,3)),
                 'orthogonalFit':small_outer_fit,'reproduced':not small_outer_fit})
# Replacement witness: existing reviewed Backpack, with inner small Bag.
check('small Bag fits reviewed Backpack orthogonally',lw.orthogonal_box_fit([13,9,7],[18,12,8],[12,8]))
outer=dict(id='outer',recipeId='recipe-280',trade='Leatherworking',family='Backpack',weight=5,load=F(1,2),
           relief=10,state='worn',hp=10,complete=True,fit=True,slot='back-cargo',bearer='A',contents=['inner'],location=[0,0,0])
inner=bag(546,'inner',state='stowed',slot=None,fit=False,contents=['odd'])
odd=dict(id='odd',weight=1,load=3)
records=[outer,inner,odd]
got=tr.inventory(records,'A')
check('lawful nested active root only',got['activeContainers'],['outer'])
check('lawful nested full physical pounds',got['physicalPounds'],F(7))
check('lawful nested canonical Load',got['canonicalLoad'],F(18,5))
check('lawful nested counted pounds',got['countedPounds'],F(5))
check('lawful nested effective Load',got['effectiveLoad'],F(17,5))
check('lawful nested body before cargo credit',got['coveredPoundsById'],{'inner':F(1),'odd':F(1)})
old=deepcopy(records)
suppressed=tr.inventory([{**outer,'suppressed':True},inner,odd],'A')
check('suppression preserves input custody records',records,old)
check('suppression removes relief but preserves pounds',suppressed['countedPounds'],F(7))
check('suppression preserves canonical Load',suppressed['effectiveLoad'],F(18,5))
broken,released=lw.break_container(records,'outer')
check('Broken releases inner subtree once',released,['inner'])
check('intact inner contents persist',next(r for r in broken if r['id']=='inner')['contents'],['odd'])
check('Broken body itself remains',next(r for r in broken if r['id']=='outer')['weight'],5)
pending,released=lw.break_container(records,'outer',same_location_legal=False,adjacent_legal=False)
check('unplaceable inner record pending',next(r for r in pending if r['id']=='inner')['state'],'pending-placement')
check('no relief-assisted meld budget',lw.meld_preflight(records,['outer'],5,F(17,5))['fits'],False)
# Actual remove-then-equip: no duplicate custody and no lingering outer credit.
removed=[{**outer,'contents':[]},bag(546,'inner',contents=['odd']),odd]
now=tr.inventory(removed,'A')
check('removed-and-equipped containers independently active',set(now['activeContainers']),{'outer','inner'})
check('empty outer cannot cover former inner body',now['coveredPoundsById'],{'odd':F(1)})
check('removed inner own body counts',now['effectiveLoad'],F(7,2))
# Return premises are explicitly given, not inferred by an unimplemented resolver.
returned_stowed=[{**outer,'contents':[]},bag(546,'inner',state='carried',slot=None,contents=['odd']),odd]
check('stowed return stays inactive',tr.inventory(returned_stowed,'A')['activeContainers'],['outer'])
check('Tiny casualty prior fixture full pounds',F(140)+F(15),F(155))
check('Tiny casualty prior fixture full Load',F(3,2)+F(3,2),F(3))

# Correctly sourced table Bag uses +1; a +2 Bag needs the 30/40-lb source/body.
for rid in (546,552,573,578,583):
 item=bag(rid,state='placed',slot=None,operator='B',accessible=True)
 task={**org,'leatherCriteriaMet':False}
 check(f'{rid}: actual Bag operator at table',tr.tailoring_task_bonus([item],task),by[rid]['task'])
 check(f'{rid}: no inaccessible operator benefit',tr.tailoring_task_bonus([{**item,'accessible':False}],task),0)
 check(f'{rid}: no secure/retrieve alias',tr.tailoring_task_bonus([item],{**task,'domain':'unlocked-retrieval'}),0)

# Reexecute the supplied 558-state sweep against a separately tabulated maximum oracle.
maxima={5:{(0,False):5,(0,True):2,(25,False):6,(25,True):3,(50,False):7,(50,True):3},
        10:{(0,False):10,(0,True):5,(25,False):12,(25,True):6,(50,False):15,(50,True):7}}
states=0
for b in (5,10):
 for oldp in (0,25,50):
  for oldf in (False,True):
   oldmax=maxima[b][oldp,oldf]
   assert lw.maximum_hp(b,oldp,oldf)==oldmax
   for hp in range(oldmax+1):
    for newp in (0,25,50):
     for newf in (False,True):
      z=lw.apply_quality(b,oldp,oldf,hp,newp,newf);states+=1
      maximum=maxima[b][max(oldp,newp),oldf or newf]
      assert z['maximum']==maximum
      assert z['current']==max(0,maximum-(oldmax-hp))
      assert z['percent']==max(oldp,newp) and z['flaw']==(oldf or newf)
check('durability enumerated states',states,558)
# Complete-order enumeration is separate from the pure HP-layer sweep.
orders=0
for q in range(1,6):
 reserve=[dict(id=str(i),model='tailoring.gloves',size='Medium',grade='Standard',ordinaryHP=5,percent=0,flaw=False,current=5,complete=True) for i in range(3*q//2)]
 for outcome,option in [(x,'yield') for x in ('Standard','Exceptional','Masterwork','Flawed','Failed','Mishap')]+[('Exceptional','durability'),('Masterwork','durability')]:
  output,unused=lw.complete_order(reserve,q,outcome,option);orders+=1
  n={'Standard':q,'Exceptional':5*q//4,'Masterwork':3*q//2,'Flawed':q//2 if q>1 else 1,'Failed':0,'Mishap':0}[outcome]
  if option=='durability':n=q
  assert [x['id'] for x in output]==[str(i) for i in range(n)]
  assert [x['id'] for x in unused]==[str(i) for i in range(n,3*q//2)]
  assert all(x['flaw']==(outcome=='Flawed' and q==1) for x in output)
check('complete-order combinations',orders,40)
reserve=[dict(id='original',model='tailoring.hat',size='Medium',grade='Standard',ordinaryHP=5,percent=0,flaw=False,current=1,complete=True)]
check('latest damage creates dormant Broken singleton',lw.complete_order(reserve,1,'Flawed')[0][0]['current'],0)
replacement={**reserve[0],'id':'lawful-pre-roll-replacement','current':4}
out=lw.complete_order([replacement],1,'Flawed')[0][0]
check('replacement identity maintained',out['id'],'lawful-pre-roll-replacement')
check('replacement latest deficit maintained',out['current'],1)
for patch in ({'missing':True},{'current':0},{'complete':False},{'imprint':True},{'committedElsewhere':True}):
 check('illegal reserve rejected '+str(patch),raises(lambda patch=patch:lw.complete_order([{**reserve[0],**patch}],1,'Standard')))
for p in (0,25,50):
 for flawed in (False,True):
  mx=maxima[5][p,flawed]
  r=[{**reserve[0],'percent':p,'flaw':flawed,'current':mx}]
  z=lw.complete_order(r,1,'Exceptional','durability')[0][0]
  check(f'no extra minimum from weaker repeat {p} flaw={flawed}',z['maximum'],maxima[5][max(p,25),flawed])

# Correct source DCs, exact references and transaction rounding.
for current in (1,0):
 terms=tr.repair_terms(current,5,F(1,2),F(997125,2),28)
 check(f'584 repair source DC at HP{current}',terms['DC'],10 if current else 28)
 check(f'584 repair hours at HP{current}',terms['hours'],F(1 if current else 8))
 check(f'584 materials at HP{current}',terms['materialsGp'],F(1,8) if current else F(997125,8))
check('584 reconstruction copper purchase rounding',tr.purchase_cp(F(997125,8)),12464063)
check('common outfit functional materials copper rounding',tr.purchase_cp(F(1,8)),13)
check('548 exact reconstruction DC',tr.repair_terms(0,5,1,F(57,5),11)['DC'],11)
check('548 missing original member disallowed',raises(lambda:tr.repair_terms(0,5,1,F(57,5),11,required_constituents_present=False)))
check('outfit missing original constituent disallowed',raises(lambda:tr.repair_terms(0,5,F(1,2),F(997125,2),28,required_constituents_present=False)))
check('year overlay ordinary minutes',tr.creation_minutes(None),115200)
check('year overlay Dwarf minutes',tr.creation_minutes(None,True),86400)
check('unqualified source tool rejected',raises(lambda:tr.tool_reservation('s',[],'A',False)))
check('overlapping source tool rejected',raises(lambda:tr.tool_reservation('s',['A'],'B',True)))
check('sequential source tool identity preserved',tr.tool_reservation('s',[],'B',True)['physicalToolId'],'s')

out={'scope':__doc__,'checks':checks,'checkCount':len(checks),'allChecksPass':all(c['pass'] for c in checks),
     'durabilityStates':states,'orderCombinations':orders,'reproducedFindings':findings,
     'notes':['Generic original 120-check working-copy validator was not executed.',
              'Supplied source-specific local fixture deviations also include acid Cloak, +2 small Bag, +3 Leatherworking Gloves, and repair DCs 12/30 instead of 11/28.',
              'The +3 Leatherworking Gloves discrepancy was cross-checked against the available prior reviewer source-control transcription; its Gloves rows have only +1 or +2.']}
Path(__file__).with_name('behavior_results.json').write_text(json.dumps(serial(out),indent=2))
print(json.dumps({k:serial(v) for k,v in out.items() if k!='checks'},indent=2))
assert out['allChecksPass'],[c for c in checks if not c['pass']]
assert all(f['reproduced'] for f in findings)
