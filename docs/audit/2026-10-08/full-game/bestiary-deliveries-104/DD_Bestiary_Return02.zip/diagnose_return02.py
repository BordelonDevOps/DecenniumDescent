"""Fresh, isolated Return02 numerical/state diagnostics.
Only standard-library data reads and independent calculations: no supplied or project module.
Refuses to overwrite completed evidence. It is not an engine or scheduler test.
"""
from pathlib import Path
from fractions import Fraction
from collections import Counter
import json, hashlib, math, sys
ROOT=Path(__file__).resolve().parent
REPORT=ROOT/'SPECIFICATION_REPORT.json'
EVIDENCE=ROOT/'NUMERICAL_STATE_EVIDENCE.json'
if REPORT.exists() or EVIDENCE.exists():
    raise SystemExit('Preserve completed evidence: output already exists.')
def read(n):return json.loads((ROOT/n).read_bytes())
def binding(n):
    b=(ROOT/n).read_bytes();return {'file':n,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
CB=read('CASEBOOK.json');P=read('PROCEDURES.json');INV=read('NATIVE_INVENTORY.json')
checks=[];counters=Counter();details=[]
def check(cat,key,ok,evidence=None):
    checks.append({'category':cat,'id':key,'pass':bool(ok),'evidence':evidence})
def walk(x,path=''):
    if isinstance(x,dict):
        yield path,x
        for k,v in x.items():yield from walk(v,path+'/'+k)
    elif isinstance(x,list):
        for i,v in enumerate(x):yield from walk(v,path+'/'+str(i))
def close(a,b):return abs(a-b)<1e-8
def box_gap(a,b):
    return math.sqrt(sum(max(a['min'][i]-b['max'][i], b['min'][i]-a['max'][i],0)**2 for i in range(3)))
ACT={a['id']:a for p in P['profiles'] for a in p.get('actions',[])+p.get('tacticCompletions',[])}
TRACES=[t for c in CB['cases'] for t in [c]+c.get('branches',[])]
# Independent source-display arithmetic, not damage rounding policy.
for j,r in enumerate(INV['damageMeanDiagnostics']):
    d=r['dice'];f=Fraction(d['dice']*(d['sides']+1),2)+d['flat']
    check('printed-display',str(j),round(f)==r['printedAverage'] and f==Fraction(r['exactMean']['n'],r['exactMean']['d']))
for j,r in enumerate(INV['abilityDiagnostics']):
    check('natural-modifier',str(j),(r['printed']['score']-10)//2==r['printed']['printedModifier'])
# Full trace state paths and newly introduced damage records, not replayed copies of old roots.
for tr in TRACES:
    tid=tr['id']
    for ei,e in enumerate(tr['timeline']):
        key=f'{tid}/{ei}';before=e['before'];after=e['after'];counters['events']+=1
        if e.get('duplicate'):
            a=dict(after);b=dict(before);a.pop('time',None);b.pop('time',None)
            check('duplicate-callback',key,a==b)
            counters['duplicateEvents']+=1
        for aid,a in after.get('actors',{}).items():
            b=before.get('actors',{}).get(aid)
            if b is None:continue
            if a.get('turnId')==b.get('turnId') and a.get('action')!=b.get('action'):
                # Removal can forfeit the unused action; it never refreshes one.
                check('action-within-turn',key+'/'+aid,a.get('action',0)<=b.get('action',0))
            old={x['id'] for x in b.get('damageRoots',[])}
            for d in a.get('damageRoots',[]):
                if d['id'] in old:continue
                counters['damageApplications']+=1;dk=key+'/'+aid+'/'+d['id']
                kind=d['damageType'];native=d['nativeAmount']
                immunity=b['nativeDefenses']['immunityLabels']['labels']
                resistance=b['nativeDefenses']['resistanceLabels']['labels']
                defended=0 if kind in immunity else native//2 if kind in resistance else native
                check('damage-defense',dk,defended==d['afterDefense'])
                temp=min(d['before']['tempHp'],defended);post=defended-temp
                hp_loss=min(d['before']['hp'],post);over=max(0,post-d['before']['hp'])
                check('damage-arithmetic',dk,
                      d['tempAbsorbed']==temp and d['postTemp']==post and d['actualHpLoss']==hp_loss and d['overkill']==over
                      and d['after']['hp']==d['before']['hp']-hp_loss and d['after']['tempHp']==d['before']['tempHp']-temp)
                check('wound-not-max-hp',dk,d['maximumHpUnchanged']==b['maxHp']==a['maxHp'])
                massive=d['after']['hp']==0 and over>=b['maxHp']
                eligible=(b['lifecycle']=='ordinaryLiving' and d['before']['life']!='dead' and post>0
                          and not d['nullNonlethal'] and not massive
                          and ((d['before']['hp']>0 and d['after']['hp']==0) or 2*post>=b['maxHp']))
                wc=d['woundCheck']
                check('wound-trigger',dk,(wc is not None)==eligible)
                if wc:
                    counters['woundChecks']+=1
                    expected=wc['d20']+b['abilities']['constitution']['printedModifier']-d['before']['wounds']
                    dc=max(10,post//2);failed=expected<dc
                    check('wound-check',dk,wc['total']==expected and wc['dc']==dc and wc['failed']==failed)
                    expected_w=d['before']['wounds']+(1 if failed and d['before']['wounds']<3 else 0)
                    check('wound-state',dk,d['after']['wounds']==expected_w)
                    if wc.get('injuryD6') is not None:
                        check('injury-threshold',dk,failed and dc-expected>=5 and 1<=wc['injuryD6']<=6)
                if d['nullNonlethal']:
                    counters['conditionalNullPackets']+=1
                    check('null-wound-boundary',dk,wc is None and d['after']['wounds']==d['before']['wounds'])
                if d['after']['life']=='dead':counters['actualDeathPackets']+=1
        for rp,r in walk(e.get('results',{})):
            rk=key+rp
            if isinstance(r.get('attackD20'),list) and 'hit'in r:
                counters['attackApplications']+=1
                act=ACT[r.get('actionId',r.get('source'))]
                dice=r['attackD20'];state=r.get('advantageState','ordinary')
                selected=min(dice) if state.startswith('disadvantage') else max(dice) if state.startswith('advantage') else dice[0]
                check('attack-selection',rk,all(1<=x<=20 for x in dice) and selected==r['selected'])
                hit=selected!=1 and (selected==20 or selected+r['bonus']>=r['targetAc']);critical=hit and selected==20
                check('attack-result',rk,r['bonus']==act['attackBonus'] and r['total']==selected+r['bonus'] and r['hit']==hit and r['critical']==critical)
                if hit:
                    dd=act['damage'];faces=r['damageFaces']
                    check('attack-native-dice',rk,len(faces)==dd['dice']*(2 if critical else 1) and all(1<=f<=dd['sides'] for f in faces) and r['flat']==dd['flat'])
                    check('attack-packet',rk,r['damage']['nativeAmount']==sum(faces)+dd['flat'] and r['damage']['damageType']==dd['type'])
                else:check('miss-no-packet',rk,not r.get('damageFaces') and 'damage'not in r)
            if isinstance(r.get('save'),dict) and 'actionId'in r:
                counters['nativeSaveApplications']+=1
                s=r['save'];act=ACT[r['actionId']];faces=r['sharedDamageFaces'];dd=act['damage']
                check('save-result',rk,s['dc']==act['save']['dc'] and s['total']==s['d20']+s['modifier'] and s['success']==(s['total']>=s['dc']))
                check('save-native-dice',rk,len(faces)==dd['dice'] and all(1<=f<=dd['sides'] for f in faces) and r['beforeSave']==sum(faces)+dd['flat'])
                output=r['beforeSave']//2 if s['success'] and act['kind']=='save-area' else 0 if s['success'] else r['beforeSave']
                check('save-packet',rk,r['afterSave']==output==r['damage']['nativeAmount'])
            if isinstance(r.get('rider'),dict) and 'modifier' in r['rider']:
                rr=r['rider'];check('rider-arithmetic',rk,rr['total']==rr['d20']+rr['modifier'])
# Complete positive coverage, rather than asserting unexercised predicates.
check('coverage','native profiles',sum(c['kind']=='full authored native encounter' for c in CB['cases'])==66)
check('coverage','individual traits',sum(c['kind']=='composed trait encounter with explicit synthetic inputs' for c in CB['cases'])==79)
check('coverage','all multiattack mains',sum(any(a['kind']=='multiattack' for a in p.get('actions',[])) for p in P['profiles'])==42)
case={c['id']:c for c in CB['cases']}
# Exact named collision/push boundary.
p=case['B02-X02-PRESSURE'];pa=p['finalState']['actors']['bear'];r=p['timeline'][0]['results']
check('pressure-positive','exact-source-and-outcome',r['save']['dc']==15 and r['sharedDamageFaces']==[3,4,5] and pa['hp']==56 and 'Prone'in pa['conditions'] and r['push']['feet']==5)
ps=next(b for b in p['branches'] if b['id'].endswith('-SAVE'))
check('pressure-positive','success-not-half',ps['finalState']['actors']['bear']['hp']==68 and 'Prone'not in ps['finalState']['actors']['bear']['conditions'])
pw=next(b for b in p['branches'] if b['id'].endswith('-WALL'))
pr=pw['timeline'][0]['results'];check('pressure-collision','bounded-one-foot',pr['actualPush']==1 and pw['finalState']['actors']['bear']['hp']==56)
# True formation unit versus separate creature identities.
f=case['B02-X03-FORMATION'];fr=f['timeline'][0]['results']
check('formation','two-intersections-one-root',len(fr['bodyIntersections'])==2 and fr['applicationsToUnit']==1 and f['finalState']['actors']['quintet']['hp']==332)
fb=f['branches'][0];losses=[a['hp'] for k,a in fb['finalState']['actors'].items() if k!='source']
# Source actor naming is deliberately read from the fixture rather than guessed.
affected=[(k,a) for k,a in fb['finalState']['actors'].items() if any(d['id'].startswith('pulse:') for d in a.get('damageRoots',[]))]
check('formation','separate-recipients',len(affected)==2 and all(a['hp']==133 for k,a in affected))
# Wound mathematics and Null are distinct actual packet branches.
w=case['B02-X01-WOUND'];d=w['timeline'][0]['results']['damage'];wa=w['finalState']['actors']['bear']
check('wound-positive','critical-native',d['nativeAmount']==47 and d['woundCheck']['dc']==23 and d['woundCheck']['total']==21 and wa['hp']==21 and wa['wounds']==1 and wa['maxHp']==68)
# Known full-state work results, with no universal phase inference.
h=case['B02-X04-BEAR-HARVEST'];hr=h['timeline'][2]['results']
check('harvest','full-real-stock',h['finalState']['time']==1860 and len(hr['recoveredIds'])==4 and close(hr['cargoMassWithoutContainers'],2.5) and hr['referenceNotCashGp']==72)
check('harvest','duplicate-removal',h['timeline'][-1]['duplicate'] and h['timeline'][-1]['results']['noRepeatedMutation'])
t=case['B02-X06-TACKLE'];catch=t['timeline'][1]['results'];secure=t['timeline'][2]['results'];harvest=t['timeline'][3]['results']
check('tackle','actual-capture-check',catch['total']==8+4+1==13 and catch['checkTime']==3300 and catch['secureBefore']==3900)
check('tackle','capture-not-material',secure['materialAwardedNow']==0 and secure['extraRecoveryAuthorized']==['reserve-1'])
check('tackle','later-real-harvest',harvest['tackleBonusOnHarvest']==0 and harvest['newCaptureCredit']==0 and harvest['total']==13 and len(harvest['newLots'])==2)
check('tackle','zero-history-retained',t['branches'][0]['timeline'][-1]['results']['newAuthorization']==0 and not t['branches'][0]['timeline'][-1]['results']['newEvaluation'])
ro=case['B02-X07-ROAST'];rr=ro['timeline'][1]['results'];meal=ro['timeline'][-1]['results']
check('recipe92','whole-food-and-containers',rr['quantity']==5 and rr['maxSlotsReserved']==7 and rr['emptyCrocks']==2 and close(rr['supplementConsumed']+rr['supplementUnused'],4.27))
check('recipe92','full-meal-time',meal['completedExclusiveMealSeconds']==600 and meal['tempHp']==4 and meal['lightningUntil']==7800 and ro['finalState']['time']==4200)
light=next(b for b in ro['branches'] if b['id'].endswith('NATIVE-LIGHTNING'));lr=light['timeline'][0]['results']
check('recipe92','real-native-resisted-hit',lr['damage']['nativeAmount']==12 and lr['damage']['afterDefense']==6 and lr['damage']['tempAbsorbed']==4 and lr['damage']['actualHpLoss']==2 and lr['riderStillLive'])
ret=case['B02-X09-RETREAT'];result=ret['timeline'][-1]['results'];actors=ret['finalState']['actors']
check('retreat','all-costs-and-damage',result['Escape']==3 and result['Pursuit']==0 and actors['lead']['hp']==85 and all(e['results']['movementFeet']==30 for e in ret['timeline']))
gate=ret['finalState']['environment']['route']['gate']['occupiedWhenClosed']
for aid in ['lead','bear']:
    b=actors[aid]['parts'][0]['box'];interior=all(min(b['max'][j],gate['max'][j])>max(b['min'][j],gate['min'][j]) for j in range(3))
    check('retreat-geometry',aid+'-not-inside-closed-gate',not interior)
# Trait encounters: actual initial/final differences and durable callbacks are retained;
# source-local state change is not a generic Boolean witness.
traits=[c for c in CB['cases'] if c['kind']=='composed trait encounter with explicit synthetic inputs']
for c in traits:
    check('trait-positive',c['id']+':real-state-change',c['initialState']!=c['finalState'] and len(c['timeline'])>=1)
    check('trait-counterplay',c['id']+':full-reset-branch',len(c['branches'])>=1 and all(b['initialState'] and b['timeline'] and b['finalState'] for b in c['branches']))
fail=[x for x in checks if not x['pass']]
report={'id':'BESTIARY_RETURN02_NEW_ISOLATED_NUMERICAL_STATE_DIAGNOSTICS','inputBindings':[binding(n) for n in ['MODEL.json','CASEBOOK.json','PROCEDURES.json','NATIVE_INVENTORY.json']],
        'assertionCount':len(checks),'failures':len(fail),'categories':dict(Counter(x['category'] for x in checks)),
        'exercised':dict(counters),'tracePaths':len(TRACES),'mainCases':len(CB['cases']),
        'limits':['New isolated standard-library calculations over complete authored source fixtures, not imported project/game modules.',
                 'No world scheduler, AI, renderer, acquisition engine or real campaign state is run or authenticated.',
                 'Conditional Null, actual recipe donor/stock/access and other external prerequisites stay conditional.',
                 'Observed damage means are display-pattern evidence only, not a global damage-rounding rule.',
                 'No numerical-balance, human gameplay, cosmology or release approval.'],'checks':checks}
if fail:
    print(json.dumps({'assertions':len(checks),'failures':fail},ensure_ascii=False,indent=2));raise SystemExit(1)
selected=['B02-X01-WOUND','B02-X02-PRESSURE','B02-X03-FORMATION','B02-X04-BEAR-HARVEST','B02-X06-TACKLE','B02-X07-ROAST','B02-X09-RETREAT']
evidence={'id':'BESTIARY_RETURN02_NEW_NUMERICAL_EVIDENCE','scope':report['limits'],'inputBindings':report['inputBindings'],
          'independentArithmeticReport':'SPECIFICATION_REPORT.json','completePositiveCasesAndBranches':[case[k] for k in selected],
          'sourceMeanRecords':INV['damageMeanDiagnostics'],'allOtherFullCases':'CASEBOOK.json',
          'actionDamageCoverage':dict(counters),'observedCounts':INV['counts']}
REPORT.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
EVIDENCE.write_text(json.dumps(evidence,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'assertions':len(checks),'failures':0,'exercised':dict(counters),'reports':[str(REPORT),str(EVIDENCE)]},indent=2))
