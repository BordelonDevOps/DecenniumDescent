"""New Return02 read-only preservation verifier. No supplied/project module is imported.
The output is a source/structure/reconstruction report, never a game-runtime verdict.
"""
from pathlib import Path, PurePosixPath
from collections import Counter
from copy import deepcopy
import json, hashlib, zipfile, io, sys

ROOT=Path(__file__).resolve().parent
checks=[]
def sha(b):return hashlib.sha256(b).hexdigest()
def load(p):return json.loads((ROOT/p).read_bytes())
def check(category,label,condition,detail=None):
    checks.append({'category':category,'id':label,'pass':bool(condition),'detail':detail})
def refget(obj,p):
    if not p:return obj
    v=obj
    for part in p.lstrip('/').split('/'):
        part=part.replace('~1','/').replace('~0','~')
        v=v[int(part)] if isinstance(v,list) else v[part]
    return v

def checkzip(path,label):
    z=zipfile.ZipFile(path);names=z.namelist()
    check('archive',label+':unique',len(names)==len(set(names)))
    check('archive',label+':safe',all(not PurePosixPath(n).is_absolute() and '..'not in PurePosixPath(n).parts and '\\' not in n and ':' not in n for n in names))
    check('archive',label+':crc',z.testzip() is None)
    return z

def verify_source_manifest(z,label,member):
    m=json.loads(z.read(member))
    entries=m['files'] if 'files'in m and isinstance(m['files'],list) else [{'path':k,**v} for k,v in m.items()]
    for e in entries:
        raw=z.read(e['path']); size=e.get('bytes',e.get('size'))
        if size is None:size=e.get('sizeBytes')
        check('source-member',label+':'+e['path'],len(raw)==size and sha(raw)==e['sha256'],{'bytes':len(raw),'sha256':sha(raw)})

sources=load('SOURCE_BINDINGS.json');zs={}
for ent in sources['inputs']:
    p=ROOT/'input'/ent['path'];raw=p.read_bytes()
    check('archive',ent['path']+':identity',len(raw)==ent['bytes'] and sha(raw)==ent['sha256'])
    zs[ent['path']]=checkzip(p,ent['path'])
main=zs['DD_Bestiary_Complete_Source_Prepared_v3_81.zip']
for filename,z in zs.items():verify_source_manifest(z,filename,'FILE_MANIFEST.json' if 'Prepared_v3'in filename else 'MANIFEST.json')
v2=checkzip(io.BytesIO(main.read('history/DD_Bestiary_Complete_Source_Prepared_v2.zip')),'retained-v2')
verify_source_manifest(v2,'retained-v2','FILE_MANIFEST.json')
ops=load('EXACT_OPERATIONS.json');rawbase=main.read(ops['base']['member']);base=json.loads(rawbase);model=load('MODEL.json')
rawmodel=(ROOT/'MODEL.json').read_bytes()
check('reconstruction','base bytes/hash',len(rawbase)==ops['base']['bytes'] and sha(rawbase)==ops['base']['sha256'])
check('reconstruction','target bytes/hash',len(rawmodel)==ops['target']['bytes'] and sha(rawmodel)==ops['target']['sha256'])
forward=deepcopy(base)
for o in ops['operations']:
    parentpath,_,key=o['path'].rpartition('/');p=refget(forward,parentpath);after=deepcopy(refget(model,o['after']['valueRef']['pointer']))
    if o['op']=='add':check('reconstruction','absent:'+o['path'],key not in p)
    else:check('reconstruction','before:'+o['path'],p[key]==refget(base,o['before']['valueRef']['pointer']))
    p[key]=after
check('reconstruction','full forward object',forward==model)
forwardbytes=(json.dumps(forward,ensure_ascii=False,indent=2)+'\n').encode()
check('reconstruction','full forward bytes',forwardbytes==rawmodel)
reverse=deepcopy(model)
for o in reversed(ops['operations']):
    parentpath,_,key=o['path'].rpartition('/');p=refget(reverse,parentpath)
    check('reconstruction','inverse-after:'+o['path'],p[key]==refget(model,o['after']['valueRef']['pointer']))
    if not o['before']['exists']:del p[key]
    else:p[key]=deepcopy(refget(base,o['before']['valueRef']['pointer']))
reversebytes=(json.dumps(reverse,ensure_ascii=False,indent=2)+'\n').replace('\n','\r\n').encode()
check('reconstruction','full reverse object',reverse==base)
check('reconstruction','full reverse bytes',reversebytes==rawbase)
# Original record preservation is exact, including full source text and historical flags.
proc=load('PROCEDURES.json')
for i,(old,new) in enumerate(zip(base['records'],model['records'])):
    cp=deepcopy(new);selected=cp.pop('proposedOperation02')
    check('native-preservation',f'complete record{i}',cp==old)
    check('mirrors',f'procedure{i}',selected==proc['profiles'][i])
    src=main.read('sources/'+old['source']['path'])
    check('native-preservation',f'known dossier bytes{i}',sha(src)==old['source']['sha256'] and src.decode('utf-8-sig')==old['source']['originalUtf8Text'])
    if old['statBlock']:
        check('native-preservation',f'full native stat{i}',selected['fullNativeStatBlock']==old['statBlock'])
        for j,a in enumerate(old['statBlock']['actions']):check('native-preservation',f'action{i}:{j}',selected['actions'][j]['original']==a)
        for j,t in enumerate(old['statBlock']['traits']):check('native-preservation',f'trait{i}:{j}',selected['traits'][j]['original']==t)
        check('native-preservation',f'harvest{i}',selected['harvest']['original']==old['harvest'])
    else:check('native-preservation','lore remains no stat',new['statBlock'] is None and 'actions'not in selected)
check('native-preservation','root original identity relations',model['identityRelations']==base['identityRelations'])
check('native-preservation','sealed metadata no operation added',model['preservedSealedRoutesOnly']==base['preservedSealedRoutesOnly'])
check('mirrors','shared full rules',model['authorship02']['sharedRules']==proc['sharedRules'])
for key in ['completeQuestionDispositions','completeCasebook','completeMaterialComparisons','sourceAuthority','completeDecisionRecord','fullHoldRegister']:
    e=model['authorship02'][key];b=(ROOT/e['file']).read_bytes();check('mirrors','model-bound:'+key,len(b)==e['bytes'] and sha(b)==e['sha256'])
# Every full-state trace, including independently reset branches, is compared in full.
cb=load('CASEBOOK.json');dis=load('CASE_DISPOSITIONS.json');traits={t['id']:t for p in proc['profiles'] for t in p.get('traits',[])}
check('case-preservation','native/trait/cross counts',(len(cb['cases'][:66]),len(cb['cases'][66:145]),len(cb['cases'][145:]))==(66,79,10))
check('case-preservation','case IDs unique',len({c['id'] for c in cb['cases']})==155)
check('case-preservation','branch count',sum(len(c['branches']) for c in cb['cases'])==cb['counts']['independentBranches'])
for i,c in enumerate(cb['cases']):
    check('mirrors','case disposition:'+c['id'],dis['cases'][i]['id']==c['id'] and len(dis['cases'][i]['branches'])==len(c['branches']))
    if 'traitId'in c:check('mirrors','complete selected trait:'+c['id'],c['selectedProcedure']==traits[c['traitId']]['procedure'])
    for trace in [c]+c['branches']:
        prior=trace['initialState']
        for k,e in enumerate(trace['timeline']):
            check('case-full-state',trace['id']+':before'+str(k),e['before']==prior)
            check('case-full-state',trace['id']+':time'+str(k),e['time']>=prior['time'])
            if e.get('duplicate'):check('case-full-state',trace['id']+':duplicate'+str(k),e['before']==e['after'])
            prior=e['after']
        check('case-full-state',trace['id']+':fullfinal',prior==trace['finalState'])
        for aid,a in trace['finalState']['actors'].items():
            check('case-actors',trace['id']+':'+aid+':bounds',0<=a['hp']<=a['maxHp'] and a['tempHp']>=0 and 0<=a['action']<=1 and 0<=a['reaction']<=1)
            if a.get('sourceIndex')is not None:
                native=base['records'][a['sourceIndex']]['statBlock'];check('case-actors',trace['id']+':'+aid+':native',a['nativeCore']==native['printedCoreFields'] and a['abilities']==native['abilities'])
            for part in a['parts']:
                f=part['foot'];d=part['dimensions'];expected={'min':[f[0]-d[0]/2,f[1]-d[1]/2,f[2]],'max':[f[0]+d[0]/2,f[1]+d[1]/2,f[2]+d[2]]}
                check('case-geometry',trace['id']+':'+part['id'],expected==part['box'] and part['voluntaryMovementSpent']>=0)
# Complete question/legacy/input comparisons, not title census.
qs=load('QUESTION_DISPOSITIONS.json');original=json.loads(main.read('BESTIARY_CURRENT_SOURCE_INTERFACES_81.json'))
check('questions','27 current full originals',[q['original'] for q in qs['currentMappedQuestions']]==original['questions'])
check('questions','13 original interfaces',[q['original'] for q in qs['originalUnresolvedInterfaces']]==original['existingUnresolvedInterfaces'])
check('questions','5 true numbered source questions',len(qs['originalNumberedSourceQuestions'])==5)
cr=json.loads(main.read('sources/docs/audit/2026-10-08/full-game/BESTIARY_CRAFTING_CROSSLINK_AUDIT.json'))
mat=load('MATERIAL_RECIPE_DISPOSITIONS.json')
check('materials','178 full original comparisons',[x['originalFullComparison'] for x in mat['materialOccurrences']]==cr['harvestRows'])
check('materials','40 full original recipe links',[x['completeOriginalComparison'] for x in mat['recipeLinks']]==cr['printedRecipeReferences'])
check('materials','6 full original questions',[x['originalQuestion'] for x in qs['originalCraftingQuestions']]==cr['reviewQuestions'])
for row in mat['materialOccurrences']:
    ptr=row['selectedUnitPointer'].split('#',1)[1]
    check('mirrors',row['id']+':complete local unit',refget(model,ptr)==row['proposedCompleteLocalUnit'])
check('materials','two current full cards supplied',sum(x['currentFullCard']is not None for x in mat['recipeLinks'])==2)
check('materials','38 unresolved links explicit',sum(x['currentFullCard']is None for x in mat['recipeLinks'])==38)
hist=load('HISTORY_DISPOSITIONS.json');oa=json.loads(main.read('sources/docs/audit/2026-10-08/full-game/BESTIARY_SOURCE_RUNTIME_AUDIT.json'))
check('history','184 exact differences',[x['completeOriginalDifference'] for x in hist['knownFieldDifferences']]==oa['runtimeFieldDifferences'])
check('history','707 bindings retained',len(hist['workbookRuntimeBindings'])==707)
check('history','public26 preserved',len(hist['currentPublicRoutes'])==26)
# No claims about independently accepted bestiary or promoted spell/index/runtime.
check('scope','no runtime install',model['runtimeInstalled'] is False and model['authorship02']['runtimeExecuted'] is False)
check('scope','no acceptance',model['authorship02']['independentlyAccepted'] is False)
check('scope','applied baseline',model['authorship02']['appliedBaseline']=={'reviewed':525,'pending':323,'standalone':249,'interfaces':173})
check('scope','53 accepted-unapplied ordinary spells',model['authorship02']['acceptedUnappliedOrdinarySpells']==53)
fail=[c for c in checks if not c['pass']]
report={'id':'BESTIARY_RETURN02_FRESH_READ_ONLY_VERIFICATION','checkCount':len(checks),'failures':len(fail),'categories':dict(Counter(c['category']for c in checks)),'limits':['New source/structure/full-byte/mirror checks only. No supplied script/project module/game engine imported or executed.','Sealed raw bytes are CRC/hash containment only; no sealed creature content selected or rendered.','No numerical balance, campaign authentication, runtime/human/cosmology or release approval.'],'checks':checks}
if fail:
    print(json.dumps({'failures':fail[:30],'failureCount':len(fail),'checks':len(checks)},ensure_ascii=False,indent=2));sys.exit(1)
p=ROOT/'VERIFICATION_REPORT.json'
if p.exists():raise SystemExit('Refuse to overwrite an existing report; preserve successful work.')
p.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'checks':len(checks),'failures':0,'report':str(p)},indent=2))
