# ACQ-05 bound source extracts
Each S identifier below is an exact source locator in the supplied archive. These extracts establish text, not campaign truth.

## S1
`DescentReviewChanges/ReviewBible/data/public/feat_candidates/exact_01/candidate.json` — `/feats/10`
SHA-256: `7dcb40a94b62c31efa00409fa4981c3038218cb876deae4e1691dfa1410ea9b0`

```json
{
  "id": "animal_companion",
  "name": "Animal Companion",
  "cohort": "general_combat",
  "sourceObject": {
    "id": "animal_companion",
    "name": "Animal Companion",
    "description": "You have formed a bond with an animal.",
    "prerequisite": "Animal Handling proficiency",
    "effect": "You gain an animal companion that follows your commands and fights alongside you.",
    "type": "General",
    "draft": false,
    "deprecated": false,
    "needsReview": false
  },
  "reviewStatus": "Source-authored; exact candidate review pending.",
  "operationalRules": "NEW acquisition: with actual Animal Handling proficiency, select one already real willing/tamed Beast, noncorrupted, INT<7, that fits one of the three finite body templates below. Finding, buying or taming it requires actual campaign access/consent; the feat creates no animal, stocked shop or universal charm. Spend one uninterrupted hour together at touch range; one bond attempt per completedLR, noRP. One feat bond at a time. Use the template corresponding to the real animal's body/native movement; do not turn a dog into a bird or grant a new breathing mode. AC12+floor(ownerPB/2), maximumHP5+total owner level; template attack/ability/movement values are explicit NEW. At initial bond convert existing HP proportionally max(1,floor(newMax×oldHP/oldMax)); preserve actual conditions/injuries. Later maximum growth never heals, decreases clamp without damage. Ordinary legal healing works, but no Hit Dice/rest-refill is invented. Use one shared BA command within60ft while the animal can perceive you: in its attached phase after your regular turn, move and make its one attack or Dash/Disengage/Help/Dodge. No independent turn/Reaction; uncommanded move defensively and Dodge. The animal's HP-only chassis dies at0, producing its one actual corpse and ending the bond, with no Wound/death-save sequence; this is a feat-specific NEW rule, not generic animal law. Death/release never creates replacement: after a new completedLR, a new real animal and full hour are required. Voluntary release takes one uninterrupted hour and ends the bond without healing; preserve the same physical animal and restore its prior ordinary profile with the same current-HP fraction, not a fresh full animal. A creature cannot have this and a Ranger bond simultaneously; transferring requires actual release and new paid acquisition, not additive statistics. Owner death ends the bond and, if the animal remains alive, restores its saved ordinary profile using the same positive-HP ratio conversion as release; a dead animal remains its actual corpse. Temporary owner incapacity prevents new commands but does not cancel a previously committed legal command; after that command, uncommanded phases remain defensive. This never supplies autonomous attacks.\nNEW explicit EX58 interface: retain one real creature identity and one current control/phase record. Riding, bonding or transferring custody does not clone a turn, movement budget, Reaction, attack allowance, body or resource pool. An attached companion acts in its source-defined phase after the owner’s regular turn; a controlled mount uses EX58’s actual mounted-phase procedure. A body fitting both roles elects one compatible route before that round’s work, preserves all already-spent allowances and cannot switch routes to gain a second phase. Its actual load, tack, rider geometry, mounting/dismounting cost and ordinary independent temperament remain. One shared Bonus Action command and one offensive companion action per owner per numbered round apply where those source engines impose them. This feat supplies no blanket override of a specific engine’s attack or no-resource restrictions.\nThe three supplied body templates are NEW complete feat chassis, not evidence that such a Beast is available. Use only the corresponding real body/native mode. Saved ordinary maximum/currentHP and original constituent identity are required before bonding; no missing oldHP record is replaced by invented full health. The feat’s0HP-death rule applies only to this feat chassis; an independently governed mount/Ranger chassis retains its own rules rather than taking both.",
  "workedCases": [
    "A ground companion bonded by level5 has max10HP. A real animal at half of its oldHP converts to5HP, not full10.",
    "At0HP it dies and leaves its actual body. Taking a rest alone neither revives it nor creates another beast."
  ],
  "payloadOperational": "NEW acquisition: with actual Animal Handling proficiency, select one already real willing/tamed Beast, noncorrupted, INT<7, that fits one of the three finite body templates below. Finding, buying or taming it requires actual campaign access/consent; the feat creates no animal, stocked shop or universal charm. Spend one uninterrupted hour together at touch range; one bond attempt per completedLR, noRP. One feat bond at a time. Use the template corresponding to the real animal's body/native movement; do not turn a dog into a bird or grant a new breathing mode. AC12+floor(ownerPB/2), maximumHP5+total owner level; template attack/ability/movement values are explicit NEW. At initial bond convert existing HP proportionally max(1,floor(newMax×oldHP/oldMax)); preserve actual conditions/injuries. Later maximum growth never heals, decreases clamp without damage. Ordinary legal healing works, but no Hit Dice/rest-refill is invented. Use one shared BA command within60ft while the animal can perceive you: in its attached phase after your regular turn, move and make its one attack or Dash/Disengage/Help/Dodge. No independent turn/Reaction; uncommanded move defensively and Dodge. The animal's HP-only chassis dies at0, producing its one actual corpse and ending the bond, with no Wound/death-save sequence; this is a feat-specific NEW rule, not generic animal law. Death/release never creates replacement: after a new completedLR, a new real animal and full hour are required. Voluntary release takes one uninterrupted hour and ends the bond without healing; preserve the same physical animal and restore its prior ordinary profile with the same current-HP fraction, not a fresh full animal. A creature cannot have this and a Ranger bond simultaneously; transferring requires actual release and new paid acquisition, not additive statistics. Owner death ends the bond and, if the animal remains alive, restores its saved ordinary profile using the same positive-HP ratio conversion as release; a dead animal remains its actual corpse. Temporary owner incapacity prevents new commands but does not cancel a previously committed legal command; after that command, uncommanded phases remain defensive. This never supplies autonomous attacks.\nNEW explicit EX58 interface: retain one real creature identity and one current control/phase record. Riding, bonding or transferring custody does not clone a turn, movement budget, Reaction, attack allowance, body or resource pool. An attached companion acts in its source-defined phase after the owner’s regular turn; a controlled mount uses EX58’s actual mounted-phase procedure. A body fitting both roles elects one compatible route before that round’s work, preserves all already-spent allowances and cannot switch routes to gain a second phase. Its actual load, tack, rider geometry, mounting/dismounting cost and ordinary independent temperament remain. One shared Bonus Action command and one offensive companion action per owner per numbered round apply where those source engines impose them. This feat supplies no blanket override of a specific engine’s attack or no-resource restrictions.\nThe three supplied body templates are NEW complete feat chassis, not evidence that such a Beast is available. Use only the corresponding real body/native mode. Saved ordinary maximum/currentHP and original constituent identity are required before bonding; no missing oldHP record is replaced by invented full health. The feat’s0HP-death rule applies only to this feat chassis; an independently governed mount/Ranger chassis retains its own rules rather than taking both.",
  "selectionEnabled": false,
  "exactApproved": false,
  "runtimeApproved": false,
  "sharedRulesRef": "shared_rules.json",
  "supplementsRef": "supplements.json"
}
```

## S2
`DescentReviewChanges/ReviewBible/data/public/feat_candidates/exact_01/shared_rules.json` — `/rules/0`
SHA-256: `bf8483fa6b70cbfc87404df5c68c48e6b849f808ec4667dcd529a89cd9b0dfb6`

```json
{
  "id": "FS-01",
  "title": "Authority, identity and acquisition",
  "disposition": "ADOPT EXPLICIT NEW COMPLETION",
  "wording": "These are source/proposal-authoring directions for 327 exact existing IDs, not approval of assembled operational cards. Preserve all 335 originals, eight already-reviewed full feats, every description/effect/legacy alternative, original questions, absent/null distinctions and prior labels. A real class-scheduled feat/ASI opportunity pays for a grant; merely reaching a total level, possessing an item, meeting prerequisites or reading this register gives no selection. Unqualified Level means total character level; named Warrior or other class gates use that class level. Check printed permanent ability, actual feat ownership and credential prerequisites at acquisition. A half-feat ability increase is capped at 20, contributes zero rather than reducing a higher score, and does not grant another selection. The pure ASI option requires its full legal allocation. Numerical skill prerequisites require actual proficiency and permanent governing ability modifier plus the applicable normal PB or replacing Expertise contribution, excluding equipment, temporary modifiers, situational feats, Help and advantage. Preserve the acquisition snapshot. Later prerequisite loss does not erase a grant; ongoing equipped/active/body requirements can disable its use.\nNEW nonrepeatability: each identity is acquired once, except the explicitly repeatable ASI, Armor Proficiency for a distinct missing tier, Resilient for a different save, and Weapon Focus for a different actual weapon type. Elemental Affinity/Adept, Spell Focus and other chosen-type feats do not gain unprinted repeatability. One same-named source represented in two catalogs is not two selections. The twelve explicitly mapped Warrior mutation-feat pairs are one paid identity; their actual class gates and active-mutation conditions control as stated in HM rows. Other shared names do NOT merge class, ancestry, item, feat, ordinary-spell or supplement permissions.\n\nWarrior mutation-feat acquisition uses the equipped-loadout rules in the Warrior engine as corrected by FEAT327-ACQ-02: at most two equipped Advanced mutations per actual tree and at most one equipped Apex mutation across all trees, within the actual unlocked total slots. Dormant equipped mutations count toward those ceilings. Evaluate each feat's equipped and active prerequisites only at the acquisition or use-time checkpoints that its exact procedure specifies. A temporary all-equipped activation does not supply an equipped prerequisite, slot, mutation, class level or feat opportunity. Preserve each feat's acquisition snapshot and existing ongoing operating conditions.",
  "basis": [
    "All nine sharedProposal objects",
    "CHARACTER_CREATION_PLAYTEST.md",
    "MAXIMUM_HP_PLAYTEST.md",
    "heritage_mutation/originalWarriorCounterpartPairs"
  ],
  "exactCardApproval": false
}
```

## S3
`DescentReviewChanges/ReviewBible/data/public/feat_candidates/exact_01/shared_rules.json` — `/rules/5`
SHA-256: `bf8483fa6b70cbfc87404df5c68c48e6b849f808ec4667dcd529a89cd9b0dfb6`

```json
{
  "id": "FS-06",
  "title": "One clock, deadlines, rests and initial uses",
  "disposition": "ADOPT EXPLICIT NEW COMPLETION",
  "wording": "Use EX58's single elapsed clock, eight-hour Watches, actual task minutes, two-active-work-Watch ceiling and scheduled Rest. A change of scene, gate, holder, location, initiative, class representation or calendar label does not reset a resource. SR/LR in these new procedures mean the actual beneficial completed owner rest, with one beneficial Long Rest per 24 elapsed hours and at most two beneficial Short Rests between beneficial Long Rests. A qualifying long rest restores a short-rest allowance as already governed. Extra safe Rest paying Rest Debt alone provides no second resource recovery. Recipient-rest limits use the actual named recipient's rest epoch.\nNEW initial acquisition completion: the newly acquired limited-use feat begins with its specified full finite allowance, unless it expressly starts empty (such as accumulated stacks/charges). Reacquisition/alias duplication cannot initialize it again. An increase in a PB-based maximum increases capacity only, not current unspent uses. Genuine maximum-HP/RP/RC, Hit Die, reserve and slot changes never heal or refill unrelated current values.\nUse each explicit own-turn/any-turn/round predicate literally. A per-round allowance has one numbered global-round identity; extra turns do not refresh it. A default 'your turn' feat allowance uses the owner's regular interval unless its exact source direction expressly retains any actual turn. Newly completed missing durations use the next future original regular marker specified by the row, not the already-underway marker, retaining virtual/absolute deadlines across schedule changes. Outside initiative use the governed six-second phase without double ticks. A missed trigger is not queued for later. An early ending does not refund time or a use.",
  "basis": [
    "EX58 FL-03",
    "CLASS_PLAYTEST_RULES.md",
    "TEX-ADD regular-turn recharge correction",
    "all cohort resource conventions"
  ],
  "exactCardApproval": false
}
```

## S4
`DescentReviewChanges/ReviewBible/data/public/feat_candidates/exact_01/shared_rules.json` — `/rules/9`
SHA-256: `bf8483fa6b70cbfc87404df5c68c48e6b849f808ec4667dcd529a89cd9b0dfb6`

```json
{
  "id": "FS-10",
  "title": "Actions, command channels, mounts and personal movement",
  "disposition": "ADOPT EXPLICIT NEW COMPLETION",
  "wording": "Keep one additional FULL Action per creature/numbered round and the existing prohibition on additional Actions generating another additional Action/Bonus Action/Reaction. A source that explicitly grants a separate later Bonus Action has only its named window. Free attacks are not full Actions and cannot recursively grant other free attacks unless an exact existing exception says so. Ordinary Attack Action, card technique, weapon attack, spell attack and cantrip are not interchangeable labels.\nUse one physical creature identity, controller record, movement pool and authoritative phase. All controlled companions retain the governed shared Bonus Action command and one offensive/control companion action per owner/round. A source may command two bodies for nonoffensive actions only where stated; it does not grant two offensive actions. The feat owner must actually send the required audible/visible/mental channel; known language, trained signals, Silence and source range matter. Existing Tinker devices use actual reviewed channels and shared budgets.\nA bonded animal may be a mount only if its actual body, training, size, seat, tack, load and access meet EX58. It does not gain a second phase for being both companion and mount. Register the applicable EX58 mounted-control phase before operation; do not switch schemas midround to obtain unused budgets. Unmounted feat companions use the explicitly supplied after-owner-regular-turn phase. Mount and rider remain separate targets and actor budgets. Cavalry adds10 to each ACTUAL existing mount locomotion Speed while legally ridden, before applicable burden, terrain and later multipliers; it creates no mode, carrying capacity or engine. Route pace uses the actual resulting limiting profile under EX58, not a second free journey. The rider's being carried is not personal walking, Dragoon Momentum or a movement-cost discount. Mount/dismount uses the actual half-current-walk movement cost, access, one-per-regular-interval allowance and fitting seat; an extra Action does not reset it.",
  "basis": [
    "EX58 TR-03/04/05 and transport profiles",
    "CLASS_PLAYTEST_RULES.md",
    "Ranger/Dragoon/Tinker current engines",
    "BODY_EQUIPMENT_PLAYTEST.md"
  ],
  "exactCardApproval": false
}
```

## S5
`DescentReviewChanges/ReviewBible/data/public/feat_candidates/exact_01/supplements.json` — `/groups/1`
SHA-256: `59635b07655f06f4d3fab872b2665638a683702ad89a5322fe2df426fcd96146`

```json
{
  "id": "SUP-02",
  "cohort": "general_combat",
  "status": "NEW supplement; source directions settled, exact review pending; not an original catalog identity.",
  "selectionEnabled": false,
  "value": [
    {
      "id": "feat-animal.ground",
      "name": "Ground companion",
      "eligibleBody": "An actual positive-HP living Small or Medium terrestrial Beast with ordinary biting anatomy; preserve its actual size. Dog/fox-like examples are illustrative, not free supplied animals.",
      "abilities": {
        "STR": 12,
        "DEX": 12,
        "CON": 12,
        "INT": 3,
        "WIS": 12,
        "CHA": 6
      },
      "movement": {
        "walkFeet": 30
      },
      "attack": "One melee bite, reach5ft, attack=ownerPB+owner actualWIS modifier, damage1d6piercing; no addedWIS damage and no automatic level scaling.",
      "sense": "Choose its actually sourced keen hearing OR smell, if present, for advantage on that sense's actual Perception checks. No new keen sense if absent.",
      "limits": "No Pack Tactics, knockdown, grapple, multiattack, burrow or extraordinary source powers. Carrying uses this actual body/STR and ordinary Load/pounds limits, real harness/hands. A mount must separately meet real riding eligibility."
    },
    {
      "id": "feat-animal.flyer",
      "name": "Flying companion",
      "eligibleBody": "An actual positive-HP living Tiny winged Beast that already possesses natural flight and a pecking/biting attack. No Hover.",
      "abilities": {
        "STR": 3,
        "DEX": 14,
        "CON": 10,
        "INT": 3,
        "WIS": 14,
        "CHA": 6
      },
      "movement": {
        "walkFeet": 10,
        "flyFeet": 30
      },
      "attack": "One melee peck/bite, reach5ft, attack=ownerPB+owner actualWIS modifier, damage1d4piercing; no addedWIS damage and no level scaling.",
      "sense": "Retain actual sourced keen sight, if present, as advantage on that sense's Perception checks; no automatic darkvision/blindsight.",
      "limits": "No free Flyby, invisibility, aerial carrying exception, Hover, multiattack or ability to carry a Medium ally. Ordinary falling, weather, carrying and support apply."
    },
    {
      "id": "feat-animal.swimmer",
      "name": "Swimming companion",
      "eligibleBody": "An actual positive-HP living Small Beast with native swimming and biting anatomy. Keep its real breathing requirements; a fish gains no lungs and an air breather gains no gills.",
      "abilities": {
        "STR": 10,
        "DEX": 12,
        "CON": 12,
        "INT": 3,
        "WIS": 12,
        "CHA": 6
      },
      "movement": {
        "walkFeet": 5,
        "swimFeet": 30
      },
      "attack": "One melee bite, reach5ft, attack=ownerPB+owner actualWIS modifier, damage1d6piercing; no addedWIS damage and no level scaling.",
      "sense": "Retain one actually sourced keen hearing OR smell, if present, for that sense's Perception advantage only.",
      "limits": "The5ft ground movement is crawling/flopping for a body without legs, paying ordinary crawl cost and suffocation/exposure; no new hands, amphibiousness, Water Breathing, multiattack or sonar."
    }
  ]
}
```

## S6
`DescentReviewChanges/ReviewBible/data/public/class_playtests/ranger.json` — `/engine/7`
SHA-256: `584df9db3a6785f6268709cf3e376ae48dd62607c3ddb8e5ad5b2cc57e62f3f2`

```json
"Base choices 1–2, Pathfinder Arch 3–9, and chosen Warder/Stalker/Outrider Hero 10–20 are distinct stages. No source Arch capstone/Finale exists: level 9 receives its normal eligible choice, while 20 automatically improves your Hero Arrow once/long rest (new capstone below). Do not acquire a Hero by spending Base choices. Beast Companion is one permanent bond; it must be a willing/tamed noncorrupted beast with INT<7 and CR no greater than your class level. Its combat profile uses the bounded companion below rather than importing a full CR 20 monster."
```

## S7
`DescentReviewChanges/ReviewBible/data/public/class_playtests/ranger.json` — `/cards/29`
SHA-256: `584df9db3a6785f6268709cf3e376ae48dd62607c3ddb8e5ad5b2cc57e62f3f2`

```json
{
  "id": "ranger.hero.warder.beast-companion",
  "name": "Beast Companion",
  "className": "Ranger",
  "band": "Hero",
  "path": "Warder",
  "sourceKind": "active",
  "minimumClassLevel": 16,
  "acquisition": "selection",
  "activation": "Ritual",
  "cost": "4 RP; 1 hour with a willing/tamed eligible beast",
  "rangeAndTarget": "One beast touched",
  "duration": "Bond persists; one companion",
  "frequency": "1/long rest",
  "effect": "Bond eligible beast using standard companion stats plus Wisdom modifier HP; preserve one movement mode up to 40 ft and keen-sense advantage. Bonus Action command gives one attack, no imported boss powers. Injury persists; heal normally. Death requires a new bond after long rest, not free resummoning.",
  "source": {
    "extract": "docs/reference/Player_Rulebook_v6_source_text.txt",
    "line": 3889,
    "originalText": "Beast Companion: Tame one beast from the bestiary (CR ≤ your level, INT < 7, not corrupted) as a permanent companion that scales with your Wisdom and level."
  },
  "designStatus": "provisional-playtest",
  "spellRank": null
}
```

## S8
`docs/audit/2026-10-08/full-game/FEAT_EXACT_01_ACQUISITION_CONTRACTS.json` — `/records/10`
SHA-256: `9ebc0a915bfae02734eb982561d743f161486a6384f1bb27611271039228581b`

```json
{
  "id": "animal_companion",
  "name": "Animal Companion",
  "originalObject": {
    "id": "animal_companion",
    "name": "Animal Companion",
    "description": "You have formed a bond with an animal.",
    "prerequisite": "Animal Handling proficiency",
    "effect": "You gain an animal companion that follows your commands and fights alongside you.",
    "type": "General",
    "draft": false,
    "deprecated": false,
    "needsReview": false
  },
  "printedPrerequisitePresent": true,
  "printedPrerequisite": "Animal Handling proficiency",
  "candidatePointer": "/feats/10",
  "requirements": {
    "kind": "actualProficiency",
    "credential": "Animal Handling"
  },
  "additionalUniversalAcquisitionGate": "One actual unspent class-scheduled ASI/feat opportunity or separately authorized feat grant; prerequisite success never creates a choice.",
  "actualClassScheduleRequired": true,
  "candidateSelectionEnabled": false,
  "acquisitionDoesNotGrantUseWithoutOngoingPredicates": true,
  "completeOperativeProcedure": "NEW acquisition: with actual Animal Handling proficiency, select one already real willing/tamed Beast, noncorrupted, INT<7, that fits one of the three finite body templates below. Finding, buying or taming it requires actual campaign access/consent; the feat creates no animal, stocked shop or universal charm. Spend one uninterrupted hour together at touch range; one bond attempt per completedLR, noRP. One feat bond at a time. Use the template corresponding to the real animal's body/native movement; do not turn a dog into a bird or grant a new breathing mode. AC12+floor(ownerPB/2), maximumHP5+total owner level; template attack/ability/movement values are explicit NEW. At initial bond convert existing HP proportionally max(1,floor(newMax×oldHP/oldMax)); preserve actual conditions/injuries. Later maximum growth never heals, decreases clamp without damage. Ordinary legal healing works, but no Hit Dice/rest-refill is invented. Use one shared BA command within60ft while the animal can perceive you: in its attached phase after your regular turn, move and make its one attack or Dash/Disengage/Help/Dodge. No independent turn/Reaction; uncommanded move defensively and Dodge. The animal's HP-only chassis dies at0, producing its one actual corpse and ending the bond, with no Wound/death-save sequence; this is a feat-specific NEW rule, not generic animal law. Death/release never creates replacement: after a new completedLR, a new real animal and full hour are required. Voluntary release takes one uninterrupted hour and ends the bond without healing; preserve the same physical animal and restore its prior ordinary profile with the same current-HP fraction, not a fresh full animal. A creature cannot have this and a Ranger bond simultaneously; transferring requires actual release and new paid acquisition, not additive statistics. Owner death ends the bond and, if the animal remains alive, restores its saved ordinary profile using the same positive-HP ratio conversion as release; a dead animal remains its actual corpse. Temporary owner incapacity prevents new commands but does not cancel a previously committed legal command; after that command, uncommanded phases remain defensive. This never supplies autonomous attacks.\nNEW explicit EX58 interface: retain one real creature identity and one current control/phase record. Riding, bonding or transferring custody does not clone a turn, movement budget, Reaction, attack allowance, body or resource pool. An attached companion acts in its source-defined phase after the owner’s regular turn; a controlled mount uses EX58’s actual mounted-phase procedure. A body fitting both roles elects one compatible route before that round’s work, preserves all already-spent allowances and cannot switch routes to gain a second phase. Its actual load, tack, rider geometry, mounting/dismounting cost and ordinary independent temperament remain. One shared Bonus Action command and one offensive companion action per owner per numbered round apply where those source engines impose them. This feat supplies no blanket override of a specific engine’s attack or no-resource restrictions.\nThe three supplied body templates are NEW complete feat chassis, not evidence that such a Beast is available. Use only the corresponding real body/native mode. Saved ordinary maximum/currentHP and original constituent identity are required before bonding; no missing oldHP record is replaced by invented full health. The feat’s0HP-death rule applies only to this feat chassis; an independently governed mount/Ranger chassis retains its own rules rather than taking both.",
  "requirementsStatus": "Source-derived finite validation contract; actual positive/negative actor histories still require testing.",
  "boundaryCasesValidated": false,
  "repeats": {
    "policy": "nonrepeatable",
    "permanentChoice": true
  },
  "sourceDecision": "Adopt the bounded proposal with the completed EX58 controller/phase/physical-history interface; no future transport dependency or extra animal turn.",
  "requiresLegacyOrContextReceiptWithoutCreatingIt": false
}
```

## S9
`docs/audit/2026-10-08/full-game/FEAT_EXACT_01_ACQUISITION_CONTRACTS.json` — `/records/297`
SHA-256: `9ebc0a915bfae02734eb982561d743f161486a6384f1bb27611271039228581b`

```json
{
  "id": "companion_training",
  "name": "Companion Training",
  "originalObject": {
    "id": "companion_training",
    "name": "Companion Training",
    "description": "Your beasts do not merely follow—they fight as extensions of your will across Aethel's wild tiers, answering whistle and gesture like soldiers who never learned fear. Prestige lineage: Beastmaster. completed from the existing development record.)",
    "prerequisite": "Animal Companion feat or proficiency in Animal Handling",
    "effect": "Beast companions you command gain +2 to attack and damage rolls and inherit your Survival proficiency for tracking. As a bonus action, command one companion to attack, dash, disengage, or help; at level 10+, you may issue the same command to two companions that can hear you. When a companion reduces a foe to 0 HP, you gain advantage on your next attack against a creature within 30 feet before the end of your next turn.",
    "type": "General",
    "source": "Completed from the existing feat draft corpus on 2026-08-05; playable wording supplied, final balance pass still required.",
    "legacyEffect": "Beast companions you command gain +2 to attack and damage rolls and inherit your Survival proficiency for tracking. As a bonus action, command one companion to attack, dash, disengage, or help; at level 10+, you may issue the same command to two companions that can hear you. When a companion reduces a foe to 0 HP, you gain advantage on your next attack against a creature within 30 feet before the end of your next turn.",
    "status": "provisional-complete",
    "balanceReview": true,
    "draft": false,
    "deprecated": false,
    "needsReview": true
  },
  "printedPrerequisitePresent": true,
  "printedPrerequisite": "Animal Companion feat or proficiency in Animal Handling",
  "candidatePointer": "/feats/297",
  "requirements": {
    "kind": "any",
    "requirements": [
      {
        "kind": "ownedFeat",
        "id": "animal_companion"
      },
      {
        "kind": "actualProficiency",
        "credential": "Animal Handling"
      }
    ]
  },
  "additionalUniversalAcquisitionGate": "One actual unspent class-scheduled ASI/feat opportunity or separately authorized feat grant; prerequisite success never creates a choice.",
  "actualClassScheduleRequired": true,
  "candidateSelectionEnabled": false,
  "acquisitionDoesNotGrantUseWithoutOngoingPredicates": true,
  "completeOperativeProcedure": "Require the exact Animal Companion feat OR actual Animal Handling proficiency. Your genuinely bound/tamed Beast companions under your lawful current command gain+2 to their attack rolls and+2flat once per native attack damage roll, not per die/type or critical doubling. NEW no benefit to an ordinary allied Beast, non-Beast construct/undead/familiar, or a body you have no actual companion/control relation with. Original source-owner stats remain; add this feat layer once across overlapping trainers. For real tracking checks, if you are proficient in Survival, the companion uses its ownWIS plus your currentPB as the inherited proficiency contribution; expertise is not inherited, and a better real own contribution can replace it, not add twice. If you lack Survival proficiency, nothing is inherited. During your regular turn spend the sharedBAcommand within60ft to one companion that can hear you, selecting attack, Dash, Disengage or Help. At total level10+, the same command can name two audible owned companions taking that same action in their attached phases. This changes command recipient count only: one shared offensive companion action per owner numbered round remains. For attack, designate at most one to spend that offense; the other may move defensively and Dodge, not bank an attack. Two pure support actions can both resolve if legal. Command fails without refund if eligibility is lost; no extra independent turns/Reactions. When one of your actually commanded Beast companions reduces a meaningful hostile from positiveHP to0, you gain one advantage entitlement for your next attack against a creature within30ft of you before your next future regular end. NEW only an attack meeting30ft consumes it; a farther attack does not. Same-family reapplication refreshes one entitlement/deadline, never queues multiple. Death is not required, source floors/copy/no-reward restrictions apply.\nNEW explicit EX58 interface: retain one real creature identity and one current control/phase record. Riding, bonding or transferring custody does not clone a turn, movement budget, Reaction, attack allowance, body or resource pool. An attached companion acts in its source-defined phase after the owner’s regular turn; a controlled mount uses EX58’s actual mounted-phase procedure. A body fitting both roles elects one compatible route before that round’s work, preserves all already-spent allowances and cannot switch routes to gain a second phase. Its actual load, tack, rider geometry, mounting/dismounting cost and ordinary independent temperament remain. One shared Bonus Action command and one offensive companion action per owner per numbered round apply where those source engines impose them. This feat supplies no blanket override of a specific engine’s attack or no-resource restrictions.",
  "requirementsStatus": "Source-derived finite validation contract; actual positive/negative actor histories still require testing.",
  "boundaryCasesValidated": false,
  "repeats": {
    "policy": "nonrepeatable",
    "permanentChoice": true
  },
  "sourceDecision": "Adopt the bounded proposal with the completed EX58 controller/phase/physical-history interface; no future transport dependency or extra animal turn.",
  "requiresLegacyOrContextReceiptWithoutCreatingIt": false
}
```

## S10
`DescentReviewChanges/ReviewBible/data/playtest/character_foundation.json` — `/classes/15`
SHA-256: `21e12af81f191abe52d1e3272ed1f57c6446ed3d4487cafbd5609dff08e56a77`

```json
{
  "class": "Warrior",
  "slug": "warrior",
  "hitDie": 12,
  "fixedLaterLevelHpBase": 7,
  "savingThrowProficiencies": [
    "STR",
    "CON"
  ],
  "weaveTier": "none",
  "armor": "Medium; Heavy",
  "weapons": "Martial weapons",
  "tools": "None",
  "skillChoices": 2,
  "skillOptions": [
    "Animal Handling",
    "Athletics",
    "Intimidation",
    "Nature",
    "Perception",
    "Survival"
  ],
  "startingWealth": {
    "diceCount": 2,
    "dieSides": 4,
    "multiplierGp": 10
  },
  "multiclassPrerequisites": {
    "STR": 13,
    "CON": 13
  },
  "multiclassProficiencies": "Light armor; medium armor; shields; simple weapons; martial weapons",
  "rpByClassLevel": [
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0
  ],
  "asiClassLevels": [
    4,
    8,
    12,
    16,
    19
  ],
  "classCandidatePath": "DescentReviewChanges/ReviewBible/data/public/class_playtests/warrior.json",
  "classCandidateSha256": "b695808e3ad03411f0c482af40da964c8d2bac3235eb7c5f8953d27ed73a11b7",
  "sourceChassisLines": [
    4775,
    4776,
    4777,
    4778
  ],
  "sourceComparison": "docs/audit/2026-10-08/full-game/CHARACTER_FOUNDATION_SOURCE_EVIDENCE.json"
}
```

## S11
`DescentReviewChanges/ReviewBible/docs/mechanics/expedition/EXPEDITION_PLAYER_BOOK.md` — `lines 55–66`
SHA-256: `4c58b9f7063e562b785b8db6006699d3c4f68edd0e697d06db69662ba9b7e480`

```text
<a id="fl-03"></a>
### FL-03 — One clock, work and rest

The campaign uses one elapsed clock. A Watch is eight hours; a day contains Morning, Afternoon and Evening Watches. Combat rounds, rests, travel, treatment and work occupy their actual time within that clock. Completing a task does not add a second Watch. Entering Haven, changing teams or starting initiative does not reset elapsed time.

A generic Watch task needs **480 active minutes** before its completion check. Feasible unfinished work can continue in another Watch, without a proportional completion reward. Exact recipes, uninterrupted training, treatment, rest and spells keep their own interruption rules. Guarding, travelling, casting, directing, interpreting, assisting or working cannot also count as incompatible rest. Passive carriage qualifies for rest only when a genuinely suitable safe berth and the actual rest requirements are satisfied.

Plan at most two active work Watches and one Rest Watch per person each day. Evening is the default Rest slot; change it prospectively before that day's first assignment. Voluntary extra noncrafting travel or guard duty can replace Rest and incur its real costs and Rest Debt. This supplies no third crafting, training, research or harvesting Watch. Emergencies still consume time and interrupt the activity underway.

Missing a scheduled Rest creates **Rest Debt**. If an emergency interrupts Rest, the debt opens after that emergency ends; otherwise it opens when the missed Rest Watch ends. Complete a qualifying safe eight-hour Rest by the end of the second following canonical Watch. If the debt remains unpaid at that deadline, gain 1 Strain once for that due event and keep owing the Rest. Missing another scheduled Rest while indebted gives 1 Strain and resets the deadline. There is no automatic additional Strain every second or every Watch merely because the same debt remains.

A safe eight-hour Rest clears the debt even when you cannot receive another Long Rest's benefits. Keep the separate limits: one beneficial Long Rest per 24 elapsed hours, two beneficial Short Rests between beneficial Long Rests, the existing four-hour Morale Rest, and 24-hour Haven care. Trance reduces sleep, not the eight-hour Long-Rest requirement. Use the actual Strain and recovery chapter for what can be removed.
```

## S12
`DescentReviewChanges/ReviewBible/docs/mechanics/expedition/EXPEDITION_PLAYER_BOOK.md` — `lines 862–877`
SHA-256: `4c58b9f7063e562b785b8db6006699d3c4f68edd0e697d06db69662ba9b7e480`

```text
<a id="tr-02"></a>
### TR-02 — Control and training

A physically compatible, trained and willing mount can be controlled. An intelligent or untrained independent mount keeps its own agency. Ownership, restraint and payment do not establish willingness or training.

A conscious, nonincapacitated seated rider can direct intended movement and choose the controlled mount's one allowed Action: **Dash, Disengage or Dodge**. Use an actual trained audible or tactile channel. An audible cue shares the language rules' speech allowance. Reins require an available hand; a trained seat/leg cue works only if that individual knows it and the current seat permits it. Ordinary riding direction adds no separate Bonus Action. It does not issue a class companion command, authorize an attack or transfer rider bonuses to the animal.

A controlled mount with its own regular turn counts toward the controller's existing limit of two commanded independent-turn combat-capable subordinates. The controller's own character is separate. A source-bound companion with only an attached phase retains its own command and offensive budgets; calling it a mount does not give it a full turn. Additional pack animals can be led outside combat through real handling, but do not give a third controlled combat turn. There is no automatic animal swarm.

An independent NPC acting as a party character counts toward the twelve-character roster. A merely ridden animal does not occupy a member seat, although its actions, cargo, provisions and history still matter. Independent animals are directed by their real agency, not treated as free player attack orders.

Recheck control when the mount acts. If the rider is no longer seated or able to cue it, the channel fails, or the mount is unable or unwilling, an unexecuted riding cue cannot compel it. If able, it defensively Dodges and stays still or moves only to an immediately safer available space, chosen through its actual agency. Its existing turn and spent budgets do not reset. An executed cue is not undone. A legitimate trained noncombat lead/follow cue can continue only while its actual conditions and handler remain available.

**New ordinary training course.** A genuinely tame, willing animal can learn one named riding or harness function through 40 active hours, at most four credited training hours per animal per day. The instructor needs Animal Handling proficiency, a suitable safe space, fitting tack and a usable conditioning method. Credit complete 15-minute phases. An interruption loses unfinished prospective phase credit; actual time, feed and fees remain spent. The full-course tuition reference is 5 gp, unless an actual voluntary or paid agreement differs.

Completion requires the real course and demonstrated safe routine behavior. It grants only the practiced function, without an obedience spell, rider proficiency or Ranger bond. A documented already-trained animal needs no repeat course. Wildness or unwillingness cannot be cured by depositing hours. A war-named purchase includes combat habituation only if its actual contract and behavior establish it. Feed, water, tack and stabling are separate unless genuinely included.
```

## S13
`DescentReviewChanges/ReviewBible/docs/feats/exact-candidate-01/source-audit/GENERAL_COMBAT.md` — `lines 143–189`
SHA-256: `c56233062df177054101fe317eb8d0cdfde020a9eb616351fadb40d47c9d0643`

```text
## GC-04 — Animal Companion

### Original complete object

```json
{
  "id": "animal_companion",
  "name": "Animal Companion",
  "description": "You have formed a bond with an animal.",
  "prerequisite": "Animal Handling proficiency",
  "effect": "You gain an animal companion that follows your commands and fights alongside you.",
  "type": "General",
  "draft": false,
  "deprecated": false,
  "needsReview": false
}
```

### Original question

Complete a finite legal animal profile/selection and acquisition route, number, size/level progression, actual bond/ownership and command economy. Define initiative/actions/reactions, no-command behavior, injury/death/replacement and global creature caps. Existing Ranger companion rules are comparison evidence, not automatic Ranger class access.

### Final source decision

Adopt the bounded proposal with the completed EX58 controller/phase/physical-history interface; no future transport dependency or extra animal turn.

### Complete candidate procedure

NEW acquisition: with actual Animal Handling proficiency, select one already real willing/tamed Beast, noncorrupted, INT<7, that fits one of the three finite body templates below. Finding, buying or taming it requires actual campaign access/consent; the feat creates no animal, stocked shop or universal charm. Spend one uninterrupted hour together at touch range; one bond attempt per completedLR, noRP. One feat bond at a time. Use the template corresponding to the real animal's body/native movement; do not turn a dog into a bird or grant a new breathing mode. AC12+floor(ownerPB/2), maximumHP5+total owner level; template attack/ability/movement values are explicit NEW. At initial bond convert existing HP proportionally max(1,floor(newMax×oldHP/oldMax)); preserve actual conditions/injuries. Later maximum growth never heals, decreases clamp without damage. Ordinary legal healing works, but no Hit Dice/rest-refill is invented. Use one shared BA command within60ft while the animal can perceive you: in its attached phase after your regular turn, move and make its one attack or Dash/Disengage/Help/Dodge. No independent turn/Reaction; uncommanded move defensively and Dodge. The animal's HP-only chassis dies at0, producing its one actual corpse and ending the bond, with no Wound/death-save sequence; this is a feat-specific NEW rule, not generic animal law. Death/release never creates replacement: after a new completedLR, a new real animal and full hour are required. Voluntary release takes one uninterrupted hour and ends the bond without healing; preserve the same physical animal and restore its prior ordinary profile with the same current-HP fraction, not a fresh full animal. A creature cannot have this and a Ranger bond simultaneously; transferring requires actual release and new paid acquisition, not additive statistics. Owner death ends the bond and, if the animal remains alive, restores its saved ordinary profile using the same positive-HP ratio conversion as release; a dead animal remains its actual corpse. Temporary owner incapacity prevents new commands but does not cancel a previously committed legal command; after that command, uncommanded phases remain defensive. This never supplies autonomous attacks.
NEW explicit EX58 interface: retain one real creature identity and one current control/phase record. Riding, bonding or transferring custody does not clone a turn, movement budget, Reaction, attack allowance, body or resource pool. An attached companion acts in its source-defined phase after the owner’s regular turn; a controlled mount uses EX58’s actual mounted-phase procedure. A body fitting both roles elects one compatible route before that round’s work, preserves all already-spent allowances and cannot switch routes to gain a second phase. Its actual load, tack, rider geometry, mounting/dismounting cost and ordinary independent temperament remain. One shared Bonus Action command and one offensive companion action per owner per numbered round apply where those source engines impose them. This feat supplies no blanket override of a specific engine’s attack or no-resource restrictions.
The three supplied body templates are NEW complete feat chassis, not evidence that such a Beast is available. Use only the corresponding real body/native mode. Saved ordinary maximum/currentHP and original constituent identity are required before bonding; no missing oldHP record is replaced by invented full health. The feat’s0HP-death rule applies only to this feat chassis; an independently governed mount/Ranger chassis retains its own rules rather than taking both.

### Final authored examples

A ground companion bonded by level5 has max10HP. A real animal at half of its oldHP converts to5HP, not full10.

At0HP it dies and leaves its actual body. Taking a rest alone neither revives it nor creates another beast.

### Preserved submitted procedure

NEW acquisition: with actual Animal Handling proficiency, select one already real willing/tamed Beast, noncorrupted, INT<7, that fits one of the three finite body templates below. Finding, buying or taming it requires actual campaign access/consent; the feat creates no animal, stocked shop or universal charm. Spend one uninterrupted hour together at touch range; one bond attempt per completedLR, noRP. One feat bond at a time. Use the template corresponding to the real animal's body/native movement; do not turn a dog into a bird or grant a new breathing mode. AC12+floor(ownerPB/2), maximumHP5+total owner level; template attack/ability/movement values are explicit NEW. At initial bond convert existing HP proportionally max(1,floor(newMax×oldHP/oldMax)); preserve actual conditions/injuries. Later maximum growth never heals, decreases clamp without damage. Ordinary legal healing works, but no Hit Dice/rest-refill is invented. Use one shared BA command within60ft while the animal can perceive you: in its attached phase after your regular turn, move and make its one attack or Dash/Disengage/Help/Dodge. No independent turn/Reaction; uncommanded move defensively and Dodge. The animal's HP-only chassis dies at0, producing its one actual corpse and ending the bond, with no Wound/death-save sequence; this is a feat-specific NEW rule, not generic animal law. Death/release never creates replacement: after a new completedLR, a new real animal and full hour are required. Voluntary release takes one uninterrupted hour and ends the bond without healing; preserve the same physical animal and restore its prior ordinary profile with the same current-HP fraction, not a fresh full animal. A creature cannot have this and a Ranger bond simultaneously; transferring requires actual release and new paid acquisition, not additive statistics. Owner death ends the bond and, if the animal remains alive, restores its saved ordinary profile using the same positive-HP ratio conversion as release; a dead animal remains its actual corpse. Temporary owner incapacity prevents new commands but does not cancel a previously committed legal command; after that command, uncommanded phases remain defensive. This never supplies autonomous attacks.

### Preserved submitted examples

A ground companion bonded by level5 has max10HP. A real animal at half of its oldHP converts to5HP, not full10.

At0HP it dies and leaves its actual body. Taking a rest alone neither revives it nor creates another beast.
```

## S14
`DescentReviewChanges/ReviewBible/tools/feat_exact_01_companion_acquisition_model.py` — `lines 1–84`
SHA-256: `58995b0286356ecd8fa9675de563ad79544062f4e13f89db1545338065f2cf66`

```text
"""Completed conditional Animal Companion acquisition histories.

This validates a supplied successful one-hour history. Rejection means that the
submitted history cannot prove an acquisition; it does not implement interrupted
attempt refunds, a taming system, command phases or an animal combat engine.
"""
from copy import deepcopy
from feat_exact_01_acquisition_models import pb
from feat_exact_01_remaining_owned_chains import RemainingOwnedChains


class CompanionAcquisition(RemainingOwnedChains):
    def acquire_companion_from_completed_history(self, level, ordinary_body, receipt, template_id):
        before = self.snapshot()
        body = deepcopy(ordinary_body)
        if self.pay.has('animal_companion') or 'animal_companion' in self.initializations:
            raise ValueError('Nonrepeatable Animal Companion grant already recorded')
        if not self.prerequisite('animal_companion'):
            raise ValueError('Actual Animal Handling proficiency is required')
        required_body = {'id', 'worldId', 'evidenceMode', 'creatureType', 'size', 'living', 'corrupted', 'abilities',
                         'ordinaryMaximumHP', 'ordinaryCurrentHP', 'nativeMovement', 'anatomy', 'breathing',
                         'conditions', 'injuries', 'controllerRelation', 'currentBonds', 'keenSenses'}
        if not required_body <= set(body):
            raise ValueError('Complete existing ordinary body and HP evidence required')
        if body['evidenceMode'] != 'conditional_fixture' or receipt.get('evidenceMode') != 'conditional_fixture':
            raise ValueError('This finite model handles only explicitly conditional records')
        if body['creatureType'] != 'Beast' or not body['living'] or body['corrupted'] or not 0 <= body['abilities']['INT'] < 7:
            raise ValueError('Body must be a living noncorrupted Beast with INT below7')
        old_max, old_current = body['ordinaryMaximumHP'], body['ordinaryCurrentHP']
        if type(old_max) is not int or type(old_current) is not int or not 0 < old_current <= old_max:
            raise ValueError('Actual positive ordinary current/max HP required; no invented full health')
        if body['currentBonds']:
            raise ValueError('Body already has another bond; no additive Ranger/feat chassis')
        relation = body['controllerRelation']
        if relation.get('actorId') != receipt.get('actorId') or relation.get('kind') not in {'willing', 'tamed'}:
            raise ValueError('This body needs an actual declared willing/tamed relationship to this actor')
        if body['worldId'] != receipt.get('worldId') or body['id'] != receipt.get('bodyId'):
            raise ValueError('Bond work and body identity differ')
        if receipt.get('ordinaryProfileBefore') != body:
            raise ValueError('Completed history must preserve the same complete ordinary profile')
        if receipt.get('completedMinutes') != 60 or receipt.get('interruptions') != [] or receipt.get('touchMinutes') != 60:
            raise ValueError('A full uninterrupted hour at touch range is required')
        if receipt.get('firstAttemptInEpoch') != {'epoch': 'initial-acquisition', 'ordinal': 1}:
            raise ValueError('This finite witness supplies only the first initial-allowance attempt')
        if receipt.get('opportunity') != self.first + ':' + str(level):
            raise ValueError('Completed acquisition must use its actual selected opportunity')
        templates = {x['id']: x for x in self.supplements['SUP-02']}
        if template_id not in templates:
            raise ValueError('Unknown source body template')
        native = body['nativeMovement']; anatomy = body['anatomy']
        eligible = {
            'feat-animal.ground': body['size'] in {'Small', 'Medium'} and native.get('walkFeet', 0) > 0 and 'bite' in anatomy,
            'feat-animal.flyer': body['size'] == 'Tiny' and native.get('flyFeet', 0) > 0 and 'wings' in anatomy and bool({'bite', 'peck'} & set(anatomy)),
            'feat-animal.swimmer': body['size'] == 'Small' and native.get('swimFeet', 0) > 0 and 'bite' in anatomy,
        }
        if not eligible[template_id]:
            raise ValueError('Template does not fit the existing body/native movement')
        template = templates[template_id]; total = sum(self.pay.current_classes.values())
        new_max = 5 + total; new_current = max(1, new_max * old_current // old_max)
        allowed_senses = {'sight'} if template_id == 'feat-animal.flyer' else {'hearing', 'smell'}
        available_senses = set(body['keenSenses']) & allowed_senses
        chosen_sense = receipt.get('keenSenseChoice')
        if (available_senses and chosen_sense not in available_senses) or (not available_senses and chosen_sense is not None):
            raise ValueError('No invented keen sense; select one actually sourced permitted sense')
        grant = self.pay.commit('animal_companion', self.first + ':' + str(level),
            choice={'bodyId': body['id'], 'templateId': template_id, 'keenSense': chosen_sense}, prerequisites_met=True)
        self.initializations['animal_companion'] = {
            'ordinaryProfile': body, 'completedHistory': deepcopy(receipt), 'bodyId': body['id'], 'templateId': template_id,
            'currentBody': {'id': body['id'], 'size': body['size'], 'abilities': deepcopy(template['abilities']),
                'movement': deepcopy(template['movement']), 'breathing': deepcopy(body['breathing']),
                'conditions': deepcopy(body['conditions']), 'injuries': deepcopy(body['injuries']),
                'maximumHP': new_max, 'currentHP': new_current, 'AC': 12 + pb(total) // 2,
                'keenSense': chosen_sense, 'controlPhase': 'attached-after-owner-regular-turn'},
            'bondAttemptAllowance': {'maximum': 1, 'current': 0, 'epoch': 'initial-acquisition'},
            'scope': 'Successful completed initial bond only; no replacement, release, commands, mount phase or actual campaign authentication.'}
        return grant

    def advance(self, level):
        super().advance(level)
        if 'animal_companion' in self.initializations:
            current = self.initializations['animal_companion']['currentBody']
            total = sum(self.pay.current_classes.values()); current['maximumHP'] = 5 + total
            current['currentHP'] = min(current['currentHP'], current['maximumHP'])
            current['AC'] = 12 + pb(total) // 2
```

## S15
`docs/audit/2026-10-08/full-game/FEAT_EXACT_01_COMPANION_ACQUISITION_CHECK.json` — `/limits`
SHA-256: `742debaa4c8020d80b75c21cd655966336746c4c8526a8b01128aab612e2fb00`

```json
[
  "The ordinary animals and completed contact-hour facts are explicit conditional world premises, not actual campaign availability, a taming result, a newly reviewed bestiary species or a source-created animal.",
  "The parent-positive histories retain Animal Handling proficiency; the owned parent node itself is separately checked. No unsupported training-loss/retraining procedure is invented to isolate that OR branch.",
  "Rejected completed records do not define when an interrupted live attempt spends/refunds a feat opportunity or bond allowance. Only successful completed initial acquisition histories are represented.",
  "Bond replacements after later Long Rests, release, owner death, creature death/healing, command phases, attacks, mounting, custody transfer and Companion Training effects remain use-procedure work.",
  "All335 identities now have finite partial prerequisite evidence. This is not335 complete acquisitions, all permanent selections, full original-case execution, actual runtime or exact candidate approval."
]
```
