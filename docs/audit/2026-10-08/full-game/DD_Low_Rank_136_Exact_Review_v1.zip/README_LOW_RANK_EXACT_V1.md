# Complete low-rank spell candidate — exact review v1

INTERNAL joint-review packet. Contains complete private comparison/source evidence. This archive is not a public distribution package; its separately identified public candidate contains only the selected public spell originals and their new authored procedures.

Start with these actual full artifacts under DescentReviewChanges/ReviewBible:

- docs/playtest/LOW_RANK_136_CANDIDATE.md: every full card and all 20 shared rules, including the nonoperative Blink receipt.
- data/playtest/spell_drafts/candidate_low_rank_136.json: complete internal 137-identity envelope, every original source-authoring record, full current public source receipts, exact class access, 141 book bindings, mode/alias decisions and 136 operationalCandidate objects.
- data/public/spell_playtests/candidate_low_rank_136.json and matching .md: complete actual public envelope and manuscript. No internalSourceAuthoringRecord or private comparison catalogs are projected into it. All 137 sourceReceipt objects are exactly equal to the existing public catalog. No catalog promotion has occurred.
- docs/playtest/LOW_RANK_137_AUTHORED_BOUNDARIES.md and data/playtest/spell_drafts/low_rank_137_authored_boundaries.json: all 187 complete authored boundary records. Matching public JSON and manuscript are in data/public/spell_playtests.

Audit artifacts under docs/audit/2026-10-08/full-game:

- LOW_RANK_136_CANDIDATE_QUESTION_MAP.json: every original question mapped to the actual full candidate paragraph, preserved modes and book bindings.
- LOW_RANK_136_CANDIDATE_AUTHORING_RECEIPT.json: all authored artifact hashes, 136 procedures, Blink receipt, 141 bindings and preserved inputs.
- LOW_RANK_136_CANDIDATE_LOCAL_VALIDATION.json: 49 passing checks covering exact source preservation, whole public parity, manuscript paragraphs, all 187 boundaries, seven deliberate corruption cases, existing helper cases and four transparent arithmetic cases. The access/pricing sweeps comprise 18,840 real class/level gates and 2,808 ordinary pricing calculations. Quotation fixtures temporarily assume approved status ONLY in local memory; no such fixture is written to any source/catalog file.
- low-rank137-source-reviewer-files/: all 28 final source-verdict package files, with original manifest and evidence; final source review LR-SOURCE-2026-10-11/reply 6ecc2e79-e637-4c69-ac48-61069296008c.

All 342 submitted original payloads remain identical at their original paths. ORIGINAL_SOURCE_V3_FILE_MANIFEST.json preserves the original manifest. The original v3 source ZIP is also included intact so the reviewer source reproduction scripts have the exact input archive. Their reported 3,476/3,726 checks have NOT been rerun locally; do not confuse those reviewer reports with the new 49 local checks. No reviewer script has been executed locally. Inspect scripts before running them in a fresh extracted workspace.

The new builder copies all final operative directions into complete candidate fields, with only five explicit editorial introduction removals. NEW clauses remain labeled. Complete source-authoring records and original source fields remain intact. Candidates are authored tabletop procedures, not deployed engine implementations. They use operationalCandidate rather than the live operational catalog slot, which remains null for every selected identity. Components/mode/range prose is intentionally retained in full rather than reduced to a lossy scalar model; any later runtime adapter is a separate task.

The 187 examples are authored expectations, NOT 187 executed gameplay tests. Existing helpers validate only their stated access/cost/roll/HP/clock scope. No complete new spell controller, sensing, trigger, wrapper, summons, class-specific hook execution, world premise authentication, human teaching trial or numerical balance approval is claimed. In particular, the original class/spell/feat comparison statuses are unchanged.

Please exact-review all LRE-01 through LRE-13 groups against the ACTUAL full artifacts and the final source directions. Return precise bounded corrections by spell ID/JSON path/manuscript paragraph with replacement wording and finite acceptance cases, or scoped authored-candidate acceptance. Do not reopen a generic preliminary source conference. One tiny editorial point to assess: TR-28 Enhance Ability is explicitly concentration up to TEN minutes; its preserved source boundary uses the shorthand “minute window.” The duration is not reduced to one minute by that example.

Carry fulfilled LAX language, NWX teaching and 687 internal/433 public recipe gates forward. Current ordinary spell totals are still 276 operational / 572 pending. Blink stays receipt-only, as do unassigned higher-rank alternatives. Literal setting terms receive no new interpretation. Final actual joint whole-game flow review must precede the already authorized GitHub push; verified remote commit must precede careful cosmology review. Source preservation/deletion constraints remain in force. There is no newly inferred owner-approval gate from notebook wording.

The validator writes only its named local report when deliberately run in a fresh extracted workspace. The builder writes its explicitly named candidate artifacts; the packaging script refuses to overwrite its existing frozen ZIP. All protected source hashes are checked before writing.
