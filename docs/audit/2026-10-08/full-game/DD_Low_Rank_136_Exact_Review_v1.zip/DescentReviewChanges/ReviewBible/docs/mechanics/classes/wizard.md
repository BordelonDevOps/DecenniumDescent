# Wizard — class playtest v0.1

**PROVISIONAL — exact numbers and acquisition are proposals for table testing.** Approved source books remain intact. The17 class names identify Base classes; Arch and Hero are later stages, with explicit exceptions below.

[All classes](../CLASS_PLAYTEST_INDEX.md) · [Shared test rules](../CLASS_PLAYTEST_RULES.md) · [Session log](../CLASS_PLAYTEST_SESSION_LOG.md)

[Preserved book and registry evidence](../../../data/playtest/class_sources/wizard.json) · [Normalized card data](../../../data/public/class_playtests/wizard.json)

## Class engine and setup

**Book setup (provisional engine resolves any explicit conflicts below):**

- Main Attribute: Intelligence
- Secondary Attributes: Constitution (for resilience under pressure)
- Hit Points: Low (6 + Constitution modifier at 1st level, 1d6 per level thereafter)
- Armor Proficiency: None (Arcane Armor feat unlocks Light armor casting)
- Weapon Proficiency: Arcane Staff, Wand, Spellblade
- Tool Proficiency: Arcana tools, scribe's supplies

PROVISIONAL PLAYTEST CONTRACT. Intelligence is the Wizard class ability. S = 1/2/3/4 at Wizard levels 1/5/11/17. M = max(1, Intelligence modifier). Wizard spell attack = d20 + normal character proficiency bonus + Intelligence modifier. Wizard spell save DC = 8 + normal character proficiency bonus + Intelligence modifier.

The Wizard remains three distinct stages: Base Wizard at levels 1-2, Arch Arcanist at levels 3-9, and one Hero path at levels 10-20: Spellbinder, Elementalist or Necromancer. Hero paths are not additional starting classes and their features cannot be selected before their Wizard class-level gates.

SPELLBOOK. At Wizard 1 your spellbook contains six chosen rank-1 Wizard spells. Arcane School Specialization also adds one legal rank-1 bonus spell of your chosen school without replacing one of those six. For this provisional progression, add 2 legal Wizard spells to the book at each Wizard level 2-4, 3 at each level 5-8, 4 at each level 9-12, 5 at each level 13-16 and 6 at each level 17-20. Level-up additions cost no money or scribing time.

LEGAL RANKS. Maximum Wizard spell rank by Wizard class level is: rank 1 at levels 1-2, rank 2 at 3-4, rank 3 at 5-6, rank 4 at 7-8, rank 5 at 9-10, rank 6 at 11-12, rank 7 at 13-14, rank 8 at 15-16 and rank 9 at 17-20. Grand Tier at level 20 is a special casting permission, not a tenth ordinary rank. A Wizard may learn Wizard-list spells from any school up to the legal rank unless a spell itself has an additional prerequisite.

PREPARED SPELL MATRIX. After a long rest, prepare a number of matrices equal to Wizard level + Intelligence modifier, minimum 1, selecting only spells currently recorded in your spellbook and within your legal rank. You cast ordinary Wizard spells only from prepared matrices unless a feature explicitly overrides that restriction. Preparing the full daily matrix set normally requires 1 hour of spellbook study. Matrix Efficiency reduces this to 45 minutes.

DUPLICATE PREPARATION. You may prepare the same spell more than once, primarily to carry different Matrix Mastery configurations. Duplicate copies never create additional first-cast Dissonance exemptions. For Refrain and the protected strain rule, all prepared copies sharing the same underlying spell name belong to one matrix family regardless of modification.

MIDDAY SUBSTITUTION. Once between long rests, you may perform a 10-minute Spellbook Study ritual to replace one prepared matrix with another legal spell from your spellbook. The replacement cannot exceed your legal Wizard rank. Sigil Rewrite and Matrix Mastery may improve this process as explicitly stated.

SPELL ACQUISITION BY SCRIBING. A found Wizard spell may be copied into the spellbook if its rank is legal for you. Baseline scribing requires 2 hours and 50 gp of inks/materials per spell rank, treating rank 0 as 1 for this calculation. Spell Scribing halves both values to 1 hour and 25 gp per rank. Failure to finish the work consumes no spellbook entry but materials already expended during an interrupted hour are lost.

SPELLBOOK LOSS. Losing the spellbook does not erase matrices currently prepared in memory; you may continue casting those prepared matrices until you next rebuild or change preparation. A blank replacement book can be seeded with your currently prepared spells at 1 hour and 25 gp per effective spell rank each. An unprepared spell you previously recorded can be reconstructed from memory with 8 hours, 100 gp per rank and an Intelligence (Arcana) check against DC 10 + spell rank. Failure consumes that attempt's time and half its materials; another attempt can be made after a long rest. Recovering the original book automatically restores access to its surviving entries.

ARCANE SCHOOL SPECIALIZATION is automatic at Wizard 1. Choose exactly one of the eight schools. Your spell attacks with that school gain +1 and your Wizard save DC for that school's spells gains +1. You also add one legal rank-1 spell of that school to the spellbook. The source table explicitly supplies seven school passives; the eighth core school, Abjuration, is named elsewhere but its passive row is missing. Its provisional playtest passive is identified below rather than silently presented as recovered text.

ABJURATION, provisional completion for the omitted eighth row: once per round after you cast an Abjuration spell, gain temporary HP equal to PB until the start of your next regular turn. CONJURATION: creatures summoned by your Wizard spells gain +1 maximum HP per Wizard level. DIVINATION: once per long rest reroll one failed saving throw and use the new result. ENCHANTMENT: when a creature fails its initial save against one of your Enchantment spells, a printed control duration of at least 1 round may last one additional round, but every normally allowed repeat save still occurs. EVOCATION: when casting an area Evocation spell, exclude one creature from its initial damaging area; that creature automatically succeeds and takes no damage if success normally halves damage. ILLUSION: gain +2 on concentration saves made to maintain Illusion spells. NECROMANCY: once per turn during a real encounter when a hostile non-summoned creature dies from your Necromancy spell, gain 1 temporary HP; it is not permanent healing. TRANSMUTATION: after casting a Transmutation spell, gain +5 feet Speed until the end of that turn.

PROTECTED DISSONANCE INTERFACE. The first cast of each different prepared matrix family during an encounter generates 0 BASE Dissonance. This exemption affects only base strain. Refrain and explicitly printed strain costs still apply; the suite disables generic Overcast and does not layer historical Burn onto Dissonance. Repeating a matrix family follows normal Refrain immediately. Preparing duplicates or differently modified copies of the same underlying spell never refreshes the exemption.

Core Systems V 2 Resonance Points and spell-rank RP costs are authoritative for Wizard spellcasting. There are no historical spell slots in this pilot. Wizard cards tagged wizard-spell are always-prepared class matrices once acquired, do not consume a daily prepared-matrix position and use the same RP, concentration, Refrain and protected first-distinct-matrix rules as other Wizard spells. Their printed RP cost replaces any generic rank cost; never pay both.

RITUAL CASTING is automatic at Wizard 2. A Wizard spell in your spellbook with the Ritual tag can be cast from the book without being prepared by increasing its casting time by at least 10 minutes. A ritual cast costs 0 RP unless that ritual explicitly lists a consumed RP cost, cannot be used during an encounter and cannot generate or vent Dissonance through ordinary casting strain.

Only one concentration effect can normally be maintained. Starting a second concentration effect ends the first. Damage uses the current Core Systems concentration rule; required half-damage rounding is down for this pilot. Spell Tether and the level-17 Tethered Cast are the only Wizard-specific exceptions in this draft, and each has an explicit RP price, duration and one-tether cap.

MATRIX MASTERY MODIFICATIONS. After acquiring Matrix Mastery, each prepared ordinary spell matrix may carry at most one modification chosen during preparation. QUICK SUBSTITUTION: once per short rest, replace one matrix marked Quick Substitution with another spellbook spell of exactly the same rank using a 1-minute ritual instead of the normal 10-minute midday swap; the replacement loses the modification until the next long rest. COMPONENT ENHANCEMENT: when casting a damaging or healing matrix, spend 1 additional RP to add one extra die of the spell's primary damage or healing die to one roll; if the spell has no such die this modification has no effect. MATRIX LINKING: pair two different prepared matrix families during preparation; after legally casting one, the other costs 1 less RP, minimum 1, if cast before the end of your next regular turn, at most once per pair per round. STABILITY REINFORCEMENT: gain +2 on concentration saves caused by damage while maintaining that matrix. A matrix modification never creates another spell cast or proc event.

All sources share a maximum of one additional full Action per creature per round. Additional Actions cannot grant another additional Action, Bonus Action or Reaction. Spell copies, Matrix Sharing, Arcane Fusion, Dual Cast and similar effects pay all explicitly required RP and do not produce duplicate resource, cast-proc or action-grant chains beyond their written resolution.

Round recharge counters decrease once at the start of your regular initiative turn even if you cannot act. Extra Actions and extra turns do not tick recharge. Outside initiative, each uninterrupted 6 seconds counts as one tick. Only positive counters can be reset or shortened and each named ability can receive at most one reset or shortening per round.

SUMMON COMMAND LIMIT. All Wizard-controlled conjured, raised and bound companions share one damaging/control Companion Command per Wizard regular turn. Spend one Bonus Action to command exactly one such creature to move up to its Speed and use one damaging or control action from its stat block. Uncommanded creatures may reposition defensively and take Dodge but cannot deal damage or impose conditions. No summoned or raised creature can create XP, treasure, RP, Dissonance relief, additional corpses or kill-resource farms.

NECROMANCER STANDARD UNDEAD. Corpse Harvest and Auto-Raise share a maximum of three standard raised minions. Skeleton: AC 14, HP 6 + 2 × Wizard level, Speed 30; Bone Shot, range 30 feet, Wizard spell attack, 1d6+S necrotic. Zombie: AC 12, HP 10 + 3 × Wizard level, Speed 20; Slam, reach 5 feet, Wizard spell attack, 1d8+S necrotic. Goblin Thrall, available only from a goblinoid corpse: AC 13, HP 8 + 2 × Wizard level, Speed 30; Shiv, reach 5 feet, Wizard spell attack, 1d6+S necrotic. These are pre-Flesh-Ascendant statistics.

NECROMANCER AUTO-RAISE. Once per round when one of your standard undead minions personally lands the killing blow on an eligible humanoid and your standard-minion count is below three, its corpse rises at the end of the current turn as the same mechanical minion type that scored the kill, if physically possible. A new minion cannot act during that same round. Auto-Raise costs no Action or RP but can never exceed the three-minion cap or generate a new resource, corpse chain, XP or treasure event. Without Infernal Pact only humanoids qualify.

ELITE UNDEAD PETS. Necromancers may bind Boneflayer, Dreadblade and Wraithbound, at most one of each and three elite pets total. They use the same shared Companion Command limit as standard undead. Boneflayer: AC 14, HP 12 + 2 × Wizard level, Speed 30. Bone Shards: range 60, Wizard spell attack, 2d6+S necrotic. Fear Pulse replaces its attack: enemies within 10 feet make Wisdom saves; failure Frightened until end of next turn; recharge 3. Grave Miasma replaces its attack: 10-foot-radius point within 30 feet until start of your next turn; enemies entering or starting there take 1d6 necrotic once; recharge 3.

Dreadblade: AC 16, HP 16 + 3 × Wizard level, Speed 30. Disrupting Blade: reach 5 feet, Wizard spell attack, 1d8+S necrotic; a concentrating target immediately makes its concentration save with disadvantage. On a natural 20 the target is Weakened until the end of its next turn, taking -1 on attack rolls. Dreadblade has advantage on saves against forced movement.

Wraithbound: AC 14, HP 10 + 2 × Wizard level, Fly 40 and hover. While it has not attacked or imposed control since the end of its previous turn it is Invisible; attacking ends that state until the end of its next turn. Wraith Strike: reach 5 feet, Wizard spell attack, 1d8+S necrotic. On natural 20 the target makes a Constitution save against your Wizard DC; failure Stuns until the end of its next turn.

Flesh Ascendant's bonus applies after the listed base statistics: every undead creature you control gains +2 maximum HP per Wizard level. If at least two of your undead creatures are active, each gains +1 AC and +1 on saving throws. This does not increase the standard-minion or elite-pet caps.

DARK-TRAUMA INTERFACE. Necromancer features involving corpse desecration, infernal bargains, domination, body control or Mind Prison remain subject to the project's existing dark-content and trauma boundaries. A table may fade description to black without changing mechanics. No feature changes a player's real belief, permanently transfers ownership of a player character or silently retires a PC.

PROPOSED ACQUISITION. Wizard 1 automatically gains Arcane School Specialization, Spell Matrix System and the starting spellbook, then chooses 4 selectable Base cards, at least 2 Active. Wizard 2 automatically gains Counterspell and Ritual Casting, then chooses 2 additional selectable Base cards. Counterspell is not also placed in the Arch selection pool.

At Wizard 3 enter Arcanist, automatically gain Arcane Tradition as an upgrade of the SAME level-1 school rather than choosing another school, and choose 2 selectable Arch cards, at least 1 Active. Wizard 4 grants one eligible Base/Arch choice. Wizard 5 grants one Base/Arch choice plus automatic School Mastery. Wizard 6 grants one Base/Arch choice plus automatic Arcane Ward. Wizard 7 grants one eligible Arch choice. Wizard 8 grants one Base/Arch choice. Wizard 9 grants one eligible Arch choice plus automatic Dual Cast.

At Wizard 10 choose Spellbinder, Elementalist or Necromancer and gain 2 Hero cards from that path. ELEMENTALIST EXCEPTION: Elemental Affinity is automatic at path selection and counts as one of those two level-10 Hero acquisitions, so an Elementalist chooses only one additional Hero card at level 10. Levels 11, 13, 15, 17 and 19 each grant one eligible unselected Base/Arch choice. Levels 12, 14, 16 and 18 each grant one Hero-path choice. The chosen Final Theorem is automatic at Wizard 20. School Mastery, Counterspell, Arcane Tradition and all progression-table automatic features are never duplicated as selections.

All acquisition gates use Wizard class level rather than total character level. Normal proficiency bonus follows the game's ordinary total-character-level rule. A multiclass dip cannot unlock higher spell ranks, Arcanist cards, Hero cards, Final Theorems or progression-table features.

Class matrices tagged wizard-spell receive a rank in normalized card data equal to maximum ordinary Wizard rank at their minimum class-level gate (cap 9). Printed RP cost replaces generic rank cost. Counterspell is rank 1 at its explicit level 2 automatic grant. This explicit convention closes rank-dependent Counterspell/Dissonance interactions without inventing extra costs.

Cantrip completion: know 3 Wizard cantrips at 1, 4 at 4, 5 at 10, using the shared missing-repertoire fallback. Cantrips are known directly and do not consume prepared matrices. Always-prepared class matrices are additional cards, not extra arbitrary ordinary spells. Class spell ranks and the normalized activation field resolve incomplete source terminology.

**Protected source interface:** The first cast of each different prepared Spell Matrix in an encounter generates 0 base Dissonance; repeating a matrix builds Refrain normally.

## Advancement and resources

RP authority: Direct Core Systems V2 table. Rank access is separate from RP capacity. ASI/feat milestones follow general advancement and are not duplicated by a card.

| Class level | Stage | RP maximum | Max ordinary spell rank | Class choices / automatic grants |
|---:|---|---:|---:|---|
| 1 | Base | 4 | 1 | Choose 4 Base; at least 2 active |
| 2 | Base | 6 | 1 | Choose 2 Base; automatic: Counterspell, Ritual Casting |
| 3 | Arch | 10 | 2 | Choose 2 Arch; at least 1 active; automatic: Arcane Tradition |
| 4 | Arch | 12 | 2 | Choose 1 Base/Arch; ASI or feat |
| 5 | Arch | 16 | 3 | Choose 1 Arch; automatic: School Mastery |
| 6 | Arch | 20 | 3 | Choose 1 Base/Arch; automatic: Arcane Ward |
| 7 | Arch | 24 | 4 | Choose 1 Arch |
| 8 | Arch | 28 | 4 | Choose 1 Base/Arch; ASI or feat |
| 9 | Arch | 32 | 5 | Choose 1 Arch; automatic: Dual Cast |
| 10 | Hero | 36 | 5 | Choose 2 Hero; at least 1 active; automatic: Elemental Affinity (Elementalist); Elementalist counts automatic Affinity as one of its two acquisitions and chooses only one additional card |
| 11 | Hero | 40 | 6 | Choose 1 Base/Arch |
| 12 | Hero | 44 | 6 | Choose 1 Hero; ASI or feat |
| 13 | Hero | 48 | 7 | Choose 1 Base/Arch; automatic: Overchannel |
| 14 | Hero | 52 | 7 | Choose 1 Hero |
| 15 | Hero | 56 | 8 | Choose 1 Base/Arch; automatic: Arcane Feedback |
| 16 | Hero | 60 | 8 | Choose 1 Hero; ASI or feat |
| 17 | Hero | 64 | 9 | Choose 1 Base/Arch; automatic: Tethered Cast |
| 18 | Hero | 68 | 9 | Choose 1 Hero |
| 19 | Hero | 72 | 9 | Choose 1 Base/Arch; ASI or feat |
| 20 | Hero | 80 | 9 | No ordinary selection; automatic: Arcane Sanctuary (Spellbinder), Reality Edit (Elementalist), Mind Prison (Necromancer), Grand Reservoir |

Source-listed options for mutually exclusive paths are alternatives, not simultaneous grants. A minimum level on an Arch card may be above9; that card remains an Arch option during later progression.

See [legal build examples](../CLASS_PLAYTEST_BUILD_EXAMPLES.md) for actual level-by-level choices and exceptional progression combinations.

## Worked encounter

1. Wizard 9 example: Intelligence 16 gives M=3, PB=4 and S=2. Assume the authoritative Core V 2 sheet gives this Wizard 32 RP. The Wizard has prepared Fireball, Web, Shield and other matrices; has selected Spell Efficiency; and begins a real encounter with Dissonance 3.
2. Turn 1: cast prepared Fireball for its normal rank-3 Core V 2 cost of 5 RP, so RP 32→27. This is the first Fireball matrix-family cast of the encounter, so its BASE casting strain produces 0 Dissonance. Any independent Overcast or other risk would still apply, but none is used here.
3. Turn 2: cast Fireball again. Spell Efficiency reduces the repeat by 1 RP, minimum 1, so this cast costs 4 RP and RP 27→23. Because Fireball has already received its first-distinct exemption, normal Refrain applies to this repeat; the protected interface does not suppress that Refrain.
4. Enemy turn: an enemy begins a rank-3 spell. Counterspell costs 3 RP, so RP 23→20. The Wizard rolls Intelligence + proficiency against DC 16 under the pilot Counterspell card. Counterspell is a different always-prepared class matrix, so its first cast receives the base-strain exemption; success negates the triggering spell after its costs are paid.
5. Turn 3: use the automatic level-9 Dual Cast, which is available once per short rest. Cast two DIFFERENT prepared spells of rank 1 or 2 as one Action sequence, paying both costs. If they cost 2 RP and 3 RP, RP 20→15. Each underlying matrix independently checks first-cast/Refrain state, but cast-trigger effects that say 'once per turn' still trigger only once as written.
6. Turn 4: cast one member of a Matrix-Linked pair for 3 RP, RP 15→12. Before the end of the next regular turn the paired matrix qualifies for its 1-RP reduction. If that paired spell normally costs 3 RP, its linked cast costs 2 RP, RP 12→10. The link changes cost only; it creates no additional spell, Action or Dissonance exemption.

## Base cards

#### Arcane Recovery

**Level 1 · selection · wizard.base.arcane-recovery**

| Activation | Cost | Range / targets | Duration | Frequency |
|---|---|---|---|---|
| Passive | 0 | Self | Instantaneous during a completed short rest | 1/long rest |

Arcane Recovery. Tags: base, passive, resonance. Once between long rests when you complete a short rest, restore RP equal to half your Wizard class level rounded up, never above your normal maximum. This is RP recovery, not a second pool, and cannot trigger spell-cast, Refrain or Dissonance effects.

<details><summary>Preserved source wording — book line5196</summary>

Arcane Recovery: Once per day during a short rest, recover RP equal to half your Wizard level (rounded up), up to your normal maximum.

</details>

#### Spell Scribing

**Level 1 · selection · wizard.base.spell-scribing**

| Activation | Cost | Range / targets | Duration | Frequency |
|---|---|---|---|---|
| Passive | 0 | Your spellbook | Permanent | Always |

Spell Scribing. Tags: base, passive, spellbook. Copying a legal found Wizard spell into your spellbook requires 1 hour and 25 gp of inks and components per spell rank, treating rank 0 as rank 1 for this calculation, instead of the pilot baseline 2 hours and 50 gp. Level-up spells remain free.

<details><summary>Preserved source wording — book line5197</summary>

Spell Scribing: Copy spells into your spellbook at half the normal cost and time.

</details>

#### Arcane Insight

**Level 1 · selection · wizard.base.arcane-insight**

| Activation | Cost | Range / targets | Duration | Frequency |
|---|---|---|---|---|
| Passive | 0 | Self | Permanent | Always |

Arcane Insight. Tags: base, passive, knowledge. Gain proficiency in Arcana, or expertise if already proficient. When examining an active magical effect, spell residue, magic item or arcane construction, you may make an Intelligence (Arcana) check to determine its broad school, function or unusual matrix behavior. The Director sets the normal knowledge DC; failure supplies no invented fact.

<details><summary>Preserved source wording — book line5198</summary>

Arcane Insight: Identify magical effects and items with greater accuracy than non-wizards.

</details>

#### Matrix Efficiency

**Level 1 · selection · wizard.base.matrix-efficiency**

| Activation | Cost | Range / targets | Duration | Frequency |
|---|---|---|---|---|
| Passive | 0 | Self | Daily preparation | Always |

Matrix Efficiency. Tags: base, passive, matrix. Your normal full daily Spell Matrix preparation time is reduced from 1 hour to 45 minutes. This does not reduce the separate 10-minute midday substitution ritual, spell scribing, rituals or spellbook reconstruction unless another feature explicitly says so.

<details><summary>Preserved source wording — book line5199</summary>

Matrix Efficiency: Reduce the preparation time for spells by 25%.

</details>

#### Scholarly Mind

**Level 1 · selection · wizard.base.scholarly-mind**

| Activation | Cost | Range / targets | Duration | Frequency |
|---|---|---|---|---|
| Passive | 0 | Self | Permanent | Always |

Scholarly Mind. Tags: base, passive, knowledge. You have advantage on Intelligence checks whose primary purpose is recalling, researching or analyzing arcane theory, magical history, planar magical principles or constructed spell formulae. It does not grant advantage on spell attacks, Counterspell checks or general Investigation unrelated to arcane scholarship.

<details><summary>Preserved source wording — book line5200</summary>

Scholarly Mind: Gain advantage on Intelligence checks related to arcane knowledge.

</details>

#### Arcane Bolt

**Level 1 · selection · wizard.base.arcane-bolt**

| Activation | Cost | Range / targets | Duration | Frequency |
|---|---|---|---|---|
| Action | 1 RP | One creature within 60 feet | Instantaneous | At will while RP remains |

Arcane Bolt. Tags: base, active, wizard-spell, universal, damage. Make a Wizard spell attack. On a hit deal S d6 + M force damage. Arcane Bolt is an always-prepared class matrix once acquired and uses the normal first-distinct-matrix and Refrain rules.

Class-spell rank: **1** for Dissonance, countering and rank restrictions; pay printed RP only.

<details><summary>Preserved source wording — book line5203</summary>

Arcane Bolt: Launch a bolt of pure arcane energy that deals force damage to a single target.

</details>

#### Minor Conjuration

**Level 1 · selection · wizard.base.minor-conjuration**

| Activation | Cost | Range / targets | Duration | Frequency |
|---|---|---|---|---|
| Action | 1 RP | One unoccupied space within 10 feet | 1 hour | At will while RP remains; one object at a time |

Minor Conjuration. Tags: base, active, wizard-spell, conjuration. Create one nonmagical unattended object that fits inside a 1-foot cube, weighs no more than 10 pounds and is made of common nonvaluable material such as wood, cloth, clay, iron or glass. It cannot be food, poison, currency, a spell component with listed cost, ammunition with special properties or a functional complex mechanism. Creating another dismisses the first.

Class-spell rank: **1** for Dissonance, countering and rank restrictions; pay printed RP only.

<details><summary>Preserved source wording — book line5204</summary>

Minor Conjuration: Create a temporary, small inanimate object that lasts for 1 hour.

</details>

#### Arcane Shield

**Level 1 · selection · wizard.base.arcane-shield**

| Activation | Cost | Range / targets | Duration | Frequency |
|---|---|---|---|---|
| Reaction | 2 RP | Self | Until start of your next regular turn | Recharge 2 rounds |

Arcane Shield. Tags: base, active, wizard-spell, abjuration, protection. Trigger when an attack roll would hit you. Gain +2 AC against the triggering attack and until the start of your next regular turn, potentially causing the attack to miss. Temporary AC from another Arcane Shield does not stack.

Class-spell rank: **1** for Dissonance, countering and rank restrictions; pay printed RP only.

<details><summary>Preserved source wording — book line5205</summary>

Arcane Shield: Create a barrier of magical force that provides temporary protection.

</details>

#### Analyze Magic

**Level 1 · selection · wizard.base.analyze-magic**

| Activation | Cost | Range / targets | Duration | Frequency |
|---|---|---|---|---|
| Action | 1 RP | One magical creature, object or effect within 30 feet | Instantaneous | Recharge 1 round |

Analyze Magic. Tags: base, active, wizard-spell, divination, knowledge. Make an Intelligence (Arcana) check against DC 10 + the effect's spell rank, treating a non-spell effect's Director-assigned tier as rank. On success learn its school or magical category, one active mechanical property and whether it is currently sustained, cursed or bound to another effect. Failure reveals only that magic is present.

Class-spell rank: **1** for Dissonance, countering and rank restrictions; pay printed RP only.

<details><summary>Preserved source wording — book line5206</summary>

Analyze Magic: Study a magical effect or item to gain insight into its properties and function.

</details>

#### Spellbook Study

**Level 1 · selection · wizard.base.spellbook-study**

| Activation | Cost | Range / targets | Duration | Frequency |
|---|---|---|---|---|
| Ritual | 0 RP | Self and spellbook | 10 minutes | 1/long rest |

Spellbook Study. Tags: base, active, matrix, ritual. Replace one currently prepared matrix with one legal spell recorded in your spellbook. The replacement must be within your Wizard rank limit. This is the normal midday substitution permission; it does not alter the spellbook, create another prepared-matrix position or reset first-cast/Refrain history for an underlying matrix family already cast this encounter.

<details><summary>Preserved source wording — book line5207</summary>

Spellbook Study: Spend time studying your spellbook to prepare a different selection of spells.

</details>

#### Counterspell

**Level 2 · automatic · wizard.base.counterspell**

| Activation | Cost | Range / targets | Duration | Frequency |
|---|---|---|---|---|
| Reaction | 3 RP | One creature you perceive casting a spell within 60 feet | Instantaneous | Automatic at Wizard 2; recharge 2 rounds |

Counterspell. Tags: arch-source, automatic, wizard-spell, abjuration, disruption. Trigger when a creature begins casting a spell. Make an Intelligence check adding proficiency against DC 10 + twice the spell's rank, treating rank 0 as 0. Success negates the triggering spell after its costs are paid; failure lets it resolve. This is gained automatically at Wizard 2 and is never also selected from the Arch pool.

Class-spell rank: **1** for Dissonance, countering and rank restrictions; pay printed RP only.

<details><summary>Preserved source wording — book line5222</summary>

Counterspell: Disrupt an enemy's spellcasting, potentially negating their spell entirely.

</details>

#### Ritual Casting

**Level 2 · automatic · wizard.supplement.ritual-casting**

| Activation | Cost | Range / targets | Duration | Frequency |
|---|---|---|---|---|
| Ritual | 0 RP unless the individual ritual explicitly states otherwise | As the ritual spell | As the ritual spell | At will outside encounters with sufficient time |

Source progression line 5184. Cast a Wizard spell bearing the Ritual tag directly from your spellbook without preparing it. Increase its casting time by at least 10 minutes. Ritual Casting cannot be completed during an encounter, does not use an ordinary prepared-matrix position and does not generate or vent normal casting Dissonance.

Prerequisite: See class engine and progression.

<details><summary>Preserved source wording — book line5184</summary>

| 2 | Counterspell Reaction, Ritual Casting |

</details>

## Arch cards

#### Floating Preparation

**Level 3 · selection · wizard.arch.floating-preparation**

| Activation | Cost | Range / targets | Duration | Frequency |
|---|---|---|---|---|
| Passive | 0 | Self | Daily preparation | Always |

Floating Preparation. Tags: arch, passive, matrix. Increase your maximum prepared Spell Matrix count by 1. The extra matrix can come from any school and obeys all ordinary spellbook and rank restrictions. It is a prepared matrix for every rule, including protected strain, duplicate-family tracking and Matrix Mastery modifications.

<details><summary>Preserved source wording — book line5213</summary>

Floating Preparation: Prepare 1 extra spell from any school each day

</details>

#### Sigil Rewrite

**Level 3 · selection · wizard.arch.sigil-rewrite**

| Activation | Cost | Range / targets | Duration | Frequency |
|---|---|---|---|---|
| Bonus Action | 0 | Self and spellbook | Instantaneous | 1/long rest |

Sigil Rewrite. Tags: arch, passive-upgrade, matrix. Replace one prepared matrix with a different spell from your spellbook of exactly the same rank without performing the normal 10-minute ritual. The replacement receives no special Dissonance reset for a matrix family already used this encounter and must obey current Wizard rank eligibility.

<details><summary>Preserved source wording — book line5214</summary>

Sigil Rewrite: Once/day, instantly swap a spell you know for another of the same tier

</details>

#### Spell Tether

**Level 5 · selection · wizard.arch.spell-tether**

| Activation | Cost | Range / targets | Duration | Frequency |
|---|---|---|---|---|
| Triggered | 3 RP | Self | Maximum 3 rounds | 1/long rest |

Spell Tether. Tags: arch, passive-upgrade, concentration, tether. When you begin a second concentration spell that targets only yourself while already concentrating on a self-only spell, spend 3 additional RP. For up to 3 rounds you may maintain both. Whenever damage requires a concentration save, make one save; failure ends BOTH spells. Starting a third concentration effect ends both tethered spells before the new one begins. Spell Tether and Tethered Cast cannot be combined; maximum two sustained concentration effects total. Only one Spell Tether can exist at a time.

<details><summary>Preserved source wording — book line5215</summary>

Spell Tether: Maintain 2 self-buff spells without concentration (1/rest)

</details>

#### Matrix Mastery

**Level 5 · selection · wizard.arch.matrix-mastery**

| Activation | Cost | Range / targets | Duration | Frequency |
|---|---|---|---|---|
| Passive | 0 | Prepared matrices | Daily preparation | Always |

Matrix Mastery. Tags: arch, passive, matrix. During preparation you may assign at most one common Matrix Mastery modification to each ordinary prepared spell: Quick Substitution, Component Enhancement, Matrix Linking or Stability Reinforcement, using the exact common definitions in the Wizard engine. Always-prepared class-card matrices cannot receive these modifications unless a card explicitly says otherwise.

<details><summary>Preserved source wording — book line5216</summary>

Matrix Mastery: Modify spell matrices to change minor aspects of prepared spells.

</details>

#### Arcane Tradition

**Level 3 · automatic · wizard.arch.arcane-tradition**

| Activation | Cost | Range / targets | Duration | Frequency |
|---|---|---|---|---|
| Passive | 0 | Your level-1 Arcane School | Permanent | Automatic at Wizard 3; not a selection |

Arcane Tradition. Tags: arch, school, automatic. Your level-1 Arcane School becomes your Arcanist tradition; do not choose a second school. Prepare one additional matrix from that same school each day without counting it against your normal prepared-matrix maximum. It otherwise obeys all ordinary rank, spellbook, Dissonance and duplicate-family rules.

<details><summary>Preserved source wording — book line5217</summary>

Arcane Tradition: Choose a school of magic to specialize in, gaining bonuses to spells of that school.

</details>

#### Spell Efficiency

**Level 7 · selection · wizard.arch.spell-efficiency**

| Activation | Cost | Range / targets | Duration | Frequency |
|---|---|---|---|---|
| Passive | 0 | Repeated prepared matrices | Until end of your next regular turn | At most once per turn |

Spell Efficiency. Tags: arch, passive, resonance. After you cast a prepared matrix, the next cast of that SAME matrix family before the end of your next regular turn costs 1 less RP, minimum 1. This cost reduction does not suppress Refrain, cannot reduce Overcast or additional feature costs and cannot combine with itself.

<details><summary>Preserved source wording — book line5218</summary>

Spell Efficiency: Reduce the Resonance Point cost of frequently cast spells by 10%.

</details>

#### Improved Concentration

**Level 7 · selection · wizard.arch.improved-concentration**

| Activation | Cost | Range / targets | Duration | Frequency |
|---|---|---|---|---|
| Passive | 0 | Self | While concentrating | Always |

Improved Concentration. Tags: arch, passive, concentration. You have advantage on Constitution saving throws made because damage threatens your concentration on a Wizard spell. This does not alter the DC, protect a Tether from rules that explicitly end both effects, or prevent Silence, incapacitation and other non-damage concentration failures.

<details><summary>Preserved source wording — book line5219</summary>

Improved Concentration: Advantage on concentration checks when taking damage.

</details>

#### Arcane Lock

**Level 3 · selection · wizard.arch.arcane-lock**

| Activation | Cost | Range / targets | Duration | Frequency |
|---|---|---|---|---|
| Action | 2 RP | One door, chest, portal or unattended object within touch | 8 hours | Recharge 2 rounds |

Arcane Lock. Tags: arch, active, wizard-spell, abjuration. Magically seal the target. Opening it without your permission requires a Strength check or thieves'/arcane-tool check against your Wizard spell DC. Dispel Magic can end the lock. You can designate up to M creatures who can bypass it. This does not make the object physically indestructible.

Class-spell rank: **2** for Dissonance, countering and rank restrictions; pay printed RP only.

<details><summary>Preserved source wording — book line5223</summary>

Arcane Lock: Create a magical barrier that prevents entry or access to an object or area.

</details>

#### Dispel Magic

**Level 5 · selection · wizard.arch.dispel-magic**

| Activation | Cost | Range / targets | Duration | Frequency |
|---|---|---|---|---|
| Action | 3 RP | One creature, object or magical effect within 60 feet | Instantaneous | Recharge 2 rounds |

Dispel Magic. Tags: arch, active, wizard-spell, abjuration. Choose one ongoing spell effect you can perceive. If its rank is 3 or lower, end it. If it is rank 4 or higher, make an Intelligence check adding proficiency against DC 10 + spell rank; success ends it. Permanent artifact properties and effects explicitly immune to dispelling are unaffected.

Class-spell rank: **3** for Dissonance, countering and rank restrictions; pay printed RP only.

<details><summary>Preserved source wording — book line5224</summary>

Dispel Magic: End magical effects in an area or on a target.

</details>

#### Dimensional Pocket

**Level 7 · selection · wizard.arch.dimensional-pocket**

| Activation | Cost | Range / targets | Duration | Frequency |
|---|---|---|---|---|
| Ritual | 3 RP | One point within 5 feet | 8 hours | 1/long rest |

Dimensional Pocket. Tags: arch, active, wizard-spell, conjuration, ritual. Create an extradimensional storage space holding up to 100 pounds or 10 cubic feet of unattended nonliving material. Retrieving or placing an item while adjacent to the opening uses an object interaction. Living creatures cannot enter. When duration ends, remaining contents appear harmlessly in the nearest unoccupied space.

Class-spell rank: **4** for Dissonance, countering and rank restrictions; pay printed RP only.

<details><summary>Preserved source wording — book line5225</summary>

Dimensional Pocket: Create a small extradimensional space to store items.

</details>

#### Arcane Sight

**Level 3 · selection · wizard.arch.arcane-sight**

| Activation | Cost | Range / targets | Duration | Frequency |
|---|---|---|---|---|
| Action | 2 RP | Self; 60-foot sight | Concentration, maximum 10 minutes | Recharge 2 rounds |

Arcane Sight. Tags: arch, active, wizard-spell, divination, concentration. While active you perceive magical auras within 60 feet and automatically know each visible aura's school or broad magical category. As an Action on a later turn, examine one aura to learn whether it is concentrated, summoned, cursed, warded or linked to another visible magical effect. Total cover blocks sight.

Class-spell rank: **2** for Dissonance, countering and rank restrictions; pay printed RP only.

<details><summary>Preserved source wording — book line5226</summary>

Arcane Sight: See magical auras and effects for a short duration.

</details>

#### School Mastery

**Level 5 · automatic · wizard.supplement.school-mastery**

| Activation | Cost | Range / targets | Duration | Frequency |
|---|---|---|---|---|
| Passive | 0 | Your level-1 Arcane School | Permanent | Automatic at Wizard 5 |

Source progression line 5186. This is the one School Mastery progression grant, not a second school choice or duplicate feat. Increase the level-1 Arcane School spell-attack and spell-save bonus from +1 to +2 total. Its school passive and bonus-spell rules otherwise remain unchanged.

Prerequisite: See class engine and progression.

<details><summary>Preserved source wording — book line5186</summary>

| 5 | Bonus Feat: School Mastery |

</details>

#### Arcane Ward

**Level 6 · automatic · wizard.supplement.arcane-ward**

| Activation | Cost | Range / targets | Duration | Frequency |
|---|---|---|---|---|
| Passive | 0 | Self | Until next long rest | Choose after each long rest |

Source progression line 5187. After preparing spells, choose one of acid, cold, fire, force, lightning, necrotic, psychic, radiant or thunder that is dealt by at least one prepared spell of your Arcane School. Gain resistance to that damage type until your next long rest. If none of your prepared school spells deals a damage type, choose force. This is provisional completion of the source's ambiguous 'chosen school's element' wording.

Prerequisite: See class engine and progression.

<details><summary>Preserved source wording — book line5187</summary>

| 6 | Arcane Ward (resistance to chosen school's element) |

</details>

#### Dual Cast

**Level 9 · automatic · wizard.supplement.dual-cast**

| Activation | Cost | Range / targets | Duration | Frequency |
|---|---|---|---|---|
| Action | Pay the complete RP costs of both spells | As each spell | As each spell | 1/short rest |

Source progression line 5188. Choose two DIFFERENT prepared Wizard spells of rank 1 or 2, neither of which summons a creature or grants an additional Action. Cast both sequentially as one Action, paying both RP costs. They cannot both require concentration. Each matrix separately updates first-cast/Refrain history. Features that trigger merely from 'casting a spell' may trigger once for each actual matrix unless that feature itself says once per turn; no trigger may create another Dual Cast or additional full Action.

Prerequisite: See class engine and progression.

<details><summary>Preserved source wording — book line5188</summary>

| 9 | Dual Cast (cast 2 Tier 1–2 spells in a round) |

</details>

## Hero cards

### Spellbinder

#### Sigil Authority

**Level 10 · selection · wizard.hero.spellbinder.sigil-authority**

| Activation | Cost | Range / targets | Duration | Frequency |
|---|---|---|---|---|
| Passive | 0 | Self | Permanent | Always |

Sigil Authority. Tags: hero, spellbinder, passive. Gain +1 on Counterspell and Dispel Magic ability checks. When a creature is Charmed, Frightened, Paralyzed, Restrained or Stunned by a source other than the spell you are currently casting, your Spellbinder spells that force it to save use a Wizard spell DC 2 higher. This increase never applies retroactively to the condition that enabled it.

<details><summary>Preserved source wording — book line5242</summary>

Sigil Authority: +1 to all counterspell rolls, +2 DC vs targets currently affected by crowd control

</details>

#### Spell Preservation

**Level 10 · selection · wizard.hero.spellbinder.spell-preservation**

| Activation | Cost | Range / targets | Duration | Frequency |
|---|---|---|---|---|
| Passive | 0 | Your spellbook | Permanent | Always |

Spell Preservation. Tags: hero, spellbinder, passive, spellbook. Your primary spellbook cannot be destroyed, erased or rendered permanently unreadable by non-artifact mundane or magical means. It can still be stolen, hidden, transported, suppressed, sealed by an artifact-level effect or voluntarily abandoned. Copies and backup books do not automatically receive this protection.

<details><summary>Preserved source wording — book line5243</summary>

Spell Preservation: Your spellbook cannot be destroyed by non-artifact means.

</details>

#### Knowledge Shield

**Level 12 · selection · wizard.hero.spellbinder.knowledge-shield**

| Activation | Cost | Range / targets | Duration | Frequency |
|---|---|---|---|---|
| Passive | 0 | Allies directly protected by one of your Abjuration Wizard spells | Until start of your next regular turn | At most once per ally per round |

Knowledge Shield. Tags: hero, spellbinder, passive, protection. When you cast an Abjuration spell that grants AC, temporary HP, resistance or a saving-throw benefit to an ally, that ally also gains +2 on its next saving throw before the start of your next regular turn. Multiple Knowledge Shields do not stack.

<details><summary>Preserved source wording — book line5244</summary>

Knowledge Shield: When you cast a protective spell, allies gain +2 to saving throws.

</details>

#### Matrix Sharing

**Level 14 · selection · wizard.hero.spellbinder.matrix-sharing**

| Activation | Cost | Range / targets | Duration | Frequency |
|---|---|---|---|---|
| Action | 2 RP plus the shared spell's normal RP cost | One willing ally within 30 feet | Until end of ally's next regular turn | 1/short rest |

Matrix Sharing. Tags: hero, spellbinder, passive-upgrade, matrix. Choose one prepared Wizard spell of rank 3 or lower with an Action casting time. Pay both costs now. The ally may cast that spell once before the end of its next turn without paying RP, using your spell attack and DC. The shared spell cannot summon creatures, create additional Actions, use Overcast, be Shared again or bypass concentration limits. Granting this permission takes your Action; the ally spends its own normal Action to cast. The ally owns concentration and strain for the cast, and it does not update your matrix-family history or grant you cast-trigger resources.

<details><summary>Preserved source wording — book line5245</summary>

Matrix Sharing: Grant an ally temporary access to one of your prepared spells.

</details>

#### Arcane Memory

**Level 16 · selection · wizard.hero.spellbinder.arcane-memory**

| Activation | Cost | Range / targets | Duration | Frequency |
|---|---|---|---|---|
| Triggered | Normal RP cost of recalled spell | As recalled spell | As recalled spell | 1/long rest |

Arcane Memory. Tags: hero, spellbinder, passive-upgrade, spellbook. Cast one legal-rank Wizard spell that you previously prepared and have recorded in your campaign memory log, even if it is not currently prepared or its spellbook entry is unavailable. Pay the normal RP cost and obey casting time, concentration and all ordinary restrictions. This grants no spell above your Wizard rank limit.

<details><summary>Preserved source wording — book line5246</summary>

Arcane Memory: Recall and cast any spell you've ever prepared once per long rest.

</details>

#### Seal Magic

**Level 10 · selection · wizard.hero.spellbinder.seal-magic**

| Activation | Cost | Range / targets | Duration | Frequency |
|---|---|---|---|---|
| Action | 4 RP | One creature within 60 feet | Maximum 3 rounds | Recharge 3 rounds |

Seal Magic. Tags: hero, spellbinder, wizard-spell, control. Choose one of the eight schools and target one creature. It makes a Wisdom save. On failure it cannot cast spells of the chosen school. At the end of each of its turns it repeats the save, ending the Seal on success. The effect ends automatically after 3 rounds and never prevents non-spell class techniques merely because they are magical.

Class-spell rank: **5** for Dissonance, countering and rank restrictions; pay printed RP only.

<details><summary>Preserved source wording — book line5249</summary>

Seal Magic: Prevent a target from casting spells of a specific school (WIS save, 3 rounds)

</details>

#### Runic Snare

**Level 10 · selection · wizard.hero.spellbinder.runic-snare**

| Activation | Cost | Range / targets | Duration | Frequency |
|---|---|---|---|---|
| Action | 3 RP | One 10-foot square within 30 feet | Until triggered or 1 minute | Recharge 3 rounds |

Runic Snare. Tags: hero, spellbinder, wizard-spell, glyph, control. Place a visible-to-you glyph. The first hostile creature entering the square makes a Dexterity save. Failure deals S d6 force damage, causes Restrained until the end of its next turn and makes it drop one non-attuned held item of its choice. Success takes half damage with no restraint or drop. A Restrained target may repeat a Strength save at the end of its turn.

Class-spell rank: **5** for Dissonance, countering and rank restrictions; pay printed RP only.

<details><summary>Preserved source wording — book line5250</summary>

Runic Snare: Glyph trap explodes in a 2x2 root + disarm on trigger

</details>

#### Counterpulse

**Level 12 · selection · wizard.hero.spellbinder.counterpulse**

| Activation | Cost | Range / targets | Duration | Frequency |
|---|---|---|---|---|
| Triggered | 1 RP | Caster whose spell you successfully Counterspelled | Until end of target's next turn | At most once per round |

Counterpulse. Tags: hero, spellbinder, counter, control. Immediately after your Counterspell succeeds, spend 1 RP. The countered caster is Silenced until the end of its next turn. This is part of the successful counter event rather than another spell cast and cannot trigger another Counterpulse.

<details><summary>Preserved source wording — book line5251</summary>

Counterpulse: Countering a spell silences the caster for 1 round

</details>

#### Spell Absorption

**Level 14 · selection · wizard.hero.spellbinder.spell-absorption**

| Activation | Cost | Range / targets | Duration | Frequency |
|---|---|---|---|---|
| Reaction | 4 RP | One hostile spell that directly targets you | Instantaneous | 1/short rest |

Spell Absorption. Tags: hero, spellbinder, wizard-spell, abjuration. Trigger after you become the target of a hostile spell but before it resolves. Make an Intelligence check adding proficiency against DC 10 + twice the spell rank. On success that spell has no effect on you, though it resolves normally against other targets, and you gain temporary HP equal to spell rank + M. On failure it resolves normally and the use is spent.

Class-spell rank: **7** for Dissonance, countering and rank restrictions; pay printed RP only.

<details><summary>Preserved source wording — book line5252</summary>

Spell Absorption: Absorb a hostile spell, gaining temporary hit points equal to the spell's level.

</details>

#### Knowledge Transfer

**Level 16 · selection · wizard.hero.spellbinder.knowledge-transfer**

| Activation | Cost | Range / targets | Duration | Frequency |
|---|---|---|---|---|
| Action | 2 RP | One willing ally you touch | 1 hour | 1/short rest |

Knowledge Transfer. Tags: hero, spellbinder, knowledge. Choose one language you can speak or one skill in which you are proficient. The ally gains proficiency in that language or skill for 1 hour. Expertise is never transferred. The feature conveys functional knowledge, not memories, secrets, class features, spellcasting or tool ownership.

<details><summary>Preserved source wording — book line5253</summary>

Knowledge Transfer: Temporarily grant an ally knowledge of a skill or language you possess.

</details>

#### Arcane Sanctuary

**Level 20 · automatic · wizard.hero.spellbinder.arcane-sanctuary**

| Activation | Cost | Range / targets | Duration | Frequency |
|---|---|---|---|---|
| Ritual | 10 RP | You and up to eight willing creatures within 15 feet | 1 hour | 1/week; automatic Spellbinder Final Theorem |

Arcane Sanctuary. Tags: hero, spellbinder, final-theorem, demiplane. Perform a 10-minute ritual to open a temporary demiplane and transport the willing targets inside. For 1 hour creatures inside cannot cast or activate harmful magical effects and magical effects originating outside cannot enter. Nonmagical violence remains physically possible, ordinary healing and communication may function, and creatures can leave through the visible exit as an Action. When the hour ends all occupants return to the entry location or nearest legal spaces.

<details><summary>Preserved source wording — book line5256</summary>

Arcane Sanctuary: Create a demiplane of safety for 1 hour where harmful magic cannot function (1/week).

</details>

### Elementalist

#### Core Sync

**Level 10 · selection · wizard.hero.elementalist.core-sync**

| Activation | Cost | Range / targets | Duration | Frequency |
|---|---|---|---|---|
| Passive | 0 | Your current Elemental Affinity | Permanent | Always |

Core Sync. Tags: hero, elementalist, passive, elemental. Rank-1 and rank-2 Wizard spells whose primary damage type matches your current Elemental Affinity cost 1 less RP, minimum 1. Once per long rest as a Bonus Action you may change your Elemental Affinity to Fire, Cold, Lightning or Earth; changing it does not alter currently active spell effects.

<details><summary>Preserved source wording — book line5269</summary>

Core Sync: Spells of your chosen element cost 1 fewer RP at Tier 1–2 (minimum 1 RP); you may change your elemental affinity once per long rest

</details>

#### Matrix Innovation

**Level 10 · selection · wizard.hero.elementalist.matrix-innovation**

| Activation | Cost | Range / targets | Duration | Frequency |
|---|---|---|---|---|
| Passive | 0 | Prepared matrices | Daily preparation | One Innovated Matrix per long rest |

Matrix Innovation. Tags: hero, elementalist, passive, matrix. During daily preparation choose two different same-rank damaging Wizard spells in your spellbook. Create one Innovated Matrix using one spell's normal range/area shape and the other's printed primary damage type. All other effects, dice, save, duration and RP cost come from the first spell. This is one matrix and one spell cast, not both spells simultaneously.

<details><summary>Preserved source wording — book line5270</summary>

Matrix Innovation: Combine aspects of two different spells into one casting.

</details>

#### Spell Adaptation

**Level 12 · selection · wizard.hero.elementalist.spell-adaptation**

| Activation | Cost | Range / targets | Duration | Frequency |
|---|---|---|---|---|
| Triggered | 2 additional RP | One damaging prepared Wizard spell you are beginning to cast | For that spell | 1/short rest |

Spell Adaptation. Tags: hero, elementalist, passive-upgrade, matrix. Before casting, choose one: change its acid, cold, fire, lightning or thunder damage to another type in that list; or change a 10-foot-radius area to a 15-foot cone, a 15-foot cone to a 30-foot line, or a 30-foot line to a 10-foot radius. Dice, save, duration and other effects remain unchanged.

<details><summary>Preserved source wording — book line5271</summary>

Spell Adaptation: Change a spell's damage type or effect type once per short rest.

</details>

#### Efficient Casting

**Level 14 · selection · wizard.hero.elementalist.efficient-casting**

| Activation | Cost | Range / targets | Duration | Frequency |
|---|---|---|---|---|
| Triggered | 0 | Self | Instantaneous | At most once per round |

Efficient Casting. Tags: hero, elementalist, passive, resonance. After you pay RP and resolve a Wizard spell costing at least 1 RP, roll a d20. On 17-20, restore the BASE RP actually spent on that spell, up to your maximum. Additional costs from Overcast, Matrix modifications, Fusion or other features are not refunded. This trigger may occur at most once per round.

<details><summary>Preserved source wording — book line5272</summary>

Efficient Casting: 20% chance to refund the RP spent on a spell immediately after it resolves.

</details>

#### Arcane Experimentation

**Level 16 · selection · wizard.hero.elementalist.arcane-experimentation**

| Activation | Cost | Range / targets | Duration | Frequency |
|---|---|---|---|---|
| Passive | 0 | Self | Permanent | Always |

Arcane Experimentation. Tags: hero, elementalist, passive, crafting. You have advantage on Intelligence checks made to research a genuinely new spell formula, alter an existing spell during downtime or create a magical item using an arcane recipe. This provides no free materials, automatic success, reduced downtime or permission to exceed campaign crafting and spell-creation limits.

<details><summary>Preserved source wording — book line5273</summary>

Arcane Experimentation: Gain advantage on checks to create new spells or magical items.

</details>

#### Elemental Affinity

**Level 10 · automatic · wizard.hero.elementalist.elemental-affinity**

| Activation | Cost | Range / targets | Duration | Frequency |
|---|---|---|---|---|
| Passive | 0 | Self | Permanent until changed by Core Sync | Automatic when Elementalist is chosen; counts as one level-10 Hero acquisition |

Elemental Affinity. Tags: hero, elementalist, elemental, automatic. Choose Fire, Cold, Lightning or Earth when entering Elementalist. Fire corresponds to fire damage, Cold to cold, Lightning to lightning and Earth to magical bludgeoning damage created by earth effects. Wizard spells matching the affinity gain +2 to their Wizard save DC or +2 on their spell attack, as applicable, and once per spell add one extra die matching that spell's primary damage die to one damage roll.

<details><summary>Preserved source wording — book line5276</summary>

Elemental Affinity: Choose 1 element (Fire, Ice, Lightning, Earth); all spells of that element gain +2 DC, +1 damage tier

</details>

#### Combo Surge

**Level 10 · selection · wizard.hero.elementalist.combo-surge**

| Activation | Cost | Range / targets | Duration | Frequency |
|---|---|---|---|---|
| Triggered | 2 RP | One target damaged by the second qualifying spell | Until end of target's next turn plus listed damage | At most once per round |

Combo Surge. Tags: hero, elementalist, elemental, combo. When you damage the same creature on consecutive regular turns with the required pair in either order, you may trigger one combo. Fire + Cold: the target takes 1d6 fire at the start of its next turn and makes a Strength save; failure Restrains it until the end of that turn. Lightning + Earth: the target is knocked Prone and makes a Constitution save; failure Stuns it until the end of its next turn, subject to one successful Combo-Surge Stun per target per encounter. Other element pairs have no Combo Surge in this pilot.

<details><summary>Preserved source wording — book line5277</summary>

Combo Surge: Casting two different elements in sequence triggers a combo effect

</details>

#### Cycling Ward

**Level 12 · selection · wizard.hero.elementalist.cycling-ward**

| Activation | Cost | Range / targets | Duration | Frequency |
|---|---|---|---|---|
| Reaction | 2 RP | Self | Until start of your next regular turn | Recharge 2 rounds |

Cycling Ward. Tags: hero, elementalist, wizard-spell, protection. Trigger after you cast a spell dealing acid, cold, fire, lightning, thunder or Elemental-Affinity Earth damage. Choose one damage type dealt by that spell. Until the start of your next turn, whenever you take that type, reduce the damage by one-quarter rounded down, minimum 0. This is not the generic Resistance condition and therefore does not double with itself.

Class-spell rank: **6** for Dissonance, countering and rank restrictions; pay printed RP only.

<details><summary>Preserved source wording — book line5280</summary>

Cycling Ward: Rotate resistance to your cast element (25% reduction)

</details>

#### Spell Modification

**Level 14 · selection · wizard.hero.elementalist.spell-modification**

| Activation | Cost | Range / targets | Duration | Frequency |
|---|---|---|---|---|
| Triggered | 2 additional RP | One prepared spell you are beginning to cast | For that spell | 1/short rest |

Spell Modification. Tags: hero, elementalist, matrix. Choose exactly one modification before casting: Range increases by 30 feet; Area increases a circular radius or cone length by 5 feet or a line length by 10 feet; Duration doubles a non-concentration duration with a printed maximum of 5 rounds or less, to no more than 10 rounds. It cannot alter target count, concentration status, Actions, saving-throw cadence or damage dice.

<details><summary>Preserved source wording — book line5281</summary>

Spell Modification: Alter a prepared spell on the fly, changing its range, duration, or area of effect.

</details>

#### Arcane Fusion

**Level 16 · selection · wizard.hero.elementalist.arcane-fusion**

| Activation | Cost | Range / targets | Duration | Frequency |
|---|---|---|---|---|
| Action | Combined normal RP costs of both spells + 2 RP | As the two selected spells | Instantaneous or as individual legal effects | 1/long rest |

Arcane Fusion. Tags: hero, elementalist, fusion, matrix. Choose two DIFFERENT prepared Wizard spells of rank 5 or lower, neither of which summons a creature or grants an additional Action. Pay both full RP costs plus 2 and resolve both spells sequentially as one Action. They may share or have different legal targets. They cannot both require concentration. Each matrix separately updates protected first-cast/Refrain state, but features triggered by 'casting a spell' may trigger only once from the Fusion, chosen by you. Fusion itself cannot be copied, Shared or used inside Dual Cast.

<details><summary>Preserved source wording — book line5282</summary>

Arcane Fusion: Combine two spells into a single, more powerful effect.

</details>

#### Reality Edit

**Level 20 · automatic · wizard.hero.elementalist.reality-edit**

| Activation | Cost | Range / targets | Duration | Frequency |
|---|---|---|---|---|
| Action | 10 RP | 20-foot-radius fixed zone centered within 60 feet | Concentration, maximum 3 rounds | 1/week; automatic Elementalist Final Theorem |

Reality Edit. Tags: hero, elementalist, final-theorem, reality, concentration. Choose ONE bounded law for the zone when cast. GRAVITY: the zone is difficult terrain; creatures entering or starting there make Strength saves, falling Prone on failure. ELEMENTAL LAW: choose acid, cold, fire, lightning or thunder; damaging spells cast entirely inside the zone may convert their damage to that type, chosen by their caster. GEOMETRY: ranged attacks and spells crossing the zone's center suffer half cover against their targets. Each hostile creature affected by a control consequence receives the listed save on every relevant turn. Reality Edit cannot create treasure, permanently transform terrain, erase creatures, rewrite history, alter beliefs or grant spells above rank eligibility.

<details><summary>Preserved source wording — book line5285</summary>

Reality Edit: Temporarily change one aspect of reality in a small area (1/week).

</details>

### Necromancer

#### Flesh Ascendant

**Level 10 · selection · wizard.hero.necromancer.flesh-ascendant**

| Activation | Cost | Range / targets | Duration | Frequency |
|---|---|---|---|---|
| Passive | 0 | Undead creatures you control | Permanent while active | Always |

Flesh Ascendant. Tags: hero, necromancer, passive, undead. Each undead creature you control gains +2 maximum HP per Wizard class level. While at least two of your undead creatures are active, each also gains +1 AC and +1 on saving throws. These bonuses apply after the common standard-minion and elite-pet statistics and do not increase companion caps or command frequency.

<details><summary>Preserved source wording — book line5298</summary>

Flesh Ascendant: All undead gain +2 HP per Wizard level, if 2+ undead are active, gain +1 AC and Save

</details>

#### Mind Matrix

**Level 10 · selection · wizard.hero.necromancer.mind-matrix**

| Activation | Cost | Range / targets | Duration | Frequency |
|---|---|---|---|---|
| Passive | 0 | Your Enchantment Wizard spells | Permanent | Always |

Mind Matrix. Tags: hero, necromancer, passive, enchantment. Increase your Wizard save DC by 2 for Enchantment spells. This stacks with your level-1 school bonus only if Enchantment is your Arcane School. It does not increase DCs for non-spell class techniques merely because they influence a creature's mind.

<details><summary>Preserved source wording — book line5299</summary>

Mind Matrix: Your enchantment spells are harder to resist (+2 to save DC).

</details>

#### Will Domination

**Level 12 · selection · wizard.hero.necromancer.will-domination**

| Activation | Cost | Range / targets | Duration | Frequency |
|---|---|---|---|---|
| Triggered | 0 | One creature that fails a save against your Wizard spell by 5 or more | Until end of target's next turn | Once per target per encounter |

Will Domination. Tags: hero, necromancer, passive, control. When a creature's total on a saving throw against your Wizard spell is at least 5 below the DC, it is Stunned until the end of its next turn. After this successfully Stuns that creature once in the encounter, later qualifying failures instead remove its Reaction until the end of its next turn. This uses the shared source-character/target hard-denial mark across all your features, not a separate allowance per spell.

<details><summary>Preserved source wording — book line5300</summary>

Will Domination: Creatures that fail saves against your spells by 5+ are stunned for 1 round.

</details>

#### Arcane Leech

**Level 14 · selection · wizard.hero.necromancer.arcane-leech**

| Activation | Cost | Range / targets | Duration | Frequency |
|---|---|---|---|---|
| Triggered | 0 | Self | Until temporary HP are lost | At most once per turn |

Arcane Leech. Tags: hero, necromancer, passive. When at least one hostile creature fails a saving throw against one of your Wizard spells, gain temporary HP equal to S+M. Multiple failed targets from the same spell do not multiply the amount. This does not drain actual HP, generate RP or trigger from your companions' abilities.

<details><summary>Preserved source wording — book line5301</summary>

Arcane Leech: Gain temporary hit points when a creature fails a save against your spells.

</details>

#### Binding Sigil

**Level 16 · selection · wizard.hero.necromancer.binding-sigil**

| Activation | Cost | Range / targets | Duration | Frequency |
|---|---|---|---|---|
| Triggered | 0 | One creature directly affected by your Wizard spell | Until end of your next regular turn | At most one marked creature at a time |

Binding Sigil. Tags: hero, necromancer, passive, mark. After one creature takes damage from or fails a save against your Wizard spell, you may mark it. Until the end of your next regular turn you have advantage on Wizard spell attacks against that creature. Marking another creature ends the previous mark. Echoes, companions and environmental damage cannot apply it.

<details><summary>Preserved source wording — book line5302</summary>

Binding Sigil: Mark a creature, giving you advantage on spell attacks against it.

</details>

#### Corpse Harvest

**Level 10 · selection · wizard.hero.necromancer.corpse-harvest**

| Activation | Cost | Range / targets | Duration | Frequency |
|---|---|---|---|---|
| Action | 4 RP | One eligible humanoid corpse within 30 feet | Until destroyed, dismissed or your next long rest | Recharge 2 rounds; standard-minion cap 3 |

Corpse Harvest. Tags: hero, necromancer, wizard-spell, undead, summon. Raise the corpse as a Skeleton or Zombie using the common standard-undead statistics; a goblinoid corpse may instead become a Goblin Thrall. The corpse is consumed into that minion state. The creature obeys the shared Bonus Action Companion Command rule. Creating a fourth standard minion requires dismissing one existing standard minion first.

Class-spell rank: **5** for Dissonance, countering and rank restrictions; pay printed RP only.

<details><summary>Preserved source wording — book line5305</summary>

Corpse Harvest: Raise skeletons/goblins/zombies from slain humanoids

</details>

#### Ghoul Lash

**Level 10 · selection · wizard.hero.necromancer.ghoul-lash**

| Activation | Cost | Range / targets | Duration | Frequency |
|---|---|---|---|---|
| Bonus Action | 2 RP | One of your standard undead minions with another allied undead within 5 feet | For this command | At most once per round |

Ghoul Lash. Tags: hero, necromancer, undead, command. Use your shared Companion Command on the chosen standard minion. If another undead you control is within 5 feet of it when commanded, it makes TWO copies of its normal damaging attack instead of one. Both attacks are part of the same single shared damaging command and cannot create additional commands, Actions or auto-raise events beyond the common once-per-round Auto-Raise limit.

<details><summary>Preserved source wording — book line5306</summary>

Ghoul Lash: Minions within 1 tile of each other gain bonus attacks

</details>

#### Infernal Pact (Quest-based unlock)

**Level 12 · selection · wizard.hero.necromancer.infernal-pact-quest-based-unlock**

| Activation | Cost | Range / targets | Duration | Frequency |
|---|---|---|---|---|
| Bonus Action | 3 RP | One creature within 60 feet | Maximum 3 rounds | 1/long rest; quest-gated |

Infernal Pact — Gravebrand. Tags: hero, necromancer, infernal, necrotic, dark-content. This card can be selected only after completing the campaign's Infernal Pact quest and its dark-trauma check-in. Mark one creature. At the start of each of its turns it makes a Constitution save; on failure it takes 1d6 necrotic damage and you regain HP equal to the actual damage dealt, maximum S+M; success ends Gravebrand. Gravebrand ignores necrotic resistance but not immunity. While you possess this Pact, Corpse Harvest and Auto-Raise may also treat Fiend corpses as eligible; other creature types remain ineligible.

<details><summary>Preserved source wording — book line5307</summary>

Infernal Pact (Quest-based unlock): Grants Gravebrand: 1d6 necrotic per round, heals caster, overrides corpse resistance

</details>

#### Mental Binding

**Level 14 · selection · wizard.hero.necromancer.mental-binding**

| Activation | Cost | Range / targets | Duration | Frequency |
|---|---|---|---|---|
| Action | 4 RP | One creature within 60 feet | Concentration, maximum 3 rounds | Recharge 3 rounds |

Mental Binding. Tags: hero, necromancer, wizard-spell, enchantment, control, concentration. Target WIS save; failure becomes Charmed for at most 3 rounds, repeat save at end each turn and on damage. On its first affected turn only, choose Approach, Retreat, Drop, Kneel or Strike; target uses up to half Speed, one object interaction or one ordinary weapon attack as appropriate, consuming its normal Action only if an attack is made. This command replaces at most one normal Action/turn and uses the shared hard-denial mark. Later turns retain normal actions, but while Charmed it cannot willingly attack you. No self-harm, compelled beliefs, resource expenditure or permanent allegiance. The player chooses the safest legal interpretation for a PC.

Class-spell rank: **7** for Dissonance, countering and rank restrictions; pay printed RP only.

<details><summary>Preserved source wording — book line5308</summary>

Mental Binding: Force a creature to obey a simple command for a short duration.

</details>

#### Arcane Domination

**Level 16 · selection · wizard.hero.necromancer.arcane-domination**

| Activation | Cost | Range / targets | Duration | Frequency |
|---|---|---|---|---|
| Action | 7 RP | One creature within 60 feet | Concentration, up to 1 minute | 1/long rest |

Arcane Domination. Tags: hero, necromancer, wizard-spell, enchantment, control, concentration. Target WIS save; failure Charmed for 1 minute, repeat at end each turn and on damage. Once during this effect, spend Bonus Action to command its NEXT normal turn: Move up to Speed and either Dodge, Disengage or make one ordinary weapon attack, replacing its normal Action and using the shared hard-denial mark. It gains no extra turn or attack; later turns retain normal actions while Charmed, with no Reactions until effect ends. A PC chooses its legal attack target and reasonable route. No self-harm, forced spell/resource expenditure, belief change or permanent control.

Class-spell rank: **8** for Dissonance, countering and rank restrictions; pay printed RP only.

<details><summary>Preserved source wording — book line5309</summary>

Arcane Domination: Take control of a creature's actions for 1 minute.

</details>

#### Mind Prison

**Level 20 · automatic · wizard.hero.necromancer.mind-prison**

| Activation | Cost | Range / targets | Duration | Frequency |
|---|---|---|---|---|
| Action | 10 RP | One creature within 60 feet | Concentration, maximum 3 rounds | 1/week; automatic Necromancer Final Theorem |

Mind Prison. Tags: hero, necromancer, final-theorem, enchantment, illusion, control, concentration. Target WIS save; failure Incapacitated until end of its NEXT normal turn, using the shared hard-denial mark. During that one turn you may spend a Bonus Action on your turn to specify one replacement behavior: target moves up to half Speed and either Dodges or makes one ordinary weapon attack instead of its lost Action; a PC chooses its own attack target and route. After that first affected turn, no further Action denial or compelled attack occurs: while concentration continues, target Speed is halved and it cannot take Reactions. It repeats WIS save at end each turn and on damage, ending on success. Maximum 3 rounds. No forced self-harm, spell expenditure, transfer of equipment, confession, belief change or permanent allegiance.

<details><summary>Preserved source wording — book line5316</summary>

Mind Prison: Trap a creature's mind in an illusory reality while controlling its body (1/week).

</details>

#### Overchannel

**Level 13 · automatic · wizard.supplement.overchannel**

| Activation | Cost | Range / targets | Duration | Frequency |
|---|---|---|---|---|
| Triggered | Pay the Core V 2 RP cost for one rank above the spell's normal cast rank | One prepared spell you are beginning to cast | For that cast | 1/long rest |

Source progression line 5190. Cast one prepared spell as though it were one rank higher than the highest rank at which you could normally cast that SAME spell, provided the spell has an explicit higher-rank scaling rule. Overchannel does not teach or prepare a higher-rank spell, cannot exceed effective rank 9 and cannot be combined with another generic Overcast rule during this pilot. All normal Dissonance/Refrain rules still apply.

Prerequisite: See class engine and progression.

<details><summary>Preserved source wording — book line5190</summary>

| 13 | Overchannel (cast a spell 1 tier higher once/day) |

</details>

#### Arcane Feedback

**Level 15 · automatic · wizard.supplement.arcane-feedback**

| Activation | Cost | Range / targets | Duration | Frequency |
|---|---|---|---|---|
| Triggered | 0 | Self | Instantaneous | At most once per round |

Source progression line 5191, converted from historical slot wording to RP. After your Counterspell successfully negates a spell, restore 1 RP, never above your normal maximum. A counter produced by a companion, reflected spell or copied Counterspell does not trigger this feature.

Prerequisite: See class engine and progression.

<details><summary>Preserved source wording — book line5191</summary>

| 15 | Arcane Feedback (after successfully countering a spell, recover 1 RP once per round) |

</details>

#### Tethered Cast

**Level 17 · automatic · wizard.supplement.tethered-cast**

| Activation | Cost | Range / targets | Duration | Frequency |
|---|---|---|---|---|
| Bonus Action | 2 RP | One concentration Wizard spell you cast this turn that targets only yourself or one willing ally | Maximum 3 rounds | At most once per round; only one Tethered Cast active at a time |

Source progression line 5192. After casting the qualifying spell, tether it. The tethered spell no longer occupies your one normal concentration slot for up to 3 rounds. When damage would require a concentration save for the tethered spell, make the save normally; failure ends only the tether. Starting another Tethered Cast ends the existing tether first. A Tethered Cast cannot itself tether Spell Tether's second spell or permit more than two simultaneously sustained Wizard effects.

Prerequisite: See class engine and progression.

<details><summary>Preserved source wording — book line5192</summary>

| 17 | Tethered Cast (bonus action spell link 1/round) |

</details>

#### Grand Reservoir

**Level 20 · automatic · wizard.supplement.grand-reservoir**

| Activation | Cost | Range / targets | Duration | Frequency |
|---|---|---|---|---|
| As the chosen spell | 0 RP for the chosen cast | One legal Wizard spell recorded in your spellbook | As that spell | 1/long rest |

Source progression line 5193. Cast one spell currently recorded in your spellbook from any school at a rank you are legally eligible to cast, maximum rank 9, without paying its normal RP cost. It need not be currently prepared. Grand Reservoir does not grant universal access to spells absent from the spellbook, does not bypass components or other prerequisites and cannot be combined with generic Overcast, Arcane Fusion, Dual Cast or another RP-refund feature. Printed strain surcharges and consumed materials still apply; only the base RP cost is waived.

Prerequisite: See class engine and progression.

<details><summary>Preserved source wording — book line5193</summary>

| 20 | Grand Reservoir (1/day spell from any school, any tier) |

</details>

## Source appendix and open balance questions

The complete original Wizard book section, including lore, examples and alternate progression, is preserved in the [source evidence JSON](../../../data/playtest/class_sources/wizard.json). The supplemental source tables are [preserved separately](../../../data/playtest/class_sources/supplements.json). Do not stack older level-table features on top of this draft.

- Does preparing Wizard level + Intelligence modifier matrices, while also learning the historically broad number of spellbook entries, create meaningful daily planning without making spellbook management too burdensome at high level?
- Do Matrix Mastery, Dual Cast, Spell Efficiency, Arcane Fusion and Tethered Cast preserve the Wizard's methodical identity without producing excessive RP efficiency, concentration bypass or cast-proc multiplication?
- Are Spellbinder suppression, Elementalist combination effects and Necromancer minion control comparably valuable when tested across several encounters with the same Core V2 RP and rest schedule?

A complete card specification is not balance approval. Record actual play results, particularly resource exhaustion, condition locks, survival and how often choices become unusable.
