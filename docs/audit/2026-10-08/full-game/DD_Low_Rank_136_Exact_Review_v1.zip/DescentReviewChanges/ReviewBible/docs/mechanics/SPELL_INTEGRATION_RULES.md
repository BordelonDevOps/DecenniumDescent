# Spell integration rules — provisional v0.1

Use this document with the [shared class rules](CLASS_PLAYTEST_RULES.md), the class's own engine and the [spell packet](SPELL_PLAYTEST_STARTER.md). This is a staged development layer, not an approved-book replacement or a live companion update.

## What owns each decision

| Decision | Source used for this packet |
|---|---|
| Spell identity, every school placement and per-class rank/access | Preserved `src/data/spells.js`; do not collapse different class ranks into one global rank. |
| Common RP prices and additional spell evidence | Core Systems Known Descent V2. Its spell blocks are retained with the catalog summaries. |
| Class identity, engine, spellbook/preparation and cadence exceptions | The current class playtest packet. |
| Generic Dissonance/Refrain, action limits and core conditions | Shared class playtest rules; source Core conditions remain unchanged. |
| Missing targeting, exact endpoints, concentration ambiguities and exploit limits | Explicitly provisional decisions on each spell card. |

The approved Core V2 source has 936 spell blocks. The companion catalog has 848 unique IDs with 936 school placements, but leaves four metadata fields unspecified. These are different views of the source, not evidence that all casting details were absent. Core's generic “Automatic or opposed as described” does not supply a concrete save or targeting rule.

Eleven possible renamed entries remain comparative evidence in the register. Harmonic Bulwark's catalog summary says 5 temporary HP per RP while the possible historical Mana Shield entry says 2; its [individual transformation and buffer review](TRANSFORMATION_SPELL_PLAYTEST.md) now supplies the operational decision. Both source variants remain preserved. Other unresolved aliases stay pending their own review; matching names never silently merge effects.

Resonance Kindle now has [exact manuscript approval](../../../../docs/audit/2026-10-08/full-game/GPT_CONJURATION_CANTRIP_EXACT_REVIEW.md): Action/Self/V/S, recover 1 RP only when this spell reaches resolution. Its one character-wide use is spent at legal cast start and refreshes only on a beneficial completed long rest. The comparative Mana Kindle block remains separately preserved; its broader wording does not trigger recovery from other cantrips and its historical range grants no remote recipient. The [Conjuration cantrip status](CONJURATION_CANTRIP_REVIEW_STATUS.json) records this bounded decision and the other eleven approved cards.

## Select a spell

1. Choose the class through which you are learning/casting it. Check that class's school access and minimum **class** level on the card.
2. Use that class's spell rank and Core V2 cost. A different eligible class may receive the same spell at a different rank and level.
3. Record it in your allowed known, prepared or spellbook choices. An eligible catalog entry is not an automatic grant. Wizard and Druid keep their explicit preparation systems; fallback counts apply only where the class has no more specific rule.
4. Select only a spell marked `operational-playtest-draft` in this packet, or an operational spell expressly supplied by a class card. Other records stay visible in the unfinished queue.
5. A class card and an ordinary spell with the same name remain separate records with separate acquisition and costs. Knowing one does not grant the other. Oath spells, Matrix techniques and similar class spells use their own card.

Oracle uses RC and its Mystery/Curse system. Soldier and Warrior have no general Weave access. Dragoon first gains ordinary magic at class 3; Paladin at class 2. Sufficient RP, total character level, a class feature with the same name, or a borrowed spellbook cannot bypass a gate.

## Resolve a cast at the table

1. Verify the available Action/Bonus Action/Reaction, its exact trigger, components, targets, range and line of effect. No legal target means no activation or payment. A target in an area still needs the card's eligibility. Total cover blocks direct targeting unless expressly overridden.
2. Choose a spell from your actual repertoire. Determine its class-specific rank and RP cost: rank 0–9 costs **0/2/3/5/7/10/13/17/21/26**. Add explicitly printed extra costs; Resonance Shield adds 1 RP even when the caster receives it as a cantrip. Generic Overcast is excluded.
3. Read Dissonance **before** casting. Limit = max(4, 2 + PB + max(0, casting modifier)). At limit/limit+3/limit+6, ranked spells cost +1/+2/+3 RP. At limit+6 ordinary rank-1+ casting is blocked. Cantrips have no strain surcharge but still build Refrain. An expressly granted traumatic-casting exception pays the cost and its printed trauma; it grants neither rank nor repertoire access.
4. Commit the legal cast's RP, materials and other printed costs before any attack/save or interruption. Perform its components and establish concentration if required, ending incompatible prior concentration. An ordinary missed, saved-against or countered legal cast refunds nothing and never restores displaced concentration.
5. At this cast's beginning, apply ordinary Dissonance and Refrain once: 0 base for rank 0, 1 for ranks 1–5, 2 for ranks 6–9; consecutive same-named casts add Refrain +1/+2/+3, capped at +3. First cast or a different name adds +0. Apply the class's exact protected reduction, routing or vent and any hook whose printed trigger is beginning/casting. Weapon or idle turns do not reset the previous name/Refrain unless the class expressly says so. This chronological commitment occurs before the Counterspell window; a later Reaction cast updates its own history, and resuming the earlier cast does not update that history again.
6. Open legal cast-interruption Reactions, resolving nested counters last-in, first-out. A surviving cast then resolves its effect: spell attacks are d20 + PB + the actual casting ability modifier; save DC is 8 + PB + that modifier. Use the exact card's hit/failure/success results and ordinary damage/conditions. Outcome-dependent class hooks occur only at their printed timing and with the required actual result. No automatic cantrip scaling applies. A negated spell grants no success/hit/damage effect merely because its casting cost was paid.
7. Record concentration, exact expiration, per-rest use, summon and companion command obligations. A second spell cannot supply an ungranted Action, duplicate concentration or resource reset. A readied spell commits this casting sequence at preparation; release has no second cast, cost, cadence update or Counterspell window.

Countering requires an actual operational spell or class card, its repertoire/access and a legal remaining Reaction. The ordinary Counterspell is now reviewed; it is separate from the Mage and Wizard class cards. Dispel Minor, Dispel Resonance, Dispel Magic (Lesser) and Dispel Magic use their exact individual scopes. Rank-limited dispels inspect the original generating cast's spell rank, not RP cost or the dispeller's rank. Higher and unassigned source variants retain their own unfinished status.

## Counterspell checks and interruption

The [exact notebook review](../../../../docs/audit/2026-10-08/full-game/GPT_ABJURATION_RANK2_3_EXACT_REVIEW.md) confirms this authored timing interface and corrects the earlier binary-check proposal using the existing [Core roll rules](CORE_RESOLUTION_PLAYTEST.md). This is a tabletop procedure; the pricing helper does not implement nested reactions.

Ordinary Counterspell uses its casting class's actual spellcasting ability + PB against **DC 10 + twice the triggering spell's actual rank**. The class Wizard/Mage cards retain their printed Intelligence + PB check and their own acquisition, cost, rank and recharge. Apply the existing fixed-DC task degrees and natural shifts, then collapse Critical Success/Success to success and Failure/Critical Failure to failure. No extra critical counter effect is invented. It is neither a spell attack nor a saving throw.

| Natural d20 + modifier | DC | Existing task result | Counter result |
|---|---:|---|---|
| 20 + 0 | 22 | Failure improves to Success | Success |
| 1 + 9 | 10 | Success worsens to Failure | Failure |
| 1 + 20 | 10 | Critical Success worsens to Success | Success |

The target must be an actual pending spell with a recorded rank. The Director may use hidden source data without revealing the spell's identity/rank; attempting grants no free identification. An unassigned rank is not automatically zero. A source-defined technique is not counterable merely because it spends RP or resembles magic.

A creature normally attempts Counterspell once against a particular pending cast, across its ordinary and same-named class sources. Another Reaction alone does not supply another attempt. An exact source expressly granting an additional attempt against that same cast overrides the default. After failure, another eligible creature may react; after negation there is no further trigger. Counterspell is itself a spell and can be countered. Resolve nested counters last-in, first-out and resume surviving parents without recasting, paying again, or replaying their earlier Refrain/Dissonance. Negation refunds no costs and restores no prior concentration. Countering one spell is not whole-Action/turn hard denial and does not spend that combined ledger.


## Reviewed placement-specific cards

Detect Poison has Divination rank-0 and Abjuration rank-1 modes. The casting class's preserved school/rank selects the mode; the rank-1 mode also requires F. Alignment Shield has Abjuration rank-1/30-foot and Conjuration rank-3/60-foot modes; its 60-foot header represents only the maximum range across modes. Read each full target and resolution field. These are manuscript rules; the pricing helper does not execute targeting or components.

Repulsion Field's operational entry is only the rank-1 object pulse. Its distinct rank-6 creature effect remains preserved but unavailable. Warding Bond uses its preserved rank-1 class access; the rank-2 duplicate grants no extra effect. Higher character level or extra RP never grants a blocked placement or changes modes. All source variants remain in the catalog's source evidence.

Alignment Sanctuary has Abjuration rank-3 admission saves and the actually granted Shaman Conjuration rank-6 matching-alignment mode. The unassigned rank-6 Abjuration benefits remain unavailable. Identity counts do not close every preserved placement; consult the [variant register](SPELL_VARIANT_REVIEW_STATUS.json).

Ordinary Warding Bond follows the reviewed damage-sharing stage/root rules and its exact card. It does not use or enlarge the Paladin class redirection round ledger or grant named Paladin healing/resource riders. Its authored promotion does not establish an implementation of its effect in the damage-sharing reference helper.

## Reviewed finite conjurations

The [rank-1 Conjuration review](../../../../docs/audit/2026-10-08/full-game/GPT_CONJURATION_RANK1_EXACT_REVIEW.md) selects **2 RP** for Summon Mod Rod under the manifest's Core V2 spellcasting precedence; the conflicting V6/catalog 1-RP wording remains preserved. Its charge and separate character-wide caster supply/recipient receipt uses commit at activation start, including prevented or zero recovery, and refresh only on each character's beneficial completed long rest. Replacing rods never resets those records.

Read the [exact cards](SPELL_PLAYTEST_STARTER.md) for each created object's weight, native HP, duration, custody, load and ending. Summon Minor Weapon is wielded through ordinary weapon actions; it grants no attack on casting. Conjure Rope and Resonance Bridge require real support and apply ordinary Falling on failure. Alignment Essence preserves its empty result-vial for one minute after full consumption. Faction Messenger conserves supplied mundane paper and cannot resolve an ambiguous recipient description magically. Heat Metal keeps its physical-item round record and six-second next-pulse deadline through recasting, handoff and initiative changes. These are authored procedures; [review status](CONJURATION_RANK1_REVIEW_STATUS.json) does not certify runtime or balance.

## Components, summons and ongoing effects

**V** requires audible speech; **S** requires a free hand or a class feature expressly permitting the gesture; **F** is the class's ordinary casting focus. Core's M/F shorthand is interpreted here as the existing focus alternative. No unspecified costly or consumed material is added. These hand/focus conventions are provisional and may require equipment integration. A spell with V is blocked by an effect explicitly preventing verbal casting.

Summon stat blocks use their printed AC/HP/attack die. Where absent, saves use the owner's PB, other ability checks use +0, walking Speed is 30 feet, and there are no unstated creature immunities or extraordinary senses. Unless a card explicitly gives another bounded range, a commanded companion must be within 60 feet and able to perceive its owner. All one owner's companions share one Bonus Action command and **one damaging action total per round**. Without a command they move and Dodge. A replacement requires the full casting cost. No summon grants loot, a reusable corpse or resource-generating death trigger.

The [rank-2 Conjuration review](../../../../docs/audit/2026-10-08/full-game/GPT_CONJURATION_RANK2_EXACT_REVIEW.md) approves this specific companion overlay: **when an exact companion source prints multiple attacks as one damaging action, those attacks are components of one commanded offensive action and consume the owner's single offensive-companion allowance unless that source expressly grants otherwise.** Summon Air Pet explicitly makes its two source attacks within that one action; no second command/action or remaining offense for another companion is created. Its fixed AC15/HP20/two 1d6 attacks do not inherit generic companion scaling.

Planar Ally (Minor) uses a finite NEW summon-only profile for the source's intended CR-1 role. The bounded public bestiary scan did not establish an eligible published exact-CR1 extraplanar creature; this card does not certify its CR or rewrite a bestiary entry. Summon Weaponry Satchel has finite conjured contents tied to one duration, with a narrow exception only for an already resolving immediate use. Alignment Weapon's suppression default applies only to that printed card.

Resonance Well rolls one 1d4 total reserve. Its separately named creation and receipt uses commit before prevention and reset only through each character's beneficial long rest. These limits neither share nor reset Kindle or Mod Rod records. Read the exact cards and [rank-2 status](CONJURATION_RANK2_REVIEW_STATUS.json); pricing/schema checks do not execute these effects or certify balance.

The [rank-3 Conjuration review](../../../../docs/audit/2026-10-08/full-game/GPT_CONJURATION_RANK3_EXACT_REVIEW.md) adds seven bounded cards. Earth Pet's knockdown is Prone, not positional movement; generic push/pull immunity does not automatically prevent it. Burst of Flamewind affects every creature the caster ordinarily classifies as an enemy at a known location in its cone, with automatic source damage and a save controlling only its push.

Elemental Displacement selects a nearby willing recipient and a perceived destination; its teleport path is not constrained by intervening terrain. Spectral Steed actually crosses planes to a known site, once per steed attempt. Its 350-pound **and** 12-Load limits count the rider's body and all gear, including melded equipment. The reviewed correction from the conference's proposed6Load avoids excluding all gear from a Medium rider; ordinary Burdened applies at6Load. Read the exact mount/command/arrival procedure; it does not close general mounted combat.

Resonance Conduit transfers already-existing RP between two separate pools, with committed deductions, gated credit, and no resource creation or daily-ledger reset. Renewed consent cannot revive an ended application, but a new legal paid cast may create a new one. Faction Portal provides actual one-way travel to a known HQ on the same or another plane. Its positive-standing predicate uses the current canonical reputation record without migrating its scale. Travel may bypass a geographic route; elapsed clocks, cargo custody, contamination, claims, arrival law and settlement remain actual procedures. These cards do not declare automatic Extraction success or invent a blanket prohibition on planar escape. [Review status](CONJURATION_RANK3_REVIEW_STATUS.json) preserves the manuscript/runtime/balance distinction.

 Noncombat helpers cannot attack or operate combat items.

A cantrip that stabilizes restores no HP and removes no Wound. Mending cannot replace finite machine repair or refresh ammunition, charges, duration or class resources. Created tools, servants and water obey the explicit card limits; a spell does not silently pay wages, produce saleable materials or erase abstract expedition Supply.

All hard whole-Action/turn denial uses one combined **source-character/target/encounter** record across that character's spells, class features and companions. Once used, later hard-denial riders from that source fail; damage and soft riders resolve as printed. Boss immunities remain effective. Same-stat flat bonuses use the strongest; same-name dice bonuses do not stack. Apply one allowed bonus-die spell per roll in this packet unless a reviewed feature explicitly permits more. Temporary HP never add together. Copies never generate copies, class procs or resource loops.

## Falling bridge — new provisional procedure

This is a newly authored table procedure agreed with the GPT notebook, **not recovered V6/Core V2 canon**. Focused searches of the current rulebook extract, Core V2 and mechanics/manual text found spell summaries but no operational falling clock or impact formula. Before promotion to canon, inspect the approved V6 environment/travel/hazard sections and archived environment tables. Preserve any older rule found and compare it explicitly.

When a creature loses support with no movement mode or effect keeping it aloft, it enters **Falling** immediately. Falling means unsupported; it grants no hovering, airborne walking or lateral movement. Track total distance descended during this fall and cumulative distance during its current uncontrolled portion, both initially zero.

**Timing:** If a fall begins during a regular initiative turn, set a fixed Fall Marker at the **end of that initiative slot in the following round**. Resolve the first Falling Step there, then one at the same marker each round. Reactions and extra turns use the enclosing regular initiative slot; an event between slots uses the most recently completed slot. Extra turns, extra Actions and initiative changes neither move nor multiply the marker. This gives every participant one normal turn opportunity before the first descent; inability to act still matters and no free rescue action is granted. A caster still needs legal targets within range when spending their Action.

Outside initiative, when timing matters, establish an order before descent and use a virtual slot immediately before its first regular slot as the initiating slot. The first step occurs when that virtual slot next recurs, after everyone has had one normal turn opportunity. When no rescue or other timing decision is possible, the Director can resolve the same descent and impact calculation directly. This is an explicit timing abstraction, not a model of physical acceleration.

If a fall begins after initiative has been established but before any regular initiative slot has yet completed, treat the virtual pre-round slot as the most recently completed slot for Fall Marker purposes.

**Ordinary descent:** At each step descend up to **300 feet**, stopping on a supporting surface. Add the distance to both trackers. On landing while uncontrolled, take **min(10, floor(uncontrolled distance / 20))d6 bludgeoning damage**. The uncontrolled distance includes earlier steps; never use only the final step's remainder.

**Feather Fall:** The spell retains its **Action** casting time and reduces descent to at most **60 feet per step**. When it takes effect, set uncontrolled distance to zero: the magic dissipates prior uncontrolled momentum in this abstraction. Keep total fall distance. If landing while it remains active, damage is **min(3, floor(total fall distance / 20))d6 bludgeoning**. This explicitly limits impact exposure without guaranteeing a harmless landing. When the spell ends aloft, reset uncontrolled distance to zero, then accumulate ordinary descent from that point at the existing marker; expiry grants no immediate extra step. Its one-minute maximum ends immediately before the caster's regular turn ten rounds after casting. If expiry and a step coincide, resolve expiry first. Earlier landing or cessation of Falling ends the spell on that target as printed.

Apply damage defenses only when their actual wording covers that damage. After damage, Falling ends; a creature suffering any positive falling damage lands **Prone** unless an explicit feature prevents it. Less than 20 relevant feet produces zero damage. Forced movement that removes support starts a fall but adds no separate fall damage. Regaining genuine support, secure support from a hold, or flight ends Falling without resolving an uncompleted impact; teleporting safely onto support likewise ends it. A later loss of support begins a new fall with new trackers and marker. Completed impact and damage cannot be undone by later casting.

| Scenario | Steps to land | Impact |
|---|---:|---:|
| Ordinary 10 feet | 1 | 0 |
| Ordinary 20 feet | 1 | 1d6 |
| Ordinary 300 feet | 1 | 10d6 |
| Ordinary 310 feet | 2 | 10d6 |
| Ordinary 610 feet | 3 | 10d6 |
| Feather Fall active through a 310-foot fall | 6 | 3d6 |
| 120 feet slowed, spell ends aloft, then 190 feet uncontrolled | 3 | 9d6 |

The 300-foot ordinary step, impact formulas, momentum reset, marker and duration conventions are provisional inventions. The source supplies Feather Fall's Action, five targets and 60-foot slowed descent. Wider hazards, equipment catches, flight loss and environmental damage still need the combat/campaign pass.

## Recovery bridge and unresolved integration

The class suite's **Retune** formula is the active RP rule for this combined test: recover max(0, floor(maxRP/4 + 0.5) + actual casting modifier), capped at maximum, and clear Dissonance after a completed one-hour short rest. Retain the expedition rule of at most **two beneficial short rests between long rests**, and one beneficial eight-hour long rest per **24 hours**. A long rest restores RP and clears Dissonance; expedition time, supply, pressure, Wounds and rest legality still apply. Count time once, not once in each tracker. Oracle and other non-RP engines use their class-specific recovery, not this formula.

This bridge explicitly chooses the class Retune formula over the gameplay draft's quarter-pool-only RP paragraph. Both originals remain preserved. A completed long rest also resets the remembered spell name and Refrain counter. A short rest clears Dissonance through Retune but does not reset Refrain unless a class feature expressly says so. This reset convention is an explicit provisional decision agreed in the notebook review. Broader recovery decisions for all class resources still require the character/campaign integration pass.

## Developer verification

`tools/spell_playtest_rules.py` checks operational status, class access, level gates, known/prepared membership and the **common pricing step**. Its Dissonance result is deliberately labelled *before class interface*. The caller must apply the actual protected class cadence or vent and verify actions, components, target legality, concentration and effect resolution. This helper is not an automatic implementation of every spell or class.

Run `python tools/build_spell_playtests.py`, then `python tools/validate_spell_playtests.py`. Source accounting, metadata coverage, access boundaries and cost/reference scenarios are independently reported. A passing result does not certify the remaining catalog, all cross-class combinations, human balance or live-app readiness.

`tools/fall_playtest_rules.py` separately exercises the new falling marker and distance/impact calculation. Callers still own actual spell availability/expiry, support, actions, damage rolls, defenses and Prone. Its regression cases specifically prevent premature or duplicate steps, harmless remainder exploits and retroactive changes to resolved landings.


## Reviewed Divination cantrip information boundaries

The [eleven-card review](../../../../docs/audit/2026-10-08/full-game/GPT_DIVINATION_CANTRIP_EXACT_REVIEW.md) and [final source clarification](../../../../docs/audit/2026-10-08/full-game/GPT_DIVINATION_CANTRIP_FINAL_CLARIFICATION.md) make each spell's information output explicit. Actual hidden facts may be revealed when a spell authorizes them; undefined records must not be invented. Sense Alignment distinguishes recorded axes, Indeterminate and genuinely unaligned objects. Detect Faction requires an actual affiliation/nonaffiliation record; absence of a field is not a negative finding. Resonance Sight reads current RP only, using ordinary visibility and actual pools; unreadability is not proof of no pool.

Protection from Scrying prevents new information about its subject within its actual generating-school scope, including new Far Echo retrieval. It does not erase events, ordinary recordings or known facts, nor grant blanket immunity to Foresight Flicker's roll modifier or Glimpse Future's initiative benefit. Soul Mark's record can remain while its directional information is blocked. The final clarification retains the source's creature eligibility: active creature-classified Undead/Construct targets are not excluded merely by type. Death/destruction/ended summoned existence ends the mark; ordinary shapechange or travel alone does not.

Omen Whisper limits materially equivalent inquiries across casters, while genuinely different material questions can receive another clue. Far Echo uses speech produced in its fixed capture sphere and actually audible at the center in the six seconds before casting. Read Surface Thoughts yields one actual current conscious thought after its save, not memories or forced truth. Detect Weather supplies an accurate current-trajectory forecast; a later actual new cause may alter it, with that cause recorded in the game. These are authored procedures, not a complete information/weather engine or balance certification. See [review status](DIVINATION_CANTRIP_REVIEW_STATUS.json).


## Mark Omen and Fate Coin: reviewed spell-specific rerolls

Mark Omen and Fate Coin share one guard: an original roll event and its entire replacement lineage may receive at most one reroll from either of these two spells, across all casters, coins, marks and recasts. Reserve this allowance at the first legal activation's commitment, not after the replacement die resolves. For a multi-die roll, the whole set/pool is one original roll event; the resulting attack's separate later damage roll is a different event. A shared area-damage roll remains one event even when applied to several creatures. Other exact class reroll features keep their own permissions and timing, but do not erase this guard or create a fresh lineage for these two spells. If competing declarations are simultaneous, use current initiative order; outside initiative use a fixed neutral table order chosen before the roll. Only the first legal commitment spends a mark/coin; a later declaration barred by this guard spends nothing. No new Action, roll event, cast, payment or duplicated outcome hook is created by replacing dice.

The [rank-1 Divination exact review](../../../../docs/audit/2026-10-08/full-game/GPT_DIVINATION_RANK1_EXACT_REVIEW.md) requires Fate Coin to wait until the **complete original roll event** is rolled and its faces are available under normal table information rules. It then replaces only one chosen die before consequences apply. Mark Omen replaces the caster’s complete attack d20 procedure before hit/miss resolution. Neither creates another attack/cast, rerolls an established resource reserve, reverses applied consequences or duplicates costs/hooks. A Well’s initial reserve die may be changed before the reserve is established. These two spell grants do not rewrite the Oracle, Mirrorsage or other class reroll contracts.

The same review preserves actual distant hearing, concealed-entrance revelation, creature sight through non-solid obscurity, willing memory-sharing, and actual faction/alignment/Corruption information. Warning Ward uses established hostility and an entry-triggered six-elapsed-second glow; it does not infer hostility from creature type or faction. Alignment Sense retains its source-defined rank-1 redundancy as an open balance question. [Review status](DIVINATION_RANK1_REVIEW_STATUS.json) records manuscript scope; no full information/roll-system runtime or human balance is certified.


## Rank-two Divination: paid information and preserved turn timing

The [exact review](../../../../docs/audit/2026-10-08/full-game/GPT_DIVINATION_RANK2_EXACT_REVIEW.md) requires **Locate Person, Faction Spy and Resonance Tracking** to resolve hidden person eligibility, plane/range conditions and trace existence after casting costs commit. Their legal Self inquiry/search must not reveal those facts through a free target-legality check. No-result feeds/bearings/searches do not diagnose the hidden reason or refund committed costs. This clarification is scoped to these exact card interfaces; other spells retain their printed target rules.

The [final timing clarification](../../../../docs/audit/2026-10-08/full-game/GPT_DIVINATION_RANK2_FINAL_CLARIFICATION.md) keeps **Vision Trap** consistent with the existing hostile/next-turn convention: its pending rider ends at the end of the target's first future regular turn, excluding the entire current target turn even if its end is still upcoming. An attack earlier than that endpoint can consume the rider normally. Existing virtual markers, outside-initiative six-second timing and end-phase-before-cleanup ordering remain unchanged.

Augury and Alignment Prediction supply bounded useful likelihood forecasts without forcing choices. Divine Perception requires actual divine provenance. Clairvoyance and Faction Spy provide only their specified fixed remote senses. Resonance Tracking preserves the original cast-start age of actual origin/path/endpoint traces; observing them creates no copied trail, new resource or refreshed age. [Review status](DIVINATION_RANK2_REVIEW_STATUS.json) records manuscript scope; wider information, provenance, runtime and numerical balance remain open.


## Rank-three Divination: initiative, remains and information

The [exact review](../../../../docs/audit/2026-10-08/full-game/GPT_DIVINATION_RANK3_EXACT_REVIEW.md) approves all eight cards without functional repairs. [Review status](DIVINATION_RANK3_REVIEW_STATUS.json) records their bounded manuscript scope.

**Future Echo** records a willing allied participant order and, at the next numbered round boundary, permutes surviving participants only among their existing regular baseline slots. Finish current end-round events, restore any prior Echo permutation while retaining legitimate other initiative changes, then apply pending schedules in stable application order. Earlier applications claim their eligible participants, including a singleton; later schedules skip those participants. Enemy/unselected slots stay fixed. A pending schedule suppressed or unavailable at its one execution boundary expires without makeup. Its execution commits a fixed one-round assignment rather than a state that can be dispelled midround to duplicate or skip turns. The baseline returns at the following boundary before another Echo is applied. Each participant still receives exactly one actual regular turn and its ordinary start/end procedure. Existing virtual duration, periodic, falling and absolute clocks do not migrate or replay. Outside initiative the spell has no scheduling effect. This is a tabletop procedure; the broader scheduler adapter and full Time Loop remain unimplemented/disabled as previously recorded.

**Speak with Dead** retains both school placements. Cast through Cleric, Mirrorsage, Ranger, Shaman, Wizard or Paladin as Divination; through Crimson Agent, Druid or Thief as Necromancy, under the actual selected class access. A Divination-only protection therefore does not automatically block its Necromancy placement. The spell uses a retained memory echo associated with actual remains/death context, not a summoned soul or resurrection. Old fragments do not automatically acquire memories from a later resurrected life. Hidden identity eligibility resolves after paid casting; currently living identities are ineligible. Five separate Action/question exchanges follow the casting Action within its one-minute window. Actual return to life or loss of the qualifying physical anchor ends the interview.

Eyes of the Divine inspects readable appearance/form layers without reverting the body. Reveal Weakness affects the next actual save event, including an automatic-result save without overriding its result. Planar Window separates public ordinary vision from the caster's private native-presence detection. Faction Divination reads a genuine institutional objective, Alignment Revelation supplies public visible sigils after a failed CHA save, and Resonance Sight (Greater) identifies readable local effects and recorded proximate provenance without remote current-location omniscience. Wider runtime, source variants, secrecy, information completeness and human balance remain open.


## Enchantment cantrips: memory, concentration and bounded influence

The [exact Enchantment-cantrip review](../../../../docs/audit/2026-10-08/full-game/GPT_ENCHANTMENT_CANTRIP_EXACT_REVIEW.md) approves twelve cards after three repairs. [Review status](ENCHANTMENT_CANTRIP_REVIEW_STATUS.json) records the manuscript scope and open runtime/balance work.

**Disrupt Memory** removes the target's own episodic recall of the six elapsed seconds immediately before resolution after a failed WIS save. It does not undo world events, resource histories, mechanical choices, physical records or other observers' memories. It ends all actual Concentration the target personally maintains, including both spells in reviewed Wizard Spell Tether, both Crimson Harmony Veinweaves, and Wizard Tethered Cast's separately sustained concentration spell. The current reviewed class cards govern those interactions; older historical wording is preserved as evidence. Unrelated non-concentration sustained effects are unaffected. Memory-only immunity does not automatically prevent the independently applicable concentration ending.

**Mental Tap** establishes its next-save +1 immediately when defenses and HP handling establish positive numeric actualDamageDealt (temp HP absorbed plus ordinary HP lost, excluding overkill). A subsequent concentration save caused by that damage may consume it, including on self-targeting; an already-resolved initial INT save cannot change. **Soothe Animal** checks actual Beast/animal eligibility at application, not continuously; later transformation on the same creature does not automatically dispel calm. Its harm-ending rule still applies on another creature's hostile commitment or a positive resolved damage packet. **Beguiling Gaze** prevents voluntary meaningful aversion/eye blocking while permitting ordinary momentary blinking; it grants no gaze attack or facing engine and does not prevent ordinary movement out of range.

False Comfort and Enthralling Tune modify actual Perception checks without an invented passive -5. Friends is a caster-side Charisma benefit, not Charmed. Faction Sympathy retains its printed concentration and F component, actual affiliation and recognized-harm ending. Alignment Empathy snapshots orientation without changing/disclosing canonical axes. Resonance Whisper uses the reviewed actual-task bridge: failed target WIS save applies Disturb; successful save leaves an existing valid Whisper intact. Minor Suggestion supplies a harmless salient option and one social-check benefit without commanding action. These rules do not certify full social-control, memory or concentration runtime, numerical balance or broader-system closure.


## Rank-one Enchantment: compulsion, alignment and final spell pricing

The [exact rank-one Enchantment review](../../../../docs/audit/2026-10-08/full-game/GPT_ENCHANTMENT_RANK1_EXACT_REVIEW.md) approves twelve cards without functional repairs. [Review status](ENCHANTMENT_RANK1_REVIEW_STATUS.json) records the manuscript scope and open runtime/balance work.

Mesmerize's Stunned package and unaware rider remain distinct. Sleep retains its no-save, ordered fixed24-current-HP budget; an attempted immune/guard-blocked target still spends its cost. A helper's physical rousing Action ends all ordinary Sleep applications on that creature, while unrelated Unconscious causes remain. Positive post-defense/pre-temp-HP damage wakes without undoing an already determined hit/critical. Confusing Flash and Command use actual existing Action/movement/interaction permissions, not added budgets, and replace their own pending same-spell applications rather than banking them. Their actual whole-Action components claim the shared source-character/target/encounter allowance when established; a blocked component receives no invented fallback.

Distract cancels a pending Action only after its commitment/beginning hooks and before its first main outcome, subject to its INT save and shared hard guard. Its independent opportunity-attack restriction ends with the current numbered round. If a nested effect already canceled the formerly valid parent, Distract cancels nothing and claims no hard allowance for that nonexistent cancellation. Costs/attempt history persist; Counterspell keeps its own reviewed scope. Hideous Laughter separately applies immediate Prone and maintained Incapacitated. Its repeat save occurs at every affected regular-turn END, including the current regular turn when affected; this is not its maximum-duration clock. Initially prevented hard control does not wait to activate later.

Pacify restricts voluntary attacks and selected damaging spell modes without a harm-ending clause. Voice of Peace snapshots its protected participating allies at application; actual recognition of the target's allies is checked when provocation occurs. Faction Charm keeps independent caster/target/faction affinity records, without stacked advantage or compelled allegiance. Enthrall affects all actual Perception checks of its up-to-three targets. Its separate Enchantment rank2/Core349 source remains preserved/unassigned, not an upcast or extra grant.

**Alignment Suggestion:** calculate each new one-step shift with all prior same-spell overlays ignored, retaining independent actual alignment changes. Only changed defined axes receive fixed overlay values. A no-change result creates no replacement; the caster's already-required concentration transition still occurs and never resurrects an old application. A valid changed-axis application replaces the previous same-spell application; replaced concentration maintains no remaining effect. Ending exposes the then-current underlying alignment, not a historical snapshot. No conduct, belief or oathbreaking is compelled.

**Resonance Influence:** compute ordinary legal spell price first, including mandatory extras, Dissonance, eligible source reductions/waivers and each feature's own minimum. Then apply final plus/minus1, minimum0. A feature's minimum1 reduction step is not a universal final-price floor. Ease can offset one RP of the resulting total, including a mandatory Resonance Shield extra. A genuine RP-priced spell reduced/waived to0 still qualifies; Burden makes it1. In Mage Spell Sharing, the Mage's earlier sharing payment is unchanged, while the ally's later actual shared spell is independently priced: Ease0/Burden1. An ally unable to pay cannot commit, leaves Influence pending, and still uses the original limited sharing window. Nonspell techniques and charge-only spells without an RP-price interface do not qualify merely because they have costs. Qualifying class discounts require their actual class/spell eligibility; examples do not reclassify nonspell techniques. No runtime implementation or numerical balance is certified by this manuscript ruling.

## Rank-two Enchantment and shared control integration

Seven rank-two Enchantment identities have [exact manuscript approval](../../../../docs/audit/2026-10-08/full-game/GPT_ENCHANTMENT_RANK2_EXACT_REVIEW.md) with no functional card repairs. Their [shared control integration](ENCHANTMENT_CONTROL_INTEGRATION_PLAYTEST.md) is part of this provisional rules overlay and applies its specific arbitration interface to existing Command and Confusing Flash as well as Illusive Commands, Dire Charm and Crown of Madness. Their prior individual card texts remain unchanged.

The integration defines native ordinary Attack Actions and the explicit Confusing Flash single-attack exception; separately scoped Dire Charm components; chronological priority for conflicting instructions using the same ordinary budget; a shared six-second cycle for ongoing Dire Charm/Crown control outside initiative; and first-real-turn budget carry without replaying control orders. Ordinary real-turn start processing still occurs. One-shot commands keep their own timing while sharing actual remaining budgets.

Calm Emotions and Zone of Truth keep independent first-exposure save histories in fixed zones, with total-cover/outside suppression and return without rerolling. Calm Emotions suppresses actual Frightened effects while underlying clocks and saves continue. The five compared emotion-themed class cards acquire no new maintenance dependency. Zone of Truth preserves both actual class/rank/price modes without granting additional access or a truth-detection oracle. The [review status](ENCHANTMENT_RANK2_REVIEW_STATUS.json) retains open numerical balance, effect-runtime and broader social-control work.


## Rank-three Enchantment: companion control, source modes and task scope

Eight further identities have [exact manuscript approval](../../../../docs/audit/2026-10-08/full-game/GPT_ENCHANTMENT_RANK3_EXACT_REVIEW.md) with no functional repairs. Their [rank-three integration supplement](ENCHANTMENT_RANK3_INTEGRATION_PLAYTEST.md) is part of this provisional overlay. It explicitly binds Dominate Beast and Suggestion to existing instruction arbitration, supplies the owner-attached Beast-companion bridge and prevents duplicate commands/turns. Hypnotic Pattern retains Enchantment60ft versus Illusion30ft casting range, and its initial self-concentration collapse uses only the reviewed spell-specific atomic batch.

Terrifying Gaze and both Slow modes use the reviewed ending-save transition without generating action budgets. Slow preserves Action/WIS Enchantment and Reaction/CON Transmutation as separate source packages; its selected trigger creature, distinct movement segments, future-Reaction restriction and prospective Action ceiling are explicit. Mental Chains uses the actual voluntary boundary and original anchor with separated-plane suppression, without universal involuntary-transport immunity. Suggestion reserves necessary hard control at establishment, including conditional future tasks, and never dynamically acquires a new hard component. The [review status](ENCHANTMENT_RANK3_REVIEW_STATUS.json) retains human balance, effect-runtime and broader-system work as open.


## Evocation cantrips: actual casts, delayed riders and source-specific attacks

Twelve cantrips have [exact manuscript approval](../../../../docs/audit/2026-10-08/full-game/GPT_EVOCATION_CANTRIP_EXACT_REVIEW.md) without functional repairs. Read the full cards in [the spell reference](SPELL_PLAYTEST_STARTER.md); all fourteen source placements/Core blocks and actual class-access rows are retained. Their components remain V/S, with no added focus or automatic damage scaling.

Arcane Echo grants one genuine Bonus Action recast with the original actual class/school/rank-0 damaging-mode provenance, normal current eligibility/costs/hooks and chronological Refrain. Its arm and generated repeat keep separate finite records; a generated repeat never triggers another arm. Freezing Touch delays its Speed rider until the next regular target turn, with the expressly reviewed virtual-to-actual onset and original absolute cap. Flame Lash preserves the source conflict as a spell-local 30-foot melee attack. Shocking Grasp retains Reaction/30 feet and its prospective Reaction denial, without canceling a committed parent Action or stacked Reaction.

Dancing Lights has actual usable illumination for either generating school and bounded commanded movement. Chill Touch blocks broad current-HP gain, including direct recovery, while retaining independent non-HP effects and the existing resurrection life-transition exception. Its blocked natural20/Stable procedures use the existing healing-state rules. Soundburst and Thunderclap preserve distinct areas/riders; Thunderclap includes its caster. The object procedures never grant generic worn-item targeting. [Review status](EVOCATION_CANTRIP_REVIEW_STATUS.json) retains runtime, human balance and broader game integration as unfinished. Cosmology remains outside this mechanics batch.


## Rank-one Evocation attacks and maintained effects

Twelve rank-one Evocation identities have [exact manuscript approval](../../../../docs/audit/2026-10-08/full-game/GPT_EVOCATION_RANK1_EXACT_REVIEW.md), preserving thirteen placements/Core blocks and actual class access. Their complete procedures are in [the spell reference](SPELL_PLAYTEST_STARTER.md); the existing spell cards remain unchanged.

Magic Missile Storm fixes three separately resolved missiles at commitment. Its card expressly applies ordinary Shield's named Magic Missile exception, with one targeting opportunity per recipient before that recipient's first missile damage. This does not alias Mage Arcane Missile. Arcane Shield Shatter requires an individually perceived rank-0/1 spell protective layer and a protected creature, with exact source-qualified eligibility. Its current Resonance Shield grant and whole Protective Sphere procedures prevent stripping unrelated temporary HP or inventing a hole in a boundary.

Witch Bolt's maintenance uses an ordinary Action to activate its existing effect. It is not another cast. Its pulse-use history survives initiative changes while preserving the Action for other uses when a pulse was already spent. Zephyr Strike grants no attack at casting; its first weapon-hit rider and continuing movement protection have separate consumption rules. Ignition Bolt and Ice Knife retain their short source ranges and captured impact positions; only attack damage dice critically double. Earth Tremor creates finite magical difficult terrain on one contiguous supporting surface. See [review status](EVOCATION_RANK1_REVIEW_STATUS.json) for the remaining runtime and human-balance questions.


## Rank-two Evocation areas and delayed damage

Eight rank-two Evocation identities have [exact manuscript approval](../../../../docs/audit/2026-10-08/full-game/GPT_EVOCATION_RANK2_EXACT_AND_DELIVERY_REVIEW.md). Their [complete cards](SPELL_PLAYTEST_STARTER.md) preserve five exact Core blocks and three separate possible historical-name blocks; matching metadata adoption does not merge identities or class access. Scorching Raystorm uses three independent attacks; line and burst spells keep their printed ranges. Shatter uses one fixed pre-damage snapshot and bounded structural sections. Frost Nova's specific elemental Speed 0 rider uses the existing refresh policy and reviewed Balanced Elements bridge. Acid Arrow's independently owned delayed packets keep their original one-shot markers and are not new casts. See [review status](EVOCATION_RANK2_REVIEW_STATUS.json) for remaining runtime and balance work.


## Reviewed ancestry spell access

The [ancestry/background integration](ANCESTRY_BACKGROUND_PLAYTEST.md) defines a separate explicit casting source for40 fixed grants and two Wizard-cantrip choices. These grants use their own total-level gates, ability, school/mode and recharge; they do not create ordinary class access, an RP pool or RC conversion. Charge-only casts retain actual components/actions/concentration/interruption and shared Dissonance/Refrain, have no RP-price interface, and remain blocked at their actual Limit+6 for ranked casting. The focus token is ancestry-scoped only. Read the guide for exact short/long-rest recovery, Oracle and Echo of the Stolen rules.

The [seventeen dependency procedures](ANCESTRY_SPELL_SUPPLEMENT_PLAYTEST.md) comprise seven existing IDs promoted into this ordinary catalog and ten separate ancestry-grant-only additions. The additions have no ordinary class access. The original848IDs/936placements remain intact; full ordinary spell mechanics, live runtime and human balance remain open.
