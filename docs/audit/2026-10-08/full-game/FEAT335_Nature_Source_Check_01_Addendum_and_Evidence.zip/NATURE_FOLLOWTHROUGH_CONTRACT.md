# Finite Nature follow-through contract

Only Nature's Whisper native/SUP09 activation, rider and one actual later check. Record references must resolve to actual controlling state or visibly conditional test-world records; no truth is established by the field name or a boolean.

## NWR-01 — activation-and-commit

- exact sourceId ranger.base.nature-s-whisper; submitted/current source version and controlling addendum ID
- stable actor identity and native acquired-card route OR actual paid versatile_mastery grant/prepared SUP09 route
- for borrowing, source-bound actual donor acquisition, preparation event/elapsed60seconds, party/consent/consciousness and actual within30ft signal perception/understanding at commit
- canonical event ID, elapsed time, actual turn/regular-marker identity, phase/sequence and expected current state version
- actual Action permission or existing Ready setup/trigger/permitted Reaction-release record; no roll or success result in the declaration
- current legitimate personal RP pool/capacity/current quantity; actor/source-ID cooldown and borrowed allowance histories
- actual conscious/capable actor, applicable prohibitions/suppression records, selected natural-terrain footprint, commitment position, perception/line/range facts
- atomic precommit/rejected OR paid-pending receipt: ownRP1, ordinaryAction1 or allowedReadyReaction1, borrowedUse1 if applicable, same-cardRecharge3 and actual magical-use event
- existing Dissonance/spell-name/Refrain and applicable real cadence records before/after; no Nature spell update or invented casting ability/Limit
- resolution or source-authorized interruption event with actual source/trigger/current predicates; no Counterspell target by default, no artificial waiting window
- recorded terminal resolved/interrupted/failed status without refund or replay; absent/unknown evidence never promoted to permission


## NWR-02 — one-unused-rider

- actor identity, same exact source identity, successful activation ID and donor provenance only where borrowed
- original fixed natural area/commitment position and actual resolution time
- absolute deadline resolution+60 seconds; no separate second initiative/rest clock
- unused/committed-to-check/consumed/replaced/expired/actually-ended state, with event predecessor
- only one unused Nature rider per actor; successful newer resolution replaces older, failed newer activation does not itself replace
- no concentration, continuing donor tether, donated skill proficiency, passive+5, extra check or independent source-controller history


## NWR-03 — task-and-rider-consumption

- exact actual task/check permission and its own action/time payment; actual source DC or observer-specific Search record, not an invented universal DC
- one stable check/root/roll identity and actor; original fixed-area membership plus current natural terrain, within15ft, actual task senses/line/access
- Perception or Survival and actor own actual applicable ability/training/Expertise and other eligible modifiers; no donor or independent skill-borrowing grant
- actual advantage/disadvantage contributors with ordinary cancellation before determining face count; rider bound/spent before faces or result
- adjudication time strictly before rider deadline; a task beginning early does not protect later adjudication
- actual roll/outcome or genuine postcommit interruption, preserved costs and consumed rider on failure/cancellation
- actual supported evidence disclosed only by lawful successful task, observer scope and unknown-data restrictions; no automatic disclosure or fabricated absence
- an invalid precommit task/rider request leaves the rider unused but provides no roll, retroactive attachment or refund of earlier valid action costs


## Bounded model obligations

### `DescentReviewChanges/ReviewBible/tools/feat335_borrowed_stunts.py`

Locations: `BorrowedStunts.nature_whisper`, `BorrowedStunts.use_nature_advantage`

Preserve this submitted model as history. A measured current descendant must replace authoritative reliance on actualMinorWeaveClearance with the NWR01 source-qualified admission/state checks, expose declaration/payment then resolution, bind fixed terrain, and create the rider only on successful resolution. Split the later check into legal payment/rider commitment before any faces/result; use actual cancellation and own task training. Do not merely delete the old boolean and treat all magic as legal.

### `DescentReviewChanges/ReviewBible/tools/feat335_borrowed_transactions.py`

Locations: `BorrowedTransactions pending/interrupt interaction`, `Nature inherited methods`

The existing attack/task interrupt API is not evidence that Nature used it. Bind actual Nature paid-pending states and terminal interruption with no refund. Ready follows the separate existing setup/release procedure; it is not an indefinitely banked ordinary pending action.

### `docs/audit/2026-10-08/full-game/FEAT335_BORROWED_SKILL_TRANSACTIONS_CHECK.json`

Locations: `histories[id=ranger.base.nature-s-whisper]`, `limitations`

Keep the original362 report and38 histories unchanged as its stated partial evidence. Append a new measured follow-through report; do not retroactively label its omitted terrain/components/strain/interrupt behavior executed.

## Closure

Exact three-operation propagation, byte/object inverse preservation, full current mirror parity, source-bound NWR records and finite NWT01–16 boundary follow-through can close these four source interfaces without another generic conference. Authored expectations and executable reference projections remain separately labeled; no full335 approval follows.

All original objects, historical text/receipts, unrelated procedures, current status/selection flags, sourceVerdict/sourceBinding historical provenance, prior fulfilled gates and deferred cosmology stay unchanged.
