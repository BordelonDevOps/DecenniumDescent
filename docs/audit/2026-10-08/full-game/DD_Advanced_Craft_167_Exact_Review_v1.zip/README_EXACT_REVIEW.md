# Advanced crafting: all 167 exact authored candidates

This is the requested separate exact authored-operational review, following the final source-authoring verdict and ADV-EDIT-01. All167 actual internal cards, all100 actual player cards, complete guides/manuscripts,22 internal/15 public body defaults or variants,50 actual weapon/suit host templates,37 qualitative sequences and current numerical evidence are included under their real repository-relative paths. FILE_MANIFEST.json binds every payload's exact bytes. No installation or network access is needed.

## Start with these actual documents

Under DescentReviewChanges/ReviewBible/:
- data/director/advanced_craft_recipe_candidate_internal.json: complete originals, operational fields and rendered manuscriptText for all167, complete procedure sections, original body profiles plus controlling corrections, all48 class-interface dispositions, version/name history and source hashes.
- data/crafting/advanced_craft_recipe_candidate_public.json: all100 player projections, full operatingGuideText/bodyGuideText,15 body profiles and50 host templates.
- docs/director-only/ADVANCED_CRAFT_INTERNAL_OPERATIONAL_GUIDE.md and ADVANCED_CRAFT_INTERNAL_BODY_CATALOGUE.md: complete governing operational text and body definitions. Historical conflicting text is preserved and expressly superseded by ADV-EDIT-01.
- docs/director-only/{ENCHANTING,RUNE_CARVING,SCRIBING,TINKERING}_INTERNAL_RECIPE_CARDS.md: the complete actual167 rendered cards.
- docs/mechanics/ADVANCED_CRAFT_CANDIDATE_GUIDE.md and ADVANCED_CRAFT_CANDIDATE_BODY_CATALOGUE.md, plus {ENCHANTING,RUNE_CARVING,SCRIBING,TINKERING}_CANDIDATE_RECIPE_CARDS.md: the whole actual player envelope. Review the prose and operating dependencies, not only equal effect fields.
- docs/director-only/ADVANCED_CRAFT_PHYSICAL_SEQUENCE_CASEBOOK.md: all19 W fixtures,18 further E sequences with explicit rejected alternatives, and22 body boundaries. These are authored expected adjudications requiring your semantic review, not automated runtime passes.

## Authority and corrections

Under docs/audit/2026-10-08/full-game/:
- GPT_ADVANCED_167_SOURCE_AUTHORING_VERDICT.md is the FINAL 171095-byte source verdict, SHA256 48f885becd03e4a99ba8d6243ce286c1e1e88cfefc776af9ff89a9182c79c8e0, reply af2a24f6-c967-4aa5-a28e-5c2e9de13cb6. The exact final13-file package is preserved in advanced167-source-authoring-reviewer-files/. Earlier live draft values are not authority.
- GPT_ADVANCED_TRAP_SPRING_CLARIFICATION.md and ADVANCED_TRAP_SPRING_INTEGRATION.json bind ADV-EDIT-01, reply a01ad150-d04b-4fb8-ae18-9ea476535a93: original trap frame/discharge block are primary; compatible spring and separate subordinate contacts are replaceable through actual restoration. All11 trap cards and shared body/repair rules carry this correction. Automaton primary actuators are unchanged.
- ADVANCED_CRAFT_PLAYER_DISSONANCE_CORRECTION.json records a local adaptation error corrected before this submission: TD-08 routes up to TWO current Dissonance into ONE own actual active qualifying device within30 feet. The player guide and embedded JSON now agree with the complete source section. This is not a new class ruling. Prior local files remain archived outside this active envelope.
- All138 source/dependency files of the earlier submission are included unchanged. ADVANCED_CRAFT_JOINT_SUBMISSION.json binds their original hashes. Source/register checks5248/1623 reproduced identically; ADVANCED_CRAFT_LOCAL_SOURCE_VERIFICATION.json records this finite scope.

## Validation, scope and reproduction

ADVANCED_CRAFT_INTERNAL_CANDIDATE_VALIDATION.json:5770 complete-source, source-index/book/manuscript, preserved-field and finite-arithmetic assertions. ADVANCED_CRAFT_PUBLIC_CANDIDATE_VALIDATION.json:1725 assertions independently reconstructing every projected component occurrence, preserving all600 book paragraphs and checking the entire public envelope for withheld fields/memberships. All343 public component mentions remain;100 supplemental profiles have independent public authority. ADVANCED_CRAFT_PUBLIC_PROJECTION_LEDGER.json preserves every exclusion internally.

ADVANCED_CRAFT_WORKED_CASE_VALIDATION.json:52 grouped numeric/coverage assertions;2004 recipe×six-band×two-option cases,519 structural contexts,4560 transitions over eight distinct ordinary B values,185 damaged-chassis conversions,410 restoration quotations,59 maintenance-pack variants,36 missing-primary rejection inputs. Inapplicable manufacturing choices are explicitly labeled. Shared Core/structural/quotation calculations are reused only for identical mathematics; this does not import Fishing item effects or implement an advanced crafting runtime.

From the extracted repository root, Python3 standard library is sufficient for:
python DescentReviewChanges/ReviewBible/tools/validate_advanced_craft_internal_candidates.py
python DescentReviewChanges/ReviewBible/tools/validate_advanced_craft_public_candidates.py
python DescentReviewChanges/ReviewBible/tools/validate_advanced_craft_worked_cases.py
These validators write their named reports. Run them in a working copy after preserving the supplied manifest snapshot if retaining exact submitted evidence. Do not rerun the one-use authoring/correction/checkpoint builders. Their code is provenance, not a reviewer setup command.

Numeric passes are not proof of authentic stock, anatomy, access, consent, world events, protocol compatibility, functional spell payloads, table balance or companion runtime. The37 qualitative cases are expected rulings for review. In particular check event ordering, live eligibility/fallback, spent-resource persistence, class device interfaces and legitimate failure paths against the full source directions.

## Requested verdict and boundaries

Inspect all167 actual cards, all100 player projections, their complete shared guides and body dependencies; assess all37 sequences and every current source-authoring section. Give one exact authored-operational verdict and an exhaustive finite list of actual corrections with affected IDs/fields and replacement wording. State whether completing those named corrections and appropriate checks permits promotion without a further generic conference. If something was inaccessible or uninspected, identify it rather than approving unseen material.

Retain all source fields, nulls, original manuscripts, history and the genuine particular-operation prerequisites. Unsupported operations remain unavailable; a price, name, declared boolean or check pass supplies no missing campaign fact. Missing spell payloads and later feat/bestiary/language interfaces remain bounded dependencies rather than grounds for repeating the settled preliminary source conference. No class card or pending feat is promoted by this recipe review.

Current totals remain520/687 recipes and333/433 public reviewed, with167/100 candidates awaiting this exact verdict. The separate complete authored game and final joint whole-game flow confirmation still precede the authorized GitHub push; remote-commit verification precedes careful cosmology review. No deletion, push, cosmology interpretation, runtime implementation, human balance approval or publication claim occurs in this submission.
