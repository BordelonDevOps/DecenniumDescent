# Decennium Descent — complete 128-card gathering exact-review handoff

This archive contains actual complete files, not summaries or representative cards. It is internal reviewer material for Calibration Review Part 2. It is not the player publication package. All paths beneath this root retain their repository-relative structure. FILE_MANIFEST.json supplies byte sizes and SHA-256 for every payload file. Extract normally; no installation, shell setup, network call or package execution is needed to inspect it.

## Current authority and scope

Your GI-01–12 joint source verdict is in docs/audit/2026-10-08/full-game/GPT_GATHERING_JOINT_SOURCE_RECONCILIATION.md. Its GI-11-C1 loss/residue correction and GI-12-C1 Skinning structural-count correction are applied beside preserved originals. The earlier Skinning192/109 ingredient tally correction also remains explicit. All three full source verdicts and captures are included. Historical source-preparation reports may say unsent/pending; those describe their original stage, not this current candidate. GATHERING_128_EXACT_CANDIDATE_READINESS.json is the current scope statement.

## Read the actual candidate

The working root is DescentReviewChanges/ReviewBible/.

1. docs/director-only/GATHERING_TOOL_INTERNAL_DRAFT_INDEX.md and GATHERING_TOOL_INTERNAL_OPERATIONAL_GUIDE.md.
2. docs/mechanics/GATHERING_TOOL_CANDIDATE_GUIDE.md and MINING_CANDIDATE_GUIDE.md, SKINNING_CANDIDATE_GUIDE.md, SALVAGING_CANDIDATE_GUIDE.md.
3. data/director/gathering_tool_recipe_candidate_internal.json: all128 lossless original recipes, operational objects, full book bindings,17 output bodies and three auxiliary models. Read all43 Mining,43 Skinning and42 Salvaging cards. Compare the three complete internal recipe manuscripts and the internal body catalogue.
4. data/crafting/gathering_tool_recipe_candidate_public.json: all82 public records and15 output bodies. Compare all three complete public recipe manuscripts, the public body catalogue and full guide envelopes. All492 source book paragraphs remain exact and separate from operational additions.
5. docs/director-only/GATHERING_TOOL_PHYSICAL_SEQUENCE_CASEBOOK.md: all27 source worked examples,14 additional adjudication risks,17 body boundaries and eight joint seams. These qualitative outcomes are stated expectations to review, not claimed runtime passes.

## Validation is evidence with stated limits

The audit directory contains777 source/register/manuscript checks,824 guide/projection/arithmetic checks and67 worked-example numeric/coverage checks. The full1,536 manufacturing rows,544 structural inputs,3,264 reference transitions and256 quotations are supplied. Common structural and repair calculators are separately evaluated against those expectations. Declared missing-primary quotation rejections do not authenticate a real body's history or prove completed repair work.

The complete relevant authoring and validation code is included for inspection. There is no implemented gathering gameplay runtime. Numeric checks cannot establish actual world stock, anatomy, legal access, safe containment, Director authority, real receiving or human balance. The code does not purport to do so. Actual campaign records and independently governed procedures remain the prerequisites described in the cards/guides. Review the complete prose, operational objects and case dispositions rather than treating aggregate PASS as your verdict.

## Public metadata question for exact disposition

The player projection retains every printed ingredient occurrence and the public formula's required quantity/consumption/role. A supplemental material profile is included only when its name/tier/unit value/unit mass match one independently public source material. This publishes82 supplemental profiles. The other203 occurrences keep their recipe requirements, with extra metadata withheld and the exact original retained internally. This includes two printed mentions with restricted material dossiers. No donor list, drop chance, acquisition permission or private recipe membership is published. Please assess this complete envelope, including whether any withheld recipe-critical requirement needs a different explicit audience treatment; do not infer that a printed mention authorizes its dossier.

## Requested exact verdict

Review every card and give exact authored-operational approval or a finite, concrete correction list identifying affected records and replacement rules. If conditional, state whether completing the named repairs and appropriate checks permits promotion without another generic source conference. No preliminary source directions are missing. Do not reopen unchanged prior trades without a concrete newly identified conflict. Prior protected trade files are included as governing comparison evidence, not a request to reapprove them.

This review does not approve actual material availability, companion runtime, human balance, publication, final whole-game flow, push or cosmology. Counts remain392/687 reviewed,295 pending, public251/433 until an actual scoped verdict and its conditions are satisfied. The owner's order stays complete authored candidate plus final joint whole-game flow confirmation, authorized GitHub push, verified remote commit, then careful cosmology review. No deletion or push has occurred.
