$ErrorActionPreference = 'Stop'
$taskRoot = [System.IO.Path]::GetFullPath('C:\Github\DecenniumDescent').TrimEnd('\')
$taskMain = [System.IO.Path]::GetFullPath('C:\Github\DecenniumDescent\Descent assets\DecenniumDescent-main').TrimEnd('\')
$taskPreserved = [System.IO.Path]::GetFullPath('C:\Github\DecenniumDescent\_preserved\2026-10-08\outer-root')
$taskLog = 'C:\Users\cbord\Documents\ChatGPT\Decennium Descent\audit_work\move_ledger.jsonl'
$taskInventory = 'C:\Users\cbord\Documents\ChatGPT\Decennium Descent\audit_work\project_inventory.json'
if (!(Test-Path -LiteralPath $taskInventory)) { throw 'Missing hashed baseline' }
if (!(Test-Path -LiteralPath $taskMain)) { throw 'Approved working root is missing' }
if (Test-Path -LiteralPath (Join-Path $taskRoot '_preserved')) { throw 'Preservation folder already exists; inspect before continuing' }
$taskOuterItems = @(Get-ChildItem -LiteralPath $taskRoot -Force | Where-Object { $_.Name -ne 'Descent assets' })
$taskMainItems = @(Get-ChildItem -LiteralPath $taskMain -Force)
$taskPlan = @()
foreach ($item in $taskOuterItems) { $taskPlan += [PSCustomObject]@{source=$item.FullName; destination=(Join-Path $taskPreserved $item.Name); phase='preserve-outer'} }
foreach ($item in $taskMainItems) { $taskPlan += [PSCustomObject]@{source=$item.FullName; destination=(Join-Path $taskRoot $item.Name); phase='relocate-approved-main'} }
foreach ($operation in $taskPlan) {
    $sourceCheck = [System.IO.Path]::GetFullPath($operation.source)
    $destCheck = [System.IO.Path]::GetFullPath($operation.destination)
    if (!$sourceCheck.StartsWith($taskRoot + '\', [System.StringComparison]::OrdinalIgnoreCase) -or !$destCheck.StartsWith($taskRoot + '\', [System.StringComparison]::OrdinalIgnoreCase)) { throw 'Move escapes authorized root' }
    if ($sourceCheck -eq $taskRoot -or $destCheck -eq $taskRoot) { throw 'Cannot move the root itself' }
}
$taskPlan | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath 'C:\Users\cbord\Documents\ChatGPT\Decennium Descent\audit_work\move_plan.json' -Encoding utf8
New-Item -ItemType Directory -Path $taskPreserved -Force | Out-Null
foreach ($operation in $taskPlan) {
    if (Test-Path -LiteralPath $operation.destination) { throw ('Destination collision: ' + $operation.destination) }
    Move-Item -LiteralPath $operation.source -Destination $operation.destination
    if (!(Test-Path -LiteralPath $operation.destination) -or (Test-Path -LiteralPath $operation.source)) { throw ('Move verification failed: ' + $operation.source) }
    $operation | ConvertTo-Json -Compress | Add-Content -LiteralPath $taskLog -Encoding utf8
}
Write-Output ('Completed ' + $taskPlan.Count + ' top-level moves. No files deleted. Content verification follows.')
