import json, hashlib, collections, zipfile, xml.etree.ElementTree as ET
from pathlib import Path
ROOT=Path('\\\\?\\C:\\Github\\DecenniumDescent')
OUT=Path(r'C:\Users\cbord\Documents\ChatGPT\Decennium Descent\audit_work')
records=json.load(open(OUT/'inventory.json',encoding='utf-8'))
project=[r for r in records if r['category']=='project']
texts=OUT/'texts';texts.mkdir(exist_ok=True)
hashes=collections.defaultdict(list);errors=[];text_index=[];archives=[];json_errors=[]
text_ext={'.md','.txt','.json','.js','.ts','.tsx','.py','.mjs','.csv','.mdc','.yml','.yaml','.html','.cjs','.ps1'}
for r in project:
    p=ROOT/r['path']
    try:
        b=p.read_bytes();h=hashlib.sha256(b).hexdigest();r['sha256']=h;hashes[h].append(r['path'])
        ext=r['suffix'];text=None
        if ext in text_ext:
            if b.startswith((b'\xff\xfe',b'\xfe\xff')): text=b.decode('utf-16')
            elif b'\x00' in b[:1000]: text=b.decode('utf-16-le',errors='replace')
            else:text=b.decode('utf-8-sig',errors='replace')
            if ext=='.json':
                try:json.loads(text)
                except Exception as e:json_errors.append({'path':r['path'],'error':str(e)})
        elif ext=='.docx':
            with zipfile.ZipFile(p) as z:
                root=ET.fromstring(z.read('word/document.xml'))
                ns={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main'}
                text='\n'.join(''.join(para.itertext()) if False else ''.join(t.text or '' for t in para.findall('.//w:t',ns)) for para in root.findall('.//w:p',ns))
        elif ext=='.zip':
            with zipfile.ZipFile(p) as z:
                archives.append({'path':r['path'],'entries':len(z.infolist()),'bytes_uncompressed':sum(x.file_size for x in z.infolist()),'files':[x.filename for x in z.infolist()]})
        if text is not None:
            out=texts/(h+'.txt')
            if not out.exists():out.write_text(text,encoding='utf-8')
            text_index.append({'path':r['path'],'sha256':h,'text_file':str(out),'chars':len(text)})
    except Exception as e:errors.append({'path':r['path'],'error':str(e)})
json.dump(project,open(OUT/'project_inventory.json','w',encoding='utf-8'),indent=2)
json.dump(text_index,open(OUT/'text_index.json','w',encoding='utf-8'),indent=2)
json.dump(archives,open(OUT/'archives.json','w',encoding='utf-8'),indent=2)
dups=[{'sha256':h,'paths':paths} for h,paths in hashes.items() if len(paths)>1]
json.dump(dups,open(OUT/'duplicates.json','w',encoding='utf-8'),indent=2)
summary={'project_files':len(project),'unique_hashes':len(hashes),'duplicate_groups':len(dups),'duplicate_instances':sum(len(d['paths'])-1 for d in dups),'text_records':len(text_index),'unique_texts':len(set(r['sha256'] for r in text_index)),'archives':[{k:v for k,v in r.items() if k!='files'} for r in archives],'json_errors':json_errors,'read_errors':errors}
json.dump(summary,open(OUT/'analysis_summary.json','w',encoding='utf-8'),indent=2)
print(json.dumps({**summary,'json_errors_count':len(json_errors),'json_errors':json_errors[:12],'read_errors_count':len(errors),'read_errors':errors[:5]},indent=2))
