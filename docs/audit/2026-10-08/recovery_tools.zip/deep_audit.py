import json, zipfile, hashlib, difflib, collections, xml.etree.ElementTree as ET, re, sys
sys.stdout.reconfigure(encoding='utf-8')
from pathlib import Path
ROOT=Path('\\\\?\\C:\\Github\\DecenniumDescent')
OUT=Path(r'C:\Users\cbord\Documents\ChatGPT\Decennium Descent\audit_work')
AUDIT=ROOT/'docs/audit/2026-10-08'
records=json.load(open(OUT/'project_inventory.json',encoding='utf-8'))
index=json.load(open(OUT/'text_index.json',encoding='utf-8'))
prefix='Descent assets/DecenniumDescent-main/'
def newpath(old):return old[len(prefix):] if old.startswith(prefix) else old if old.startswith('Descent assets/') else '_preserved/2026-10-08/outer-root/'+old
checked={};packages=[];books=[]
for r in records:
    if r['suffix'] not in {'.docx','.xlsx','.zip'}:continue
    if r['sha256'] not in checked:
        try:
            with zipfile.ZipFile(ROOT/newpath(r['path'])) as z:
                failed=z.testzip()
                item={'valid_crc':failed is None,'failed_member':failed,'entries':len(z.infolist())}
                if r['suffix']=='.xlsx':
                    ns={'s':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
                    wb=ET.fromstring(z.read('xl/workbook.xml'))
                    item['sheets']=[s.attrib.get('name') for s in wb.findall('.//s:sheet',ns)]
                    item['external_links']=[n for n in z.namelist() if n.startswith('xl/externalLinks/')]
                checked[r['sha256']]=item
        except Exception as e:checked[r['sha256']]={'error':str(e)}
    packages.append({'path':newpath(r['path']),'sha256':r['sha256'],**checked[r['sha256']]})
def txt(relative):
    row=next(r for r in index if r['path']==prefix+relative)
    return Path(row['text_file']).read_text(encoding='utf-8')
main=txt('docs/manuals/The_Directors_Crucible_Complete_Director_Edition.docx')
rb=txt('DescentReviewChanges/ReviewBible/docs/manuals/The_Directors_Crucible_Complete_Director_Edition.docx')
diff=list(difflib.unified_diff(rb.splitlines(),main.splitlines(),fromfile='ReviewBible DM-01',tofile='main DM-01',n=2))
(AUDIT/'director_main_vs_review.diff.txt').write_text('\n'.join(diff),encoding='utf-8')
player=txt('books/player/Decennium_Descent_Player_Rulebook_v6.docx')
bookflags={k:len(re.findall(p,player,re.I)) for k,p in {'spell_slot_phrases':r'spell slots?','percentage_expressions':r'\d+\s*%','skill_point_mentions':r'skill points?','cooldown_mentions':r'cooldown','tiles_mentions':r'\btiles?\b','four_steps':r'four steps'}.items()}
json.dump(packages,open(AUDIT/'package_integrity.json','w',encoding='utf-8'),indent=2)
result={'package_files':len(packages),'unique_packages':len(checked),'package_errors':[r for r in packages if r.get('error') or r.get('valid_crc') is False],'director_main_characters':len(main),'director_review_characters':len(rb),'director_text_identical':main==rb,'director_diff_lines':len(diff),'player_text_flags':bookflags}
json.dump(result,open(AUDIT/'deep_audit_summary.json','w',encoding='utf-8'),indent=2)
print(json.dumps(result,indent=2))
print('Director changes excerpt:')
print('\n'.join(line[:260] for line in diff[:75]))
print('Residual spell slot references:')
for line in player.splitlines():
    if re.search(r'spell slots?',line,re.I):print(line[:1200])
