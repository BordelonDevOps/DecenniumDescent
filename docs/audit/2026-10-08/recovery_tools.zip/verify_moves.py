import json, hashlib, os
from pathlib import Path
ROOT=Path('\\\\?\\C:\\Github\\DecenniumDescent')
OUT=Path(r'C:\Users\cbord\Documents\ChatGPT\Decennium Descent\audit_work')
records=json.load(open(OUT/'inventory.json',encoding='utf-8'))
project={r['path']:r for r in json.load(open(OUT/'project_inventory.json',encoding='utf-8'))}
prefix='Descent assets/DecenniumDescent-main/'
errors=[];path_map=[];hashed=0;checked=0
for r in records:
    old=r['path']
    new=old[len(prefix):] if old.startswith(prefix) else old if old.startswith('Descent assets/') else '_preserved/2026-10-08/outer-root/'+old
    try:
        p=ROOT/new;st=p.stat()
        if st.st_size!=r['bytes']:errors.append({'old':old,'new':new,'error':'size mismatch'})
        if old in project:
            actual=hashlib.sha256(p.read_bytes()).hexdigest();hashed+=1
            if actual!=project[old]['sha256']:errors.append({'old':old,'new':new,'error':'SHA256 mismatch'})
        checked+=1
        if old!=new:path_map.append({'old_path':old,'new_path':new,'bytes':r['bytes'],'sha256':project.get(old,{}).get('sha256')})
    except Exception as e:errors.append({'old':old,'new':new,'error':str(e)})
report={'files_checked':checked,'project_hashes_verified':hashed,'mapped_files':len(path_map),'total_original_bytes':sum(r['bytes'] for r in records),'errors':errors,'deleted_files':0,'note':'Every original inventoried file checked for existence and size; all project files rehashed. Asset and dependency bytes not rehashed; whole-directory/local moves preserved them.'}
json.dump(path_map,open(OUT/'path_map.json','w',encoding='utf-8'),indent=2)
json.dump(report,open(OUT/'move_verification.json','w',encoding='utf-8'),indent=2)
print(json.dumps(report,indent=2))
if errors:raise SystemExit(1)
