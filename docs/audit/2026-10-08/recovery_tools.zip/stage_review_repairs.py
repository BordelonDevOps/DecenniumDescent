import json, hashlib, shutil, difflib
from pathlib import Path
from xml.etree import ElementTree as ET

ROOT=Path(r'C:\Github\DecenniumDescent')
LAB=ROOT/'DescentReviewChanges/incoming/DecenniumDescentV7_2_AI_Calibration_Lab/DecenniumDescentV7_2_AI_Calibration_Lab'
REVIEW=ROOT/'DescentReviewChanges/ReviewBible'
AUDIT=ROOT/'docs/audit/2026-10-08'
BACKUP=ROOT/'_preserved/2026-10-08/pre-edit'
ledger=[]
def sha(b):return hashlib.sha256(b).hexdigest()
def write(target,data,reason,source=None):
    before=target.read_bytes() if target.exists() else None
    if before==data:return
    rel=target.relative_to(ROOT)
    if before is not None:
        backup=BACKUP/rel
        if backup.exists():raise RuntimeError(f'Existing backup; refusing to replace {backup}')
        backup.parent.mkdir(parents=True,exist_ok=True);backup.write_bytes(before)
    target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
    ledger.append({'path':rel.as_posix(),'source':source,'before_sha256':sha(before) if before is not None else None,'after_sha256':sha(data),'reason':reason})

# The existing ReviewBible is the sole assembled review target. No frozen lab edits.
files=[
 'docs/mechanics/GAMEPLAY_LOOP_CANON.md','docs/mechanics/QUICKSTART_LEVEL_1.md',
 'docs/mechanics/DESIGN_DOCTRINE.md','books/player/Decennium_Descent_Quickstart_Reference_v1.docx',
 'src/lib/gameplay-loop.ts','src/components/ExpeditionTracker.tsx','tools/validate_gameplay_loop.py',
]
for rel in files:
    write(REVIEW/rel,(LAB/rel).read_bytes(),'Assemble existing reviewed V7.2 procedures in ReviewBible for playtest review; not a main cutover',str((LAB/rel).relative_to(ROOT)))

rules=json.loads((LAB/'data/public/Decennium_Descent_Gameplay_Loop_v1_2.json').read_text(encoding='utf-8'))
ex=rules['extraction']
ex['handlingModifiers']={
 'attentionExposed':1,'burdened':1,
 'unsecuredDangerousLot':{'perLot':1,'maximum':3,'tags':['Volatile','Cursed','Living'],'countRule':'Count each unsecured lot once even if it has multiple dangerous tags.'},
 'pursued':2,'securedRoute':-2,
 'capAppliesTo':['highestExtractionClass','attentionExposed','burdened','unsecuredDangerousLots'],
 'outsideCap':['pursued','securedRoute'],
}
ex['dcFormula']='tier DC + min(7, highest Extraction Class + exposed Attention + Burdened + min(3, unsecured dangerous lots)) + (2 if pursued) - (2 if Secured route)'
data=(json.dumps(rules,ensure_ascii=False,indent=2)+'\n').encode('utf-8')
for rel in ['data/public/Decennium_Descent_Gameplay_Loop_v1_2.json','src/data/gameplay-loop.json']:
    write(REVIEW/rel,data,'Fill explicit JSON representation from existing V7.2 extraction prose and helper; no change to published coefficients',str((LAB/'data/public/Decennium_Descent_Gameplay_Loop_v1_2.json').relative_to(ROOT)))

# Recover only differing ReviewBible passages, with both directions traceable.
def paras(p):
    import zipfile
    with zipfile.ZipFile(p) as z:doc=ET.fromstring(z.read('word/document.xml'))
    ns={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main'}
    return [''.join(p.itertext()) for p in []] if False else [''.join(t.text or '' for t in p.findall('.//w:t',ns)) for p in doc.findall('.//w:p',ns)]
rel='docs/manuals/The_Directors_Crucible_Complete_Director_Edition.docx'
a,b=paras(ROOT/rel),paras(REVIEW/rel)
blocks=[]
for tag,i,j,k,l in difflib.SequenceMatcher(None,a,b,autojunk=False).get_opcodes():
    if tag=='equal':continue
    blocks.append({'operation':tag,'main_paragraphs':[i+1,j],'review_paragraphs':[k+1,l],'main_text':a[i:j],'review_text':b[k:l]})
body=['# Recovered Director lore addendum','', '**Director only.** Recovered on 2026-10-08 from the existing ReviewBible edition and its 2026-07-31 theme-propagation changelog. These are source passages, not newly invented lore. The original books remain unchanged.','',
 '[Primary Director book](../manuals/The_Directors_Crucible_Complete_Director_Edition.docx) · [curated source](../../DescentReviewChanges/ReviewBible/docs/manuals/The_Directors_Crucible_Complete_Director_Edition.docx) · [source changelog](../../DescentReviewChanges/ReviewBible/CHANGELOG_THEME_PROPAGATION_2026-07-31.md) · [complete two-way comparison](../audit/2026-10-08/director_lore_blocks.json)','',
 'Use the documented thematic additions below alongside the primary book. Existing mechanics and intentional mysteries remain governed by their registered sources. Keep Heartcell/Silent Ones, Unity susceptibility and Coinfather truths out of player handouts. Public goblin diversity and financial institutions do not establish secret guilt or universal complicity.','']
for n,bl in enumerate(blocks,1):
    if not any(x.strip() for x in bl['review_text']):continue
    body.extend([f'## Recovered passage {n}',f"Source paragraph positions: ReviewBible {bl['review_paragraphs'][0]}–{bl['review_paragraphs'][1]}; compared with main {bl['main_paragraphs'][0]}–{bl['main_paragraphs'][1]}.",''])
    body.extend(t+'\n' for t in bl['review_text'] if t.strip())
write(AUDIT/'director_lore_blocks.json',(json.dumps(blocks,ensure_ascii=False,indent=2)+'\n').encode('utf-8'),'Traceable paragraph comparison of preserved Director books')
write(ROOT/'docs/director-only/RECOVERED_THEME_ADDENDUM.md','\n'.join(body).encode('utf-8'),'Consolidate documented curated lore as Director-only companion to primary book, preserving both originals',str((REVIEW/rel).relative_to(ROOT)))
if (AUDIT/'candidate_changes.json').exists():raise RuntimeError('Candidate ledger already exists')
(AUDIT/'candidate_changes.json').write_text(json.dumps(ledger,indent=2),encoding='utf-8')
print(json.dumps({'changed_files':len(ledger),'director_diff_blocks':len(blocks),'deleted':0}))
