from pathlib import Path
import json,hashlib,re,zipfile,os
from urllib.parse import unquote
ROOT=Path(r'\\?\C:\Github\DecenniumDescent')
AUDIT=ROOT/'docs/audit/2026-10-08'
TOOLROOT=Path(r'C:\Users\cbord\Documents\ChatGPT\Decennium Descent\audit_tools')

# Presentation cleanup: retain all diff evidence, omit punctuation-only passages from the reading addendum.
blocks=json.loads((AUDIT/'director_lore_blocks.json').read_text(encoding='utf-8'))
addendum=ROOT/'docs/director-only/RECOVERED_THEME_ADDENDUM.md'
intro=addendum.read_text(encoding='utf-8').split('## Recovered passage')[0]
norm=lambda a:re.sub(r'\s+',' ',re.sub(r'(?<=\d),(?=\d)','',' '.join(a))).strip()
parts=[intro]
kept=0
for n,b in enumerate(blocks,1):
    if norm(b['main_text'])==norm(b['review_text']) or not norm(b['review_text']):continue
    kept+=1
    main=b['main_paragraphs'];review=b['review_paragraphs']
    pos=f'before main paragraph {main[0]}' if main[1]<main[0] else f'main paragraphs {main[0]}–{main[1]}'
    parts += [f'## Recovered passage {n}\n',f'Source: ReviewBible paragraphs {review[0]}–{review[1]}; compared with {pos}.\n','\n\n'.join(p for p in b['review_text'] if p.strip())+'\n']
addendum.write_text('\n'.join(parts),encoding='utf-8')

# Locate every original project byte stream either at its mapped path or in its pre-edit backup.
records=json.loads((AUDIT/'project_inventory.json').read_text(encoding='utf-8'))
prefix='Descent assets/DecenniumDescent-main/'
def mapped(p):return p[len(prefix):] if p.startswith(prefix) else p if p.startswith('Descent assets/') else '_preserved/2026-10-08/outer-root/'+p
errors=[];current=0;backed_up=0
for rec in records:
    rel=mapped(rec['path']);p=ROOT/rel
    actual=hashlib.sha256(p.read_bytes()).hexdigest() if p.is_file() else None
    if actual==rec['sha256']:current+=1;continue
    backup=ROOT/'_preserved/2026-10-08/pre-edit'/rel
    bh=hashlib.sha256(backup.read_bytes()).hexdigest() if backup.is_file() else None
    if bh==rec['sha256']:backed_up+=1
    else:errors.append({'original':rec['path'],'current':rel,'expected':rec['sha256'],'actual':actual,'backup':bh})
result={'original_project_files':len(records),'original_bytes_at_current_path':current,'original_bytes_in_pre_edit_backup':backed_up,'errors':errors,'deleted_original_files':0 if not errors else 'unverified','note':'All original project file contents hashed after repairs. See move_verification.json for whole-folder asset/dependency existence and size verification before repairs.'}
(AUDIT/'final_preservation_check.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
if errors:raise RuntimeError(json.dumps(errors))

docs=[ROOT/'START_HERE.md',ROOT/'docs/director-only/RECOVERED_THEME_ADDENDUM.md',ROOT/'DescentReviewChanges/ReviewBible/RECOVERY_REVIEW_2026-10-08.md']+list(AUDIT.glob('*.md'))
bad=[];links=0
for doc in docs:
    for target in re.findall(r'\]\(([^)]+)\)',doc.read_text(encoding='utf-8')):
        if re.match(r'https?://',target) or target.startswith('#'):continue
        target=unquote(target.split('#')[0].strip('<>'));links+=1
        if not Path(os.path.normpath(str(doc.parent/target))).exists():bad.append({'file':str(doc.relative_to(ROOT)),'target':target})
(AUDIT/'navigation_validation.json').write_text(json.dumps({'local_links_checked':links,'missing':bad},indent=2),encoding='utf-8')
if bad:raise RuntimeError(json.dumps(bad))
with zipfile.ZipFile(AUDIT/'recovery_tools.zip','w',zipfile.ZIP_DEFLATED) as z:
    for p in TOOLROOT.glob('*'):
        if p.is_file():z.write(p,p.name)
with zipfile.ZipFile(AUDIT/'recovery_tools.zip') as z:assert z.testzip() is None
hashes=[]
for p in AUDIT.iterdir():
    if p.is_file() and p.name!='audit_artifact_hashes.json':hashes.append({'name':p.name,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
(AUDIT/'audit_artifact_hashes.json').write_text(json.dumps(hashes,indent=2),encoding='utf-8')
print(json.dumps({**result,'links_checked':links,'missing_links':bad,'substantive_director_passages':kept}))
