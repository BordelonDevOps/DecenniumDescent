from pathlib import Path
import zipfile,json,hashlib,collections
ROOT=Path(r'\\?\C:\Github\DecenniumDescent')
AUDIT=ROOT/'docs/audit/2026-10-08'
known={r['sha256'] for r in json.loads((AUDIT/'project_inventory.json').read_text(encoding='utf-8'))}
packages=json.loads((AUDIT/'package_integrity.json').read_text(encoding='utf-8'))
archives=[]
for package in packages:
    if not package['path'].lower().endswith('.zip'):continue
    members=[]
    with zipfile.ZipFile(ROOT/package['path']) as z:
        for info in z.infolist():
            if info.is_dir():continue
            digest=hashlib.sha256(z.read(info)).hexdigest()
            members.append({'member':info.filename,'bytes':info.file_size,'sha256':digest,'has_loose_project_match':digest in known})
    archives.append({'path':package['path'],'members':members})
unmatched=[{'archive':a['path'],**m} for a in archives for m in a['members'] if not m['has_loose_project_match']]
result={'archives':archives,'unmatched_members':unmatched,'note':'No archives extracted or deleted. Unmatched means no byte-identical loose project file in the original inventory, not necessarily unique semantic content.'}
(AUDIT/'archive_content_audit.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
counts=collections.Counter(Path(m['member']).suffix.lower() for m in unmatched)
lines=['# Archive contents audit','','Archive members were hashed and compared with all original loose project-file hashes. No archive was deleted or blindly unpacked. An unmatched member may be an older or differently packaged version; absence of a byte match does not make it new canon.','',f'Archives inspected: {len(archives)}. File members: {sum(len(a["members"]) for a in archives)}. Unmatched file members: {len(unmatched)} ({len(set(m["sha256"] for m in unmatched))} distinct byte contents).','', '| Archive | File members | No loose byte match |','|---|---:|---:|']
for a in archives:lines.append(f'| `{a["path"]}` | {len(a["members"])} | {sum(not m["has_loose_project_match"] for m in a["members"])} |')
lines+=['','Full paths, sizes and hashes: [archive_content_audit.json](archive_content_audit.json). Retain all archives until these unmatched members have been reconciled.','']
(AUDIT/'ARCHIVE_CONTENTS.md').write_text('\n'.join(lines),encoding='utf-8')
print(json.dumps({'archives':len(archives),'members':sum(len(a['members']) for a in archives),'unmatched':len(unmatched),'unmatched_distinct':len(set(m['sha256'] for m in unmatched)),'unmatched_extensions':dict(counts)}))
