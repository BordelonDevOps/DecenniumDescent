import os, json, collections, hashlib, datetime, zipfile
from pathlib import Path

ROOT=Path('\\\\?\\C:\\Github\\DecenniumDescent')
OUT=Path(r'C:\Users\cbord\Documents\ChatGPT\Decennium Descent\audit_work')
OUT.mkdir(exist_ok=True)
generated={'.git','node_modules','.next','out','__pycache__','.cache','.venv','venv'}
records=[]
errors=[]
def error(e): errors.append(str(e))
for directory, dirs, files in os.walk(ROOT, onerror=error):
    for name in files:
        p=Path(directory)/name
        rel=p.relative_to(ROOT)
        parts=rel.parts
        asset=len(parts)>1 and parts[0]=='Descent assets' and parts[1]!='DecenniumDescent-main'
        cat='third_party_or_imported_assets' if asset else 'generated_or_dependency' if any(x in generated for x in parts[:-1]) else 'project'
        try:
            st=p.stat()
            records.append({'path':rel.as_posix(),'bytes':st.st_size,'modified':datetime.datetime.fromtimestamp(st.st_mtime,datetime.timezone.utc).isoformat(),'category':cat,'suffix':p.suffix.lower()})
        except OSError as e: error(e)
json.dump(records,open(OUT/'inventory.json','w',encoding='utf-8'),ensure_ascii=False,indent=2)
cats=collections.defaultdict(lambda:{'files':0,'bytes':0})
trees=collections.defaultdict(lambda:{'files':0,'bytes':0})
ext=collections.Counter()
for r in records:
    cats[r['category']]['files']+=1;cats[r['category']]['bytes']+=r['bytes']
    parts=r['path'].split('/'); key='/'.join(parts[:3]) if parts[0]=='Descent assets' else parts[0]
    trees[key]['files']+=1; trees[key]['bytes']+=r['bytes']
    if r['category']=='project':ext[r['suffix']]+=1
summary={'total_files':len(records),'total_bytes':sum(r['bytes'] for r in records),'categories':dict(cats),'top_trees':dict(sorted(trees.items(),key=lambda x:-x[1]['bytes'])[:35]),'project_extensions':dict(ext.most_common()),'errors':errors}
json.dump(summary,open(OUT/'summary.json','w',encoding='utf-8'),indent=2)
print(json.dumps({**summary,'top_trees':{},'errors_count':len(errors),'errors':errors[:3]},indent=2))
with open(OUT/'project_paths.txt','w',encoding='utf-8') as f:
    f.write('\n'.join(r['path'] for r in records if r['category']=='project'))
