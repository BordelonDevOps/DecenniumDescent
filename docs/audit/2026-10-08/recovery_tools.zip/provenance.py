import json, collections, re
from pathlib import Path
BASE=Path('\\\\?\\C:\\Github\\DecenniumDescent')
OUT=Path(r'C:\Users\cbord\Documents\ChatGPT\Decennium Descent\audit_work')
records=json.load(open(OUT/'project_inventory.json',encoding='utf-8'))
by_path={r['path']:r for r in records}
MAIN='Descent assets/DecenniumDescent-main/'
roots={'outer':'','main':MAIN,'review':MAIN+'DescentReviewChanges/ReviewBible/','v6':MAIN+'DecenniumDescentv6/','v7_1':MAIN+'DescentReviewChanges/incoming/DecenniumDescentV7_1_AI_Playtest_Lab/DecenniumDescentV7_1_AI_Playtest_Lab/','v7_2':MAIN+'DescentReviewChanges/incoming/DecenniumDescentV7_2_AI_Calibration_Lab/DecenniumDescentV7_2_AI_Calibration_Lab/'}
target_paths=['docs/canon/CANON_MANIFEST.json','CANON_MANIFEST.json','books/player/Decennium_Descent_Player_Rulebook_v6.docx','decennium descent player rulebook.docx','rulebook_output.txt','src/data/class-core-mechanics.js','src/data/class-details.js','src/data/feats.js','src/data/spells.js','src/data/crafting-recipes.json','src/bestiary_data_full.json','src/data/gameplay-loop.json','docs/mechanics/GAMEPLAY_LOOP_CANON.md','docs/manuals/The_Directors_Crucible_Complete_Director_Edition.docx','data/public/Decennium_Descent_Core_Systems_Data_v2_Known_Descent.json']
matrix=[]
for t in target_paths:
    row={'file':t,'versions':{}}
    for label,root in roots.items():
        r=by_path.get(root+t)
        row['versions'][label]={'sha256':r['sha256'],'bytes':r['bytes']} if r else None
    matrix.append(row)
json.dump(matrix,open(OUT/'version_matrix.json','w'),indent=2)
manifest=json.loads((BASE/MAIN/'docs/canon/CANON_MANIFEST.json').read_text(encoding='utf-8'))
missing=[]
for d in manifest['domains']:
    for p in d.get('authoritativePaths',[]):
        if not (BASE/MAIN/p).exists():missing.append({'domain':d['domain'],'path':p})
json.dump(missing,open(OUT/'missing_canon_paths.json','w'),indent=2)
print('Missing canonical paths:',json.dumps(missing))
for label,root in roots.items():
    count={}
    for rel in ['src/data/crafting-recipes.json','src/bestiary_data_full.json','data/crafting/Decennium_Descent_Crafting_Bible_v4.json']:
        p=BASE/root/rel
        if p.exists():
            x=json.loads(p.read_text(encoding='utf-8-sig'));count[rel]=len(x) if isinstance(x,list) else {k:len(v) for k,v in x.items() if isinstance(v,list)}
    print(label,json.dumps(count))
print('Selected identical sets:')
for row in matrix:
    h=collections.defaultdict(list)
    for label,v in row['versions'].items():
        if v:h[v['sha256'][:12]].append(label)
    print(row['file'],dict(h))
idx=json.load(open(OUT/'text_index.json',encoding='utf-8'))
for filename in ['books/player/Decennium_Descent_Player_Rulebook_v6.docx','docs/manuals/The_Directors_Crucible_Complete_Director_Edition.docx']:
    for row in idx:
        if row['path']==MAIN+filename:
            content=Path(row['text_file']).read_text(encoding='utf-8')
            (OUT/('player_v6.txt' if 'Player_Rulebook' in filename else 'director.txt')).write_text(content,encoding='utf-8')
            print(filename, 'chars',len(content),'fighter',len(re.findall(r'\bFighter\b',content)),'spell slots',len(re.findall(r'spell slots?',content,re.I)))
