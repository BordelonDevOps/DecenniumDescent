import fs from 'node:fs';
import path from 'node:path';
import {pathToFileURL} from 'node:url';
import crypto from 'node:crypto';

const root='C:/Github/DecenniumDescent';
const lab=root+'/DescentReviewChanges/incoming/DecenniumDescentV7_2_AI_Calibration_Lab/DecenniumDescentV7_2_AI_Calibration_Lab';
const out=root+'/docs/audit/2026-10-08';
const scratch='C:/Users/cbord/Documents/ChatGPT/Decennium Descent/audit_work/registry-snapshot';
const results={};
for(const [label,source] of Object.entries({main:root,v7_2:lab})){
  const dest=path.join(scratch,label);fs.mkdirSync(dest,{recursive:true});
  fs.writeFileSync(path.join(dest,'package.json'),JSON.stringify({type:'module'}));
  const provenance=[];
  for(const name of fs.readdirSync(path.join(source,'src/data'))){
    if(!name.endsWith('.js'))continue;
    const bytes=fs.readFileSync(path.join(source,'src/data',name));
    // Only a disposable inspection copy gains explicit Node import extensions.
    const text=bytes.toString('utf8').replace(/(from\s+["'])(\.\/[\w-]+)(["'])/g,'$1$2.js$3');
    fs.writeFileSync(path.join(dest,name),text);
    provenance.push({path:'src/data/'+name,sha256:crypto.createHash('sha256').update(bytes).digest('hex')});
  }
  const read=async n=>import(pathToFileURL(path.join(dest,n+'.js')).href);
  const {CANON_CLASSES}=await read('canon-classes');
  const {default:details}=await read('class-details');
  const {default:paths}=await read('class-paths');
  const {default:core}=await read('class-core-mechanics');
  const {CLASS_HIT_DICE}=await read('class-hit-dice');
  const {default:feats}=await read('feats');
  const classes=[],abilities=[];
  for(const cls of CANON_CLASSES){
    const d=details[cls],p=paths[cls];
    const levels=Array.from({length:20},(_,i)=>({level:i+1,features:(d.levels?.[i+1]??[]).map(f=>typeof f==='string'?{text:f,draft:false}:f)}));
    for(const band of ['archPaths','heroPaths'])for(const [pi,pth] of (p[band]??[]).entries())for(const kind of ['passives','actives'])for(const [ai,a] of (pth[kind]??[]).entries()){
      const txt=typeof a==='string'?a:JSON.stringify(a);
      abilities.push({auditLocator:`${cls}/${band}/${pi}/${kind}/${ai}`,class:cls,path:pth.name,band,kind,sourceText:txt,sourceType:typeof a,withoutColon:!txt.includes(':'),capstoneOrFinal:/capstone|finale|final[ —:]|final miracle/i.test(txt),fields:typeof a==='object'?Object.keys(a):[],canonicalId:typeof a==='object'?(a.id??null):null,structuredMinimumClassLevel:typeof a==='object'?(a.minLevel??a.level??null):null});
    }
    classes.push({class:cls,hitDie:CLASS_HIT_DICE[cls].die,core:core[cls],levels,emptyLevels:levels.filter(l=>!l.features.length).map(l=>l.level),draftFeatures:levels.flatMap(l=>l.features.filter(f=>f.draft).map(f=>({level:l.level,...f}))),asiLevels:levels.filter(l=>l.features.some(f=>/ability score improvement/i.test(f.text))).map(l=>l.level),paths:p});
  }
  const texts=provenance.filter(p=>/class-|prestige|feats|oracle|paladin|druid/.test(p.path)).map(p=>({path:p.path,text:fs.readFileSync(path.join(source,p.path),'utf8')}));
  const pointHits=texts.flatMap(t=>t.text.split(/\r?\n/).flatMap((l,i)=>/skill.?points|pointsSpent|treeCost|nodeCost|unlockPoints|\brespec\b/i.test(l)?[{path:t.path,line:i+1,text:l}]:[]));
  results[label]={source,provenance,classes,abilities,pointOrRespecHits:pointHits,feats:{count:feats.length,uniqueIds:new Set(feats.map(f=>f.id)).size,statuses:feats.reduce((s,f)=>{s[f.status??'unspecified']=(s[f.status??'unspecified']??0)+1;return s;},{})}};
}
fs.writeFileSync(out+'/advancement_matrix.json',JSON.stringify(results,null,2));
const rows=results.v7_2.classes.map(c=>{
  const a=results.v7_2.abilities.filter(a=>a.class===c.class);
  return `| ${c.class} | d${c.hitDie} | ${c.core.primary} | ${c.paths.archPaths.length}/${c.paths.heroPaths.length} | ${a.length} | ${a.filter(x=>x.withoutColon).length} | ${c.draftFeatures.length} | ${c.emptyLevels.join(', ')||'none'} |`;
});
const md=`# Structured advancement extraction\n\nSource comparison: main and preserved V7.2, 2026-10-08. This is an audit, not new rules. Full verbatim fields, every class level and source SHA-256 values are in [advancement_matrix.json](advancement_matrix.json). Temporary import adapters were used only in the audit workspace; source modules were not changed.\n\nBoth branches still use many plain strings rather than operational ability records. Path-level active/passive entries have no canonical ability IDs or explicit acquisition, action, resource-cost and cooldown fields. The no-colon count is a text-format signal, not proof of a missing description; entries with colons can still lack playable details. Automatic-vs-selected acquisition cannot be inferred from presence in an array.\n\n## V7.2 coverage\n\n| Class | Runtime HD | Protected engine | Arch/Hero paths | Path entries | No-colon entries | Draft level features | Levels with no feature entry |\n|---|---|---|---:|---:|---:|---:|---|\n${rows.join('\n')}\n\nEmpty levels may legitimately have resource or spell progression elsewhere. They are not automatically defects. Draft features remain author-review drafts even when runtime merges them into a level table. V7.2 validation currently checks identity and presence, not complete operational ability definitions.\n\n## Findings\n\n- Runtime Bard still contains Crescendo die/Bard College/Font of Inspiration level features, while the protected engine and book describe a five-stack rhythm system.\n- Druid runtime grants Shapeshifting at L2 while the book and uses function grant it at L1.\n- Oracle runtime HD is d8; the detailed book entry says d6 while its overview says d8.\n- Slot-era draft wording survives in V7.2 as well as main. Do not assume lab promotion alone repairs it.\n- A universal skill-point economy is not implemented in these modules. See exact point/respec search hits in the JSON.\n- Arch and Hero entries include names or qualitative effects without complete mechanical fields. They need deliberate design completion, not only document cleanup.\n\n## Scope\n\nThe matrix includes all 17 class-level tables and path lists, core contracts, hit dice, feat counts and point/respec references in related structured modules. Druid forms, Oracle Mysteries/Curses, Paladin Oaths, spell progression and prestige text remain separate source modules and must be consulted when completing individual abilities.\n`;
fs.writeFileSync(out+'/ADVANCEMENT_MATRIX.md',md);
const summary=Object.fromEntries(Object.entries(results).map(([k,v])=>[k,{classes:v.classes.length,pathEntries:v.abilities.length,withoutColon:v.abilities.filter(a=>a.withoutColon).length,structuredAbilityObjects:v.abilities.filter(a=>a.sourceType==='object').length,draftFeatures:v.classes.reduce((n,c)=>n+c.draftFeatures.length,0),pointOrRespecHits:v.pointOrRespecHits.length,feats:v.feats}]));
console.log(JSON.stringify(summary,null,2));

