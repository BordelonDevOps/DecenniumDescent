from pathlib import Path
import json,hashlib
ROOT=Path(r'C:\Github\DecenniumDescent')
AUDIT=ROOT/'docs/audit/2026-10-08'
ledger=[]
def update(rel,fn):
    p=ROOT/rel;old=p.read_bytes();new=fn(old.decode('utf-8-sig')).encode('utf-8')
    if old==new:return
    backup=ROOT/'_preserved/2026-10-08/pre-edit'/rel
    if backup.exists():raise RuntimeError('Refusing to overwrite backup '+str(backup))
    backup.parent.mkdir(parents=True,exist_ok=True);backup.write_bytes(old);p.write_bytes(new)
    ledger.append({'path':rel,'before_sha256':hashlib.sha256(old).hexdigest(),'after_sha256':hashlib.sha256(new).hexdigest()})
def tsconfig(text):
    j=json.loads(text)
    for item in ['_preserved','Descent assets']:
        if item not in j['exclude']:j['exclude'].append(item)
    return json.dumps(j,indent=2)+'\n'
update('tsconfig.json',tsconfig)
update('README.md',lambda s: '> **Recovered working root — 2026-10-08:** Start with [START_HERE.md](START_HERE.md) for the current books, preserved history and completion status. This folder contains approved V6 plus unpromoted review work; older release claims below must be read in that context.\n\n'+s)
update('src/data/CONTENT_GAPS.md',lambda s: '> **Historical report (July 2026).** Some counts and completion claims below are superseded. Use [the October recovery audit](../../docs/audit/2026-10-08/AUDIT_REPORT.md) and [advancement matrix](../../docs/audit/2026-10-08/ADVANCEMENT_MATRIX.md) for the current source comparison. Original findings remain below for provenance.\n\n'+s)
update('docs/canon/REPOSITORY_PROMOTION.md',lambda s:s.replace('`DecenniumDescent-main` working tree','`C:\\Github\\DecenniumDescent` working tree (relocated 2026-10-08)'))
(AUDIT/'navigation_changes.json').write_text(json.dumps(ledger,indent=2),encoding='utf-8')
print(json.dumps({'files_updated':len(ledger),'reason':'Route readers to current evidence; exclude preserved and imported trees from main TypeScript build after relocation'}))
