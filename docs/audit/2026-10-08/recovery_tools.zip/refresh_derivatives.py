import json, hashlib, shutil
from pathlib import Path
ROOT=Path('C:/Github/DecenniumDescent')
OUT=Path(r'C:\Users\cbord\Documents\ChatGPT\Decennium Descent\audit_work')
backup=ROOT/'_preserved/2026-10-08/pre-edit'
changes=[]
def write(rel,content,encoding='utf-8'):
    p=ROOT/rel
    before=None
    if p.exists():
        before=hashlib.sha256(p.read_bytes()).hexdigest()
        b=backup/rel;b.parent.mkdir(parents=True,exist_ok=True)
        if b.exists():raise RuntimeError('Backup already exists: '+str(b))
        shutil.copy2(p,b)
    p.parent.mkdir(parents=True,exist_ok=True);p.write_text(content,encoding=encoding)
    changes.append({'path':rel,'before_sha256':before,'after_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'reason':'Restore source-derived reference and current workspace paths; no rule changes'})
source=(OUT/'player_v6.txt').read_text(encoding='utf-8')
for rel in ['rulebook_output.txt','DescentReviewChanges/ReviewBible/rulebook_output.txt']:
    write(rel,source,'utf-16')
write('docs/reference/Player_Rulebook_v6_source_text.txt',source)
for rel in ['docs/mechanics/CONTINUITY_SOURCE_OF_TRUTH.md','DescentReviewChanges/ReviewBible/docs/mechanics/CONTINUITY_SOURCE_OF_TRUTH.md']:
    p=ROOT/rel
    if p.exists():
        text=p.read_text(encoding='utf-8-sig')
        updated=text.replace('C:\\Github\\Descent assets\\DecenniumDescent-main','C:\\Github\\DecenniumDescent').replace('C:\\Github\\DecenniumDescent\\Descent assets\\DecenniumDescent-main','C:\\Github\\DecenniumDescent')
        if updated!=text:write(rel,updated)
audit=ROOT/'docs/audit/2026-10-08';audit.mkdir(parents=True,exist_ok=True)
for name in ['inventory.json','summary.json','project_inventory.json','duplicates.json','archives.json','version_matrix.json','missing_canon_paths.json','path_map.json','move_plan.json','move_ledger.jsonl','move_verification.json','analysis_summary.json']:
    shutil.copy2(OUT/name,audit/name)
json.dump(changes,open(audit/'reference_changes.json','w',encoding='utf-8'),indent=2)
print(json.dumps({'derivatives_and_paths_updated':len(changes),'changes':changes},indent=2))
