import json
from pathlib import Path
root=Path(__file__).resolve().parent
repo=root.parent/'github-delivery'
ref=repo/'docs/unity/evidence/2026-11-15-mgt03-cleric-long-rest/implementation/qualification/trace-terminal/reference/cleric-advanced.ddsave'
out=root/'one-day';out.mkdir(exist_ok=False)
rows=[]
def add(op,**kw): rows.append(dict(op=op,**kw))
def submit(kind,actor='TEST_ONLY.companion',target='',**kw):
 add('submit',id='bishop.one-day.'+str(len(rows)),seat='Player',actor=actor,kind=kind,target=target,x=0,y=0,**kw)
def clock(n,d=1): add('clock',id='bishop.one-day.clock.'+str(len(rows)),x=n,y=d)
def checkpoint(name): add('save',path=str(out/(name+'.ddsave')));add('view',seat='Player')
def intake(target,n):submit('StartIntake','TEST_ONLY.actor',target,inventory=dict(numerator=n,denominator=1,destination='',handling='Pickup'))
def guidance(target):submit('CastKnownSpell',target=target,spellCast=dict(spellId='guidance',focusItemId='',willingTarget=True,electFocusedDc=False))
add('load',path=str(ref));checkpoint('before')
intake('TEST_ONLY.pack-rations',2)
clock(1759,2) # 56720.5 -> 57600, hero food remains active.
submit('BeginLongRest',target='TEST_ONLY.cleric-long-rest-berth')
clock(1841,2) # 58520.5, hero completes the paid 1800-second intake.
intake('TEST_ONLY.ready-water',4);clock(240)
intake('TEST_ONLY.pack-water',4);clock(240)
checkpoint('provisioned')
clock(54799,2) # 59000.5 -> 86400.
checkpoint('first-rest')
guidance('TEST_ONLY.companion');clock(6)
submit('UseHealingRite',target='TEST_ONLY.actor')
checkpoint('paid-care')
clock(57594);submit('BeginLongRest',target='TEST_ONLY.cleric-long-rest-berth');clock(28800)
checkpoint('second-rest')
clock(57600);submit('BeginLongRest',target='TEST_ONLY.cleric-long-rest-berth');clock(28800)
checkpoint('third-rest')
guidance('TEST_ONLY.companion');clock(6)
submit('CastKnownSpell',target='TEST_ONLY.companion',spellCast=dict(spellId='detect-magic',focusItemId='TEST_ONLY.cleric-casting.holy-symbol',willingTarget=False,electFocusedDc=False))
checkpoint('guidance-detect')
add('submit',id='bishop.one-day.continue',seat='Player',actor='TEST_ONLY.companion',kind='BeginWorldStep',target='walk',x=1,y=0);clock(2)
checkpoint('paid-continuation')
(out/'inputs.jsonl').write_text(''.join(json.dumps(x)+'\n' for x in rows),encoding='utf8')
print(json.dumps({'inputs':len(rows),'output':str(out)}))
