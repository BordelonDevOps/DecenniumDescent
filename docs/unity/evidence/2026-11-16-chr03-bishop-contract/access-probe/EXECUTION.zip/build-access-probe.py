import json
from pathlib import Path

root = Path(__file__).resolve().parent
repo = root.parent / 'github-delivery'
ref = repo / 'docs/unity/evidence/2026-11-15-mgt03-cleric-long-rest/implementation/qualification/trace-terminal/reference/cleric-advanced.ddsave'
out = root / 'access'
out.mkdir(exist_ok=False)
rows=[]
def add(op,**kw): rows.append(dict(op=op,**kw))
def submit(kind,actor='TEST_ONLY.companion',target='',**kw):
    add('submit', id='bishop.access.'+str(len(rows)), seat='Player', actor=actor, kind=kind,target=target,x=0,y=0,**kw)
def clock(n): add('clock',id='bishop.access.clock.'+str(len(rows)),x=n,y=1)
def save(name): add('save',path=str(out/(name+'.ddsave')))
def inventory(n,destination='',handling='Pickup'): return dict(numerator=n,denominator=1,destination=destination,handling=handling)
def denial(name,kind,actor='TEST_ONLY.companion',target='',**kw):
    save(name+'.before');submit(kind,actor,target,**kw);save(name+'.after')
add('load',path=str(ref)); add('view',seat='Player')
add('submit',id='bishop.access.move',seat='Player',actor='TEST_ONLY.companion',kind='BeginWorldStep',target='',x=1,y=0)
clock(2);add('view',seat='Player')
denial('fill-clean-pool','StartWaterFill',target='TEST_ONLY.clean-pool',inventory=inventory(4,'TEST_ONLY.companion-skin'))
denial('drink-pool','StartIntake',target='TEST_ONLY.clean-pool',inventory=inventory(4))
denial('move-pool','HandleInventory',target='TEST_ONLY.clean-pool',inventory=inventory(4))
denial('drink-crop-stock','StartIntake',target='TEST_ONLY.water-pints',inventory=inventory(8))
denial('fill-crop-stock','StartWaterFill',target='TEST_ONLY.water-pints',inventory=inventory(4,'TEST_ONLY.companion-skin'))
denial('pick-pool-portable','HandlePortableEquipment',target='TEST_ONLY.clean-pool',inventory=inventory(1))
denial('hero-rest','BeginRest',actor='TEST_ONLY.actor',target='TEST_ONLY.cleric-long-rest-berth')
denial('hero-long-rest','BeginLongRest',actor='TEST_ONLY.actor',target='TEST_ONLY.cleric-long-rest-berth')
denial('hero-schedule','ScheduleRestWatch',actor='TEST_ONLY.actor',target='day.1')
submit('StartIntake','TEST_ONLY.actor','TEST_ONLY.pack-rations',inventory=inventory(2));clock(1800)
submit('StartIntake','TEST_ONLY.actor','TEST_ONLY.ready-water',inventory=inventory(4));clock(240)
submit('StartIntake','TEST_ONLY.actor','TEST_ONLY.pack-water',inventory=inventory(4));clock(240)
save('after-hero-intake');add('view',seat='Player')
(out/'inputs.jsonl').write_text(''.join(json.dumps(x)+'\n' for x in rows),encoding='utf8')
print(json.dumps({'inputs':len(rows),'output':str(out)}))
