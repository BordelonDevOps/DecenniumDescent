import hashlib,json,subprocess,zipfile
from pathlib import Path

root=Path(__file__).resolve().parent
repo=root.parent/'github-delivery'
packet=repo/'docs/unity/evidence/2026-11-16-chr03-bishop-contract'
dest=packet/'timing-probe'
dest.mkdir(exist_ok=False)
sha=lambda b:hashlib.sha256(b).hexdigest()
def rows(p): return [json.loads(x) for x in p.read_text(encoding='utf-8-sig').splitlines()]
def write(p,o): p.write_bytes((json.dumps(o,indent=2,ensure_ascii=False)+'\n').replace('\n','\r\n').encode())

left=root/'console-uninterrupted'; right=root/'console-restored'
li,lo=rows(left/'inputs.jsonl'),rows(left/'outputs.jsonl')
ri,ro=rows(right/'inputs.jsonl'),rows(right/'outputs.jsonl')
assert len(li)==len(lo)==223 and len(ri)==len(ro)==238
for ins,outs in [(li,lo),(ri,ro)]:
 for q,r in zip(ins,outs):
  expected={'load':'Restored','save':'Saved','clock':'Committed','submit':'Committed'}.get(q['op'])
  if expected: assert r.get('Response')==expected,(q,r)
ln=[r for q,r in zip(li,lo) if q['op']!='load']
rn=[r for q,r in zip(ri,ro) if q['op']!='load']
assert ln==rn and len(ln)==222
assert [r for q,r in zip(li,lo) if q['op']=='view']==[r for q,r in zip(ri,ro) if q['op']=='view']
canonical=[]
for p in sorted(left.rglob('*.ddsave')):
 rel=p.relative_to(left); b=p.read_bytes()
 assert b==(right/rel).read_bytes()
 canonical.append(dict(path=rel.as_posix(),bytes=len(b),sha256=sha(b)))
assert len(canonical)==15
comparison=json.loads((root/'TIMING_COMPARISON.json').read_text())
assert comparison['nonLoadResponseComparisons']==len(ln)
write(dest/'COMPARISON.json',dict(comparison,canonical=canonical))

facts=json.loads((root/'TIMING_FACTS.json').read_text(encoding='utf-8-sig'))
for f in facts: assert sha((root/f['Path']).read_bytes())==f['Sha256']
last=[r for r in lo if r.get('LongRest')][-1]
pressure=dict(revision=last['Revision'],clock=last['Clock'],source='console-uninterrupted/outputs.jsonl: last Player view',
             **{k:last['LongRest'][k] for k in ['DailyProvisioning','WatchOutcomes','DebtHistory','RecoveryOffers']})
write(dest/'PRESSURE_FACTS.json',pressure)

folders=['early-wire111','early-qualified','early-encounter','early-encounter-qualified','console-uninterrupted','console-restored']
members=[]; runs=[]; exclusions=[]
with zipfile.ZipFile(dest/'EXECUTION.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for folder in folders:
  p=root/folder; ins=rows(p/'inputs.jsonl'); outs=rows(p/'outputs.jsonl')
  assert len(ins)==len(outs)
  failures=[dict(inputIndex=i,request=q,response=r) for i,(q,r) in enumerate(zip(ins,outs)) if r.get('Response')=='Unavailable']
  runs.append(dict(name=folder,inputCount=len(ins),responseCount=len(outs),unavailable=failures))
  for f in sorted(p.rglob('*')):
   if not f.is_file():continue
   name=f.relative_to(root).as_posix()
   if f.name in ['read-current.ddsave','read-current.ddsave.bak']:
    exclusions.append(dict(path=name,reason='Overwritten read-only routing cache; no commands or evidence checkpoints omitted.'));continue
   b=f.read_bytes();z.writestr(name,b);members.append(dict(path=name,bytes=len(b),sha256=sha(b)))
 for name in ['build-early-probe.py','Run-EarlyEncounter-attempt1.ps1','Run-EarlyEncounter.ps1','Inspect-TimingFacts.ps1','TIMING_FACTS.json','TIMING_COMPARISON.json','retain-timing-probes.py']:
  b=(root/name).read_bytes();z.writestr(name,b);members.append(dict(path=name,bytes=len(b),sha256=sha(b)))
with zipfile.ZipFile(dest/'EXECUTION.zip') as z:
 assert z.testzip() is None
 for m in members:assert sha(z.read(m['path']))==m['sha256']

revision='6d840c4dfce268115904ea0dda6b475450f7be6f'
paths=['engine/com.decennium.foundation/Laboratory/Model/'+n+'.cs' for n in ['ConnectedExpeditionSession','SharedClericLongRest','SharedRestDebt','SharedDailyProvisioning','SharedPostRecoveryEncounter','SharedSpellCasting','SharedClericSettlement','TestOnlyInventoryPolicy']]
paths+=['engine/tools/Open-ConnectedExpedition.ps1']
pins=[]
for path in paths:
 b=subprocess.check_output(['git','show',revision+':'+path],cwd=repo)
 assert (repo/path).read_bytes()==b
 pins.append(dict(path=path,revision=revision,gitBlob=subprocess.check_output(['git','rev-parse',revision+':'+path],cwd=repo,text=True).strip(),bytes=len(b),sha256=sha(b)))
archive='docs/unity/evidence/2026-11-16-exp07-post-recovery/implementation/qualification-evidence.zip'
binding=json.loads((root/'early-wire111/binding.json').read_text())
with zipfile.ZipFile(repo/archive) as z:
 b=z.read(binding['member']); assert b==(root/'early-wire111/authentic-before-objective.ddsave').read_bytes()
assert sha(b)==binding['sha256']
assemblies=json.loads((packet/'pressure-probe/bindings.json').read_text())['assemblies']
assembly_archive='docs/unity/evidence/2026-11-16-exp07-post-recovery/implementation/execution-assemblies.zip'
frozen=repo/'engine/artifacts/exp07-post-recovery/frozen-build/run-20261116T140712373Z-6d1285d3'
with zipfile.ZipFile(repo/assembly_archive) as z:
 for a in assemblies:
  b=z.read(a['name']); assert b==(frozen/a['name']).read_bytes() and sha(b)==a['sha256']
write(dest/'SOURCE_BINDINGS.json',dict(acceptedEngine=revision,pins=pins,authenticInput=dict(archive=archive,member=binding['member'],bytes=binding['bytes'],sha256=binding['sha256']),assemblies=assemblies,acceptedAssemblyArchive=assembly_archive))
result=dict(status='PASS_EXISTING_ENGINE_TIMING_FEASIBILITY',engineChanged=False,newCompilation=False,newFullRegression=False,bishopRuntimeExecuted=False,indefiniteSurvival=False,
 limitations='Existing wire111/Cleric2 only. Initial own-Start and stance-order attempts fail as retained. Successful combined replay is the route through the actual encounter. No Invocation/Aura/Dispel or earned3 execution.',
 runs=runs,exclusions=exclusions,archive=dict(path='EXECUTION.zip',bytes=(dest/'EXECUTION.zip').stat().st_size,sha256=sha((dest/'EXECUTION.zip').read_bytes()),members=len(members),expandedBytes=sum(m['bytes'] for m in members)),members=members)
write(dest/'RESULTS.json',result)
print(json.dumps(dict(archive=result['archive'],pins=len(pins),canonical=len(canonical),responses=len(ln),runs=[dict(name=r['name'],inputs=r['inputCount'],rejections=len(r['unavailable'])) for r in runs])))
