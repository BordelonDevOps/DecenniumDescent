import json,zipfile,hashlib
from pathlib import Path
root=Path(__file__).resolve().parent;repo=root.parent/'github-delivery'
out=root/'early-wire111';out.mkdir(exist_ok=False)
archive=repo/'docs/unity/evidence/2026-11-16-exp07-post-recovery/implementation/qualification-evidence.zip'
member='qualification/campaigns/main/trace/reference/cleric-before-objective.ddsave'
with zipfile.ZipFile(archive) as z:
 b=z.read(member);(out/'authentic-before-objective.ddsave').write_bytes(b)
 original=[json.loads(x) for x in z.read('qualification/campaigns/main/trace/inputs.jsonl').decode('utf-8-sig').splitlines()]
(out/'binding.json').write_text(json.dumps(dict(archive=str(archive),member=member,bytes=len(b),sha256=hashlib.sha256(b).hexdigest()),indent=2)+'\n')
rows=[dict(op='load',path=str(out/'authentic-before-objective.ddsave'))]+original[264:267]
def add(op,**kw):rows.append(dict(op=op,**kw))
def submit(kind,actor='TEST_ONLY.companion',target='',**kw):
 add('submit',id='bishop.early.'+str(len(rows)),seat='Player',actor=actor,kind=kind,target=target,x=0,y=0,**kw)
def clock(n,d=1):add('clock',id='bishop.early.clock.'+str(len(rows)),x=n,y=d)
def checkpoint(name):add('save',path=str(out/(name+'.ddsave')));add('view',seat='Player')
def intake(target,n):submit('StartIntake','TEST_ONLY.actor',target,inventory=dict(numerator=n,denominator=1,destination='',handling='Pickup'))
def guidance(target):submit('CastKnownSpell',target=target,spellCast=dict(spellId='guidance',focusItemId='',willingTarget=True,electFocusedDc=False))
def step(actor,dx,dy):add('submit',id='bishop.early.step.'+str(len(rows)),seat='Player',actor=actor,kind='BeginWorldStep',target='walk',x=dx,y=dy);clock(1)
checkpoint('earned2')
submit('BeginLongRest',target='TEST_ONLY.cleric-long-rest-berth')
intake('TEST_ONLY.pack-rations',2);clock(1800)
intake('TEST_ONLY.ready-water',4);clock(240)
intake('TEST_ONLY.pack-water',4);clock(240)
step('TEST_ONLY.actor',1,0) # Actual hero (1,2), within touch reach of berth.
checkpoint('provisioned')
clock(26519) # 59001.5 -> 85520.5.
checkpoint('first-rest')
guidance('TEST_ONLY.companion');clock(6)
submit('UseHealingRite',target='TEST_ONLY.actor')
step('TEST_ONLY.companion',1,0);checkpoint('paid-care-departure')
step('TEST_ONLY.companion',-1,0)
clock(57592) # 85528.5 -> 143120.5.
submit('BeginLongRest',target='TEST_ONLY.cleric-long-rest-berth');clock(28800)
checkpoint('second-rest')
clock(57600);submit('BeginLongRest',target='TEST_ONLY.cleric-long-rest-berth');clock(28800)
checkpoint('third-rest')
guidance('TEST_ONLY.actor');clock(6)
submit('CastKnownSpell',target='TEST_ONLY.companion',spellCast=dict(spellId='detect-magic',focusItemId='TEST_ONLY.cleric-casting.holy-symbol',willingTarget=False,electFocusedDc=False))
checkpoint('guidance-detect-living-hero')
add('submit',id='bishop.early.continue',seat='Player',actor='TEST_ONLY.companion',kind='BeginWorldStep',target='walk',x=1,y=0);clock(2)
checkpoint('paid-continuation')
clock(1743,2) # 258328.5 -> 259200. Retain the impending consequences explicitly.
checkpoint('later-pressure-boundary')
(out/'inputs.jsonl').write_text(''.join(json.dumps(x)+'\n' for x in rows),encoding='utf8')
print(json.dumps(dict(inputs=len(rows),output=str(out))))
