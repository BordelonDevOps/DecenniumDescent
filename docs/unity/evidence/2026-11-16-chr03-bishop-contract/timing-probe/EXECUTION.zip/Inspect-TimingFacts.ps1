$ErrorActionPreference='Stop'
$repo=(Resolve-Path (Join-Path $PSScriptRoot '../github-delivery')).Path
foreach($part in 'Core','Persistence','LabModel'){
 Add-Type -Path (Join-Path $repo "engine/artifacts/exp07-post-recovery/frozen-build/run-20261116T140712373Z-6d1285d3/Decennium.Foundation.$part.dll")
}
$factsStore=[Decennium.Foundation.FileSaveStore]::new()
$records=@()
foreach($relative in @('early-qualified/earned2','early-qualified/first-rest','early-qualified/paid-care-departure','early-qualified/second-rest','early-encounter-qualified/entered','early-encounter-qualified/closed','early-encounter-qualified/third-rest','early-encounter-qualified/guidance-detect-living-hero','early-encounter-qualified/continued','early-encounter-qualified/later-pressure-boundary')){
 $path=Join-Path $PSScriptRoot ($relative+'.ddsave')
 $state=$factsStore.Load($path)
 $actors=@()
 foreach($actor in 'TEST_ONLY.actor','TEST_ONLY.companion'){
  $actors += [ordered]@{ActorId=$actor;Life=@($state.Lives | Where-Object ActorId -eq $actor);Position=@($state.Actors | Where-Object Id -eq $actor);Strain=[Decennium.Foundation.Laboratory.ExpeditionStrainRules]::Current($state,$actor);WalkingSpeed=[Decennium.Foundation.Laboratory.TestOnlyClubAttackPolicy]::WalkingSpeed($state,$actor)}
 }
 $records += [ordered]@{Path=$relative+'.ddsave';Sha256=(Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant();Revision=$state.Revision;Clock=$state.RuleClock;InCombat=$state.InventoryCombat;Actors=$actors;ClericRestSettlements=$state.ClericLongRestSettlements;PostRecovery=$state.PostRecoveryEncounter;NewOpponentAttacks=@($state.MeleeAttacks | Where-Object AttackerId -eq 'TEST_ONLY.recovery-defender');NewSpellSaves=@($state.SpellSaves | Where-Object Revision -gt 216);NewFearSaves=@($state.FrightenedSaves | Where-Object Revision -gt 216);HealingRites=$state.HealingRites;SpellEffects=$state.SpellEffects}
}
$records | ConvertTo-Json -Depth 18 -EnumsAsStrings | Set-Content -LiteralPath (Join-Path $PSScriptRoot 'TIMING_FACTS.json') -Encoding utf8
foreach($record in $records){
 [ordered]@{path=$record.Path;at=$record.Clock;actors=@($record.Actors | ForEach-Object { [ordered]@{id=$_.ActorId;hp=$_.Life[0].Hp;dead=$_.Life[0].Dead;strain=$_.Strain.Level;speed=$_.WalkingSpeed} })} | ConvertTo-Json -Depth 5 -Compress
}
