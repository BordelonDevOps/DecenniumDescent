param([string]$OutputName='early-encounter')
$ErrorActionPreference='Stop'
$repo=(Resolve-Path (Join-Path $PSScriptRoot '../github-delivery')).Path
$probeOut=Join-Path $PSScriptRoot $OutputName
if(Test-Path -LiteralPath $probeOut){throw 'Use a fresh output directory'}
New-Item -ItemType Directory -Path $probeOut | Out-Null
$bootstrap=Join-Path $probeOut 'bootstrap.jsonl'
[IO.File]::WriteAllText($bootstrap,'')
. (Join-Path $repo 'engine/tools/Open-ConnectedExpedition.ps1') -AssemblyRoot (Join-Path $repo 'engine/artifacts/exp07-post-recovery/frozen-build/run-20261116T140712373Z-6d1285d3') -PostRecoveryEncounter -InputPath $bootstrap
$probeStore=[Decennium.Foundation.FileSaveStore]::new()
$probeSequence=0
$hero='TEST_ONLY.actor';$companion='TEST_ONLY.companion';$npc='TEST_ONLY.recovery-defender'
function Read-State {
 $scratch=Join-Path $probeOut 'read-current.ddsave'
 $session.Save($scratch)
 return $probeStore.Load($scratch)
}
function Do-Input([hashtable]$request,[switch]$AllowUnavailable) {
 if($request.op -in @('submit','clock','close')) {
  $script:probeSequence++
  $request.id='bishop.timing.encounter.'+$script:probeSequence
  if(!$request.ContainsKey('x')){$request.x=0};if(!$request.ContainsKey('y')){$request.y=0}
 }
 $line=ConvertTo-Json -InputObject $request -Depth 12 -Compress
 [IO.File]::AppendAllText((Join-Path $probeOut 'inputs.jsonl'),$line+"`n")
 $response=Write-SessionResponse $line
 [IO.File]::AppendAllText((Join-Path $probeOut 'outputs.jsonl'),$response+"`n")
 $parsed=ConvertFrom-Json -AsHashtable $response
 if($request.op -in @('submit','clock','close') -and $parsed.Response -ne 'Committed' -and !$AllowUnavailable) {
  throw ('Public command failed: '+$line+' => '+$response)
 }
 return $parsed
}
function Checkpoint([string]$name) {
 $null=Do-Input @{op='save';path=(Join-Path $probeOut ($name+'.ddsave'))}
 $null=Do-Input @{op='view';seat='Player'}
 $null=Do-Input @{op='view';seat='RecoveryOpponent'}
}
function Submit-Action([string]$kind,[string]$actor=$companion,[string]$target='', [hashtable]$extra=@{}) {
 $request=@{op='submit';kind=$kind;actor=$actor;target=$target;seat=$(if($actor -eq $npc){'RecoveryOpponent'}else{'Player'})}
 foreach($key in $extra.Keys){$request[$key]=$extra[$key]}
 $null=Do-Input $request
}
function Advance-By([long]$numerator,[long]$denominator=1) { $null=Do-Input @{op='clock';x=$numerator;y=$denominator} }
function Advance-To($target) {
 $now=(Read-State).RuleClock
 $n=$target.Numerator*$now.Denominator-$now.Numerator*$target.Denominator
 if($n -lt 0){throw 'Cannot reverse time'}
 if($n -gt 0){Advance-By $n ($target.Denominator*$now.Denominator)}
 if((Read-State).RuleClock -ne $target){throw 'Clock yielded before requested target'}
}
function Paid-Step([string]$actor,[int]$dx,[int]$dy) {
 $s=Read-State
 $speed=[Decennium.Foundation.Laboratory.TestOnlyClubAttackPolicy]::WalkingSpeed($s,$actor)
 Submit-Action 'BeginWorldStep' $actor 'walk' @{x=$dx;y=$dy}
 Advance-By 30 $speed
 if(@((Read-State).WorldTraversals).Count -ne 0){throw 'Step did not complete'}
}
function Await-ClericStart {
 $s=Read-State;$epoch=[Decennium.Foundation.WorldTiming]::ForActor($s,$companion);$slot=$epoch.SlotAt($s.RuleClock)
 while($epoch.Order[[int]($slot % $epoch.Order.Count)] -ne $companion -or $epoch.Start($slot) -lt $s.RuleClock){$slot++}
 Advance-To $epoch.Start($slot)
}
function Cast([string]$spell,[string]$target,[bool]$willing) {
 Submit-Action 'CastKnownSpell' $companion $target @{spellCast=@{spellId=$spell;focusItemId=$(if($spell -eq 'guidance'){''}else{'TEST_ONLY.cleric-casting.holy-symbol'});willingTarget=$willing;electFocusedDc=$false}}
}
$null=Do-Input @{op='load';path=(Join-Path $PSScriptRoot 'early-qualified/second-rest.ddsave')}
Checkpoint 'second-rest'
Paid-Step $companion 1 0
Paid-Step $companion 1 0
Paid-Step $companion 0 1
Paid-Step $hero 1 0
Paid-Step $hero 1 0
$s=Read-State;$epoch=$s.Reinforcement.Admission.Phase.Epoch
$speed=[Decennium.Foundation.Laboratory.TestOnlyClubAttackPolicy]::WalkingSpeed($s,$hero)
$duration=[Decennium.Foundation.RuleTime]::new(30,$speed)
$earliest=[Decennium.Foundation.RuleTime]::new(($s.RuleClock.Numerator*$duration.Denominator+$duration.Numerator*$s.RuleClock.Denominator),($s.RuleClock.Denominator*$duration.Denominator))
$slot=$epoch.SlotAt($s.RuleClock)
while($epoch.Order[[int]($slot % $epoch.Order.Count)] -ne 'TEST_ONLY.later-defender' -or $epoch.Start($slot) -lt $earliest){$slot++}
$arrival=$epoch.Start($slot)
$departure=[Decennium.Foundation.RuleTime]::new(($arrival.Numerator*$duration.Denominator-$duration.Numerator*$arrival.Denominator),($arrival.Denominator*$duration.Denominator))
Advance-To $departure
Checkpoint 'before-contact'
Paid-Step $hero 0 1
if(!(Read-State).InventoryCombat){throw 'Actual paid contact did not admit encounter'}
Checkpoint 'entered'
$initial=Read-State
$initialHeroHp=($initial.Lives | Where-Object ActorId -eq $hero).Hp
$initialCompanionHp=($initial.Lives | Where-Object ActorId -eq $companion).Hp
$feared=$false;$detected=$false;$cared=$false;$deathSeen=$false;$postDeathEnds=0
for($turn=0;$turn -lt 100;$turn++) {
 $s=Read-State;$actor=$s.Encounter.CurrentActor;$turnId=$s.Encounter.CurrentTurnId
 $life=$s.Lives | Where-Object ActorId -eq $actor
 $enemy=$s.Lives | Where-Object ActorId -eq $npc
 if($enemy.Dead -and $postDeathEnds -ge 3 -and $actor -ne $npc){
  $close=Do-Input @{op='close';target=$turnId} -AllowUnavailable
  if($close.Response -eq 'Committed'){break}
 }
 if($life.Hp -gt 0 -and !$life.Dead){
  Submit-Action 'SelectCombatStance' $actor '' @{combat=@{turn=$turnId;stance=1}}
  $heroLife=$s.Lives | Where-Object ActorId -eq $hero
  $companionLife=$s.Lives | Where-Object ActorId -eq $companion
  if($actor -eq $npc){
   if(!$feared){Submit-Action 'UseIntimidatingPresence' $npc '' @{intimidatingPresence=@{targets=@($hero,$companion)}};$feared=$true}
   elseif($heroLife.Hp -ge $initialHeroHp){Submit-Action 'AttackClub' $npc $hero @{combat=@{turn=$turnId;weapon='TEST_ONLY.recovery-defender-club'}}}
   elseif($companionLife.Hp -ge $initialCompanionHp){Submit-Action 'AttackClub' $npc $companion @{combat=@{turn=$turnId;weapon='TEST_ONLY.recovery-defender-club'}}}
  } elseif($actor -eq $companion){
   if(!$detected){Cast 'detect-magic' $companion $false;$detected=$true}
   elseif(!$cared -and ($heroLife.Hp -lt $initialHeroHp -or $companionLife.Hp -lt $initialCompanionHp)){
    $patient=if($heroLife.Hp -lt $initialHeroHp){$hero}else{$companion}
    Submit-Action 'UseHealingRite' $companion $patient @{healingRite=@{curePreference='Frightened'}};$cared=$true
    Checkpoint 'paid-care-in-encounter'
   }
  } elseif($actor -eq $hero -and $heroLife.Hp -gt 0 -and !$enemy.Dead -and $feared -and $heroLife.Hp -lt $initialHeroHp -and $companionLife.Hp -lt $initialCompanionHp){
   Submit-Action 'AttackClub' $hero $npc @{combat=@{turn=$turnId;weapon='TEST_ONLY.actor-club'}}
  }
 }
 Submit-Action 'EndRegularTurn' $actor $turnId
 if($enemy.Dead){$postDeathEnds++}
}
if((Read-State).InventoryCombat){throw 'Encounter did not close within bounded probe'}
Checkpoint 'closed'
# Vacate by actual movement and return to the original berth.
Paid-Step $hero -1 0
Paid-Step $hero -1 0
Paid-Step $hero 0 -1
Paid-Step $companion -1 0
Paid-Step $companion -1 0
Paid-Step $companion 0 -1
$s=Read-State
foreach($effect in @($s.SpellEffects | Where-Object { $_.Present -and $_.RequiresConcentration -and $_.CasterId -eq $companion })){
 Submit-Action 'EndSpellConcentration' $companion $effect.Id
}
Checkpoint 'returned'
Advance-To ([Decennium.Foundation.RuleTime]::new(459041,2))
Submit-Action 'BeginLongRest' $companion 'TEST_ONLY.cleric-long-rest-berth'
Advance-By 28800
Checkpoint 'third-rest'
Await-ClericStart
Cast 'guidance' $hero $true
Advance-By 6
Cast 'detect-magic' $companion $false
Checkpoint 'guidance-detect-living-hero'
Paid-Step $companion 1 0
Checkpoint 'continued'
Advance-To ([Decennium.Foundation.RuleTime]::new(259200))
Checkpoint 'later-pressure-boundary'
'Completed existing-engine timing/encounter probe: '+$probeOut
