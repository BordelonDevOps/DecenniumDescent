param([string[]]$CaseNames)
$ErrorActionPreference = 'Stop'
$baseline = Get-Content -LiteralPath (Join-Path $PSScriptRoot 'results.json') -Raw | ConvertFrom-Json
foreach ($name in @('Core','Persistence','LabModel','HeadlessTests')) { Add-Type -Path (Join-Path $PSScriptRoot ("Decennium.Foundation.$name.dll")) }
$record = [ordered]@{status='FAIL'; sourceRun=$PSScriptRoot; startedUtc=[DateTime]::UtcNow.ToString('o'); compilation=$baseline.coreCompilation; sourceHashes=$baseline.sourceHashes; assemblyHashes=@(Get-ChildItem -LiteralPath $PSScriptRoot -Filter '*.dll' | ForEach-Object { @{name=$_.Name; sha256=(Get-FileHash -LiteralPath $_.FullName).Hash.ToLowerInvariant()} }); cases=@()}
$caseRoot = Join-Path $PSScriptRoot ('additional-' + [DateTime]::UtcNow.ToString('yyyyMMddTHHmmssfffZ'))
New-Item -ItemType Directory -Path $caseRoot | Out-Null
foreach ($name in $CaseNames) {
 $caseDirectory = Join-Path $caseRoot $name
 New-Item -ItemType Directory -Path $caseDirectory | Out-Null
 $result = [Decennium.Foundation.Tests.FoundationCases]::Run($name,$caseDirectory)
 $record.cases += $result
 $record | ConvertTo-Json -Depth 12 | Set-Content -LiteralPath (Join-Path $caseRoot 'results.json') -Encoding utf8
 Write-Output ($result | ConvertTo-Json -Compress)
}
$record.status = if (@($record.cases | Where-Object { -not $_.Passed }).Count -eq 0 -and $record.cases.Count -gt 0) {'PASS'} else {'FAIL'}
$record.finishedUtc = [DateTime]::UtcNow.ToString('o')
$record | ConvertTo-Json -Depth 12 | Set-Content -LiteralPath (Join-Path $caseRoot 'results.json') -Encoding utf8
Write-Output ($record.status + ': ' + $caseRoot)
if ($record.status -ne 'PASS') { exit 1 }
