using System;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text.Json;
using Decennium.Foundation;
using Decennium.Foundation.Laboratory;
using Decennium.Foundation.Tests;

public static class OrdinaryRetreatProbe
{
    static object Call(string name, params object[] args) => typeof(FoundationCases).GetMethod(name, BindingFlags.Static | BindingFlags.NonPublic).Invoke(null, args);
    static void Check(bool ok, string why) { if (!ok) throw new Exception(why); }
    static readonly JsonSerializerOptions Json = new JsonSerializerOptions { IncludeFields = true, WriteIndented = true };
    public static void Run(string directory) {
        Directory.CreateDirectory(directory);
        try {
            var genesis = ConnectedExpeditionSession.StartWithOrdinaryMagicalActivity(ClericInitialSelection.AuthoredExample(),
                ClericRepertoireSelection.AuthoredExample(), ClericMilestoneDeclaration.AuthoredExample(), BishopEntryRecord.Announced());
            var policy = (TestOnlySharedWorldPolicy)Call("ClericPolicy", genesis);
            var sim = (Simulation)Call("ReengagementContinued", policy, false, 0, 1, null);
            var outside = sim.Capture();
            Check(outside.OrdinaryMagic != null && !outside.InventoryCombat && outside.Retreat.SuccessfulExit != null, "No genuine116 living retreat");
            var codec = new SnapshotCodec();
            void Save(string name) {
                var state = sim.Capture(); var bytes = codec.Encode(state); var path = Path.Combine(directory, name + ".ddsave");
                new FileSaveStore().Save(path, state);
                var restored = new Simulation(policy, new FileSaveStore().Load(path), ExecutionProfile.Laboratory);
                Check(bytes.SequenceEqual(codec.Encode(restored.Capture())), "Simulation save/restore mismatch " + name);
                File.WriteAllText(Path.Combine(directory, name + ".facts.json"), JsonSerializer.Serialize(new { state.Revision, state.RuleClock, state.OrdinaryMagic, state.Retreat, state.Reengagement, state.WorldIntervals, state.BonusActions }, Json));
                Console.WriteLine("CHECKPOINT " + name + " r" + state.Revision); Console.Out.Flush();
            }
            Save("retreated-outside");
            Call("StageReengagement", sim, false);
            var departure = (RuleTime)Call("ReengagementDepartureAt", sim, null);
            Call("ReengagementWaitTo", sim, departure);
            Save("before-reentry");
            Call("CompleteReengagement", sim);
            var entered = sim.Capture();
            Check(entered.InventoryCombat && entered.Reengagement.Entry != null, "No actual same-epoch reentry");
            var transition = entered.OrdinaryMagic.Transitions.Last();
            Check(transition.FromEpoch == transition.ToEpoch && transition.ToInitiative && transition.AdmissionCarry == null,
                "Reentry invented epoch admission or redundant budget claims");
            Save("reentered");
            Call("EndReinforcementTurn", sim); Save("reentry-continued");
            File.WriteAllText(Path.Combine(directory, "result.json"), JsonSerializer.Serialize(new { status = "PASS", scope = "Fresh116 genuine Simulation API living-retreat/skipped-Start and same-epoch paid reentry; exact snapshot restore. Full ConnectedExpeditionSession path qualification remains separate.", sim.Capture().Revision, sim.Capture().RuleClock }, Json));
        } catch (Exception error) { File.WriteAllText(Path.Combine(directory, "failure.txt"), error.ToString()); throw; }
    }
}
