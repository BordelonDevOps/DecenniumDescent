param([string]$AssemblyRoot,[string]$Run)
$ErrorActionPreference='Stop'
$AssemblyRoot=(Resolve-Path -LiteralPath $AssemblyRoot).Path
$Run=[IO.Path]::GetFullPath($Run)
if(Test-Path -LiteralPath $Run){throw 'Use a fresh output folder.'}
$refs=@(Get-ChildItem -LiteralPath (Join-Path $PSHOME 'ref') -Filter '*.dll'|ForEach-Object FullName)
foreach($part in 'Core','Persistence','LabModel','HeadlessTests'){$dll=Join-Path $AssemblyRoot "Decennium.Foundation.$part.dll";Add-Type -Path $dll;$refs+=$dll}
$null=New-Item -ItemType Directory -Path $Run
$source=Join-Path $PSScriptRoot 'OrdinaryRetreatProbe.cs'
Copy-Item -LiteralPath $source -Destination $Run
Copy-Item -LiteralPath $PSCommandPath -Destination $Run
$report=[ordered]@{status='FAIL';startedUtc=[DateTime]::UtcNow.ToString('o');sourceRun=$AssemblyRoot;sourceSha256=(Get-FileHash -LiteralPath $source).Hash.ToLowerInvariant();assemblyHashes=@(Get-ChildItem -LiteralPath $AssemblyRoot -Filter '*.dll'|ForEach-Object{@{name=$_.Name;sha256=(Get-FileHash -LiteralPath $_.FullName).Hash.ToLowerInvariant()}})}
try{Add-Type -Path $source -ReferencedAssemblies $refs -CompilerOptions @('/langversion:9.0','/warnaserror');[OrdinaryRetreatProbe]::Run($Run);$report.status='PASS'}
catch{$report.error=$_.Exception.ToString()}
finally{$report.finishedUtc=[DateTime]::UtcNow.ToString('o');$report|ConvertTo-Json -Depth 8|Set-Content -LiteralPath (Join-Path $Run 'execution.json');Write-Output ($report.status+': '+$Run)}
if($report.status-ne'PASS'){throw $report.error}
