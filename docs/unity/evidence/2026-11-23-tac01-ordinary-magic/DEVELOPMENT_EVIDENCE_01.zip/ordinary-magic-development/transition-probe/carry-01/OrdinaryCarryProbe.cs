using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using System.Text.Json;
using Decennium.Foundation;
using Decennium.Foundation.Laboratory;

public static partial class OrdinaryTransitionProbe
{
    static void NextLate(ConnectedExpeditionSession session) {
        var s = S(session); var epoch = WorldTiming.ForActor(s, A);
        Advance(session, epoch.Start(epoch.LatestStart(A, epoch.ProcessedSlot) + epoch.Order.Count).AddSeconds(3));
    }
    public static void Carry(string fresh116, string directory) {
        Directory.CreateDirectory(directory); var outcomes = new List<object>();
        try {
            for (int rites = 0; rites <= 3; rites++) {
                var dir = Path.Combine(directory, "rites-" + rites); Directory.CreateDirectory(dir);
                var session = ConnectedExpeditionSession.StartWithOrdinaryMagicalActivity(ClericInitialSelection.AuthoredExample(),
                    ClericRepertoireSelection.AuthoredExample(), ClericMilestoneDeclaration.AuthoredExample(), BishopEntryRecord.Announced());
                session.Restore(fresh116);
                for (int i = 0; i < rites; i++) { NextLate(session); var s = S(session);
                    C(session, new Command("oma.carry.rite." + i, A, s.Revision, CommandKind.UseHealingRite, H)); }
                for (int i = 0; i < 3; i++) { NextLate(session); var s = S(session);
                    C(session, new Command("oma.carry.guidance." + i, A, s.Revision, CommandKind.CastKnownSpell, A,
                        spellCast: new SpellCastRequest("guidance", willingTarget: true))); }
                var before = S(session); Check(before.CastingStrain.Single().Dissonance == 6, "Actual Guidance did not supply D6");
                var epoch = WorldTiming.ForActor(before, A); int speed = (int)TestOnlyClubAttackPolicy.WalkingSpeed(before, H);
                long slot = epoch.SlotAt(before.RuleClock);
                RuleTime Departure(long k) { var at = epoch.Start(k); return new RuleTime(checked(at.Numerator * speed - 30L * at.Denominator), checked(at.Denominator * speed)); }
                while (epoch.Order[(int)(slot % epoch.Order.Count)] != PostRecoveryEncounterDefinition.Actor || Departure(slot) <= before.RuleClock) slot++;
                Advance(session, Departure(slot)); var ready = S(session);
                Check(!ready.OrdinaryMagic.Current.Consumed && ready.CastingStrain.Single().Dissonance == 6, "Approach lost open meaningful strain interval");
                string fork = Path.Combine(dir, "before-ground.ddsave"); session.Save(fork);
                C(session, new Command("oma.carry.ground", A, ready.Revision, CommandKind.GroundCastingStrain));
                var groundOrigin = S(session).OrdinaryMagic.Current.Origin; var deadline = S(session).OrdinaryMagic.Current.Deadline;
                C(session, new Command("oma.carry.contact", H, S(session).Revision, CommandKind.BeginWorldStep, "walk", 0, 1));
                Advance(session, epoch.Start(slot)); var entered = S(session); var admission = entered.FerryWraith.Admission;
                Check(admission != null, "No actual Ferry entry");
                var carry = entered.OrdinaryMagic.Transitions.Last(x => x.FromEpoch != x.ToEpoch);
                Check(carry.Origin.SameAs(groundOrigin) && carry.AdmissionCarry.Interval.ActionSpent, "Actual paid Grounding budget was not carried");
                var firstAt = admission.Epoch.Start(admission.Epoch.Order.ToList().IndexOf(A));
                Save(session, dir, "ground-admitted");
                int guard = 0;
                while (S(session).Encounter.CurrentActor != A && guard++ < 8) { if (session.View(ExpeditionSeat.Player).NextSeat == ExpeditionTurnSeat.FerryOpponent) Auto(session); else End(session); }
                Check(S(session).Encounter.CurrentActor == A, "No first new owner turn");
                var end = S(session).OrdinaryMagic.Settlements.Single(x => x.Origin.SameAs(groundOrigin));
                Check(end.Grounding && !end.MagicalActivity && end.Before == 6 && end.After == 4
                    && end.At == (firstAt < deadline ? firstAt : deadline)
                    && end.Reason == (firstAt < deadline ? MagicalSettlementReason.ReplacementStartPartial : MagicalSettlementReason.OutsideDeadline),
                    "Carried Grounding changed earliest endpoint or stacked reduction");
                Save(session, dir, "ground-replaced");

                // Separate genuine branch with the same paid RNG prefix and an unspent
                // carried Action. A failed early-kill attempt is retained, never edited.
                session = ConnectedExpeditionSession.StartWithOrdinaryMagicalActivity(ClericInitialSelection.AuthoredExample(),
                    ClericRepertoireSelection.AuthoredExample(), ClericMilestoneDeclaration.AuthoredExample(), BishopEntryRecord.Announced());
                session.Restore(fork);
                C(session, new Command("oma.early.contact", H, S(session).Revision, CommandKind.BeginWorldStep, "walk", 0, 1));
                Advance(session, epoch.Start(slot)); var attempt = S(session); string early = "INITIATIVE_ORDER_NOT_HERO_FERRY_CLERIC";
                bool earlySuccess = false;
                if (attempt.FerryWraith.Admission.Epoch.Order.SequenceEqual(new[] { H, FerryWraithProfile.Actor, A })) {
                    C(session, new Command("oma.early.aggressive", H, attempt.Revision, CommandKind.SelectCombatStance,
                        combat: new CombatRequest(attempt.Encounter.CurrentTurnId, stance: (int)CombatStance.Aggressive)));
                    var s = S(session);
                    C(session, new Command("oma.early.step", H, s.Revision, CommandKind.TacticalStep, s.Encounter.CurrentTurnId, 9, 2));
                    s = S(session);
                    C(session, new Command("oma.early.attack", H, s.Revision, CommandKind.AttackClub, FerryWraithProfile.Actor,
                        combat: new CombatRequest(s.Encounter.CurrentTurnId, "TEST_ONLY.actor-club")));
                    s = S(session); early = s.Lives.Single(x => x.ActorId == FerryWraithProfile.Actor).Dead ? "KILLED" : "ACTUAL_OPENING_ATTACK_DID_NOT_KILL";
                    if (early == "KILLED") {
                        C(session, new Command("oma.early.close", H, s.Revision, CommandKind.EndFixedEncounter, s.Encounter.CurrentTurnId)); s = S(session);
                        Check(!s.InventoryCombat && s.OrdinaryMagic.Current.Origin.EpochId == epoch.Id
                            && s.FerryWraith.Admission.Epoch.LatestStart(A, s.FerryWraith.Admission.Epoch.ProcessedSlot) < 0,
                            "Closure already supplied first new owner Start");
                        C(session, new Command("oma.early.carried-guidance", A, s.Revision, CommandKind.CastKnownSpell, A,
                            spellCast: new SpellCastRequest("guidance", willingTarget: true)));
                        earlySuccess = true; early = "GENUINE_CARRIED_OUTSIDE_MAGIC";
                    }
                }
                Save(session, dir, "early-attempt");
                var outcome = new { rites, partial = firstAt < deadline, firstAt, deadline, end, actualOrder = admission.Epoch.Order, early, earlySuccess };
                outcomes.Add(outcome);
                File.WriteAllText(Path.Combine(dir, "result.json"), JsonSerializer.Serialize(outcome, Json));
                Console.WriteLine("CARRY " + rites + " partial=" + (firstAt < deadline) + " early=" + early); Console.Out.Flush();
            }
            File.WriteAllText(Path.Combine(directory, "result.json"), JsonSerializer.Serialize(new { status = "PASS_CARRY_CHECKS_EARLY_WITNESS_REPORTED_SEPARATELY", scope = "Four finite actual paid Rite RNG prefixes, genuine D6 Guidance and paid Grounding; partial/full carry endpoint branches plus unedited early-closure attempts. No arbitrary RNG or resource injection.", outcomes }, Json));
        } catch (Exception error) { File.WriteAllText(Path.Combine(directory, "failure.txt"), error.ToString()); throw; }
    }
}
