param([string]$AssemblyRoot,[string]$Run)
$ErrorActionPreference = 'Stop'
$AssemblyRoot = (Resolve-Path -LiteralPath $AssemblyRoot).Path
$Run = [IO.Path]::GetFullPath($Run)
if (Test-Path -LiteralPath $Run) { throw 'Use a new output directory.' }
$references = @(Get-ChildItem -LiteralPath (Join-Path $PSHOME 'ref') -Filter '*.dll' | ForEach-Object FullName)
foreach ($part in 'Core','Persistence','LabModel','HeadlessTests') {
    $assembly = Join-Path $AssemblyRoot ("Decennium.Foundation.$part.dll")
    Add-Type -Path $assembly
    $references += $assembly
}
$null = New-Item -ItemType Directory -Path $Run
$source = Join-Path $PSScriptRoot 'OrdinaryTransitionProbe.cs'
$report = [ordered]@{ status='FAIL'; startedUtc=[DateTime]::UtcNow.ToString('o'); sourceSha256=(Get-FileHash -LiteralPath $source).Hash.ToLowerInvariant(); sourceRun=$AssemblyRoot; assemblyHashes=@(Get-ChildItem -LiteralPath $AssemblyRoot -Filter '*.dll' | ForEach-Object { @{name=$_.Name;sha256=(Get-FileHash -LiteralPath $_.FullName).Hash.ToLowerInvariant()} }) }
try {
    Add-Type -Path $source -ReferencedAssemblies $references -CompilerOptions @('/langversion:9.0','/warnaserror')
    [OrdinaryTransitionProbe]::Run((Join-Path $PSScriptRoot 'authentic115-before-contact.ddsave'),$Run)
    $report.status='PASS'
} catch { $report.error=$_.Exception.ToString() }
finally { $report.finishedUtc=[DateTime]::UtcNow.ToString('o'); $report | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $Run 'execution.json') -Encoding utf8; Write-Output ($report.status + ': ' + $Run) }
if ($report.status -ne 'PASS') { throw $report.error }
