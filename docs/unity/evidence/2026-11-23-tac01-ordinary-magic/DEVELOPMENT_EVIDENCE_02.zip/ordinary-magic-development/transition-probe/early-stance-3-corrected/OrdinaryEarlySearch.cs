using System;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text.Json;
using Decennium.Foundation;
using Decennium.Foundation.Laboratory;
using Decennium.Foundation.Tests;

public static partial class OrdinaryTransitionProbe
{
    public static bool SearchEarly(int pattern, string directory) {
        Directory.CreateDirectory(directory);
        Func<int, int> stance = round => (int)(pattern <= 3 ? (round < pattern ? CombatStance.Guarded : CombatStance.Aggressive)
            : pattern == 4 ? (round % 2 == 0 ? CombatStance.Aggressive : CombatStance.Guarded)
            : pattern == 5 ? (round % 2 == 0 ? CombatStance.Guarded : CombatStance.Aggressive)
            : pattern == 6 ? CombatStance.Focused : (round == 0 ? CombatStance.Aggressive : CombatStance.Guarded));
        try {
            var initial = ConnectedExpeditionSession.StartWithOrdinaryMagicalActivity(ClericInitialSelection.AuthoredExample(),
                ClericRepertoireSelection.AuthoredExample(), ClericMilestoneDeclaration.AuthoredExample(), BishopEntryRecord.Announced());
            var session = (ConnectedExpeditionSession)typeof(FoundationCases).GetMethod("RunFerryAdmission", BindingFlags.NonPublic | BindingFlags.Static)
                .Invoke(null, new object[] { directory, initial, stance });
            var admitted = S(session); string disposition = "INITIATIVE_ORDER_NOT_HERO_FERRY_CLERIC"; bool success = false;
            if (admitted.FerryWraith.Admission.Epoch.Order.SequenceEqual(new[] { H, FerryWraithProfile.Actor, A })) {
                C(session, new Command("oma.search.aggressive", H, admitted.Revision, CommandKind.SelectCombatStance,
                    combat: new CombatRequest(admitted.Encounter.CurrentTurnId, stance: (int)CombatStance.Aggressive)));
                var s = S(session); C(session, new Command("oma.search.step", H, s.Revision, CommandKind.TacticalStep, s.Encounter.CurrentTurnId, 9, 2));
                s = S(session); C(session, new Command("oma.search.attack", H, s.Revision, CommandKind.AttackClub, FerryWraithProfile.Actor,
                    combat: new CombatRequest(s.Encounter.CurrentTurnId, "TEST_ONLY.actor-club")));
                s = S(session); disposition = "ACTUAL_OPENING_ATTACK_DID_NOT_KILL";
                if (s.Lives.Single(x => x.ActorId == FerryWraithProfile.Actor).Dead) {
                    C(session, new Command("oma.search.close", H, s.Revision, CommandKind.EndFixedEncounter, s.Encounter.CurrentTurnId)); s = S(session);
                    Check(!s.InventoryCombat && s.OrdinaryMagic.Current.Origin.EpochId != s.OrdinaryMagic.Current.ContextEpoch
                        && !s.WorldIntervals.Single(x => x.ActorId == A).ActionSpent, "Closure did not preserve an unrefreshed unspent allowance");
                    Save(session, directory, "before-carried-magic");
                    C(session, new Command("oma.search.carried-guidance", A, s.Revision, CommandKind.CastKnownSpell, A,
                        spellCast: new SpellCastRequest("guidance", willingTarget: true)));
                    var activity = S(session).OrdinaryMagic.Activities.Last();
                    Check(!activity.InInitiative && activity.Origin.EpochId != activity.ContextEpoch, "Outside carried action lost real origin");
                    disposition = "GENUINE_CARRIED_OUTSIDE_MAGIC"; success = true;
                }
            }
            Save(session, directory, "search-outcome");
            File.WriteAllText(Path.Combine(directory, "result.json"), JsonSerializer.Serialize(new { status = success ? "WITNESS_FOUND" : "NO_WITNESS_IN_THIS_BRANCH", pattern,
                scope = "Fresh actual campaign with only legal earlier Hero stance selection varied; no seed, save, resource or receipt editing",
                order = admitted.FerryWraith.Admission.Epoch.Order, admitted.RandomState, disposition, finalRevision = S(session).Revision }, Json));
            return success;
        } catch (Exception error) { File.WriteAllText(Path.Combine(directory, "failure.txt"), error.ToString()); throw; }
    }
}
