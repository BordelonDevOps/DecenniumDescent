using System;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text.Json;
using Decennium.Foundation;
using Decennium.Foundation.Laboratory;
using Decennium.Foundation.Tests;

public static partial class OrdinaryTransitionProbe
{
    const string A = ClericRpProfile.Actor, H = FerryWraithProfile.Hero;
    static readonly JsonSerializerOptions Json = new JsonSerializerOptions { IncludeFields = true, WriteIndented = true };
    static Snapshot S(ConnectedExpeditionSession session) => (Snapshot)typeof(FoundationCases).GetMethod("ShortRestCapture", BindingFlags.Static | BindingFlags.NonPublic).Invoke(null, new object[] { session });
    static void Check(bool ok, string why) { if (!ok) throw new Exception(why); }
    static void C(ConnectedExpeditionSession session, Command command) {
        var result = command.Kind == CommandKind.AdvanceClock || command.Kind == CommandKind.EndFixedEncounter
            ? session.SubmitSessionCommand(command) : session.Submit(ExpeditionSeat.Player, command);
        Check(result.Response == ExpeditionResponse.Committed, command.Id + " / " + result.Response);
    }
    static void Advance(ConnectedExpeditionSession session, RuleTime target) {
        var state = S(session); if (target == state.RuleClock) return;
        Check(target > state.RuleClock, "Clock reversal");
        var delta = new RuleTime(checked(target.Numerator * state.RuleClock.Denominator - state.RuleClock.Numerator * target.Denominator), checked(target.Denominator * state.RuleClock.Denominator));
        C(session, new Command("oma.transition.advance." + state.Revision, H, state.Revision, CommandKind.AdvanceClock, x: checked((int)delta.Numerator), y: checked((int)delta.Denominator)));
        Check(S(session).RuleClock == target, "Advance missed actual target");
    }
    static void Save(ConnectedExpeditionSession session, string dir, string name) {
        var before = new SnapshotCodec().Encode(S(session)); var path = Path.Combine(dir, name + ".ddsave");
        session.Save(path); session.Restore(path);
        Check(before.SequenceEqual(new SnapshotCodec().Encode(S(session))), "Restore mismatch " + name);
        File.WriteAllText(Path.Combine(dir, name + ".facts.json"), JsonSerializer.Serialize(new { S(session).Revision, S(session).RuleClock, S(session).RandomState, S(session).OrdinaryMagic, S(session).AbilityRecharges }, Json));
        Console.WriteLine("CHECKPOINT " + name + " r" + S(session).Revision); Console.Out.Flush();
    }
    static void End(ConnectedExpeditionSession session) {
        var s = S(session);
        if (!TestOnlyClubAttackPolicy.ConditionsFor(s, s.Encounter.CurrentActor).View().Unaware
            && !s.Stances.Any(x => x.TurnOrdinal == s.Encounter.TurnOrdinal && EncounterHistory.InCurrent(s, x.Revision))) {
            C(session, new Command("oma.transition.guard." + s.Revision, s.Encounter.CurrentActor, s.Revision, CommandKind.SelectCombatStance,
                combat: new CombatRequest(s.Encounter.CurrentTurnId, stance: (int)CombatStance.Guarded))); s = S(session);
        }
        C(session, new Command("oma.transition.end." + s.Revision, s.Encounter.CurrentActor, s.Revision, CommandKind.EndRegularTurn, s.Encounter.CurrentTurnId));
    }
    static void Auto(ConnectedExpeditionSession session) {
        int count = 0;
        while (session.View(ExpeditionSeat.Player).NextSeat == ExpeditionTurnSeat.FerryOpponent && count++ < 16)
            Check(session.AdvanceAutomaticDefender().Response == ExpeditionResponse.Committed, "Actual Ferry controller failed");
        Check(count <= 16, "Actual controller exceeded finite bound");
    }
    public static void Run(string predecessor, string directory) {
        Directory.CreateDirectory(directory);
        try {
            var old = new FileSaveStore().Load(predecessor);
            Check(old.WireSchemaVersion == 115 && old.Revision == 344, "Not the retained genuine predecessor command source");
            var session = ConnectedExpeditionSession.StartWithOrdinaryMagicalActivity(ClericInitialSelection.AuthoredExample(),
                ClericRepertoireSelection.AuthoredExample(), ClericMilestoneDeclaration.AuthoredExample(), BishopEntryRecord.Announced());
            foreach (var receipt in old.Receipts) {
                var command = CommandHistory.Read(receipt); ExpeditionActionResult result;
                if (receipt.Principal == "TEST_ONLY.session-operator") result = session.SubmitSessionCommand(command);
                else if (receipt.Principal == "TEST_ONLY.tac10-later-defender.v1") result = session.AdvanceAutomaticDefender();
                else result = session.Submit(receipt.Principal == "TEST_ONLY.session-first-opponent" ? ExpeditionSeat.FirstOpponent
                    : receipt.Principal == "TEST_ONLY.post-recovery-defender.v1" ? ExpeditionSeat.RecoveryOpponent : ExpeditionSeat.Player, command);
                Check(result.Response == ExpeditionResponse.Committed, "Fresh prefix " + receipt.Revision + " / " + command.Id + " / " + result.Response);
                var actual = S(session).Receipts.Last();
                Check(actual.Id == receipt.Id && actual.Principal == receipt.Principal && actual.Fingerprint == receipt.Fingerprint, "Actual command recipe diverged");
                if (receipt.Revision % 50 == 0) { Console.WriteLine("PREFIX " + receipt.Revision); Console.Out.Flush(); }
            }
            Save(session, directory, "fresh116-before-contact");
            var before = S(session); var epoch = WorldTiming.ForActor(before, A);
            long local = epoch.LatestStart(A, epoch.ProcessedSlot);
            while (epoch.Start(local).AddSeconds(3) <= before.RuleClock) local += epoch.Order.Count;
            Advance(session, epoch.Start(local).AddSeconds(3));
            var late = S(session); var origin = late.OrdinaryMagic.Current.Origin;
            C(session, new Command("oma.transition.late-consecrate", A, late.Revision, CommandKind.UseConsecrate, consecrate: new ConsecrateRequest(8, 2)));
            Save(session, directory, "late-paid"); var zone = S(session).Consecration.Zones.Single();
            Check(!zone.InInitiative && zone.ExpiresAt == zone.At.AddSeconds(18), "Late outside expiry not captured");
            // Continue the actual paid approach; its admission and later owner Start are distinct.
            var paid = S(session); int speed = (int)TestOnlyClubAttackPolicy.WalkingSpeed(paid, H); long slot = epoch.SlotAt(paid.RuleClock);
            RuleTime Departure(long k) { var at = epoch.Start(k); return new RuleTime(checked(at.Numerator * speed - 30L * at.Denominator), checked(at.Denominator * speed)); }
            while (epoch.Order[(int)(slot % epoch.Order.Count)] != PostRecoveryEncounterDefinition.Actor || Departure(slot) < paid.RuleClock) slot++;
            Advance(session, Departure(slot)); var departure = S(session);
            C(session, new Command("oma.transition.contact", H, departure.Revision, CommandKind.BeginWorldStep, "walk", 0, 1));
            Advance(session, epoch.Start(slot));
            var entered = S(session); var carry = entered.OrdinaryMagic.Transitions.Last(x => x.FromEpoch != x.ToEpoch);
            Check(entered.FerryWraith.Admission != null && carry.ToEpoch == entered.FerryWraith.Admission.Epoch.Id
                && carry.AdmissionCarry != null && entered.Consecration.Zones.Single().ExpiresAt == zone.ExpiresAt,
                "Actual admission lost carried provenance or moved expiry");
            Save(session, directory, "admitted");
            int rounds = 0;
            while (S(session).Encounter.CurrentActor != A && rounds++ < 8) { if (session.View(ExpeditionSeat.Player).NextSeat == ExpeditionTurnSeat.FerryOpponent) Auto(session); else End(session); }
            Check(S(session).Encounter.CurrentActor == A, "No genuine first new owner Start");
            var first = S(session); var settlement = first.OrdinaryMagic.Settlements.Single(x => x.Origin.SameAs(carry.Origin));
            Check(first.OrdinaryMagic.Current.Origin.EpochId == carry.ToEpoch && settlement.At <= first.RuleClock
                && first.OrdinaryMagic.Settlements.Count(x => x.Origin.SameAs(carry.Origin)) == 1,
                "Carry gained another settlement or lost replacement Start");
            Save(session, directory, "first-owner");
            while (S(session).RuleClock < zone.ExpiresAt && rounds++ < 20) { End(session); Auto(session); }
            Check(S(session).RuleClock >= zone.ExpiresAt && S(session).Consecration.Zones.Single().End == ConsecrationEnd.Expiry
                && S(session).Consecration.Zones.Single().EndAt == zone.ExpiresAt
                && S(session).AbilityRecharges.Single(x => x.AbilityId == ConsecrationProfile.Consecrate).Remaining == 0,
                "Cross-epoch captured expiry or real Start recharge changed");
            Save(session, directory, "expired-continued");
            File.WriteAllText(Path.Combine(directory, "result.json"), JsonSerializer.Serialize(new { status = "PASS", scope = "Fresh116 actual command prefix; post-recovery late Consecrate; genuine paid Ferry contact; origin carry, first Start, expiry/recharge and continued actual combat", prefixCommands = old.Receipts.Length, lateOrigin = origin, admission = carry, settlement, finalRevision = S(session).Revision }, Json));
        } catch (Exception error) { File.WriteAllText(Path.Combine(directory, "failure.txt"), error.ToString()); throw; }
    }
}
