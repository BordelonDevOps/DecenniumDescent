using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using System.Text.Json;
using Decennium.Foundation;
using Decennium.Foundation.Laboratory;

public static partial class OrdinaryTransitionProbe
{
    static void MainNextLate(ConnectedExpeditionSession session) {
        var state = S(session); var epoch = WorldTiming.ForActor(state, A);
        Advance(session, epoch.Start(epoch.LatestStart(A, epoch.ProcessedSlot) + epoch.Order.Count).AddSeconds(3));
    }
    static void MainStance(ConnectedExpeditionSession session, CombatStance stance) {
        var state = S(session);
        if (!TestOnlyClubAttackPolicy.ConditionsFor(state, state.Encounter.CurrentActor).View().Unaware
            && !state.Stances.Any(x => x.TurnOrdinal == state.Encounter.TurnOrdinal && EncounterHistory.InCurrent(state, x.Revision)))
            C(session, new Command("oma.main.stance." + state.Revision, state.Encounter.CurrentActor, state.Revision,
                CommandKind.SelectCombatStance, combat: new CombatRequest(state.Encounter.CurrentTurnId, stance: (int)stance)));
    }
    public static void MainConnected(string fresh116, string directory) {
        Directory.CreateDirectory(directory); var marks = new List<object>();
        try {
            var session = ConnectedExpeditionSession.StartWithOrdinaryMagicalActivity(ClericInitialSelection.AuthoredExample(),
                ClericRepertoireSelection.AuthoredExample(), ClericMilestoneDeclaration.AuthoredExample(), BishopEntryRecord.Announced());
            session.Restore(fresh116);
            void Mark(string name) { Save(session, directory, name); marks.Add(new { name, revision = S(session).Revision }); }
            Mark("source-prefix");
            for (int i = 0; i < 3; i++) {
                MainNextLate(session); var state = S(session);
                C(session, new Command("oma.main.guidance." + i, A, state.Revision, CommandKind.CastKnownSpell, A,
                    spellCast: new SpellCastRequest("guidance", willingTarget: true)));
            }
            Check(S(session).CastingStrain.Single().Dissonance == 6, "Genuine main prefix did not create D6");
            Mark("meaningful-strain");
            MainNextLate(session); var late = S(session); var lateOrigin = late.OrdinaryMagic.Current.Origin;
            Check(!late.OrdinaryMagic.Current.Consumed && late.CastingStrain.Single().Dissonance == 6, "Virtual short End consumed or reduced the late allowance");
            Mark("before-late-consecrate");
            C(session, new Command("oma.main.late-consecrate", A, late.Revision, CommandKind.UseConsecrate, consecrate: new ConsecrateRequest(8, 2)));
            var zone = S(session).Consecration.Zones.Single(); Mark("late-consecrate-paid");
            var paid = S(session); var epoch = WorldTiming.ForActor(paid, A); int speed = (int)TestOnlyClubAttackPolicy.WalkingSpeed(paid, H);
            long slot = epoch.SlotAt(paid.RuleClock);
            RuleTime Departure(long k) { var at = epoch.Start(k); return new RuleTime(checked(at.Numerator * speed - 30L * at.Denominator), checked(at.Denominator * speed)); }
            while (epoch.Order[(int)(slot % epoch.Order.Count)] != PostRecoveryEncounterDefinition.Actor || Departure(slot) < paid.RuleClock) slot++;
            Advance(session, Departure(slot));
            var settled = S(session).OrdinaryMagic.Settlements.Single(x => x.Origin.SameAs(lateOrigin));
            Check(settled.MagicalActivity && settled.Before == 6 && settled.After == 6, "Late Consecrate received retroactive idle decay");
            Mark("settled-before-contact");
            C(session, new Command("oma.main.contact", H, S(session).Revision, CommandKind.BeginWorldStep, "walk", 0, 1));
            Advance(session, epoch.Start(slot)); Check(S(session).FerryWraith.Admission != null, "Main paid contact did not enter Ferry");
            Mark("ferry-admitted");
            int guard = 0;
            while (S(session).Encounter.CurrentActor != A && guard++ < 8) {
                if (session.View(ExpeditionSeat.Player).NextSeat == ExpeditionTurnSeat.FerryOpponent) Auto(session); else End(session);
            }
            Check(S(session).Encounter.CurrentActor == A, "Main first actual owner Start missing");
            MainStance(session, CombatStance.Guarded);
            var grounding = new Command("oma.main.tactical-ground", A, S(session).Revision, CommandKind.GroundCastingStrain);
            Check(session.QueryCastingCommand(ExpeditionSeat.Player, grounding).Admissible, "Main meaningful tactical Grounding unavailable");
            C(session, grounding); Mark("ferry-first-owner-ground");
            End(session); End(session); Auto(session);
            Check(S(session).Encounter.CurrentActor == A && S(session).RuleClock < zone.ExpiresAt, "Main live-terrain Rite missed its actual interval");
            var rite = new Command("oma.main.terrain-rite", A, S(session).Revision, CommandKind.UseHealingRite, H);
            C(session, rite); var healed = S(session);
            var ground = healed.Consecration.Healing.Single(x => x.RiteCommandId == rite.Id);
            Check(healed.HealingRites.Single(x => x.CommandId == rite.Id).ActualGain > 0 && ground.ActualGain > 0,
                "Main Rite did not produce actual positive base and Ground healing");
            Mark("live-terrain-care");
            while (S(session).RuleClock < zone.ExpiresAt && guard++ < 20) { End(session); Auto(session); }
            Check(S(session).Consecration.Zones.Single().End == ConsecrationEnd.Expiry
                && S(session).Consecration.Zones.Single().EndAt == zone.ExpiresAt
                && S(session).AbilityRecharges.Single(x => x.AbilityId == ConsecrationProfile.Consecrate).Remaining == 0,
                "Main original expiry and actual Start recharge failed");
            Mark("terrain-expired-recharged");
            int turns = 0;
            while (S(session).Encounter != null && turns++ < 96) {
                if (session.View(ExpeditionSeat.Player).NextSeat == ExpeditionTurnSeat.FerryOpponent) { Auto(session); continue; }
                var state = S(session); string actor = state.Encounter.CurrentActor;
                var life = state.Lives.Single(x => x.ActorId == actor); var enemy = state.Lives.Single(x => x.ActorId == FerryWraithProfile.Actor);
                if (!life.Dead && life.Hp > 0) {
                    MainStance(session, actor == H ? CombatStance.Aggressive : CombatStance.Guarded); state = S(session);
                    if (enemy.Dead && actor == H) { C(session, new Command("oma.main.close", H, state.Revision, CommandKind.EndFixedEncounter, state.Encounter.CurrentTurnId)); break; }
                    if (!enemy.Dead && actor == H) {
                        var command = new Command("oma.main.attack." + state.Revision, H, state.Revision, CommandKind.AttackClub, FerryWraithProfile.Actor,
                            combat: new CombatRequest(state.Encounter.CurrentTurnId, "TEST_ONLY.actor-club", knockout: AttackKnockoutMode.OrdinaryOutcome,
                                pressInstruction: PressHitInstruction.KeepExisting));
                        Check(session.QueryCastingCommand(ExpeditionSeat.Player, command).Admissible, "Main legal Hero attack unavailable"); C(session, command);
                    } else if (actor == A && state.Lives.Single(x => x.ActorId == H).Hp < 15) {
                        var command = new Command("oma.main.extra-care." + state.Revision, A, state.Revision, CommandKind.UseHealingRite, H);
                        if (session.QueryCastingCommand(ExpeditionSeat.Player, command).Admissible) C(session, command);
                    }
                }
                End(session);
            }
            var closed = S(session);
            Check(closed.Encounter == null && closed.Lives.Single(x => x.ActorId == FerryWraithProfile.Actor).Dead
                && closed.Lives.Where(x => x.ActorId == H || x.ActorId == A).All(x => x.Hp > 0 && !x.Dead), "Main did not reach real Dead closure with both living party members");
            Check(closed.Consecration.Attacks.Any(x => x.Undead && x.Contribution == -1)
                && closed.Consecration.Attacks.Any(x => x.Undead && x.At >= zone.ExpiresAt && x.Contribution == 0), "Missing actual before/after terrain attack effects");
            Mark("ferry-closed");
            MainNextLate(session);
            var prepare = new Command("oma.main.outside-ground", A, S(session).Revision, CommandKind.GroundCastingStrain);
            if (session.QueryCastingCommand(ExpeditionSeat.Player, prepare).Admissible) C(session, prepare);
            Mark("ordinary-prepared");
            var beforeStep = S(session); var body = beforeStep.Actors.Single(x => x.Id == H); int xBefore = body.X;
            speed = (int)TestOnlyClubAttackPolicy.WalkingSpeed(beforeStep, H);
            C(session, new Command("oma.main.continue", H, beforeStep.Revision, CommandKind.BeginWorldStep, "walk", -1, 0));
            C(session, new Command("oma.main.continue-clock", H, S(session).Revision, CommandKind.AdvanceClock, x: 30, y: speed));
            Check(S(session).Actors.Single(x => x.Id == H).X == xBefore - 1 && !S(session).WorldTraversals.Any(x => x.ActorId == H), "Main paid ordinary continuation failed");
            Mark("continued");
            File.WriteAllText(Path.Combine(directory, "checkpoints.json"), JsonSerializer.Serialize(marks, Json));
            File.WriteAllText(Path.Combine(directory, "result.json"), JsonSerializer.Serialize(new { status = "PASS", scope = "Actual fresh116 command lineage through exploration/acquisition/management/earn/rest preparation, nonzero strain, late Consecrate, settlement, paid Ferry contact, real Ground/Claw consumers, fixed expiry/recharge, Dead closure and paid ordinary continuation. Five-path qualification is separate.", source = fresh116, finalRevision = S(session).Revision, turns, zone, ground, marks }, Json));
        } catch (Exception error) { File.WriteAllText(Path.Combine(directory, "failure.txt"), error.ToString()); throw; }
    }
}
