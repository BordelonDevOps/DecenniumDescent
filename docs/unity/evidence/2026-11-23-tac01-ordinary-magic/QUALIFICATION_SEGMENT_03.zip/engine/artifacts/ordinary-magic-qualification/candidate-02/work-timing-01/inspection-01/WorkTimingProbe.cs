using System;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.Text.Json;
using Decennium.Foundation;
using Decennium.Foundation.Laboratory;

public static class WorkTimingProbe
{
    static readonly SnapshotCodec Codec = new SnapshotCodec();
    static readonly JsonSerializerOptions J = new JsonSerializerOptions { IncludeFields = true, WriteIndented = true };
    static readonly Authority Grant = TestOnlySharedWorldPolicy.Host();
    const string Hero = ConnectedExpeditionSession.Hero, Cleric = ClericRpProfile.Actor;
    static string Root;
    static readonly List<object> Rows = new List<object>();
    static string Hash(byte[] bytes) { using (var h = SHA256.Create()) return string.Concat(h.ComputeHash(bytes).Select(x => x.ToString("x2"))); }
    static void Check(bool ok, string why) { if (!ok) throw new Exception(why); }
    static void Write(string name, object value) => File.WriteAllText(Path.Combine(Root, name + ".json"), JsonSerializer.Serialize(value, J));
    static ConnectedExpeditionSession New() => ConnectedExpeditionSession.StartWithOrdinaryMagicalActivity(ClericInitialSelection.AuthoredExample(), ClericRepertoireSelection.AuthoredExample(), ClericMilestoneDeclaration.AuthoredExample(), BishopEntryRecord.Announced());
    static Simulation Sim(ConnectedExpeditionSession session) => (Simulation)typeof(ConnectedExpeditionSession).GetField("simulation", BindingFlags.NonPublic | BindingFlags.Instance).GetValue(session);
    static ConnectedExpeditionSession Restore(string path)
    {
        var session = New(); session.Restore(path);
        Write("input", new { path, sha256 = Hash(File.ReadAllBytes(path)), scope = "Strict restore of unchanged authentic116 source; existing TEST_ONLY Simulation command API. ConnectedExpeditionSession does not expose water filling." });
        return session;
    }
    static object Inventory(Snapshot s) => new {
        s.Revision, clock = s.RuleClock.ToString(), s.InventoryCombat,
        actors = s.Actors.Select(a => new { a.Id, a.X, a.Y }),
        vessels = s.Vessels.Select(v => new { v.Id, profile = v.Profile.ToString(), v.OwnerId, v.LocationId, v.CustodianId, contents = WaterFilling.Contents(s, v.Id).ToString(), free = WaterFilling.FreeCapacity(s, v.Id).ToString() }),
        water = s.InventoryLots.Where(m => m.Nutrition == NutritionKind.WaterPints).Select(m => { var l = s.Work.Lots.Single(x => x.Id == m.LotId); return new { m.LotId, m.OwnerId, access = m.Access.ToString(), l.LocationId, l.CustodianId, amount = l.Amount.ToString(), available = s.Work.AvailableAmount(l.Id).ToString() }; }),
        portable = s.PortableEquipment.Where(x => x.OwnerId == Hero || x.OwnerId == Cleric).Select(x => new { x.Id, x.OwnerId, x.CustodianId, x.LocationId, placement = x.Placement.ToString(), x.Open }),
        fills = s.WaterFills.Select(x => new { x.Id, x.WorkerId, x.SourceLotId, x.DestinationId, progress = x.Progress.ToString(), status = x.Status.ToString() }),
        s.OrdinaryMagic
    };
    public static void Inspect(string dir, string[] args)
    {
        Root = dir; var session = Restore(args[0]); var sim = Sim(session); var s = sim.Capture();
        byte[] before = Codec.Encode(s);
        Write("inventory", Inventory(s));
        Write("discovery", sim.DiscoverCommands(Grant, Hero).Select(x => new { x.Command.Kind, x.Command.Fingerprint, x.Query.Admissible, x.Query.Code }).ToArray());
        Check(before.SequenceEqual(Codec.Encode(sim.Capture())), "Inventory/discovery inspection mutated gameplay");
        Write("result", new { status = "INSPECTED", unchanged = true, s.Revision, sourceSha256 = Hash(File.ReadAllBytes(args[0])) });
    }
}
