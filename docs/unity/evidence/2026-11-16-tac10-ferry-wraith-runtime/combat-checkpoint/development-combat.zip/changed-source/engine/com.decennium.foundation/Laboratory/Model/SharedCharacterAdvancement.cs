#if DECENNIUM_TEST_ONLY && (UNITY_EDITOR || DEVELOPMENT_BUILD || HEADLESS_TESTS)
using System;
using System.Globalization;
using System.Linq;
using System.Security.Cryptography;
using System.Text;

namespace Decennium.Foundation.Laboratory
{
    /// <summary>One explicit Soldier 1 fixture for the source-scoped level-2 advancement path.</summary>
    public sealed class CharacterAdvancementFixture
    {
        public const string DefensivePositioning=CharacterFeatureIds.DefensivePositioning;
        public const string TacticalReposition=CharacterFeatureIds.TacticalReposition;
        public const string SoldierSourceRevision="46a4d52728ee6956f0bebcb5d2103ffd5bc67ba4";
        public ActorLifeRecord HeroLife { get; }
        public bool StartingHitDieSpent { get; }
        public bool HistorySchemaEnabled { get; }
        public bool TacticalAssessmentSchemaEnabled { get; }
        public bool CommandStepSchemaEnabled { get; }
        public bool SuppressionFireSchemaEnabled { get; }
        public bool DefensiveFormationSchemaEnabled { get; }
        public bool LevelFourAdvancementEnabled { get; }
        public System.Collections.Generic.IReadOnlyList<TacticalCoverRecord> Covers { get; }
        public CharacterAdvancementFixture(ActorLifeRecord heroLife=null,params TacticalCoverRecord[] covers)
            :this(heroLife,false,covers)
        { }
        public CharacterAdvancementFixture(ActorLifeRecord heroLife,bool startingHitDieSpent,params TacticalCoverRecord[] covers)
            :this(heroLife,startingHitDieSpent,false,covers)
        { }
        public CharacterAdvancementFixture(ActorLifeRecord heroLife,bool startingHitDieSpent,bool historySchemaEnabled,params TacticalCoverRecord[] covers)
            :this(heroLife,startingHitDieSpent,historySchemaEnabled,false,covers)
        { }
        public CharacterAdvancementFixture(ActorLifeRecord heroLife,bool startingHitDieSpent,bool historySchemaEnabled,
            bool tacticalAssessmentSchemaEnabled,params TacticalCoverRecord[] covers)
            :this(heroLife,startingHitDieSpent,historySchemaEnabled,tacticalAssessmentSchemaEnabled,false,covers)
        { }
        public CharacterAdvancementFixture(ActorLifeRecord heroLife,bool startingHitDieSpent,bool historySchemaEnabled,
            bool tacticalAssessmentSchemaEnabled,bool commandStepSchemaEnabled,params TacticalCoverRecord[] covers)
            :this(heroLife,startingHitDieSpent,historySchemaEnabled,tacticalAssessmentSchemaEnabled,commandStepSchemaEnabled,false,covers)
        { }
        public CharacterAdvancementFixture(ActorLifeRecord heroLife,bool startingHitDieSpent,bool historySchemaEnabled,
            bool tacticalAssessmentSchemaEnabled,bool commandStepSchemaEnabled,bool suppressionFireSchemaEnabled,params TacticalCoverRecord[] covers)
        {
            HeroLife=heroLife??new ActorLifeRecord(TestOnlyPolicy.ActorId,10,4,0,Array.Empty<int>(),false,false,true,0,0,null,0,false,new[]{TestOnlyClubAttackPolicy.ActorClub});
            StartingHitDieSpent=startingHitDieSpent;
            HistorySchemaEnabled=historySchemaEnabled||tacticalAssessmentSchemaEnabled||suppressionFireSchemaEnabled;
            TacticalAssessmentSchemaEnabled=tacticalAssessmentSchemaEnabled;
            CommandStepSchemaEnabled=commandStepSchemaEnabled;
            SuppressionFireSchemaEnabled=suppressionFireSchemaEnabled;
            var rows=covers??Array.Empty<TacticalCoverRecord>();
            if(HeroLife.ActorId!=TestOnlyPolicy.ActorId||HeroLife.MaximumHp!=10||!HeroLife.HeldItems.SequenceEqual(new[]{TestOnlyClubAttackPolicy.ActorClub},StringComparer.Ordinal)
                ||rows.Length>64||rows.Any(x=>x==null)
                ||rows.Select(x=>x.Id).Distinct(StringComparer.Ordinal).Count()!=rows.Length||rows.Select(x=>x.X+","+x.Y).Distinct(StringComparer.Ordinal).Count()!=rows.Length)
                throw new ArgumentException("The advancement fixture requires the named Soldier's ten-point level-1 capacity, held Club custody, and unique cover markers.");
            Covers=Array.AsReadOnly(rows.ToArray());
        }
        public CharacterAdvancementFixture(ActorLifeRecord heroLife,bool startingHitDieSpent,bool historySchemaEnabled,
            bool tacticalAssessmentSchemaEnabled,bool commandStepSchemaEnabled,bool suppressionFireSchemaEnabled,
            bool defensiveFormationSchemaEnabled,params TacticalCoverRecord[] covers)
            :this(heroLife,startingHitDieSpent,historySchemaEnabled,tacticalAssessmentSchemaEnabled,commandStepSchemaEnabled,
                suppressionFireSchemaEnabled,defensiveFormationSchemaEnabled,false,covers)
        { }
        public CharacterAdvancementFixture(ActorLifeRecord heroLife,bool startingHitDieSpent,bool historySchemaEnabled,
            bool tacticalAssessmentSchemaEnabled,bool commandStepSchemaEnabled,bool suppressionFireSchemaEnabled,
            bool defensiveFormationSchemaEnabled,bool levelFourAdvancementEnabled,params TacticalCoverRecord[] covers)
            :this(heroLife,startingHitDieSpent,historySchemaEnabled,tacticalAssessmentSchemaEnabled,commandStepSchemaEnabled,suppressionFireSchemaEnabled,covers)
        {
            DefensiveFormationSchemaEnabled=defensiveFormationSchemaEnabled;
            LevelFourAdvancementEnabled=levelFourAdvancementEnabled;
            if(defensiveFormationSchemaEnabled)HistorySchemaEnabled=true;
            if(levelFourAdvancementEnabled)HistorySchemaEnabled=true;
        }
        internal string Key=>"soldier-1-to-2-v1|milestone-only|fixed-average-d10-base-6|prior-hit-die-spent="+(StartingHitDieSpent?"1":"0")
            +"|advancement-history-schema30="+(HistorySchemaEnabled?"1":"0")
            +(TacticalAssessmentSchemaEnabled?"|tactical-assessment-schema31=1":"")
            +(CommandStepSchemaEnabled?"|command-step-schema32=1":"")
            +(SuppressionFireSchemaEnabled?"|suppression-fire-schema33=1":"")
            +(DefensiveFormationSchemaEnabled?"|defensive-formation-schema34=1":"")
            +(LevelFourAdvancementEnabled?"|shared-character-advancement-schema61=1":"")+"|"+string.Join("|",new[]{HeroLife.ActorId,
            HeroLife.MaximumHp.ToString(CultureInfo.InvariantCulture),HeroLife.Hp.ToString(CultureInfo.InvariantCulture),HeroLife.TemporaryHp.ToString(CultureInfo.InvariantCulture),
            string.Join(",",HeroLife.LinkedInjuries),HeroLife.Stable?"1":"0",HeroLife.Dead?"1":"0",HeroLife.UsesDeathSaves?"1":"0",
            HeroLife.DeathSuccesses.ToString(CultureInfo.InvariantCulture),HeroLife.DeathFailures.ToString(CultureInfo.InvariantCulture),HeroLife.StableUntil?.ToString()??"none",
            HeroLife.LastDeathTurn.ToString(CultureInfo.InvariantCulture),HeroLife.Prone?"1":"0",string.Join(",",HeroLife.HeldItems),
            string.Join(";",Covers.OrderBy(x=>x.Id,StringComparer.Ordinal).Select(x=>x.Id+":"+x.X.ToString(CultureInfo.InvariantCulture)+","+x.Y.ToString(CultureInfo.InvariantCulture)))});
        internal const string SourceReferences="46a4d52728ee6956f0bebcb5d2103ffd5bc67ba4:DescentReviewChanges/ReviewBible/docs/mechanics/CHARACTER_CREATION_PLAYTEST.md@04c77b3ddff460219600df2f28bac27d854647af#sha256=5c9f9ab4c9b485546a249637a335f56193dd3d58e58c451f9561c4e330c09a84;"
            +"46a4d52728ee6956f0bebcb5d2103ffd5bc67ba4:DescentReviewChanges/ReviewBible/docs/mechanics/CLASS_PLAYTEST_RULES.md@5a446dd0dabae096e51f419b5e71756e0169bb3b#sha256=adb2f4752b45dc70ce792a675bb30dda362aab5056588061bcde3ba31c4c8a81;"
            +"46a4d52728ee6956f0bebcb5d2103ffd5bc67ba4:DescentReviewChanges/ReviewBible/data/public/class_playtests/manifest.json@c7f68a17b5b38cfc6ab7ce6022eae80ae635b890#sha256=41c044ad787394f0b52a0bf8ec7bb7f4a923c7cbec9a553423fa78c64947c20d;"
            +"46a4d52728ee6956f0bebcb5d2103ffd5bc67ba4:DescentReviewChanges/ReviewBible/data/public/class_playtests/soldier.json@c414a1d9ba2ce37cde89d0ef73265821bb74ac2d#sha256=ab9cd3bd64355166dceb5a09e1ddab98443a957bb4bcdce813f1ad294ec048f0;"
            +"46a4d52728ee6956f0bebcb5d2103ffd5bc67ba4:DescentReviewChanges/ReviewBible/data/playtest/character_foundation.json@88fad6737419c7053d262bdf747fad80fd20f1c4#sha256=21e12af81f191abe52d1e3272ed1f57c6446ed3d4487cafbd5609dff08e56a77;"
            +"46a4d52728ee6956f0bebcb5d2103ffd5bc67ba4:DescentReviewChanges/ReviewBible/docs/mechanics/XP_ADVANCEMENT_CANON.md@f16bbdf4f352aaccf8e8548e2b993ef338e9c05d#sha256=f9c92adc2444f37bf0cabc0baabce4e37ab58781f0959bdce178c2266c8ebf01;"
            +"Engine:docs/unity/CHARACTER_ADVANCEMENT_RULE_DECISIONS.md@3a8cdfcf83072f02a9b08fa457d354e42f4ac12b#sha256=6a53f8cfb9ac6e197c38b4b73c082f36bfbc8f4791893e8ca0abd97b8f3d41e9";
        internal string BindFingerprint(string prior)
        {
            using(var sha=SHA256.Create())return "TEST_ONLY.soldier-v1-"+string.Concat(sha.ComputeHash(Encoding.UTF8.GetBytes(prior+"|"+Key
                +"|sources="+SourceReferences))
                .Select(b=>b.ToString("x2",CultureInfo.InvariantCulture)));
        }
    }

    /// <summary>Opt-in schema24 foundation for the Soldier's automatic Overwatch entitlement and the shared Bonus Action ledger.</summary>
    public sealed class OverwatchFoundationFixture
    {
        public const string SoldierSourceRevision="46a4d52728ee6956f0bebcb5d2103ffd5bc67ba4";
        internal const string SourceReferences="46a4d52728ee6956f0bebcb5d2103ffd5bc67ba4:DescentReviewChanges/ReviewBible/data/public/class_playtests/soldier.json@c414a1d9ba2ce37cde89d0ef73265821bb74ac2d#sha256=ab9cd3bd64355166dceb5a09e1ddab98443a957bb4bcdce813f1ad294ec048f0#/engine/1;/schedule/0;/cards/0;"
            +"46a4d52728ee6956f0bebcb5d2103ffd5bc67ba4:DescentReviewChanges/ReviewBible/docs/mechanics/CLASS_PLAYTEST_RULES.md@5a446dd0dabae096e51f419b5e71756e0169bb3b#sha256=adb2f4752b45dc70ce792a675bb30dda362aab5056588061bcde3ba31c4c8a81;"
            +"Engine:docs/unity/BONUS_ACTION_RULE_DECISIONS.md@e54af34ed3ab7b72a5b051b8b1f92218707e12c3#sha256=825feecd8ec0f7c58a4ab03fadc267ad4554883b9351880a0a16ed60aa1972604";
        internal string BindFingerprint(string prior)
        {
            using(var sha=SHA256.Create())return "TEST_ONLY.overwatch-v1-"+string.Concat(sha.ComputeHash(Encoding.UTF8.GetBytes(prior+
                "|schema24-shared-bonus-action|automatic-base-overwatch-not-a-selection|sources="+SourceReferences))
                .Select(b=>b.ToString("x2",CultureInfo.InvariantCulture)));
        }
    }

    /// <summary>Source-pinned Soldier Level 1 card selection. This fixture records ownership;
    /// cards without connected handlers remain unavailable as actions.</summary>
    public sealed class SoldierInitialLoadoutFixture
    {
        public const string SourceRevision="46a4d52728ee6956f0bebcb5d2103ffd5bc67ba4";
        public const string DecisionDocumentReference="Engine:docs/unity/SOLDIER_LEVEL1_LOADOUT_RULE_DECISIONS.md@bd5c83aba5e684362cdf624846531e7c91db7f06#sha256=1731730f5dfbb776deb13ea3b577e2ef7ccb695b349551a0c569f2931767abad";
        private static readonly string[] SelectedCards={CharacterFeatureIds.WarningShot,CharacterFeatureIds.TacticalReposition,
            CharacterFeatureIds.ShieldTrained,CharacterFeatureIds.CoveringFire};
        public System.Collections.Generic.IReadOnlyList<string> SelectedFeatureIds=>Array.AsReadOnly(SelectedCards.ToArray());
        internal string Key=>"soldier-level1-initial-card-selection-v1|source="+SourceRevision+"|choices="+
            string.Join(",",SelectedCards.OrderBy(x=>x,StringComparer.Ordinal))+"|decisions="+DecisionDocumentReference;
        internal string BindFingerprint(string prior)
        {
            using(var sha=SHA256.Create())return "TEST_ONLY.soldier-loadout-v1-"+string.Concat(sha.ComputeHash(Encoding.UTF8.GetBytes(prior+"|"+Key))
                .Select(b=>b.ToString("x2",CultureInfo.InvariantCulture)));
        }
    }

    /// <summary>A source-bounded character-build fixture. These are explicit player choices,
    /// not a default standard array, ancestry, background, or class-wide creation flow.</summary>
    public sealed class SoldierCharacterBuildFixture
    {
        public const string SourceRevision="46a4d52728ee6956f0bebcb5d2103ffd5bc67ba4";
        private readonly string[] selectedSkillIds;
        public System.Collections.Generic.IReadOnlyList<string> SelectedSkillIds=>Array.AsReadOnly(selectedSkillIds.ToArray());
        public int InitialCurrentHp { get; }
        public bool TacticalTechniquesEnabled { get; }
        public SoldierCharacterBuildFixture(string[] selectedSkillIds=null,int initialCurrentHp=10)
            :this(selectedSkillIds,initialCurrentHp,false)
        { }
        private SoldierCharacterBuildFixture(string[] selectedSkillIds,int initialCurrentHp,bool tacticalTechniquesEnabled)
        {
            var skills=selectedSkillIds??new[]{"athletics","perception"};
            var allowed=new[]{"athletics","intimidation","perception","survival"};
            if(skills.Length!=2||skills.Any(x=>!allowed.Contains(x,StringComparer.Ordinal))
                ||skills.Distinct(StringComparer.Ordinal).Count()!=2||initialCurrentHp<1||initialCurrentHp>10)
                throw new ArgumentException("Invalid Soldier starting skill or current-HP fixture fact.");
            this.selectedSkillIds=skills.OrderBy(x=>x,StringComparer.Ordinal).ToArray();InitialCurrentHp=initialCurrentHp;
            TacticalTechniquesEnabled=tacticalTechniquesEnabled;
        }
        public static SoldierCharacterBuildFixture ForTacticalTechniques(string[] selectedSkillIds=null,int initialCurrentHp=10)
            =>new SoldierCharacterBuildFixture(selectedSkillIds,initialCurrentHp,true);
        internal string Key=>"soldier-level1-build-v1|optional-point-buy=12-of-27|abilities=10,10,10,10,10,10|skills="
            +string.Join(",",selectedSkillIds)+"|saves=CON,STR|hp="+InitialCurrentHp.ToString(CultureInfo.InvariantCulture)
            +"|kit=chain-mail+repeating-crossbow+20-bolts+dagger+shield+dungeoneer-pack|pack-ground=0,0|"
            +"pack-fit=inside-rations20+pitons2.5+tinder1+skin1+water4;attached-crowbar5+hammer3+torches10+rope10"
            +"|decisions="+SoldierInitialLoadoutFixture.DecisionDocumentReference
            +"|equipment=DescentReviewChanges/ReviewBible/data/playtest/equipment_acquisition_candidate.json@4037e188edb890c971acb39e8679cfd5a142b0042508af30c95d4703d2a2745b"
            +"|creation=DescentReviewChanges/ReviewBible/docs/mechanics/CHARACTER_CREATION_PLAYTEST.md@5c9f9ab4c9b485546a249637a335f56193dd3d58e58c451f9561c4e330c09a84"
            +(TacticalTechniquesEnabled?"|tactical-techniques-schema29":"");
        internal string BindFingerprint(string prior)
        {
            using(var sha=SHA256.Create())return "TEST_ONLY.soldier-build-v1-"+string.Concat(sha.ComputeHash(Encoding.UTF8.GetBytes(prior+"|"+Key))
                .Select(b=>b.ToString("x2",CultureInfo.InvariantCulture)));
        }
    }

    public static class CharacterAdvancementRules
    {
        private sealed class AdvancementAssessment
        {
            public bool AwardMilestone;
            public ActorCharacterRecord Character;
            public string MilestoneId;
            public int NewClassLevel;
            public string[] Features;
            public CharacterAbility[] AbilityIncreases;
            public int[] AbilitiesBefore;
            public int[] AbilitiesAfter;
            public ActorLifeRecord Life;
            public long MaximumHpBefore;
            public long MaximumHpAfter;
            public long CurrentHpAfter;
            public int LastRegularStart;
            public CharacterFeatureRuntimeRecord PriorRuntime;
        }
        private static bool EmptyCommand(Command c)=>c.Inventory==null&&c.Combat==null&&c.X==0&&c.Y==0;
        private static string FeatureOne(string a,string b)=>string.CompareOrdinal(a,b)<0?a:b;
        private static string FeatureTwo(string a,string b)=>string.CompareOrdinal(a,b)<0?b:a;
        internal static bool Busy(Snapshot s,string actor)
            =>s.WorldTraversals.Any(x=>x.ActorId==actor)
                ||s.Crops.SelectMany(x=>x.Tasks).Any(x=>x.WorkerId==actor&&x.Status==CropWorkStatus.Working)
                ||s.FormulaWork.Any(x=>x.WorkerId==actor&&x.Status==FormulaWorkStatus.Working)
                ||s.WaterFills.Any(x=>x.WorkerId==actor&&x.Status==WaterFillStatus.Working)
                ||s.Intakes.Any(x=>x.ActorId==actor&&x.Status==IntakeStatus.Working)
                ||s.RepairWork.Any(x=>x.WorkerId==actor&&x.Status==RepairWorkStatus.Working)
                ||s.ManufacturingOrders.Any(x=>x.WorkerId==actor&&x.Status==ManufacturingStatus.Working)
                ||s.SupplyCacheAttempts.Any(x=>x.ActorId==actor&&x.Status==SupplyCacheAttemptStatus.Working);
        private static void SetRuntime(Snapshot s,CharacterFeatureRuntimeRecord value)
            =>s.CharacterFeatureRuntime=s.CharacterFeatureRuntime.Select(x=>x.ActorId==value.ActorId?value:x).ToArray();
        private static CharacterFeatureRuntimeRecord Runtime(Snapshot s,string actor)
            =>s.CharacterFeatureRuntime.SingleOrDefault(x=>x.ActorId==actor);
        internal static bool BonusActionAvailable(Snapshot s,string actor)
        {
            if(s.SchemaVersion>=Snapshot.SharedBonusActionSchema)return s.BonusActions.SingleOrDefault(x=>x.ActorId==actor)?.Available==true;
            return Runtime(s,actor)?.BonusActionAvailable==true;
        }
        internal static bool SpendBonusAction(Snapshot s,string actor)
        {
            if(!BonusActionAvailable(s,actor))return false;
            if(s.SchemaVersion>=Snapshot.SharedBonusActionSchema) {
                s.BonusActions=s.BonusActions.Select(x=>x.ActorId==actor?x.Spend():x).ToArray();
            }
            var runtime=Runtime(s,actor);if(runtime!=null)SetRuntime(s,runtime.WithBonusActionAvailable(false));
            return true;
        }
        internal static void RegularStart(Snapshot s,string actor,int ordinal)
        {
            RefreshNamedAbilityRecharge(s, actor, ordinal);
            var stationarity=s.ShieldStationarity.SingleOrDefault(x=>x.ActorId==actor);
            if(stationarity!=null&&ordinal>stationarity.LastRegularStart)
                s.ShieldStationarity=s.ShieldStationarity.Select(x=>x.ActorId==actor?x.RegularStart(ordinal):x).ToArray();
            if(s.SchemaVersion>=Snapshot.SharedBonusActionSchema) {
                var budget=s.BonusActions.SingleOrDefault(x=>x.ActorId==actor);
                if(budget!=null&&ordinal>budget.LastRegularStart)
                    s.BonusActions=s.BonusActions.Select(x=>x.ActorId==actor?x.RegularStart(ordinal):x).ToArray();
            }
            var before=Runtime(s,actor);if(before==null||ordinal<=before.LastRegularStart)return;
            int elapsedStarts=1;
            if(s.SchemaVersion>=Snapshot.SoldierTacticalTechniquesSchema&&s.WorldSchedule!=null) {
                int rosterSize=s.WorldSchedule.Order.Count;
                int actorIndex=Array.IndexOf(s.WorldSchedule.Order.ToArray(),actor);
                if(actorIndex<0)throw new InvalidOperationException("Feature owner has no regular schedule slot.");
                elapsedStarts=before.LastRegularStart<0
                    ?checked((ordinal-actorIndex)/rosterSize+1)
                    :checked((ordinal-before.LastRegularStart)/rosterSize);
                if(elapsedStarts<1)throw new InvalidOperationException("Feature recharge start count is inconsistent with the world schedule.");
            }
            SetRuntime(s,before.RegularStart(ordinal,elapsedStarts));
        }
        private static void RefreshNamedAbilityRecharge(Snapshot state, string actor, int globalStart)
        {
            var owned = state.AbilityRecharges.Where(x => x.ActorId == actor).ToArray();
            if (owned.Length == 0) return;
            var epoch = WorldTiming.ForActor(state, actor);
            var phase = state.Reinforcement?.Admission?.Phase;
            long local = epoch.Id == phase?.Epoch.Id ? globalStart - (long)phase.FirstTurn : globalStart;
            if (local < 0 || epoch.LatestStart(actor, local) != local)
                throw new InvalidOperationException("Named ability recharge has no matching owner start.");
            foreach(var before in owned) {
                bool transfer=epoch.Id!=before.EpochId;
                if(transfer && (state.BishopEntry==null||before.AbilityId!=BishopProfile.Invocation||!PostRecoveryProfile.IsEpoch(state,epoch.Id)))
                    throw new InvalidOperationException("Named ability recharge has no matching epoch.");
                if(!transfer && local<=before.LastLocalStart)continue;
                // Admission itself gives no tick. The first actual owner Start in the new epoch does.
                long elapsed=transfer?1:(local-before.LastLocalStart)/epoch.Order.Count;
                if(elapsed<1)throw new InvalidOperationException("Named ability recharge cadence is inconsistent.");
                int remaining=checked((int)Math.Max(0,before.Remaining-elapsed));
                var after=new CharacterAbilityRechargeRecord(actor,before.AbilityId,epoch.Id,local,epoch.Start(local),remaining);
                state.AbilityRecharges=state.AbilityRecharges.Select(x=>x==before?after:x).ToArray();
            }
        }
        internal static void MarkMoved(Snapshot s,string actor)
        {
            var before=s.ShieldStationarity.SingleOrDefault(x=>x.ActorId==actor);
            if(before!=null&&!before.MovedSinceRegularStart)
                s.ShieldStationarity=s.ShieldStationarity.Select(x=>x.ActorId==actor?x.MarkMoved():x).ToArray();
        }
        internal static int ArmorClass(Snapshot s,string actor,int dexterity)
        {
            var creature=s.Creatures.SingleOrDefault(x=>x.ActorId==actor);
            if(creature!=null)return creature.ArmorClass;
            int ac=checked((int)PrototypeArmor.UnarmoredBaseAc(dexterity));
            var armor=s.PortableEquipment.SingleOrDefault(x=>x.CustodianId==actor&&x.ParentId==""
                &&x.Placement==PortablePlacement.Worn&&x.ProfileId=="armor-and-shields.chain-mail");
            if(armor!=null)ac=16;
            bool shield=s.PortableEquipment.Any(x=>x.CustodianId==actor&&x.ParentId==""&&x.Placement==PortablePlacement.Worn
                &&x.ProfileId=="armor-and-shields.shield");
            if(shield)ac=checked(ac+2);
            return ac;
        }
        internal static int ArmorStrengthSpeedPenalty(Snapshot s,string actor)
        {
            var armor=s.PortableEquipment.SingleOrDefault(x=>x.CustodianId==actor&&x.ParentId==""
                &&x.Placement==PortablePlacement.Worn&&x.ProfileId=="armor-and-shields.chain-mail");
            return armor!=null&&CharacterRuleFacts.ForActor(s,actor).AbilityScore(CharacterAbility.Strength)<13?10:0;
        }
        internal static bool ShieldOccupiesHand(Snapshot s,string actor)
            =>s.PortableEquipment.Any(x=>x.CustodianId==actor&&x.ParentId==""&&x.Placement==PortablePlacement.Worn
                &&x.ProfileId=="armor-and-shields.shield");
        internal static bool ShieldTrainedCrossbowException(Snapshot s,string actor)
        {
            var loadout=s.InitialCharacterLoadouts.SingleOrDefault(x=>x.ActorId==actor);
            return loadout!=null&&s.CharacterFeatureGrants.Any(x=>x.ActorId==actor&&x.FeatureId==CharacterFeatureIds.ShieldTrained)
                &&s.PortableEquipment.Any(x=>x.Id==loadout.ShieldId&&x.CustodianId==actor&&x.ParentId==""
                    &&x.Placement==PortablePlacement.Worn&&x.ProfileId=="armor-and-shields.shield");
        }
        internal static bool OwnsDefensiveFormation(Snapshot s,string actor)
            =>s.CharacterFeatureGrants.Any(x=>x.ActorId==actor&&x.FeatureId==CharacterFeatureIds.DefensiveFormation
                &&x.ClassName=="Soldier"&&x.Origin==CharacterFeatureGrantOrigin.SelectedCard
                &&(x.ClassLevel==3||x.ClassLevel==4&&s.SchemaVersion>=Snapshot.SharedCharacterAdvancementSchema));
        internal static int SaveProficiencyBonus(Snapshot s,string actor,string abilityId)
        {
            if(s.ConnectedClericRp&&s.ClericEntry?.ActorId==actor&&s.ClericEntry.SavingThrows.Contains(abilityId,StringComparer.Ordinal))
                return CharacterRuleFacts.ForActor(s,actor).ProficiencyBonus;
            var loadout=s.InitialCharacterLoadouts.SingleOrDefault(x=>x.ActorId==actor);
            if(loadout==null||!loadout.SavingThrowProficiencyIds.Contains(abilityId,StringComparer.Ordinal))return 0;
            return CharacterRuleFacts.ForActor(s,actor).ProficiencyBonus;
        }
        public static long ReduceIncomingDamage(Snapshot s,string actor,long amount)
        {
            if(amount<0)throw new ArgumentOutOfRangeException(nameof(amount));
            var loadout=s.InitialCharacterLoadouts.SingleOrDefault(x=>x.ActorId==actor);
            bool wearingShield=loadout!=null&&s.CharacterFeatureGrants.Any(x=>x.ActorId==actor&&x.FeatureId==CharacterFeatureIds.ShieldTrained)
                &&s.ShieldStationarity.SingleOrDefault(x=>x.ActorId==actor)?.MovedSinceRegularStart==false
                &&s.PortableEquipment.Any(x=>x.Id==loadout.ShieldId&&x.CustodianId==actor&&x.ParentId==""&&x.Placement==PortablePlacement.Worn);
            var target=s.Actors.SingleOrDefault(x=>x.Id==actor);
            bool formation=s.SchemaVersion>=Snapshot.DefensiveFormationSchema&&target!=null&&s.DefensiveFormations
                .Where(x=>x.Active).Any(x=> {
                    var recipients=x.Shifts.Select(y=>y.RecipientActorId).ToArray();
                    return recipients.Contains(actor,StringComparer.Ordinal)&&recipients.Where(id=>id!=actor).Any(id=> {
                        var partner=s.Actors.SingleOrDefault(a=>a.Id==id);
                        return partner!=null&&PlanarCombatGeometry.DistanceFeet(new CombatCell(target.X,target.Y),new CombatCell(partner.X,partner.Y))==5;
                    });
                });
            return amount>0&&(wearingShield||formation)?amount-1:amount;
        }
        internal static void TacticalExit(Snapshot s)
            =>s.CharacterFeatureRuntime=s.CharacterFeatureRuntime.Select(x=>x.RepositionTurnOrdinal>=0?x.EndTacticalUse():x).ToArray();
        internal static void EndRegularTurn(Snapshot s,string actor,int ordinal)
        {
            var state=Runtime(s,actor);if(state!=null&&state.RepositionTurnOrdinal==ordinal)SetRuntime(s,state.EndTacticalUse());
        }
        internal static string ActivateTacticalReposition(Snapshot s,Command c)
        {
            if(!s.InventoryCombat||s.Encounter==null)return "TacticalRepositionRequiresCombat";
            if(c.Target!=s.Encounter.CurrentTurnId||c.X!=0||c.Y!=0||c.Inventory!=null||c.Combat!=null||c.Advancement!=null)return "InvalidTacticalReposition";
            if(c.Actor!=s.Encounter.CurrentActor)return "WrongRegularTurn";
            if(!ActorLifeRules.CanAct(s,c.Actor))return "ActorCannotAct";
            if(!s.CharacterFeatureGrants.Any(x=>x.ActorId==c.Actor&&x.FeatureId==CharacterAdvancementFixture.TacticalReposition))return "FeatureNotOwned";
            var runtime=Runtime(s,c.Actor);if(runtime==null)return "FeatureRuntimeUnavailable";
            var life=s.Lives.Single(x=>x.ActorId==c.Actor);long speed=TestOnlyClubAttackPolicy.WalkingSpeed(s,c.Actor);
            if(speed==0)return "ZeroSpeedCannotMove";
            if(s.SchemaVersion>=Snapshot.ConditionSchema) {
                var view=TestOnlyClubAttackPolicy.ConditionsFor(s,c.Actor).View();
                if(view.Unaware||!view.PermissionsForLife(ActorLifeRules.Read(life)).VoluntarySpeed)return "ConditionPreventsMovement";
            }
            if(!BonusActionAvailable(s,c.Actor))return "BonusActionUnavailable";
            if(runtime.RepositionRechargeRemaining>0)return "TacticalRepositionRecharging";
            if(s.TacticalMoves.Length>=64)return "ContinuationCapacityReached";
            try {
                if(s.SchemaVersion>=Snapshot.SharedBonusActionSchema&&!SpendBonusAction(s,c.Actor))return "BonusActionUnavailable";
                SetRuntime(s,runtime.Activate(s.Encounter.TurnOrdinal,speed/2));return null;
            }
            catch(ArgumentException){return "TacticalRepositionUnavailable";}
        }
        internal static long RepositionBudget(Snapshot s,string actor,int turnOrdinal)
        {
            var state=Runtime(s,actor);return state!=null&&state.RepositionTurnOrdinal==turnOrdinal?state.RepositionBudgetRemaining:0;
        }
        internal static void SpendReposition(Snapshot s,string actor,long cost)
        {
            var state=Runtime(s,actor)??throw new ArgumentException("FeatureRuntimeUnavailable");SetRuntime(s,state.SpendReposition(cost));
        }
        public static int DefensivePositioningBonus(Snapshot s,string actor)
        {
            if(!s.CharacterFeatureGrants.Any(x=>x.ActorId==actor&&x.FeatureId==CharacterAdvancementFixture.DefensivePositioning))return 0;
            var body=s.Actors.Single(x=>x.Id==actor);
            return s.TacticalCovers.Any(x=>PlanarCombatGeometry.DistanceFeet(new CombatCell(body.X,body.Y),new CombatCell(x.X,x.Y))==5)?1:0;
        }
        private static bool ActiveOption(ClassAdvancementOption option)
            =>(option.KindProperty=="sourceKind"&&option.Kind=="active")
                ||option.Activation.StartsWith("Action",StringComparison.Ordinal)
                ||option.Activation.StartsWith("Bonus Action",StringComparison.Ordinal)
                ||option.Activation.StartsWith("Reaction",StringComparison.Ordinal)
                ||option.Activation.StartsWith("Ritual",StringComparison.Ordinal);

        private static bool HasExecutableSoldierFeatureHandler(string featureId)
            =>featureId==CharacterFeatureIds.DefensiveFormation;

        private static string AssessRowChoices(Snapshot s,ActorCharacterRecord character,CharacterAdvancementRequest request,
            int classLevel,System.Collections.Generic.IEnumerable<string> previouslySelectedAdvancementFeatures,out string[] features)
        {
            features=Array.Empty<string>();
            var schedule=ClassAdvancementScheduleCatalog.Get("Soldier",classLevel);
            if(schedule==null)return "ClassScheduleUnavailable";
            if(schedule.Kind==ClassAdvancementScheduleKind.NarrativeException)return "ClassScheduleNeedsBinding";
            if(!schedule.RequiredSelections.HasValue||!schedule.MinimumActiveSelections.HasValue||!schedule.HasAsiOrFeatOpportunity.HasValue)
                return "ClassScheduleNeedsBinding";
            var automatic=ClassAdvancementOptionCatalog.Options.Where(x=>x.ClassName=="Soldier"
                &&x.Acquisition=="automatic"&&x.MinimumClassLevel==classLevel).ToArray();
            if(automatic.Length!=0)return "ClassRowOperationsUnbound";
            if(classLevel==4&&s.SchemaVersion<Snapshot.SharedCharacterAdvancementSchema)return "ClassRowOperationsUnbound";
            if(request.FeatureIds.Count!=schedule.RequiredSelections.Value
                ||request.FeatureIds.Any(x=>x=="")||request.FeatureIds.Distinct(StringComparer.Ordinal).Count()!=request.FeatureIds.Count)
                return "IncompleteFeatureSelection";
            var requestedFeatures=request.FeatureIds.ToArray();
            features=requestedFeatures.OrderBy(x=>x,StringComparer.Ordinal).ToArray();
            var candidates=ClassAdvancementOptionCatalog.Candidates(schedule);
            var options=features.Select(x=>ClassAdvancementOptionCatalog.Get("Soldier",x)).ToArray();
            if(options.Any(x=>x==null||!candidates.Contains(x)))return "FeatureOutsideClassSchedule";
            if(options.Any(x=>x.HasPathConstraint||x.HasDeclaredPrerequisite))return "FeaturePrerequisiteBindingRequired";
            int activeSelections=options.Count(ActiveOption);
            if(activeSelections<schedule.MinimumActiveSelections)return "ActiveSelectionRequirementNotMet";
            if(features.Any(feature=>previouslySelectedAdvancementFeatures.Contains(feature,StringComparer.Ordinal)))return "FeatureAlreadyOwned";
            if(classLevel==4&&features.Any(feature=>!HasExecutableSoldierFeatureHandler(feature)))return "ClassRowOperationUnbound";
            bool hasAsi=schedule.HasAsiOrFeatOpportunity.Value;
            if(request.FeatId!="")return hasAsi?"ClassRowOperationUnbound":"UnexpectedAdvancementOperation";
            if(hasAsi&&request.AsiAbilityIncreases.Count!=2)return "IncompleteAbilityScoreIncrease";
            if(!hasAsi&&request.AsiAbilityIncreases.Count!=0)return "UnexpectedAdvancementOperation";
            if(!hasAsi&&request.FeatId!="")return "UnexpectedAdvancementOperation";
            bool levelTwo=classLevel==2&&character.Levels.Count==1&&schedule.RequiredSelections==2
                &&schedule.Bands.SequenceEqual(new[]{"Base"},StringComparer.Ordinal)
                &&features.SequenceEqual(new[]{CharacterAdvancementFixture.DefensivePositioning,CharacterAdvancementFixture.TacticalReposition}
                    .OrderBy(x=>x,StringComparer.Ordinal),StringComparer.Ordinal);
            bool levelThreeFirst=classLevel==3&&character.Levels.Count==2&&s.SchemaVersion>=Snapshot.CommandStepSchema
                &&schedule.Bands.SequenceEqual(new[]{"Arch"},StringComparer.Ordinal)
                &&features.SequenceEqual(new[]{CharacterFeatureIds.CommandStep,CharacterFeatureIds.TacticalAssessment}
                    .OrderBy(x=>x,StringComparer.Ordinal),StringComparer.Ordinal);
            bool levelThreeSecond=classLevel==3&&character.Levels.Count==2&&s.SchemaVersion>=Snapshot.SuppressionFireSchema
                &&schedule.Bands.SequenceEqual(new[]{"Arch"},StringComparer.Ordinal)
                &&features.SequenceEqual(new[]{CharacterFeatureIds.SuppressionFire,CharacterFeatureIds.TacticalAssessment}
                    .OrderBy(x=>x,StringComparer.Ordinal),StringComparer.Ordinal);
            bool levelThreeThird=classLevel==3&&character.Levels.Count==2&&s.SchemaVersion>=Snapshot.DefensiveFormationSchema
                &&schedule.Bands.SequenceEqual(new[]{"Arch"},StringComparer.Ordinal)
                &&features.SequenceEqual(new[]{CharacterFeatureIds.CommandStep,CharacterFeatureIds.DefensiveFormation}
                    .OrderBy(x=>x,StringComparer.Ordinal),StringComparer.Ordinal);
            bool levelFour=classLevel==4&&s.SchemaVersion>=Snapshot.SharedCharacterAdvancementSchema
                &&schedule.RequiredSelections==1&&schedule.Bands.SequenceEqual(new[]{"Base","Arch"},StringComparer.Ordinal)
                &&schedule.HasAsiOrFeatOpportunity==true;
            if(!levelTwo&&!levelThreeFirst&&!levelThreeSecond&&!levelThreeThird&&!levelFour)
                return "LegalFeatureChoiceNotImplemented";
            return null;
        }

        private static string Assess(Snapshot s,Command c,out AdvancementAssessment assessment)
        {
            assessment=null;
            if(s.SchemaVersion!=Snapshot.CharacterAdvancementSchema&&s.SchemaVersion<Snapshot.SharedBonusActionSchema)return "CharacterAdvancementUnsupported";
            if(!EmptyCommand(c))return "InvalidAdvancementCommand";
            var character=s.Characters.SingleOrDefault(x=>x.ActorId==c.Actor);
            if(character==null)return "CharacterNotFound";
            bool supportedProfile=character.ProfileId==CharacterAdvancementProfileIds.TestOnlySoldierLevel1
                ||s.SchemaVersion>=Snapshot.SoldierInitialBuildSchema&&character.ProfileId==CharacterAdvancementProfileIds.TestOnlySoldierLevel1InitialBuild;
            if(!supportedProfile)return "UnsupportedAdvancementPath";
            if(character.Levels.Count<1||character.Levels.Count>=20||character.Levels.Any(x=>x.ClassName!="Soldier"))return "UnsupportedAdvancementPath";
            if(c.Kind==CommandKind.AwardCharacterMilestone) {
                if(c.Advancement!=null||c.Target=="")return "InvalidMilestoneAward";
                if(s.CharacterMilestones.Any(x=>x.ActorId==c.Actor&&x.MilestoneId==c.Target))return "MilestoneAlreadyAwarded";
                if(s.CharacterMilestones.Length>=256)return "MilestoneCapacityReached";
                assessment=new AdvancementAssessment{AwardMilestone=true,Character=character,MilestoneId=c.Target};
                return null;
            }
            if(c.Kind!=CommandKind.AdvanceCharacterLevel||c.Advancement==null||c.Target=="")return "CharacterAdvancementCommandNotImplemented";
            var entitlement=s.CharacterMilestones.SingleOrDefault(x=>x.ActorId==c.Actor&&x.MilestoneId==c.Target);
            if(entitlement==null)return "MilestoneNotAvailable";
            if(entitlement.ConsumedRevision!=0)return "MilestoneAlreadyConsumed";
            if(s.InventoryCombat)return "TacticalControlActive";
            if(TestOnlySharedWorldPolicy.PendingCalendarChoice(s))return "TacticalChoicePending";
            if(s.ManufacturingAdvance!=null)return "ManufacturingChoicePending";
            if(Busy(s,c.Actor))return "CharacterBusy";
            int nextClassLevel=character.Levels.Count+1;
            var request=c.Advancement;
            string rowError=AssessRowChoices(s,character,request,nextClassLevel,
                s.CharacterAdvancements.Where(x=>x.ActorId==c.Actor).SelectMany(x=>x.SelectedFeatureIds),out var features);
            if(rowError!=null)return rowError;
            if(s.CharacterAdvancements.Length>=128||s.CharacterFeatureGrants.Length+features.Length>256||s.CharacterHitDice.Length>=1280)return "AdvancementCapacityReached";
            var dice=s.CharacterHitDice.Where(x=>x.ActorId==c.Actor).OrderBy(x=>x.LevelOrdinal).ToArray();
            if(dice.Length!=nextClassLevel-1||dice.Where((x,i)=>x.LevelOrdinal!=i+1||x.ClassName!="Soldier"||x.DieSize!=10).Any())
                return "HitDieLedgerMismatch";
            var life=s.Lives.Single(x=>x.ActorId==c.Actor);
            int[] abilitiesBefore=character.Abilities.ToArray();int[] abilitiesAfter=abilitiesBefore.ToArray();
            foreach(var ability in request.AsiAbilityIncreases) {
                int index=(int)ability;
                if(abilitiesAfter[index]>=20)return "AbilityScoreCapExceeded";
                abilitiesAfter[index]=checked(abilitiesAfter[index]+1);
            }
            var previousLevels=character.Levels.Select(x=>new CharacterLevelRecord(x.ClassName,x.BaseHp)).ToArray();
            var levels=character.Levels.Concat(new[]{new CharacterLevelFact("Soldier",6)}).ToArray();
            long maximumBefore=PlaytestCharacters.BaseMaximumHp(previousLevels,abilitiesBefore[(int)CharacterAbility.Constitution]).BaseMaximum;
            if(life.MaximumHp!=maximumBefore)return "AdvancementHealthBasisMismatch";
            long maximumAfter=PlaytestCharacters.BaseMaximumHp(levels.Select(x=>new CharacterLevelRecord(x.ClassName,x.BaseHp)).ToArray(),
                abilitiesAfter[(int)CharacterAbility.Constitution]).BaseMaximum;
            long currentAfter=PlaytestCharacters.ClampAfterCapacityChange(life.Hp,maximumAfter);
            var priorRuntime=Runtime(s,c.Actor);
            int lastStart=checked((int)s.WorldIntervals.Single(x=>x.ActorId==c.Actor).LastStart);
            if(priorRuntime!=null&&priorRuntime.LastRegularStart!=lastStart)return "FeatureRuntimeStartMismatch";
            assessment=new AdvancementAssessment{Character=character,MilestoneId=c.Target,NewClassLevel=nextClassLevel,Features=features,
                AbilityIncreases=request.AsiAbilityIncreases.ToArray(),AbilitiesBefore=abilitiesBefore,AbilitiesAfter=abilitiesAfter,Life=life,
                MaximumHpBefore=maximumBefore,MaximumHpAfter=maximumAfter,CurrentHpAfter=currentAfter,LastRegularStart=lastStart,PriorRuntime=priorRuntime};
            return null;
        }

        internal static string Assess(Snapshot s,Command c)=>Assess(s,c,out _);

        internal static ActorCharacterRecord AtRevision(Snapshot s,string actorId,long revision)
        {
            if(s==null)throw new ArgumentNullException(nameof(s));
            if(revision<0||revision>s.Revision)throw new ArgumentOutOfRangeException(nameof(revision));
            var character=s.Characters.SingleOrDefault(x=>x.ActorId==actorId)
                ??throw new ArgumentException("CharacterNotFound",nameof(actorId));
            var events=s.CharacterAdvancements.Where(x=>x.ActorId==actorId).OrderByDescending(x=>x.Revision).ToArray();
            int[] scores=character.Abilities.ToArray();
            foreach(var advancement in events.Where(x=>x.Revision>revision&&x.AsiAbilityIncreases.Count!=0)) {
                if(!advancement.AbilityScoresAfter.SequenceEqual(scores))throw new ArgumentException("InvalidAbilityHistory",nameof(s));
                scores=advancement.AbilityScoresBefore.ToArray();
            }
            int totalLevel=1+s.CharacterAdvancements.Count(x=>x.ActorId==actorId&&x.Revision<=revision);
            if(totalLevel>character.Levels.Count)throw new ArgumentException("InvalidAdvancementHistory",nameof(s));
            return new ActorCharacterRecord(character.ActorId,character.ProfileId,scores,character.Levels.Take(totalLevel));
        }

        internal static string ValidateHistorical(Snapshot s)
        {
            if(s.SchemaVersion<Snapshot.SharedCharacterAdvancementSchema)return null;
            foreach(string actorId in s.CharacterAdvancements.Select(x=>x.ActorId).Distinct(StringComparer.Ordinal)) {
                var actor=s.Characters.SingleOrDefault(x=>x.ActorId==actorId);
                var events=s.CharacterAdvancements.Where(x=>x.ActorId==actorId).OrderBy(x=>x.Revision).ToArray();
                if(actor==null||events.Length==0)return "InvalidAdvancementHistory";
                if(s.ConnectedClericSettlement&&actorId==ClericRpProfile.Actor) {
                    if(events.Length!=(BishopProfile.Earned(s)?2:1)||!ClericSettlementProfile.ValidAdvancement(s,events[0])
                        ||events[0].ClassLevel!=2||events.Length==2&&!BishopProfile.ValidAdvancement(s,events[1]))
                        return "InvalidClericAdvancementHistory";
                    continue;
                }
                int[] scores={10,10,10,10,10,10};
                int level=1;
                foreach(var advancement in events) {
                    var receipt=s.Receipts.SingleOrDefault(x=>x.Revision==advancement.Revision);
                    if(receipt==null)return "AdvancementReceiptMissing";
                    Command command;
                    try { command=CommandHistory.Read(receipt); }
                    catch(ArgumentException) { return "InvalidAdvancementReceipt"; }
                    if(command.Kind!=CommandKind.AdvanceCharacterLevel||command.Actor!=actorId||command.Target!=advancement.MilestoneId
                        ||command.Advancement==null||command.Advancement.FeatId!=""
                        ||!command.Advancement.FeatureIds.SequenceEqual(advancement.SelectedFeatureIds)
                        ||!command.Advancement.AsiAbilityIncreases.SequenceEqual(advancement.AsiAbilityIncreases))
                        return "AdvancementReceiptMismatch";
                    if(advancement.PreviousTotalLevel!=level||advancement.NewTotalLevel!=level+1
                        ||advancement.ClassName!="Soldier"||advancement.ClassLevel!=level+1
                        ||actor.Levels.Count<=level||actor.Levels[level].ClassName!="Soldier"
                        ||actor.Levels[level].BaseHp!=6)return "InvalidAdvancementChronology";
                    if(advancement.AsiAbilityIncreases.Count!=0&&!advancement.AbilityScoresBefore.SequenceEqual(scores))
                        return "InvalidAbilityScoreHistory";
                    var nextScores=scores.ToArray();
                    foreach(var ability in advancement.AsiAbilityIncreases) {
                        int index=(int)ability;
                        if(nextScores[index]>=20)return "AbilityScoreCapExceeded";
                        nextScores[index]++;
                    }
                    if(advancement.AsiAbilityIncreases.Count!=0&&!advancement.AbilityScoresAfter.SequenceEqual(nextScores))
                        return "InvalidAbilityScoreHistory";
                    var priorSelections=s.CharacterAdvancements.Where(x=>x.ActorId==actorId&&x.Revision<advancement.Revision)
                        .SelectMany(x=>x.SelectedFeatureIds).ToArray();
                    var historicalCharacter=new ActorCharacterRecord(actorId,actor.ProfileId,scores,
                        actor.Levels.Take(level));
                    var request=new CharacterAdvancementRequest(advancement.SelectedFeatureIds.ToArray(),
                        advancement.AsiAbilityIncreases.ToArray());
                    string rowError=AssessRowChoices(s,historicalCharacter,request,level+1,priorSelections,out var selected);
                    if(rowError!=null||!selected.SequenceEqual(advancement.SelectedFeatureIds))return "InvalidAdvancementSourceRow";
                    var priorLevels=actor.Levels.Take(level).Select(x=>new CharacterLevelRecord(x.ClassName,x.BaseHp)).ToArray();
                    var nextLevels=actor.Levels.Take(level+1).Select(x=>new CharacterLevelRecord(x.ClassName,x.BaseHp)).ToArray();
                    long expectedBefore=PlaytestCharacters.BaseMaximumHp(priorLevels,scores[(int)CharacterAbility.Constitution]).BaseMaximum;
                    long expectedAfter=PlaytestCharacters.BaseMaximumHp(nextLevels,nextScores[(int)CharacterAbility.Constitution]).BaseMaximum;
                    if(advancement.MaximumHpBefore!=expectedBefore||advancement.MaximumHpAfter!=expectedAfter
                        ||advancement.CurrentHpBefore>expectedBefore
                        ||advancement.CurrentHpAfter!=PlaytestCharacters.ClampAfterCapacityChange(advancement.CurrentHpBefore,expectedAfter))
                        return "InvalidAdvancementHealthHistory";
                    scores=nextScores;level++;
                }
                if(level!=actor.Levels.Count||!scores.SequenceEqual(actor.Abilities))return "InvalidAbilityScoreHistory";
                long expectedMaximum=PlaytestCharacters.BaseMaximumHp(actor.Levels.Select(x=>new CharacterLevelRecord(x.ClassName,x.BaseHp)).ToArray(),
                    actor.Abilities[(int)CharacterAbility.Constitution]).BaseMaximum;
                if(s.Lives.Single(x=>x.ActorId==actorId).MaximumHp!=expectedMaximum)return "InvalidAdvancementHealthHistory";
            }
            return null;
        }

        internal static System.Collections.Generic.IEnumerable<Command> Discover(Snapshot s,string actor)
        {
            if(s==null||!Validation.ValidId(actor))yield break;
            var character=s.Characters.SingleOrDefault(x=>x.ActorId==actor);
            if(character==null||character.Levels.Count<1||character.Levels.Count>=20)yield break;
            int next=character.Levels.Count+1;
            var milestones=s.CharacterMilestones.Where(x=>x.ActorId==actor&&x.ConsumedRevision==0)
                .OrderBy(x=>x.AwardedRevision).ThenBy(x=>x.MilestoneId,StringComparer.Ordinal).ToArray();
            if(milestones.Length==0)yield break;
            string[][] boundSelections=next==2
                ?new[]{new[]{CharacterAdvancementFixture.DefensivePositioning,CharacterAdvancementFixture.TacticalReposition}}
                :next==3
                    ?new[]{new[]{CharacterFeatureIds.CommandStep,CharacterFeatureIds.TacticalAssessment},
                        new[]{CharacterFeatureIds.SuppressionFire,CharacterFeatureIds.TacticalAssessment},
                        new[]{CharacterFeatureIds.CommandStep,CharacterFeatureIds.DefensiveFormation}}
                    :next==4?ClassAdvancementOptionCatalog.Candidates(ClassAdvancementScheduleCatalog.Get("Soldier",4))
                        .Where(x=>HasExecutableSoldierFeatureHandler(x.Id)).Select(x=>new[]{x.Id}).ToArray():Array.Empty<string[]>();
            int index=0;
            foreach(var milestone in milestones)
                foreach(var features in boundSelections)
                    if(next==4) {
                        for(int first=0;first<6;first++)for(int second=first;second<6;second++) {
                            var increases=new[]{(CharacterAbility)first,(CharacterAbility)second};
                            var request=new CharacterAdvancementRequest(features,increases);
                            var command=new Command("option."+s.Revision.ToString(CultureInfo.InvariantCulture)+".advancement."+
                                (index++).ToString(CultureInfo.InvariantCulture),actor,s.Revision,CommandKind.AdvanceCharacterLevel,
                                milestone.MilestoneId,advancement:request);
                            if(Assess(s,command)==null)yield return command;
                        }
                    } else {
                        var request=new CharacterAdvancementRequest(features);
                        var command=new Command("option."+s.Revision.ToString(CultureInfo.InvariantCulture)+".advancement."+
                            (index++).ToString(CultureInfo.InvariantCulture),actor,s.Revision,CommandKind.AdvanceCharacterLevel,
                            milestone.MilestoneId,advancement:request);
                        if(Assess(s,command)==null)yield return command;
                    }
        }

        public static string Resolve(Snapshot s,Command c)
        {
            string failure=Assess(s,c,out var assessment);if(failure!=null)return failure;
            if(assessment.AwardMilestone) {
                s.CharacterMilestones=s.CharacterMilestones.Concat(new[]{new CharacterMilestoneRecord(assessment.MilestoneId,c.Actor,s.Revision+1)}).ToArray();
                return null;
            }
            var character=assessment.Character;int level=assessment.NewClassLevel;var life=assessment.Life;
            var levels=character.Levels.Concat(new[]{new CharacterLevelFact("Soldier",6)}).ToArray();
            // No resource or life transition is attached to a capacity increase.
            s.Characters=s.Characters.Select(x=>x.ActorId==c.Actor?new ActorCharacterRecord(x.ActorId,x.ProfileId,assessment.AbilitiesAfter,levels):x).ToArray();
            s.Lives=s.Lives.Select(x=>x.ActorId==c.Actor?new ActorLifeRecord(x.ActorId,assessment.MaximumHpAfter,assessment.CurrentHpAfter,x.TemporaryHp,x.LinkedInjuries,
                x.Stable,x.Dead,x.UsesDeathSaves,x.DeathSuccesses,x.DeathFailures,x.StableUntil,x.LastDeathTurn,x.Prone,x.HeldItems):x).ToArray();
            s.CharacterMilestones=s.CharacterMilestones.Select(x=>x.ActorId==c.Actor&&x.MilestoneId==c.Target?x.Consume(s.Revision+1):x).ToArray();
            s.CharacterHitDice=s.CharacterHitDice.Concat(new[]{new CharacterHitDieRecord(c.Actor,level,"Soldier",10,false)}).ToArray();
            s.CharacterFeatureGrants=s.CharacterFeatureGrants.Concat(assessment.Features.Select(feature=>
                new CharacterFeatureGrantRecord(c.Actor,feature,"Soldier",level,c.Target,s.Revision+1))).ToArray();
            bool bonusActionAvailable=s.SchemaVersion>=Snapshot.SharedBonusActionSchema?BonusActionAvailable(s,c.Actor):true;
            var refreshedRuntime=assessment.PriorRuntime==null?new CharacterFeatureRuntimeRecord(c.Actor,assessment.LastRegularStart,bonusActionAvailable)
                :assessment.PriorRuntime.WithBonusActionAvailable(bonusActionAvailable);
            if(assessment.PriorRuntime==null)s.CharacterFeatureRuntime=s.CharacterFeatureRuntime.Concat(new[]{refreshedRuntime}).ToArray();
            else s.CharacterFeatureRuntime=s.CharacterFeatureRuntime.Select(x=>x.ActorId==c.Actor?refreshedRuntime:x).ToArray();
            s.CharacterAdvancements=s.CharacterAdvancements.Concat(new[]{new CharacterAdvancementRecord(c.Actor,c.Target,s.Revision+1,level-1,level,"Soldier",level,6,
                HitPointGainMethod.FixedAverage,assessment.MaximumHpBefore,assessment.MaximumHpAfter,life.Hp,assessment.CurrentHpAfter,
                assessment.Features,assessment.AbilityIncreases,
                assessment.AbilityIncreases.Length==0?Array.Empty<int>():assessment.AbilitiesBefore,
                assessment.AbilityIncreases.Length==0?Array.Empty<int>():assessment.AbilitiesAfter)}).ToArray();
            return null;
        }
    }

    public sealed partial class TestOnlySharedWorldPolicy
    {
        private readonly CharacterAdvancementFixture characterAdvancement;
        private readonly OverwatchFoundationFixture overwatchFoundation;
        private readonly SoldierInitialLoadoutFixture soldierInitialLoadout;
        private readonly SoldierCharacterBuildFixture soldierCharacterBuild;
        public TestOnlySharedWorldPolicy(CharacterAdvancementFixture advancement,SharedCombatFixture combat,int walkingSpeed=30,
            ConditionCombatFixture conditions=null,params TacticalTerrainCell[] terrain)
            :this(combat,(SharedResearchFixture)null,(SharedCraftingFixture)null,(SharedRepairFixture)null,(SharedManufacturingFixture)null,
                (SupplyCacheFixture)null,walkingSpeed,conditions,terrain)
        {
            characterAdvancement=advancement??throw new ArgumentNullException(nameof(advancement));
            if(combat==null)throw new ArgumentNullException(nameof(combat));
            ContentFingerprint=characterAdvancement.BindFingerprint(ContentFingerprint);
        }
        private void InitializeCharacterAdvancement(Snapshot s)
        {
            if(characterAdvancement==null)return;
            s.Characters=s.Characters.Select(x=>x.ActorId==TestOnlyPolicy.ActorId
                ?new ActorCharacterRecord(x.ActorId,CharacterAdvancementProfileIds.TestOnlySoldierLevel1,new[]{10,10,10,10,10,10},new[]{new CharacterLevelFact("Soldier",10)}):x).ToArray();
            s.Lives=s.Lives.Select(x=>x.ActorId==TestOnlyPolicy.ActorId?characterAdvancement.HeroLife:x).ToArray();
            s.CharacterHitDice=new[]{new CharacterHitDieRecord(TestOnlyPolicy.ActorId,1,"Soldier",10,characterAdvancement.StartingHitDieSpent)};
            s.TacticalCovers=characterAdvancement.Covers.ToArray();
        }
        private void InitializeOverwatchFoundation(Snapshot s)
        {
            if(overwatchFoundation==null)return;
                if(s.SchemaVersion<Snapshot.SharedBonusActionSchema||s.WorldSchedule==null||characterAdvancement==null
                ||s.Characters.Single(x=>x.ActorId==TestOnlyPolicy.ActorId).Levels.Count!=1)
                throw new ArgumentException("Overwatch foundation requires the source-scoped Soldier 1 schema24 fixture.");
            s.BonusActions=s.WorldIntervals.Select(x=>new ActorBonusActionRecord(x.ActorId,checked((int)x.LastStart))).ToArray();
            s.CharacterFeatureGrants=s.CharacterFeatureGrants.Concat(new[]{new CharacterFeatureGrantRecord(TestOnlyPolicy.ActorId,
                CharacterFeatureIds.Overwatch,"Soldier",1,"",0,CharacterFeatureGrantOrigin.AutomaticClassFeature)}).ToArray();
        }
        private void InitializeSoldierInitialLoadout(Snapshot s)
        {
            if(soldierInitialLoadout==null)return;
            if((s.SchemaVersion!=Snapshot.SoldierInitialLoadoutSchema&&s.SchemaVersion!=Snapshot.SoldierInitialBuildSchema
                &&s.SchemaVersion!=Snapshot.SoldierTacticalTechniquesSchema&&s.SchemaVersion!=Snapshot.CharacterAdvancementHistorySchema
                &&s.SchemaVersion!=Snapshot.TacticalAssessmentSchema&&s.SchemaVersion!=Snapshot.CommandStepSchema
                &&s.SchemaVersion!=Snapshot.SuppressionFireSchema&&s.SchemaVersion!=Snapshot.DefensiveFormationSchema
                &&!(characterAdvancement!=null&&characterAdvancement.LevelFourAdvancementEnabled
                    &&s.SchemaVersion==Snapshot.SharedCharacterAdvancementSchema)
                &&!(dodgeActionEnabled&&s.SchemaVersion==Snapshot.DodgeSchema)
                &&!(readyActionEnabled&&s.SchemaVersion==Snapshot.ReadyActionSchema))
                ||characterAdvancement==null||overwatchFoundation==null
                ||s.WorldSchedule==null||s.CharacterFeatureGrants.Any(g=>g.ActorId==TestOnlyPolicy.ActorId&&g.Origin==CharacterFeatureGrantOrigin.InitialClassSelection))
                throw new ArgumentException("Soldier initial selections require the explicit source-scoped Soldier 1 and Overwatch fixtures.");
            s.Characters=s.Characters.Select(x=>x.ActorId==TestOnlyPolicy.ActorId
                ?new ActorCharacterRecord(x.ActorId,soldierCharacterBuild==null?CharacterAdvancementProfileIds.TestOnlySoldierLevel1WithInitialCards
                    :CharacterAdvancementProfileIds.TestOnlySoldierLevel1InitialBuild,x.Abilities,x.Levels):x).ToArray();
            var selection=new CharacterInitialClassSelectionRecord(TestOnlyPolicy.ActorId,"Soldier",1,SoldierInitialLoadoutFixture.SourceRevision,
                soldierInitialLoadout.SelectedFeatureIds.ToArray());
            s.InitialClassSelections=new[]{selection};
            s.CharacterFeatureGrants=s.CharacterFeatureGrants.Concat(selection.SelectedFeatureIds.Select(feature=>new CharacterFeatureGrantRecord(
                TestOnlyPolicy.ActorId,feature,"Soldier",1,"",0,CharacterFeatureGrantOrigin.InitialClassSelection))).ToArray();
            int lastStart=checked((int)s.WorldIntervals.Single(x=>x.ActorId==TestOnlyPolicy.ActorId).LastStart);
            s.CharacterFeatureRuntime=new[]{new CharacterFeatureRuntimeRecord(TestOnlyPolicy.ActorId,lastStart)};
        }
        private void InitializeSoldierCharacterBuild(Snapshot s)
        {
            if(soldierCharacterBuild==null)return;
            int expectedSchema=characterAdvancement.LevelFourAdvancementEnabled?Snapshot.SharedCharacterAdvancementSchema
                :characterAdvancement.DefensiveFormationSchemaEnabled?Snapshot.DefensiveFormationSchema
                :characterAdvancement.SuppressionFireSchemaEnabled?Snapshot.SuppressionFireSchema
                :characterAdvancement.CommandStepSchemaEnabled?Snapshot.CommandStepSchema
                :characterAdvancement.TacticalAssessmentSchemaEnabled?Snapshot.TacticalAssessmentSchema
                :characterAdvancement.HistorySchemaEnabled?Snapshot.CharacterAdvancementHistorySchema
                :soldierCharacterBuild.TacticalTechniquesEnabled?Snapshot.SoldierTacticalTechniquesSchema:Snapshot.SoldierInitialBuildSchema;
            if((s.SchemaVersion!=expectedSchema&&!(readyActionEnabled&&s.SchemaVersion==Snapshot.ReadyActionSchema))
                ||soldierInitialLoadout==null||overwatchFoundation==null
                ||characterAdvancement==null||s.WorldSchedule==null||s.RepeatingCrossbows.Length!=1||s.AmmunitionLots.Length!=1)
                throw new ArgumentException("Soldier character build requires its complete source-scoped level-one fixture.");
            s.Lives=s.Lives.Select(x=>x.ActorId==TestOnlyPolicy.ActorId
                ?new ActorLifeRecord(x.ActorId,10,soldierCharacterBuild.InitialCurrentHp,0,Array.Empty<int>(),false,false,true,0,0,null,0,false,
                    new[]{RepeatingCrossbowFixture.WeaponId}):x).ToArray();
            s.Clubs=s.Clubs.Where(x=>x.Id!=TestOnlyClubAttackPolicy.ActorClub).ToArray();
            var skills=soldierCharacterBuild.SelectedSkillIds.ToArray();
            s.SkillTraining=s.SkillTraining.Where(x=>!(x.ActorId==TestOnlyPolicy.ActorId&&x.SkillId!="medicine")).Concat(
                skills.Select(x=>new SkillTrainingRecord(TestOnlyPolicy.ActorId,x,1))).ToArray();
            string pack=SoldierInitialEquipmentIds.Pack;
            int lastStart=checked((int)s.WorldIntervals.Single(x=>x.ActorId==TestOnlyPolicy.ActorId).LastStart);
            s.InitialCharacterLoadouts=new[]{new CharacterInitialLoadoutRecord(TestOnlyPolicy.ActorId,SoldierCharacterBuildFixture.SourceRevision,12,
                CharacterAdvancementProfileIds.TestOnlySoldierLevel1InitialBuild,skills,new[]{"STR","CON"},SoldierInitialEquipmentIds.ChainMail,
                SoldierInitialEquipmentIds.Shield,SoldierInitialEquipmentIds.Dagger,pack,RepeatingCrossbowFixture.WeaponId,
                RepeatingCrossbowFixture.AmmunitionId,SoldierInitialEquipmentIds.Rations,SoldierInitialEquipmentIds.Waterskin,
                SoldierInitialEquipmentIds.Water,0,0)};
            s.ShieldStationarity=new[]{new ShieldStationarityRecord(TestOnlyPolicy.ActorId,lastStart,false)};
            InitializeSoldierPortableEquipment(s);
            if(soldierCharacterBuild.TacticalTechniquesEnabled) {
                s.WorldSchedule=new WorldScheduleRecord(s.WorldSchedule.Id,s.WorldSchedule.Origin,
                    new[]{TestOnlyPolicy.ActorId,TestOnlyPolicy.CompanionId,AdditionalTacticalActor.Id},s.WorldSchedule.ProcessedSlot);
                s.WorldIntervals=s.WorldSchedule.Order.Select(actor=>new WorldIntervalRecord(actor,s.WorldSchedule.LatestStart(actor,s.WorldSchedule.ProcessedSlot))).ToArray();
                s.TacticalActors=s.TacticalActors.Select(actor=>{
                    var interval=s.WorldIntervals.Single(x=>x.ActorId==actor.ActorId);
                    return new ActorTacticalRecord(actor.ActorId,checked((int)interval.LastStart),interval.ReactionAvailable,actor.MobileFeet,actor.PressConsumed,actor.DisengageTurn);
                }).ToArray();
                s.ActorMovement=s.ActorMovement.Select(m=>new ActorMovementRecord(m.ActorId,m.BaseWalkingSpeed,
                    checked((int)s.WorldSchedule.LatestStart(m.ActorId,s.WorldSchedule.ProcessedSlot)),m.TurnOrdinal<0?0:m.Spent)).ToArray();
                s.BonusActions=s.WorldIntervals.Select(interval=>new ActorBonusActionRecord(interval.ActorId,checked((int)interval.LastStart))).ToArray();
                s.TacticalAllies=new[]{new TacticalAllyRecord(TestOnlyPolicy.ActorId,TestOnlyPolicy.CompanionId)};
                if(offCalendarActivityEnabled||s.SchemaVersion>=Snapshot.OffCalendarActivitySchema)
                    s.WorldActivityIntervals=s.Actors.Where(actor=>!s.WorldSchedule.Order.Contains(actor.Id)).OrderBy(actor=>actor.Id,StringComparer.Ordinal)
                        .Select(actor=>new WorldActivityIntervalRecord(s.WorldSchedule.Id,actor.Id,
                            WorldActivityIntervalRecord.IndexAt(s.WorldSchedule,s.RuleClock))).ToArray();
            }
        }
        public TestOnlySharedWorldPolicy(OverwatchFoundationFixture overwatch,CharacterAdvancementFixture advancement,SharedCombatFixture combat,
            int walkingSpeed=30,ConditionCombatFixture conditions=null,params TacticalTerrainCell[] terrain)
            :this(advancement,combat,walkingSpeed,conditions,terrain)
        {
            overwatchFoundation=overwatch??throw new ArgumentNullException(nameof(overwatch));
            ContentFingerprint=overwatchFoundation.BindFingerprint(ContentFingerprint);
        }
        public TestOnlySharedWorldPolicy(SoldierInitialLoadoutFixture loadout,OverwatchFoundationFixture overwatch,CharacterAdvancementFixture advancement,
            SharedCombatFixture combat,int walkingSpeed=30,ConditionCombatFixture conditions=null,params TacticalTerrainCell[] terrain)
            :this(overwatch,advancement,combat,walkingSpeed,conditions,terrain)
        {
            soldierInitialLoadout=loadout??throw new ArgumentNullException(nameof(loadout));
            ContentFingerprint=soldierInitialLoadout.BindFingerprint(ContentFingerprint);
        }
        public TestOnlySharedWorldPolicy(SoldierCharacterBuildFixture build,OverwatchFoundationFixture overwatch,
            CharacterAdvancementFixture advancement,SharedCombatFixture combat,int walkingSpeed=30,
            ConditionCombatFixture conditions=null,params TacticalTerrainCell[] terrain)
            :this(overwatch,advancement,combat,walkingSpeed,conditions,terrain)
        {
            soldierCharacterBuild=build??throw new ArgumentNullException(nameof(build));
            soldierInitialLoadout=new SoldierInitialLoadoutFixture();
            ContentFingerprint=soldierInitialLoadout.BindFingerprint(ContentFingerprint);
            ContentFingerprint=RepeatingCrossbowFixture.BindFingerprint(ContentFingerprint,new RepeatingCrossbowFixture());
            ContentFingerprint=soldierCharacterBuild.BindFingerprint(ContentFingerprint);
            if(soldierCharacterBuild.TacticalTechniquesEnabled)
                ContentFingerprint=SoldierTacticalTechniqueFixture.BindFingerprint(ContentFingerprint);
            rangedCombat=new RepeatingCrossbowFixture();
        }
        public TestOnlySharedWorldPolicy(OverwatchFoundationFixture overwatch,PeriodicRiderFixture periodic,CharacterAdvancementFixture advancement,
            SharedCombatFixture combat,int walkingSpeed=30,ConditionCombatFixture conditions=null,params TacticalTerrainCell[] terrain)
            :this(periodic,advancement,combat,walkingSpeed,conditions,terrain)
        {
            overwatchFoundation=overwatch??throw new ArgumentNullException(nameof(overwatch));
            ContentFingerprint=overwatchFoundation.BindFingerprint(ContentFingerprint);
        }
        private string ResolveCharacterAdvancement(Snapshot s,Command c)=>IsClericAdvancement(s,c)
            ? ResolveClericAdvancement(s,c) : CharacterAdvancementRules.Resolve(s,c);
    }
}
#endif
