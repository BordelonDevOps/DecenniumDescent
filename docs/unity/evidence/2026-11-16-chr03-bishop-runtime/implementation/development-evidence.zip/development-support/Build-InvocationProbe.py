import json,sys
from pathlib import Path
root=Path(__file__).resolve().parent
out=root/(sys.argv[1] if len(sys.argv)>1 else 'invocation-attempt1')
out.mkdir(exist_ok=False)
rows=[json.loads(x) for x in (root/'advancement-attempt2/inputs.jsonl').read_text().splitlines()]
choice=dict(targets=['TEST_ONLY.actor','TEST_ONLY.companion'],cureTarget='',curePreference='None')
def invocation(op,id):return dict(op=op,id=id,actor='TEST_ONLY.companion',kind='UseDivineInvocation',target='',x=0,y=0,divineInvocation=choice)
rows[293:293]=[invocation('query','bishop.unfunded.query'),invocation('submit','bishop.unfunded.reject')]
rows += [dict(op='clock',id='bishop.funded.own-start',x=2,y=1),invocation('query','bishop.funded.query'),
 invocation('submit','bishop.funded.invocation'),dict(op='view',seat='Player'),dict(op='save',path='invocation-paid.ddsave'),
 dict(op='load',path='invocation-paid.ddsave'),dict(op='view',seat='Player'),dict(op='clock',id='bishop.recharge1',x=6,y=1),
 dict(op='view',seat='Player'),dict(op='clock',id='bishop.recharge3',x=12,y=1),dict(op='view',seat='Player'),
 dict(op='save',path='invocation-ready.ddsave'),dict(op='load',path='invocation-ready.ddsave'),dict(op='view',seat='Player')]
for r in rows:
 if r['op'] in ['save','load']:r['path']=str(out/Path(r['path']).name)
(out/'inputs.jsonl').write_text('\n'.join(json.dumps(r) for r in rows)+'\n')
print(out)
