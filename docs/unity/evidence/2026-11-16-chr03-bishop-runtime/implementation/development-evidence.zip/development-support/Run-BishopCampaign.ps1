param([string]$OutputName='primary-attempt1',[string]$BootstrapName='advancement-attempt3')
$ErrorActionPreference='Stop'
$repo=(Resolve-Path (Join-Path $PSScriptRoot '../github-delivery')).Path
$probeOut=Join-Path $PSScriptRoot $OutputName
if(Test-Path -LiteralPath $probeOut){throw 'Use a fresh output directory'}
New-Item -ItemType Directory -Path $probeOut | Out-Null
$bootstrap=Join-Path $probeOut 'bootstrap.jsonl'
[IO.File]::WriteAllText($bootstrap,'')
$selectedAssemblies=Get-Content -LiteralPath (Join-Path $PSScriptRoot ($BootstrapName+'/assembly-root.txt'))
$selectedAssemblies | Set-Content -LiteralPath (Join-Path $probeOut 'assembly-root.txt')
. (Join-Path $repo 'engine/tools/Open-ConnectedExpedition.ps1') -AssemblyRoot $selectedAssemblies -BishopEntry -InputPath $bootstrap
$probeStore=[Decennium.Foundation.FileSaveStore]::new()
$probeSequence=0
$hero='TEST_ONLY.actor';$companion='TEST_ONLY.companion';$npc='TEST_ONLY.recovery-defender'
function Read-State {
 $scratch=Join-Path $probeOut 'read-current.ddsave'
 $session.Save($scratch)
 return $probeStore.Load($scratch)
}
function Do-Input([hashtable]$request,[switch]$AllowUnavailable) {
 if($request.op -in @('submit','clock','close')) {
  $script:probeSequence++
  $request.id='bishop.primary.'+$script:probeSequence
  if(!$request.ContainsKey('x')){$request.x=0};if(!$request.ContainsKey('y')){$request.y=0}
 }
 $line=ConvertTo-Json -InputObject $request -Depth 12 -Compress
 [IO.File]::AppendAllText((Join-Path $probeOut 'inputs.jsonl'),$line+"`n")
 $response=Write-SessionResponse $line
 [IO.File]::AppendAllText((Join-Path $probeOut 'outputs.jsonl'),$response+"`n")
 $parsed=ConvertFrom-Json -AsHashtable $response
 if($request.op -in @('submit','clock','close') -and $parsed.Response -ne 'Committed' -and !$AllowUnavailable) {
  throw ('Public command failed: '+$line+' => '+$response)
 }
 return $parsed
}
function Checkpoint([string]$name) {
 $null=Do-Input @{op='save';path=(Join-Path $probeOut ($name+'.ddsave'))}
 $null=Do-Input @{op='view';seat='Player'}
 $null=Do-Input @{op='view';seat='RecoveryOpponent'}
}
function Submit-Action([string]$kind,[string]$actor=$companion,[string]$target='', [hashtable]$extra=@{}) {
 $request=@{op='submit';kind=$kind;actor=$actor;target=$target;seat=$(if($actor -eq $npc){'RecoveryOpponent'}else{'Player'})}
 foreach($key in $extra.Keys){$request[$key]=$extra[$key]}
 $null=Do-Input $request
}
function Advance-By([long]$numerator,[long]$denominator=1) { $null=Do-Input @{op='clock';x=$numerator;y=$denominator} }
function Advance-To($target) {
 $now=(Read-State).RuleClock
 $n=$target.Numerator*$now.Denominator-$now.Numerator*$target.Denominator
 if($n -lt 0){throw 'Cannot reverse time'}
 if($n -gt 0){Advance-By $n ($target.Denominator*$now.Denominator)}
 if((Read-State).RuleClock -ne $target){throw 'Clock yielded before requested target'}
}
function Paid-Step([string]$actor,[int]$dx,[int]$dy) {
 $s=Read-State
 $speed=[Decennium.Foundation.Laboratory.TestOnlyClubAttackPolicy]::WalkingSpeed($s,$actor)
 Submit-Action 'BeginWorldStep' $actor 'walk' @{x=$dx;y=$dy}
 Advance-By 30 $speed
 if(@((Read-State).WorldTraversals).Count -ne 0){throw 'Step did not complete'}
}
function Await-ClericStart {
 $s=Read-State;$epoch=[Decennium.Foundation.WorldTiming]::ForActor($s,$companion);$slot=$epoch.SlotAt($s.RuleClock)
 while($epoch.Order[[int]($slot % $epoch.Order.Count)] -ne $companion -or $epoch.Start($slot) -lt $s.RuleClock){$slot++}
 Advance-To $epoch.Start($slot)
}
function Cast([string]$spell,[string]$target,[bool]$willing) {
 Submit-Action 'CastKnownSpell' $companion $target @{spellCast=@{spellId=$spell;focusItemId=$(if($spell -eq 'guidance'){''}else{'TEST_ONLY.cleric-casting.holy-symbol'});willingTarget=$willing;electFocusedDc=$false}}
}
$null=Do-Input @{op='load';path=(Join-Path $PSScriptRoot ($BootstrapName+'/second-rest.ddsave'))}
Checkpoint 'second-rest'
Paid-Step $companion 1 0
Paid-Step $companion 1 0
Paid-Step $companion 0 1
Paid-Step $hero 1 0
Paid-Step $hero 1 0
$s=Read-State;$epoch=$s.Reinforcement.Admission.Phase.Epoch
$speed=[Decennium.Foundation.Laboratory.TestOnlyClubAttackPolicy]::WalkingSpeed($s,$hero)
$duration=[Decennium.Foundation.RuleTime]::new(30,$speed)
$earliest=[Decennium.Foundation.RuleTime]::new(($s.RuleClock.Numerator*$duration.Denominator+$duration.Numerator*$s.RuleClock.Denominator),($s.RuleClock.Denominator*$duration.Denominator))
$slot=$epoch.SlotAt($s.RuleClock)
while($epoch.Order[[int]($slot % $epoch.Order.Count)] -ne 'TEST_ONLY.later-defender' -or $epoch.Start($slot) -lt $earliest){$slot++}
$arrival=$epoch.Start($slot)
$departure=[Decennium.Foundation.RuleTime]::new(($arrival.Numerator*$duration.Denominator-$duration.Numerator*$arrival.Denominator),($arrival.Denominator*$duration.Denominator))
Advance-To $departure
Checkpoint 'before-contact'
Paid-Step $hero 0 1
if(!(Read-State).InventoryCombat){throw 'Actual paid contact did not admit encounter'}
Checkpoint 'entered'
$initial=Read-State
$initialHeroHp=($initial.Lives | Where-Object ActorId -eq $hero).Hp
$initialCompanionHp=($initial.Lives | Where-Object ActorId -eq $companion).Hp
$feared=$false;$detected=$false;$invoked=$false;$cared=$false;$deathSeen=$false;$postDeathEnds=0
for($turn=0;$turn -lt 100;$turn++) {
 $s=Read-State;$actor=$s.Encounter.CurrentActor;$turnId=$s.Encounter.CurrentTurnId
 $life=$s.Lives | Where-Object ActorId -eq $actor
 $enemy=$s.Lives | Where-Object ActorId -eq $npc
 if($life.Hp -gt 0 -and !$life.Dead){
  Submit-Action 'SelectCombatStance' $actor '' @{combat=@{turn=$turnId;stance=1}}
  if($enemy.Dead -and $postDeathEnds -ge 3 -and $actor -eq $hero){
   $close=Do-Input @{op='close';target=$turnId} -AllowUnavailable
   if($close.Response -eq 'Committed'){break}
  }
  $heroLife=$s.Lives | Where-Object ActorId -eq $hero
  $companionLife=$s.Lives | Where-Object ActorId -eq $companion
  if($actor -eq $npc){
   $recharge=$s.AbilityRecharges | Where-Object { $_.ActorId -eq $npc -and $_.AbilityId -eq [Decennium.Foundation.FrightenedProfile]::SourceId }
   if(!$feared -or (!$invoked -and $heroLife.Hp -lt $initialHeroHp -and $companionLife.Hp -lt $initialCompanionHp -and $recharge.Remaining -eq 0)){
    Submit-Action 'UseIntimidatingPresence' $npc '' @{intimidatingPresence=@{targets=@($hero,$companion)}};$feared=$true
   } elseif(!$invoked -and $heroLife.Hp -ge $initialHeroHp){
    Submit-Action 'AttackClub' $npc $hero @{combat=@{turn=$turnId;weapon='TEST_ONLY.recovery-defender-club'}}
   } elseif(!$invoked -and $companionLife.Hp -ge $initialCompanionHp){
    Submit-Action 'AttackClub' $npc $companion @{combat=@{turn=$turnId;weapon='TEST_ONLY.recovery-defender-club'}}
   } elseif($invoked -and !$cared -and $heroLife.Hp -gt 13){
    Submit-Action 'AttackClub' $npc $hero @{combat=@{turn=$turnId;weapon='TEST_ONLY.recovery-defender-club'}}
   }
  } elseif($actor -eq $companion){
   $fearTarget=''
   foreach($patient in @($hero,$companion)){
    if([Decennium.Foundation.Laboratory.TestOnlyClubAttackPolicy]::ConditionsFor($s,$patient).View().Has([Decennium.Foundation.Laboratory.ConditionKind]::Frightened)){$fearTarget=$patient;break}
   }
   if(!$detected){Cast 'detect-magic' $companion $false;$detected=$true}
   elseif(!$invoked -and $heroLife.Hp -lt $initialHeroHp -and $companionLife.Hp -lt $initialCompanionHp -and $fearTarget -ne ''){
    Submit-Action 'UseDivineInvocation' $companion '' @{divineInvocation=@{targets=@($hero,$companion);cureTarget=$fearTarget;curePreference='Frightened'}}
    $invoked=$true
    Checkpoint 'invocation-cure'
    $use=(Read-State).BishopEntry.Invocations[-1]
    if($use.EndedApplicationIds.Count -lt 1 -or @($use.Recipients | Where-Object ActualGain -gt 0).Count -ne 2){throw 'Invocation did not genuinely heal two recipients and cure a condition'}
    $null=Do-Input @{op='load';path=(Join-Path $probeOut 'invocation-cure.ddsave')}
   } elseif($invoked -and !$cared -and $heroLife.Hp -le 13){
    Submit-Action 'UseHealingRite' $companion $hero @{healingRite=@{curePreference='None'}};$cared=$true
    Checkpoint 'rite-radiance-aura'
    $care=Read-State
    if($care.HealingRites[-1].ActualGain -le 0 -or $care.RadianceUses[-1].AdditionalGain -le 0 -or $care.BishopEntry.AuraHealing[-1].ActualGain -le 0){throw 'Rite did not genuinely heal with both distinct riders'}
   }
  } elseif($actor -eq $hero -and $heroLife.Hp -gt 0 -and !$enemy.Dead -and $invoked -and $cared){
   Submit-Action 'AttackClub' $hero $npc @{combat=@{turn=$turnId;weapon='TEST_ONLY.actor-club'}}
  }
 }
 Submit-Action 'EndRegularTurn' $actor $turnId
 if($enemy.Dead){$postDeathEnds++}
}
if((Read-State).InventoryCombat){throw 'Encounter did not close within bounded probe'}
Checkpoint 'closed'
# Vacate by actual movement and return to the original berth.
Paid-Step $hero -1 0
Paid-Step $hero -1 0
Paid-Step $hero 0 -1
Paid-Step $companion 0 -1
Paid-Step $companion -1 0
Paid-Step $companion -1 0
$s=Read-State
foreach($effect in @($s.SpellEffects | Where-Object { $_.Present -and $_.RequiresConcentration -and $_.CasterId -eq $companion })){
 Submit-Action 'EndSpellConcentration' $companion $effect.Id
}
Checkpoint 'returned'
Advance-To ([Decennium.Foundation.RuleTime]::new(459041,2))
Submit-Action 'BeginLongRest' $companion 'TEST_ONLY.cleric-long-rest-berth'
Advance-By 28800
Checkpoint 'third-rest'
Await-ClericStart
Cast 'guidance' $hero $true
Advance-By 6
Cast 'detect-magic' $companion $false
Checkpoint 'guidance-detect-living-hero'
Advance-By 6
$playerView=$session.View('Player')
$heroView=$playerView.Actors | Where-Object {$_.Position.Id -eq $hero}
$clericView=$playerView.Actors | Where-Object {$_.Position.Id -eq $companion}
$observations=@($clericView.Casting.Auras | Where-Object {$_.X -eq $heroView.Position.X -and $_.Y -eq $heroView.Position.Y})
if($observations.Count -ne 1){throw 'Expected one permitted individual outline at the hero'}
Cast 'dispel-magic-lesser' $observations[0].ObservationId $false
Checkpoint 'guidance-dispelled'
$dispelled=Read-State
if(@($dispelled.SpellEffects | Where-Object {$_.SpellId -eq 'guidance' -and $_.Present}).Count -ne 0 -or @($dispelled.SpellEffects | Where-Object {$_.SpellId -eq 'detect-magic' -and $_.Present}).Count -ne 1){throw 'Dispel ended the wrong effect'}
$null=Do-Input @{op='load';path=(Join-Path $probeOut 'guidance-dispelled.ddsave')}
Paid-Step $companion 1 0
Checkpoint 'continued'
Advance-To ([Decennium.Foundation.RuleTime]::new(259200))
Checkpoint 'later-pressure-boundary'
'Completed development Bishop campaign: '+$probeOut
