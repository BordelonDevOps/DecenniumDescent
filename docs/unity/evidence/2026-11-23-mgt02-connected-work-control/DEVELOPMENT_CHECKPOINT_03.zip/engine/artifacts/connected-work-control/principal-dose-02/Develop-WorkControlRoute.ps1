param([Parameter(Mandatory)][string]$AssemblyRoot,[Parameter(Mandatory)][string]$Run,
    [ValidateSet('Prefix','Dose','Fight','Work')][string]$Stage='Prefix',[string]$ResumeSave)
$ErrorActionPreference='Stop'
$AssemblyRoot=(Resolve-Path -LiteralPath $AssemblyRoot).Path;$Run=[IO.Path]::GetFullPath($Run)
if(Test-Path -LiteralPath $Run){throw 'Use a new evidence directory.'}
$null=New-Item -ItemType Directory -Path $Run
Copy-Item -LiteralPath $PSCommandPath -Destination $Run
$repo=(Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '../../../../..')).Path
$oldSupport=Join-Path $repo 'docs/unity/evidence/2026-11-23-tac01-ordinary-magic/support'
Copy-Item -LiteralPath (Join-Path $oldSupport 'TypedCommand.ps1') -Destination $Run
. (Join-Path $Run 'TypedCommand.ps1')
$report=[ordered]@{status='RUNNING';scope='Genuine new-profile principal route development; not final acceptance';stage=$Stage;startedUtc=[DateTime]::UtcNow.ToString('o');commands=0;queries=0;checkpoints=@();assemblyRoot=$AssemblyRoot;driverSha256=(Get-FileHash -LiteralPath $PSCommandPath).Hash.ToLowerInvariant()}
function Json($v){ConvertTo-Json -InputObject $v -Depth 12 -Compress -EnumsAsStrings}
function Require([bool]$condition,[string]$message){if(!$condition){throw $message}}
try {
    foreach($part in 'Core','Persistence','LabModel'){Add-Type -Path (Join-Path $AssemblyRoot "Decennium.Foundation.$part.dll")}
    $session=[Decennium.Foundation.Laboratory.ConnectedExpeditionSession]::StartWithConnectedWorkControl(
        [Decennium.Foundation.Laboratory.ClericInitialSelection]::AuthoredExample(),[Decennium.Foundation.Laboratory.ClericRepertoireSelection]::AuthoredExample(),
        [Decennium.Foundation.ClericMilestoneDeclaration]::AuthoredExample(),[Decennium.Foundation.BishopEntryRecord]::Announced())
    $store=[Decennium.Foundation.FileSaveStore]::new();$codec=[Decennium.Foundation.SnapshotCodec]::new()
    $hero=[Decennium.Foundation.Laboratory.ConnectedExpeditionSession]::Hero;$ally=[Decennium.Foundation.Laboratory.ConnectedExpeditionSession]::Companion
    if($ResumeSave){$ResumeSave=(Resolve-Path -LiteralPath $ResumeSave).Path;$session.Restore($ResumeSave);$report.parentSave=$ResumeSave;$report.parentSha256=(Get-FileHash -LiteralPath $ResumeSave).Hash.ToLowerInvariant()}
    elseif($Stage-ne'Prefix'){throw 'A continuation stage needs a genuine same-profile save.'}
    function State {$session.Save((Join-Path $Run 'latest.ddsave'));$store.Load((Join-Path $Run 'latest.ddsave'))}
    function Witness([string]$name) {
        $path=Join-Path $Run ($name+'.ddsave');$session.Save($path);$s=$store.Load($path)
        foreach($actor in @($hero,$ally)) {
            [IO.File]::WriteAllText((Join-Path $Run ($name+'.'+$actor+'.work.json')),(Json ($session.ObserveWork('Player',$actor))))
            [IO.File]::WriteAllText((Join-Path $Run ($name+'.'+$actor+'.discover.json')),(Json @($session.DiscoverCommands('Player',$actor))))
        }
        $report.checkpoints+=,@{name=$name;revision=$s.Revision;clock=$s.RuleClock;random=$s.RandomState;sha256=(Get-FileHash -LiteralPath $path).Hash.ToLowerInvariant()}
    }
    function Dispatch($request) {
        $command=New-TypedCommand $request
        if($request.op-eq'submit') {
            $query=$session.QueryCommand($request.seat,$command);$report.queries++
            [IO.File]::AppendAllText((Join-Path $Run 'queries.jsonl'),(Json @{request=$request;query=$query})+"`n")
            if($query.Supported){Require $query.Admissible "Denied query $($command.Kind): $($query.Code)"}
        }
        $result=switch($request.op){
            'clock'{$session.SubmitSessionCommand($command)}
            'close'{$session.SubmitSessionCommand($command)}
            'auto'{$session.AdvanceAutomaticDefender()}
            'defender-presence'{$session.SubmitDefenderIntimidatingPresence([Decennium.Foundation.Laboratory.LaterDefenderController]::DefenderAuthority(),$command)}
            'defender-sanctuary'{$session.SubmitDefenderSanctuary([Decennium.Foundation.Laboratory.LaterDefenderController]::DefenderAuthority(),$command)}
            default{$session.Submit($request.seat,$command)}
        }
        [IO.File]::AppendAllText((Join-Path $Run 'execution.jsonl'),(Json @{request=$request;result=$result})+"`n")
        Require ($result.Response.ToString()-eq'Committed') "Command failed $($request.id)/$($request.kind): $($result.Response)"
        $report.commands++;$session.Save((Join-Path $Run 'latest.ddsave'))
        if($report.commands%25-eq0){Write-Output ("$Stage committed $($report.commands); revision$($result.Revision)")}
    }
    function Send([string]$kind,[string]$actor=$hero,[string]$target='',[int]$x=0,[int]$y=0,$inventory=$null,$combat=$null) {
        $r=$session.View('Player').Revision
        $request=@{op=$(if($kind-eq'AdvanceClock'){'clock'}elseif($kind-eq'EndFixedEncounter'){'close'}else{'submit'});seat='Player';id="work-control.route.$r";actor=$actor;revision=$r;kind=$kind;target=$target;x=$x;y=$y}
        if($inventory){$request.inventory=$inventory};if($combat){$request.combat=$combat};Dispatch $request
    }
    function Walk([string]$actor,[int]$dx,[int]$seconds=6) {Send 'BeginWorldStep' $actor 'walk' $dx;Send 'AdvanceClock' $hero '' $seconds 1}
    function Guard([string]$actor) {Send 'SelectCombatStance' $actor -combat @{turn=$session.View('Player').TurnId;stance=1}}
    function End([string]$actor) {Send 'EndRegularTurn' $actor $session.View('Player').TurnId}
    function Automatic {
        for($i=0;$session.View('Player').NextSeat.ToString()-eq'AutomaticDefender';$i++) {
            Require ($i-lt16) 'Automatic defender exceeded one bounded decision sequence.'
            $r=$session.View('Player').Revision
            Dispatch @{op='auto';seat='Player';id="work-control.auto.$r";actor='TEST_ONLY.later-defender';revision=$r;kind='EndRegularTurn';target='';x=0;y=0}
        }
    }
    Witness 'initial'
    if($Stage-eq'Prefix') {
        $source=Join-Path $repo 'engine/artifacts/ordinary-magic-qualification/candidate-02/five-paths-01/inputs.jsonl'
        $report.prefixInputSha256=(Get-FileHash -LiteralPath $source).Hash.ToLowerInvariant()
        $already=$session.View('Player').Revision
        $commands=@(Get-Content -LiteralPath $source|ForEach-Object{ConvertFrom-Json -AsHashtable $_}|Where-Object{$_.op-in@('submit','clock','close','auto','defender-presence','defender-sanctuary')}|Select-Object -First 108|Select-Object -Skip $already)
        Require ($commands.Count+$already-eq108) 'Missing finite prefix.'
        foreach($request in $commands) {
            Dispatch $request
            $r=$session.View('Player').Revision
            if($r-in@(15,16,17,93,94,95,96,97,104,105,106,107,108)){Witness ('r'+$r.ToString('D3'))}
        }
        $s=State
        Require ($s.ManufacturingOrders.Count-eq1-and$s.AlchemyDoses.Count-gt0) 'Prefix did not produce actual doses.'
    } elseif($Stage-eq'Dose') {
        Require ($session.View('Player').Revision-in@(108,110)) 'Dose stage begins at the genuine completed-batch prefix or retained failed pickup approach.'
        $dose='manufacture.order.104.dose0'
        # The selected Cleric profile leaves batch doses at the actual worksite; it does not
        # select the separate carried-vial profile. Preserve that boundary and use in reach.
        if($session.View('Player').Revision-eq110){Walk $hero -1}
        Walk $ally -1;Walk $hero -1 12
        Send 'BeginReinforcementApproach' $ally 'TEST_ONLY.companion-reinforcement.v1'
        Witness 'actual-encounter-entry'
        Guard $hero;Send 'TacticalStep' $hero $session.View('Player').TurnId 0 2;Automatic
        End $hero;Automatic;Guard $ally
        Send 'TacticalStep' $ally $session.View('Player').TurnId 2 3;Automatic
        $before=State;$life=@($before.Lives|Where-Object ActorId -eq $ally)[0]
        Witness 'before-use'
        Send 'UseAlchemyDose' $ally $dose -inventory @{numerator=1;denominator=1;destination=$ally;handling='Pickup'}
        $after=State;$healed=@($after.Lives|Where-Object ActorId -eq $ally)[0]
        Require ($healed.Hp-gt$life.Hp-and@($after.AlchemyDoses|Where-Object Id -eq $dose)[0].Spent) 'Actual batch output did not heal a damaged actor and become spent.'
        $report.usefulDose=@{id=$dose;beforeHp=$life.Hp;afterHp=$healed.Hp;beforeRng=$before.RandomState;afterRng=$after.RandomState}
    } else {throw 'Continuation stage is not yet authored.'}
    Witness 'final';$s=State
    $report.finalRevision=$s.Revision;$report.finalClock=$s.RuleClock;$report.randomState=$s.RandomState
    $report.actors=@($s.Actors|Select-Object Id,X,Y);$report.lives=@($s.Lives|Select-Object ActorId,Hp,Dead)
    $report.doses=@($s.AlchemyDoses|Select-Object Id,OwnerId,LocationId,ConsumedAt)
    $report.workCounts=@{lots=$s.Work.Lots.Count;bookings=$s.Work.WorkerIntervals.Count;reservations=$s.Work.Reservations.Count;receipts=$s.Receipts.Count}
    $report.status='PASS_BOUNDED_STAGE'
} catch {$report.status='FAIL';$report.error=$_.Exception.ToString()}
finally {$report.finishedUtc=[DateTime]::UtcNow.ToString('o');$report|ConvertTo-Json -Depth 12|Set-Content -LiteralPath (Join-Path $Run 'results.json') -Encoding utf8;Write-Output ("$($report.status): $Run")}
if($report.status-ne'PASS_BOUNDED_STAGE'){exit 1}
