using System;
using System.IO;
using System.Linq;
using System.Text.Json;
using Decennium.Foundation.Tests;
public static class Program {
 public static int Main(string[] args) {
  var names=FoundationCases.Names();
  if(args.Length==1&&args[0]=="--list") { foreach(var n in names)Console.WriteLine(n);return 0; }
  if(args.Length<2)throw new ArgumentException("Output directory and one or more exact case names are required.");
  Directory.CreateDirectory(args[0]);var options=new JsonSerializerOptions{IncludeFields=true,WriteIndented=true};bool failed=false;
  foreach(var name in args.Skip(1)) {
   if(!names.Contains(name))throw new ArgumentException("Unknown case "+name);
   Console.WriteLine("START "+name);Console.Out.Flush();
   var result=FoundationCases.Run(name,Path.Combine(args[0],name));
   var json=JsonSerializer.Serialize(result,options);File.WriteAllText(Path.Combine(args[0],name+".json"),json);
   Console.WriteLine(json);Console.Out.Flush();if(!result.Passed)failed=true;
  }
  return failed?1:0;
 }
}
