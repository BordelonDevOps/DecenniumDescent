using System;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;

namespace Decennium.Foundation
{
    public sealed class SnapshotCodec
    {
        public const int LegacyMaxBytes = 1024 * 1024;
        public const int MaxBytes = 2 * 1024 * 1024;
        public const int ConditionMaxBytes = 6 * 1024 * 1024;
        private static int Limit(int schema) => schema >= Snapshot.ConditionSchema ? ConditionMaxBytes : schema >= Snapshot.ActorLifeSchema ? MaxBytes : LegacyMaxBytes;
        private static readonly UTF8Encoding Utf8 = new UTF8Encoding(false, true);
        private const int Magic = 0x31464444; // DDF1, little endian. Checksum detects corruption, not tampering.
        public byte[] Encode(Snapshot state)
        {
            Validation.Snapshot(state);
            byte[] payload;
            using (var stream = new MemoryStream())
            using (var writer = new BinaryWriter(stream, Utf8, true))
            {
                writer.Write(Magic); writer.Write(state.WireSchemaVersion);
                WriteText(writer, state.ContentFingerprint); WriteText(writer, RandomV1.Algorithm);
                writer.Write(state.TestOnly); writer.Write(state.Revision); writer.Write(state.Clock); writer.Write(state.RandomState);
                writer.Write(state.Actors.Length);
                foreach (var a in state.Actors.OrderBy(x => x.Id, StringComparer.Ordinal))
                { WriteText(writer, a.Id); writer.Write(a.X); writer.Write(a.Y); writer.Write(a.Tokens); }
                writer.Write(state.Objects.Length);
                foreach (var o in state.Objects.OrderBy(x => x.Id, StringComparer.Ordinal))
                { WriteText(writer, o.Id); writer.Write(o.X); writer.Write(o.Y); writer.Write(o.Opened); }
                writer.Write(state.Receipts.Length);
                foreach (var r in state.Receipts.OrderBy(x => x.Revision))
                { WriteText(writer, r.Principal); WriteText(writer, r.Id); WriteText(writer, r.Fingerprint); writer.Write(r.Revision); }
                if (state.SchemaVersion >= Snapshot.WorkSchema)
                {
                    writer.Write(state.RuleClock.Numerator); writer.Write(state.RuleClock.Denominator);
                    WriteText(writer, DiceStream.MappingVersion);
                    byte[] work = new WorkLedgerCodec().Encode(state.Work,state.SchemaVersion>=Snapshot.InventorySchema?2:1);
                    writer.Write(work.Length); writer.Write(work);
                }
                if (state.SchemaVersion >= Snapshot.CropSchema) CropRecordCodec.Write(writer,state);
                if (state.SchemaVersion >= Snapshot.InventorySchema) InventoryRecordCodec.Write(writer,state);
                if (state.SchemaVersion >= Snapshot.VesselSchema) WaterVesselCodec.Write(writer,state);
                if (state.SchemaVersion >= Snapshot.MovableVesselSchema) VesselHandlingCodec.Write(writer,state);
                if (state.SchemaVersion >= Snapshot.EncounterSchema) FixedEncounterCodec.Write(writer,state);
                if (state.SchemaVersion >= Snapshot.ActorLifeSchema) ActorLifeCodec.Write(writer,state);
                if (state.SchemaVersion >= Snapshot.ClubAttackSchema) ClubAttackCodec.Write(writer,state);
                if (state.SchemaVersion >= Snapshot.PostureSchema) ActorMovementCodec.Write(writer,state);
                if (state.SchemaVersion >= Snapshot.TacticalMovementSchema) TacticalMovementCodec.Write(writer,state);
                if (state.SchemaVersion >= Snapshot.ConditionSchema) {
                    writer.Write(state.Conditions.Length);
                    foreach (var journal in state.Conditions.OrderBy(x => x.Target, StringComparer.Ordinal)) {
                        byte[] component = new ConditionJournalCodec().Encode(journal); writer.Write(component.Length); writer.Write(component);
                    }
                }
                if (state.SchemaVersion >= Snapshot.SharedWorldSchema) {
                    writer.Write(state.ClosedEncounters.Length);
                    foreach (var closed in state.ClosedEncounters.OrderBy(x => x.Encounter.StartRevisions[0])) {
                        FixedEncounterCodec.WriteRecord(writer, closed.Encounter, state.SchemaVersion >= Snapshot.CalendarCombatSchema); writer.Write(closed.ClosedRevision);
                        writer.Write(closed.ClosedAt.Numerator); writer.Write(closed.ClosedAt.Denominator); WriteText(writer, closed.Reason);
                    }
                    WorldScheduleCodec.Write(writer, state);
                }
                if (state.SchemaVersion >= Snapshot.FormulaWorkSchema) FormulaWorkCodec.Write(writer, state);
                if (state.SchemaVersion >= Snapshot.CraftingConsequenceSchema) CraftingConsequenceCodec.Write(writer, state);
                if (state.SchemaVersion >= Snapshot.RepairWorkSchema) RepairWorkCodec.Write(writer, state);
                if (state.SchemaVersion >= Snapshot.ManufacturingSchema) ManufacturingCodec.Write(writer,state);
                if (state.SchemaVersion >= Snapshot.SupplyCacheSchema) SupplyCacheCodec.Write(writer,state);
                if (state.SchemaVersion >= Snapshot.PortableEquipmentSchema) PortableEquipmentCodec.Write(writer,state);
                if (state.SchemaVersion >= Snapshot.CharacterAdvancementSchema) CharacterAdvancementCodec.Write(writer,state);
                if (state.SchemaVersion >= Snapshot.RepeatingCrossbowSchema) RangedCombatCodec.Write(writer,state);
                if (state.SchemaVersion >= Snapshot.PeriodicRiderSchema) PeriodicRiderCodec.Write(writer,state);
                if (state.SchemaVersion >= Snapshot.OverwatchSchema) OverwatchCodec.Write(writer,state);
                if (state.SchemaVersion >= Snapshot.OverwatchExecutionSchema) OverwatchExecutionCodec.Write(writer,state);
                if (state.SchemaVersion >= Snapshot.SoldierInitialBuildSchema) CharacterAdvancementCodec.WriteInitialBuild(writer,state);
                if (state.SchemaVersion >= Snapshot.SoldierTacticalTechniquesSchema) SoldierTacticalFeatureCodec.Write(writer,state);
                if (state.SchemaVersion >= Snapshot.FishingTrapLegacySchema) FishingTrapCodec.Write(writer,state);
                if (state.SchemaVersion >= Snapshot.ExpeditionAssignmentSchema) ExpeditionAssignmentCodec.Write(writer,state);
                if (state.SchemaVersion >= Snapshot.OffCalendarActivitySchema) WorldActivityCodec.Write(writer, state);
                if (state.SchemaVersion >= Snapshot.HarvestSchema) HarvestCodec.Write(writer, state, state.SchemaVersion);
                if (state.SchemaVersion >= Snapshot.MiningSchema) MiningCodec.Write(writer, state);
                if (state.SchemaVersion >= Snapshot.ProspectingSchema) ProspectingCodec.Write(writer, state);
                if (state.SchemaVersion >= Snapshot.MiningAssaySchema) MiningAssayCodec.Write(writer, state);
                if (state.SchemaVersion >= Snapshot.DestructiveMiningAssaySchema) DestructiveMiningAssayCodec.Write(writer, state);
                if (state.SchemaVersion >= Snapshot.MineralPreparationSchema) MineralPreparationCodec.Write(writer,state);
                if (state.SchemaVersion >= Snapshot.MiningToolCandidateSchema) MiningToolCodec.Write(writer,state);
                if (state.SchemaVersion >= Snapshot.OrdinaryReceptacleSchema) OrdinaryReceptacleCodec.Write(writer,state);
                if (state.SchemaVersion >= Snapshot.ObservationSchema) ObservationCodec.Write(writer,state);
                if (state.SchemaVersion >= Snapshot.ExpeditionRouteSchema) ExpeditionRouteTravelCodec.Write(writer,state);
                if (state.SchemaVersion >= Snapshot.RouteObservationSchema) ExpeditionRouteSpatialCodec.Write(writer,state);
                if (state.SchemaVersion >= Snapshot.RouteMappingSchema) ExpeditionRouteMappingCodec.Write(writer,state);
                if (state.SchemaVersion >= Snapshot.HuntingTrapSchema) HuntingTrapCodec.Write(writer,state);
                if (state.SchemaVersion >= Snapshot.BuriedCacheSchema) CacheExcavationCodec.Write(writer,state);
                if (state.SchemaVersion >= Snapshot.ReadyActionSchema) ReadyActionCodec.Write(writer,state);
                if (state.SchemaVersion >= Snapshot.RouteMappingWorkSchema) ExpeditionRouteMappingWorkCodec.Write(writer,state);
                if (state.SchemaVersion >= Snapshot.RouteReconnaissanceSchema) ExpeditionRouteReconnaissanceCodec.Write(writer,state);
                if (state.SchemaVersion >= Snapshot.DailyProvisioningSchema) ExpeditionProvisioningCodec.Write(writer,state);
                if (state.SchemaVersion >= Snapshot.ExpeditionPressureSchema) ExpeditionPressureCodec.Write(writer,state);
                if (state.SchemaVersion >= Snapshot.ExpeditionCampUseSchema) ExpeditionCampCodec.Write(writer,state);
                if (state.SchemaVersion >= Snapshot.TemporaryCampConstructionSchema) TemporaryCampConstructionCodec.Write(writer,state);
                if (state.SchemaVersion >= Snapshot.PortableStorageSchema) PortableEquipmentCodec.WriteStorageProfiles(writer,state);
                if (state.SchemaVersion >= Snapshot.Recipe347Schema) Recipe347Codec.Write(writer,state);
                if (state.SchemaVersion >= Snapshot.HarvestPreservationSchema) HarvestRequirementWorkCodec.Write(writer,state);
                if (state.SchemaVersion >= Snapshot.HarvestPreservationTreatmentSchema) HarvestPreservationTreatmentCodec.Write(writer,state);
                if (state.SchemaVersion >= Snapshot.HarvestPreservationExposureSchema) HarvestPreservationEvidenceCodec.Write(writer,state);
                if (state.SchemaVersion >= Snapshot.HavenAppraisalSchema) HavenAppraisalCodec.Write(writer,state);
                if (state.SchemaVersion >= Snapshot.HavenSaleSchema) HavenSaleCodec.Write(writer,state);
                if (state.SchemaVersion >= Snapshot.HavenMealSchema) HavenMealPurchaseCodec.Write(writer,state);
                if (state.SchemaVersion >= Snapshot.ExpeditionBillSchema) ExpeditionBillCodec.Write(writer,state);
                if (state.SchemaVersion >= Snapshot.ExpeditionEpisodeCloseSchema) ExpeditionEpisodeCloseCodec.Write(writer,state.ExpeditionEpisodeClose);
                if (state.SchemaVersion >= Snapshot.NextCharterPlanSchema) NextCharterPlanCodec.Write(writer,state);
                if (state.SchemaVersion >= Snapshot.NextCharterAgreementSchema) NextCharterAgreementCodec.Write(writer,state.NextCharterAgreement);
                if (state.SchemaVersion >= Snapshot.CharterAttemptSchema) CharterAttemptCodec.Write(writer,state.CharterAttempt);
                if (state.SchemaVersion >= Snapshot.LaterEncounterSchema) LaterEncounterCodec.Write(writer,state.LaterEncounter);
                if (state.SchemaVersion >= Snapshot.ReinforcementSchema) ReinforcementCodec.Write(writer,state.Reinforcement);
                if (state.SchemaVersion >= Snapshot.RetreatSchema) RetreatCodec.Write(writer,state.Retreat);
                if (state.SchemaVersion >= Snapshot.ReengagementSchema) ReengagementCodec.Write(writer, state.Reengagement);
                if (state.SchemaVersion == Snapshot.SurpriseEntrySchema) SurpriseEntryCodec.Write(writer, state.SurpriseEntry);
                if (state.ExplorationSearch != null) ExplorationSearchCodec.Write(writer, state.ExplorationSearch);
                if (state.ExplorationHide != null) ExplorationHideCodec.Write(writer, state.ExplorationHide);
                if (state.BloodSpecimen != null) ConnectedBloodSpecimenCodec.Write(writer, state.BloodSpecimen);
                if (state.ConnectedBatch != null) ConnectedRecipe4BatchCodec.Write(writer, state.ConnectedBatch);
                if (state.ConnectedCarriedVial)
                    writer.Write(state.ConnectedCompanionStabilization ? ConnectedVialRules.StabilizationMarker
                        : state.ConnectedCompanionDose ? ConnectedVialRules.CompanionMarker
                        : state.ConnectedTacticalVial ? ConnectedVialRules.TacticalMarker
                        : state.ConnectedStowedVial ? ConnectedVialRules.StowMarker : ConnectedVialRules.Marker);
                if (state.ConnectedCompanionStabilization) CompanionStabilizationCodec.Write(writer, state.CompanionStabilizations);
                if (state.ConnectedWoundTreatment) {
                    writer.Write(WoundTreatmentStation.Marker);
                    WoundTreatmentCodec.Write(writer, state.WoundTreatments);
                }
                if (state.ConnectedConsumeDecay) {
                    writer.Write(ConsumeDecaySite.Marker);
                    ConsumeDecayCodec.Write(writer, state.ConsumeDecay);
                }
                if (state.ConnectedShortRest) {
                    writer.Write(ShortRestBerth.Marker);
                    ShortRestCodec.Write(writer, state.ShortRests);
                }
                if (state.ConnectedFleshWarden) {
                    writer.Write(FleshWardenProfile.Marker);
                    FleshWardenCodec.Write(writer, state.FleshWarden);
                }
                if (state.ConnectedClericRp) {
                    writer.Write(ClericRpProfile.Marker);
                    ResonanceCodec.Write(writer, state);
                }
                if (state.ConnectedClericRepertoire) {
                    writer.Write(ClericRepertoireProfile.Marker);
                    SpellRepertoireCodec.Write(writer, state);
                }
                if (state.ConnectedFrightened) {
                    writer.Write(FrightenedProfile.Marker);
                    FrightenedCodec.Write(writer, state);
                }
                if (state.ConnectedClericSettlement) {
                    writer.Write(ClericSettlementProfile.Marker);
                    ClericSettlementCodec.Write(writer, state);
                }
                if (state.ConnectedClericCasting) {
                    writer.Write(SpellCastingProfile.Marker);
                    SpellCastingCodec.Write(writer, state);
                }
                if (state.ConnectedClericLongRest) {
                    writer.Write(ClericLongRestProfile.Marker);
                    ClericLongRestCodec.Write(writer, state);
                }
                if (state.PostRecoveryEncounter != null) {
                    writer.Write(PostRecoveryProfile.Marker);
                    PostRecoveryEncounterCodec.Write(writer, state.PostRecoveryEncounter);
                }
                if (state.BishopEntry != null) {
                    writer.Write(BishopProfile.Marker);
                    BishopEntryCodec.Write(writer,state.BishopEntry);
                }
                if (state.DeclaredGeometry != null) {
                    writer.Write(DeclaredGeometryProfile.Marker);
                    DeclaredGeometryCodec.Write(writer, state.DeclaredGeometry);
                }
                if (state.FerryWraith != null) {
                    writer.Write(FerryWraithProfile.Marker);
                    FerryWraithCodec.Write(writer,state);
                }
                if (state.Consecration != null) {
                    writer.Write(ConsecrationProfile.Marker);
                    ConsecrationCodec.Write(writer,state.Consecration);
                }
                writer.Flush(); payload = stream.ToArray();
            }
            if (payload.Length + 32 > Limit(state.WireSchemaVersion)) throw new InvalidDataException("Save exceeds schema size limit.");
            using (var hash = SHA256.Create()) return payload.Concat(hash.ComputeHash(payload)).ToArray();
        }
        public Snapshot Decode(byte[] data)
        {
            if (data == null || data.Length < 40 || data.Length > ConditionMaxBytes) throw new InvalidDataException("Invalid save length.");
            int length = data.Length - 32;
            using (var hash = SHA256.Create())
                if (!hash.ComputeHash(data, 0, length).SequenceEqual(data.Skip(length))) throw new InvalidDataException("Save checksum mismatch.");
            try
            {
                using (var stream = new MemoryStream(data, 0, length, false))
                using (var reader = new BinaryReader(stream, Utf8))
                {
                    if (reader.ReadInt32() != Magic) throw new InvalidDataException("Unsupported save format.");
                    int wireSchema = reader.ReadInt32();
                    bool bishopEnvelope = wireSchema == Snapshot.BishopEntrySchema || wireSchema == Snapshot.DeclaredGeometrySchema || wireSchema == Snapshot.FerryWraithSchema || wireSchema == Snapshot.ConsecrationSchema;
                    // The selected ordinary observation extensions use the schema51 feature payload.
                    int schema = wireSchema switch {
                        Snapshot.ExplorationSearchSchema => Snapshot.ObservationSchema,
                        Snapshot.ExplorationHideSchema => Snapshot.ObservationSchema,
                        Snapshot.ConnectedExplorationObservationSchema => Snapshot.SurpriseEntrySchema,
                        Snapshot.ConnectedBloodSpecimenSchema => Snapshot.SurpriseEntrySchema,
                        Snapshot.ConnectedRecipe4BatchSchema => Snapshot.SurpriseEntrySchema,
                        Snapshot.ConnectedCarriedVialSchema => Snapshot.SurpriseEntrySchema,
                        Snapshot.ConnectedStowedVialSchema => Snapshot.SurpriseEntrySchema,
                        Snapshot.ConnectedTacticalVialSchema => Snapshot.SurpriseEntrySchema,
                        Snapshot.ConnectedCompanionDoseSchema => Snapshot.SurpriseEntrySchema,
                        Snapshot.ConnectedCompanionStabilizationSchema => Snapshot.SurpriseEntrySchema,
                        Snapshot.ConnectedWoundTreatmentSchema => Snapshot.SurpriseEntrySchema,
                        Snapshot.ConnectedConsumeDecaySchema => Snapshot.SurpriseEntrySchema,
                        Snapshot.ConnectedShortRestSchema => Snapshot.SurpriseEntrySchema,
                        Snapshot.ConnectedFleshWardenSchema => Snapshot.SurpriseEntrySchema,
                        Snapshot.ConnectedClericRpSchema => Snapshot.SurpriseEntrySchema,
                        Snapshot.ConnectedClericRepertoireSchema => Snapshot.SurpriseEntrySchema,
                        Snapshot.ConnectedFrightenedSchema => Snapshot.SurpriseEntrySchema,
                        Snapshot.ConnectedClericSettlementSchema => Snapshot.SurpriseEntrySchema,
                        Snapshot.ConnectedClericCastingSchema => Snapshot.SurpriseEntrySchema,
                        Snapshot.ConnectedClericLongRestSchema => Snapshot.SurpriseEntrySchema,
                        Snapshot.PostRecoveryEncounterSchema => Snapshot.SurpriseEntrySchema,
                        Snapshot.BishopEntrySchema => Snapshot.SurpriseEntrySchema,
                        Snapshot.DeclaredGeometrySchema => Snapshot.SurpriseEntrySchema,
                        Snapshot.FerryWraithSchema => Snapshot.SurpriseEntrySchema,
                        Snapshot.ConsecrationSchema => Snapshot.SurpriseEntrySchema,
                        _ => wireSchema
                    };
                    if (data.Length > Limit(wireSchema)) throw new InvalidDataException("Save exceeds schema size limit.");
                    if (schema != Snapshot.ExpeditionPressureSchema && schema != Snapshot.ExpeditionPressureLifecycleSchema && schema != Snapshot.ExpeditionCampUseSchema && schema != Snapshot.TemporaryCampConstructionSchema && schema != Snapshot.PortableStorageSchema && schema != Snapshot.Recipe347Schema && schema != Snapshot.PortableCountedLotSchema && schema != Snapshot.HarvestPreservationSchema && schema != Snapshot.HarvestPreservationTreatmentSchema && schema != Snapshot.HarvestPreservationExposureSchema && schema != Snapshot.HavenCareSchema && schema != Snapshot.MoraleRestSchema && schema != Snapshot.ExpeditionStrainRecoverySchema && schema != Snapshot.RestDebtSchema && schema != Snapshot.DailyProvisioningSchema && schema != Snapshot.RouteReconnaissanceSchema && schema != Snapshot.RouteMappingWorkSchema && schema != Snapshot.ReadyActionSchema && schema != Snapshot.HuntingTrapSchema && schema != Snapshot.DodgeSchema && schema != Snapshot.RouteMappingSchema && schema != Snapshot.RouteObservationSchema && schema != Snapshot.ExpeditionRouteSchema && schema != Snapshot.ObservationSchema && schema != Snapshot.OrdinaryReceptacleSchema && schema != Snapshot.MiningToolCandidateSchema && schema != Snapshot.MineralPreparationSchema && schema != Snapshot.MiningExpeditionAssignmentSchema && schema != Snapshot.DestructiveMiningAssaySchema && schema != Snapshot.MiningAssaySchema && schema != Snapshot.ProspectingSchema && schema != Snapshot.Schema && schema != Snapshot.WorkSchema && schema != Snapshot.CropSchema && schema != Snapshot.InventorySchema && schema != Snapshot.VesselSchema && schema != Snapshot.MovableVesselSchema && schema != Snapshot.EncounterSchema && schema != Snapshot.ActorLifeSchema && schema != Snapshot.ClubAttackSchema && schema != Snapshot.PostureSchema && schema != Snapshot.TacticalMovementSchema && schema != Snapshot.ConditionSchema && schema != Snapshot.SharedWorldSchema && schema != Snapshot.CalendarCombatSchema && schema != Snapshot.FormulaWorkSchema && schema != Snapshot.CraftingConsequenceSchema && schema != Snapshot.RepairWorkSchema && schema != Snapshot.ManufacturingSchema && schema != Snapshot.SupplyCacheSchema && schema != Snapshot.PortableEquipmentSchema && schema != Snapshot.CharacterAdvancementSchema && schema != Snapshot.RepeatingCrossbowSchema && schema != Snapshot.PeriodicRiderSchema && schema != Snapshot.SharedBonusActionSchema && schema != Snapshot.OverwatchSchema && schema != Snapshot.OverwatchExecutionSchema && schema != Snapshot.SoldierInitialLoadoutSchema && schema != Snapshot.SoldierInitialBuildSchema && schema != Snapshot.SoldierTacticalTechniquesSchema && schema != Snapshot.CharacterAdvancementHistorySchema && schema != Snapshot.TacticalAssessmentSchema && schema != Snapshot.CommandStepSchema && schema != Snapshot.SuppressionFireSchema && schema != Snapshot.DefensiveFormationSchema && schema != Snapshot.FishingTrapLegacySchema && schema != Snapshot.FishingTrapBaitSchema && schema != Snapshot.FishingTrapSchema && schema != Snapshot.FishingStockSchema && schema != Snapshot.ExpeditionAssignmentSchema && schema != Snapshot.OffCalendarActivitySchema && schema != Snapshot.HarvestSchema && schema != Snapshot.HarvestManifestSchema && schema != Snapshot.MiningSchema && schema != Snapshot.BuriedCacheSchema && schema != Snapshot.SharedCharacterAdvancementSchema && schema != Snapshot.MiningAssistantSchema && schema != Snapshot.HavenAppraisalSchema && schema != Snapshot.HavenSaleSchema && schema != Snapshot.HavenMealSchema && schema != Snapshot.ExpeditionBillSchema && schema != Snapshot.ExpeditionEpisodeCloseSchema && schema != Snapshot.NextCharterPlanSchema && schema != Snapshot.NextCharterAgreementSchema && schema != Snapshot.CharterAttemptSchema && schema != Snapshot.LaterEncounterSchema && schema != Snapshot.ReinforcementSchema && schema != Snapshot.RetreatSchema && schema != Snapshot.ReengagementSchema && schema != Snapshot.SurpriseEntrySchema)
                        throw new InvalidDataException("Unsupported save schema.");
                    string fingerprint = ReadText(reader);
                    if (ReadText(reader) != RandomV1.Algorithm) throw new InvalidDataException("Unsupported RNG version.");
                    var s = new Snapshot { SchemaVersion = schema, ContentFingerprint = fingerprint, TestOnly = ReadBool(reader), Revision = reader.ReadInt64(),
                        Clock = reader.ReadInt64(), RandomState = reader.ReadUInt32() };
                    s.Actors = new ActorState[ReadCount(reader, 64)];
                    for (int i = 0; i < s.Actors.Length; i++) s.Actors[i] = new ActorState {
                        Id = ReadText(reader), X = reader.ReadInt32(), Y = reader.ReadInt32(), Tokens = reader.ReadInt32() };
                    s.Objects = new ObjectState[ReadCount(reader, 64)];
                    for (int i = 0; i < s.Objects.Length; i++) s.Objects[i] = new ObjectState {
                        Id = ReadText(reader), X = reader.ReadInt32(), Y = reader.ReadInt32(), Opened = ReadBool(reader) };
                    s.Receipts = new CommandReceipt[ReadCount(reader, Validation.MaxReceipts)];
                    for (int i = 0; i < s.Receipts.Length; i++) s.Receipts[i] = new CommandReceipt {
                        Principal = ReadText(reader), Id = ReadText(reader), Fingerprint = ReadText(reader), Revision = reader.ReadInt64() };
                    if (schema >= Snapshot.WorkSchema)
                    {
                        s.RuleClock = new RuleTime(reader.ReadInt64(), reader.ReadInt64());
                        if (ReadText(reader) != DiceStream.MappingVersion) throw new InvalidDataException("Unsupported dice mapping.");
                        int workLength = ReadCount(reader, WorkLedgerCodec.MaxBytes);
                        byte[] work = reader.ReadBytes(workLength);
                        if (work.Length != workLength) throw new EndOfStreamException();
                        s.Work = new WorkLedgerCodec().Decode(work,schema>=Snapshot.InventorySchema?2:1);
                    }
                    if (schema >= Snapshot.CropSchema) CropRecordCodec.Read(reader,s);
                    if (schema >= Snapshot.InventorySchema) InventoryRecordCodec.Read(reader,s);
                    if (schema >= Snapshot.VesselSchema) WaterVesselCodec.Read(reader,s);
                    if (schema >= Snapshot.MovableVesselSchema) VesselHandlingCodec.Read(reader,s);
                    if (schema >= Snapshot.EncounterSchema) FixedEncounterCodec.Read(reader,s);
                    if (schema >= Snapshot.ActorLifeSchema) ActorLifeCodec.Read(reader,s);
                    if (schema >= Snapshot.ClubAttackSchema) ClubAttackCodec.Read(reader,s);
                    if (schema >= Snapshot.PostureSchema) ActorMovementCodec.Read(reader,s);
                    if (schema >= Snapshot.TacticalMovementSchema) TacticalMovementCodec.Read(reader,s);
                    if (schema >= Snapshot.ConditionSchema) {
                        s.Conditions = new ConditionJournal[ReadCount(reader, Snapshot.MaxActors)];
                        for (int i = 0; i < s.Conditions.Length; i++) {
                            int count = ReadCount(reader, ConditionJournalCodec.MaxBytes); byte[] component = reader.ReadBytes(count);
                            if (component.Length != count) throw new EndOfStreamException();
                            s.Conditions[i] = new ConditionJournalCodec().Decode(component);
                        }
                    }
                    if (schema >= Snapshot.SharedWorldSchema) {
                        s.ClosedEncounters = new ClosedEncounterRecord[ReadCount(reader, EncounterHistory.MaxClosedEncounters)];
                        for (int i = 0; i < s.ClosedEncounters.Length; i++)
                            s.ClosedEncounters[i] = new ClosedEncounterRecord(FixedEncounterCodec.ReadRecord(reader, schema >= Snapshot.CalendarCombatSchema), reader.ReadInt64(),
                                new RuleTime(reader.ReadInt64(), reader.ReadInt64()), ReadText(reader));
                        WorldScheduleCodec.Read(reader, s);
                    }
                    if (schema >= Snapshot.FormulaWorkSchema) FormulaWorkCodec.Read(reader, s);
                    if (schema >= Snapshot.CraftingConsequenceSchema) CraftingConsequenceCodec.Read(reader, s);
                    if (schema >= Snapshot.RepairWorkSchema) RepairWorkCodec.Read(reader, s);
                    if(schema >= Snapshot.ManufacturingSchema)ManufacturingCodec.Read(reader,s);
                    if(schema >= Snapshot.SupplyCacheSchema)SupplyCacheCodec.Read(reader,s);
                    if(schema >= Snapshot.PortableEquipmentSchema)PortableEquipmentCodec.Read(reader,s);
                    if(schema >= Snapshot.CharacterAdvancementSchema)CharacterAdvancementCodec.Read(reader,s);
                    if(schema >= Snapshot.RepeatingCrossbowSchema)RangedCombatCodec.Read(reader,s);
                    if(schema >= Snapshot.PeriodicRiderSchema)PeriodicRiderCodec.Read(reader,s);
                    if(schema >= Snapshot.OverwatchSchema)OverwatchCodec.Read(reader,s);
                    if(schema >= Snapshot.OverwatchExecutionSchema)OverwatchExecutionCodec.Read(reader,s);
                    if(schema >= Snapshot.SoldierInitialBuildSchema)CharacterAdvancementCodec.ReadInitialBuild(reader,s);
                    if(schema >= Snapshot.SoldierTacticalTechniquesSchema)SoldierTacticalFeatureCodec.Read(reader,s);
                    if(schema >= Snapshot.FishingTrapLegacySchema)FishingTrapCodec.Read(reader,s,schema);
                    if(schema >= Snapshot.ExpeditionAssignmentSchema)ExpeditionAssignmentCodec.Read(reader,s);
                    if(schema >= Snapshot.OffCalendarActivitySchema)WorldActivityCodec.Read(reader,s);
                    if(schema >= Snapshot.HarvestSchema)HarvestCodec.Read(reader,s,schema);
                    if(schema >= Snapshot.MiningSchema)MiningCodec.Read(reader,s);
                    if(schema >= Snapshot.ProspectingSchema)ProspectingCodec.Read(reader,s);
                    if(schema >= Snapshot.MiningAssaySchema)MiningAssayCodec.Read(reader,s);
                    if(schema >= Snapshot.DestructiveMiningAssaySchema)DestructiveMiningAssayCodec.Read(reader,s);
                    if(schema >= Snapshot.MineralPreparationSchema)MineralPreparationCodec.Read(reader,s);
                    if(schema >= Snapshot.MiningToolCandidateSchema)MiningToolCodec.Read(reader,s);
                    if(schema >= Snapshot.OrdinaryReceptacleSchema)OrdinaryReceptacleCodec.Read(reader,s);
                    if(schema >= Snapshot.ObservationSchema)ObservationCodec.Read(reader,s);
                    if(schema >= Snapshot.ExpeditionRouteSchema)ExpeditionRouteTravelCodec.Read(reader,s);
                    if(schema >= Snapshot.RouteObservationSchema)ExpeditionRouteSpatialCodec.Read(reader,s);
                    if(schema >= Snapshot.RouteMappingSchema)ExpeditionRouteMappingCodec.Read(reader,s);
                    if(schema >= Snapshot.HuntingTrapSchema)HuntingTrapCodec.Read(reader,s);
                    if(schema >= Snapshot.BuriedCacheSchema)CacheExcavationCodec.Read(reader,s);
                    if(schema >= Snapshot.ReadyActionSchema)ReadyActionCodec.Read(reader,s);
                    if(schema >= Snapshot.RouteMappingWorkSchema)ExpeditionRouteMappingWorkCodec.Read(reader,s);
                    if(schema >= Snapshot.RouteReconnaissanceSchema)ExpeditionRouteReconnaissanceCodec.Read(reader,s);
                    if(schema >= Snapshot.DailyProvisioningSchema)ExpeditionProvisioningCodec.Read(reader,s,wireSchema == Snapshot.ConnectedClericLongRestSchema || (wireSchema == Snapshot.PostRecoveryEncounterSchema || bishopEnvelope));
                    if(schema >= Snapshot.ExpeditionPressureSchema)ExpeditionPressureCodec.Read(reader,s);
                    if(schema >= Snapshot.ExpeditionCampUseSchema)ExpeditionCampCodec.Read(reader,s);
                    if(schema >= Snapshot.TemporaryCampConstructionSchema)TemporaryCampConstructionCodec.Read(reader,s);
                    if(schema >= Snapshot.PortableStorageSchema)PortableEquipmentCodec.ReadStorageProfiles(reader,s);
                    if(schema >= Snapshot.Recipe347Schema)Recipe347Codec.Read(reader,s);
                    if(schema >= Snapshot.HarvestPreservationSchema)HarvestRequirementWorkCodec.Read(reader,s);
                    if(schema >= Snapshot.HarvestPreservationTreatmentSchema)HarvestPreservationTreatmentCodec.Read(reader,s);
                    if(schema >= Snapshot.HarvestPreservationExposureSchema)HarvestPreservationEvidenceCodec.Read(reader,s);
                    if(schema >= Snapshot.HavenAppraisalSchema)HavenAppraisalCodec.Read(reader,s);
                    if(schema >= Snapshot.HavenSaleSchema)HavenSaleCodec.Read(reader,s);
                    if(schema >= Snapshot.HavenMealSchema)HavenMealPurchaseCodec.Read(reader,s);
                    if(schema >= Snapshot.ExpeditionBillSchema)ExpeditionBillCodec.Read(reader,s);
                    if(schema >= Snapshot.ExpeditionEpisodeCloseSchema)s.ExpeditionEpisodeClose=ExpeditionEpisodeCloseCodec.Read(reader);
                    if(schema >= Snapshot.NextCharterPlanSchema)NextCharterPlanCodec.Read(reader,s);
                    if(schema >= Snapshot.NextCharterAgreementSchema)s.NextCharterAgreement=NextCharterAgreementCodec.Read(reader,s);
                    if(schema >= Snapshot.CharterAttemptSchema)s.CharterAttempt=CharterAttemptCodec.Read(reader);
                    if(schema >= Snapshot.LaterEncounterSchema)s.LaterEncounter=LaterEncounterCodec.Read(reader);
                    if(schema >= Snapshot.ReinforcementSchema)ReinforcementCodec.Read(reader,s);
                    if(schema >= Snapshot.RetreatSchema)s.Retreat=RetreatCodec.Read(reader);
                    if (schema >= Snapshot.ReengagementSchema) ReengagementCodec.Read(reader, s);
                    if (schema == Snapshot.SurpriseEntrySchema) SurpriseEntryCodec.Read(reader, s);
                    s.ConnectedClericLongRest = wireSchema == Snapshot.ConnectedClericLongRestSchema || (wireSchema == Snapshot.PostRecoveryEncounterSchema || bishopEnvelope);
                    s.ConnectedClericCasting = s.ConnectedClericLongRest || wireSchema == Snapshot.ConnectedClericCastingSchema;
                    s.ConnectedClericSettlement = s.ConnectedClericCasting || wireSchema == Snapshot.ConnectedClericSettlementSchema;
                    s.ConnectedFrightened = s.ConnectedClericSettlement || wireSchema == Snapshot.ConnectedFrightenedSchema;
                    s.ConnectedClericRepertoire = s.ConnectedFrightened || wireSchema == Snapshot.ConnectedClericRepertoireSchema;
                    s.ConnectedClericRp = s.ConnectedClericRepertoire || wireSchema == Snapshot.ConnectedClericRpSchema;
                    s.ConnectedFleshWarden = wireSchema == Snapshot.ConnectedFleshWardenSchema;
                    s.ConnectedShortRest = s.ConnectedFleshWarden || wireSchema == Snapshot.ConnectedShortRestSchema;
                    s.ConnectedConsumeDecay = s.ConnectedShortRest || wireSchema == Snapshot.ConnectedConsumeDecaySchema;
                    s.ConnectedWoundTreatment = s.ConnectedConsumeDecay || wireSchema == Snapshot.ConnectedWoundTreatmentSchema;
                    bool carriedVialEnvelope = s.ConnectedWoundTreatment || wireSchema == Snapshot.ConnectedCarriedVialSchema
                        || wireSchema == Snapshot.ConnectedStowedVialSchema || wireSchema == Snapshot.ConnectedTacticalVialSchema
                        || wireSchema == Snapshot.ConnectedCompanionDoseSchema || wireSchema == Snapshot.ConnectedCompanionStabilizationSchema;
                    if (wireSchema == Snapshot.ExplorationSearchSchema || wireSchema == Snapshot.ExplorationHideSchema
                        || wireSchema == Snapshot.ConnectedExplorationObservationSchema || wireSchema == Snapshot.ConnectedBloodSpecimenSchema
                        || wireSchema == Snapshot.ConnectedRecipe4BatchSchema || carriedVialEnvelope || s.ConnectedClericRp)
                        ExplorationSearchCodec.Read(reader, s);
                    if (wireSchema == Snapshot.ExplorationHideSchema || wireSchema == Snapshot.ConnectedExplorationObservationSchema
                        || wireSchema == Snapshot.ConnectedBloodSpecimenSchema || wireSchema == Snapshot.ConnectedRecipe4BatchSchema
                        || carriedVialEnvelope || s.ConnectedClericRp)
                        ExplorationHideCodec.Read(reader, s);
                    if (wireSchema == Snapshot.ConnectedBloodSpecimenSchema || wireSchema == Snapshot.ConnectedRecipe4BatchSchema
                        || carriedVialEnvelope || s.ConnectedClericRp)
                        s.BloodSpecimen = ConnectedBloodSpecimenCodec.Read(reader);
                    if (wireSchema == Snapshot.ConnectedRecipe4BatchSchema || carriedVialEnvelope || s.ConnectedClericRp)
                        s.ConnectedBatch = ConnectedRecipe4BatchCodec.Read(reader);
                    if (carriedVialEnvelope) {
                        s.ConnectedCompanionStabilization = s.ConnectedWoundTreatment || wireSchema == Snapshot.ConnectedCompanionStabilizationSchema;
                        s.ConnectedCompanionDose = s.ConnectedCompanionStabilization || wireSchema == Snapshot.ConnectedCompanionDoseSchema;
                        s.ConnectedTacticalVial = s.ConnectedCompanionDose || wireSchema == Snapshot.ConnectedTacticalVialSchema;
                        s.ConnectedStowedVial = s.ConnectedTacticalVial || wireSchema == Snapshot.ConnectedStowedVialSchema;
                        byte marker = s.ConnectedCompanionStabilization ? ConnectedVialRules.StabilizationMarker
                            : s.ConnectedCompanionDose ? ConnectedVialRules.CompanionMarker
                            : s.ConnectedTacticalVial ? ConnectedVialRules.TacticalMarker
                            : s.ConnectedStowedVial ? ConnectedVialRules.StowMarker : ConnectedVialRules.Marker;
                        if (reader.ReadByte() != marker) throw new InvalidDataException("Invalid carried vial marker.");
                        s.ConnectedCarriedVial = true;
                    }
                    if (s.ConnectedCompanionStabilization) s.CompanionStabilizations = CompanionStabilizationCodec.Read(reader);
                    if (s.ConnectedWoundTreatment) {
                        if (reader.ReadByte() != WoundTreatmentStation.Marker) throw new InvalidDataException("Invalid Wound treatment marker.");
                        s.WoundTreatments = WoundTreatmentCodec.Read(reader);
                    }
                    if (s.ConnectedConsumeDecay) {
                        if (reader.ReadByte() != ConsumeDecaySite.Marker) throw new InvalidDataException("Invalid Consume Decay marker.");
                        s.ConsumeDecay = ConsumeDecayCodec.Read(reader);
                    }
                    if (s.ConnectedShortRest) {
                        if (reader.ReadByte() != ShortRestBerth.Marker) throw new InvalidDataException("Invalid Short Rest marker.");
                        s.ShortRests = ShortRestCodec.Read(reader);
                    }
                    if (s.ConnectedFleshWarden) {
                        if (reader.ReadByte() != FleshWardenProfile.Marker) throw new InvalidDataException("Invalid Flesh Warden marker.");
                        s.FleshWarden = FleshWardenCodec.Read(reader);
                    }
                    if (s.ConnectedClericRp) {
                        if (reader.ReadByte() != ClericRpProfile.Marker) throw new InvalidDataException("Invalid Cleric RP marker.");
                        ResonanceCodec.Read(reader, s);
                    }
                    if (s.ConnectedClericRepertoire) {
                        if (reader.ReadByte() != ClericRepertoireProfile.Marker) throw new InvalidDataException("Invalid repertoire marker.");
                        SpellRepertoireCodec.Read(reader, s);
                    }
                    if (s.ConnectedFrightened) {
                        if (reader.ReadByte() != FrightenedProfile.Marker) throw new InvalidDataException("Invalid Frightened marker.");
                        FrightenedCodec.Read(reader, s);
                    }
                    if (s.ConnectedClericSettlement) {
                        if (reader.ReadByte() != ClericSettlementProfile.Marker) throw new InvalidDataException("Invalid Cleric settlement marker.");
                        ClericSettlementCodec.Read(reader, s, wireSchema == Snapshot.ConsecrationSchema);
                    }
                    if (s.ConnectedClericCasting) {
                        if (reader.ReadByte() != SpellCastingProfile.Marker) throw new InvalidDataException("Invalid casting marker.");
                        SpellCastingCodec.Read(reader, s,bishopEnvelope);
                    }
                    if (s.ConnectedClericLongRest) {
                        if (reader.ReadByte() != ClericLongRestProfile.Marker) throw new InvalidDataException("Invalid Long Rest marker.");
                        ClericLongRestCodec.Read(reader, s, bishopEnvelope);
                    }
                    if ((wireSchema == Snapshot.PostRecoveryEncounterSchema || bishopEnvelope)) {
                        if (reader.ReadByte() != PostRecoveryProfile.Marker) throw new InvalidDataException("Invalid post-recovery encounter marker.");
                        s.PostRecoveryEncounter = PostRecoveryEncounterCodec.Read(reader);
                    }
                    if (bishopEnvelope) {
                        if (reader.ReadByte() != BishopProfile.Marker) throw new InvalidDataException("Invalid Bishop marker.");
                        s.BishopEntry = BishopEntryCodec.Read(reader);
                    }
                    if (wireSchema == Snapshot.DeclaredGeometrySchema || wireSchema == Snapshot.FerryWraithSchema || wireSchema == Snapshot.ConsecrationSchema) {
                        if (reader.ReadByte() != DeclaredGeometryProfile.Marker) throw new InvalidDataException("Invalid declared geometry marker.");
                        s.DeclaredGeometry = DeclaredGeometryCodec.Read(reader);
                    }
                    if (wireSchema == Snapshot.FerryWraithSchema || wireSchema == Snapshot.ConsecrationSchema) {
                        if (reader.ReadByte() != FerryWraithProfile.Marker) throw new InvalidDataException("Invalid Ferry-Wraith marker.");
                        FerryWraithCodec.Read(reader,s);
                    }
                    if (wireSchema == Snapshot.ConsecrationSchema) {
                        if (reader.ReadByte()!=ConsecrationProfile.Marker)throw new InvalidDataException("Invalid Consecration marker.");
                        s.Consecration=ConsecrationCodec.Read(reader);
                    }
                    if (stream.Position != length) throw new InvalidDataException("Unexpected trailing save data.");
                    Validation.Snapshot(s);
                    if (s.WireSchemaVersion != wireSchema) throw new InvalidDataException("Save envelope does not match its validated layout.");
                    return s;
                }
            }
            catch (Exception ex) when (ex is ArgumentException || ex is EndOfStreamException || ex is OverflowException)
            { throw new InvalidDataException("Malformed save.", ex); }
        }
        internal static int ReadCount(BinaryReader reader, int maximum)
        { int n = reader.ReadInt32(); if (n < 0 || n > maximum) throw new InvalidDataException("Invalid collection length."); return n; }
        internal static bool ReadBool(BinaryReader reader)
        { byte b = reader.ReadByte(); if (b > 1) throw new InvalidDataException("Invalid boolean."); return b == 1; }
        internal static void WriteText(BinaryWriter writer, string value)
        { byte[] bytes = Utf8.GetBytes(value); writer.Write(bytes.Length); writer.Write(bytes); }
        internal static string ReadText(BinaryReader reader)
        {
            int n = ReadCount(reader, 512); byte[] bytes = reader.ReadBytes(n);
            if (bytes.Length != n) throw new EndOfStreamException(); return Utf8.GetString(bytes);
        }
    }

    public interface IFileCommit
    {
        void Commit(string temporary, string destination, string backup);
    }
    public sealed class SameVolumeCommit : IFileCommit
    {
        public void Commit(string temporary, string destination, string backup)
        {
            if (File.Exists(destination)) File.Replace(temporary, destination, backup, true);
            else File.Move(temporary, destination);
        }
    }
    // Single writer, stable local path, completed-command boundaries only. No silent backup fallback.
    public sealed class FileSaveStore
    {
        private readonly SnapshotCodec codec = new SnapshotCodec();
        private readonly IFileCommit committer;
        public FileSaveStore() : this(new SameVolumeCommit()) { }
        public FileSaveStore(IFileCommit committer) { this.committer = committer ?? throw new ArgumentNullException(nameof(committer)); }
        public Snapshot Load(string path)
        {
            using (var stream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read))
            {
                if (stream.Length > SnapshotCodec.ConditionMaxBytes) throw new InvalidDataException("Save exceeds size limit.");
                using (var memory = new MemoryStream()) { stream.CopyTo(memory); return codec.Decode(memory.ToArray()); }
            }
        }
        public void Save(string path, Snapshot snapshot)
        {
            byte[] bytes = codec.Encode(snapshot);
            string full = Path.GetFullPath(path);
            Directory.CreateDirectory(Path.GetDirectoryName(full));
            // A corrupt current file must not replace the last-known-good backup.
            if (File.Exists(full))
            {
                Snapshot current = Load(full);
                if (current.SchemaVersion != snapshot.SchemaVersion || current.ContentFingerprint != snapshot.ContentFingerprint
                    || current.TestOnly != snapshot.TestOnly)
                    throw new InvalidDataException("Existing save has a different schema or content scope; use a separate destination.");
            }
            WriteAndCommit(full, bytes, full + ".bak");
        }
        // Explicit user recovery. Validate domain/content before writing; preserve both the
        // selected backup and the displaced primary. Caller must serialize all file operations.
        public string RecoverBackup(string path, Action<Snapshot> validate)
        {
            if (validate == null) throw new ArgumentNullException(nameof(validate));
            string full = Path.GetFullPath(path);
            Snapshot recovered = Load(full + ".bak");
            validate(recovered.Copy());
            string preserved = File.Exists(full) ? full + ".recovery-evidence-" + Guid.NewGuid().ToString("N") : null;
            WriteAndCommit(full, codec.Encode(recovered), preserved);
            return preserved;
        }
        private void WriteAndCommit(string full, byte[] bytes, string backup)
        {
            string temporary = full + ".tmp-" + Guid.NewGuid().ToString("N");
            try
            {
                using (var stream = new FileStream(temporary, FileMode.CreateNew, FileAccess.Write, FileShare.None))
                { stream.Write(bytes, 0, bytes.Length); stream.Flush(true); }
                Load(temporary);
                committer.Commit(temporary, full, backup);
            }
            finally { if (File.Exists(temporary)) File.Delete(temporary); }
        }
    }
}
