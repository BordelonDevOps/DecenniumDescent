using System;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text.Json;
using Decennium.Foundation;
using Decennium.Foundation.Laboratory;
using Decennium.Foundation.Tests;
public static class PrefixProbe {
 static readonly JsonSerializerOptions Json=new JsonSerializerOptions{IncludeFields=true,WriteIndented=true};
 static readonly BindingFlags Hidden=BindingFlags.Static|BindingFlags.NonPublic;
 static Snapshot State(ConnectedExpeditionSession s)=>(Snapshot)typeof(FoundationCases).GetMethod("ShortRestCapture",Hidden).Invoke(null,new object[]{s});
 static void Check(bool ok,string why){if(!ok)throw new Exception(why);}
 static void Commit(ConnectedExpeditionSession s,Command c){var r=s.Submit(ExpeditionSeat.Player,c);Check(r.Response==ExpeditionResponse.Committed,c.Id+": "+r.Response);}
 static void End(ConnectedExpeditionSession s){var x=State(s);Commit(s,new Command("probe.end."+x.Revision,x.Encounter.CurrentActor,x.Revision,CommandKind.EndRegularTurn,x.Encounter.CurrentTurnId));}
 static void Guard(ConnectedExpeditionSession s){var x=State(s);Commit(s,new Command("probe.guard."+x.Revision,x.Encounter.CurrentActor,x.Revision,CommandKind.SelectCombatStance,combat:new CombatRequest(x.Encounter.CurrentTurnId,stance:(int)CombatStance.Guarded)));}
 static void Auto(ConnectedExpeditionSession s){int n=0;while(s.View(ExpeditionSeat.Player).NextSeat==ExpeditionTurnSeat.FerryOpponent&&n++<16)Check(s.AdvanceAutomaticDefender().Response==ExpeditionResponse.Committed,"Controller failed");Check(n<=16,"Controller bound");}
 static void Save(ConnectedExpeditionSession s,string dir,string name,bool restore=true){var codec=new SnapshotCodec();var before=codec.Encode(State(s));var p=Path.Combine(dir,name+".ddsave");s.Save(p);if(restore)s.Restore(p);Check(before.SequenceEqual(codec.Encode(State(s))),"Restore mismatch "+name);Console.WriteLine("CHECKPOINT "+name+" r"+State(s).Revision);Console.Out.Flush();}
 public static int Main(string[] args){try{
  var receipts=JsonSerializer.Deserialize<CommandReceipt[]>(File.ReadAllText(args[0]),Json);var dir=args[1];Directory.CreateDirectory(dir);
  var session=ConnectedExpeditionSession.StartWithConsecration(ClericInitialSelection.AuthoredExample(),ClericRepertoireSelection.AuthoredExample(),ClericMilestoneDeclaration.AuthoredExample(),BishopEntryRecord.Announced());
  foreach(var receipt in receipts){var c=CommandHistory.Read(receipt);ExpeditionActionResult r;
   if(receipt.Principal=="TEST_ONLY.session-operator")r=session.SubmitSessionCommand(c);
   else if(receipt.Principal=="TEST_ONLY.tac10-later-defender.v1")r=session.AdvanceAutomaticDefender();
   else r=session.Submit(receipt.Principal=="TEST_ONLY.session-first-opponent"?ExpeditionSeat.FirstOpponent:receipt.Principal=="TEST_ONLY.post-recovery-defender.v1"?ExpeditionSeat.RecoveryOpponent:ExpeditionSeat.Player,c);
   Check(r.Response==ExpeditionResponse.Committed,"Prefix "+receipt.Revision+" "+c.Id+" "+r.Response);
   var actual=State(session).Receipts.Last();Check(actual.Id==receipt.Id&&actual.Principal==receipt.Principal&&actual.Fingerprint==receipt.Fingerprint,"Prefix command diverged at "+receipt.Revision);
   if(receipt.Revision%50==0){Console.WriteLine("PREFIX "+receipt.Revision);Console.Out.Flush();}
   if(receipt.Revision==344)Save(session,dir,"before-contact",false);
  }
  Save(session,dir,"admitted");Guard(session);End(session);Auto(session);Save(session,dir,"before-consecrate");
  var before=State(session);const string actor=ClericRpProfile.Actor,hero=FerryWraithProfile.Hero;
  var c1=new Command("probe.consecrate",actor,before.Revision,CommandKind.UseConsecrate,consecrate:new ConsecrateRequest(8,2));
  Check(session.QueryCastingCommand(ExpeditionSeat.Player,c1).Admissible,"Query rejected");Commit(session,c1);Save(session,dir,"paid");
  var paid=State(session);Check(paid.ResonancePools.Single().Current==before.ResonancePools.Single().Current-2&&paid.RandomState==before.RandomState,"Payment/RNG");
  End(session);Guard(session);End(session);Auto(session);Save(session,dir,"before-rite",false);
  var r0=State(session);var rite=new Command("probe.rite",actor,r0.Revision,CommandKind.UseHealingRite,hero);Commit(session,rite);Save(session,dir,"rite");
  var healed=State(session);File.WriteAllText(Path.Combine(dir,"healing.json"),JsonSerializer.Serialize(session.ObserveConsecrationHealing(ExpeditionSeat.Player,actor),Json));
  File.WriteAllText(Path.Combine(dir,"attack-contributions.json"),JsonSerializer.Serialize(healed.Consecration.Attacks,Json));
  var g=healed.Consecration.Healing.Single(x=>x.RiteCommandId==rite.Id);Check(g.ActualGain>0,"Ground did not genuinely recover HP");
  var expiry=paid.Consecration.Zones.Single().ExpiresAt;int turns=0;while(State(session).RuleClock<expiry&&turns++<12){End(session);Auto(session);}
  Save(session,dir,"expired");var final=State(session);Check(final.Consecration.Zones.Single().End==ConsecrationEnd.Expiry&&final.AbilityRecharges.Single(x=>x.AbilityId==ConsecrationProfile.Consecrate).Remaining==0,"Expiry/recharge");
  File.WriteAllText(Path.Combine(dir,"result.json"),JsonSerializer.Serialize(new{status="PASS",prefixCommands=receipts.Length,final.Revision,final.RuleClock,ground=g,zone=final.Consecration.Zones.Single(),attacks=final.Consecration.Attacks},Json));Console.WriteLine("PASS genuine fresh-prefix execution, paid zone/Ground/expiry");return 0;
 }catch(Exception e){Console.WriteLine(e);if(args.Length>1){Directory.CreateDirectory(args[1]);File.WriteAllText(Path.Combine(args[1],"failure.txt"),e.ToString());}return 1;}}
}
