using System;using System.IO;using System.Linq;using System.Reflection;using System.Text.Json;using Decennium.Foundation;using Decennium.Foundation.Laboratory;using Decennium.Foundation.Tests;
public static class ClosureProbe {
 static readonly JsonSerializerOptions J=new JsonSerializerOptions{IncludeFields=true,WriteIndented=true};
 static Snapshot S(ConnectedExpeditionSession s)=>(Snapshot)typeof(FoundationCases).GetMethod("ShortRestCapture",BindingFlags.NonPublic|BindingFlags.Static).Invoke(null,new object[]{s});
 static void Check(bool v,string m){if(!v)throw new Exception(m);}
 static void Commit(ConnectedExpeditionSession s,Command c){var r=c.Kind==CommandKind.AdvanceClock||c.Kind==CommandKind.EndFixedEncounter?s.SubmitSessionCommand(c):s.Submit(ExpeditionSeat.Player,c);Check(r.Response==ExpeditionResponse.Committed,c.Kind+" "+r.Response);}
 public static int Main(string[] a){try{Directory.CreateDirectory(a[1]);var s=ConnectedExpeditionSession.StartWithConsecration(ClericInitialSelection.AuthoredExample(),ClericRepertoireSelection.AuthoredExample(),ClericMilestoneDeclaration.AuthoredExample(),BishopEntryRecord.Announced());s.Restore(a[0]);var first=S(s);int turns=0;
 while(S(s).Encounter!=null&&turns++<96){var x=S(s);if(s.View(ExpeditionSeat.Player).NextSeat==ExpeditionTurnSeat.FerryOpponent){Check(s.AdvanceAutomaticDefender().Response==ExpeditionResponse.Committed,"Ferry controller");continue;}
  string who=x.Encounter.CurrentActor;var life=x.Lives.Single(z=>z.ActorId==who);var enemy=x.Lives.Single(z=>z.ActorId==FerryWraithProfile.Actor);
  if(!life.Dead&&life.Hp>0){if(!x.Stances.Any(z=>z.TurnOrdinal==x.Encounter.TurnOrdinal&&EncounterHistory.InCurrent(x,z.Revision))){Commit(s,new Command("close.stance."+x.Revision,who,x.Revision,CommandKind.SelectCombatStance,combat:new CombatRequest(x.Encounter.CurrentTurnId,stance:(int)(who==FerryWraithProfile.Hero?CombatStance.Aggressive:CombatStance.Guarded))));x=S(s);}
   if(enemy.Dead&&who==FerryWraithProfile.Hero){Commit(s,new Command("close.exit."+x.Revision,who,x.Revision,CommandKind.EndFixedEncounter,x.Encounter.CurrentTurnId));break;}
   if(!enemy.Dead&&who==FerryWraithProfile.Hero){var c=new Command("close.attack."+x.Revision,who,x.Revision,CommandKind.AttackClub,FerryWraithProfile.Actor,combat:new CombatRequest(x.Encounter.CurrentTurnId,"TEST_ONLY.actor-club",knockout:AttackKnockoutMode.OrdinaryOutcome,pressInstruction:PressHitInstruction.KeepExisting));if(s.QueryCastingCommand(ExpeditionSeat.Player,c).Admissible)Commit(s,c);else throw new Exception("Hero attack unavailable");}
   else if(who==ClericRpProfile.Actor&&x.Lives.Single(z=>z.ActorId==FerryWraithProfile.Hero).Hp<15){var c=new Command("close.rite."+x.Revision,who,x.Revision,CommandKind.UseHealingRite,FerryWraithProfile.Hero);if(s.QueryCastingCommand(ExpeditionSeat.Player,c).Admissible)Commit(s,c);}
  }
  x=S(s);Commit(s,new Command("close.end."+x.Revision,who,x.Revision,CommandKind.EndRegularTurn,x.Encounter.CurrentTurnId));
 }
 var closed=S(s);Check(closed.Encounter==null&&closed.Lives.Single(x=>x.ActorId==FerryWraithProfile.Actor).Dead,"No genuine Dead closure within32 rounds");
 Check(closed.Consecration.Attacks.Any(x=>x.Undead&&x.At>=first.Consecration.Zones.Last().ExpiresAt&&x.Contribution==0&&x.TotalModifier==3),"No actual post-expiry unpenalized Claw");
 s.Save(Path.Combine(a[1],"closed.ddsave"));var hero=closed.Actors.Single(x=>x.Id==FerryWraithProfile.Hero);int beforeX=hero.X;int speed=(int)TestOnlyClubAttackPolicy.WalkingSpeed(closed,hero.Id);
 Commit(s,new Command("close.continue.step",hero.Id,closed.Revision,CommandKind.BeginWorldStep,"walk",-1,0));var moving=S(s);Commit(s,new Command("close.continue.advance",hero.Id,moving.Revision,CommandKind.AdvanceClock,x:30,y:speed));
 var final=S(s);Check(final.Actors.Single(x=>x.Id==hero.Id).X==beforeX-1&&!final.WorldTraversals.Any(x=>x.ActorId==hero.Id),"Ordinary continuation missing");var bytes=new SnapshotCodec().Encode(final);string path=Path.Combine(a[1],"continued.ddsave");s.Save(path);s.Restore(path);Check(bytes.SequenceEqual(new SnapshotCodec().Encode(S(s))),"Continued strict restore changed bytes");
 File.WriteAllText(Path.Combine(a[1],"result.json"),JsonSerializer.Serialize(new{status="PASS",startingRevision=first.Revision,final.Revision,turns,life=final.Lives,attacks=final.Consecration.Attacks.Where(x=>x.Undead),zone=final.Consecration.Zones},J));Console.WriteLine("PASS actual expiry removal, source Dead closure, paid ordinary continuation and strict restore r"+final.Revision);return 0;
 }catch(Exception e){Console.WriteLine(e);if(a.Length>1)File.WriteAllText(Path.Combine(a[1],"failure.txt"),e.ToString());return 1;}}
}
