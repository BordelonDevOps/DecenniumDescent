#if DECENNIUM_TEST_ONLY && (UNITY_EDITOR || DEVELOPMENT_BUILD || HEADLESS_TESTS)
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Security.Cryptography;
using System.Text;

namespace Decennium.Foundation.Laboratory
{
    /// <summary>Authored facts for one public knowledge-only project. The actor has Alchemy5 and
    /// primary-tool proficiency, ordinary suitable tools/station at the plot, visual sufficient
    /// evidence and two legal work Watches [0,8h),[8h,16h). This is not general character acquisition,
    /// evidence adjudication, rest, purchasing or permission to manufacture the formula's output.</summary>
    public sealed class SharedResearchFixture
    {
        public const string Recipe = "recipe-4", Recipe14 = "recipe-14", Evidence = "research.guild-notes", FreshEvidence = "research.independent-notes",
            LegibleFormula = "research.legible-formula", Recipe14Evidence = "research.recipe14.guild-notes",
            Recipe14FreshEvidence = "research.recipe14.independent-notes", Recipe14LegibleFormula = "research.recipe14.legible-formula",
            Supplies = "research.writing-supplies";
        private readonly string[] recipeIds;
        public IReadOnlyList<string> RecipeIds { get; }
        public string RecipeId => recipeIds.Length==1?recipeIds[0]:null;
        public string WorkerId { get; }
        public bool Qualified { get; }
        public bool Accessible { get; }
        public bool Sufficient { get; }
        public bool StationSuitable { get; }
        public SharedResearchFixture(string workerId = TestOnlyPolicy.CompanionId, bool qualified = true,
            bool accessible = true, bool sufficient = true, bool stationSuitable = true,string recipeId=Recipe,IEnumerable<string> recipeIds=null)
        {
            var selected=(recipeIds??new[]{recipeId}).ToArray();
            if ((workerId != TestOnlyPolicy.ActorId && workerId != TestOnlyPolicy.CompanionId)
                ||recipeIds!=null&&recipeId!=Recipe||selected.Length<1||selected.Length>2
                ||selected.Any(x=>x!=Recipe&&x!=Recipe14)||selected.Distinct(StringComparer.Ordinal).Count()!=selected.Length)
                throw new ArgumentException("Unknown supplied researcher or formula profile.");
            this.recipeIds=selected.OrderBy(x=>Selector(x)).ToArray();RecipeIds=Array.AsReadOnly(this.recipeIds);
            WorkerId = workerId; Qualified = qualified; Accessible = accessible; Sufficient = sufficient; StationSuitable = stationSuitable;
        }
        public bool SupportsRecipe(string recipeId)=>recipeIds.Contains(recipeId,StringComparer.Ordinal);
        public static int Selector(string recipeId)=>recipeId==Recipe?0:recipeId==Recipe14?1:-1;
        public static string RecipeForSelector(int selector)=>selector==0?Recipe:selector==1?Recipe14:null;
        public static string EvidenceFor(string recipeId,bool fresh=false,bool copy=false)
            =>recipeId==Recipe?(copy?LegibleFormula:fresh?FreshEvidence:Evidence)
                :recipeId==Recipe14?(copy?Recipe14LegibleFormula:fresh?Recipe14FreshEvidence:Recipe14Evidence):null;
        public static int Difficulty(string recipeId)=>recipeId==Recipe?8:recipeId==Recipe14?11:throw new ArgumentException("Unknown formula profile.",nameof(recipeId));
        public static long MinimumResearchHours(string recipeId)=>recipeId==Recipe?0:recipeId==Recipe14?0:throw new ArgumentException("Unknown formula profile.",nameof(recipeId));
        internal string Key
        {
            get {
                string facts=WorkerId+"|"+Qualified+"|"+Accessible+"|"+Sufficient+"|"+StationSuitable;
                if(RecipeId==Recipe)return "research-v1|recipe4-V4-32b2bf00c28584ad259c343bc5b961126d25078c094444c05bf3caf0c9edda5e|H8|INT-DC8|visual-evidence|retain-knowledge-work|retry-full-H|first-labor-copy-cost|windows0-8-16|"+facts;
                if(RecipeId==Recipe14)return "research-v2|recipe14-source-46a4d52728ee6956f0bebcb5d2103ffd5bc67ba4|H8|INT-DC11|visual-evidence|retain-knowledge-work|retry-full-H|first-labor-copy-cost|windows0-8-16|"+facts;
                return "research-multi-v1|source-46a4d52728ee6956f0bebcb5d2103ffd5bc67ba4|"+string.Join(",",recipeIds)+"|recipe-keyed-formula-history|H8|"+facts;
            }
        }
    }
    public static class FormulaResearchRules
    {
        public static RuleTime RequiredTime(long minimumResearchHours)
        {
            if (minimumResearchHours < 0) throw new ArgumentOutOfRangeException(nameof(minimumResearchHours));
            return new RuleTime(checked(Math.Max(8, minimumResearchHours) * 3600));
        }
        public static bool Succeeds(int natural, int modifier, int dc) => PlaytestRolls.TaskCheck(natural, modifier, dc).Degree >= TaskDegree.Success;
        public static bool Knows(Snapshot s, string actor, string recipe) => s.FormulaWork.Any(x => x.WorkerId == actor && x.RecipeId == recipe && x.Status == FormulaWorkStatus.Success);
    }

    /// <summary>One pre-existing TEST_ONLY FL-07 facility, with a supplied Fortified context,
    /// suitable site, research furnishings and permission. These facts grant no construction marks.
    /// The structural numbers below belong to the fixture, not a general facility specification.</summary>
    public sealed class TestOnlyResearchStationProfile
    {
        public const string InstanceId="TEST_ONLY.research-station",StructureProfileId="TEST_ONLY.FL07.research-station";
        private const string Offsite="TEST_ONLY.research-station-offsite";
        internal const int CheckBonus=2;
        internal ObjectStructureRecord InitialStructure { get; }
        internal string ResearcherId { get; }
        internal bool FurnishingsInstalled { get; }
        internal bool LawfulUse { get; }

        public TestOnlyResearchStationProfile(string researcherId=TestOnlyPolicy.CompanionId,bool lawfulUse=true,
            bool furnishingsInstalled=true,bool atWorksite=true,bool intact=true)
        {
            if(researcherId!=TestOnlyPolicy.ActorId&&researcherId!=TestOnlyPolicy.CompanionId)
                throw new ArgumentException("Unknown TEST_ONLY researcher.",nameof(researcherId));
            ResearcherId=researcherId;LawfulUse=lawfulUse;FurnishingsInstalled=furnishingsInstalled;
            InitialStructure=new ObjectStructureRecord(InstanceId,StructureProfileId,TestOnlyPolicy.ActorId,TestOnlyPolicy.ActorId,
                atWorksite?TestOnlyCropPolicy.PlotId:Offsite,ObjectMaterial.WoodLeather,5,intact?5:0,0,new RuleQuantity(50));
        }

        internal string Key=>"FL07-46a4d52728ee6956f0bebcb5d2103ffd5bc67ba4|recipe-4|fortified-authored|"
            +InstanceId+"|"+StructureProfileId+"|"+InitialStructure.OwnerId+"|"+InitialStructure.CustodianId+"|"
            +InitialStructure.LocationId+"|"+InitialStructure.Material+"|"+InitialStructure.MassPounds+"|"
            +InitialStructure.MaximumHp.ToString(CultureInfo.InvariantCulture)+"|"+InitialStructure.Hp.ToString(CultureInfo.InvariantCulture)+"|"
            +InitialStructure.BaselineCopper.ToString(CultureInfo.InvariantCulture)+"|"
            +ResearcherId+"|"+LawfulUse+"|"+FurnishingsInstalled;
    }

    public sealed partial class TestOnlySharedWorldPolicy
    {
        private SharedResearchFixture research;
        private TestOnlyResearchStationProfile researchStation;

        public TestOnlySharedWorldPolicy EnableResearchStation(TestOnlyResearchStationProfile profile)
        {
            if(initializationStarted||researchStation!=null||crafting==null||repair==null
                ||research?.RecipeId!=SharedResearchFixture.Recipe)
                throw new InvalidOperationException("Select the station once before initializing a recipe-4 research/crafting/repair host.");
            if(profile==null)throw new ArgumentNullException(nameof(profile));
            if(profile.ResearcherId!=research.WorkerId)throw new ArgumentException("Research station permission binding names another researcher.",nameof(profile));
            researchStation=profile;
            using(var sha=SHA256.Create())ContentFingerprint="TEST_ONLY.research-station-v1-"+string.Concat(sha.ComputeHash(
                Encoding.UTF8.GetBytes(ContentFingerprint+"|"+profile.Key)).Select(x=>x.ToString("x2",CultureInfo.InvariantCulture)));
            return this;
        }

        private void InitializeResearchStation(Snapshot s)
        {
            if(researchStation!=null)s.Structures=s.Structures.Concat(new[]{researchStation.InitialStructure}).ToArray();
        }

        private static string ResearchFingerprint(string body, SharedResearchFixture facts)
        {
            using (var sha = SHA256.Create()) return "TEST_ONLY.research-v1-" + string.Concat(sha.ComputeHash(Encoding.UTF8.GetBytes(body + "|" + facts.Key)).Select(x => x.ToString("x2", CultureInfo.InvariantCulture)));
        }
        private void InitializeResearch(Snapshot s)
        {
            if (research == null || connectedFormulaResearch) return;
            s.Work = new WorkLedger(s.Work.Lots.Concat(new[] { new ResourceLot(SharedResearchFixture.Supplies, "writing-allotment-1sp", 3, TestOnlyCropPolicy.PlotId, research.WorkerId) }), s.Work.WorkerIntervals, s.Work.Reservations);
            s.InventoryLots = s.InventoryLots.Concat(new[] { new InventoryLotRecord(SharedResearchFixture.Supplies, "", research.WorkerId, new RuleQuantity(3), default, NutritionKind.None, null, InventoryAccess.Ground) }).ToArray();
        }
        private string ValidateFormulaProfile(Snapshot s)
        {
            var station=s.Structures.SingleOrDefault(x=>x.Id==TestOnlyResearchStationProfile.InstanceId);
            if(researchStation==null ? station!=null : station==null||station.ProfileId!=TestOnlyResearchStationProfile.StructureProfileId)
                return "InvalidResearchStationBinding";
            if(research==null)return s.FormulaWork.Length==0?null:"FormulaFixtureNotSelected";
            return s.FormulaWork.Any(x=>!research.SupportsRecipe(x.RecipeId))?"FormulaFixtureMismatch":ValidateConnectedFormulaResearch(s);
        }
        private static bool FormulaCommand(CommandKind kind) => kind == CommandKind.StartFormulaResearch || kind == CommandKind.StartFormulaCopy
            || kind == CommandKind.PauseFormulaWork || kind == CommandKind.ResumeFormulaWork || kind == CommandKind.CancelFormulaWork;
        private static bool FormulaOpen(FormulaWorkRecord job) => job.Status == FormulaWorkStatus.Working || job.Status == FormulaWorkStatus.Paused || job.Status == FormulaWorkStatus.AwaitingCheck;
        private static void PutFormula(Snapshot s, FormulaWorkRecord job) => s.FormulaWork = s.FormulaWork.Select(x => x.Id == job.Id ? job : x).ToArray();
        private static FormulaWorkRecord ChangeFormula(Snapshot s, FormulaWorkRecord job, FormulaWorkStatus status, ActiveWorkProgress progress = null,
            int first = 0, int second = 0, int natural = 0) => new FormulaWorkRecord(job.Id, job.WorkerId, job.RecipeId, job.EvidenceId, job.MethodId,
                job.Kind, status, job.StartedAt, s.RuleClock, progress ?? job.Work, first, second, natural, job.PreviousAttemptId);
        private static RuleTime? ResearchWindowEnd(RuleTime at) => at < new RuleTime(28800) ? new RuleTime(28800) : at < new RuleTime(57600) ? new RuleTime(57600) : (RuleTime?)null;
        private bool ResearchCapable(Snapshot s, string actor) => research != null && actor == research.WorkerId && CapableWorker(s, actor)
            && !View(s, actor).BlocksSight && AvailableHands(s, actor) >= 1;
        private bool ResearchParticipantInCombat(Snapshot s, string actor) => s.InventoryCombat
            && (connectedFormulaResearch ? WorldTiming.ForEncounter(s).Order : s.WorldSchedule.Order).Contains(actor);
        private string ResearchAccess(Snapshot s, string actor, bool requireWindow = true, bool requiresPrimaryTool = true)
            => ResearchAccessConstraintV1(s, actor, requireWindow, requiresPrimaryTool)?.NativeCode;

        private NativeCommandConstraintV1 ResearchAccessConstraintV1(Snapshot s, string actor, bool requireWindow = true, bool requiresPrimaryTool = true)
        {
            if (actor != research.WorkerId || !research.Qualified
                || connectedFormulaResearch && !s.Trades.Any(x => x.WorkerId == actor
                    && x.TradeId == SharedCraftingFixture.TradeId && x.Level >= 5)) return new NativeCommandConstraintV1("ResearchCredentialMissing", "engine/com.decennium.foundation/Laboratory/Model/SharedFormulaResearch.cs", 157);
            if (!research.Accessible || !research.Sufficient) return new NativeCommandConstraintV1("ResearchEvidenceUnavailable", "engine/com.decennium.foundation/Laboratory/Model/SharedFormulaResearch.cs", 158);
            if (!research.StationSuitable) return new NativeCommandConstraintV1("ResearchStationUnavailable", "engine/com.decennium.foundation/Laboratory/Model/SharedFormulaResearch.cs", 159);
            if(requiresPrimaryTool && TargetInActiveRepair(s,SharedCraftingFixture.ToolId))return new NativeCommandConstraintV1("ResearchToolInRepair", "engine/com.decennium.foundation/Laboratory/Model/SharedFormulaResearch.cs", 160);
            if (connectedFormulaResearch) {
                if (!ConnectedResearchWorkshopAvailable(s)) return new NativeCommandConstraintV1("ResearchToolsOrStationUnavailable", "engine/com.decennium.foundation/Laboratory/Model/SharedFormulaResearch.cs", 162);
            } else if(crafting!=null&&(CraftingRestrictions.StationUseBlocked(s,SharedCraftingFixture.StationId)||requiresPrimaryTool && s.Structures.Single(x=>x.Id==SharedCraftingFixture.ToolId).Broken))return new NativeCommandConstraintV1("ResearchToolsOrStationUnavailable", "engine/com.decennium.foundation/Laboratory/Model/SharedFormulaResearch.cs", 163);
            if (!ResearchCapable(s, actor)) return new NativeCommandConstraintV1("ResearchWorkerIncapable", "engine/com.decennium.foundation/Laboratory/Model/SharedFormulaResearch.cs", 164);
            var body = s.Actors.Single(x => x.Id == actor);
            if (s.WorldTraversals.Any(x => x.ActorId == actor) || Math.Max(Math.Abs(body.X - 3), Math.Abs(body.Y - 3)) > 1) return new NativeCommandConstraintV1("ResearchStationOutOfReach", "engine/com.decennium.foundation/Laboratory/Model/SharedFormulaResearch.cs", 166);
            if (ResearchParticipantInCombat(s, actor)) return new NativeCommandConstraintV1("ResearchParticipantInCombat", "engine/com.decennium.foundation/Laboratory/Model/SharedFormulaResearch.cs", 167);
            if (requireWindow && !ResearchWindowEnd(s.RuleClock).HasValue) return new NativeCommandConstraintV1("ResearchWorkWindowClosed", "engine/com.decennium.foundation/Laboratory/Model/SharedFormulaResearch.cs", 168);
            return null;
        }
        private static void BookFormula(Snapshot s, FormulaWorkRecord job)
        {
            var end = CampGreens.Add(s.RuleClock, job.Work.Remaining); var window = ResearchWindowEnd(s.RuleClock).Value; if (window < end) end = window;
            string id = job.Id + ".labor." + (s.Revision + 1).ToString(CultureInfo.InvariantCulture);
            s.Work = s.Work.Reserve(job.Id, new[] { new WorkerInterval(id, job.Id, job.WorkerId, s.RuleClock, end) }, Array.Empty<ResourceReservation>());
        }
        private static void PauseFormula(Snapshot s, FormulaWorkRecord job)
        {
            if (job.Status != FormulaWorkStatus.Working) return;
            s.Work = s.Work.CancelFutureWork(job.Id, s.RuleClock);
            PutFormula(s, ChangeFormula(s, job, FormulaWorkStatus.Paused, job.Work.Interrupt(false)));
        }
        private void PauseIncompatibleFormulaWork(Snapshot s)
        {
            if (research == null) return;
            foreach (var job in s.FormulaWork.Where(x => x.Status == FormulaWorkStatus.Working).ToArray()) {
                if (connectedFormulaResearch) {
                    if (ResearchAccess(s, job.WorkerId, requireWindow: false) != null) PauseFormula(s, job);
                    continue;
                }
                if (!ResearchCapable(s, job.WorkerId) || (s.InventoryCombat && s.WorldSchedule.Order.Contains(job.WorkerId))
                    || (s.SchemaVersion < 17 || job.Kind == FormulaWorkKind.Research) && TargetInActiveRepair(s,SharedCraftingFixture.ToolId)
                    || crafting!=null&&(CraftingRestrictions.StationUseBlocked(s,SharedCraftingFixture.StationId)
                        || (s.SchemaVersion < 17 || job.Kind == FormulaWorkKind.Research) && s.Structures.Single(x=>x.Id==SharedCraftingFixture.ToolId).Broken)) PauseFormula(s, job);
            }
        }
        private static RuleTime? NextFormulaBoundary(Snapshot s)
        {
            var ends = s.FormulaWork.Where(x => x.Status == FormulaWorkStatus.Working).Select(x => s.Work.WorkerIntervals.Single(w => w.JobId == x.Id && w.Start <= s.RuleClock && w.End > s.RuleClock).End).ToArray();
            return ends.Length == 0 ? (RuleTime?)null : ends.Min();
        }
        private static void CreditFormulaWork(Snapshot s, RuleTime elapsed, ICollection<string> ready)
        {
            foreach (var job in s.FormulaWork.Where(x => x.Status == FormulaWorkStatus.Working).ToArray()) {
                if (job.Kind == FormulaWorkKind.Copy && job.Work.Labor == default) s.Work = s.Work.Consume(job.Id, job.Id + ".supplies");
                var progress = job.Work.Credit(elapsed); FormulaWorkStatus status = FormulaWorkStatus.Working;
                if (progress.Complete) {
                    status = job.Kind == FormulaWorkKind.Copy ? FormulaWorkStatus.Success : FormulaWorkStatus.AwaitingCheck;
                    if (status == FormulaWorkStatus.AwaitingCheck) ready.Add(job.Id);
                } else if (!s.Work.WorkerIntervals.Any(w => w.JobId == job.Id && w.Start <= s.RuleClock && w.End > s.RuleClock)) status = FormulaWorkStatus.Paused;
                PutFormula(s, ChangeFormula(s, job, status, progress));
            }
        }
        private void FinishFormulaCheck(Snapshot s, FormulaWorkRecord job)
        {
            var actorFacts = CharacterStateFacts.ForActor(s, job.WorkerId);
            var facts = actorFacts.Rules;
            int modifier = facts.AbilityModifier(CharacterAbility.Intelligence) + facts.ProficiencyBonus;
            // Schema16 histories retain their original check outcomes. Schema17 corrects actual tool checks.
            if (s.SchemaVersion >= 17) modifier += actorFacts.InjuryPenalty(CharacterAbility.Intelligence, toolCheck: true);
            if(ResearchStationIneligibility(s,job)==null)modifier+=TestOnlyResearchStationProfile.CheckBonus;
            var roll = PlaytestDice.RollD20(s.RandomState, disadvantageSources:
                View(s, job.WorkerId).Has(ConditionKind.Poisoned) || FrightenedRules.VisibleSource(s, job.WorkerId) ? 1 : 0);
            s.RandomState = roll.NextRandomState;
            var status = FormulaResearchRules.Succeeds(roll.Natural, modifier, SharedResearchFixture.Difficulty(job.RecipeId)) ? FormulaWorkStatus.Success : FormulaWorkStatus.Failure;
            PutFormula(s, ChangeFormula(s, job, status, first: roll.First, second: roll.Second ?? 0, natural: roll.Natural));
        }

        private string ResearchStationIneligibility(Snapshot s,FormulaWorkRecord job)
        {
            if(researchStation==null||job.Kind!=FormulaWorkKind.Research||job.RecipeId!=SharedResearchFixture.Recipe)
                return "ResearchStationNotSelected";
            if(!researchStation.LawfulUse||job.WorkerId!=researchStation.ResearcherId)return "ResearchStationPermissionMissing";
            if(!researchStation.FurnishingsInstalled)return "ResearchStationFurnishingsUnavailable";
            var station=s.Structures.SingleOrDefault(x=>x.Id==TestOnlyResearchStationProfile.InstanceId);
            if(station==null||station.ProfileId!=TestOnlyResearchStationProfile.StructureProfileId)
                return "ResearchStationInstanceMissing";
            if(station.LocationId!=TestOnlyCropPolicy.PlotId)return "ResearchStationOffsite";
            if(station.OwnerId!=researchStation.InitialStructure.OwnerId||station.CustodianId!=researchStation.InitialStructure.CustodianId)
                return "ResearchStationCustodyChanged";
            if(station.Broken)return "ResearchStationBroken";
            return CraftingRestrictions.StationUseBlocked(s,station.Id)?"ResearchStationUseBlocked":null;
        }
        private NativeCommandConstraintV1 FormulaWorkConstraintV1(Snapshot s, Command c, out string recipeId, out bool copy, out string method, out FormulaWorkRecord current)
        {
            recipeId = null; copy = false; method = null; current = null;
            if (research == null) return new NativeCommandConstraintV1("FormulaWorkNotSelected", "engine/com.decennium.foundation/Laboratory/Model/SharedFormulaResearch.cs", 246);
            if (c.Inventory != null || c.Combat != null) return new NativeCommandConstraintV1("InvalidFormulaRequest", "engine/com.decennium.foundation/Laboratory/Model/SharedFormulaResearch.cs", 247);
            if (connectedFormulaResearch) {
                var failure = ConnectedResearchAdmissionConstraintV1(s, c);
                if (failure != null) return failure;
            }
            bool start = c.Kind == CommandKind.StartFormulaResearch || c.Kind == CommandKind.StartFormulaCopy;
            if (start) {
                if (c.X < 0 || c.X > 1 || c.Kind == CommandKind.StartFormulaCopy && c.X != 0) return new NativeCommandConstraintV1("UnknownResearchMethod", "engine/com.decennium.foundation/Laboratory/Model/SharedFormulaResearch.cs", 254);
                recipeId=SharedResearchFixture.RecipeForSelector(c.Y);
                string selectedRecipeId=recipeId;
                if(!research.SupportsRecipe(recipeId))return new NativeCommandConstraintV1("FormulaNotSelected", "engine/com.decennium.foundation/Laboratory/Model/SharedFormulaResearch.cs", 256);
                copy = c.Kind == CommandKind.StartFormulaCopy;
                if (copy ? c.Target != SharedResearchFixture.EvidenceFor(recipeId,copy:true)
                    : c.Target != SharedResearchFixture.EvidenceFor(recipeId) && c.Target != SharedResearchFixture.EvidenceFor(recipeId,fresh:true)) return new NativeCommandConstraintV1("UnknownResearchEvidence", "engine/com.decennium.foundation/Laboratory/Model/SharedFormulaResearch.cs", 259);
                var access = ResearchAccessConstraintV1(s, c.Actor, requiresPrimaryTool: !copy || s.SchemaVersion < 17); if (access != null) return access;
                if (FormulaResearchRules.Knows(s, c.Actor, recipeId)) return new NativeCommandConstraintV1("FormulaAlreadyKnown", "engine/com.decennium.foundation/Laboratory/Model/SharedFormulaResearch.cs", 261);
                if (s.FormulaWork.Any(x => x.WorkerId == c.Actor && FormulaOpen(x)) || OrdinaryInventory.Busy(s, c.Actor)) return new NativeCommandConstraintV1("WorkerBusy", "engine/com.decennium.foundation/Laboratory/Model/SharedFormulaResearch.cs", 262);
                if (copy && s.Work.AvailableAmount(SharedResearchFixture.Supplies) < new RuleQuantity(1)) return new NativeCommandConstraintV1("WritingSuppliesUnavailable", "engine/com.decennium.foundation/Laboratory/Model/SharedFormulaResearch.cs", 263);
                method = copy ? "method.transcription" : c.X == 0 ? "method.sequence-analysis" : "method.independent-comparison";
                if (!copy && s.FormulaWork.Any(x => x.WorkerId == c.Actor && x.RecipeId==selectedRecipeId&&x.EvidenceId == c.Target && x.MethodId == (c.Kind == CommandKind.StartFormulaCopy ? "method.transcription" : c.X == 0 ? "method.sequence-analysis" : "method.independent-comparison") && x.Status == FormulaWorkStatus.Failure)) return new NativeCommandConstraintV1("UnchangedResearchEvidence", "engine/com.decennium.foundation/Laboratory/Model/SharedFormulaResearch.cs", 265);
                if (s.FormulaWork.Length == FormulaWorkValidation.MaxRecords) return new NativeCommandConstraintV1("FormulaHistoryCapacityReached", "engine/com.decennium.foundation/Laboratory/Model/SharedFormulaResearch.cs", 266);
                return null;
            }
            if (c.X != 0||c.Y!=0) return new NativeCommandConstraintV1("InvalidFormulaRequest", "engine/com.decennium.foundation/Laboratory/Model/SharedFormulaResearch.cs", 276);
            current = s.FormulaWork.SingleOrDefault(x => x.Id == c.Target && x.WorkerId == c.Actor); if (current == null) return new NativeCommandConstraintV1("UnknownFormulaWork", "engine/com.decennium.foundation/Laboratory/Model/SharedFormulaResearch.cs", 277);
            if(!research.SupportsRecipe(current.RecipeId))return new NativeCommandConstraintV1("FormulaNotSelected", "engine/com.decennium.foundation/Laboratory/Model/SharedFormulaResearch.cs", 278);
            if (!FormulaOpen(current)) return new NativeCommandConstraintV1("FormulaWorkClosed", "engine/com.decennium.foundation/Laboratory/Model/SharedFormulaResearch.cs", 279);
            if (c.Kind == CommandKind.PauseFormulaWork) {
                if (current.Status != FormulaWorkStatus.Working) return new NativeCommandConstraintV1("FormulaNotWorking", "engine/com.decennium.foundation/Laboratory/Model/SharedFormulaResearch.cs", 281);
                return null;
            }
            if (c.Kind == CommandKind.CancelFormulaWork) {
                return null;
            }
            if (c.Kind == CommandKind.ResumeFormulaWork) {
                if (current.Status == FormulaWorkStatus.Working) return new NativeCommandConstraintV1("FormulaAlreadyWorking", "engine/com.decennium.foundation/Laboratory/Model/SharedFormulaResearch.cs", 292);
                var access = ResearchAccessConstraintV1(s, c.Actor, current.Status != FormulaWorkStatus.AwaitingCheck, current.Kind == FormulaWorkKind.Research || s.SchemaVersion < 17); if (access != null) return access;
                if (OrdinaryInventory.Busy(s, c.Actor)) return new NativeCommandConstraintV1("WorkerBusy", "engine/com.decennium.foundation/Laboratory/Model/SharedFormulaResearch.cs", 294);
                return null;
            }
            return new NativeCommandConstraintV1("InvalidFormulaRequest", "engine/com.decennium.foundation/Laboratory/Model/SharedFormulaResearch.cs", 299);
        }
        private string ResolveFormulaWork(Snapshot s, Command c, bool assessOnly = false)
        {
            var failure = FormulaWorkConstraintV1(s, c, out var recipeId, out bool copy, out var method, out var current);
            if (failure != null || assessOnly) return failure?.NativeCode;
            if (c.Kind == CommandKind.StartFormulaResearch || c.Kind == CommandKind.StartFormulaCopy) {
                var prior = s.FormulaWork.Where(x => x.WorkerId == c.Actor && x.RecipeId == recipeId && x.Status == FormulaWorkStatus.Failure)
                    .OrderByDescending(x=>x.UpdatedAt).ThenBy(x=>x.Id,StringComparer.Ordinal).FirstOrDefault();
                string id = "formula." + (s.Revision + 1).ToString(CultureInfo.InvariantCulture);
                var job = new FormulaWorkRecord(id, c.Actor, recipeId, c.Target, method, copy ? FormulaWorkKind.Copy : FormulaWorkKind.Research,
                    FormulaWorkStatus.Working, s.RuleClock, s.RuleClock, new ActiveWorkProgress(new[] { copy ? new RuleTime(3600) : FormulaResearchRules.RequiredTime(SharedResearchFixture.MinimumResearchHours(recipeId)) }), previousAttemptId: prior?.Id ?? "");
                if (copy) s.Work = s.Work.Reserve(id, Array.Empty<WorkerInterval>(), new[] { new ResourceReservation(id + ".supplies", id, SharedResearchFixture.Supplies, 1) });
                BookFormula(s, job); s.FormulaWork = s.FormulaWork.Concat(new[] { job }).ToArray(); return null;
            }
            if (c.Kind == CommandKind.PauseFormulaWork) { PauseFormula(s, current); return null; }
            if (c.Kind == CommandKind.CancelFormulaWork) {
                s.Work = s.Work.CancelFutureWork(current.Id, s.RuleClock);
                if (current.Kind == FormulaWorkKind.Copy && current.Work.Labor == default) s.Work = s.Work.Release(current.Id, current.Id + ".supplies");
                PutFormula(s, ChangeFormula(s, current, FormulaWorkStatus.Cancelled)); return null;
            }
            if (c.Kind == CommandKind.ResumeFormulaWork) {
                if (current.Status == FormulaWorkStatus.AwaitingCheck) { FinishFormulaCheck(s, current); return null; }
                BookFormula(s, current); PutFormula(s, ChangeFormula(s, current, FormulaWorkStatus.Working)); return null;
            }
            throw new InvalidOperationException("Formula admission did not select an execution branch.");
        }

    }
}
#endif
